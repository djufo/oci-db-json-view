import { createContext, useContext, type CSSProperties, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../lib/cn";

// Global density mode (emibs-theme/2 / issue-2181). Density is a scope, not a
// per-component prop: wrap a subtree in <DensityScope density="compact"> and
// every density-aware component tightens together. The scope does two things:
//   1. Provides the active density through context (`useDensity`) so components
//      can branch class names / logic.
//   2. Resolves the active `--density-*` aliases from the theme's comfortable/
//      compact scale tokens (see tokens.ts `densityTokens`) so token-driven CSS
//      reads one stable variable regardless of mode.
// DensityScope is meant to sit inside a ThemeScope (which supplies the scale
// tokens it references); nesting scopes overrides density for that subtree.

export type Density = "comfortable" | "compact";

export const DENSITIES: readonly Density[] = ["comfortable", "compact"];
export const DEFAULT_DENSITY: Density = "comfortable";

const DensityContext = createContext<Density>(DEFAULT_DENSITY);

// Read the ambient density. An explicit `override` (e.g. a legacy per-component
// `density` prop) always wins, so migrating a component to the scope keeps its
// prop working for back-compat.
export function useDensity(override?: Density): Density {
  const scoped = useContext(DensityContext);
  return override ?? scoped;
}

// The active `--density-*` aliases for a mode, pointing at the theme's scale
// tokens. Applied by DensityScope; also exported so a product can wire density
// onto an existing element without the wrapper div.
export function densityToStyle(density: Density): CSSProperties {
  return {
    "--density-control-height": `var(--density-control-height-${density})`,
    "--density-row-height": `var(--density-row-height-${density})`,
    "--density-gap": `var(--density-gap-${density})`,
    "--density-padding-x": `var(--density-padding-x-${density})`,
    "--density-padding-y": `var(--density-padding-y-${density})`,
  } as CSSProperties;
}

export type DensityScopeProps = HTMLAttributes<HTMLDivElement> & {
  density?: Density;
  children: ReactNode;
};

export function DensityScope({ density = DEFAULT_DENSITY, className, style, children, ...props }: DensityScopeProps) {
  return (
    <DensityContext.Provider value={density}>
      <div
        {...props}
        className={cn("ui-density-scope", className)}
        data-density={density}
        style={{ ...densityToStyle(density), ...style }}
      >
        {children}
      </div>
    </DensityContext.Provider>
  );
}
