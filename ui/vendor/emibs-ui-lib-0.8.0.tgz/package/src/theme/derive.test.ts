import { describe, expect, it } from "vitest";
import { deriveDarkTokens } from "./derive";
import { evaluateThemeContrast, summarizeThemeContrast } from "./contrast";
import { neutralLightTheme, type ThemeTokenMap } from "./tokens";

function valueOf(tokens: ThemeTokenMap, name: string): string {
  return tokens.find((token) => token.name === name)?.value ?? "";
}

// Rough sRGB luminance for ordering assertions (0 dark … 1 light).
function luminance(hex: string): number {
  const raw = hex.replace("#", "");
  const r = parseInt(raw.slice(0, 2), 16) / 255;
  const g = parseInt(raw.slice(2, 4), 16) / 255;
  const b = parseInt(raw.slice(4, 6), 16) / 255;
  return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}

describe("deriveDarkTokens", () => {
  const derived = deriveDarkTokens(neutralLightTheme.tokens);

  it("darkens backgrounds/surfaces and lightens text", () => {
    expect(luminance(valueOf(derived, "--bg"))).toBeLessThan(0.15);
    expect(luminance(valueOf(derived, "--surface"))).toBeLessThan(0.2);
    expect(luminance(valueOf(derived, "--text"))).toBeGreaterThan(0.75);
    expect(luminance(valueOf(derived, "--text-muted"))).toBeGreaterThan(0.4);
    // bg must sit below surface, which sits below muted (layering preserved).
    expect(luminance(valueOf(derived, "--bg"))).toBeLessThan(luminance(valueOf(derived, "--surface")));
    expect(luminance(valueOf(derived, "--surface"))).toBeLessThan(luminance(valueOf(derived, "--surface-muted")));
  });

  it("leaves space/radius/type tokens unchanged", () => {
    for (const name of ["--space-4", "--radius-md", "--font-sans", "--type-md"]) {
      expect(valueOf(derived, name)).toBe(valueOf(neutralLightTheme.tokens, name));
    }
  });

  it("preserves hue while lifting a dark accent for dark surfaces", () => {
    // neutral --accent is a dark teal (#0f766e); derived should be a brighter teal.
    const light = valueOf(neutralLightTheme.tokens, "--accent");
    const dark = valueOf(derived, "--accent");
    expect(dark).not.toBe(light);
    expect(luminance(dark)).toBeGreaterThan(luminance(light));
  });

  it("produces AA-adequate body/action contrast on the derived dark surfaces", () => {
    const summary = summarizeThemeContrast(evaluateThemeContrast({ tokens: derived }));
    expect(summary.failed).toBe(0);
  });

  it("is deterministic", () => {
    expect(deriveDarkTokens(neutralLightTheme.tokens)).toEqual(derived);
  });

  it("passes through unparseable color values without crashing", () => {
    const result = deriveDarkTokens([
      { name: "--bg", value: "oklch(0.98 0.01 250)" },
      { name: "--text", value: "rebeccapurple" },
      { name: "--space-4", value: "16px" },
    ]);
    expect(valueOf(result, "--bg")).toBe("oklch(0.98 0.01 250)");
    expect(valueOf(result, "--text")).toBe("rebeccapurple");
    expect(valueOf(result, "--space-4")).toBe("16px");
  });

  it("handles partial drafts (subset of tokens)", () => {
    const result = deriveDarkTokens([{ name: "--bg", value: "#ffffff" }]);
    expect(result).toHaveLength(1);
    expect(luminance(valueOf(result, "--bg"))).toBeLessThan(0.15);
  });
});
