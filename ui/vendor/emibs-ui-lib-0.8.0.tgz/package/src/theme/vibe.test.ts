import { describe, expect, it } from "vitest";
import {
  buildVibeThemePrompt,
  VIBE_THEME_MODEL,
  vibeThemeProposalFromJson,
  vibeThemeTokenNames,
} from "./vibe";
import { neutralDarkTheme, neutralLightTheme, type ThemeTokenMap } from "./tokens";

function proposalJson(overrides: Record<string, unknown> = {}) {
  return JSON.stringify({
    id: "calm-operator",
    label: "Calm operator",
    light: vibeTokens({
      "--bg": "#f8fafc",
      "--surface": "#ffffff",
      "--surface-muted": "#eef2f7",
      "--surface-strong": "#111827",
      "--border": "#d8e0ea",
      "--border-strong": "#aebccc",
      "--text": "#101827",
      "--text-muted": "#4b5b70",
      "--accent": "#2563eb",
      "--accent-strong": "#1d4ed8",
      "--info": "#2563eb",
      "--success": "#15803d",
      "--warning": "#a16207",
      "--danger": "#b91c1c",
      "--focus": "#2563eb",
      "--control-min-height": "42px",
    }),
    dark: vibeTokens({
      "--bg": "#0f172a",
      "--surface": "#111827",
      "--surface-muted": "#1f2937",
      "--surface-strong": "#020617",
      "--border": "#334155",
      "--border-strong": "#475569",
      "--text": "#e5edf7",
      "--text-muted": "#a7b4c7",
      "--accent": "#60a5fa",
      "--accent-strong": "#93c5fd",
      "--info": "#60a5fa",
      "--success": "#4ade80",
      "--warning": "#facc15",
      "--danger": "#fb7185",
      "--focus": "#93c5fd",
      "--control-min-height": "42px",
    }),
    ...overrides,
  });
}

function vibeTokens(values: Record<(typeof vibeThemeTokenNames)[number], string>) {
  return vibeThemeTokenNames.map((name) => ({ name, value: values[name] }));
}

function valueOf(tokens: ThemeTokenMap, name: string) {
  return tokens.find((token) => token.name === name)?.value;
}

describe("buildVibeThemePrompt", () => {
  it("pins the model, exact 16-token contract, and preview-before-apply instruction", () => {
    const prompt = buildVibeThemePrompt({ prompt: "Calm audit desk" });

    expect(prompt).toContain(VIBE_THEME_MODEL);
    expect(prompt).toContain("Both light and dark arrays must contain exactly these 16 tokens");
    expect(prompt).toContain("--control-min-height");
    expect(prompt).toContain("must not be applied until the caller explicitly accepts them");
  });
});

describe("vibeThemeProposalFromJson", () => {
  it("validates a light+dark 16-token proposal and expands it to full EmibsTheme maps", () => {
    const result = vibeThemeProposalFromJson(proposalJson(), { prompt: "Calm audit desk" });

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.proposal.model).toBe(VIBE_THEME_MODEL);
    expect(result.proposal.tokenCount).toBe(16);
    expect(result.proposal.light.colorScheme).toBe("light");
    expect(result.proposal.dark.colorScheme).toBe("dark");
    expect(result.proposal.light.tokens).toHaveLength(neutralLightTheme.tokens.length);
    expect(result.proposal.dark.tokens).toHaveLength(neutralDarkTheme.tokens.length);
    expect(valueOf(result.proposal.light.tokens, "--bg")).toBe("#f8fafc");
    expect(valueOf(result.proposal.dark.tokens, "--bg")).toBe("#0f172a");
    expect(valueOf(result.proposal.light.tokens, "--space-4")).toBe(valueOf(neutralLightTheme.tokens, "--space-4"));
    expect(result.proposal.contrast.light.total).toBeGreaterThan(0);
    expect(result.proposal.contrast.dark.total).toBeGreaterThan(0);
  });

  it("rejects unknown, missing, duplicate, and extra proposed tokens before apply", () => {
    const invalidLight = [
      ...vibeTokens(Object.fromEntries(vibeThemeTokenNames.map((name) => [name, "#ffffff"])) as Record<(typeof vibeThemeTokenNames)[number], string>),
      { name: "--not-a-token", value: "#fff" },
      { name: "--accent", value: "#111111" },
    ].filter((token) => token.name !== "--focus");

    const result = vibeThemeProposalFromJson(proposalJson({ light: invalidLight }), { prompt: "Broken" });

    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.some((error) => error.includes("unknown token name"))).toBe(true);
    expect(result.errors.some((error) => error.includes("missing required token"))).toBe(true);
    expect(result.errors.some((error) => error.includes("defined more than once"))).toBe(true);
    expect(result.errors.some((error) => error.includes("exactly 16 token entries"))).toBe(true);
  });
});
