import type { EmibsTheme, ThemeTokenName } from "./tokens";

const scoreColorTokenNames = [
  ["background", "--bg"],
  ["surface", "--surface"],
  ["surface-raised", "--surface-muted"],
  ["text", "--text"],
  ["text-secondary", "--text-secondary"],
  ["text-muted", "--text-muted"],
  ["border", "--border"],
  ["border-strong", "--border-strong"],
  ["primary", "--accent"],
  ["primary-text", "--primary-text"],
  ["accent", "--success"],
  ["accent-text", "--accent-text"],
  ["warning", "--warning"],
  ["danger", "--danger"],
  ["link", "--link"],
  ["focus", "--focus"],
] as const satisfies readonly (readonly [string, ThemeTokenName])[];

/** Generates the Score color declarations from a complete emibs-theme/2 map. */
export function scoreThemeToCss(theme: EmibsTheme): string {
  const values = new Map(theme.tokens.map(({ name, value }) => [name, value]));
  return `:root {\n${scoreColorTokenNames
    .map(([scoreName, themeName]) => `  --score-color-${scoreName}: ${values.get(themeName) ?? ""};`)
    .join("\n")}\n}\n`;
}
