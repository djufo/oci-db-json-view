import { evaluateThemeContrast, summarizeThemeContrast } from "./contrast";
import {
  neutralDarkTheme,
  neutralLightTheme,
  themeTokenDefinitions,
  type EmibsTheme,
  type ThemeToken,
  type ThemeTokenMap,
  type ThemeTokenName,
} from "./tokens";

export const VIBE_THEME_MODEL = "claude-opus-4-8";

export const vibeThemeTokenNames = [
  "--bg",
  "--surface",
  "--surface-muted",
  "--surface-strong",
  "--border",
  "--border-strong",
  "--text",
  "--text-muted",
  "--accent",
  "--accent-strong",
  "--info",
  "--success",
  "--warning",
  "--danger",
  "--focus",
  "--control-min-height",
] as const satisfies readonly ThemeTokenName[];

export type VibeThemeTokenName = (typeof vibeThemeTokenNames)[number];

export type VibeThemePromptRequest = {
  prompt: string;
  id?: string;
  label?: string;
  baseLight?: EmibsTheme;
  baseDark?: EmibsTheme;
};

export type VibeThemeProposal = {
  id: string;
  label: string;
  model: typeof VIBE_THEME_MODEL;
  prompt: string;
  light: EmibsTheme;
  dark: EmibsTheme;
  tokenCount: number;
  contrast: {
    light: ReturnType<typeof summarizeThemeContrast>;
    dark: ReturnType<typeof summarizeThemeContrast>;
  };
};

export type VibeThemeProposalResult =
  | { ok: true; proposal: VibeThemeProposal }
  | { ok: false; errors: string[] };

export function buildVibeThemePrompt({
  prompt,
  id,
  label,
  baseLight = neutralLightTheme,
  baseDark = neutralDarkTheme,
}: VibeThemePromptRequest): string {
  const tokenList = vibeThemeTokenNames
    .map((name) => {
      const definition = themeTokenDefinitions.find((token) => token.name === name);
      return `- ${name}: ${definition?.label ?? name}`;
    })
    .join("\n");

  return [
    `Use ${VIBE_THEME_MODEL} to propose an EMIBS theme token set.`,
    "Return JSON only. Do not include markdown.",
    `Theme id: ${id ?? "derive a kebab-case id from the vibe"}`,
    `Theme label: ${label ?? "derive a concise label from the vibe"}`,
    `Vibe prompt: ${prompt.trim()}`,
    "Return exactly this shape:",
    '{"id":"...","label":"...","light":[{"name":"--bg","value":"#ffffff"}],"dark":[{"name":"--bg","value":"#000000"}]}',
    "Both light and dark arrays must contain exactly these 16 tokens, once each:",
    tokenList,
    "Use CSS color values for color tokens and a CSS length for --control-min-height.",
    "Keep light and dark as preview proposals. They must not be applied until the caller explicitly accepts them.",
    "Reference light base:",
    JSON.stringify(pickVibeTokens(baseLight.tokens)),
    "Reference dark base:",
    JSON.stringify(pickVibeTokens(baseDark.tokens)),
  ].join("\n");
}

export function vibeThemeProposalFromJson(
  input: string,
  {
    prompt,
    baseLight = neutralLightTheme,
    baseDark = neutralDarkTheme,
  }: { prompt: string; baseLight?: EmibsTheme; baseDark?: EmibsTheme },
): VibeThemeProposalResult {
  let parsed: unknown;
  try {
    parsed = JSON.parse(input);
  } catch {
    return { ok: false, errors: ["Not valid JSON - check the model response syntax."] };
  }

  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return { ok: false, errors: ["Expected a JSON object describing a vibe theme proposal."] };
  }

  const record = parsed as Record<string, unknown>;
  const errors: string[] = [];
  const id = typeof record.id === "string" && record.id.trim() ? record.id.trim() : slugify(record.label, "vibe-theme");
  const label = typeof record.label === "string" && record.label.trim() ? record.label.trim() : "Vibe theme";
  const lightTokens = validateVibeTokens(record.light, "light", errors);
  const darkTokens = validateVibeTokens(record.dark, "dark", errors);

  if (errors.length > 0 || !lightTokens || !darkTokens) return { ok: false, errors };

  const light: EmibsTheme = {
    id: `${id}-light`,
    label: `${label} light`,
    colorScheme: "light",
    tokens: overlayTokens(baseLight.tokens, lightTokens),
  };
  const dark: EmibsTheme = {
    id: `${id}-dark`,
    label: `${label} dark`,
    colorScheme: "dark",
    tokens: overlayTokens(baseDark.tokens, darkTokens),
  };

  return {
    ok: true,
    proposal: {
      id,
      label,
      model: VIBE_THEME_MODEL,
      prompt,
      light,
      dark,
      tokenCount: vibeThemeTokenNames.length,
      contrast: {
        light: summarizeThemeContrast(evaluateThemeContrast(light)),
        dark: summarizeThemeContrast(evaluateThemeContrast(dark)),
      },
    },
  };
}

function validateVibeTokens(raw: unknown, mode: "light" | "dark", errors: string[]): ThemeToken[] | null {
  if (!Array.isArray(raw)) {
    errors.push(`Field "${mode}" must be an array of 16 token entries.`);
    return null;
  }

  const allowed = new Set<string>(vibeThemeTokenNames);
  const seen = new Set<string>();
  const tokens: ThemeToken[] = [];

  raw.forEach((entry, index) => {
    if (typeof entry !== "object" || entry === null) {
      errors.push(`${mode}[${index}] must be an object with "name" and "value".`);
      return;
    }
    const token = entry as Record<string, unknown>;
    const name = token.name;
    const value = token.value;
    if (typeof name !== "string" || !allowed.has(name)) {
      errors.push(`${mode}[${index}] has unknown token name ${JSON.stringify(name ?? null)}.`);
      return;
    }
    if (seen.has(name)) {
      errors.push(`${mode} token "${name}" is defined more than once.`);
      return;
    }
    if (typeof value !== "string" || value.trim() === "") {
      errors.push(`${mode} token "${name}" must have a non-empty string value.`);
      return;
    }
    seen.add(name);
    tokens.push({ name: name as ThemeTokenName, value: value.trim() });
  });

  const missing = vibeThemeTokenNames.filter((name) => !seen.has(name));
  if (missing.length > 0) errors.push(`${mode} is missing required token${missing.length === 1 ? "" : "s"}: ${missing.join(", ")}.`);
  if (raw.length !== vibeThemeTokenNames.length) {
    errors.push(`${mode} must contain exactly ${vibeThemeTokenNames.length} token entries.`);
  }

  return errors.length > 0 ? null : tokens;
}

function overlayTokens(base: ThemeTokenMap, tokens: readonly ThemeToken[]): ThemeTokenMap {
  const proposed = new Map(tokens.map((token) => [token.name, token.value]));
  return base.map((token) => ({ name: token.name, value: proposed.get(token.name) ?? token.value }));
}

function pickVibeTokens(tokens: ThemeTokenMap): ThemeToken[] {
  const byName = new Map(tokens.map((token) => [token.name, token.value]));
  return vibeThemeTokenNames.map((name) => ({ name, value: byName.get(name) ?? "" }));
}

function slugify(value: unknown, fallback: string): string {
  if (typeof value !== "string") return fallback;
  const slug = value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return slug || fallback;
}
