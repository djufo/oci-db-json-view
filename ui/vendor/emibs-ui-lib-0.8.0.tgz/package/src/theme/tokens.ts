import type { CSSProperties } from "react";

// emibs-theme/1 vocabulary — the original 34-token map. emibs-theme/2 is a
// STRICT SUPERSET of this list: every name below stays, in the same order, so a
// /1 theme upgrades losslessly (see `themeFromJson` + THEME_JSON_FORMAT).
export const legacyThemeTokenNames = [
  // Color
  "--bg",
  "--surface",
  "--surface-muted",
  "--surface-strong",
  "--border",
  "--border-strong",
  "--text",
  "--text-muted",
  "--accent",
  "--accent-strong",
  "--info",
  "--success",
  "--warning",
  "--danger",
  "--focus",
  // Space
  "--space-1",
  "--space-2",
  "--space-3",
  "--space-4",
  "--space-5",
  "--space-6",
  "--control-min-height",
  // Radius
  "--radius-sm",
  "--radius-md",
  "--radius-lg",
  "--radius-xl",
  "--radius-pill",
  // Type
  "--font-sans",
  "--font-mono",
  "--type-xs",
  "--type-sm",
  "--type-md",
  "--type-lg",
  "--type-xl",
] as const;

// emibs-theme/2 additions — the semantic families the score/elitua operator UIs
// re-implement ad hoc today (priority bands, delivery classes, capacity states
// incl. a visually distinct `unknown`, severity, freshness), a system-wide
// interaction-state model, and a global density scale. Every one of these is a
// new token; none change the meaning of a /1 token, so /1 stays a valid subset.
export const v2ThemeTokenNames = [
  // Score color slots absent from emibs-theme/1. These remain /2-only so
  // emibs-theme/1 payloads keep their original ordered vocabulary.
  "--text-secondary",
  "--primary-text",
  "--accent-text",
  "--link",
  // Inverse emphasis band — an ink surface with light text on it, in EVERY
  // theme (see foundationalTokens for why these are literals, not var()).
  "--surface-inverse",
  "--text-inverse",
  // Semantic — priority bands (shelved … campaign, dormant → active)
  "--band-shelved",
  "--band-deep-park",
  "--band-parked",
  "--band-normal",
  "--band-infra",
  "--band-campaign",
  // Semantic — delivery classes
  "--delivery-convergence",
  "--delivery-build",
  "--delivery-orchestration",
  // Semantic — capacity states (unknown is deliberately neutral, never `ok`)
  "--capacity-ok",
  "--capacity-warn",
  "--capacity-critical",
  "--capacity-unknown",
  // Semantic — severity ramp
  "--severity-info",
  "--severity-warning",
  "--severity-error",
  "--severity-critical",
  // Semantic — freshness
  "--freshness-fresh",
  "--freshness-stale",
  "--freshness-offline",
  // Interaction-state model (see STATES.md)
  "--state-hover-bg",
  "--state-active-bg",
  "--state-selected-bg",
  "--state-selected-border",
  "--state-focus-ring",
  "--state-readonly-bg",
  "--state-disabled-opacity",
  "--state-busy-opacity",
  // Density scale (comfortable / compact) — resolved by DensityScope
  "--density-control-height-comfortable",
  "--density-control-height-compact",
  "--density-row-height-comfortable",
  "--density-row-height-compact",
  "--density-gap-comfortable",
  "--density-gap-compact",
  "--density-padding-x-comfortable",
  "--density-padding-x-compact",
  "--density-padding-y-comfortable",
  "--density-padding-y-compact",
] as const;

export const themeTokenNames = [...legacyThemeTokenNames, ...v2ThemeTokenNames] as const;

export type ThemeTokenName = (typeof themeTokenNames)[number];
export type LegacyThemeTokenName = (typeof legacyThemeTokenNames)[number];
export type ThemeTokenCategory = "color" | "space" | "radius" | "type" | "semantic" | "state" | "density";
export type ThemeTokenValueKind = "color" | "length" | "fontFamily" | "number";

export type ThemeToken = {
  name: ThemeTokenName;
  value: string;
};

export type ThemeTokenMap = readonly ThemeToken[];

export type ThemeTokenDefinition = {
  name: ThemeTokenName;
  label: string;
  category: ThemeTokenCategory;
  valueKind: ThemeTokenValueKind;
};

export const themeTokenDefinitions: readonly ThemeTokenDefinition[] = [
  { name: "--bg", label: "Background", category: "color", valueKind: "color" },
  { name: "--surface", label: "Surface", category: "color", valueKind: "color" },
  { name: "--surface-muted", label: "Surface muted", category: "color", valueKind: "color" },
  { name: "--surface-strong", label: "Surface strong", category: "color", valueKind: "color" },
  { name: "--border", label: "Border", category: "color", valueKind: "color" },
  { name: "--border-strong", label: "Border strong", category: "color", valueKind: "color" },
  { name: "--text", label: "Text", category: "color", valueKind: "color" },
  { name: "--text-muted", label: "Text muted", category: "color", valueKind: "color" },
  { name: "--accent", label: "Accent", category: "color", valueKind: "color" },
  { name: "--accent-strong", label: "Accent strong", category: "color", valueKind: "color" },
  { name: "--info", label: "Info", category: "color", valueKind: "color" },
  { name: "--success", label: "Success", category: "color", valueKind: "color" },
  { name: "--warning", label: "Warning", category: "color", valueKind: "color" },
  { name: "--danger", label: "Danger", category: "color", valueKind: "color" },
  { name: "--focus", label: "Focus", category: "color", valueKind: "color" },
  { name: "--space-1", label: "Space 1", category: "space", valueKind: "length" },
  { name: "--space-2", label: "Space 2", category: "space", valueKind: "length" },
  { name: "--space-3", label: "Space 3", category: "space", valueKind: "length" },
  { name: "--space-4", label: "Space 4", category: "space", valueKind: "length" },
  { name: "--space-5", label: "Space 5", category: "space", valueKind: "length" },
  { name: "--space-6", label: "Space 6", category: "space", valueKind: "length" },
  { name: "--control-min-height", label: "Control minimum height", category: "space", valueKind: "length" },
  { name: "--radius-sm", label: "Radius small", category: "radius", valueKind: "length" },
  { name: "--radius-md", label: "Radius medium", category: "radius", valueKind: "length" },
  { name: "--radius-lg", label: "Radius large", category: "radius", valueKind: "length" },
  { name: "--radius-xl", label: "Radius x-large", category: "radius", valueKind: "length" },
  { name: "--radius-pill", label: "Radius pill", category: "radius", valueKind: "length" },
  { name: "--font-sans", label: "Sans font", category: "type", valueKind: "fontFamily" },
  { name: "--font-mono", label: "Mono font", category: "type", valueKind: "fontFamily" },
  { name: "--type-xs", label: "Type x-small", category: "type", valueKind: "length" },
  { name: "--type-sm", label: "Type small", category: "type", valueKind: "length" },
  { name: "--type-md", label: "Type medium", category: "type", valueKind: "length" },
  { name: "--type-lg", label: "Type large", category: "type", valueKind: "length" },
  { name: "--type-xl", label: "Type x-large", category: "type", valueKind: "length" },
  { name: "--text-secondary", label: "Text secondary", category: "color", valueKind: "color" },
  { name: "--primary-text", label: "Primary text", category: "color", valueKind: "color" },
  { name: "--accent-text", label: "Accent text", category: "color", valueKind: "color" },
  { name: "--link", label: "Link", category: "color", valueKind: "color" },
  { name: "--surface-inverse", label: "Surface inverse", category: "color", valueKind: "color" },
  { name: "--text-inverse", label: "Text inverse", category: "color", valueKind: "color" },
  // --- emibs-theme/2 semantic families ---
  { name: "--band-shelved", label: "Band shelved", category: "semantic", valueKind: "color" },
  { name: "--band-deep-park", label: "Band deep park", category: "semantic", valueKind: "color" },
  { name: "--band-parked", label: "Band parked", category: "semantic", valueKind: "color" },
  { name: "--band-normal", label: "Band normal", category: "semantic", valueKind: "color" },
  { name: "--band-infra", label: "Band infra", category: "semantic", valueKind: "color" },
  { name: "--band-campaign", label: "Band campaign", category: "semantic", valueKind: "color" },
  { name: "--delivery-convergence", label: "Delivery convergence", category: "semantic", valueKind: "color" },
  { name: "--delivery-build", label: "Delivery build", category: "semantic", valueKind: "color" },
  { name: "--delivery-orchestration", label: "Delivery orchestration", category: "semantic", valueKind: "color" },
  { name: "--capacity-ok", label: "Capacity ok", category: "semantic", valueKind: "color" },
  { name: "--capacity-warn", label: "Capacity warn", category: "semantic", valueKind: "color" },
  { name: "--capacity-critical", label: "Capacity critical", category: "semantic", valueKind: "color" },
  { name: "--capacity-unknown", label: "Capacity unknown", category: "semantic", valueKind: "color" },
  { name: "--severity-info", label: "Severity info", category: "semantic", valueKind: "color" },
  { name: "--severity-warning", label: "Severity warning", category: "semantic", valueKind: "color" },
  { name: "--severity-error", label: "Severity error", category: "semantic", valueKind: "color" },
  { name: "--severity-critical", label: "Severity critical", category: "semantic", valueKind: "color" },
  { name: "--freshness-fresh", label: "Freshness fresh", category: "semantic", valueKind: "color" },
  { name: "--freshness-stale", label: "Freshness stale", category: "semantic", valueKind: "color" },
  { name: "--freshness-offline", label: "Freshness offline", category: "semantic", valueKind: "color" },
  // --- emibs-theme/2 interaction-state model ---
  { name: "--state-hover-bg", label: "State hover surface", category: "state", valueKind: "color" },
  { name: "--state-active-bg", label: "State active surface", category: "state", valueKind: "color" },
  { name: "--state-selected-bg", label: "State selected surface", category: "state", valueKind: "color" },
  { name: "--state-selected-border", label: "State selected border", category: "state", valueKind: "color" },
  { name: "--state-focus-ring", label: "State focus ring", category: "state", valueKind: "color" },
  { name: "--state-readonly-bg", label: "State readonly surface", category: "state", valueKind: "color" },
  { name: "--state-disabled-opacity", label: "State disabled opacity", category: "state", valueKind: "number" },
  { name: "--state-busy-opacity", label: "State busy opacity", category: "state", valueKind: "number" },
  // --- emibs-theme/2 density scale ---
  { name: "--density-control-height-comfortable", label: "Density control height (comfortable)", category: "density", valueKind: "length" },
  { name: "--density-control-height-compact", label: "Density control height (compact)", category: "density", valueKind: "length" },
  { name: "--density-row-height-comfortable", label: "Density row height (comfortable)", category: "density", valueKind: "length" },
  { name: "--density-row-height-compact", label: "Density row height (compact)", category: "density", valueKind: "length" },
  { name: "--density-gap-comfortable", label: "Density gap (comfortable)", category: "density", valueKind: "length" },
  { name: "--density-gap-compact", label: "Density gap (compact)", category: "density", valueKind: "length" },
  { name: "--density-padding-x-comfortable", label: "Density padding-x (comfortable)", category: "density", valueKind: "length" },
  { name: "--density-padding-x-compact", label: "Density padding-x (compact)", category: "density", valueKind: "length" },
  { name: "--density-padding-y-comfortable", label: "Density padding-y (comfortable)", category: "density", valueKind: "length" },
  { name: "--density-padding-y-compact", label: "Density padding-y (compact)", category: "density", valueKind: "length" },
];

export const themeTokenCategoryLabels: Record<ThemeTokenCategory, string> = {
  color: "Color",
  space: "Space",
  radius: "Radius",
  type: "Type",
  semantic: "Semantic",
  state: "Interaction state",
  density: "Density",
};

export type EmibsTheme = {
  id: string;
  label: string;
  colorScheme: "light" | "dark";
  tokens: ThemeTokenMap;
};

// Global density scale (emibs-theme/2). Comfortable is the historical default
// (control-min-height 44px); compact tightens controls, rows, gaps and padding
// for dense operator surfaces. These are the *scale* definitions; DensityScope
// resolves the active `--density-*` aliases from them at runtime. Density is a
// global, brand-independent scale, so it lives in foundationalTokens — every
// theme shares one density language.
export const densityTokens = [
  { name: "--density-control-height-comfortable", value: "44px" },
  { name: "--density-control-height-compact", value: "32px" },
  { name: "--density-row-height-comfortable", value: "40px" },
  { name: "--density-row-height-compact", value: "30px" },
  { name: "--density-gap-comfortable", value: "12px" },
  { name: "--density-gap-compact", value: "8px" },
  { name: "--density-padding-x-comfortable", value: "16px" },
  { name: "--density-padding-x-compact", value: "10px" },
  { name: "--density-padding-y-comfortable", value: "10px" },
  { name: "--density-padding-y-compact", value: "5px" },
] as const satisfies ThemeTokenMap;

// Interaction-state scalars (emibs-theme/2). The state *surfaces* are colors and
// derive per-theme (see semanticColorDefaults); disabled/busy are opacity
// multipliers, brand-independent, so they live here. See STATES.md.
export const interactionStateScalarTokens = [
  { name: "--state-disabled-opacity", value: "0.5" },
  { name: "--state-busy-opacity", value: "0.7" },
] as const satisfies ThemeTokenMap;

// Semantic color defaults (emibs-theme/2). Every value DERIVES from an existing
// /1 token via var()/color-mix, so a /1 theme upgrades losslessly and each
// theme's brand palette flows through automatically. score/elitua reference
// themes override selected entries with curated values from their live palettes
// (see defineCuratedTheme below). Invariant: `--capacity-unknown` is a neutral
// grey mixed from text-muted/border — it must never read as `--capacity-ok`.
export const semanticColorDefaults = [
  // Priority bands: dormant → active.
  { name: "--band-shelved", value: "color-mix(in oklab, var(--text-muted) 45%, var(--surface))" },
  { name: "--band-deep-park", value: "color-mix(in oklab, var(--text-muted) 62%, var(--surface))" },
  { name: "--band-parked", value: "var(--text-muted)" },
  { name: "--band-normal", value: "var(--text)" },
  { name: "--band-infra", value: "var(--info)" },
  { name: "--band-campaign", value: "var(--accent)" },
  // Delivery classes.
  { name: "--delivery-convergence", value: "var(--success)" },
  { name: "--delivery-build", value: "var(--info)" },
  { name: "--delivery-orchestration", value: "color-mix(in oklab, var(--accent) 70%, var(--focus))" },
  // Capacity states.
  { name: "--capacity-ok", value: "var(--success)" },
  { name: "--capacity-warn", value: "var(--warning)" },
  { name: "--capacity-critical", value: "var(--danger)" },
  { name: "--capacity-unknown", value: "color-mix(in oklab, var(--text-muted) 60%, var(--border))" },
  // Severity ramp.
  { name: "--severity-info", value: "var(--info)" },
  { name: "--severity-warning", value: "var(--warning)" },
  { name: "--severity-error", value: "var(--danger)" },
  { name: "--severity-critical", value: "color-mix(in oklab, var(--danger) 82%, var(--text))" },
  // Freshness.
  { name: "--freshness-fresh", value: "var(--success)" },
  { name: "--freshness-stale", value: "var(--warning)" },
  { name: "--freshness-offline", value: "var(--text-muted)" },
] as const satisfies ThemeTokenMap;

// Interaction-state SURFACES (emibs-theme/2, see STATES.md). Colors, so they
// derive per-theme; the disabled/busy scalars live in
// interactionStateScalarTokens. Order matches themeTokenDefinitions' `state`
// group so createCustomTheme (definition order) and a theme's own token order
// stay identical.
export const interactionStateColorTokens = [
  { name: "--state-hover-bg", value: "color-mix(in oklab, var(--text) 6%, transparent)" },
  { name: "--state-active-bg", value: "color-mix(in oklab, var(--text) 12%, transparent)" },
  { name: "--state-selected-bg", value: "color-mix(in oklab, var(--accent) 14%, transparent)" },
  { name: "--state-selected-border", value: "var(--accent)" },
  { name: "--state-focus-ring", value: "var(--focus)" },
  { name: "--state-readonly-bg", value: "color-mix(in oklab, var(--surface-muted) 60%, var(--surface))" },
] as const satisfies ThemeTokenMap;

// foundationalTokens carries every non-brand token, in the SAME order as
// themeTokenDefinitions (space/radius/type, then semantic, state, density), so a
// theme's token list = [brand colors, ...foundationalTokens] lines up 1:1 with
// the definition order.
export const foundationalTokens = [
  { name: "--space-1", value: "4px" },
  { name: "--space-2", value: "8px" },
  { name: "--space-3", value: "12px" },
  { name: "--space-4", value: "16px" },
  { name: "--space-5", value: "24px" },
  { name: "--space-6", value: "32px" },
  { name: "--control-min-height", value: "44px" },
  { name: "--radius-sm", value: "6px" },
  { name: "--radius-md", value: "8px" },
  { name: "--radius-lg", value: "12px" },
  { name: "--radius-xl", value: "16px" },
  { name: "--radius-pill", value: "999px" },
  {
    name: "--font-sans",
    value: 'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
  },
  { name: "--font-mono", value: '"SFMono-Regular", Consolas, "Liberation Mono", monospace' },
  { name: "--type-xs", value: "0.75rem" },
  { name: "--type-sm", value: "0.875rem" },
  { name: "--type-md", value: "1rem" },
  { name: "--type-lg", value: "1.125rem" },
  { name: "--type-xl", value: "1.375rem" },
  { name: "--text-secondary", value: "var(--text-muted)" },
  { name: "--primary-text", value: "var(--surface)" },
  { name: "--accent-text", value: "var(--text)" },
  { name: "--link", value: "var(--accent)" },
  // Inverse emphasis band: a deliberately ink-dark surface carrying light text,
  // used for shells/scrims/quote bands/code blocks that must stay dark in BOTH
  // polarities. These are LITERALS on purpose, not var() references, and they
  // deliberately have NO derive.ts COLOR_RULES entry.
  //
  // WHY (decided — please do not "fix" this):
  //   * An inverse band's relationship to the page flips polarity with the
  //     theme, and CSS has no shippable way to express "the opposite of --bg"
  //     (color-contrast() is not available), so ANY var()-based default is
  //     wrong in one direction. Declaring them brand-independent constants
  //     makes the intent explicit: the emphasis band is ink in every theme.
  //   * They are NOT in semanticColorDefaults — that list's contract is that
  //     every value derives via var()/color-mix (semanticTokens.test.ts
  //     asserts it), and a literal cannot honour it. They are loose entries
  //     here instead, beside --text-secondary/--primary-text/--accent-text.
  //   * No derive.ts rule means deriveDarkColor returns them unchanged (it
  //     returns early when a token has no COLOR_RULES entry), which is exactly
  //     the intended dark-mode behaviour — not an oversight.
  // They stay per-theme overridable and ThemeStudio-editable like any colour;
  // contrast.ts pairs them so an override that breaks the pair is caught.
  { name: "--surface-inverse", value: "#111827" },
  { name: "--text-inverse", value: "#f8fafc" },
  ...semanticColorDefaults,
  ...interactionStateColorTokens,
  ...interactionStateScalarTokens,
  ...densityTokens,
] as const satisfies ThemeTokenMap;

// Build a reference theme whose semantic/state colors are the derived defaults,
// with a curated OVERRIDE map layered on top (score/elitua pull real values
// from their live palettes). No token is duplicated: overrides replace the
// matching foundational entry in place, so the theme still round-trips.
function overrideFoundationTokens(overrides: Partial<Record<ThemeTokenName, string>>): ThemeToken[] {
  return foundationalTokens.map((token) =>
    overrides[token.name] !== undefined ? { name: token.name, value: overrides[token.name] as string } : { name: token.name, value: token.value },
  );
}

function defineCuratedTheme(
  id: string,
  label: string,
  colorScheme: "light" | "dark",
  brandTokens: readonly ThemeToken[],
  semanticOverrides: Partial<Record<ThemeTokenName, string>>,
): EmibsTheme {
  return { id, label, colorScheme, tokens: [...brandTokens, ...overrideFoundationTokens(semanticOverrides)] };
}

export const neutralLightTheme = {
  id: "neutral-light",
  label: "Neutral light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#f7f8fb" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#eef2f6" },
    { name: "--surface-strong", value: "#19202a" },
    { name: "--border", value: "#d9e0ea" },
    { name: "--border-strong", value: "#b9c4d1" },
    { name: "--text", value: "#1c2530" },
    { name: "--text-muted", value: "#667385" },
    { name: "--accent", value: "#0f766e" },
    { name: "--accent-strong", value: "#115e59" },
    { name: "--info", value: "#2563eb" },
    { name: "--success", value: "#17803b" },
    { name: "--warning", value: "#a16207" },
    { name: "--danger", value: "#c2410c" },
    { name: "--focus", value: "#4f46e5" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const neutralDarkTheme = {
  id: "neutral-dark",
  label: "Neutral dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#0b0f14" },
    { name: "--surface", value: "#141b24" },
    { name: "--surface-muted", value: "#1c2630" },
    { name: "--surface-strong", value: "#060a0f" },
    { name: "--border", value: "#283543" },
    { name: "--border-strong", value: "#3a4a5c" },
    { name: "--text", value: "#e6edf5" },
    { name: "--text-muted", value: "#9fb0c3" },
    { name: "--accent", value: "#2dd4bf" },
    { name: "--accent-strong", value: "#5eead4" },
    { name: "--info", value: "#60a5fa" },
    { name: "--success", value: "#4ade80" },
    { name: "--warning", value: "#fbbf24" },
    { name: "--danger", value: "#fb923c" },
    { name: "--focus", value: "#818cf8" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const neutralThemes = [neutralLightTheme, neutralDarkTheme] as const;

// Score brand theme — mapped from projects/score/ui/src/styles.css shadcn
// tokens so the catalog can preview Score components in their product palette.
// Board: issue-257. Semantic families (issue-2181) are curated from the live
// Score token source (score/ui/tokens/tokens.json): capacity + severity carry
// the exact operator values, bands/delivery map to Score's status/type palette.
const scoreLightSemanticOverrides: Partial<Record<ThemeTokenName, string>> = {
  "--text-secondary": "oklch(0.38 0.032 248)",
  "--primary-text": "oklch(0.985 0.007 95)",
  "--accent-text": "oklch(0.18 0.034 145)",
  "--link": "oklch(0.52 0.16 262)",
  "--capacity-ok": "oklch(0.64 0.15 150)",
  "--capacity-warn": "oklch(0.72 0.13 75)",
  "--capacity-critical": "oklch(0.62 0.2 22)",
  "--severity-info": "oklch(0.5 0.15 258)",
  "--severity-warning": "oklch(0.56 0.11 75)",
  "--severity-error": "oklch(0.54 0.19 22)",
  "--severity-critical": "oklch(0.52 0.19 12)",
  "--band-infra": "oklch(0.52 0.09 190)",
  "--band-campaign": "oklch(0.52 0.2 300)",
  "--delivery-convergence": "oklch(0.52 0.13 150)",
  "--delivery-build": "oklch(0.5 0.15 258)",
  "--delivery-orchestration": "oklch(0.52 0.19 305)",
};

const scoreDarkSemanticOverrides: Partial<Record<ThemeTokenName, string>> = {
  "--text-secondary": "oklch(0.8 0.016 250)",
  "--primary-text": "oklch(0.16 0.02 250)",
  "--accent-text": "oklch(0.16 0.03 145)",
  "--link": "oklch(0.72 0.13 262)",
  "--capacity-ok": "oklch(0.64 0.15 150)",
  "--capacity-warn": "oklch(0.72 0.13 75)",
  "--capacity-critical": "oklch(0.62 0.2 22)",
  "--severity-info": "oklch(0.8 0.1 258)",
  "--severity-warning": "oklch(0.82 0.11 80)",
  "--severity-error": "oklch(0.78 0.14 22)",
  "--severity-critical": "oklch(0.8 0.15 12)",
  "--band-infra": "oklch(0.8 0.08 190)",
  "--band-campaign": "oklch(0.8 0.14 300)",
  "--delivery-convergence": "oklch(0.8 0.11 150)",
  "--delivery-build": "oklch(0.8 0.1 258)",
  "--delivery-orchestration": "oklch(0.8 0.13 305)",
};

export const scoreLightTheme = defineCuratedTheme("score-light", "Score light", "light", [
  { name: "--bg", value: "oklch(0.985 0.007 95)" },
  { name: "--surface", value: "oklch(0.998 0.002 95)" },
  { name: "--surface-muted", value: "oklch(0.963 0.012 90)" },
  { name: "--surface-strong", value: "oklch(0.963 0.012 90)" },
  { name: "--border", value: "oklch(0.87 0.018 92)" },
  { name: "--border-strong", value: "oklch(0.72 0.034 92)" },
  { name: "--text", value: "oklch(0.24 0.03 248)" },
  { name: "--text-muted", value: "oklch(0.47 0.032 248)" },
  { name: "--accent", value: "oklch(0.49 0.12 205)" },
  { name: "--accent-strong", value: "oklch(0.49 0.12 205)" },
  { name: "--info", value: "oklch(0.52 0.16 262)" },
  { name: "--success", value: "oklch(0.65 0.135 145)" },
  { name: "--warning", value: "oklch(0.72 0.142 75)" },
  { name: "--danger", value: "oklch(0.57 0.19 28)" },
  { name: "--focus", value: "oklch(0.61 0.15 205)" },
], scoreLightSemanticOverrides);

export const scoreDarkTheme = defineCuratedTheme("score-dark", "Score dark", "dark", [
  { name: "--bg", value: "oklch(0.17 0.02 250)" },
  { name: "--surface", value: "oklch(0.21 0.021 250)" },
  { name: "--surface-muted", value: "oklch(0.25 0.022 250)" },
  { name: "--surface-strong", value: "oklch(0.25 0.022 250)" },
  { name: "--border", value: "oklch(0.33 0.02 250)" },
  { name: "--border-strong", value: "oklch(0.46 0.025 250)" },
  { name: "--text", value: "oklch(0.93 0.012 250)" },
  { name: "--text-muted", value: "oklch(0.64 0.02 250)" },
  { name: "--accent", value: "oklch(0.66 0.13 205)" },
  { name: "--accent-strong", value: "oklch(0.66 0.13 205)" },
  { name: "--info", value: "oklch(0.72 0.13 262)" },
  { name: "--success", value: "oklch(0.72 0.14 145)" },
  { name: "--warning", value: "oklch(0.78 0.15 75)" },
  { name: "--danger", value: "oklch(0.66 0.19 28)" },
  { name: "--focus", value: "oklch(0.7 0.15 205)" },
], scoreDarkSemanticOverrides);

export const scoreThemes = [scoreLightTheme, scoreDarkTheme] as const;

// eLitua brand theme — extracted from projects/elitua ui/src/styles/theme.scss
// (eLitua blue #046bd2, Brand-DNA dark slate #1e293b, blue-tinted neutrals) and
// adapted to the 15 EmibsTheme tokens. Board: task-274.
// Semantic curation for eLitua (issue-2181): the booking "warm" amber accent
// (theme.scss --color-warm) drives campaign/booking bands; steel-blue secondary
// stands in for infra. Capacity/severity/freshness derive from the brand palette
// already mapped above, so they need no override.
const elituaLightSemanticOverrides: Partial<Record<ThemeTokenName, string>> = {
  "--band-campaign": "oklch(72% 0.14 76)",
  "--band-infra": "oklch(42% 0.08 230)",
};

const elituaDarkSemanticOverrides: Partial<Record<ThemeTokenName, string>> = {
  "--band-campaign": "oklch(78% 0.1 78)",
  "--band-infra": "oklch(70% 0.09 205)",
};

export const elituaLightTheme = defineCuratedTheme("elitua-light", "eLitua light", "light", [
  { name: "--bg", value: "#f3f7fb" },
  { name: "--surface", value: "#ffffff" },
  { name: "--surface-muted", value: "#eaf3fa" },
  { name: "--surface-strong", value: "#1e293b" },
  { name: "--border", value: "#d5e0ea" },
  { name: "--border-strong", value: "#adc0d0" },
  { name: "--text", value: "#1e293b" },
  { name: "--text-muted", value: "#526a7d" },
  { name: "--accent", value: "#046bd2" },
  { name: "--accent-strong", value: "#083f82" },
  { name: "--info", value: "#1a73e8" },
  { name: "--success", value: "#10b981" },
  { name: "--warning", value: "#f59e0b" },
  { name: "--danger", value: "#ef4444" },
  { name: "--focus", value: "#046bd2" },
], elituaLightSemanticOverrides);

// eLitua dark — extracted from the [data-theme="dark"] block (navy dark palette,
// softened accent #42a5f5, cyan info #00b4d8).
export const elituaDarkTheme = defineCuratedTheme("elitua-dark", "eLitua dark", "dark", [
  { name: "--bg", value: "#06101e" },
  { name: "--surface", value: "#0f1c30" },
  { name: "--surface-muted", value: "#162238" },
  { name: "--surface-strong", value: "#030a14" },
  { name: "--border", value: "#1e3050" },
  { name: "--border-strong", value: "#2c4468" },
  { name: "--text", value: "#f0f4f9" },
  { name: "--text-muted", value: "#8eaac8" },
  { name: "--accent", value: "#42a5f5" },
  { name: "--accent-strong", value: "#78b9ff" },
  { name: "--info", value: "#00b4d8" },
  { name: "--success", value: "#34d399" },
  { name: "--warning", value: "#fcd34d" },
  { name: "--danger", value: "#f87171" },
  { name: "--focus", value: "#1a73e8" },
], elituaDarkSemanticOverrides);

export const elituaThemes = [elituaLightTheme, elituaDarkTheme] as const;

// ---------------------------------------------------------------------------
// Travel theme pack — three playful palettes extracted from real travel brands
// and destination palettes (board: issue-354 community theme pack).
//   - Wander : Airbnb brand (Rausch coral #FF385C + Babu teal #00A699).
//     Source: usbrandcolors.com/airbnb-colors, airbnb.design.
//   - Reef   : tropical "Coral Reef" palette (deep ocean #003049, coral #D62828,
//     warm orange #F77F00, gold #FCBF49, sand #EAE2B7). Source: media.io travel.
//   - Dusk   : "Safari Dusk" sunset palette (plum #3A2E39, mauve #6D597A,
//     rose #B56576, coral #E56B6F, peach #EAAC8B). Source: media.io travel.
// AA target: --text on --bg/--surface >= 4.5:1; --accent-strong carries white.
// ---------------------------------------------------------------------------

// Wander — Airbnb-inspired: friendly coral + Babu teal, the classic playful
// booking look.
export const wanderLightTheme = {
  id: "wander-light",
  label: "Wander light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#fdf6f5" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#fdeceb" },
    { name: "--surface-strong", value: "#2b2122" },
    { name: "--border", value: "#f6d6d4" },
    { name: "--border-strong", value: "#ecb3af" },
    { name: "--text", value: "#2b2122" },
    { name: "--text-muted", value: "#6f5f60" },
    { name: "--accent", value: "#ff385c" },
    { name: "--accent-strong", value: "#e0214a" },
    { name: "--info", value: "#008a7e" },
    { name: "--success", value: "#00897b" },
    { name: "--warning", value: "#c2540f" },
    { name: "--danger", value: "#d6283b" },
    { name: "--focus", value: "#ff385c" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const wanderDarkTheme = {
  id: "wander-dark",
  label: "Wander dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#1a1213" },
    { name: "--surface", value: "#241819" },
    { name: "--surface-muted", value: "#2f2021" },
    { name: "--surface-strong", value: "#120c0d" },
    { name: "--border", value: "#3d2a2c" },
    { name: "--border-strong", value: "#523a3c" },
    { name: "--text", value: "#fbeceb" },
    { name: "--text-muted", value: "#c79b9c" },
    { name: "--accent", value: "#ff5a78" },
    { name: "--accent-strong", value: "#ff8095" },
    { name: "--info", value: "#2dd4bf" },
    { name: "--success", value: "#34d399" },
    { name: "--warning", value: "#fb7a4d" },
    { name: "--danger", value: "#f4566a" },
    { name: "--focus", value: "#ff5a78" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const wanderThemes = [wanderLightTheme, wanderDarkTheme] as const;

// Reef — tropical island: sunlit sand + sea light, deep-dive dark. Warm orange
// accent over an ocean-navy strong surface.
export const reefLightTheme = {
  id: "reef-light",
  label: "Reef light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#f2f8f7" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#e3f1ef" },
    { name: "--surface-strong", value: "#003049" },
    { name: "--border", value: "#cfe6e2" },
    { name: "--border-strong", value: "#a9d2cc" },
    { name: "--text", value: "#062a36" },
    { name: "--text-muted", value: "#4f6b71" },
    { name: "--accent", value: "#e26a00" },
    { name: "--accent-strong", value: "#c0211f" },
    { name: "--info", value: "#0a6e8a" },
    { name: "--success", value: "#1f8a52" },
    { name: "--warning", value: "#a86b00" },
    { name: "--danger", value: "#d62828" },
    { name: "--focus", value: "#e26a00" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const reefDarkTheme = {
  id: "reef-dark",
  label: "Reef dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#04161d" },
    { name: "--surface", value: "#0a232c" },
    { name: "--surface-muted", value: "#103039" },
    { name: "--surface-strong", value: "#020e12" },
    { name: "--border", value: "#1c3d47" },
    { name: "--border-strong", value: "#2c5560" },
    { name: "--text", value: "#e7f4f2" },
    { name: "--text-muted", value: "#9cc0bd" },
    { name: "--accent", value: "#ff9e3d" },
    { name: "--accent-strong", value: "#ffb86b" },
    { name: "--info", value: "#38bdf8" },
    { name: "--success", value: "#36c98b" },
    { name: "--warning", value: "#fcbf49" },
    { name: "--danger", value: "#ff6a5c" },
    { name: "--focus", value: "#ff9e3d" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const reefThemes = [reefLightTheme, reefDarkTheme] as const;

// Dusk — golden-hour safari sunset: warm peach light, plum-night dark, rose
// accent.
export const duskLightTheme = {
  id: "dusk-light",
  label: "Dusk light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#fdf4f0" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#f8e7e0" },
    { name: "--surface-strong", value: "#3a2e39" },
    { name: "--border", value: "#f0d6cd" },
    { name: "--border-strong", value: "#e3b6a8" },
    { name: "--text", value: "#3a2e39" },
    { name: "--text-muted", value: "#7d6470" },
    { name: "--accent", value: "#b56576" },
    { name: "--accent-strong", value: "#9d4a5d" },
    { name: "--info", value: "#6d597a" },
    { name: "--success", value: "#4f8068" },
    { name: "--warning", value: "#c07242" },
    { name: "--danger", value: "#d6504f" },
    { name: "--focus", value: "#b56576" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const duskDarkTheme = {
  id: "dusk-dark",
  label: "Dusk dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#1c151b" },
    { name: "--surface", value: "#271d27" },
    { name: "--surface-muted", value: "#332533" },
    { name: "--surface-strong", value: "#120d12" },
    { name: "--border", value: "#3e2f3d" },
    { name: "--border-strong", value: "#574252" },
    { name: "--text", value: "#f6e9ef" },
    { name: "--text-muted", value: "#c2a4b3" },
    { name: "--accent", value: "#d98a98" },
    { name: "--accent-strong", value: "#e8a9b4" },
    { name: "--info", value: "#a98cc0" },
    { name: "--success", value: "#7fb894" },
    { name: "--warning", value: "#eaac8b" },
    { name: "--danger", value: "#e56b6f" },
    { name: "--focus", value: "#d98a98" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const duskThemes = [duskLightTheme, duskDarkTheme] as const;

// ---------------------------------------------------------------------------
// Beach theme pack — three coastal-destination palettes (board: issue-354).
//   - Santorini : whitewashed Aegean (blue #00B2F6, turquoise #66C7BB, sun
//     #FFEF92, white). Source: color-hex.com/color-palette/69943.
//   - Bondi     : warm surf beach (sand #F4E3D7, coral #D0836E, sea-grey
//     #9CA9B1, surf #4B7A90, deep ocean #142B43). Source: color-hex 1021235.
//   - Amalfi    : Mediterranean citrus coast (teal #008080, coral #FF7F50,
//     lemon #FFF44F, mint #98FF98). Source: color-hex 1027678.
// AA target: --text on --bg/--surface >= 4.5:1; --accent-strong carries white
// in light themes / dark text in dark themes (lighter than --accent).
// ---------------------------------------------------------------------------

// Santorini — crisp whitewashed Aegean blue, cool and high-contrast.
export const santoriniLightTheme = {
  id: "santorini-light",
  label: "Santorini light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#f4fbff" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#e6f4fb" },
    { name: "--surface-strong", value: "#0c3a5c" },
    { name: "--border", value: "#cde7f3" },
    { name: "--border-strong", value: "#a7d0e6" },
    { name: "--text", value: "#0c3a5c" },
    { name: "--text-muted", value: "#4a6b80" },
    { name: "--accent", value: "#0e8fd6" },
    { name: "--accent-strong", value: "#0a6fae" },
    { name: "--info", value: "#1f97a8" },
    { name: "--success", value: "#1f9c6e" },
    { name: "--warning", value: "#b27a00" },
    { name: "--danger", value: "#d6453b" },
    { name: "--focus", value: "#0e8fd6" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const santoriniDarkTheme = {
  id: "santorini-dark",
  label: "Santorini dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#04141f" },
    { name: "--surface", value: "#0a2230" },
    { name: "--surface-muted", value: "#102f40" },
    { name: "--surface-strong", value: "#020c12" },
    { name: "--border", value: "#1c3d4f" },
    { name: "--border-strong", value: "#2c5468" },
    { name: "--text", value: "#e7f5fb" },
    { name: "--text-muted", value: "#9bc0d2" },
    { name: "--accent", value: "#38bdf8" },
    { name: "--accent-strong", value: "#7dd3fc" },
    { name: "--info", value: "#5ad1c4" },
    { name: "--success", value: "#34d399" },
    { name: "--warning", value: "#ffd24d" },
    { name: "--danger", value: "#ff6a5c" },
    { name: "--focus", value: "#38bdf8" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const santoriniThemes = [santoriniLightTheme, santoriniDarkTheme] as const;

// Bondi — warm sand + surf blue, deep-ocean strong surface.
export const bondiLightTheme = {
  id: "bondi-light",
  label: "Bondi light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#faf1e9" },
    { name: "--surface", value: "#fffaf6" },
    { name: "--surface-muted", value: "#f1e1d4" },
    { name: "--surface-strong", value: "#142b43" },
    { name: "--border", value: "#e5d2c2" },
    { name: "--border-strong", value: "#d0b6a1" },
    { name: "--text", value: "#142b43" },
    { name: "--text-muted", value: "#6b6258" },
    { name: "--accent", value: "#2f6d86" },
    { name: "--accent-strong", value: "#245468" },
    { name: "--info", value: "#3f7287" },
    { name: "--success", value: "#2f8f63" },
    { name: "--warning", value: "#b06a3a" },
    { name: "--danger", value: "#c4503e" },
    { name: "--focus", value: "#2f6d86" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const bondiDarkTheme = {
  id: "bondi-dark",
  label: "Bondi dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#0c1a26" },
    { name: "--surface", value: "#142838" },
    { name: "--surface-muted", value: "#1c3346" },
    { name: "--surface-strong", value: "#060f17" },
    { name: "--border", value: "#284154" },
    { name: "--border-strong", value: "#3a5a70" },
    { name: "--text", value: "#eef3f7" },
    { name: "--text-muted", value: "#a7bccb" },
    { name: "--accent", value: "#6db3cc" },
    { name: "--accent-strong", value: "#9fcfe0" },
    { name: "--info", value: "#7fb0c4" },
    { name: "--success", value: "#4ecf91" },
    { name: "--warning", value: "#e8a06a" },
    { name: "--danger", value: "#ec7a68" },
    { name: "--focus", value: "#6db3cc" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const bondiThemes = [bondiLightTheme, bondiDarkTheme] as const;

// Amalfi — Mediterranean citrus coast: coral accent + lemon/teal on sea-mist.
export const amalfiLightTheme = {
  id: "amalfi-light",
  label: "Amalfi light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#f6fbfa" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#fbeadd" },
    { name: "--surface-strong", value: "#064a4a" },
    { name: "--border", value: "#f0dccf" },
    { name: "--border-strong", value: "#e0bda9" },
    { name: "--text", value: "#073d3d" },
    { name: "--text-muted", value: "#4d6f6c" },
    { name: "--accent", value: "#ff7f50" },
    { name: "--accent-strong", value: "#b34a22" },
    { name: "--info", value: "#0a7d7d" },
    { name: "--success", value: "#2f9e6a" },
    { name: "--warning", value: "#b58900" },
    { name: "--danger", value: "#d6453b" },
    { name: "--focus", value: "#ff7f50" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const amalfiDarkTheme = {
  id: "amalfi-dark",
  label: "Amalfi dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#06191a" },
    { name: "--surface", value: "#0c2a2a" },
    { name: "--surface-muted", value: "#133838" },
    { name: "--surface-strong", value: "#030f10" },
    { name: "--border", value: "#1f4444" },
    { name: "--border-strong", value: "#2f5e5e" },
    { name: "--text", value: "#e9f6f4" },
    { name: "--text-muted", value: "#9ec5c0" },
    { name: "--accent", value: "#ff9d6e" },
    { name: "--accent-strong", value: "#ffbb96" },
    { name: "--info", value: "#2fc4c4" },
    { name: "--success", value: "#4cd49a" },
    { name: "--warning", value: "#ffe14d" },
    { name: "--danger", value: "#ff6a5c" },
    { name: "--focus", value: "#ff9d6e" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const amalfiThemes = [amalfiLightTheme, amalfiDarkTheme] as const;

// ---------------------------------------------------------------------------
// Community theme pack — well-known developer palettes mapped to the 15 tokens
// (board: issue-354 -> 356/358/360/362/363). Canonical palette sources:
//   Catppuccin (Latte+Mocha), Tokyo Night (Day+Storm), Nord, Rosé Pine
//   (Dawn+Moon), Solarized (Light+Dark). Dark accent-strong stays lighter than
//   accent (dark text); light accent-strong carries white. Body text >= AA.
// ---------------------------------------------------------------------------

// Catppuccin — Latte (light) + Mocha (dark), mauve accent.
export const catppuccinLatteTheme = {
  id: "catppuccin-latte",
  label: "Catppuccin Latte",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#eff1f5" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#e6e9ef" },
    { name: "--surface-strong", value: "#4c4f69" },
    { name: "--border", value: "#ccd0da" },
    { name: "--border-strong", value: "#bcc0cc" },
    { name: "--text", value: "#4c4f69" },
    { name: "--text-muted", value: "#6c6f85" },
    { name: "--accent", value: "#8839ef" },
    { name: "--accent-strong", value: "#7a2fd6" },
    { name: "--info", value: "#1e66f5" },
    { name: "--success", value: "#40a02b" },
    { name: "--warning", value: "#b5760f" },
    { name: "--danger", value: "#d20f39" },
    { name: "--focus", value: "#8839ef" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const catppuccinMochaTheme = {
  id: "catppuccin-mocha",
  label: "Catppuccin Mocha",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#1e1e2e" },
    { name: "--surface", value: "#25253a" },
    { name: "--surface-muted", value: "#313244" },
    { name: "--surface-strong", value: "#11111b" },
    { name: "--border", value: "#313244" },
    { name: "--border-strong", value: "#45475a" },
    { name: "--text", value: "#cdd6f4" },
    { name: "--text-muted", value: "#a6adc8" },
    { name: "--accent", value: "#cba6f7" },
    { name: "--accent-strong", value: "#ddbcff" },
    { name: "--info", value: "#89b4fa" },
    { name: "--success", value: "#a6e3a1" },
    { name: "--warning", value: "#f9e2af" },
    { name: "--danger", value: "#f38ba8" },
    { name: "--focus", value: "#cba6f7" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const catppuccinThemes = [catppuccinLatteTheme, catppuccinMochaTheme] as const;

// Tokyo Night — Day (light) + Storm (dark), blue accent.
export const tokyoNightDayTheme = {
  id: "tokyo-night-light",
  label: "Tokyo Night Day",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#e1e2e7" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#d0d5e3" },
    { name: "--surface-strong", value: "#1a1b26" },
    { name: "--border", value: "#c4c8da" },
    { name: "--border-strong", value: "#a8aecb" },
    { name: "--text", value: "#343b58" },
    { name: "--text-muted", value: "#6a7299" },
    { name: "--accent", value: "#2e7de9" },
    { name: "--accent-strong", value: "#1c5fc4" },
    { name: "--info", value: "#007197" },
    { name: "--success", value: "#587539" },
    { name: "--warning", value: "#8c6c3e" },
    { name: "--danger", value: "#dd1f5a" },
    { name: "--focus", value: "#2e7de9" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const tokyoNightStormTheme = {
  id: "tokyo-night-dark",
  label: "Tokyo Night Storm",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#24283b" },
    { name: "--surface", value: "#2a2f44" },
    { name: "--surface-muted", value: "#1f2335" },
    { name: "--surface-strong", value: "#16161e" },
    { name: "--border", value: "#32384e" },
    { name: "--border-strong", value: "#444b6a" },
    { name: "--text", value: "#c0caf5" },
    { name: "--text-muted", value: "#a9b1d6" },
    { name: "--accent", value: "#7aa2f7" },
    { name: "--accent-strong", value: "#a3c0ff" },
    { name: "--info", value: "#7dcfff" },
    { name: "--success", value: "#9ece6a" },
    { name: "--warning", value: "#e0af68" },
    { name: "--danger", value: "#f7768e" },
    { name: "--focus", value: "#7aa2f7" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const tokyoNightThemes = [tokyoNightDayTheme, tokyoNightStormTheme] as const;

// Nord — Snow Storm (light) + Polar Night (dark), frost accent.
export const nordLightTheme = {
  id: "nord-light",
  label: "Nord light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#eceff4" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#e5e9f0" },
    { name: "--surface-strong", value: "#2e3440" },
    { name: "--border", value: "#d8dee9" },
    { name: "--border-strong", value: "#c2cad8" },
    { name: "--text", value: "#2e3440" },
    { name: "--text-muted", value: "#4c566a" },
    { name: "--accent", value: "#5e81ac" },
    { name: "--accent-strong", value: "#48648a" },
    { name: "--info", value: "#4a7a9e" },
    { name: "--success", value: "#5b7a45" },
    { name: "--warning", value: "#9a7d2e" },
    { name: "--danger", value: "#bf616a" },
    { name: "--focus", value: "#5e81ac" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const nordDarkTheme = {
  id: "nord-dark",
  label: "Nord dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#2e3440" },
    { name: "--surface", value: "#3b4252" },
    { name: "--surface-muted", value: "#434c5e" },
    { name: "--surface-strong", value: "#272c36" },
    { name: "--border", value: "#4c566a" },
    { name: "--border-strong", value: "#5b677d" },
    { name: "--text", value: "#eceff4" },
    { name: "--text-muted", value: "#abb6cb" },
    { name: "--accent", value: "#88c0d0" },
    { name: "--accent-strong", value: "#a9d4e0" },
    { name: "--info", value: "#81a1c1" },
    { name: "--success", value: "#a3be8c" },
    { name: "--warning", value: "#ebcb8b" },
    { name: "--danger", value: "#bf616a" },
    { name: "--focus", value: "#88c0d0" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const nordThemesPack = [nordLightTheme, nordDarkTheme] as const;

// Rosé Pine — Dawn (light) + Moon (dark), iris accent.
export const rosePineDawnTheme = {
  id: "rose-pine-light",
  label: "Rosé Pine Dawn",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#faf4ed" },
    { name: "--surface", value: "#fffaf3" },
    { name: "--surface-muted", value: "#f2e9e1" },
    { name: "--surface-strong", value: "#575279" },
    { name: "--border", value: "#dfd8d0" },
    { name: "--border-strong", value: "#cfc7be" },
    { name: "--text", value: "#575279" },
    { name: "--text-muted", value: "#797593" },
    { name: "--accent", value: "#907aa9" },
    { name: "--accent-strong", value: "#6f5a8c" },
    { name: "--info", value: "#286983" },
    { name: "--success", value: "#3e7d88" },
    { name: "--warning", value: "#b06f15" },
    { name: "--danger", value: "#b4637a" },
    { name: "--focus", value: "#907aa9" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const rosePineMoonTheme = {
  id: "rose-pine-dark",
  label: "Rosé Pine Moon",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#232136" },
    { name: "--surface", value: "#2a273f" },
    { name: "--surface-muted", value: "#393552" },
    { name: "--surface-strong", value: "#191724" },
    { name: "--border", value: "#44415a" },
    { name: "--border-strong", value: "#56526e" },
    { name: "--text", value: "#e0def4" },
    { name: "--text-muted", value: "#908caa" },
    { name: "--accent", value: "#c4a7e7" },
    { name: "--accent-strong", value: "#d6c0f0" },
    { name: "--info", value: "#3e8fb0" },
    { name: "--success", value: "#9ccfd8" },
    { name: "--warning", value: "#f6c177" },
    { name: "--danger", value: "#eb6f92" },
    { name: "--focus", value: "#c4a7e7" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const rosePineThemes = [rosePineDawnTheme, rosePineMoonTheme] as const;

// Solarized — precision light + dark, blue accent (Ethan Schoonover palette).
export const solarizedLightTheme = {
  id: "solarized-light",
  label: "Solarized light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#fdf6e3" },
    { name: "--surface", value: "#fffbf0" },
    { name: "--surface-muted", value: "#eee8d5" },
    { name: "--surface-strong", value: "#073642" },
    { name: "--border", value: "#e3dcc4" },
    { name: "--border-strong", value: "#c9c2a8" },
    { name: "--text", value: "#586e75" },
    { name: "--text-muted", value: "#657b83" },
    { name: "--accent", value: "#268bd2" },
    { name: "--accent-strong", value: "#1f6fa8" },
    { name: "--info", value: "#2aa198" },
    { name: "--success", value: "#718600" },
    { name: "--warning", value: "#b58900" },
    { name: "--danger", value: "#dc322f" },
    { name: "--focus", value: "#268bd2" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const solarizedDarkTheme = {
  id: "solarized-dark",
  label: "Solarized dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#002b36" },
    { name: "--surface", value: "#073642" },
    { name: "--surface-muted", value: "#0a4554" },
    { name: "--surface-strong", value: "#00212b" },
    { name: "--border", value: "#0f4d5e" },
    { name: "--border-strong", value: "#1a6377" },
    { name: "--text", value: "#93a1a1" },
    { name: "--text-muted", value: "#839496" },
    { name: "--accent", value: "#268bd2" },
    { name: "--accent-strong", value: "#4ba6e6" },
    { name: "--info", value: "#2aa198" },
    { name: "--success", value: "#859900" },
    { name: "--warning", value: "#b58900" },
    { name: "--danger", value: "#dc322f" },
    { name: "--focus", value: "#268bd2" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const solarizedThemes = [solarizedLightTheme, solarizedDarkTheme] as const;

// High contrast — accessibility theme (board: issue-277). Maximum legibility:
// pure black/white surfaces, hard borders, and accents chosen for the strongest
// possible contrast against their background.
export const highContrastLightTheme = {
  id: "contrast-light",
  label: "High contrast light",
  colorScheme: "light",
  tokens: [
    { name: "--bg", value: "#ffffff" },
    { name: "--surface", value: "#ffffff" },
    { name: "--surface-muted", value: "#f0f0f0" },
    { name: "--surface-strong", value: "#000000" },
    { name: "--border", value: "#000000" },
    { name: "--border-strong", value: "#000000" },
    { name: "--text", value: "#000000" },
    { name: "--text-muted", value: "#2b2b2b" },
    { name: "--accent", value: "#0b3d91" },
    { name: "--accent-strong", value: "#00337a" },
    { name: "--info", value: "#084298" },
    { name: "--success", value: "#0f5132" },
    { name: "--warning", value: "#664d03" },
    { name: "--danger", value: "#842029" },
    { name: "--focus", value: "#0b3d91" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const highContrastDarkTheme = {
  id: "contrast-dark",
  label: "High contrast dark",
  colorScheme: "dark",
  tokens: [
    { name: "--bg", value: "#000000" },
    { name: "--surface", value: "#000000" },
    { name: "--surface-muted", value: "#1a1a1a" },
    { name: "--surface-strong", value: "#ffffff" },
    { name: "--border", value: "#ffffff" },
    { name: "--border-strong", value: "#ffffff" },
    { name: "--text", value: "#ffffff" },
    { name: "--text-muted", value: "#e6e6e6" },
    { name: "--accent", value: "#66ccff" },
    { name: "--accent-strong", value: "#99ddff" },
    { name: "--info", value: "#66ccff" },
    { name: "--success", value: "#5cff5c" },
    { name: "--warning", value: "#ffe066" },
    { name: "--danger", value: "#ff6b6b" },
    { name: "--focus", value: "#66ccff" },
    ...foundationalTokens,
  ],
} as const satisfies EmibsTheme;

export const highContrastThemes = [highContrastLightTheme, highContrastDarkTheme] as const;

// Theme catalog: every selectable brand theme. Feeds the explorer theme picker.
// Board: task-276 (theme registry + catalog metadata).
export const themes: readonly EmibsTheme[] = [
  neutralLightTheme,
  neutralDarkTheme,
  scoreLightTheme,
  scoreDarkTheme,
  elituaLightTheme,
  elituaDarkTheme,
  wanderLightTheme,
  wanderDarkTheme,
  reefLightTheme,
  reefDarkTheme,
  duskLightTheme,
  duskDarkTheme,
  santoriniLightTheme,
  santoriniDarkTheme,
  bondiLightTheme,
  bondiDarkTheme,
  amalfiLightTheme,
  amalfiDarkTheme,
  catppuccinLatteTheme,
  catppuccinMochaTheme,
  tokyoNightDayTheme,
  tokyoNightStormTheme,
  nordLightTheme,
  nordDarkTheme,
  rosePineDawnTheme,
  rosePineMoonTheme,
  solarizedLightTheme,
  solarizedDarkTheme,
  highContrastLightTheme,
  highContrastDarkTheme,
];

export function themeToStyle(theme: EmibsTheme): CSSProperties {
  return {
    colorScheme: theme.colorScheme,
    ...Object.fromEntries(theme.tokens.map((token) => [token.name, token.value])),
  } as CSSProperties;
}

export function getThemeToken(theme: EmibsTheme, name: ThemeTokenName): string {
  return theme.tokens.find((token) => token.name === name)?.value ?? "";
}

function themeConstName(id: string): string {
  const camel = id.replace(/-([a-z0-9])/g, (_, c: string) => c.toUpperCase());
  return `${camel}Theme`;
}

// Export the theme as a CSS custom-property block, ready to drop into a product's
// global stylesheet. Board: issue-294.
export function themeToCssRoot(theme: EmibsTheme): string {
  const body = theme.tokens.map((token) => `  ${token.name}: ${token.value};`).join("\n");
  return `/* ${theme.label} (${theme.colorScheme}) — generated by emibs-ui-lib */\n:root {\n  color-scheme: ${theme.colorScheme};\n${body}\n}`;
}

// Export the theme as a typed EmibsTheme TS module, ready to register in a
// product's theme catalog. Board: issue-294.
export function themeToTsModule(theme: EmibsTheme): string {
  const tokens = theme.tokens
    .map((token) => `    { name: ${JSON.stringify(token.name)}, value: ${JSON.stringify(token.value)} },`)
    .join("\n");
  return [
    `import type { EmibsTheme } from "emibs-ui-lib/theme";`,
    ``,
    `export const ${themeConstName(theme.id)} = {`,
    `  id: ${JSON.stringify(theme.id)},`,
    `  label: ${JSON.stringify(theme.label)},`,
    `  colorScheme: ${JSON.stringify(theme.colorScheme)},`,
    `  tokens: [`,
    tokens,
    `  ],`,
    `} as const satisfies EmibsTheme;`,
  ].join("\n");
}

// ---------------------------------------------------------------------------
// Portable JSON format — the canonical round-trippable theme artifact for
// export + import across Score, eLitua, and the catalog. Board: issue-293.
//
// Shape (versioned so the parser can reject foreign/newer payloads):
//   { "format": "emibs-theme/1", "id", "label", "colorScheme", "tokens": [...] }
// `themeToJson` serializes an EmibsTheme; `themeFromJson` parses + validates an
// arbitrary string back into an EmibsTheme, reporting every problem verbatim.
// Both are pure and environment-independent (no DOM / CSS.supports), so they
// unit-test cleanly and round-trip every built-in theme.
// ---------------------------------------------------------------------------

// The native serialization format is now emibs-theme/2. emibs-theme/1 payloads
// still import: they carry only the legacy 34 tokens, and the parser fills the
// emibs-theme/2-only tokens with their derived defaults (lossless upgrade —
// every /1 value is preserved verbatim, new tokens derive from existing ones).
export const THEME_JSON_FORMAT = "emibs-theme/2";
export const LEGACY_THEME_JSON_FORMAT = "emibs-theme/1";
export const SUPPORTED_THEME_JSON_FORMATS = [LEGACY_THEME_JSON_FORMAT, THEME_JSON_FORMAT] as const;
export type ThemeJsonFormat = (typeof SUPPORTED_THEME_JSON_FORMATS)[number];

export type ThemeFromJsonResult = { ok: true; theme: EmibsTheme } | { ok: false; errors: string[] };
export type ThemePortableArtifact = {
  format: typeof THEME_JSON_FORMAT;
  id: string;
  label: string;
  colorScheme: "light" | "dark";
  tokens: ThemeToken[];
};

const themeTokenNameSet: ReadonlySet<string> = new Set(themeTokenNames);

// The derived default value for every emibs-theme/2-only token, keyed by name.
// Used to upgrade a /1 payload, to backfill any /2 payload that omits a token
// added after it was written (a saved custom theme — see
// customThemes.migrateStoredCustomTheme), so the result is always a complete
// emibs-theme/2 theme.
//
// PROJECTED from foundationalTokens rather than re-listed. foundationalTokens
// already holds the canonical default for every /2 token (semanticTokens.test.ts
// asserts the coverage), and this list used to be a hand-maintained duplicate of
// it: a token added there but forgotten here backfilled `undefined`. One list to
// add a token to, not two.
const v2ThemeTokenNameSet: ReadonlySet<string> = new Set<string>(v2ThemeTokenNames);
const v2TokenDefaults: ReadonlyMap<string, string> = new Map(
  foundationalTokens
    .filter((token) => v2ThemeTokenNameSet.has(token.name))
    .map((token) => [token.name, token.value]),
);

// Upgrade an ordered token list to a full emibs-theme/2 set: keep every supplied
// token in place, then append any missing emibs-theme/2-only token with its
// derived default. Pure + order-stable so round-tripping stays deterministic.
export function upgradeTokensToV2(tokens: readonly ThemeToken[]): ThemeToken[] {
  const present = new Set(tokens.map((token) => token.name));
  const upgraded = tokens.map((token) => ({ name: token.name, value: token.value }));
  for (const name of v2ThemeTokenNames) {
    if (!present.has(name)) upgraded.push({ name, value: v2TokenDefaults.get(name) as string });
  }
  return upgraded;
}

// Serialize a theme to the portable JSON string (pretty-printed, format-tagged).
export function themeToJson(theme: EmibsTheme): string {
  return `${JSON.stringify(themeToPortableArtifactObject(theme), null, 2)}\n`;
}

// Build the versioned portable artifact object used by product code and tests.
export function themeToPortableArtifactObject(theme: EmibsTheme): ThemePortableArtifact {
  return {
    format: THEME_JSON_FORMAT,
    id: theme.id,
    label: theme.label,
    colorScheme: theme.colorScheme,
    tokens: theme.tokens.map((token) => ({ name: token.name, value: token.value })),
  };
}

// Alias used by product docs and public APIs that talk about a portable
// artifact instead of a raw JSON export.
export function themeToPortableArtifact(theme: EmibsTheme): string {
  return themeToJson(theme);
}

export function themeFromPortableArtifactObject(parsed: unknown): ThemeFromJsonResult {
  if (typeof parsed !== "object" || parsed === null || Array.isArray(parsed)) {
    return { ok: false, errors: ["Expected a JSON object describing a theme."] };
  }

  const record = parsed as Record<string, unknown>;
  const errors: string[] = [];

  const isSupportedFormat = SUPPORTED_THEME_JSON_FORMATS.includes(record.format as ThemeJsonFormat);
  if (!isSupportedFormat) {
    errors.push(
      `Unsupported format ${JSON.stringify(record.format ?? null)} — expected one of ${SUPPORTED_THEME_JSON_FORMATS.map((format) => `"${format}"`).join(", ")}.`,
    );
  }
  // A /1 payload carries only the legacy 34 tokens; emibs-theme/2-only tokens are
  // OPTIONAL for it (they upgrade to derived defaults). A /2 payload must be
  // complete. An unsupported format is validated as /2 so its other problems
  // still surface alongside the format error.
  const isLegacyPayload = record.format === LEGACY_THEME_JSON_FORMAT;
  const requiredTokenNames = isLegacyPayload ? legacyThemeTokenNames : themeTokenNames;

  const id = record.id;
  if (typeof id !== "string" || id.trim() === "") {
    errors.push('Field "id" must be a non-empty string.');
  }

  const label = record.label;
  if (typeof label !== "string" || label.trim() === "") {
    errors.push('Field "label" must be a non-empty string.');
  }

  const colorScheme = record.colorScheme;
  if (colorScheme !== "light" && colorScheme !== "dark") {
    errors.push('Field "colorScheme" must be "light" or "dark".');
  }

  const rawTokens = record.tokens;
  const tokens: ThemeToken[] = [];
  if (!Array.isArray(rawTokens)) {
    errors.push('Field "tokens" must be an array of { name, value } entries.');
  } else {
    const seen = new Set<string>();
    rawTokens.forEach((entry, index) => {
      if (typeof entry !== "object" || entry === null) {
        errors.push(`tokens[${index}] must be an object with "name" and "value".`);
        return;
      }
      const tokenRecord = entry as Record<string, unknown>;
      const name = tokenRecord.name;
      const value = tokenRecord.value;
      if (typeof name !== "string" || !themeTokenNameSet.has(name)) {
        errors.push(`tokens[${index}] has unknown token name ${JSON.stringify(name ?? null)}.`);
        return;
      }
      if (seen.has(name)) {
        errors.push(`Token "${name}" is defined more than once.`);
        return;
      }
      if (typeof value !== "string" || value.trim() === "") {
        errors.push(`Token "${name}" must have a non-empty string value.`);
        return;
      }
      seen.add(name);
      tokens.push({ name: name as ThemeTokenName, value });
    });

    const missing = requiredTokenNames.filter((name) => !seen.has(name));
    if (missing.length > 0) {
      errors.push(`Missing required token${missing.length === 1 ? "" : "s"}: ${missing.join(", ")}.`);
    }
  }

  if (errors.length > 0) {
    return { ok: false, errors };
  }

  return {
    ok: true,
    theme: {
      id: id as string,
      label: label as string,
      colorScheme: colorScheme as "light" | "dark",
      // Backfill any emibs-theme/2-only token the payload omitted (always the
      // case for a /1 import) with its derived default → a complete /2 theme.
      tokens: upgradeTokensToV2(tokens),
    },
  };
}

// Parse + validate a portable theme JSON string. Returns the reconstructed
// EmibsTheme on success, or the full list of validation errors on failure.
// Preserves the input token order so themeFromJson(themeToJson(t)) round-trips.
export function themeFromJson(input: string): ThemeFromJsonResult {
  let parsed: unknown;
  try {
    parsed = JSON.parse(input);
  } catch {
    return { ok: false, errors: ["Not valid JSON — check for syntax errors."] };
  }

  return themeFromPortableArtifactObject(parsed);
}

// Alias used by product docs and public APIs that consume a portable artifact
// round-trip. It preserves the same validation and error reporting as JSON.
export function themeFromPortableArtifact(input: string): ThemeFromJsonResult {
  return themeFromJson(input);
}
