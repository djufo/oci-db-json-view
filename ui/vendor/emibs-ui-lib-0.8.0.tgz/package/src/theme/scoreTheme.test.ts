import { describe, expect, it } from "vitest";
import { scoreDarkTheme, scoreLightTheme } from "./tokens";
import { scoreThemeToCss } from "./scoreTheme";

describe("scoreThemeToCss", () => {
  it("emits the Score light color sheet from the complete reference theme", () => {
    expect(scoreThemeToCss(scoreLightTheme)).toBe(`:root {
  --score-color-background: oklch(0.985 0.007 95);
  --score-color-surface: oklch(0.998 0.002 95);
  --score-color-surface-raised: oklch(0.963 0.012 90);
  --score-color-text: oklch(0.24 0.03 248);
  --score-color-text-secondary: oklch(0.38 0.032 248);
  --score-color-text-muted: oklch(0.47 0.032 248);
  --score-color-border: oklch(0.87 0.018 92);
  --score-color-border-strong: oklch(0.72 0.034 92);
  --score-color-primary: oklch(0.49 0.12 205);
  --score-color-primary-text: oklch(0.985 0.007 95);
  --score-color-accent: oklch(0.65 0.135 145);
  --score-color-accent-text: oklch(0.18 0.034 145);
  --score-color-warning: oklch(0.72 0.142 75);
  --score-color-danger: oklch(0.57 0.19 28);
  --score-color-link: oklch(0.52 0.16 262);
  --score-color-focus: oklch(0.61 0.15 205);
}
`);
  });

  it("retains the complete dark Score color palette", () => {
    const css = scoreThemeToCss(scoreDarkTheme);
    expect(css).toContain("--score-color-primary: oklch(0.66 0.13 205);");
    expect(css).toContain("--score-color-primary-text: oklch(0.16 0.02 250);");
    expect(css).toContain("--score-color-accent-text: oklch(0.16 0.03 145);");
    expect(css).toContain("--score-color-text-secondary: oklch(0.8 0.016 250);");
  });
});
