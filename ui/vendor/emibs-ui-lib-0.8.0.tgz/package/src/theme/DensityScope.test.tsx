import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { DEFAULT_DENSITY, DensityScope, densityToStyle, useDensity, type Density } from "./DensityScope";

function DensityProbe({ override }: { override?: Density }) {
  const density = useDensity(override);
  return <span data-testid="probe">{density}</span>;
}

describe("densityToStyle", () => {
  it("points the active aliases at the requested mode's scale tokens", () => {
    const style = densityToStyle("compact") as Record<string, string>;
    expect(style["--density-control-height"]).toBe("var(--density-control-height-compact)");
    expect(style["--density-gap"]).toBe("var(--density-gap-compact)");
    expect(densityToStyle("comfortable")["--density-padding-x" as keyof ReturnType<typeof densityToStyle>]).toBe(
      "var(--density-padding-x-comfortable)",
    );
  });
});

describe("DensityScope", () => {
  it("defaults to comfortable and exposes it through context", () => {
    const html = renderToStaticMarkup(
      <DensityProbe />,
    );
    expect(html).toContain(">comfortable<");
    expect(DEFAULT_DENSITY).toBe("comfortable");
  });

  it("provides the scoped density to descendants and stamps data-density", () => {
    const html = renderToStaticMarkup(
      <DensityScope density="compact">
        <DensityProbe />
      </DensityScope>,
    );
    expect(html).toContain('data-density="compact"');
    expect(html).toContain(">compact<");
  });

  it("lets an explicit override win over the scope (back-compat with the old prop)", () => {
    const html = renderToStaticMarkup(
      <DensityScope density="compact">
        <DensityProbe override="comfortable" />
      </DensityScope>,
    );
    expect(html).toContain(">comfortable<");
  });
});
