# Touch-target model (emibs-theme/2)

The system-wide model for how large an interactive control must be. It is
defined once, here, and every component sizes its controls through the same
token hook — no component invents its own minimum. The library is deliberately
density-aware, so this contract is a *floor plus a target*, not a single number:
a blanket 44px would fight `--density-*` and wreck dense operator UIs.

`scripts/check-touch-targets.mjs` enforces the part of this document that a
static CSS guard can enforce, fails the build on any new undersized control, and
holds the accepted exceptions in `scripts/baselines/touch-targets.json`. **What
it does and does not see is written down in "What the guard actually checks"
below, and that section is part of the contract.** A rule stated here without a
note saying it is unenforced is a rule the guard enforces; a rule marked
*aspirational* is one you have to uphold in review, because nothing will go red.

Every baseline entry must carry a written justification in that file's `reasons`
map, keyed identically to the entry, naming which of three categories it falls
in: a **declared dense variant** (rule 3), a **nested host-bounded affordance**
(rule 6), or a **guard artifact** (the rule does not actually size the control
the guard matched — e.g. a shared shape rule whose control is re-sized by a
later rule, a bare `input` selector whose 44px target lives on the wrapping
`<label>`, or a rule that sizes something which is not a control at all).
Anything that fits none of the three is a defect: fix it, do not baseline it.
The guard **fails** — it does not warn — on an entry with no usable
justification, on one that names none of the three categories, and on a key that
matches nothing in the source. `--update-baseline` preserves the reasons it
already has, and on its own it can never buy a green build.

**Rule 1 outranks the baseline itself, and that is enforced too.** All three
categories accept a size of any value, so nothing used to stop a 12px control
from being shelved as a "dense tier" and read afterwards as a decision. The
guard now resolves every baseline entry's recorded value and **fails** on any
that lands below the 24px floor, unless the reason identifies it as a
checkbox/radio glyph under rule 5 — the one case where the sub-floor number is
not the target at all but the glyph the guard matched *instead of* the wrapping
`<label>` (`subFloorBaselineReport`, pinned by test). "No baseline entry is
below the floor" is therefore a build condition, not a claim in a PR
description.

## The four tiers

| Tier | Applies to | Size | Basis |
|------|-----------|------|-------|
| **Floor** | every interactive control, in every density | **≥ 24 × 24 CSS px** | WCAG 2.2 SC 2.5.8 *Target Size (Minimum)*, Level AA |
| **Standard** | default / comfortable density | `var(--control-min-height)` (44px) | WCAG 2.1 SC 2.5.5 *Target Size*, Level AAA |
| **Dense** | explicit `--compact` / `--sm` variants | 24px – 43px | deliberate density tradeoff |
| **Nested** | an affordance bounded by an already-sized host | the largest size the host allows, never below the floor | geometry, not preference |

## Rules

1. **The floor is absolute.** Anything below 24 × 24 is a defect, not a
   tradeoff. It is fixed unconditionally, in every density variant, with no
   baseline entry and no exception. The floor outranks the dense tier: a
   `--density-*` token that resolves below 24px is a failure like any other
   number would be.
2. **Default density uses the token, not a number.** Every control that is not
   an explicit dense variant is sized with `var(--control-min-height)` — never a
   literal `44px`. That is the point of the token: a theme adjusts the standard
   once and the whole library follows. This governs the systemic floors that
   everything else is built on: `.ui-button--md`, `.ui-icon-button`, dialog and
   drawer close buttons, menu triggers, tabs, nav links, and the
   `input`/`select`/`textarea` field rules.
   *Partly aspirational.* The guard catches a control sized **below** the
   standard, in any unit and in either axis vocabulary. It does **not** catch a
   literal `44px` written where `var(--control-min-height)` was meant: 44px
   passes the size check, so "use the token rather than the number" is a review
   rule, not a build rule.
3. **Dense variants may sit between the floor and the standard.** A declared
   `--compact`, `--sm` or `--dense` modifier is a design decision, not a defect;
   it is recorded in the guard baseline as accepted. Never force one to 44 — but
   never let one fall under 24 either (rule 1 outranks this one).
   A `var(--density-*)` size is treated as **the dense tier**, not as compliance
   with the standard. It was previously treated as "sized by the theme, nothing
   to see", which quietly blessed `--density-control-height-compact` (32px) as
   meeting a 44px contract.
4. **Square controls raise both axes.** Where a control is sized by
   `width`/`height` as a square (icon buttons, close buttons), both take the
   token. Raising one axis alone produces a control that passes the guard and
   fails the user. The guard judges each declaration separately, so a rule that
   tokenises one axis and hardcodes the other is now reported on the axis it
   hardcoded.
5. **Checkbox and radio glyphs keep their size; the label carries the target.**
   A 16–18px checkbox or radio — native or custom-drawn — is the browser's own
   control size and must not be enlarged; enlarging it produces an oversized
   box, not a better target. The accessible target is the wrapping `<label>`,
   which takes `min-height: var(--control-min-height)` plus padding, so the
   visual control keeps its size while the target grows. The same applies to a
   switch: the `<label>` row is the target, and `.ui-switch-control__switch`
   only has to clear the floor. Where no wrapper can be sized from CSS alone,
   the fix belongs in the component, not here.
   *Aspirational in one direction.* The guard sends the glyph to review rather
   than failing it, but it cannot verify that the wrapping label really is
   44px — a CSS selector cannot see which element wraps which. That half is a
   review obligation.
6. **Nested affordances take the space their host has.** A clear button inside a
   44px field, or a remove button inside a chip, is bounded by that host: raising
   it to 44 inflates the host past the standard it just met. It gets the largest
   size the host's box allows (e.g. 36px inside a 44px field with 4px padding,
   24px inside a chip) and is recorded as accepted. It never drops below the
   floor.
   *Aspirational.* "The largest size the host allows" is a geometric claim about
   two elements; the guard sees one declaration at a time and cannot check it.
   It is asserted in the baseline reason and checked by a human.
7. **Non-interactive decoration stays small.** Status and signal dots, avatars,
   badges and count pills, icons inside an already-sized control, progress bars,
   drag handles, and `.ui-switch-control__thumb` are not targets and are not
   sized by this contract. The guard excludes them by name; disagree with a
   classification in review rather than resizing around it.
   A decoration-sounding name is the **weakest** signal the guard has: if the
   same rule declares `cursor: pointer`, or the name is a known control name,
   the element is a control regardless of what it is called. Renaming `__close`
   to `__close-icon` does not retire it from the contract.
   **Widening `DECORATION_WORDS` is how a rule-7 name leaves the review list —
   not a baseline entry.** A baseline entry is a recorded *exception* filed
   under one of the three categories above; a status dot is not an exception,
   it was never a target, and filing it as one claims a tradeoff nobody made.
   Adding a word is safe by construction because the decoration check runs
   last, after `cursor: pointer`, control names, interactive tags and ARIA
   roles — and a decoration name proved clickable by another rule still lands
   in review. It is not safe by *accident*, though: every word must be
   justified by reading the markup of every selector it retires, and the guard
   source records that reading beside the word.

## What the guard actually checks

A contract document that claims an unenforced guarantee is worse than no
document, so this is the perimeter, stated exactly.

**Properties.** `height`, `width`, `min-height`, `min-width`, `max-height`,
`max-width` and the logical-property spellings of all six: `block-size`,
`inline-size`, `min-block-size`, `min-inline-size`, `max-block-size`,
`max-inline-size`.

**Values.** `px`, `rem` and `em` (both resolved against the 16px root default —
the library sets no `html { font-size }`); `calc()`, `clamp()`, `min()` and
`max()` where the value is statically resolvable; and `var(--token)` for any
length token defined at a theme scope (`:root`, `:host`, `html`,
`[data-color-scheme]`) or listed in the guard's own `THEME_LENGTH_TOKENS`.
An expression resolves to the **smallest** size it can produce — `clamp()` to
its first argument, `min()` to its smallest term — because that is the only
honest reading for a floor.

**Not checked, deliberately:**

- **Percentages and viewport/container units.** `100%`, `min(100%, 1120px)`,
  `calc(100vh - 24px)` describe a layout box against its container, not a
  control against the standard, and have no static value.
- **`min-*: 0`.** The flex/grid overflow idiom removes a minimum rather than
  imposing a small one.
- **`44px` written instead of `var(--control-min-height)`** — see rule 2.
- **Anything sized from JavaScript or an inline style.** This used to apply in
  full to the `--density-*` **aliases** — `--density-control-height`,
  `--density-row-height`, `--density-gap`, `--density-padding-x/y` — which
  `src/theme/DensityScope.tsx` writes as inline styles: outside a
  `<DensityScope>` a bare `min-height: var(--density-control-height)` used to
  resolve to nothing at all, so there was no floor unless the call site spelled
  out a fallback. As of `uif/issue-4677`, all five are ALSO declared in
  `src/styles.css`'s `:root` at their comfortable value (see "Where the floor
  tokens are declared" below), so an out-of-scope control now has a real floor
  whether or not its own declaration bothers with a fallback.
  `<DensityScope>`'s inline styles still beat `:root`, so nothing changes when a
  scope is present.
  The guard still cannot tell whether a given rule is only ever rendered inside
  a scope, and a call site with a fallback that does NOT match the comfortable
  default (e.g. a deliberately-compact icon button) is not exempted by this —
  its size is judged on the fallback it declares, same as before.
  The **floor tokens are no longer in that category.** `src/styles.css` declares
  `--control-min-height: 44px`, `--density-control-height-comfortable: 44px` and
  `--density-control-height-compact: 32px` in `:root` as defensive defaults, so
  a control sized through them has a real floor with no React ancestor mounted.
  `<ThemeScope>`'s inline styles beat `:root`, so the theme still owns the
  values and nothing changes when a scope is present. Those three are the only
  theme tokens `:root` restates for the GUARD's benefit (they are also the only
  ones mirrored in the guard's own `THEME_LENGTH_TOKENS`, see the pinning test);
  colours, radii and type stay owned solely by `src/theme/tokens.ts`. The five
  `--density-*` aliases are a separate case — see below — declared in `:root`
  for real-browser correctness, not because the guard needed it (the guard
  already resolved every call site through its per-site fallback).
- **Whether the element is really interactive.** The guard infers this from the
  tag, the ARIA role, `cursor: pointer`, and a vocabulary of BEM names. Names it
  does not recognise go to **review** — never to silence — so the reviewer
  decides. Only an unambiguous control fails the build.
- **Relationships between elements** — rules 5 and 6 both rest on "the wrapping
  label" / "the host's box", which one CSS declaration cannot express.

**Review is a real channel, not an overflow bin.** Everything the guard is
unsure about lands there rather than disappearing, and the list was meant to be
burned down — it now has been, and `--strict` (which promotes review to a build
failure) is on, so the channel starts empty and stays that way. A new review
entry fails CI; clearing it means the same work as clearing the original 115 —
read the markup, then fix it in source, retire the name as decoration, or
baseline it with a justification naming one of the three categories.

**Current enforcement state (`uif/issue-4796`, 2026-09-01). `--strict` is ON.**
`check:a11y` is `check-touch-targets.mjs --strict`, run by the package `build`
script and therefore by the `build-and-test` job in
`.github/workflows/emibs-ui-lib-ci.yml` on every pull request into
`score-work`. The review bucket is empty of unclassified entries, so it cannot
silently regrow: a new ambiguous undersized control fails the build like an
unambiguous one.

Getting there meant classifying all **115** review entries the previous audit
(`uif/issue-4670`, 33 baselined / 115 review) left open, one at a time, by
reading the markup that renders each selector rather than guessing from its
class name. They landed in four places:

- **47 were rule-7 decoration the guard's vocabulary had not been taught yet**
  — status and presence dots, count pills, a drag handle, `aria-hidden` glyph
  slots, `role="alert"` message bands. These were retired by widening
  `DECORATION_WORDS`, not by baselining them (see rule 7 above). The words
  added, and the selectors each one retires, are recorded in the guard source.
- **13 declarations across nine rules were genuine defects** — real controls at
  default density, no dense modifier, no sized host — and were fixed in source
  to `var(--control-min-height)`: `.ui-command-bar__field` (36→44),
  `.ui-actor-access__select` (34→44), `.ui-legal-document__contact-link`
  (36→44), `.portal-demo-brand-mobile` (38→44 both axes),
  `.ui-checklist-editor__check` (28×36→44×44),
  `.ui-segmented-control__option` (42→44), `.ui-work-item-card__external`
  (34→44 both axes), `.ui-work-item-card__epic` (24→44) and
  `.ui-work-item-trace__relation-item` (34→44).
- **the remaining 55 were baselined with a written justification each**,
  naming one of the three categories.

`.ui-segmented-control__option` is worth naming separately. It read
`var(--ui-segmented-option-min)`, a custom property declared on the *block*
(42px, 36px under `--compact`), which the guard cannot resolve from the
option's own declaration — so the real 42px default never faced the standard
and sat two pixels under it unseen, and the compact tier hid inside the same
property rather than being declared where the modifier is. The indirection is
gone: the default takes the token, and the compact tier states its 36px on
`.ui-segmented-control--compact .ui-segmented-control__option`, where it reads
as the deliberate dense variant it is.

`uif/issue-4677`'s `.ui-command-bar__field | height: 36px` entry is now closed
as a defect rather than carried. That ticket rewrote it from
`var(--density-control-height, 36px)` to a plain literal so declaring the alias
at `:root` could not silently resize it, and correctly reported the resulting
loss of the blanket density exemption. What the literal then exposed is that
the field is a `<button>` with no dense modifier, which rule 2 says is sized by
the token — "a fixed chrome size that matches no tier" is not one of the three
exemptions. The 4677 concern still holds and the token satisfies it: it is a
real declared value, not a fallback something else can override.

**The baseline is now 90 entries** (33 carried + 57 added): 32 declared dense
variants, 18 nested host-bounded affordances and 40 guard artifacts (a handful
of reasons cite two categories where both genuinely apply — e.g. a compact
switch track). 26 of them are checkbox/radio glyphs at 16–18px; those are the
only entries below the 24px floor, and the sub-floor check described above is
what keeps that true.

## Token hooks

- `--control-min-height` (`space`, length, 44px) — the standard. The only value
  a default-density control should reference.
- `--density-control-height-comfortable` (44px) /
  `--density-control-height-compact` (32px), with `--density-padding-x/y` and
  `--density-gap` — the density scale a compact context opts into. A
  **declaration** that references a `var(--density-*)` length has chosen the
  dense tier; the rest of the rule is judged on its own merits, and the floor
  still applies.

**Where the floor tokens are declared.** Three of them are declared twice on
purpose, and the duplication is load-bearing rather than a drift risk:

| Token | `src/theme/tokens.ts` | `:root` in `src/styles.css` | guard `THEME_LENGTH_TOKENS` |
|---|---|---|---|
| `--control-min-height` | 44px (owner) | 44px (defensive) | 44 |
| `--density-control-height-comfortable` | 44px (owner) | 44px (defensive) | 44 |
| `--density-control-height-compact` | 32px (owner) | 32px (defensive) | 32 |

`tokens.ts` is the owner: a theme changes the value there and `<ThemeScope>`
writes it inline, which beats `:root`. The `:root` copy exists only so that a
control has a floor **outside** a ThemeScope, where an undeclared custom
property makes `min-height` compute to `auto` — no floor at all — rather than to
a small number. The guard's table is its own static mirror and predates both.
Because the guard already resolved these three to the same numbers, declaring
them in `:root` moved **nothing** between the hard, review and passing buckets:
the fix is a runtime fix, not a guard fix.

The three columns are **pinned to each other by test**, not by convention:
`scripts/check-touch-targets.test.mjs` ("theme length tokens are pinned to
src/theme/tokens.ts") imports `foundationalTokens` and asserts that
`THEME_LENGTH_TOKENS` holds exactly the theme's size-floor tokens at exactly the
theme's values, and that every floor token `:root` restates matches `tokens.ts`
too. A value edit in any of the three columns, and a size-floor token added to
the density scale but not to the guard, both fail that test — so the guard can
no longer be left measuring against a number the product has stopped using.

**The five `--density-*` ALIASES are a separate, fourth thing `:root` now
declares** (`uif/issue-4677`), and deliberately outside the table above — they
are not in `THEME_LENGTH_TOKENS` and the pinning test does not (and must not)
see them, because `--density-gap` / `--density-padding-x` / `--density-padding-y`
size the space AROUND a control, not the control's own box, and the guard's own
size-floor pattern (`floorTokenPattern` in the test) deliberately excludes
gap/padding for exactly that reason:

| Alias | `:root` in `src/styles.css` |
|---|---|
| `--density-control-height` | 44px |
| `--density-row-height` | 40px |
| `--density-gap` | 12px |
| `--density-padding-x` | 16px |
| `--density-padding-y` | 10px |

Each is declared at its **comfortable** value — `DensityScope`'s own default
density (`DEFAULT_DENSITY` in `DensityScope.tsx`) — for the same reason as the
three floor tokens above: `src/theme/DensityScope.tsx` writes these ONLY as an
inline style, so outside a `<DensityScope>` a bare `var(--density-gap)` used to
resolve to no value at all (dropping the whole declaration), not a small one.
Unlike the three floor tokens, these are a **runtime-correctness fix, not a
guard fix**: `height`/`width`/`min-height` etc. built from `--density-control-height`
already had a per-site fallback everywhere and were already exempted by the
guard's density-token rule (rule 3) before this change, so `:root` declaring it
moved nothing in the hard/review buckets for those. `--density-gap` and
`--density-padding-x/y` aren't sized properties at all (`gap`, `padding` are not
in "Properties" above), so the guard never saw them either way — the fix there
is purely for a real browser rendering outside a `<DensityScope>`.

**The alias in this table is not one thing, and the call sites got two
different treatments accordingly — a distinction it took a follow-up
(`uif/issue-4677`, second pass) to draw correctly:**

- **`--density-control-height` is a FLOOR.** Pixel stability at that property
  matters more than following ambient density, so any call site whose
  per-site fallback disagreed with the comfortable default was rewritten to
  stop depending on the fallback, so declaring the alias in `:root` could not
  silently resize it: `.ui-inspector-rail__close` (width/height) wanted the
  compact tier outright, so it reads `var(--density-control-height-compact)`
  directly — a real declared token, not a fallback literal — and
  `.ui-command-bar__field` (height) wants a fixed `36px` that matches no
  declared tier (CommandBar takes no `density` prop and is never rendered
  inside a `<DensityScope>`), so it stays a plain literal with a comment.
- **`--density-gap` and `--density-padding-x/-y` are SPACING**, and responding
  to ambient density is the entire purpose of those tokens — freezing one to a
  literal defeats the token itself (a compact scope no longer tightens that
  rule), which costs more than the small computed-value change avoiding it
  would save. So every spacing call site stays on the alias, with the
  now-redundant per-site fallback dropped since `:root` supplies the same
  default: `.ui-alert-lane` (`gap: var(--density-gap)`),
  `.ui-audit-timeline__row` (`padding: var(--density-padding-y) 0`), and
  `.ui-inspector-rail__head` / `.ui-inspector-rail__tabs
  .ui-content-tabs__panel` (`var(--density-padding-y)` restored alongside the
  already-aliased `--density-padding-x`, so the whole declaration follows
  density instead of half of it). Outside a `<DensityScope>` this moves the
  computed value to the comfortable default — gap 8px→12px on `.ui-alert-lane`,
  padding-y 8px→10px on `.ui-audit-timeline__row`, 12px→10px on
  `.ui-inspector-rail__head` and the tabs panel — which is precisely what
  declaring a default is for: a site with no ambient density now gets the
  comfortable default instead of a hand-picked pre-density number.

A rule must never mix a literal and a `--density-*` alias across the same
property group (e.g. `padding-y` frozen to a literal while `padding-x` on the
same declaration still reads the alias) — that rule only half-responds to
density, which is worse than either consistent choice, and no rule in
`src/styles.css` does this as of this audit.

The one enforcement-visible exception, noted above under "Current enforcement
state", is that removing `.ui-command-bar__field`'s density-token *mention*
also removed the guard's blanket density-tier exemption for that one
declaration, moving it from a silent pass to `review` — never a resize, but a
(correct) guard-visibility change. The `--density-gap` / `--density-padding-*`
restorations above move no guard bucket at all, because `gap` and `padding`
are not in "Properties" the guard checks (see above) — they were never seen by
the guard either way.

**Floor-token vocabulary and the density scale are different things, and
conflating them is a mistake worth naming explicitly** (it is exactly what
produced the literal-freezing of the three spacing sites above in the first
pass at this ticket, before it was corrected). "No declared
`--density-gap-compact` floor token" is not the same claim as "no compact
tier exists for gap." `src/theme/DensityScope.tsx`'s `densityToStyle` writes,
per mode:

```
"--density-gap": `var(--density-gap-${density})`,
"--density-padding-x": `var(--density-padding-x-${density})`,
"--density-padding-y": `var(--density-padding-y-${density})`,
```

and `src/theme/tokens.ts`'s `densityTokens` gives those compact tokens real
values (`--density-gap-compact: 8px`, `--density-padding-x-compact: 10px`,
`--density-padding-y-compact: 5px`), which a mounted `<ThemeScope>` supplies as
inline styles. So the compact tier for gap/padding exists and is live at
runtime inside `<DensityScope density="compact">` — it is simply not one of
the three **floor tokens** this document's guard-facing table tracks, because
`--density-gap`/`--density-padding-*` size the space AROUND a control rather
than the control's own box, which is exactly why the guard's `floorTokenPattern`
excludes them (see above). Absence from the floor-token table is a statement
about what the *touch-target guard* needs declared defensively at `:root`; it
says nothing about whether a density tier exists for that token at runtime.
Do not read "not a floor token" as "not density-aware" — that conflation is
what leads to freezing a spacing token to a literal instead of trusting the
alias.

Every other theme token — colours, radii, type — is declared in exactly one
place. Do not add to the `:root` list without a size floor, or a
`DensityScope`-only-inline-style gap/padding to point at.

The 24px floor has no token: it is a conformance constant, not a design
parameter, and a theme must not be able to lower it.
