import { describe, expect, it } from "vitest";
import {
  foundationalTokens,
  scoreDarkTheme,
  scoreLightTheme,
  semanticColorDefaults,
  themeTokenNames,
  themes,
  v2ThemeTokenNames,
} from "./tokens";

describe("emibs-theme/2 built-in themes", () => {
  it("every theme carries the complete /2 token map, once each", () => {
    for (const theme of themes) {
      const names = theme.tokens.map((token) => token.name);
      expect(new Set(names).size).toBe(names.length); // no duplicates
      for (const name of themeTokenNames) expect(names).toContain(name);
      expect(names).toHaveLength(themeTokenNames.length);
    }
  });

  it("keeps capacity-unknown neutral — never equal to capacity-ok — in every theme", () => {
    for (const theme of themes) {
      const byName = new Map(theme.tokens.map((token) => [token.name, token.value]));
      expect(byName.get("--capacity-unknown")).not.toBe(byName.get("--capacity-ok"));
    }
  });

  it("derives semantic defaults from existing tokens (var/color-mix references)", () => {
    for (const token of semanticColorDefaults) {
      expect(/^(var\(|color-mix\()/.test(token.value)).toBe(true);
    }
  });
});

describe("curated reference themes", () => {
  it("gives Score its live capacity palette (distinct from --success)", () => {
    const light = new Map(scoreLightTheme.tokens.map((token) => [token.name, token.value]));
    expect(light.get("--capacity-ok")).toBe("oklch(0.64 0.15 150)");
    // Curated capacity green differs from Score's teal --success (hue 184).
    expect(light.get("--capacity-ok")).not.toBe(light.get("--success"));
  });

  it("curates Score severity per color-scheme", () => {
    const light = new Map(scoreLightTheme.tokens.map((token) => [token.name, token.value]));
    const dark = new Map(scoreDarkTheme.tokens.map((token) => [token.name, token.value]));
    expect(light.get("--severity-critical")).not.toBe(dark.get("--severity-critical"));
  });

  it("does not duplicate a token when an override is applied", () => {
    const names = scoreLightTheme.tokens.map((token) => token.name);
    expect(new Set(names).size).toBe(names.length);
  });
});

describe("foundationalTokens", () => {
  it("includes the density scale, state scalars, and semantic color defaults", () => {
    const names = new Set(foundationalTokens.map((token) => token.name));
    for (const name of v2ThemeTokenNames) expect(names.has(name)).toBe(true);
  });
});
