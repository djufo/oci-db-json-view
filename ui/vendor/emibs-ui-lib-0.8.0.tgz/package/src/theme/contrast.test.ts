import { describe, expect, it } from "vitest";
import { evaluateThemeContrast } from "./contrast";
import type { ThemeContrastPair } from "./contrast";
import type { ThemeTokenMap } from "./tokens";

const pair: ThemeContrastPair = {
  id: "sample",
  label: "Sample",
  foreground: "--text",
  background: "--bg",
  minimumRatio: 4.5,
};

function check(tokens: ThemeTokenMap) {
  return evaluateThemeContrast({ tokens }, [pair])[0];
}

describe("evaluateThemeContrast", () => {
  it("computes WCAG contrast for hex colors", () => {
    const result = check([
      { name: "--text", value: "#000000" },
      { name: "--bg", value: "#ffffff" },
    ]);

    expect(result.ratio).toBeCloseTo(21, 1);
    expect(result.status).toBe("pass");
  });

  it("computes rgb and rgba colors with alpha compositing", () => {
    const result = check([
      { name: "--text", value: "rgba(0, 0, 0, 0.5)" },
      { name: "--bg", value: "rgb(255 255 255)" },
    ]);

    expect(result.ratio).toBeCloseTo(3.95, 2);
    expect(result.status).toBe("fail");
  });

  it("resolves common CSS named colors", () => {
    const result = check([
      { name: "--text", value: "rebeccapurple" },
      { name: "--bg", value: "white" },
    ]);

    expect(result.ratio).toBeGreaterThan(7);
    expect(result.status).toBe("pass");
  });

  it("marks unresolvable color values as unknown", () => {
    const result = check([
      { name: "--text", value: "oklch(0.6 0.2 120)" },
      { name: "--bg", value: "#ffffff" },
    ]);

    expect(result.ratio).toBeNull();
    expect(result.status).toBe("unknown");
    expect(result.summary).toBe("Unsupported color syntax");
  });
});
