import { describe, expect, it } from "vitest";
import {
  LEGACY_THEME_JSON_FORMAT,
  THEME_JSON_FORMAT,
  legacyThemeTokenNames,
  themeFromJson,
  themeFromPortableArtifact,
  themeFromPortableArtifactObject,
  themeToJson,
  themeToPortableArtifact,
  themeToPortableArtifactObject,
  themeTokenNames,
  themes,
  v2ThemeTokenNames,
  type EmibsTheme,
} from "./tokens";

// The epic acceptance test (issue-295): every built-in theme must survive a
// full export -> import trip with structural equality.
describe("themeToJson / themeFromJson — round-trip", () => {
  for (const theme of themes) {
    it(`round-trips ${theme.id}`, () => {
      const json = themeToJson(theme);
      const result = themeFromJson(json);
      expect(result.ok).toBe(true);
      if (!result.ok) return;
      expect(result.theme).toEqual({
        id: theme.id,
        label: theme.label,
        colorScheme: theme.colorScheme,
        tokens: theme.tokens.map((token) => ({ name: token.name, value: token.value })),
      });
    });

    it(`serializes ${theme.id} as the portable artifact`, () => {
      expect(themeToJson(theme)).toBe(themeToPortableArtifact(theme));
    });
  }

  it("emits the versioned format tag and trailing newline", () => {
    const json = themeToJson(themes[0]);
    expect(JSON.parse(json).format).toBe(THEME_JSON_FORMAT);
    expect(json.endsWith("\n")).toBe(true);
  });

  it("round-trips the portable artifact object and aliases", () => {
    const artifact = themeToPortableArtifactObject(themes[0]);
    expect(artifact.format).toBe(THEME_JSON_FORMAT);
    expect(artifact.tokens).toEqual(themes[0].tokens.map((token) => ({ name: token.name, value: token.value })));
    expect(themeFromPortableArtifactObject(artifact).ok).toBe(true);

    const json = themeToPortableArtifact(themes[0]);
    const result = themeFromPortableArtifact(json);
    expect(result.ok).toBe(true);
  });
});

function validExport(overrides: Partial<Record<string, unknown>> = {}): string {
  const base = themes[0];
  return JSON.stringify({
    format: THEME_JSON_FORMAT,
    id: base.id,
    label: base.label,
    colorScheme: base.colorScheme,
    tokens: base.tokens.map((token) => ({ name: token.name, value: token.value })),
    ...overrides,
  });
}

function errorsOf(input: string): string[] {
  const result = themeFromJson(input);
  return result.ok ? [] : result.errors;
}

describe("themeFromJson — validation", () => {
  it("rejects non-JSON input", () => {
    expect(errorsOf("not json {")).toEqual(["Not valid JSON — check for syntax errors."]);
  });

  it("rejects a JSON array / non-object", () => {
    expect(errorsOf("[]")).toEqual(["Expected a JSON object describing a theme."]);
    expect(errorsOf("42")).toEqual(["Expected a JSON object describing a theme."]);
  });

  it("rejects an unknown/missing format", () => {
    const expected = `expected one of "${LEGACY_THEME_JSON_FORMAT}", "${THEME_JSON_FORMAT}"`;
    expect(errorsOf(validExport({ format: "emibs-theme/3" }))).toContain(
      `Unsupported format "emibs-theme/3" — ${expected}.`,
    );
    expect(errorsOf(JSON.stringify({ id: "x", label: "X", colorScheme: "light", tokens: [] }))).toContain(
      `Unsupported format null — ${expected}.`,
    );
  });

  it("rejects an invalid colorScheme", () => {
    expect(errorsOf(validExport({ colorScheme: "sepia" }))).toContain(
      'Field "colorScheme" must be "light" or "dark".',
    );
  });

  it("rejects empty id / label", () => {
    const errors = errorsOf(validExport({ id: "", label: "  " }));
    expect(errors).toContain('Field "id" must be a non-empty string.');
    expect(errors).toContain('Field "label" must be a non-empty string.');
  });

  it("rejects unknown token names", () => {
    const base = themes[0];
    const tokens = [{ name: "--not-a-token", value: "#000" }, ...base.tokens];
    expect(errorsOf(validExport({ tokens }))).toContain('tokens[0] has unknown token name "--not-a-token".');
  });

  it("lists every missing required token", () => {
    const base = themes[0];
    const tokens = base.tokens.filter((token) => token.name !== "--bg" && token.name !== "--text");
    const errors = errorsOf(validExport({ tokens }));
    expect(errors.some((error) => error.startsWith("Missing required tokens:"))).toBe(true);
    expect(errors.some((error) => error.includes("--bg") && error.includes("--text"))).toBe(true);
  });

  it("rejects duplicate token definitions", () => {
    const base = themes[0];
    const tokens = [...base.tokens, { name: "--bg", value: "#111" }];
    expect(errorsOf(validExport({ tokens }))).toContain('Token "--bg" is defined more than once.');
  });

  it("rejects a non-string / empty token value", () => {
    const base = themes[0];
    const tokens = base.tokens.map((token) => (token.name === "--bg" ? { name: "--bg", value: 0 } : token));
    expect(errorsOf(validExport({ tokens }))).toContain('Token "--bg" must have a non-empty string value.');
  });

  it("accepts a well-formed hand-authored theme", () => {
    const base = themes[0] as EmibsTheme;
    const authored = validExport({ id: "my-brand", label: "My brand" });
    const result = themeFromJson(authored);
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.theme.id).toBe("my-brand");
    expect(result.theme.tokens).toHaveLength(base.tokens.length);
  });
});

// Build a legacy emibs-theme/1 payload: format tag + ONLY the 34 legacy tokens.
function legacyExport(overrides: Partial<Record<string, unknown>> = {}): string {
  const base = themes[0];
  const byName = new Map(base.tokens.map((token) => [token.name, token.value]));
  return JSON.stringify({
    format: LEGACY_THEME_JSON_FORMAT,
    id: base.id,
    label: base.label,
    colorScheme: base.colorScheme,
    tokens: legacyThemeTokenNames.map((name) => ({ name, value: byName.get(name) as string })),
    ...overrides,
  });
}

describe("emibs-theme/2 is a strict superset of /1", () => {
  it("keeps every legacy token name, in order, at the head of the /2 map", () => {
    expect(themeTokenNames.slice(0, legacyThemeTokenNames.length)).toEqual([...legacyThemeTokenNames]);
    for (const name of legacyThemeTokenNames) expect(themeTokenNames).toContain(name);
  });

  it("adds the new semantic/state/density families as /2-only tokens", () => {
    for (const name of v2ThemeTokenNames) {
      expect(themeTokenNames).toContain(name);
      expect(legacyThemeTokenNames).not.toContain(name);
    }
  });

  it("serializes built-in themes as the emibs-theme/2 format", () => {
    expect(JSON.parse(themeToJson(themes[0])).format).toBe("emibs-theme/2");
  });
});

describe("themeFromJson — /1 → /2 lossless upgrade", () => {
  it("imports a /1 payload and fills every /2-only token with a derived default", () => {
    const result = themeFromJson(legacyExport());
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    // Result is a complete /2 theme.
    expect(result.theme.tokens).toHaveLength(themeTokenNames.length);
    const names = result.theme.tokens.map((token) => token.name);
    for (const name of themeTokenNames) expect(names).toContain(name);
  });

  it("preserves every legacy value verbatim (lossless)", () => {
    const base = themes[0];
    const byName = new Map(base.tokens.map((token) => [token.name, token.value]));
    const result = themeFromJson(legacyExport());
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const resultByName = new Map(result.theme.tokens.map((token) => [token.name, token.value]));
    for (const name of legacyThemeTokenNames) {
      expect(resultByName.get(name)).toBe(byName.get(name));
    }
  });

  it("derives capacity-unknown as visually distinct from capacity-ok (never ok)", () => {
    const result = themeFromJson(legacyExport());
    expect(result.ok).toBe(true);
    if (!result.ok) return;
    const byName = new Map(result.theme.tokens.map((token) => [token.name, token.value]));
    expect(byName.get("--capacity-unknown")).toBeDefined();
    expect(byName.get("--capacity-unknown")).not.toBe(byName.get("--capacity-ok"));
  });

  it("does not require /2-only tokens from a /1 payload", () => {
    // A legacy payload omitting all new tokens must NOT report them missing.
    const result = themeFromJson(legacyExport());
    expect(result.ok).toBe(true);
  });

  it("still requires the legacy tokens in a /1 payload", () => {
    const base = themes[0];
    const byName = new Map(base.tokens.map((token) => [token.name, token.value]));
    const tokens = legacyThemeTokenNames
      .filter((name) => name !== "--bg")
      .map((name) => ({ name, value: byName.get(name) as string }));
    const result = themeFromJson(legacyExport({ tokens }));
    expect(result.ok).toBe(false);
    if (result.ok) return;
    expect(result.errors.some((error) => error.startsWith("Missing required token"))).toBe(true);
  });

  it("re-exports an upgraded /1 theme as /2 and then round-trips", () => {
    const upgraded = themeFromJson(legacyExport());
    expect(upgraded.ok).toBe(true);
    if (!upgraded.ok) return;
    const json = themeToJson(upgraded.theme);
    expect(JSON.parse(json).format).toBe(THEME_JSON_FORMAT);
    const round = themeFromJson(json);
    expect(round.ok).toBe(true);
    if (!round.ok) return;
    expect(round.theme.tokens).toEqual(upgraded.theme.tokens);
  });
});
