import type { EmibsTheme, ThemeTokenName } from "./tokens";

type Rgba = [number, number, number, number];
type Rgb = [number, number, number];

export type ThemeContrastStatus = "pass" | "fail" | "unknown";

export type ThemeContrastPair = {
  id: string;
  label: string;
  foreground: ThemeTokenName;
  background: ThemeTokenName;
  minimumRatio: number;
};

export type ThemeContrastCheck = ThemeContrastPair & {
  ratio: number | null;
  status: ThemeContrastStatus;
  summary: string;
};

export const defaultThemeContrastPairs: readonly ThemeContrastPair[] = [
  { id: "page-text", label: "Page text", foreground: "--text", background: "--bg", minimumRatio: 4.5 },
  { id: "surface-text", label: "Surface text", foreground: "--text", background: "--surface", minimumRatio: 4.5 },
  {
    id: "muted-surface-text",
    label: "Muted surface text",
    foreground: "--text-muted",
    background: "--surface",
    minimumRatio: 4.5,
  },
  {
    id: "accent-surface-action",
    label: "Accent action",
    foreground: "--accent",
    background: "--surface",
    minimumRatio: 3,
  },
  {
    id: "danger-surface-action",
    label: "Danger action",
    foreground: "--danger",
    background: "--surface",
    minimumRatio: 3,
  },
  { id: "focus-page-ring", label: "Focus ring", foreground: "--focus", background: "--bg", minimumRatio: 3 },
  // The inverse emphasis band stays ink in both polarities, so this pair is the
  // only automated guard that a theme overriding one half keeps it legible.
  {
    id: "inverse-band-text",
    label: "Inverse band text",
    foreground: "--text-inverse",
    background: "--surface-inverse",
    minimumRatio: 4.5,
  },
];

export function evaluateThemeContrast(
  theme: Pick<EmibsTheme, "tokens">,
  pairs: readonly ThemeContrastPair[] = defaultThemeContrastPairs,
): ThemeContrastCheck[] {
  return pairs.map((pair) => {
    const foreground = getTokenValue(theme, pair.foreground);
    const background = getTokenValue(theme, pair.background);
    const ratio = foreground && background ? contrastRatio(foreground, background) : null;
    const status: ThemeContrastStatus = ratio == null ? "unknown" : ratio >= pair.minimumRatio ? "pass" : "fail";

    return {
      ...pair,
      ratio,
      status,
      summary:
        ratio == null
          ? "Unsupported color syntax"
          : `${ratio.toFixed(1)}:1 ${status === "pass" ? "passes" : "fails"} ${pair.minimumRatio}:1`,
    };
  });
}

export function summarizeThemeContrast(checks: readonly ThemeContrastCheck[]): {
  total: number;
  passed: number;
  failed: number;
  unknown: number;
  status: ThemeContrastStatus;
} {
  const summary = checks.reduce(
    (acc, check) => {
      if (check.status === "pass") acc.passed += 1;
      if (check.status === "fail") acc.failed += 1;
      if (check.status === "unknown") acc.unknown += 1;
      return acc;
    },
    { total: checks.length, passed: 0, failed: 0, unknown: 0 },
  );

  return {
    ...summary,
    status: summary.failed > 0 ? "fail" : summary.unknown > 0 ? "unknown" : "pass",
  };
}

function getTokenValue(theme: Pick<EmibsTheme, "tokens">, name: ThemeTokenName): string | null {
  return theme.tokens.find((token) => token.name === name)?.value ?? null;
}

function contrastRatio(foreground: string, background: string): number | null {
  const fg = parseColor(foreground);
  const bg = parseColor(background);
  if (!fg || !bg) return null;
  const opaqueBg = compositeColor(bg, [255, 255, 255]);
  const opaqueFg = compositeColor(fg, opaqueBg);
  const fgLum = relativeLuminance(opaqueFg);
  const bgLum = relativeLuminance(opaqueBg);
  const lighter = Math.max(fgLum, bgLum);
  const darker = Math.min(fgLum, bgLum);
  return (lighter + 0.05) / (darker + 0.05);
}

function relativeLuminance(rgb: Rgb): number {
  const [red, green, blue] = rgb.map((channel) => {
    const value = channel / 255;
    return value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * red + 0.7152 * green + 0.0722 * blue;
}

function parseColor(value: string): Rgba | null {
  const color = value.trim().toLowerCase();
  if (color.startsWith("#")) return parseHexColor(color);
  if (color.startsWith("rgb(") || color.startsWith("rgba(")) return parseRgbColor(color);
  return parseNamedColor(color);
}

function parseHexColor(color: string): Rgba | null {
  const raw = color.slice(1);
  if (!/^[0-9a-f]+$/i.test(raw)) return null;
  if (raw.length === 3) {
    return [...raw.split("").map((part) => parseInt(part + part, 16)), 1] as Rgba;
  }
  if (raw.length === 6) {
    return [...hexRgbByteParts(raw).map((part) => parseInt(part, 16)), 1] as Rgba;
  }
  if (raw.length === 4) {
    const parts = raw.split("").map((part) => parseInt(part + part, 16));
    return [parts[0], parts[1], parts[2], alphaByteToUnit(parts[3])];
  }
  if (raw.length === 8) {
    const parts = hexRgbaByteParts(raw).map((part) => parseInt(part, 16));
    return [parts[0], parts[1], parts[2], alphaByteToUnit(parts[3])];
  }
  return null;
}

function hexRgbByteParts(raw: string): [string, string, string] {
  return [raw.slice(0, 2), raw.slice(2, 4), raw.slice(4, 6)];
}

function hexRgbaByteParts(raw: string): [string, string, string, string] {
  return [raw.slice(0, 2), raw.slice(2, 4), raw.slice(4, 6), raw.slice(6, 8)];
}

function parseRgbColor(color: string): Rgba | null {
  const body = color.slice(color.indexOf("(") + 1, color.lastIndexOf(")"));
  const [channelsBody, slashAlpha] = splitOnce(body, "/");
  const parts = channelsBody.includes(",") ? channelsBody.split(",") : channelsBody.trim().split(/\s+/);
  const alphaPart = slashAlpha ?? (parts.length === 4 ? parts.pop() : undefined);
  const channels = parts
    .map((part) => part.trim())
    .filter(Boolean)
    .map(parseRgbChannel);
  const alpha = alphaPart ? parseAlpha(alphaPart) : 1;

  if (channels.length !== 3 || channels.some((channel) => channel == null) || alpha == null) return null;
  return [...channels.map((channel) => clampChannel(channel ?? 0)), alpha] as Rgba;
}

function parseRgbChannel(part: string): number | null {
  if (part === "none") return null;
  if (part.endsWith("%")) return (Number.parseFloat(part) / 100) * 255;
  const parsed = Number.parseFloat(part);
  return Number.isFinite(parsed) ? parsed : null;
}

function parseAlpha(part: string): number | null {
  const trimmed = part.trim();
  if (trimmed === "none") return null;
  const parsed = trimmed.endsWith("%") ? Number.parseFloat(trimmed) / 100 : Number.parseFloat(trimmed);
  return Number.isFinite(parsed) ? Math.max(0, Math.min(1, parsed)) : null;
}

function parseNamedColor(color: string): Rgba | null {
  const fallback = commonNamedColorFallbacks[color];
  if (fallback) return fallback;
  if (typeof document === "undefined" || typeof window === "undefined") return null;
  const probe = document.createElement("span");
  probe.style.color = color;
  if (!probe.style.color) return null;
  const host = document.body ?? document.documentElement;
  if (!host) return null;
  probe.style.position = "fixed";
  probe.style.pointerEvents = "none";
  probe.style.visibility = "hidden";
  host.appendChild(probe);
  const computed = window.getComputedStyle(probe).color;
  probe.remove();
  if (computed.startsWith("rgb(") || computed.startsWith("rgba(")) return parseRgbColor(computed);
  if (computed.startsWith("#")) return parseHexColor(computed);
  return null;
}

function splitOnce(value: string, separator: string): [string, string | undefined] {
  const index = value.indexOf(separator);
  if (index === -1) return [value, undefined];
  return [value.slice(0, index), value.slice(index + separator.length)];
}

function clampChannel(channel: number): number {
  return Math.max(0, Math.min(255, Math.round(channel)));
}

function alphaByteToUnit(alpha: number): number {
  return Math.max(0, Math.min(1, alpha / 255));
}

function compositeColor(source: Rgba, backdrop: Rgb): Rgb {
  const [red, green, blue, alpha] = source;
  if (alpha >= 1) return [red, green, blue];
  if (alpha <= 0) return backdrop;
  return [
    clampChannel(red * alpha + backdrop[0] * (1 - alpha)),
    clampChannel(green * alpha + backdrop[1] * (1 - alpha)),
    clampChannel(blue * alpha + backdrop[2] * (1 - alpha)),
  ];
}

const commonNamedColorFallbacks: Record<string, Rgba> = {
  black: [0, 0, 0, 1],
  blue: [0, 0, 255, 1],
  green: [0, 128, 0, 1],
  red: [255, 0, 0, 1],
  rebeccapurple: [102, 51, 153, 1],
  transparent: [0, 0, 0, 0],
  white: [255, 255, 255, 1],
};
