# Interaction-state model (emibs-theme/2)

The system-wide model for how a control looks in each interaction state. It is
defined once, here, and every component applies the same vocabulary through the
same theme token hooks — no component invents its own hover tint or disabled
opacity. Board: issue-2181 (UIF-E1).

## The seven states

| State      | Trigger                                   | Token hook(s)                                   | Applied as |
|------------|-------------------------------------------|-------------------------------------------------|-----------|
| `hover`    | pointer over an enabled control           | `--state-hover-bg`                              | background overlay |
| `focus`    | keyboard/programmatic focus (`:focus-visible`) | `--state-focus-ring` (+ `--focus`)         | outline / ring |
| `active`   | pressed (`:active`)                       | `--state-active-bg`                            | background overlay |
| `selected` | current/chosen item (`aria-selected`, `aria-current`, `[data-selected]`) | `--state-selected-bg`, `--state-selected-border` | background + border |
| `disabled` | not interactive (`:disabled`, `aria-disabled`) | `--state-disabled-opacity`                 | opacity + `pointer-events: none` |
| `busy`     | in-flight (`aria-busy`, `[data-busy]`)    | `--state-busy-opacity`                          | opacity (control stays focusable) |
| `readonly` | value shown, not editable (`[readonly]`, `aria-readonly`) | `--state-readonly-bg`             | muted surface, no hover/active |

## Rules

1. **One token, every component.** A control's hover surface is always
   `--state-hover-bg`; never a hard-coded `rgba()` or a bespoke per-component
   variable. This keeps the whole system re-themeable from a single vocabulary.
2. **States are additive overlays**, not replacement colors. `--state-hover-bg`
   and `--state-active-bg` are `color-mix(... transparent)` overlays that sit on
   top of the control's own surface, so they compose over any theme and any
   base color without a per-variant lookup table.
3. **`focus` is independent** of hover/active and must remain visible for
   keyboard users — use `:focus-visible` and `--state-focus-ring`. Focus is
   never suppressed by hover.
4. **Precedence** when several states co-occur:
   `disabled` > `readonly` > `busy` > `selected` > `active` > `hover`. A
   disabled control shows no hover/active/focus affordance; a selected control
   still shows hover on top of its selected surface.
5. **`disabled` vs `busy`.** `disabled` removes interactivity
   (`pointer-events: none`, not focusable). `busy` signals an in-flight action:
   the control dims to `--state-busy-opacity` but stays focusable and announces
   `aria-busy="true"`. They are different states with different tokens.
6. **`selected` needs two hooks** so it reads on both filled and outlined
   surfaces: `--state-selected-bg` tints the fill, `--state-selected-border`
   marks the edge.
7. **Affordance labelling.** A control whose icon reflects the current state and
   toggles it on click must disclose current state + resulting action in its
   accessible name (see the `ui-affordance` contract). The state model governs
   the *visuals*; the label contract governs the *words*.

## Token hooks

The state tokens are part of every emibs-theme/2 theme (see `tokens.ts`):

- Surfaces (`color`, derive per-theme): `--state-hover-bg`, `--state-active-bg`,
  `--state-selected-bg`, `--state-selected-border`, `--state-focus-ring`,
  `--state-readonly-bg`.
- Scalars (`number`, brand-independent): `--state-disabled-opacity`,
  `--state-busy-opacity`.

Because they derive from existing `/1` tokens (`--text`, `--accent`, `--focus`,
`--surface`), a `/1` theme upgrades to sensible state values automatically, and
a brand theme's states track its palette with no extra authoring.
