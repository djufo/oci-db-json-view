import { afterEach, describe, expect, it, vi } from "vitest";
import {
  CUSTOM_THEME_STORAGE_KEY,
  CUSTOM_THEME_STORAGE_VERSION,
  createCustomTheme,
  inspectCustomThemeStorage,
  loadCustomThemes,
  migrateStoredCustomTheme,
  persistCustomThemes,
  readCustomThemes,
  type EmibsCustomTheme,
} from "./customThemes";
import {
  foundationalTokens,
  legacyThemeTokenNames,
  neutralLightTheme,
  themeTokenNames,
  v2ThemeTokenNames,
} from "./tokens";

// Regression suite for uif/issue-4671: adding ANY theme token used to make every
// previously-saved custom theme fail validation, after which `loadCustomThemes`
// discarded it with no message. A stored theme is now migrated to the current
// vocabulary, and only a genuinely unreadable record is rejected — loudly.

function savedTheme(overrides: Partial<EmibsCustomTheme> = {}): EmibsCustomTheme {
  return {
    ...createCustomTheme({
      sourceTheme: neutralLightTheme,
      customThemes: [],
      drafts: { "--accent": "#8b1d5f", "--bg": "#fffaf0" },
      label: "My brand",
      baseThemeId: neutralLightTheme.id,
      savedAt: "2026-08-01T00:00:00.000Z",
    }),
    ...overrides,
  };
}

/** A record as an OLDER build of this library would have written it: the same
 *  envelope, but without the tokens that did not exist yet. */
function savedBeforeTokensExisted(...absent: readonly string[]): Record<string, unknown> {
  const theme = savedTheme();
  return { ...theme, tokens: theme.tokens.filter((token) => !absent.includes(token.name)) };
}

function stubStorage(seed?: unknown) {
  return stubRawStorage(seed === undefined ? undefined : JSON.stringify(seed));
}

/** Seeds the EXACT stored string, so a test can assert on bytes rather than on
 *  a re-parsed value — the whole point of the carry-forward fixes. */
function stubRawStorage(seed?: string) {
  const storage = new Map<string, string>();
  if (seed !== undefined) storage.set(CUSTOM_THEME_STORAGE_KEY, seed);
  vi.stubGlobal("window", {
    localStorage: {
      getItem: (key: string) => storage.get(key) ?? null,
      setItem: (key: string, value: string) => void storage.set(key, value),
      removeItem: (key: string) => void storage.delete(key),
    },
  });
  return {
    raw: () => storage.get(CUSTOM_THEME_STORAGE_KEY) as string,
    read: () => JSON.parse(storage.get(CUSTOM_THEME_STORAGE_KEY) as string) as { version: number; themes: unknown[] },
  };
}

function stored(...themes: unknown[]) {
  return { version: CUSTOM_THEME_STORAGE_VERSION, themes };
}

/**
 * The version of the store as it stands right now — what a caller that has just
 * read it holds. Every write has to carry one (uif/issue-4701), and passing the
 * CURRENT version is what these tests mean: they are about what a write does to
 * bytes it has seen, not about the staleness check, which has its own suite.
 */
function currentVersion() {
  return readCustomThemes().version;
}

afterEach(() => {
  vi.unstubAllGlobals();
});

describe("migrateStoredCustomTheme — fillable vs unrecoverable", () => {
  it("fills a token added after the theme was saved, and keeps the theme", () => {
    // `--surface-inverse` / `--text-inverse` are the real additions that wiped
    // every saved custom theme; a pre-addition record simply has no entry.
    const migration = migrateStoredCustomTheme(savedBeforeTokensExisted("--surface-inverse", "--text-inverse"));

    expect(migration.ok).toBe(true);
    if (!migration.ok) return;
    expect(migration.filled).toEqual(["--surface-inverse", "--text-inverse"]);
    const byName = new Map(migration.theme.tokens.map((token) => [token.name, token.value]));
    // Filled from the shared defaults …
    expect(byName.get("--surface-inverse")).toBe("#111827");
    expect(byName.get("--text-inverse")).toBe("#f8fafc");
    // … and the user's own edits survive untouched.
    expect(byName.get("--accent")).toBe("#8b1d5f");
    expect(byName.get("--bg")).toBe("#fffaf0");
    expect(migration.theme.tokens).toHaveLength(themeTokenNames.length);
  });

  it("fills every emibs-theme/2 token, so any future addition is migratable", () => {
    const migration = migrateStoredCustomTheme(savedBeforeTokensExisted(...v2ThemeTokenNames));

    expect(migration.ok).toBe(true);
    if (!migration.ok) return;
    expect(migration.filled).toEqual([...v2ThemeTokenNames]);
    const byName = new Map(migration.theme.tokens.map((token) => [token.name, token.value]));
    const defaults = new Map(foundationalTokens.map((token) => [token.name, token.value]));
    for (const name of v2ThemeTokenNames) expect(byName.get(name)).toBe(defaults.get(name));
  });

  it("rejects a malformed value for a token that DOES exist — not fillable", () => {
    const theme = savedTheme();
    const migration = migrateStoredCustomTheme({
      ...theme,
      tokens: theme.tokens.map((token) => (token.name === "--accent" ? { name: "--accent", value: 17 } : token)),
    });

    expect(migration.ok).toBe(false);
    if (migration.ok) return;
    expect(migration.label).toBe("My brand");
    expect(migration.errors).toContain('Token "--accent" must have a non-empty string value.');
  });

  it("rejects an empty value and a duplicated token", () => {
    const theme = savedTheme();
    expect(
      migrateStoredCustomTheme({
        ...theme,
        tokens: theme.tokens.map((token) => (token.name === "--bg" ? { name: "--bg", value: "   " } : token)),
      }),
    ).toMatchObject({ ok: false, errors: ['Token "--bg" must have a non-empty string value.'] });

    expect(
      migrateStoredCustomTheme({ ...theme, tokens: [...theme.tokens, { name: "--bg", value: "#000" }] }),
    ).toMatchObject({ ok: false, errors: ['Token "--bg" is defined more than once.'] });
  });

  it("rejects a missing emibs-theme/1 token — the /1 vocabulary is frozen, so a gap is corruption", () => {
    const migration = migrateStoredCustomTheme(savedBeforeTokensExisted("--bg"));

    expect(migration.ok).toBe(false);
    if (migration.ok) return;
    expect(migration.errors).toContain("Missing required token: --bg.");
    // The strictness of the old validator is retained for the frozen vocabulary.
    for (const name of legacyThemeTokenNames) {
      const dropped = migrateStoredCustomTheme(savedBeforeTokensExisted(name));
      expect(dropped.ok, name).toBe(false);
    }
  });

  it("rejects a broken envelope, naming every field at fault", () => {
    expect(migrateStoredCustomTheme(null)).toMatchObject({ ok: false, label: null });
    expect(migrateStoredCustomTheme([])).toMatchObject({ ok: false, label: null });

    const migration = migrateStoredCustomTheme({
      ...savedTheme(),
      id: "",
      colorScheme: "sepia",
      savedAt: "not-a-date",
    });
    expect(migration.ok).toBe(false);
    if (migration.ok) return;
    expect(migration.errors).toEqual([
      'Field "id" must be a non-empty string.',
      'Field "colorScheme" must be "light" or "dark".',
      'Field "savedAt" must be an ISO timestamp string.',
    ]);
  });

  it("drops a token that no longer exists and keeps the rest of the theme", () => {
    const theme = savedTheme();
    const migration = migrateStoredCustomTheme({
      ...theme,
      tokens: [...theme.tokens, { name: "--retired-elevation", value: "#123456" }],
    });

    expect(migration.ok).toBe(true);
    if (!migration.ok) return;
    expect(migration.dropped).toEqual(["--retired-elevation"]);
    expect(migration.theme.tokens.map((token) => token.name)).not.toContain("--retired-elevation");
    expect(migration.theme.tokens).toHaveLength(themeTokenNames.length);
  });

  it("leaves a current-format theme byte-for-byte unchanged", () => {
    const theme = savedTheme();
    const migration = migrateStoredCustomTheme(JSON.parse(JSON.stringify(theme)));

    expect(migration.ok).toBe(true);
    if (!migration.ok) return;
    expect(migration.theme).toEqual(theme);
    expect(migration.filled).toEqual([]);
    expect(migration.dropped).toEqual([]);
  });
});

describe("readCustomThemes / loadCustomThemes", () => {
  it("migrates a pre-addition theme on load instead of discarding it", () => {
    stubStorage(stored(savedBeforeTokensExisted("--surface-inverse", "--text-inverse")));

    const report = readCustomThemes();
    expect(report.themes.map((theme) => theme.label)).toEqual(["My brand"]);
    expect(report.unreadable).toEqual([]);
    expect(report.migrated).toEqual([
      { label: "My brand", filled: ["--surface-inverse", "--text-inverse"], dropped: [] },
    ]);
    expect(loadCustomThemes()).toHaveLength(1);
  });

  it("reports an unreadable theme rather than dropping it silently", () => {
    const theme = savedTheme();
    stubStorage(
      stored(
        { ...theme, tokens: theme.tokens.map((t) => (t.name === "--accent" ? { name: "--accent", value: 17 } : t)) },
        savedTheme({ id: "custom-ok", label: "Still fine" }),
      ),
    );

    const report = readCustomThemes();
    expect(report.themes.map((entry) => entry.label)).toEqual(["Still fine"]);
    expect(report.unreadable).toEqual([
      { label: "My brand", errors: ['Token "--accent" must have a non-empty string value.'] },
    ]);
  });

  it("round-trips a current-format theme through storage unchanged", () => {
    const theme = savedTheme();
    stubStorage();
    persistCustomThemes([theme], currentVersion());
    expect(loadCustomThemes()).toEqual([theme]);
  });

  it("does not write to storage while reading", () => {
    const record = savedBeforeTokensExisted("--surface-inverse");
    const storage = stubStorage(stored(record));

    readCustomThemes();

    // Migration is in memory: the stored bytes are the user's only copy.
    expect(storage.read().themes).toEqual([record]);
  });

  it("does not age-out an old theme, and still ignores a foreign storage envelope", () => {
    // CHANGED BY uif/issue-4683. This assertion used to encode the defect: an
    // old theme produced a COMPLETELY EMPTY report, so it was neither loaded
    // nor mentioned, and the next unrelated Save then purged its bytes. Age is
    // no longer a reason to withhold a record. The foreign-envelope half is
    // unchanged — that store is not this build's to read or rewrite.
    const aged = stubStorage(stored(savedTheme({ savedAt: "2019-01-01T00:00:00.000Z" })));
    expect(readCustomThemes()).toEqual({
      themes: [savedTheme({ savedAt: "2019-01-01T00:00:00.000Z" })],
      migrated: [],
      unreadable: [],
      // The report also carries the store it was read from (uif/issue-4701).
      version: { source: aged.raw() },
    });

    const foreign = stubStorage({ version: 99, themes: [{ bad: true }] });
    expect(readCustomThemes()).toEqual({
      themes: [],
      migrated: [],
      unreadable: [],
      version: { source: foreign.raw() },
    });
  });
});

describe("persistCustomThemes", () => {
  it("carries an unreadable record forward so a later Save cannot finish the deletion", () => {
    const broken = { ...savedTheme(), colorScheme: "sepia" };
    const storage = stubStorage(stored(broken));

    persistCustomThemes([savedTheme({ id: "custom-new", label: "New" })], currentVersion());

    const written = storage.read().themes;
    expect(written).toHaveLength(2);
    expect(written[1]).toEqual(broken);
    // …and it is still reported, not resurrected as a usable theme.
    expect(readCustomThemes().unreadable).toHaveLength(1);
  });
});

// ---------------------------------------------------------------------------
// The two data-loss paths that survived the uif/issue-4671 migration fix, found
// by the independent cross-provider review of PR #487. Both are about the WRITE
// path: the migration itself is sound, but persisting used to normalise or
// delete stored bytes the current vocabulary cannot represent.
// ---------------------------------------------------------------------------
describe("persistCustomThemes — carry-forward must not lose bytes", () => {
  // A record this build cannot read, holding the two things `JSON.parse` /
  // `JSON.stringify` silently destroy: a duplicate object key (the earlier one
  // is gone after a round trip) and an out-of-range number (becomes `null`).
  const unreadableSource =
    '{"id":"custom-broken","label":"Broken brand","label":"Broken brand (v2)",' +
    '"colorScheme":"sepia","baseThemeId":"neutral-light","savedAt":"2026-08-01T00:00:00.000Z",' +
    '"budget":1e999,"tokens":[]}';

  it("re-emits an unreadable record byte-for-byte, keeping a duplicate key and an out-of-range number", () => {
    const storage = stubRawStorage(`{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${unreadableSource}]}`);

    persistCustomThemes([savedTheme({ id: "custom-new", label: "New" })], currentVersion());

    // The bytes, not a re-serialization of the parsed value.
    expect(storage.raw()).toContain(unreadableSource);
    // Which is exactly what a JSON round trip would have destroyed: the first
    // of the two "label" keys collapses away, and 1e999 becomes null.
    const roundTripped = JSON.stringify(JSON.parse(unreadableSource));
    expect(unreadableSource.match(/"label":/g)).toHaveLength(2);
    expect(roundTripped.match(/"label":/g)).toHaveLength(1);
    expect(roundTripped).not.toContain('"label":"Broken brand"');
    expect(roundTripped).toContain('"budget":null');
    // …and it is still reported, not resurrected as a usable theme.
    expect(readCustomThemes().unreadable).toHaveLength(1);
  });

  it("re-emits a READABLE record byte-for-byte too, so its unknown fields and spacing survive", () => {
    const theme = savedTheme();
    const readableSource = JSON.stringify({ ...theme, note: "kept by the user" }, null, 1);
    const storage = stubRawStorage(`{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${readableSource}]}`);

    persistCustomThemes([...loadCustomThemes(), savedTheme({ id: "custom-new", label: "New" })], currentVersion());

    expect(storage.raw()).toContain(readableSource);
    expect(storage.read().themes).toHaveLength(2);
  });

  it("refuses the write when storage is malformed JSON, instead of replacing everything with []", () => {
    const healthySource = JSON.stringify(savedTheme());
    // Valid record, then a syntax error. Nothing here is loadable…
    const malformed = `{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${healthySource},{"id":]}`;
    const storage = stubRawStorage(malformed);

    expect(readCustomThemes().themes).toEqual([]);
    persistCustomThemes([savedTheme({ id: "custom-new", label: "New" })], currentVersion());

    // …so the ONLY safe move is to leave the user's single copy alone.
    expect(storage.raw()).toBe(malformed);
    expect(storage.raw()).toContain(healthySource);
  });

  it("refuses the write when the envelope is not the one this build writes", () => {
    const foreign = '{"version":99,"themes":[{"writtenByANewerBuild":true}]}';
    const storage = stubRawStorage(foreign);

    persistCustomThemes([savedTheme({ id: "custom-new", label: "New" })], currentVersion());

    expect(storage.raw()).toBe(foreign);
  });

  it("still writes normally when storage is empty or holds a well-formed envelope", () => {
    const empty = stubRawStorage();
    persistCustomThemes([savedTheme()], currentVersion());
    expect(empty.read().themes).toHaveLength(1);

    const seeded = stubStorage(stored(savedTheme()));
    persistCustomThemes([...loadCustomThemes(), savedTheme({ id: "custom-two", label: "Two" })], currentVersion());
    expect(seeded.read().themes).toHaveLength(2);
  });
});

describe("a refused write is reported, never silent", () => {
  it("returns the refusal and its reason instead of throwing it away", () => {
    stubRawStorage('{"version":1,"themes":[{"id":]}');
    const refusal = persistCustomThemes([savedTheme()], currentVersion());

    expect(refusal.ok).toBe(false);
    if (refusal.ok) return;
    expect(refusal.reason).toBe("The stored custom themes are not valid JSON.");
  });

  it("reports how many unreadable records a successful write carried forward", () => {
    const storage = stubStorage(stored({ ...savedTheme(), colorScheme: "sepia" }));
    const written = persistCustomThemes([savedTheme({ id: "custom-new", label: "New" })], currentVersion());

    // Plus the version of what it just wrote, so the caller can save again
    // without a re-read another tab could slip inside (uif/issue-4701).
    expect(written).toEqual({ ok: true, carriedForward: 1, version: { source: storage.raw() } });
  });

  it("inspects the store so a caller can warn before the user tries to save", () => {
    stubRawStorage();
    expect(inspectCustomThemeStorage()).toEqual({ ok: true, records: 0 });

    stubStorage(stored(savedTheme(), savedTheme({ id: "custom-two", label: "Two" })));
    expect(inspectCustomThemeStorage()).toEqual({ ok: true, records: 2 });

    stubRawStorage('{"version":99,"themes":[]}');
    expect(inspectCustomThemeStorage()).toMatchObject({ ok: false });

    stubRawStorage("not json at all");
    expect(inspectCustomThemeStorage()).toMatchObject({ ok: false });
  });
});

// ---------------------------------------------------------------------------
// uif/issue-4683 — the THIRD data-loss path: `CUSTOM_THEME_MAX_AGE_MS`.
//
// `readCustomThemes` used to skip a record whose `savedAt` was older than a
// one-year window WITHOUT reporting it — unlike an unreadable record, which is
// named. Because the theme was then absent from the caller's array, the next
// unrelated Save or Delete purged its bytes for good. `savedAt` was never
// refreshed, so the clock measured age rather than disuse: a theme opened every
// day still died on its first birthday.
//
// The window is retired rather than announced or tombstoned. A custom theme is
// a user-authored, user-named document with its own Delete button, and this
// module already refuses to delete a record it cannot even READ; deleting a
// perfectly readable one for being old was the inconsistency. The tests below
// pin the retirement AND the structural property that made the silent drop
// destructive in the first place.
// ---------------------------------------------------------------------------
describe("no saved theme is destroyed for being old (uif/issue-4683)", () => {
  const ANCIENT = "2016-01-01T00:00:00.000Z";

  /** The exact reproduction: seed an aged record, load, then Save something
   *  else and look at the bytes. */
  function seedAged() {
    const aged = savedTheme({ id: "custom-my-brand", savedAt: ANCIENT });
    const source = JSON.stringify(aged);
    return { aged, source, storage: stubRawStorage(`{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${source}]}`) };
  }

  it("loads an aged theme instead of dropping it in silence", () => {
    seedAged();

    const report = readCustomThemes();
    expect(report.themes.map((theme) => theme.label)).toEqual(["My brand"]);
    // It is not merely "reported instead of dropped" — it is USABLE again.
    expect(report.unreadable).toEqual([]);
    expect(report.migrated).toEqual([]);
    expect(loadCustomThemes()).toHaveLength(1);
  });

  it("keeps an aged theme's bytes through an unrelated Save and an unrelated Delete", () => {
    const { source, storage } = seedAged();

    // The user saves a DIFFERENT theme. Before the fix this purged the aged one.
    persistCustomThemes([...loadCustomThemes(), savedTheme({ id: "custom-b", label: "Theme B" })], currentVersion());
    expect(storage.raw()).toContain(source);
    expect(storage.read().themes).toHaveLength(2);

    // …and deletes that different theme again.
    persistCustomThemes(loadCustomThemes().filter((theme) => theme.id !== "custom-b"), currentVersion());
    expect(storage.raw()).toContain(source);
    expect(storage.read().themes).toHaveLength(1);
  });

  it("an unrelated Save purges nothing the user was not told about", () => {
    // A store holding one readable-but-aged record and one unreadable record.
    const aged = JSON.stringify(savedTheme({ id: "custom-my-brand", savedAt: ANCIENT }));
    const broken = JSON.stringify({ ...savedTheme({ id: "custom-broken", label: "Broken" }), colorScheme: "sepia" });
    const storage = stubRawStorage(
      `{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${aged},${broken}]}`,
    );

    const before = readCustomThemes();
    persistCustomThemes([...before.themes, savedTheme({ id: "custom-b", label: "Theme B" })], before.version);

    // Every pre-existing record is still there: the aged one because it loaded,
    // the broken one because it was carried forward AND named to the user.
    expect(storage.raw()).toContain(aged);
    expect(storage.raw()).toContain(broken);
    expect(storage.read().themes).toHaveLength(3);
    expect(before.unreadable.map((failure) => failure.label)).toEqual(["Broken"]);
  });

  it("withholds nothing: every stored record is either loaded or reported", () => {
    // The structural invariant behind the whole defect. `persistCustomThemes`
    // deletes exactly the readable records the caller does not hold, so a record
    // `readCustomThemes` omits without reporting is destroyed by the next
    // unrelated write. Anything a future filter withholds must show up here.
    const records = [
      savedTheme({ id: "custom-current" }),
      savedTheme({ id: "custom-ancient", savedAt: ANCIENT }),
      savedTheme({ id: "custom-epoch", savedAt: new Date(0).toISOString() }),
      savedTheme({ id: "custom-future", savedAt: "2099-12-31T23:59:59.000Z" }),
      savedBeforeTokensExisted("--surface-inverse"),
      { ...savedTheme({ id: "custom-broken", label: "Broken" }), colorScheme: "sepia" },
    ];
    stubStorage(stored(...records));

    const report = readCustomThemes();
    expect(report.themes.length + report.unreadable.length).toBe(records.length);
    expect(report.themes).toHaveLength(5);
    expect(report.unreadable).toHaveLength(1);
  });

  it("keeps the invariants uif/issue-4671 established, on an aged record", () => {
    const { source, storage } = seedAged();

    // 1. A read never writes — even now that an aged record is returned.
    readCustomThemes();
    expect(storage.raw()).toBe(`{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${source}]}`);

    // 2. Storage stays a superset of memory: the aged record is re-emitted as
    //    its ORIGINAL BYTES, not re-serialized from the in-memory theme.
    persistCustomThemes([...loadCustomThemes(), savedTheme({ id: "custom-b", label: "Theme B" })], currentVersion());
    expect(storage.raw()).toContain(source);

    // 3. Persist still REFUSES on a parse/scan disagreement rather than writing.
    const malformed = `{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${source},{"id":]}`;
    const broken = stubRawStorage(malformed);
    expect(persistCustomThemes([savedTheme({ id: "custom-b", label: "Theme B" })], currentVersion())).toMatchObject({
      ok: false,
    });
    expect(broken.raw()).toBe(malformed);
  });

  it("an aged theme the user explicitly deletes is still deleted", () => {
    // The fix must not turn Delete into a no-op: the user's own decision to
    // remove a theme is the ONE deletion this module honours.
    const { storage } = seedAged();

    persistCustomThemes(loadCustomThemes().filter((theme) => theme.id !== "custom-my-brand"), currentVersion());

    expect(storage.read().themes).toHaveLength(0);
    expect(readCustomThemes().themes).toEqual([]);
  });
});

describe("persistCustomThemes — a retired token survives the next mutation", () => {
  const retiredEntry = '{"name":"--retired-elevation","value":"0 1px 2px rgba(0,0,0,.25)"}';

  function seedThemeWithRetiredToken() {
    const theme = savedTheme();
    const source = `{"id":${JSON.stringify(theme.id)},"label":${JSON.stringify(theme.label)},` +
      `"colorScheme":"light","baseThemeId":${JSON.stringify(theme.baseThemeId)},` +
      `"savedAt":${JSON.stringify(theme.savedAt)},` +
      `"tokens":[${theme.tokens.map((token) => JSON.stringify(token)).join(",")},${retiredEntry}]}`;
    return {
      source,
      storage: stubRawStorage(`{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${source}]}`),
    };
  }

  it("keeps the retired token out of the in-memory theme", () => {
    seedThemeWithRetiredToken();
    const [loaded] = loadCustomThemes();

    // It has no meaning in the current vocabulary: it must not reach
    // themeToStyle as a dead custom property, nor an export.
    expect(loaded.tokens.map((token) => token.name)).not.toContain("--retired-elevation");
    expect(loaded.tokens).toHaveLength(themeTokenNames.length);
    expect(readCustomThemes().migrated).toEqual([
      { label: "My brand", filled: [], dropped: ["--retired-elevation"] },
    ]);
  });

  it("keeps its bytes in storage through a Save and a Delete of another theme", () => {
    const { source, storage } = seedThemeWithRetiredToken();

    // Save a second theme…
    persistCustomThemes([...loadCustomThemes(), savedTheme({ id: "custom-new", label: "New" })], currentVersion());
    expect(storage.raw()).toContain(retiredEntry);
    expect(storage.raw()).toContain(source);

    // …then delete it again.
    persistCustomThemes(loadCustomThemes().filter((theme) => theme.id !== "custom-new"), currentVersion());
    expect(storage.raw()).toContain(retiredEntry);
    expect(storage.raw()).toContain(source);
    expect(storage.read().themes).toHaveLength(1);
  });

  it("carries the retired token onto a theme the caller edited, so an edit cannot delete it either", () => {
    const { storage } = seedThemeWithRetiredToken();
    const [loaded] = loadCustomThemes();

    persistCustomThemes(
      [{ ...loaded, tokens: loaded.tokens.map((t) => (t.name === "--bg" ? { ...t, value: "#0b0b0b" } : t)) }],
      currentVersion(),
    );

    const [written] = storage.read().themes as [{ tokens: { name: string; value: string }[] }];
    expect(written.tokens).toContainEqual({ name: "--retired-elevation", value: "0 1px 2px rgba(0,0,0,.25)" });
    expect(written.tokens.find((token) => token.name === "--bg")?.value).toBe("#0b0b0b");
  });

  it("restores the user's value if the token returns to the vocabulary", async () => {
    const { storage } = seedThemeWithRetiredToken();
    persistCustomThemes([...loadCustomThemes(), savedTheme({ id: "custom-new", label: "New" })], currentVersion());
    const survivingRecord = storage.read().themes[0];

    // A later build that re-adds `--retired-elevation` reads the SAME stored
    // record and simply accepts the token again — nothing had to be recovered,
    // because nothing was ever deleted.
    vi.resetModules();
    vi.doMock("./tokens", async () => {
      const actual = await vi.importActual<typeof import("./tokens")>("./tokens");
      return { ...actual, themeTokenNames: [...actual.themeTokenNames, "--retired-elevation"] };
    });
    const revived = await import("./customThemes");
    const migration = revived.migrateStoredCustomTheme(survivingRecord);
    vi.doUnmock("./tokens");
    vi.resetModules();

    expect(migration.ok).toBe(true);
    if (!migration.ok) return;
    expect(migration.dropped).toEqual([]);
    expect(migration.theme.tokens).toContainEqual({
      name: "--retired-elevation",
      value: "0 1px 2px rgba(0,0,0,.25)",
    });
  });
});

// ---------------------------------------------------------------------------
// uif/issue-4701 — the FOURTH data-loss path: the lost update.
//
// The first three were all about what this module does with bytes it can see.
// This one is about bytes it never saw. A page reads storage ONCE and then
// holds that array for as long as it is open, so a second tab's Save makes the
// first tab's snapshot incomplete without touching the first tab at all. The
// next Save there wrote an array with the second tab's theme simply missing —
// and because absence from the caller's array is the only delete signal
// `persistCustomThemes` has, that read as a deletion and was executed as one.
// It even reported success: { ok: true, carriedForward: 0 }.
//
// No property of the array can distinguish "the user deleted this" from "this
// caller never saw it" — they are the same array. The fix is therefore not a
// better merge but the missing evidence: a write carries the version of the
// store it was derived from, and lands only if that is still the store.
// ---------------------------------------------------------------------------
describe("a save from a stale snapshot cannot destroy another tab's theme (uif/issue-4701)", () => {
  const STALE_REASON = "The saved themes changed in another tab after this page read them.";

  /** Seeds one stored theme and returns the read a page would hold from mount. */
  function openTab(...seeded: EmibsCustomTheme[]) {
    const storage = stubStorage(stored(...seeded));
    return { storage, snapshot: readCustomThemes() };
  }

  it("refuses the write and leaves both themes standing — the exact reproduction", () => {
    const { storage, snapshot: tabA } = openTab(savedTheme({ id: "custom-a", label: "Theme A" }));

    // Tab B reads, saves, and is gone. Storage is now [A, B].
    const tabB = readCustomThemes();
    expect(
      persistCustomThemes([...tabB.themes, savedTheme({ id: "custom-b", label: "Theme B" })], tabB.version),
    ).toMatchObject({ ok: true });

    // Tab A saves C from the snapshot it took before B existed. This used to
    // return { ok: true, carriedForward: 0 } and leave ['Theme A', 'Theme C'].
    const written = persistCustomThemes(
      [...tabA.themes, savedTheme({ id: "custom-c", label: "Theme C" })],
      tabA.version,
    );

    expect(written).toEqual({ ok: false, code: "stale", reason: STALE_REASON });
    // Nothing was written at all: Theme B is untouched and Theme C is not there
    // either. A refusal is not a partial save.
    expect(readCustomThemes().themes.map((theme) => theme.label)).toEqual(["Theme A", "Theme B"]);
    expect(storage.read().themes).toHaveLength(2);
  });

  it("refuses a stale DELETE too — the intent is a whole array either way", () => {
    const { snapshot: tabA } = openTab(
      savedTheme({ id: "custom-a", label: "Theme A" }),
      savedTheme({ id: "custom-x", label: "Theme X" }),
    );

    const tabB = readCustomThemes();
    persistCustomThemes([...tabB.themes, savedTheme({ id: "custom-b", label: "Theme B" })], tabB.version);

    // Tab A deletes X from its stale snapshot. Honouring that array would take
    // Theme B with it, because the array simply has no Theme B in it.
    const written = persistCustomThemes(
      tabA.themes.filter((theme) => theme.id !== "custom-x"),
      tabA.version,
    );

    expect(written).toMatchObject({ ok: false, code: "stale" });
    expect(readCustomThemes().themes.map((theme) => theme.label)).toEqual(["Theme A", "Theme X", "Theme B"]);
  });

  it("lets the caller merge on evidence: re-read, re-apply the intent, write", () => {
    const { snapshot: tabA } = openTab(savedTheme({ id: "custom-a", label: "Theme A" }));
    const tabB = readCustomThemes();
    persistCustomThemes([...tabB.themes, savedTheme({ id: "custom-b", label: "Theme B" })], tabB.version);

    const refused = persistCustomThemes(
      [...tabA.themes, savedTheme({ id: "custom-c", label: "Theme C" })],
      tabA.version,
    );
    expect(refused).toMatchObject({ ok: false, code: "stale" });

    // `stale` is the one refusal a caller can act on by itself: what it wanted
    // was "add Theme C", not "make storage be exactly this array".
    const fresh = readCustomThemes();
    expect(
      persistCustomThemes([...fresh.themes, savedTheme({ id: "custom-c", label: "Theme C" })], fresh.version),
    ).toMatchObject({ ok: true });

    expect(readCustomThemes().themes.map((theme) => theme.label)).toEqual(["Theme A", "Theme B", "Theme C"]);
  });

  it("still deletes what the user actually deleted", () => {
    // The fix must not buy safety by making deletion impossible: a write from a
    // CURRENT version deletes exactly what is missing from it, as before.
    const { storage, snapshot } = openTab(
      savedTheme({ id: "custom-a", label: "Theme A" }),
      savedTheme({ id: "custom-b", label: "Theme B" }),
    );

    const written = persistCustomThemes(
      snapshot.themes.filter((theme) => theme.id !== "custom-a"),
      snapshot.version,
    );

    expect(written).toMatchObject({ ok: true });
    expect(storage.read().themes).toHaveLength(1);
    expect(readCustomThemes().themes.map((theme) => theme.label)).toEqual(["Theme B"]);
  });

  it("hands a successful write the version it produced, so a tab can keep saving", () => {
    const { snapshot } = openTab(savedTheme({ id: "custom-a", label: "Theme A" }));

    const first = persistCustomThemes(
      [...snapshot.themes, savedTheme({ id: "custom-b", label: "Theme B" })],
      snapshot.version,
    );
    expect(first).toMatchObject({ ok: true });
    if (!first.ok) return;

    // A second save built on the first one's result lands with no re-read — the
    // re-read is exactly the gap another tab could slip through.
    const themes = readCustomThemes().themes;
    expect(persistCustomThemes([...themes, savedTheme({ id: "custom-c", label: "Theme C" })], first.version)).toMatchObject({
      ok: true,
    });

    // …and the version it replaced is refused from then on.
    expect(persistCustomThemes(themes, first.version)).toMatchObject({ ok: false, code: "stale" });
  });

  it("refuses a write built on an empty store once another tab has created one", () => {
    stubRawStorage();
    const empty = readCustomThemes();
    expect(empty.version).toEqual({ source: null });

    persistCustomThemes([savedTheme({ id: "custom-b", label: "Theme B" })], readCustomThemes().version);

    expect(persistCustomThemes([savedTheme({ id: "custom-c", label: "Theme C" })], empty.version)).toMatchObject({
      ok: false,
      code: "stale",
    });
    expect(readCustomThemes().themes.map((theme) => theme.label)).toEqual(["Theme B"]);
  });

  it("keeps the byte-preservation of PR #487 through a conflict and its retry", () => {
    // The re-serialize branch is what destroys an unknown field, a duplicate
    // key or an unrepresentable number, so the conflict path must not force a
    // record down it. A theme that came back from a re-read is byte-identical
    // to what is stored, so it is still re-emitted verbatim.
    const theme = savedTheme({ id: "custom-a", label: "Theme A" });
    // Written as text: a duplicate key cannot be expressed as an object literal
    // — which is exactly why `JSON.stringify` cannot round-trip one.
    const readableSource = JSON.stringify({ ...theme, note: "kept by the user" }).replace(
      '"note":"kept by the user"',
      '"note":"kept by the user","note":"kept by the user (v2)"',
    );
    const storage = stubRawStorage(`{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${readableSource}]}`);

    const tabA = readCustomThemes();
    const tabB = readCustomThemes();
    persistCustomThemes([...tabB.themes, savedTheme({ id: "custom-b", label: "Theme B" })], tabB.version);

    expect(
      persistCustomThemes([...tabA.themes, savedTheme({ id: "custom-c", label: "Theme C" })], tabA.version),
    ).toMatchObject({ ok: false, code: "stale" });

    const fresh = readCustomThemes();
    expect(
      persistCustomThemes([...fresh.themes, savedTheme({ id: "custom-c", label: "Theme C" })], fresh.version),
    ).toMatchObject({ ok: true });

    // Both "note" keys survive — which a JSON round trip would not have done.
    expect(storage.raw()).toContain(readableSource);
    expect(readableSource.match(/"note":/g)).toHaveLength(2);
    expect(JSON.stringify(JSON.parse(readableSource)).match(/"note":/g)).toHaveLength(1);
    expect(readCustomThemes().themes.map((entry) => entry.label)).toEqual(["Theme A", "Theme B", "Theme C"]);
  });

  it("checks staleness before it looks at the store's shape", () => {
    // A caller that gets `stale` can recover by re-reading; one that gets a
    // parse failure cannot. When both are true the recoverable answer is the
    // useful one, and it is also the honest one: the store this array was
    // derived from is gone, whatever replaced it looks like.
    stubStorage(stored(savedTheme({ id: "custom-a", label: "Theme A" })));
    const snapshot = readCustomThemes();

    stubRawStorage('{"version":1,"themes":[{"id":]}');
    expect(persistCustomThemes(snapshot.themes, snapshot.version)).toMatchObject({ ok: false, code: "stale" });
  });
});
