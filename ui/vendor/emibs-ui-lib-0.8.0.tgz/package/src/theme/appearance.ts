import { useCallback, useEffect, useMemo, useState } from "react";
import { DEFAULT_DENSITY, type Density } from "./DensityScope";
import {
  highContrastDarkTheme,
  highContrastLightTheme,
  neutralDarkTheme,
  neutralLightTheme,
  nordDarkTheme,
  nordLightTheme,
  scoreDarkTheme,
  scoreLightTheme,
  type EmibsTheme,
} from "./tokens";

// The house appearance contract.
//
// Every operator app in the estate offered the same choice — a theme family, a
// light/dark mode — and each one re-implemented it: the same four families, the
// same two localStorage keys under its own prefix, the same default. Copies of
// one decision drift, so the decision lives here once. An app that wants the
// house style mounts <AppFrame> and gets this; an app with a fixed brand (eLitua)
// passes its own family list instead.

export type AppearanceMode = "light" | "dark" | "system";
export type ResolvedAppearanceMode = "light" | "dark";

export type AppearanceFamily = {
  /** Stable id, persisted in storage. */
  id: string;
  /** Name shown in the theme picker. */
  label: string;
  light: EmibsTheme;
  dark: EmibsTheme;
};

/** The house families, in picker order. The first one is the house default. */
export const houseAppearanceFamilies: readonly AppearanceFamily[] = [
  { id: "score", label: "Score", light: scoreLightTheme, dark: scoreDarkTheme },
  { id: "neutral", label: "Neutral", light: neutralLightTheme, dark: neutralDarkTheme },
  { id: "nord", label: "Nord", light: nordLightTheme, dark: nordDarkTheme },
  { id: "contrast", label: "High contrast", light: highContrastLightTheme, dark: highContrastDarkTheme },
];

export const APPEARANCE_MODES: readonly AppearanceMode[] = ["light", "dark", "system"];

export type AppearanceState = {
  familyId: string;
  mode: AppearanceMode;
  density: Density;
};

export type AppearanceOptions = {
  /**
   * Prefix for the persisted keys (`<storageKey>:theme-family`,
   * `<storageKey>:theme-mode`, `<storageKey>:density`). Use the app's name so
   * two apps on one origin keep separate choices. Omit to keep the choice in
   * memory only.
   */
  storageKey?: string;
  /** Families offered to the user. Defaults to the house families. */
  families?: readonly AppearanceFamily[];
  /** Family used until the user picks one. Defaults to the first family. */
  defaultFamilyId?: string;
  /** Mode used until the user picks one. */
  defaultMode?: AppearanceMode;
  /** Density used until the user picks one. */
  defaultDensity?: Density;
};

export type Appearance = AppearanceState & {
  families: readonly AppearanceFamily[];
  family: AppearanceFamily;
  /** `mode` with "system" resolved against the OS preference. */
  resolvedMode: ResolvedAppearanceMode;
  /** The theme to hand to ThemeScope. */
  theme: EmibsTheme;
  setFamilyId: (familyId: string) => void;
  setMode: (mode: AppearanceMode) => void;
  setDensity: (density: Density) => void;
};

const DARK_QUERY = "(prefers-color-scheme: dark)";

function isMode(value: unknown): value is AppearanceMode {
  return value === "light" || value === "dark" || value === "system";
}

function isDensity(value: unknown): value is Density {
  return value === "comfortable" || value === "compact";
}

function readStored(key: string): string | null {
  // Storage can be unavailable (private mode, disabled cookies, SSR). A stored
  // preference is a convenience, so every failure degrades to the default.
  try {
    return typeof window === "undefined" ? null : window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function writeStored(key: string, value: string): void {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    // Ignored on purpose: the choice still applies for this page view.
  }
}

/**
 * Resolves the initial appearance from storage, falling back to the defaults
 * for anything missing or no longer valid (for example a family the app has
 * since stopped offering). Pure apart from the storage read, so it is testable.
 */
export function resolveInitialAppearance(options: AppearanceOptions = {}): AppearanceState {
  const families = options.families ?? houseAppearanceFamilies;
  const fallbackFamilyId =
    families.find((family) => family.id === options.defaultFamilyId)?.id ?? families[0]?.id ?? "";
  const { storageKey } = options;
  const storedFamily = storageKey ? readStored(`${storageKey}:theme-family`) : null;
  const storedMode = storageKey ? readStored(`${storageKey}:theme-mode`) : null;
  const storedDensity = storageKey ? readStored(`${storageKey}:density`) : null;
  return {
    familyId: families.some((family) => family.id === storedFamily) ? (storedFamily as string) : fallbackFamilyId,
    mode: isMode(storedMode) ? storedMode : (options.defaultMode ?? "light"),
    density: isDensity(storedDensity) ? storedDensity : (options.defaultDensity ?? DEFAULT_DENSITY),
  };
}

function systemPrefersDark(): boolean {
  return typeof window !== "undefined" && typeof window.matchMedia === "function"
    ? window.matchMedia(DARK_QUERY).matches
    : false;
}

/**
 * The appearance state for an app: which family, which mode, which density, and
 * the resolved theme. Choices persist under `storageKey` and "system" follows
 * the OS preference live.
 */
export function useAppearance(options: AppearanceOptions = {}): Appearance {
  const families = options.families ?? houseAppearanceFamilies;
  const { storageKey } = options;
  const [state, setState] = useState<AppearanceState>(() => resolveInitialAppearance(options));
  const [prefersDark, setPrefersDark] = useState(systemPrefersDark);

  useEffect(() => {
    if (typeof window === "undefined" || typeof window.matchMedia !== "function") return;
    const media = window.matchMedia(DARK_QUERY);
    const update = () => setPrefersDark(media.matches);
    update();
    media.addEventListener("change", update);
    return () => media.removeEventListener("change", update);
  }, []);

  const setFamilyId = useCallback(
    (familyId: string) => {
      if (!families.some((family) => family.id === familyId)) return;
      if (storageKey) writeStored(`${storageKey}:theme-family`, familyId);
      setState((current) => ({ ...current, familyId }));
    },
    [families, storageKey],
  );

  const setMode = useCallback(
    (mode: AppearanceMode) => {
      if (!isMode(mode)) return;
      if (storageKey) writeStored(`${storageKey}:theme-mode`, mode);
      setState((current) => ({ ...current, mode }));
    },
    [storageKey],
  );

  const setDensity = useCallback(
    (density: Density) => {
      if (!isDensity(density)) return;
      if (storageKey) writeStored(`${storageKey}:density`, density);
      setState((current) => ({ ...current, density }));
    },
    [storageKey],
  );

  return useMemo(() => {
    const family = families.find((candidate) => candidate.id === state.familyId) ?? families[0];
    const resolvedMode: ResolvedAppearanceMode =
      state.mode === "system" ? (prefersDark ? "dark" : "light") : state.mode;
    return {
      ...state,
      families,
      family,
      resolvedMode,
      theme: resolvedMode === "dark" ? family.dark : family.light,
      setFamilyId,
      setMode,
      setDensity,
    };
  }, [families, prefersDark, setDensity, setFamilyId, setMode, state]);
}
