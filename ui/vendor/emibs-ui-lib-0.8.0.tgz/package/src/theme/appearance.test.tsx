// @vitest-environment happy-dom
import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import {
  houseAppearanceFamilies,
  resolveInitialAppearance,
  useAppearance,
  type Appearance,
  type AppearanceOptions,
} from "./appearance";
import { nordDarkTheme, scoreDarkTheme, scoreLightTheme } from "./tokens";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

type MediaListener = () => void;

/** A controllable stand-in for the OS colour-scheme preference. */
function stubSystemScheme(initialDark: boolean) {
  let dark = initialDark;
  const listeners = new Set<MediaListener>();
  vi.stubGlobal("matchMedia", () => ({
    get matches() {
      return dark;
    },
    addEventListener: (_: string, listener: MediaListener) => listeners.add(listener),
    removeEventListener: (_: string, listener: MediaListener) => listeners.delete(listener),
  }));
  return {
    set(next: boolean) {
      dark = next;
      listeners.forEach((listener) => listener());
    },
    listenerCount: () => listeners.size,
  };
}

describe("resolveInitialAppearance", () => {
  beforeEach(() => window.localStorage.clear());

  it("is the house default when nothing is stored: first family, light, comfortable", () => {
    expect(resolveInitialAppearance({ storageKey: "app" })).toEqual({
      familyId: houseAppearanceFamilies[0].id,
      mode: "light",
      density: "comfortable",
    });
    expect(houseAppearanceFamilies[0].id).toBe("score");
  });

  it("honours the app's own defaults", () => {
    expect(
      resolveInitialAppearance({ defaultFamilyId: "nord", defaultMode: "system", defaultDensity: "compact" }),
    ).toEqual({ familyId: "nord", mode: "system", density: "compact" });
  });

  it("reads each stored choice under the app's prefix, and only that prefix", () => {
    window.localStorage.setItem("app:theme-family", "nord");
    window.localStorage.setItem("app:theme-mode", "dark");
    window.localStorage.setItem("app:density", "compact");
    window.localStorage.setItem("other:theme-family", "contrast");

    expect(resolveInitialAppearance({ storageKey: "app" })).toEqual({ familyId: "nord", mode: "dark", density: "compact" });
    expect(resolveInitialAppearance({ storageKey: "other" }).familyId).toBe("contrast");
    expect(resolveInitialAppearance({ storageKey: "third" }).familyId).toBe("score");
  });

  it("falls back per field when a stored value is no longer valid", () => {
    window.localStorage.setItem("app:theme-family", "a-family-we-removed");
    window.localStorage.setItem("app:theme-mode", "sepia");
    window.localStorage.setItem("app:density", "cosy");

    expect(resolveInitialAppearance({ storageKey: "app", defaultFamilyId: "neutral" })).toEqual({
      familyId: "neutral",
      mode: "light",
      density: "comfortable",
    });
  });

  it("ignores a default family the app does not offer", () => {
    const families = houseAppearanceFamilies.slice(1, 3);
    expect(resolveInitialAppearance({ families, defaultFamilyId: "score" }).familyId).toBe(families[0].id);
  });

  it("treats storage that throws as empty instead of failing the app", () => {
    const getItem = vi.spyOn(Storage.prototype, "getItem").mockImplementation(() => {
      throw new Error("storage disabled");
    });
    expect(resolveInitialAppearance({ storageKey: "app" }).familyId).toBe("score");
    getItem.mockRestore();
  });
});

describe("useAppearance", () => {
  let container: HTMLDivElement;
  let root: ReturnType<typeof createRoot>;
  let current: Appearance;

  function Probe(options: AppearanceOptions) {
    current = useAppearance(options);
    return null;
  }

  function mount(options: AppearanceOptions = {}) {
    act(() => root.render(<Probe {...options} />));
  }

  beforeEach(() => {
    window.localStorage.clear();
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
    vi.unstubAllGlobals();
  });

  it("resolves the theme from family and mode", () => {
    stubSystemScheme(false);
    mount({ storageKey: "app" });
    expect(current.theme).toBe(scoreLightTheme);

    act(() => current.setMode("dark"));
    expect(current.theme).toBe(scoreDarkTheme);

    act(() => current.setFamilyId("nord"));
    expect(current.theme).toBe(nordDarkTheme);
  });

  it("persists each choice so a reload restores it", () => {
    stubSystemScheme(false);
    mount({ storageKey: "app" });
    act(() => {
      current.setFamilyId("nord");
      current.setMode("dark");
      current.setDensity("compact");
    });

    expect(window.localStorage.getItem("app:theme-family")).toBe("nord");
    expect(window.localStorage.getItem("app:theme-mode")).toBe("dark");
    expect(window.localStorage.getItem("app:density")).toBe("compact");
    expect(resolveInitialAppearance({ storageKey: "app" })).toEqual({ familyId: "nord", mode: "dark", density: "compact" });
  });

  it("writes nothing without a storage key", () => {
    stubSystemScheme(false);
    mount();
    act(() => current.setFamilyId("nord"));
    expect(current.family.id).toBe("nord");
    expect(window.localStorage.length).toBe(0);
  });

  it("rejects a family the app does not offer", () => {
    stubSystemScheme(false);
    mount({ storageKey: "app" });
    act(() => current.setFamilyId("not-a-family"));
    expect(current.family.id).toBe("score");
    expect(window.localStorage.getItem("app:theme-family")).toBeNull();
  });

  it("follows the OS preference in system mode, live, and only in system mode", () => {
    const system = stubSystemScheme(true);
    mount({ defaultMode: "system" });
    expect(current.resolvedMode).toBe("dark");
    expect(current.theme).toBe(scoreDarkTheme);

    act(() => system.set(false));
    expect(current.resolvedMode).toBe("light");
    expect(current.mode).toBe("system");

    act(() => current.setMode("dark"));
    act(() => system.set(false));
    expect(current.resolvedMode).toBe("dark");
  });

  it("stops listening to the OS preference when unmounted", () => {
    const system = stubSystemScheme(false);
    mount();
    expect(system.listenerCount()).toBe(1);
    act(() => root.render(<span />));
    expect(system.listenerCount()).toBe(0);
  });
});
