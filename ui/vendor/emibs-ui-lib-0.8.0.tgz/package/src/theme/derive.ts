import {
  themeTokenDefinitions,
  type ThemeTokenMap,
  type ThemeTokenName,
} from "./tokens";

// Derive a dark token set from an edited light token map. Board: issue-285.
//
// Deterministic + pure: color tokens are mapped to role-appropriate lightness
// targets in HSL (hue preserved, saturation gently clamped) — backgrounds and
// surfaces darken, text/text-muted lighten, borders adapt, and accent/status
// colors keep their hue while being clamped into a band that stays legible on
// the dark surfaces. Space/radius/type tokens are copied through untouched.
// Values that cannot be parsed as an sRGB color (e.g. oklch(), named colors)
// are left exactly as-is so partial/exotic drafts never crash the caller.

type ColorRule =
  // Structural roles pin an absolute target lightness.
  | { kind: "target"; lightness: number; maxSaturation: number }
  // Accent/status roles keep their own lightness but clamp it into a band so
  // they stay bright enough for the dark surfaces without over-brightening.
  | { kind: "band"; min: number; max: number; maxSaturation: number };

const COLOR_RULES: Record<string, ColorRule> = {
  "--bg": { kind: "target", lightness: 0.09, maxSaturation: 0.4 },
  "--surface": { kind: "target", lightness: 0.14, maxSaturation: 0.4 },
  "--surface-muted": { kind: "target", lightness: 0.2, maxSaturation: 0.4 },
  "--surface-strong": { kind: "target", lightness: 0.05, maxSaturation: 0.4 },
  "--border": { kind: "target", lightness: 0.26, maxSaturation: 0.42 },
  "--border-strong": { kind: "target", lightness: 0.36, maxSaturation: 0.45 },
  "--text": { kind: "target", lightness: 0.93, maxSaturation: 0.22 },
  "--text-muted": { kind: "target", lightness: 0.7, maxSaturation: 0.3 },
  "--accent": { kind: "band", min: 0.58, max: 0.72, maxSaturation: 0.9 },
  "--accent-strong": { kind: "band", min: 0.68, max: 0.82, maxSaturation: 0.9 },
  "--info": { kind: "band", min: 0.58, max: 0.74, maxSaturation: 0.9 },
  "--success": { kind: "band", min: 0.55, max: 0.74, maxSaturation: 0.9 },
  "--warning": { kind: "band", min: 0.6, max: 0.78, maxSaturation: 0.95 },
  "--danger": { kind: "band", min: 0.58, max: 0.74, maxSaturation: 0.9 },
  "--focus": { kind: "band", min: 0.58, max: 0.74, maxSaturation: 0.9 },
};

const colorTokenNames: ReadonlySet<string> = new Set(
  themeTokenDefinitions.filter((definition) => definition.valueKind === "color").map((definition) => definition.name),
);

// Accent/status/focus colors must clear this ratio against the derived surface
// so they read as legible actions/rings on the dark theme.
const ACTION_MIN_CONTRAST = 3.05;

export function deriveDarkTokens(tokens: ThemeTokenMap): ThemeTokenMap {
  // Pass 1: resolve structural tokens so accents can be lifted against the
  // actual derived surface (the lighter of the two dark backgrounds).
  const derivedByName = new Map<string, string>();
  for (const token of tokens) {
    const rule = COLOR_RULES[token.name];
    if (rule?.kind === "target") derivedByName.set(token.name, deriveDarkColor(token.name, token.value));
  }
  const surface = parseColor(derivedByName.get("--surface") ?? "") ?? { r: 20, g: 20, b: 20 };

  // Pass 2: everything else — accents lifted for contrast, non-colors copied.
  return tokens.map((token) => {
    const cached = derivedByName.get(token.name);
    if (cached !== undefined) return { name: token.name, value: cached };
    if (!colorTokenNames.has(token.name)) return { name: token.name, value: token.value };
    return { name: token.name, value: deriveDarkColor(token.name, token.value, surface) };
  });
}

function deriveDarkColor(name: ThemeTokenName, value: string, surface?: Rgb): string {
  const rule = COLOR_RULES[name];
  const rgb = parseColor(value);
  if (!rule || !rgb) return value;

  const hsl = rgbToHsl(rgb);
  const saturation = Math.min(hsl.s, rule.maxSaturation);
  if (rule.kind === "target") {
    return rgbToHex(hslToRgb({ h: hsl.h, s: saturation, l: rule.lightness }));
  }

  // Band role: clamp into the band, then lighten until it clears the action
  // contrast minimum against the surface (conservative, deterministic step).
  let lightness = clamp(hsl.l, rule.min, rule.max);
  let out = hslToRgb({ h: hsl.h, s: saturation, l: lightness });
  const ceiling = 0.9;
  while (surface && contrastRatio(out, surface) < ACTION_MIN_CONTRAST && lightness < ceiling) {
    lightness = Math.min(ceiling, lightness + 0.02);
    out = hslToRgb({ h: hsl.h, s: saturation, l: lightness });
  }
  return rgbToHex(out);
}

function contrastRatio(a: Rgb, b: Rgb): number {
  const la = relativeLuminance(a);
  const lb = relativeLuminance(b);
  const lighter = Math.max(la, lb);
  const darker = Math.min(la, lb);
  return (lighter + 0.05) / (darker + 0.05);
}

function relativeLuminance({ r, g, b }: Rgb): number {
  const [rl, gl, bl] = [r, g, b].map((channel) => {
    const value = channel / 255;
    return value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
  });
  return 0.2126 * rl + 0.7152 * gl + 0.0722 * bl;
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

// ---- color conversions (self-contained; hex + rgb()/rgba() input) ----

type Rgb = { r: number; g: number; b: number };
type Hsl = { h: number; s: number; l: number };

function parseColor(value: string): Rgb | null {
  const color = value.trim().toLowerCase();
  if (color.startsWith("#")) return parseHex(color);
  if (color.startsWith("rgb(") || color.startsWith("rgba(")) return parseRgb(color);
  return null;
}

function parseHex(color: string): Rgb | null {
  const raw = color.slice(1);
  if (!/^[0-9a-f]+$/i.test(raw)) return null;
  if (raw.length === 3) {
    return {
      r: parseInt(raw[0] + raw[0], 16),
      g: parseInt(raw[1] + raw[1], 16),
      b: parseInt(raw[2] + raw[2], 16),
    };
  }
  if (raw.length === 6) {
    return {
      r: parseInt(raw.slice(0, 2), 16),
      g: parseInt(raw.slice(2, 4), 16),
      b: parseInt(raw.slice(4, 6), 16),
    };
  }
  return null;
}

function parseRgb(color: string): Rgb | null {
  const body = color.slice(color.indexOf("(") + 1, color.lastIndexOf(")"));
  const channels = body
    .split(/[,\s/]+/)
    .map((part) => part.trim())
    .filter(Boolean)
    .slice(0, 3)
    .map((part) => (part.endsWith("%") ? Math.round((Number.parseFloat(part) / 100) * 255) : Number.parseFloat(part)));

  if (channels.length !== 3 || channels.some((channel) => !Number.isFinite(channel))) return null;
  const [r, g, b] = channels.map((channel) => clamp(Math.round(channel), 0, 255));
  return { r, g, b };
}

function rgbToHsl({ r, g, b }: Rgb): Hsl {
  const rn = r / 255;
  const gn = g / 255;
  const bn = b / 255;
  const max = Math.max(rn, gn, bn);
  const min = Math.min(rn, gn, bn);
  const delta = max - min;
  const l = (max + min) / 2;

  let h = 0;
  let s = 0;
  if (delta !== 0) {
    s = l > 0.5 ? delta / (2 - max - min) : delta / (max + min);
    if (max === rn) h = ((gn - bn) / delta + (gn < bn ? 6 : 0)) / 6;
    else if (max === gn) h = ((bn - rn) / delta + 2) / 6;
    else h = ((rn - gn) / delta + 4) / 6;
  }
  return { h, s, l };
}

function hslToRgb({ h, s, l }: Hsl): Rgb {
  if (s === 0) {
    const value = Math.round(l * 255);
    return { r: value, g: value, b: value };
  }
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
  const p = 2 * l - q;
  return {
    r: Math.round(hueToChannel(p, q, h + 1 / 3) * 255),
    g: Math.round(hueToChannel(p, q, h) * 255),
    b: Math.round(hueToChannel(p, q, h - 1 / 3) * 255),
  };
}

function hueToChannel(p: number, q: number, t: number): number {
  let temp = t;
  if (temp < 0) temp += 1;
  if (temp > 1) temp -= 1;
  if (temp < 1 / 6) return p + (q - p) * 6 * temp;
  if (temp < 1 / 2) return q;
  if (temp < 2 / 3) return p + (q - p) * (2 / 3 - temp) * 6;
  return p;
}

function rgbToHex({ r, g, b }: Rgb): string {
  return `#${[r, g, b].map((channel) => clamp(channel, 0, 255).toString(16).padStart(2, "0")).join("")}`;
}
