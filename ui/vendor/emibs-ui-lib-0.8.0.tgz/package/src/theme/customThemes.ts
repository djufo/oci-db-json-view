import {
  getThemeToken,
  legacyThemeTokenNames,
  themeTokenDefinitions,
  themeTokenNames,
  upgradeTokensToV2,
  v2ThemeTokenNames,
  type EmibsTheme,
  type ThemeToken,
  type ThemeTokenMap,
  type ThemeTokenName,
} from "./tokens";

export type CustomThemeDrafts = Partial<Record<ThemeTokenName, string>>;

export type EmibsCustomTheme = EmibsTheme & {
  baseThemeId: string;
  /**
   * When the user saved this theme. PROVENANCE ONLY — it is displayed and
   * round-tripped, and it is never a reason to stop loading or to delete a
   * record. See `readCustomThemes` for why the retention window it used to
   * drive was retired (uif/issue-4683).
   */
  savedAt: string;
};

/**
 * Outcome of reading ONE stored custom-theme record against the CURRENT token
 * vocabulary. See `migrateStoredCustomTheme` for the fillable/unrecoverable
 * split this encodes.
 */
export type CustomThemeMigration =
  | { ok: true; theme: EmibsCustomTheme; filled: ThemeTokenName[]; dropped: string[] }
  | { ok: false; label: string | null; errors: string[] };

/** One entry per stored theme that was repaired on load. */
export type CustomThemeMigrationNote = {
  label: string;
  filled: ThemeTokenName[];
  dropped: string[];
};

/** One entry per stored theme that could NOT be loaded — never dropped silently. */
export type CustomThemeLoadFailure = {
  label: string | null;
  errors: string[];
};

/**
 * The exact stored text a read observed — the "version" half of the
 * compare-and-swap every write has to pass. `null` means the key was absent.
 *
 * It carries the CONTENT rather than a counter or a hash, and that is the whole
 * point. A counter has to live in the envelope, which means an older build that
 * does not know about it silently drops it on its next write; a hash trades an
 * absolute guarantee for a collision probability, and "the store looked
 * unchanged" is exactly the belief that destroys a theme here. Comparing the
 * bytes is exact, needs nothing added to the stored format, and works against a
 * store written by any build. The cost is holding a few KB of text per open
 * editor, which is nothing next to the parsed themes beside it.
 *
 * Treat it as opaque: read it from `readCustomThemes`, hand it back to
 * `persistCustomThemes`, and replace it with the one a successful write returns.
 */
export type CustomThemeStoreVersion = { readonly source: string | null };

/** Why a write was refused. `stale` is the only one the caller can recover from
 *  on its own — by re-reading and re-applying its intent to what is there now. */
export type CustomThemePersistRefusal =
  | "storage-unavailable"
  | "unparseable"
  | "foreign-envelope"
  | "unsliceable"
  | "stale";

/**
 * Outcome of a write. A refusal is NOT an error to swallow: it means the stored
 * value could not be read back safely — or was not the value this write was
 * derived from — so the write was abandoned to keep the user's only copy
 * intact. Callers surface it (see `ThemeStudioPage`).
 *
 * A success returns the version of what it just wrote, so the caller can keep
 * writing without re-reading. It must NEVER be obtained by reading the store
 * again after the write: another tab may have written in between, and adopting
 * that version would tell the next write "you have seen everything" when it has
 * not — the very defect this compare-and-swap exists to close.
 */
export type CustomThemePersistResult =
  | { ok: true; carriedForward: number; version: CustomThemeStoreVersion }
  | { ok: false; code: CustomThemePersistRefusal; reason: string };

/**
 * Whether the stored value can be rewritten at all. Additive companion to
 * `readCustomThemes`, which answers a different question (what can be LOADED)
 * and deliberately keeps its shape.
 */
export type CustomThemeStorageStatus =
  | { ok: true; records: number }
  | { ok: false; reason: string };

/**
 * Everything a caller needs to render an honest load: the usable themes, what
 * was quietly repaired, what could not be read at all — and the version of the
 * store all three were derived from.
 *
 * `version` is not decoration. A caller that intends to WRITE must carry it
 * into `persistCustomThemes`, because absence from the written array is the
 * only delete signal that function has and the version is the only thing that
 * distinguishes "the user deleted this" from "this caller never saw it". It
 * comes from the SAME read as the themes on purpose: taking it from a second
 * `getItem` would let another tab's write land in between, producing a version
 * that vouches for records the caller does not hold.
 */
export type CustomThemeLoadReport = {
  themes: EmibsCustomTheme[];
  migrated: CustomThemeMigrationNote[];
  unreadable: CustomThemeLoadFailure[];
  version: CustomThemeStoreVersion;
};

export const CUSTOM_THEME_STORAGE_KEY = "emibs-ui-lib:custom-themes:v1";
export const CUSTOM_THEME_STORAGE_VERSION = 1;
export const CUSTOM_THEME_SELECTION_STORAGE_KEY = "emibs-ui-lib:custom-theme-selection:v1";

const themeTokenNameSet: ReadonlySet<string> = new Set<string>(themeTokenNames);

export function createCustomTheme({
  sourceTheme,
  customThemes,
  drafts,
  label,
  baseThemeId,
  savedAt = new Date().toISOString(),
}: {
  sourceTheme: EmibsTheme;
  customThemes: readonly EmibsCustomTheme[];
  drafts: CustomThemeDrafts;
  label: string;
  baseThemeId: string;
  savedAt?: string;
}): EmibsCustomTheme {
  return {
    ...sourceTheme,
    id: uniqueCustomThemeId(customThemes, label),
    label,
    baseThemeId,
    savedAt,
    tokens: themeTokenDefinitions.map((definition) => ({
      name: definition.name,
      value: (drafts[definition.name] ?? getThemeToken(sourceTheme, definition.name)).trim(),
    })),
  };
}

export function customThemeTokensToDrafts(tokens: ThemeTokenMap, sourceTheme: EmibsTheme): CustomThemeDrafts {
  const next: CustomThemeDrafts = {};
  for (const token of tokens) {
    if (token.value !== getThemeToken(sourceTheme, token.name)) next[token.name] = token.value;
  }
  return next;
}

/**
 * Read one stored custom-theme record written by ANY earlier version of this
 * library and bring it up to the current token vocabulary.
 *
 * Adding a theme token used to destroy every previously-saved custom theme: the
 * old validator demanded a value for every CURRENT token, so a record saved
 * before the addition failed and `loadCustomThemes` discarded it with no
 * message (uif/issue-4671). The split below is the fix:
 *
 *   FILLABLE — a token the record does not carry because it did not exist when
 *     the theme was saved. Every token added after the /1 vocabulary froze is
 *     an emibs-theme/2 token with a default, so `upgradeTokensToV2` — the same
 *     mechanism `themeFromJson` uses to lift a /1 payload to /2 — fills it. The
 *     record is KEPT; the user's own values are preserved verbatim.
 *
 *   UNRECOVERABLE — a stored value we cannot honour or invent: a malformed
 *     entry, a duplicate token, an empty/non-string value for a token that DOES
 *     exist, or a missing emibs-theme/1 token (the /1 vocabulary is frozen, so
 *     a gap there is corruption, not an upgrade, and a brand colour has no
 *     theme-independent default to fall back on). These are REJECTED with the
 *     reason — the caller surfaces them, and `persistCustomThemes` keeps the
 *     stored bytes so nothing is destroyed behind the user's back.
 *
 *   RETIRED — a token that no longer exists in the vocabulary. Dropped from the
 *     IN-MEMORY theme, and only reported through `dropped`: it has no meaning in
 *     the current theme, it would leak into `themeToStyle` as a dead custom
 *     property, and `themeFromJson` rejects unknown names, so keeping it would
 *     make the theme unexportable. It is NOT dropped from storage: dropping it
 *     in memory and re-serializing on the next Save deleted it permanently, so
 *     `persistCustomThemes` re-emits the record's original bytes instead. If the
 *     token ever returns, so does the user's setting.
 *
 * Pure and storage-independent, so it unit-tests without a DOM.
 */
export function migrateStoredCustomTheme(candidate: unknown): CustomThemeMigration {
  if (!isRecord(candidate)) {
    return { ok: false, label: null, errors: ["Stored entry is not a theme object."] };
  }

  const label = typeof candidate.label === "string" && candidate.label.trim() !== "" ? candidate.label : null;
  const errors: string[] = [];

  if (typeof candidate.id !== "string" || candidate.id.trim() === "") {
    errors.push('Field "id" must be a non-empty string.');
  }
  if (label === null) {
    errors.push('Field "label" must be a non-empty string.');
  }
  if (candidate.colorScheme !== "light" && candidate.colorScheme !== "dark") {
    errors.push('Field "colorScheme" must be "light" or "dark".');
  }
  if (typeof candidate.baseThemeId !== "string") {
    errors.push('Field "baseThemeId" must be a string.');
  }
  if (typeof candidate.savedAt !== "string" || Number.isNaN(Date.parse(candidate.savedAt))) {
    errors.push('Field "savedAt" must be an ISO timestamp string.');
  }

  const tokens: ThemeToken[] = [];
  const dropped: string[] = [];
  // `seen` = accepted; `named` = mentioned at all. A token whose stored value is
  // malformed already reported its own error — it must not ALSO be reported as
  // missing, which would read as "your theme is from an older build".
  const seen = new Set<string>();
  const named = new Set<string>();

  if (!Array.isArray(candidate.tokens)) {
    errors.push('Field "tokens" must be an array of { name, value } entries.');
  } else {
    candidate.tokens.forEach((entry: unknown, index: number) => {
      if (!isRecord(entry)) {
        errors.push(`tokens[${index}] must be an object with "name" and "value".`);
        return;
      }
      const name = entry.name;
      const value = entry.value;
      if (typeof name !== "string") {
        errors.push(`tokens[${index}] has an invalid token name ${JSON.stringify(name ?? null)}.`);
        return;
      }
      if (!themeTokenNameSet.has(name)) {
        // Retired since this theme was saved — drop it, keep the theme.
        dropped.push(name);
        return;
      }
      named.add(name);
      if (seen.has(name)) {
        errors.push(`Token "${name}" is defined more than once.`);
        return;
      }
      if (typeof value !== "string" || value.trim() === "") {
        errors.push(`Token "${name}" must have a non-empty string value.`);
        return;
      }
      seen.add(name);
      tokens.push({ name: name as ThemeTokenName, value });
    });

    const unrecoverable = legacyThemeTokenNames.filter((name) => !named.has(name));
    if (unrecoverable.length > 0) {
      errors.push(
        `Missing required token${unrecoverable.length === 1 ? "" : "s"}: ${unrecoverable.join(", ")}.`,
      );
    }
  }

  if (errors.length > 0) {
    return { ok: false, label, errors };
  }

  const filled = v2ThemeTokenNames.filter((name) => !seen.has(name));
  return {
    ok: true,
    theme: {
      id: candidate.id as string,
      label: label as string,
      colorScheme: candidate.colorScheme as "light" | "dark",
      baseThemeId: candidate.baseThemeId as string,
      savedAt: candidate.savedAt as string,
      // Same order-stable backfill `themeFromJson` applies to a /1 payload.
      tokens: upgradeTokensToV2(tokens),
    },
    filled: [...filled],
    dropped,
  };
}

/**
 * Load the stored custom themes, migrating each one to the current vocabulary,
 * and report what was repaired and what could not be read.
 *
 * Migration is IN MEMORY: a read never writes. A load can run in a preview,
 * during SSR hydration, or from an older/newer build in another tab, and the
 * stored bytes are the only copy of the user's work — leaving them untouched
 * means a future, better migration can still recover a record this build had to
 * reject.
 *
 * The repair never lands in storage at all: `persistCustomThemes` re-emits an
 * unchanged record's original bytes, so a theme that migrates cleanly on every
 * load is simply migrated again on the next one. The in-memory view and the
 * stored bytes therefore DIVERGE, in one direction only — storage keeps what
 * this build cannot represent (a retired token, an unknown field, a record it
 * cannot read), and memory adds only values DERIVED from `foundationalTokens`,
 * recomputed identically on every load. No value the user authored exists only
 * in memory.
 *
 * NOTHING IS FILTERED OUT. Every readable record is returned, and every record
 * that is NOT readable is reported. This is load-bearing, not a nicety:
 * `persistCustomThemes` deletes a readable stored record precisely when the
 * caller's array does not contain it, because that is how Delete works. So any
 * record this function silently omits is destroyed by the next unrelated Save —
 * the omission IS the deletion, just deferred and attributed to the wrong
 * action. A future filter here must therefore either report what it withheld or
 * not exist. Do not add a quiet `continue`.
 *
 * Handing back every record is necessary, and it is NOT sufficient. It makes
 * the snapshot complete at the instant it is taken; it says nothing about the
 * instant it is written back, and a tab holds that snapshot for as long as the
 * page is open. `version` is the other half — see `persistCustomThemes`.
 *
 * That is how the retention window came to delete saved themes (uif/issue-4683)
 * and why it is gone. A `CUSTOM_THEME_MAX_AGE_MS` of one year used to drop any
 * record whose `savedAt` was older than the window, without reporting it, after
 * which the next Save or Delete purged its bytes for good. Retiring it, rather
 * than announcing it or tombstoning it, is a deliberate policy call:
 *
 *   - A custom theme is a USER-AUTHORED, user-named document with a Delete
 *     button. A store of documents does not delete documents. The age-out
 *     solved no problem this code has: theme records are a few KB against a
 *     multi-MB quota, and an age-out bounds nothing anyway (a hundred themes
 *     saved this morning all survive; one theme opened daily for a year does
 *     not). Schema drift — the one real reason stored state goes stale — is
 *     what `migrateStoredCustomTheme` above exists for.
 *   - It contradicted this module's own settled invariants. An UNREADABLE
 *     record is kept in storage forever and surfaced by name; a perfectly
 *     readable one was deleted for being old. Corruption was treated more
 *     gently than age.
 *   - `savedAt` was never refreshed, so the clock measured age, not disuse,
 *     and a theme in daily use died on its first birthday.
 *
 * Incidental UI state is a different matter and still expires: see
 * `THEME_STUDIO_SETTINGS_MAX_AGE_MS`, which ages out collapsed-section
 * booleans. Nothing there was authored by the user, and forgetting it costs a
 * chevron. That is the line — expire machine-generated state, never a document.
 */
export function readCustomThemes(): CustomThemeLoadReport {
  const raw = readStoredSource();
  const version: CustomThemeStoreVersion = { source: raw };
  const report: CustomThemeLoadReport = { themes: [], migrated: [], unreadable: [], version };
  if (!raw) return report;
  try {
    const parsed = JSON.parse(raw);
    if (!isRecord(parsed) || parsed.version !== CUSTOM_THEME_STORAGE_VERSION || !Array.isArray(parsed.themes)) {
      return report;
    }
    for (const entry of parsed.themes) {
      const migration = migrateStoredCustomTheme(entry);
      if (!migration.ok) {
        report.unreadable.push({ label: migration.label, errors: migration.errors });
        continue;
      }
      report.themes.push(migration.theme);
      if (migration.filled.length > 0 || migration.dropped.length > 0) {
        report.migrated.push({ label: migration.theme.label, filled: migration.filled, dropped: migration.dropped });
      }
    }
    return report;
  } catch {
    return { themes: [], migrated: [], unreadable: [], version };
  }
}

/**
 * The themes alone. Fine for a read-only consumer (a theme picker, a preview).
 * A caller that will later WRITE must use `readCustomThemes` instead and carry
 * `version` into the write — an array on its own is not evidence of what the
 * store held, which is exactly how uif/issue-4701 destroyed another tab's theme.
 */
export function loadCustomThemes(): EmibsCustomTheme[] {
  return readCustomThemes().themes;
}

/**
 * Write the custom themes back, WITHOUT destroying anything the current build
 * cannot represent.
 *
 * Two rules, both of them data-loss fixes:
 *
 *   VERBATIM — every stored record that is still wanted is re-emitted as its
 *     ORIGINAL SOURCE BYTES, sliced out of the stored string, not re-serialized
 *     from a parsed value. `JSON.parse`/`JSON.stringify` is not a byte-lossless
 *     round trip: it collapses duplicate object keys to the last one and turns
 *     an out-of-range number into `null`. A record we could not read is exactly
 *     the record we must not rewrite — and a record we CAN read may still carry
 *     a retired token or an unknown field that this build has no name for, so
 *     the bytes are the only faithful copy of either.
 *
 *   ABORT — if the stored value cannot be parsed, or its envelope is not the
 *     one this build writes, the write is REFUSED. Replacing an unreadable
 *     store with a fresh array is a total loss of every theme in it, readable
 *     ones included; refusing to persist is strictly better, and the refusal is
 *     returned so the caller can say so out loud.
 *
 * A record is only dropped when the caller genuinely dropped it (Delete) —
 * never as a side effect of this build not understanding it, and no longer
 * because it is old (uif/issue-4683). Absence from `customThemes` is the ONLY
 * delete signal this function has, and it cannot tell a deliberate Delete from
 * a caller that simply never saw the record, so `readCustomThemes` must hand
 * the caller every readable record. See the note there.
 *
 *   COMPARE-AND-SWAP — `baseVersion` is the store this write was derived from,
 *     and the write lands only if that is still the store. This is the fourth
 *     data-loss fix (uif/issue-4701) and the one that finishes the argument
 *     above. Handing every readable record to the caller is necessary but not
 *     sufficient: a caller reads ONCE and then holds a snapshot, so another
 *     tab's Save makes that snapshot incomplete without touching this tab, and
 *     the next Save here writes an array that is missing a theme nobody
 *     deleted. Last-write-wins reported `{ ok: true }` while destroying it.
 *
 *     Nothing inside the array can distinguish that case — a theme absent
 *     because the user deleted it and a theme absent because the caller never
 *     saw it are the same array. The version is the missing evidence, so it is
 *     a REQUIRED argument rather than an option: a write with no evidence of
 *     what it saw cannot be made safe, and an API that accepts one is an API
 *     that will be called that way. On a mismatch the write is REFUSED with
 *     `code: "stale"` — recoverable, and the caller that gets it can re-read
 *     and re-apply its intent (append this theme, remove that id) to what is
 *     actually stored, which is a merge on evidence rather than a guess. What
 *     it must never do is take the refusal as "already saved".
 *
 *     The residual window is the gap between the `getItem` below and the
 *     `setItem` a few lines later — one synchronous stretch with no `await` in
 *     it, versus the minutes or hours a tab holds its snapshot. localStorage
 *     offers no atomic swap, so that gap cannot be closed here; it can only be
 *     made small enough that closing it further needs a different storage
 *     backend, not a different algorithm.
 */
export function persistCustomThemes(
  customThemes: readonly EmibsCustomTheme[],
  baseVersion: CustomThemeStoreVersion,
): CustomThemePersistResult {
  if (typeof window === "undefined") {
    return { ok: false, code: "storage-unavailable", reason: STORAGE_UNAVAILABLE_REASON };
  }

  let raw: string | null;
  try {
    raw = window.localStorage.getItem(CUSTOM_THEME_STORAGE_KEY);
  } catch {
    return { ok: false, code: "storage-unavailable", reason: STORAGE_UNAVAILABLE_REASON };
  }

  // Checked before anything is parsed: if the store is not the one this array
  // was derived from, what it contains does not matter — the array cannot be
  // trusted to mean "these are the themes that should exist".
  if (raw !== baseVersion.source) {
    return { ok: false, code: "stale", reason: STALE_STORE_REASON };
  }

  let stored: readonly StoredRecordSource[] = [];
  if (raw) {
    const scan = scanStoredRecords(raw);
    if (!scan.ok) return { ok: false, code: scan.code, reason: scan.reason };
    stored = scan.records;
  }

  const composed = composeStoredRecords(customThemes, stored);
  // Assembled textually, not via JSON.stringify, because the carried-forward
  // entries are already JSON source and must not be re-encoded. The shape is
  // byte-for-byte what JSON.stringify({ version, themes }) produced before.
  const next = `{"version":${CUSTOM_THEME_STORAGE_VERSION},"themes":[${composed.entries.join(",")}]}`;
  try {
    window.localStorage.setItem(CUSTOM_THEME_STORAGE_KEY, next);
  } catch {
    return { ok: false, code: "storage-unavailable", reason: STORAGE_UNAVAILABLE_REASON };
  }
  // The bytes we just wrote — the caller's next write is derived from these, so
  // it can keep saving without a re-read that another tab could slip inside.
  return { ok: true, carriedForward: composed.carriedForward, version: { source: next } };
}

/**
 * Whether a write would be accepted, and how many records the store holds.
 * Lets a caller warn BEFORE the user tries to save, instead of only at the
 * moment the save is refused.
 */
export function inspectCustomThemeStorage(): CustomThemeStorageStatus {
  if (typeof window === "undefined") return { ok: false, reason: STORAGE_UNAVAILABLE_REASON };
  let raw: string | null;
  try {
    raw = window.localStorage.getItem(CUSTOM_THEME_STORAGE_KEY);
  } catch {
    return { ok: false, reason: STORAGE_UNAVAILABLE_REASON };
  }
  if (!raw) return { ok: true, records: 0 };
  const scan = scanStoredRecords(raw);
  return scan.ok ? { ok: true, records: scan.records.length } : { ok: false, reason: scan.reason };
}

export function loadSelectedCustomThemeId(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(CUSTOM_THEME_SELECTION_STORAGE_KEY)?.trim() || null;
  } catch {
    return null;
  }
}

export function persistSelectedCustomThemeId(customThemeId: string | null) {
  if (typeof window === "undefined") return;
  try {
    if (customThemeId) {
      window.localStorage.setItem(CUSTOM_THEME_SELECTION_STORAGE_KEY, customThemeId);
    } else {
      window.localStorage.removeItem(CUSTOM_THEME_SELECTION_STORAGE_KEY);
    }
  } catch {
    /* localStorage unavailable */
  }
}

// ---------------------------------------------------------------------------
// Raw-source retention — the machinery behind `persistCustomThemes`.
//
// The unit of preservation is the ORIGINAL SOURCE TEXT of one stored record.
// Nothing is attached to `EmibsCustomTheme`: the in-memory theme keeps exactly
// the shape it had, so preserved bytes cannot leak into `themeToStyle` or into
// an export, which is the whole reason a retired token is dropped in memory.
// ---------------------------------------------------------------------------

const STORAGE_UNAVAILABLE_REASON = "Local storage could not be written.";
const UNPARSEABLE_REASON = "The stored custom themes are not valid JSON.";
const FOREIGN_ENVELOPE_REASON =
  `The stored custom themes do not use the expected envelope (version ${CUSTOM_THEME_STORAGE_VERSION} with a themes array).`;
const UNSLICEABLE_REASON = "The stored custom themes could not be read back byte-for-byte.";
const STALE_STORE_REASON = "The saved themes changed in another tab after this page read them.";

/** The stored text, or `null` for "absent" AND for "could not be read at all".
 *  Collapsing those two is safe here: every write re-reads through
 *  `window.localStorage` itself and refuses on its own failure. */
function readStoredSource(): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(CUSTOM_THEME_STORAGE_KEY);
  } catch {
    return null;
  }
}

/** One stored record: its exact source bytes, its parsed value, and how this
 *  build reads it. `source` — never `value` — is what gets re-emitted. */
type StoredRecordSource = {
  source: string;
  value: unknown;
  migration: CustomThemeMigration;
};

type StoredRecordScan =
  | { ok: true; records: StoredRecordSource[] }
  | { ok: false; code: CustomThemePersistRefusal; reason: string };

function scanStoredRecords(raw: string): StoredRecordScan {
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch {
    return { ok: false, code: "unparseable", reason: UNPARSEABLE_REASON };
  }
  if (!isRecord(parsed) || parsed.version !== CUSTOM_THEME_STORAGE_VERSION || !Array.isArray(parsed.themes)) {
    return { ok: false, code: "foreign-envelope", reason: FOREIGN_ENVELOPE_REASON };
  }
  const sources = scanStoredRecordSources(raw);
  // The slices must line up 1:1 with what `JSON.parse` saw, and each must be
  // valid JSON on its own. If the scanner and the parser disagree about the
  // stored value, we do not understand it well enough to rewrite it.
  if (!sources || sources.length !== parsed.themes.length) {
    return { ok: false, code: "unsliceable", reason: UNSLICEABLE_REASON };
  }
  const records: StoredRecordSource[] = [];
  for (const [index, source] of sources.entries()) {
    try {
      JSON.parse(source);
    } catch {
      return { ok: false, code: "unsliceable", reason: UNSLICEABLE_REASON };
    }
    const value = parsed.themes[index];
    records.push({ source, value, migration: migrateStoredCustomTheme(value) });
  }
  return { ok: true, records };
}

/**
 * Decide, for each entry of the next stored array, whether to re-emit stored
 * bytes or serialize a caller-supplied theme.
 *
 * A caller theme that still matches its stored record is emitted VERBATIM, so
 * everything the current vocabulary has no name for — a retired token, an
 * unknown field, a duplicate key, a number JSON cannot round-trip — survives
 * the write untouched. Only a theme the caller actually changed (or a brand-new
 * one) is serialized, and even then the stored record's unknown tokens are
 * carried onto it so a mutation cannot delete them either.
 */
function composeStoredRecords(
  customThemes: readonly EmibsCustomTheme[],
  stored: readonly StoredRecordSource[],
): { entries: string[]; carriedForward: number } {
  const entries: string[] = [];
  const claimed = new Set<number>();

  for (const theme of customThemes) {
    const index = stored.findIndex(
      (record, position) =>
        !claimed.has(position) && record.migration.ok && record.migration.theme.id === theme.id,
    );
    if (index === -1) {
      entries.push(JSON.stringify(theme));
      continue;
    }
    claimed.add(index);
    const record = stored[index];
    const migrated = record.migration.ok ? record.migration.theme : null;
    if (migrated && sameCustomTheme(migrated, theme)) {
      entries.push(record.source);
      continue;
    }
    entries.push(JSON.stringify(withPreservedUnknownTokens(theme, record.value)));
  }

  // Records this build cannot read are never in `customThemes` (the caller only
  // ever holds loadable themes), so their absence is not a deletion. Without
  // this a later Save or Delete would quietly finish the deletion that
  // uif/issue-4671 is about.
  let carriedForward = 0;
  for (const record of stored) {
    if (record.migration.ok) continue;
    entries.push(record.source);
    carriedForward += 1;
  }
  return { entries, carriedForward };
}

/** Structural equality over the fields a stored record round-trips through. */
function sameCustomTheme(left: EmibsCustomTheme, right: EmibsCustomTheme): boolean {
  return canonicalCustomTheme(left) === canonicalCustomTheme(right);
}

function canonicalCustomTheme(theme: EmibsCustomTheme): string {
  return JSON.stringify([
    theme.id,
    theme.label,
    theme.colorScheme,
    theme.baseThemeId,
    theme.savedAt,
    theme.tokens.map((token) => [token.name, token.value]),
  ]);
}

/**
 * Re-attach the tokens `migrateStoredCustomTheme` dropped as RETIRED. They have
 * no meaning in the current vocabulary, so they stay out of the in-memory theme
 * — but they are the user's setting, and persisting must not delete them.
 * Appended after the known tokens; their original position is not recoverable
 * once a caller has edited the theme, and only an edited theme reaches here.
 */
function withPreservedUnknownTokens(theme: EmibsCustomTheme, storedValue: unknown): Record<string, unknown> {
  const preserved = unknownStoredTokens(storedValue);
  if (preserved.length === 0) return { ...theme };
  return { ...theme, tokens: [...theme.tokens, ...preserved] };
}

function unknownStoredTokens(storedValue: unknown): unknown[] {
  if (!isRecord(storedValue) || !Array.isArray(storedValue.tokens)) return [];
  return storedValue.tokens.filter(
    (entry: unknown) => isRecord(entry) && typeof entry.name === "string" && !themeTokenNameSet.has(entry.name),
  );
}

// --- Minimal JSON source scanner -------------------------------------------
// Locates the exact source span of every element of the envelope's `themes`
// array so it can be sliced out verbatim. It only computes spans; the VALUES
// still come from `JSON.parse`, and the two are cross-checked above.

type JsonSpan = { start: number; end: number };

const JSON_WHITESPACE = new Set([" ", "\t", "\n", "\r"]);
const JSON_NUMBER_PATTERN = /-?(?:0|[1-9]\d*)(?:\.\d+)?(?:[eE][+-]?\d+)?/y;

function scanStoredRecordSources(raw: string): string[] | null {
  try {
    const root = scanJsonValue(raw, 0);
    if (skipJsonWhitespace(raw, root.end) !== raw.length) return null;
    if (raw[root.start] !== "{") return null;
    const envelope = scanJsonObject(raw, root.start);
    const keys = envelope.members.map((member) => member.key);
    // A duplicate envelope key means `JSON.parse` and a textual rewrite would
    // disagree about which value survives. Refuse rather than guess.
    if (new Set(keys).size !== keys.length) return null;
    const themes = envelope.members.find((member) => member.key === "themes");
    if (!themes || raw[themes.value.start] !== "[") return null;
    return scanJsonArray(raw, themes.value.start).elements.map((span) => raw.slice(span.start, span.end));
  } catch {
    return null;
  }
}

function skipJsonWhitespace(text: string, index: number): number {
  let cursor = index;
  while (cursor < text.length && JSON_WHITESPACE.has(text[cursor])) cursor += 1;
  return cursor;
}

function scanJsonValue(text: string, index: number): JsonSpan {
  const start = skipJsonWhitespace(text, index);
  const character = text[start];
  if (character === undefined) throw new SyntaxError("Unexpected end of stored JSON.");
  if (character === "{") return { start, end: scanJsonObject(text, start).end };
  if (character === "[") return { start, end: scanJsonArray(text, start).end };
  if (character === '"') return { start, end: scanJsonString(text, start) };
  for (const literal of ["true", "false", "null"]) {
    if (text.startsWith(literal, start)) return { start, end: start + literal.length };
  }
  return { start, end: scanJsonNumber(text, start) };
}

function scanJsonString(text: string, index: number): number {
  let cursor = index + 1;
  while (cursor < text.length) {
    const character = text[cursor];
    if (character === "\\") {
      cursor += 2;
      continue;
    }
    if (character === '"') return cursor + 1;
    cursor += 1;
  }
  throw new SyntaxError("Unterminated string in stored JSON.");
}

function scanJsonNumber(text: string, index: number): number {
  JSON_NUMBER_PATTERN.lastIndex = index;
  const match = JSON_NUMBER_PATTERN.exec(text);
  if (!match || match.index !== index || match[0].length === 0) {
    throw new SyntaxError("Malformed number in stored JSON.");
  }
  return index + match[0].length;
}

function scanJsonArray(text: string, index: number): { end: number; elements: JsonSpan[] } {
  const elements: JsonSpan[] = [];
  let cursor = skipJsonWhitespace(text, index + 1);
  if (text[cursor] === "]") return { end: cursor + 1, elements };
  for (;;) {
    const element = scanJsonValue(text, cursor);
    elements.push(element);
    cursor = skipJsonWhitespace(text, element.end);
    if (text[cursor] === ",") {
      cursor += 1;
      continue;
    }
    if (text[cursor] === "]") return { end: cursor + 1, elements };
    throw new SyntaxError("Malformed array in stored JSON.");
  }
}

function scanJsonObject(text: string, index: number): { end: number; members: { key: string; value: JsonSpan }[] } {
  const members: { key: string; value: JsonSpan }[] = [];
  let cursor = skipJsonWhitespace(text, index + 1);
  if (text[cursor] === "}") return { end: cursor + 1, members };
  for (;;) {
    cursor = skipJsonWhitespace(text, cursor);
    if (text[cursor] !== '"') throw new SyntaxError("Expected a member name in stored JSON.");
    const keyEnd = scanJsonString(text, cursor);
    const key = JSON.parse(text.slice(cursor, keyEnd)) as string;
    cursor = skipJsonWhitespace(text, keyEnd);
    if (text[cursor] !== ":") throw new SyntaxError("Expected ':' in stored JSON.");
    const value = scanJsonValue(text, cursor + 1);
    members.push({ key, value });
    cursor = skipJsonWhitespace(text, value.end);
    if (text[cursor] === ",") {
      cursor += 1;
      continue;
    }
    if (text[cursor] === "}") return { end: cursor + 1, members };
    throw new SyntaxError("Malformed object in stored JSON.");
  }
}

function uniqueCustomThemeId(customThemes: readonly EmibsCustomTheme[], label: string): string {
  const base = `custom-${label.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "") || "theme"}`;
  const existingIds = new Set(customThemes.map((customTheme) => customTheme.id));
  if (!existingIds.has(base)) return base;
  let suffix = 2;
  while (existingIds.has(`${base}-${suffix}`)) suffix += 1;
  return `${base}-${suffix}`;
}

function isRecord(candidate: unknown): candidate is Record<string, unknown> {
  return Boolean(candidate && typeof candidate === "object" && !Array.isArray(candidate));
}
