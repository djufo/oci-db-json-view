import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Award,
  Bell,
  Bike,
  BookOpen,
  Bot,
  BrainCircuit,
  Building2,
  CalendarDays,
  CircleDollarSign,
  Clock,
  Columns3,
  Cookie,
  CreditCard,
  Database,
  Facebook,
  FileText,
  Flag,
  GitBranch,
  Globe2,
  Heart,
  Home,
  Images,
  Info,
  KeyRound,
  Landmark,
  Languages,
  LayoutDashboard,
  LayoutGrid,
  Lightbulb,
  Link2,
  List,
  ListChecks,
  Map as MapIcon,
  MapPinned,
  Mail,
  MessageSquare,
  Moon,
  Newspaper,
  Palette,
  PanelRightOpen,
  Phone,
  PlugZap,
  Plus,
  Search,
  ShieldCheck,
  Share2,
  SlidersHorizontal,
  Sparkles,
  Sun,
  Table2,
  Tags,
  TerminalSquare,
  ToggleRight,
  Trees,
  UploadCloud,
  User,
  Users,
  WalletCards,
  Wrench,
} from "lucide-react";
import { demoBrandImage, demoHeroImage, demoImage } from "./demoImage";
import type { AccountSessionItem } from "../components/auth/AccountSessionsPanel";
import type {
  AccountProfileBadge,
  AccountProfileLink,
  AccountProfileStat,
} from "../components/auth/AccountProfilePanel";
import type { AuthProviderAction } from "../components/auth/AuthAccessPanel";
import type {
  AdminHomeActionItem,
  AdminHomeMetric,
  AdminHomeNotice,
  AdminHomeSection,
} from "../components/data/AdminHomePanel";
import type {
  AccessibilityAuditNote,
  AccessibilityAuditViolation,
} from "../components/data/AccessibilityAuditPanel";
import type {
  AgentManagementAgent,
  AgentManagementMetric,
  AgentManagementRunner,
} from "../components/data/AgentManagementPanel";
import type {
  SubscriptionCapacityMetric,
  SubscriptionCapacityRow,
} from "../components/data/SubscriptionCapacityPanel";
import type { AdminRecordEditorMeta, AdminRecordEditorNotice } from "../components/data/AdminRecordEditorPanel";
import type {
  AgentProfileField,
  AgentProfileFieldOption,
  AgentProfileGrant,
  AgentProfileMetric,
} from "../components/data/AgentProfilePanel";
import type {
  ActivityDashboardFeedItem,
  ActivityDashboardMetric,
  ActivityDashboardQueueItem,
} from "../components/data/ActivityDashboard";
import type { ActorAccessItem, ActorAccessRoleOption } from "../components/data/ActorAccessMatrix";
import type { CommandConsoleMessage, CommandConsoleSession } from "../components/data/CommandConsole";
import type { DesignIdeaBoardItem, DesignIdeaBoardLane } from "../components/data/DesignIdeaBoardPanel";
import type { EntityCardGridItem } from "../components/data/EntityCardGridPanel";
import type { EntityFilterOption, EntityFilterPanelStat } from "../components/data/EntityFilterPanel";
import type { IdeaBacklogItem } from "../components/data/IdeaBacklogPanel";
import type { IntegrationSetupMetric } from "../components/data/IntegrationSetupPanel";
import type { KanbanColumn } from "../components/data/KanbanBoard";
import type { MetricGridItem } from "../components/data/MetricGrid";
import type { MapInfoCardBadge, MapInfoCardRow } from "../components/data/MapInfoCard";
import type { MediaAssetItem, MediaAssetStat } from "../components/data/MediaAssetPanel";
import type {
  OperationalDiagnosticDetail,
  OperationalDiagnosticMetric,
} from "../components/data/OperationalDiagnosticPanel";
import type { ProjectDirectoryItem } from "../components/data/ProjectDirectoryPanel";
import type { ProjectSettingsStat } from "../components/data/ProjectSettingsPanel";
import type { WorkBoardToolbarBadge, WorkBoardToolbarOption } from "../components/data/WorkBoardToolbar";
import type { WorkItemCardProps } from "../components/data/WorkItemCard";
import type { WorkItemPlanningOption } from "../components/data/WorkItemPlanningPanel";
import type { WorkItemTraceNote, WorkItemTraceRelationGroup } from "../components/data/WorkItemTracePanel";
import type { WorkflowCommandBarCommand } from "../components/data/WorkflowCommandBar";
import type { MarkdownDocumentMeta } from "../components/data/MarkdownDocumentPanel";
import type { FileActionListItem } from "../components/data/FileActionListPanel";
import type { FilePreviewMeta } from "../components/data/FilePreviewPanel";
import type { PaymentAccountStat, PaymentLedgerRow, PaymentMethodItem } from "../components/data/PaymentAccountPanel";
import type { RelationshipPickerItem } from "../components/data/RelationshipPickerPanel";
import type { ResourceIndexItem } from "../components/data/ResourceIndexPanel";
import type { ResourceTransferTarget } from "../components/data/ResourceTransferDialog";
import type { SchedulerControlItem } from "../components/data/SchedulerControlPanel";
import type { ProcessRunHistoryItem } from "../components/data/ProcessRunHistoryPanel";
import type { ToastStackItem } from "../components/feedback/ToastStack";
import type { ValidationSummaryItem } from "../components/feedback/ValidationSummary";
import type { ContactLinkListItem } from "../components/primitives/ContactLinkList";
import type { DescriptionListItem } from "../components/primitives/DescriptionList";
import type { InfoChipListItem } from "../components/primitives/InfoChipList";
import type { SegmentedControlOption } from "../components/primitives/SegmentedControl";
import type { TagInputItem, TagInputSuggestion } from "../components/primitives/TagInput";
import type {
  EditorialArticleAuthor,
  EditorialArticleMetaItem,
  EditorialArticleRelatedItem,
  EditorialArticleSection,
  EditorialArticleShareAction,
  EditorialArticleTocEntry,
} from "../components/layout/EditorialArticlePage";
import type { TableOfContentsNavItem } from "../components/layout/TableOfContentsNav";
import type { EditorialListingArticle, EditorialListingCategory } from "../components/layout/EditorialListingPage";
import type { LegalDocumentBlock, LegalDocumentMetaItem } from "../components/layout/LegalDocumentPage";
import type { MapViewportMarker, MapViewportStat } from "../components/layout/MapViewport";
import type { NavigationMenuGroup, NavigationMenuItem } from "../components/layout/NavigationMenu";
import type { BrandImageSource } from "../components/layout/BrandImageLink";
import type { PortalFooterLink } from "../components/layout/PortalFooter";
import type { PortalHeaderNavItem } from "../components/layout/PortalHeader";
import type {
  PortalLandingFeature,
  PortalLandingIntent,
  PortalLandingPlanner,
  PortalLandingStat,
} from "../components/layout/PortalLandingPage";
import type { PortalInfoAuthor, PortalInfoSection, PortalInfoStat } from "../components/layout/PortalInfoPage";
import type { PortalMobileNavigationGroup, PortalMobileNavigationItem } from "../components/layout/PortalMobileNavigation";
import type {
  PublicProfileAction,
  PublicProfileBadge,
  PublicProfilePanel,
  PublicProfileStat,
} from "../components/layout/PublicProfilePage";
import type { WorkspaceShellTab } from "../components/layout/WorkspaceShell";

export const navItems = [
  { label: "Overview", href: "#overview", icon: <LayoutDashboard size={17} />, active: true },
  { label: "Landing Page", href: "#portal-landing", icon: <Sparkles size={17} /> },
  { label: "Info Page", href: "#portal-info", icon: <Info size={17} /> },
  { label: "Article Page", href: "#editorial-article", icon: <Newspaper size={17} /> },
  { label: "Table of Contents", href: "#table-of-contents-nav", icon: <List size={17} /> },
  { label: "Article Listing", href: "#editorial-listing", icon: <BookOpen size={17} /> },
  { label: "Legal Document", href: "#legal-document", icon: <FileText size={17} /> },
  { label: "Cookie Consent", href: "#cookie-consent", icon: <Cookie size={17} /> },
  { label: "Toast Stack", href: "#toast-stack", icon: <Bell size={17} /> },
  { label: "Notice Banner", href: "#notice-banner", icon: <AlertTriangle size={17} /> },
  { label: "Validation Summary", href: "#validation-summary", icon: <AlertTriangle size={17} /> },
  { label: "Data States", href: "#data-state-panel", icon: <Info size={17} /> },
  { label: "Dialog Frame", href: "#dialog-frame", icon: <PanelRightOpen size={17} /> },
  { label: "Confirm Dialog", href: "#confirmation-dialog", icon: <AlertTriangle size={17} /> },
  { label: "Creation Dialog", href: "#creation-dialog", icon: <Plus size={17} /> },
  { label: "Public Profile", href: "#public-profile", icon: <User size={17} /> },
  { label: "Contact Links", href: "#contact-link-list", icon: <Phone size={17} /> },
  { label: "Portal Shell", href: "#portal-shell", icon: <PanelRightOpen size={17} /> },
  { label: "Navigation Menu", href: "#navigation-menu", icon: <List size={17} /> },
  { label: "Portal Header", href: "#portal-header", icon: <Home size={17} /> },
  { label: "Brand Link", href: "#brand-image-link", icon: <Images size={17} /> },
  { label: "Account Menu", href: "#account-menu", icon: <User size={17} /> },
  { label: "Identity Avatar", href: "#identity-avatar", icon: <User size={17} /> },
  { label: "Status Indicator", href: "#status-indicator", icon: <Activity size={17} /> },
  { label: "Payload Block", href: "#payload-block", icon: <TerminalSquare size={17} /> },
  { label: "Segmented Control", href: "#segmented-control", icon: <Languages size={17} /> },
  { label: "Content Tabs", href: "#content-tabs", icon: <ListChecks size={17} /> },
  { label: "Collapsible", href: "#collapsible", icon: <Columns3 size={17} /> },
  { label: "Icon Button", href: "#icon-button", icon: <Bell size={17} /> },
  { label: "Action Group", href: "#action-group", icon: <LayoutGrid size={17} /> },
  { label: "Search Field", href: "#search-field", icon: <Search size={17} /> },
  { label: "Command Palette", href: "#command-palette", icon: <Search size={17} /> },
  { label: "Combobox Field", href: "#combobox-field", icon: <Search size={17} /> },
  { label: "Select Control", href: "#select-control", icon: <List size={17} /> },
  { label: "Temporal Input", href: "#temporal-input-control", icon: <CalendarDays size={17} /> },
  { label: "Text Area", href: "#textarea-control", icon: <FileText size={17} /> },
  { label: "Icon Input", href: "#icon-input-field", icon: <KeyRound size={17} /> },
  { label: "Tag Input", href: "#tag-input", icon: <Tags size={17} /> },
  { label: "Info Chips", href: "#info-chip-list", icon: <Tags size={17} /> },
  { label: "Description List", href: "#description-list", icon: <ListChecks size={17} /> },
  { label: "Metric Grid", href: "#metric-grid", icon: <LayoutDashboard size={17} /> },
  { label: "Mode Controls", href: "#mode-control", icon: <SlidersHorizontal size={17} /> },
  { label: "Entity Filters", href: "#entity-filter-panel", icon: <Search size={17} /> },
  { label: "Mobile Nav", href: "#portal-mobile-nav", icon: <MapPinned size={17} /> },
  { label: "Portal Footer", href: "#portal-footer", icon: <Info size={17} /> },
  { label: "Workspace Shell", href: "#workspace-shell", icon: <Wrench size={17} /> },
  { label: "Auth Access", href: "#auth-access", icon: <ShieldCheck size={17} /> },
  { label: "Session Refresh", href: "#session-refresh-dialog", icon: <KeyRound size={17} /> },
  { label: "Auth Status", href: "#auth-status", icon: <Mail size={17} /> },
  { label: "Account Sessions", href: "#account-sessions", icon: <KeyRound size={17} /> },
  { label: "Account Profile", href: "#account-profile", icon: <User size={17} /> },
  { label: "Payments", href: "#payment-account", icon: <CreditCard size={17} /> },
  { label: "Integrations", href: "#integration-setup", icon: <PlugZap size={17} /> },
  { label: "Project Settings", href: "#project-settings", icon: <Wrench size={17} /> },
  { label: "Editable Forms", href: "#editable-form-panel", icon: <Wrench size={17} /> },
  { label: "Checklist Editor", href: "#checklist-editor-panel", icon: <ListChecks size={17} /> },
  { label: "Board Toolbar", href: "#work-board-toolbar", icon: <Search size={17} /> },
  { label: "Work Item Card", href: "#work-item-card", icon: <FileText size={17} /> },
  { label: "Workflow Commands", href: "#workflow-command-bar", icon: <GitBranch size={17} /> },
  { label: "Notification Toggle", href: "#notification-toggle", icon: <Bell size={17} /> },
  { label: "Checkbox Control", href: "#checkbox-control", icon: <ListChecks size={17} /> },
  { label: "Switch Control", href: "#switch-control", icon: <ToggleRight size={17} /> },
  { label: "Work Item Planning", href: "#work-item-planning", icon: <ListChecks size={17} /> },
  { label: "Relation Editor", href: "#work-item-relation-editor", icon: <GitBranch size={17} /> },
  { label: "Work Item Trace", href: "#work-item-trace", icon: <GitBranch size={17} /> },
  { label: "Live Activity", href: "#live-activity", icon: <Activity size={17} /> },
  { label: "Subscriptions", href: "#subscription-capacity", icon: <KeyRound size={17} /> },
  { label: "Schedulers", href: "#scheduler-control", icon: <CalendarDays size={17} /> },
  { label: "Run History", href: "#process-run-history", icon: <TerminalSquare size={17} /> },
  { label: "Admin Home", href: "#admin-home", icon: <ShieldCheck size={17} /> },
  { label: "Design Ideas", href: "#design-idea-board", icon: <Lightbulb size={17} /> },
  { label: "Idea Backlog", href: "#idea-backlog", icon: <Lightbulb size={17} /> },
  { label: "Access Matrix", href: "#actor-access", icon: <Users size={17} /> },
  { label: "Agent Management", href: "#agent-management", icon: <Bot size={17} /> },
  { label: "Agent Profile", href: "#agent-profile", icon: <ShieldCheck size={17} /> },
  { label: "Resource Index", href: "#resource-index", icon: <Database size={17} /> },
  { label: "Project Directory", href: "#project-directory-panel", icon: <Database size={17} /> },
  { label: "Relationship Picker", href: "#relationship-picker", icon: <GitBranch size={17} /> },
  { label: "Record Editor", href: "#admin-record-editor", icon: <FileText size={17} /> },
  { label: "Diagnostics", href: "#operational-diagnostics", icon: <Database size={17} /> },
  { label: "Media Assets", href: "#media-assets", icon: <Images size={17} /> },
  { label: "Resource Transfer", href: "#resource-transfer-dialog", icon: <ArrowRight size={17} /> },
  { label: "File Preview", href: "#file-preview-panel", icon: <FileText size={17} /> },
  { label: "File Upload", href: "#file-upload-control", icon: <UploadCloud size={17} /> },
  { label: "Markdown Documents", href: "#markdown-documents", icon: <FileText size={17} /> },
  { label: "Command Console", href: "#command-console", icon: <TerminalSquare size={17} /> },
  { label: "Component Playground", href: "#component-playground-panel", icon: <SlidersHorizontal size={17} /> },
  { label: "Component Review", href: "#component-review-panel", icon: <LayoutDashboard size={17} /> },
  { label: "Theme Audit", href: "#theme-audit-panel", icon: <Palette size={17} /> },
  { label: "Preview Matrix", href: "#preview-matrix-panel", icon: <Table2 size={17} /> },
  { label: "Score Board", href: "#score-board", icon: <Columns3 size={17} /> },
  { label: "Entity Card Grid", href: "#entity-card-grid", icon: <LayoutGrid size={17} /> },
  { label: "Entity Browser", href: "#entity-browser", icon: <Database size={17} /> },
  { label: "Record Detail", href: "#record-detail", icon: <PanelRightOpen size={17} /> },
  { label: "Explorer", href: "#explorer-workspace", icon: <MapPinned size={17} /> },
  { label: "Map Viewport", href: "#map-viewport", icon: <MapIcon size={17} /> },
  { label: "Map Info Card", href: "#map-info-card", icon: <MapPinned size={17} /> },
  { label: "Map Marker Pin", href: "#map-marker-pin", icon: <MapPinned size={17} /> },
  { label: "Map Controls", href: "#map-control-panel", icon: <SlidersHorizontal size={17} /> },
  { label: "Extraction Notes", href: "#extractions", icon: <BookOpen size={17} /> },
];

export const statusItems = [
  { id: "refresh", label: "Manual refresh", value: "ready", tone: "info" as const, variant: "badge" as const },
  { id: "components", label: "Components", value: "118", detail: "visible in demos", icon: <ShieldCheck size={18} />, tone: "success" as const },
  { id: "extractions", label: "Extraction cycles", value: "137", detail: "Score + eLitua", tone: "accent" as const },
  { id: "route", label: "Route target", value: "ui-lib.ayc.io", detail: "hostable catalog" },
];

export const adminHomeMetrics: AdminHomeMetric[] = [
  {
    id: "actors",
    label: "Actors",
    value: "18",
    detail: "Score role/access rows",
    tone: "info",
    icon: <Users size={15} />,
  },
  {
    id: "projects",
    label: "Projects",
    value: "7",
    detail: "enabled workspaces",
    tone: "accent",
    icon: <Database size={15} />,
  },
  {
    id: "sessions",
    label: "Sessions",
    value: "4",
    detail: "active admin devices",
    tone: "success",
    icon: <KeyRound size={15} />,
  },
  {
    id: "alerts",
    label: "Alerts",
    value: "1",
    detail: "permissions need review",
    tone: "warning",
    icon: <Bell size={15} />,
  },
];

export const adminHomeNotices: AdminHomeNotice[] = [
  {
    id: "route-ownership",
    title: "Route and permission policy stay local",
    tone: "info",
    icon: <ShieldCheck size={16} />,
    children:
      "The shared panel only renders the admin landing surface; Score and eLitua still own project grants, session loading, and route guards.",
  },
];

export const adminHomeActions: AdminHomeActionItem[] = [
  {
    id: "users",
    title: "Users",
    description: "Manage account records, verification state, and role changes.",
    href: "#admin-home",
    icon: <Users size={18} />,
    featured: true,
    meta: [
      { id: "elitua", label: "eLitua", tone: "accent" },
      { id: "accounts", label: "42 accounts", tone: "info" },
    ],
    trailing: "AdminProfilePage",
  },
  {
    id: "projects",
    title: "Projects",
    description: "Review project metadata, access policy, priorities, and definition-of-done items.",
    href: "#resource-index",
    icon: <Database size={18} />,
    meta: [
      { id: "score", label: "Score", tone: "success" },
      { id: "ready", label: "resource index ready", tone: "neutral" },
    ],
    trailing: "AdminDashboard",
  },
  {
    id: "profiles",
    title: "Profiles",
    description: "Open guide/provider profile administration without moving profile mutations into the shared layer.",
    href: "#account-profile",
    icon: <Activity size={18} />,
    meta: [{ id: "review", label: "review queue", tone: "warning" }],
  },
  {
    id: "sessions",
    title: "Sessions",
    description: "Show active-device summary while revocation and session parsing stay in the product.",
    href: "#account-sessions",
    icon: <KeyRound size={18} />,
    meta: [{ id: "secure", label: "security", tone: "info" }],
  },
];

export const adminHomeSections: AdminHomeSection[] = [
  {
    id: "account-summary",
    title: "Admin account",
    description: "Optional sections carry product-owned account or environment details.",
    children: (
      <dl className="admin-home-demo-account">
        <div>
          <dt>Identity</dt>
          <dd>owner@example.lt</dd>
        </div>
        <div>
          <dt>Role</dt>
          <dd>admin</dd>
        </div>
        <div>
          <dt>Environment</dt>
          <dd>score-work</dd>
        </div>
      </dl>
    ),
  },
];

export const ideaBacklogItems: IdeaBacklogItem[] = [
  {
    id: "idea-routing",
    title: "Saved board filters for UI Framework refactors",
    description: "Let operators preserve project, epic, and Lucene search presets for recurring cleanup passes.",
    status: "Open",
    statusTone: "info",
    createdAt: "2026-06-22",
    source: "Score admin",
    icon: <Lightbulb size={16} />,
    meta: [
      { id: "project", label: "score", tone: "success" },
      { id: "priority", label: "low", tone: "neutral" },
    ],
    href: "#idea-backlog",
  },
  {
    id: "idea-evidence",
    title: "Attach extraction evidence to adoption tasks",
    description: "Show source paths and catalog links beside low-priority refactor follow-ups.",
    status: "Grooming",
    statusTone: "warning",
    createdAt: "2026-06-24",
    source: "Maestro note",
    icon: <MessageSquare size={16} />,
    meta: [{ id: "epic", label: "UI Framework", tone: "accent" }],
  },
  {
    id: "idea-dod",
    title: "Definition-of-done checklist templates",
    description: "Seed common build, deploy, and verification items when new Score projects are created.",
    status: "Ready",
    statusTone: "success",
    createdAt: "2026-06-27",
    source: "Project admin",
    icon: <ListChecks size={16} />,
  },
];

export const designIdeaBoardLanes: DesignIdeaBoardLane[] = [
  {
    id: "ready",
    title: "Ready to port",
    description: "Mockup ideas with a clear product owner and known implementation surface.",
  },
  {
    id: "evaluate",
    title: "Evaluate first",
    description: "Ideas that need product, data, or workflow decisions before implementation.",
  },
  {
    id: "later",
    title: "Later candidates",
    description: "Useful patterns to keep visible while higher-value adoption work finishes.",
  },
];

export const designIdeaBoardItems: DesignIdeaBoardItem[] = [
  {
    id: "elitua-portal-planner",
    title: "Portal planner entry",
    source: "eLitua portal landing",
    sourceHref: "#/c/portal-landing-page",
    target: "eLitua",
    laneId: "ready",
    priority: "P1",
    note: "Port the hero search, route chips, and planner CTA into the public home route once localized copy and search dispatch are wired.",
    ownerBoundary: "eLitua owns route state, localization, search dispatch, saved trips, and analytics.",
    blockers: ["Localized copy", "Search route state"],
  },
  {
    id: "elitua-map-itinerary",
    title: "Map itinerary strip",
    source: "eLitua map explorer",
    sourceHref: "#/c/map-viewport",
    target: "eLitua",
    laneId: "ready",
    priority: "P1",
    note: "Use the bottom route strip and selected-place detail as the live map review shape for traveler itinerary building.",
    ownerBoundary: "eLitua owns map provider state, selected records, route geometry, and persistence.",
    blockers: ["Map record DTOs", "Saved-trip mutation path"],
  },
  {
    id: "score-release-pulse",
    title: "Release pulse panel",
    source: "Score operations mockup",
    sourceHref: "#/m/score-operations-dashboard",
    target: "Score",
    laneId: "evaluate",
    priority: "P2",
    note: "Adapt the compact status rhythm into release and QA surfaces after release-grant workflow rules are clarified.",
    ownerBoundary: "Score owns live workflow counts, release grants, scheduler state, and task transitions.",
    blockers: ["Release grant decision", "QA transition copy"],
  },
  {
    id: "score-command-sessions",
    title: "Command session rail",
    source: "Score command console mockup",
    sourceHref: "#/m/score-command-console",
    target: "Score",
    laneId: "later",
    priority: "P3",
    note: "Preserve the compact session rail and generated-work links for a later Maestro chat refinement pass.",
    ownerBoundary: "Score owns chat persistence, task creation, transcript retention, and notifications.",
    blockers: ["Transcript retention policy", "Session search semantics"],
  },
  {
    id: "elitua-checkout-readiness",
    title: "Checkout readiness stack",
    source: "eLitua checkout",
    sourceHref: "#/c/payment-checkout-panel",
    target: "eLitua",
    laneId: "evaluate",
    priority: "P2",
    note: "Keep the payment account and trip total composition visible while payout and payment status language settles.",
    ownerBoundary: "eLitua owns payment processor calls, provider payout data, traveler identity, and receipt history.",
    blockers: ["Payment provider contract", "Payout status vocabulary"],
  },
];

export const adminRecordEditorMeta: AdminRecordEditorMeta[] = [
  { id: "entity", label: "user #42", tone: "info" },
  { id: "role", label: "guide", tone: "accent" },
  { id: "state", label: "active", tone: "success" },
];

export const adminRecordEditorNotices: AdminRecordEditorNotice[] = [
  {
    id: "saved",
    tone: "success",
    title: "Saved successfully",
    message: "Product code owns the mutation response, redirect policy and toast queue.",
  },
  {
    id: "validation",
    tone: "danger",
    title: "Email requires review",
    message: "Validation and localized error copy stay in the consuming admin route.",
  },
];

export const entityCardGridItems: EntityCardGridItem[] = [
  {
    id: "accm-lakehouse",
    eyebrow: "Accommodation",
    title: "Aukstaitija Lakehouse Retreat",
    subtitle: "Utena region",
    description: "Rural stay card with capacity, license, region and review status mapped from eLitua accommodation records.",
    accentColor: "#0f766e",
    icon: <Building2 size={24} />,
    badges: [
      { id: "type", label: "Sodyba", tone: "accent" },
      { id: "review", label: "Needs review", tone: "warning" },
    ],
    meta: [
      { id: "region", label: "Utena", icon: <MapPinned size={13} /> },
      { id: "capacity", label: "18 beds", icon: <Home size={13} /> },
    ],
    footer: "License ACCM-774",
  },
  {
    id: "guide-ruta",
    eyebrow: "Guide",
    title: "Ruta Travels",
    subtitle: "Vilnius, Trakai",
    description: "Guide card pattern with identity verification, language summary, route region and public profile action.",
    accentColor: "#2563eb",
    icon: <Users size={24} />,
    badges: [
      { id: "verified", label: "Verified", tone: "success" },
      { id: "language", label: "LT +2", tone: "info" },
    ],
    meta: [
      { id: "regions", label: "Vilnius routes", icon: <MapPinned size={13} /> },
      { id: "phone", label: "+370 600 00000", icon: <Phone size={13} /> },
    ],
    footer: "Public profile route stays in eLitua.",
    href: "#public-profile",
  },
  {
    id: "geo-old-town",
    eyebrow: "Place",
    title: "Vilnius Old Town",
    subtitle: "UNESCO city route",
    description: "Place cards keep type, verification and map-location metadata while map dispatch remains product-owned.",
    accentColor: "#7c3aed",
    icon: <Landmark size={24} />,
    badges: [
      { id: "geo", label: "Geo", tone: "accent" },
      { id: "published", label: "Published", tone: "success" },
    ],
    meta: [
      { id: "city", label: "Vilnius", icon: <MapPinned size={13} /> },
      { id: "score", label: "96% content score", icon: <Award size={13} /> },
    ],
    footer: "Updated 2026-06-23",
  },
  {
    id: "guide-mantas",
    eyebrow: "Guide",
    title: "Mantas Food Walks",
    subtitle: "Kaunas tasting routes",
    description: "Compact card content can support admin review without absorbing the guide state service.",
    accentColor: "#be185d",
    icon: <Users size={24} />,
    badges: [
      { id: "review", label: "Needs review", tone: "warning" },
      { id: "language", label: "EN +1", tone: "info" },
    ],
    meta: [
      { id: "city", label: "Kaunas", icon: <MapPinned size={13} /> },
      { id: "languages", label: "English, Lithuanian", icon: <Globe2 size={13} /> },
    ],
    footer: "License date pending",
  },
  {
    id: "accm-dunes",
    eyebrow: "Accommodation",
    title: "Dunes family apartments",
    subtitle: "Neringa",
    description: "Accommodation type accents and footer identifiers are passed as data, not hardcoded into the grid.",
    accentColor: "#b45309",
    icon: <Building2 size={24} />,
    badges: [
      { id: "type", label: "Apartments", tone: "accent" },
      { id: "review", label: "Draft", tone: "neutral" },
    ],
    meta: [
      { id: "region", label: "Neringa", icon: <MapPinned size={13} /> },
      { id: "capacity", label: "6 guests", icon: <Home size={13} /> },
    ],
    footer: "Imported from stays feed",
  },
  {
    id: "geo-anyksciai",
    eyebrow: "Place",
    title: "Anyksciai treetop path",
    subtitle: "Forest attraction",
    description: "Empty images fall back to an icon block so card dimensions stay stable during media loading.",
    accentColor: "#15803d",
    icon: <Trees size={24} />,
    badges: [
      { id: "geo", label: "Place", tone: "success" },
      { id: "draft", label: "Draft", tone: "neutral" },
    ],
    meta: [
      { id: "region", label: "Anyksciai", icon: <MapPinned size={13} /> },
      { id: "owner", label: "Places import", icon: <Database size={13} /> },
    ],
    footer: "Updated 2026-06-12",
  },
];

export const workBoardToolbarBadges: WorkBoardToolbarBadge[] = [
  { id: "actor", label: "Codex Maestro", tone: "accent" },
  { id: "refresh", label: "Manual refresh", tone: "neutral" },
  { id: "count", label: "18 / 74 tasks", tone: "info" },
  { id: "search", label: "type:story", tone: "success" },
];

export const workBoardProjectOptions: WorkBoardToolbarOption[] = [
  { value: "__all_projects__", label: "All projects (74)" },
  { value: "score", label: "Score (38)" },
  { value: "elitua", label: "eLitua (21)" },
  { value: "emibs", label: "emibs (15)" },
];

export const workBoardEpicOptions: WorkBoardToolbarOption[] = [
  { value: "__all_epics__", label: "All epics (74)" },
  { value: "task-206", label: "UI Framework (12)" },
  { value: "task-64", label: "Agentic orchestration (9)" },
  { value: "task-175", label: "Narrow responsive design (4)" },
];

export const workItemCards: WorkItemCardProps[] = [
  {
    itemId: "task-497",
    eyebrow: "ready story",
    title: "Refactor Score board task cards to adopt WorkItemCard",
    subtitle: "Low-priority follow-up after the shared card shell is reviewed.",
    href: "#work-item-card/task-497",
    externalLink: {
      href: "#work-item-card/task-497-new",
      label: "Open task-497 in a new tab",
      title: "Open in new tab",
      target: "_blank",
    },
    badges: [
      { id: "type", label: "story", tone: "info" },
      { id: "project", label: "score" },
      { id: "priority", label: "p900", tone: "neutral" },
      { id: "role", label: "engineer", tone: "accent" },
      { id: "actor", label: "a:codex-maestro", tone: "success" },
    ],
    epic: {
      label: "UI Framework",
      href: "#work-item-card/task-312",
      title: "Parent epic",
    },
    meta: [
      { id: "status", label: "ready", icon: <GitBranch size={13} /> },
      { id: "age", label: "created today", icon: <Clock size={13} /> },
      { id: "owner", label: "agent-codex-maestro", icon: <Bot size={13} /> },
    ],
  },
  {
    itemId: "task-312",
    eyebrow: "epic context",
    title: "UI Framework",
    subtitle: "Owning epic for shared UI extractions and adoption follow-ups.",
    selected: true,
    density: "compact",
    badges: [
      { id: "type", label: "epic", tone: "accent" },
      { id: "project", label: "score" },
      { id: "children", label: "child tasks", tone: "info" },
    ],
    meta: [
      { id: "status", label: "created", icon: <GitBranch size={13} /> },
      { id: "priority", label: "p200", icon: <ListChecks size={13} /> },
    ],
    footer: "Route, workflow, actor labels and persistence stay in Score.",
  },
];

export const workflowCommandBarCommands: WorkflowCommandBarCommand[] = [
  {
    id: "processing-review",
    label: "Submit",
    to: "review",
    direction: "next",
    icon: <ArrowRight size={15} />,
    description: "Move implementation work to reviewer attention.",
    meta: "Developer or manager access",
  },
  {
    id: "processing-ready",
    label: "Backlog",
    to: "ready",
    direction: "back",
    description: "Return work to the ready queue without closing the task.",
    meta: "Manager override after triage",
  },
  {
    id: "open-detail",
    label: "Open detail",
    to: "task route",
    direction: "neutral",
    icon: <GitBranch size={15} />,
    description: "Use alongside route-backed task cards or detail panels.",
    meta: "Route stays product-owned",
  },
];

export const workflowReleaseCommands: WorkflowCommandBarCommand[] = [
  {
    id: "review-qa",
    label: "Approve",
    to: "qa",
    direction: "next",
    description: "Advance reviewer-approved work into QA.",
    meta: "Reviewer decision required",
  },
  {
    id: "qa-prod",
    label: "Promote",
    to: "prod",
    direction: "next",
    disabled: true,
    description: "Release-gated transitions can render disabled with policy copy.",
    meta: "Direct release grant missing",
  },
  {
    id: "review-processing",
    label: "Changes",
    to: "processing",
    direction: "back",
    icon: <AlertTriangle size={15} />,
    description: "Return work for implementation changes.",
    meta: "Comment and audit trail stay local",
  },
];

export const projectSettingsStats: ProjectSettingsStat[] = [
  {
    id: "runtime",
    label: "Runtime config",
    value: "1 doc",
    detail: "admin-gated JSON",
    tone: "info",
    icon: <Database size={15} />,
  },
  {
    id: "public",
    label: "Public config",
    value: "runtime",
    detail: "fetched by UI",
    tone: "success",
    icon: <Globe2 size={15} />,
  },
  {
    id: "summary",
    label: "Digest",
    value: "enabled",
    detail: "recipient + title",
    tone: "accent",
    icon: <Mail size={15} />,
  },
  {
    id: "secrets",
    label: "Secrets",
    value: "vault",
    detail: "referenced by name",
    tone: "warning",
    icon: <KeyRound size={15} />,
  },
];

export const workItemTypeOptions: WorkItemPlanningOption[] = [
  { value: "story", label: "story" },
  { value: "bug", label: "bug" },
  { value: "issue", label: "issue" },
  { value: "task", label: "task" },
  { value: "idea", label: "idea" },
  { value: "epic", label: "epic" },
];

export const workItemProjectOptions: WorkItemPlanningOption[] = [
  { value: "score", label: "score" },
  { value: "elitua", label: "elitua" },
  { value: "emibs", label: "emibs" },
];

export const workItemRoleOptions: WorkItemPlanningOption[] = [
  { value: "", label: "Unspecified" },
  { value: "researcher", label: "researcher" },
  { value: "architect", label: "architect" },
  { value: "engineer", label: "engineer" },
  { value: "worker", label: "worker" },
  { value: "maestro", label: "maestro" },
];

export const workItemComplexityOptions: WorkItemPlanningOption[] = [
  { value: "", label: "Unspecified" },
  { value: "small", label: "small" },
  { value: "medium", label: "medium" },
  { value: "large", label: "large" },
];

export const workItemActorOptions = [
  "agent-codex-maestro",
  "agent-codex-reviewer",
  "agent-codex-worker",
  "owner",
];

export const workItemEpicOptions = [
  "task-206 - UI Framework",
  "task-64 - Agentic orchestration",
  "task-175 - Narrow responsive design",
];

export const workItemTraceRelationGroups: WorkItemTraceRelationGroup[] = [
  {
    id: "depends-on",
    label: "Depends on",
    items: [
      {
        id: "task-290",
        label: "task-290",
        href: "#work-item-trace",
        meta: "ProjectSettingsPanel extraction",
        tone: "info",
      },
    ],
  },
  {
    id: "blocked-by",
    label: "Blocked by",
    emptyLabel: "No open blockers.",
    items: [],
  },
  {
    id: "related",
    label: "Related",
    items: [
      {
        id: "task-293",
        label: "task-293",
        href: "#work-item-planning",
        meta: "Planning controls adoption",
        tone: "accent",
      },
      {
        id: "task-206",
        label: "task-206",
        href: "#extractions",
        meta: "UI Framework epic",
        tone: "success",
      },
    ],
  },
];

export const workItemTraceNotes: WorkItemTraceNote[] = [
  {
    id: "review-1",
    author: "agent-codex-reviewer",
    decision: "request changes",
    decisionTone: "warning",
    createdAt: "2026-06-28 02:44 UTC",
    version: "v2",
    body: "The relation section needs explicit empty states and the review note body must wrap long task ids and actor names.",
  },
  {
    id: "review-2",
    author: "agent-codex-maestro",
    decision: "approved",
    decisionTone: "success",
    createdAt: "2026-06-28 03:02 UTC",
    version: "v3",
    meta: "follow-up ready",
    body: "Extraction keeps review creation, task route generation, workflow rules, subscriptions and audit behavior in Score.",
  },
  {
    id: "review-3",
    author: "owner",
    createdAt: "2026-06-28 03:12 UTC",
    body: "Review the shared trace panel in the UI catalog before replacing the task detail relations and review-note sections.",
  },
];

export const toastStackItems: ToastStackItem[] = [
  {
    id: "settings-saved",
    title: "Settings saved",
    description: "The Score settings page emits this success message after the product-owned API call returns.",
    tone: "success",
    meta: "now",
  },
  {
    id: "agent-warning",
    title: "Agent capacity warning",
    description: "Consumers can map operational warnings into a shared visual shape without moving capacity policy.",
    tone: "warning",
    meta: "2m",
    icon: <AlertTriangle size={18} />,
  },
  {
    id: "maestro-queued",
    title: "Maestro prompt queued",
    description: "Actions, route links, dedupe, timers and toast persistence remain controlled by the app.",
    tone: "info",
    meta: "task-288",
    icon: <Bell size={18} />,
  },
];

export const validationSummaryProfileItems: ValidationSummaryItem[] = [
  {
    id: "business-name",
    label: "Business name",
    message: "Enter the public accommodation or provider name before saving.",
    controlId: "validation-demo-business-name",
  },
  {
    id: "contact-email",
    label: "Contact email",
    message: "Use a valid email address for traveler replies.",
    controlId: "validation-demo-contact-email",
  },
  {
    id: "api-secret",
    label: "API secret",
    message: "Secret key is required before testing the Bókun connection.",
    controlId: "validation-demo-api-secret",
    tone: "warning",
  },
];

export const validationSummarySettingsItems: ValidationSummaryItem[] = [
  {
    id: "settings-json",
    label: "Settings JSON",
    message: "Config must parse as an object before Score can persist it.",
    controlId: "validation-demo-settings-json",
  },
  {
    id: "parent-epic",
    label: "Parent epic",
    message: "The selected parent must be an accessible epic and cannot create a cycle.",
    controlId: "validation-demo-parent-epic",
  },
];

export const segmentedLocaleOptions: SegmentedControlOption[] = [
  { id: "en", label: "EN", ariaLabel: "English" },
  { id: "lt", label: "LT", ariaLabel: "Lithuanian" },
  { id: "ru", label: "RU", ariaLabel: "Russian" },
];

export const segmentedThemeOptions: SegmentedControlOption[] = [
  { id: "light", label: "Light", icon: <Sun size={16} />, ariaLabel: "Light theme" },
  { id: "dark", label: "Dark", icon: <Moon size={16} />, ariaLabel: "Dark theme" },
];

export const segmentedViewOptions: SegmentedControlOption[] = [
  { id: "map", label: "Map", icon: <MapIcon size={16} />, description: "Pins" },
  { id: "table", label: "Table", icon: <List size={16} />, description: "Rows" },
  { id: "cards", label: "Cards", icon: <LayoutGrid size={16} />, description: "Grid" },
];

const brandDesktopSrc =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='112' viewBox='0 0 300 112'%3E%3Crect width='300' height='112' rx='16' fill='%23ffffff'/%3E%3Crect x='18' y='24' width='58' height='64' rx='12' fill='%23046bd2'/%3E%3Crect x='29' y='35' width='36' height='12' rx='3' fill='%23facc15'/%3E%3Crect x='29' y='50' width='36' height='12' rx='3' fill='%2316a34a'/%3E%3Crect x='29' y='65' width='36' height='12' rx='3' fill='%23dc2626'/%3E%3Ctext x='96' y='67' font-family='Arial,Helvetica,sans-serif' font-size='42' font-weight='800' fill='%23046bd2'%3EeLitua%3C/text%3E%3Ctext x='98' y='88' font-family='Arial,Helvetica,sans-serif' font-size='13' font-weight='700' fill='%231e293b'%3ELithuania in the palm of your hand%3C/text%3E%3C/svg%3E";

const brandMobileSrc =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='112' height='42' viewBox='0 0 112 42'%3E%3Crect width='112' height='42' rx='10' fill='%23046bd2'/%3E%3Crect x='10' y='10' width='16' height='5' rx='2' fill='%23facc15'/%3E%3Crect x='10' y='18' width='16' height='5' rx='2' fill='%2316a34a'/%3E%3Crect x='10' y='26' width='16' height='5' rx='2' fill='%23dc2626'/%3E%3Ctext x='34' y='28' font-family='Arial,Helvetica,sans-serif' font-size='20' font-weight='800' fill='%23ffffff'%3EeLitua%3C/text%3E%3C/svg%3E";

export const brandImageDesktop: BrandImageSource = {
  src: brandDesktopSrc,
  sizes: "(max-width: 300px) 100vw, 300px",
  width: 300,
  height: 112,
};

export const brandImageMobile: BrandImageSource = {
  src: brandMobileSrc,
  sizes: "112px",
  width: 112,
  height: 42,
};

export const tagInputItems: TagInputItem[] = [
  { id: "lt", label: "Lithuanian", value: "Lithuanian", tone: "success" },
  { id: "en", label: "English", value: "English", tone: "info" },
  { id: "pl", label: "Polish", value: "Polish", tone: "accent" },
];

export const tagInputSuggestions: TagInputSuggestion[] = [
  { value: "Latvian" },
  { value: "German" },
  { value: "French" },
  { value: "Spanish" },
  { value: "Italian" },
  { value: "Estonian" },
];

export const infoChipListLanguageItems: InfoChipListItem[] = [
  { id: "lt", label: "Lithuanian", tone: "success" },
  { id: "en", label: "English", tone: "info" },
  { id: "de", label: "German", tone: "accent" },
  { id: "pl", label: "Polish" },
];

export const infoChipListRouteItems: InfoChipListItem[] = [
  { id: "old-town", label: "Vilnius Old Town", icon: <MapPinned size={15} />, tone: "info", href: "#info-chip-list" },
  { id: "curonian", label: "Curonian Spit", icon: <MapPinned size={15} />, tone: "success", href: "#info-chip-list" },
  { id: "trakai", label: "Trakai Castle", icon: <MapPinned size={15} />, tone: "accent" },
];

export const contactLinkListPublicItems: ContactLinkListItem[] = [
  { id: "phone", label: "+370 600 00124", href: "tel:+37060000124", icon: <Phone size={16} />, tone: "success" },
  { id: "email", label: "austeja@example.lt", href: "mailto:austeja@example.lt", icon: <Mail size={16} />, tone: "info" },
  { id: "website", label: "Website", href: "https://example.lt", icon: <Globe2 size={16} />, external: true, tone: "accent" },
];

export const contactLinkListDetailItems: ContactLinkListItem[] = [
  { id: "phone", label: "+370 612 00000", href: "tel:+37061200000", icon: <Phone size={15} />, meta: "direct" },
  { id: "email", label: "host@example.lt", href: "mailto:host@example.lt", icon: <Mail size={15} />, meta: "replies in 1 day" },
  {
    id: "website",
    label: "hostel.example.lt",
    href: "https://hostel.example.lt",
    icon: <Globe2 size={15} />,
    external: true,
    meta: "external",
  },
];

export const descriptionListGuideItems: DescriptionListItem[] = [
  { id: "license", label: "License", value: "LT-G-2041", tone: "success", icon: <ShieldCheck size={15} /> },
  { id: "licensed-since", label: "Licensed since", value: "2019", meta: "verified by eLitua" },
  { id: "country", label: "Country", value: "Lithuania", icon: <Flag size={15} /> },
];

export const descriptionListTaskItems: DescriptionListItem[] = [
  { id: "author", label: "Author", value: "Maestro", tone: "info", icon: <Bot size={15} /> },
  { id: "branch", label: "Branch", value: "score-299-extract-description-list", meta: "score-work merge target" },
  {
    id: "preview",
    label: "Review link",
    value: "catalog preview",
    href: "#description-list",
    meta: "route supplied by Score",
  },
  { id: "updated", label: "Updated", value: "Just now" },
];

export const descriptionListPlainItems: DescriptionListItem[] = [
  { id: "provider", label: "Provider", value: "Bokun" },
  { id: "channel", label: "Channel", value: "Default" },
  { id: "sync", label: "Last sync", value: "Just now", tone: "success" },
];

export const metricGridItems: MetricGridItem[] = [
  {
    id: "ready",
    label: "Ready work",
    value: "14",
    detail: "Score queue count",
    tone: "success",
    icon: <ListChecks size={15} />,
  },
  {
    id: "sync",
    label: "Last sync",
    value: "Just now",
    detail: "eLitua integration status",
    tone: "info",
    icon: <PlugZap size={15} />,
  },
  {
    id: "profiles",
    label: "Profiles",
    value: "28",
    detail: "guide and host records",
    tone: "accent",
    icon: <Users size={15} />,
  },
  {
    id: "warnings",
    label: "Warnings",
    value: "1",
    detail: "review threshold",
    tone: "warning",
    icon: <AlertTriangle size={15} />,
  },
];

export const metricGridCompactItems: MetricGridItem[] = [
  {
    id: "provider",
    label: "Provider",
    value: "Bókun",
    detail: "owned by eLitua",
    icon: <BookOpen size={14} />,
  },
  {
    id: "channel",
    label: "Channel",
    value: "Baltic tours",
    detail: "preformatted",
    tone: "info",
    icon: <Link2 size={14} />,
  },
  {
    id: "dispatches",
    label: "Dispatches",
    value: "37",
    detail: "Score activity",
    tone: "success",
    icon: <Bot size={14} />,
  },
];

export const entityFilterTypeOptions: EntityFilterOption[] = [
  { value: "", label: "All types" },
  { value: "guide", label: "Guides" },
  { value: "accommodation", label: "Accommodation" },
  { value: "geo", label: "Places and routes" },
];

export const entityFilterVerificationOptions: EntityFilterOption[] = [
  { value: "", label: "Any verification" },
  { value: "1", label: "Verified" },
  { value: "0", label: "Needs review" },
];

export const entityFilterStatusOptions: EntityFilterOption[] = [
  { value: "", label: "Any status" },
  { value: "1", label: "Enabled" },
  { value: "0", label: "Disabled" },
];

export const entityFilterRegionOptions: EntityFilterOption[] = [
  { value: "", label: "All regions" },
  { value: "vilnius", label: "Vilnius" },
  { value: "kaunas", label: "Kaunas" },
  { value: "klaipeda", label: "Klaipeda" },
  { value: "utena", label: "Utena" },
];

export const entityFilterStats: EntityFilterPanelStat[] = [
  { id: "visible", label: "visible", value: "42" },
  { id: "source", label: "source", value: "87" },
];

export const actorAccessRoleOptions: ActorAccessRoleOption[] = [
  { value: "viewer", label: "viewer" },
  { value: "user", label: "user" },
  { value: "developer", label: "developer" },
  { value: "manager", label: "manager" },
  { value: "admin", label: "admin" },
];

export const actorAccessRows: ActorAccessItem[] = [
  {
    id: "agent-codex-maestro",
    primary: "Codex Maestro",
    secondary: "agent-codex-maestro",
    meta: "codex provider · owns scheduled UI framework nudges",
    interfaceLabel: "Agent",
    status: "Enabled",
    statusTone: "success",
    role: "admin",
    roleOptions: actorAccessRoleOptions,
    grants: [
      {
        id: "score-release",
        label: "Score release",
        checked: true,
        description: "Direct release grant for scope.ayc.io",
      },
      {
        id: "ui-framework-owner",
        label: "UI Framework owner",
        checked: true,
        description: "Can update extraction tasks under the epic",
      },
    ],
  },
  {
    id: "agent-score-worker",
    primary: "Score Worker",
    secondary: "agent-score-worker",
    meta: "host-side runner",
    interfaceLabel: "Agent",
    status: "Capacity gated",
    statusTone: "warning",
    role: "developer",
    roleOptions: actorAccessRoleOptions,
    grants: [
      {
        id: "score-release",
        label: "Score release",
        checked: false,
        description: "Can build but cannot release without a direct grant",
      },
      {
        id: "ui-framework-owner",
        label: "UI Framework owner",
        checked: false,
      },
    ],
  },
  {
    id: "owner",
    primary: "Owner",
    secondary: "dzeiranas@example.com",
    meta: "human admin account",
    interfaceLabel: "Human",
    status: "Enabled",
    statusTone: "success",
    role: "admin",
    roleOptions: actorAccessRoleOptions,
    grants: [
      {
        id: "score-release",
        label: "Score release",
        checked: true,
        saving: true,
        description: "Saving state is rendered by the consuming app",
      },
      {
        id: "ui-framework-owner",
        label: "UI Framework owner",
        checked: true,
      },
    ],
  },
];

export const resourceIndexItems: ResourceIndexItem[] = [
  {
    id: "score",
    title: "score",
    subtitle: "Agentic project control plane",
    description: "Open a project to edit metadata, definition-of-done items and access policy.",
    href: "#resource-index",
    selected: true,
    leading: <Database size={19} />,
    meta: [
      { id: "priority", label: "Priority 100", tone: "info" },
      { id: "status", label: "Enabled", tone: "success" },
      { id: "repo", label: "djufo/score" },
    ],
    moveUpDisabled: true,
  },
  {
    id: "emibs",
    title: "emibs",
    subtitle: "Shared UI and service libraries",
    description: "Library workspace for reusable components, state services, auth helpers and future kits.",
    href: "#resource-index",
    leading: <Wrench size={19} />,
    meta: [
      { id: "priority", label: "Priority 900" },
      { id: "status", label: "Enabled", tone: "success" },
      { id: "repo", label: "djufo/emibs" },
    ],
  },
  {
    id: "elitua-users",
    title: "eLitua users",
    subtitle: "Admin user index",
    description: "The same card grammar can represent user and profile indexes without adopting project ordering.",
    href: "#resource-index",
    leading: <Users size={19} />,
    meta: [
      { id: "count", label: "42 users", tone: "accent" },
      { id: "state", label: "Active", tone: "success" },
    ],
  },
  {
    id: "elitua-profiles",
    title: "eLitua profiles",
    subtitle: "Profile resource index",
    description: "Profile cards keep the routing and data loading local while sharing index density and metadata layout.",
    href: "#resource-index",
    leading: <User size={19} />,
    meta: [
      { id: "count", label: "28 profiles", tone: "accent" },
      { id: "state", label: "Review" },
    ],
    moveDownDisabled: true,
  },
];

export const projectDirectoryItems: ProjectDirectoryItem[] = [
  {
    id: "score",
    key: "score",
    title: "Score",
    description: "Agentic project control plane for epics, stories, executable tasks, and runtime evidence.",
    href: "#project-directory-panel",
    badges: [
      { id: "status", label: "enabled", tone: "success" },
      { id: "priority", label: "p100", tone: "info" },
      { id: "checklist", label: "7 checklist items", tone: "neutral" },
    ],
    footer: "Project loading, sorting, and route ownership stay in Score.",
  },
  {
    id: "emibs",
    key: "emibs",
    title: "EMIBS shared libraries",
    description: "Reusable UI, state, auth, and implementation packages reviewed before product adoption.",
    href: "#project-directory-panel",
    badges: [
      { id: "status", label: "enabled", tone: "success" },
      { id: "priority", label: "p900", tone: "neutral" },
      { id: "checklist", label: "4 checklist items", tone: "neutral" },
    ],
  },
  {
    id: "elitua",
    key: "elitua",
    title: "eLitua",
    description: "Lithuanian tourism marketplace with public discovery, provider profiles, and admin workflows.",
    badges: [
      { id: "status", label: "disabled", tone: "warning" },
      { id: "priority", label: "p0", tone: "neutral" },
      { id: "checklist", label: "5 checklist items", tone: "neutral" },
    ],
    disabled: true,
  },
];

export const relationshipPickerItems: RelationshipPickerItem[] = [
  {
    id: "vilnius",
    label: "Vilnius city and old town",
    checked: true,
    description: "Primary city coverage used by the selected guide profile.",
    href: "#relationship-picker",
    leading: <Landmark size={18} />,
    meta: [
      { id: "region", label: "Region", tone: "info" },
      { id: "verified", label: "Verified", tone: "success" },
    ],
    trailing: "18 routes",
  },
  {
    id: "trakai",
    label: "Trakai castle route",
    checked: true,
    description: "Nearby day-trip coverage with cultural guide availability.",
    href: "#relationship-picker",
    leading: <MapPinned size={18} />,
    meta: [
      { id: "municipality", label: "Municipality" },
      { id: "active", label: "Active", tone: "success" },
    ],
    trailing: "7 routes",
  },
  {
    id: "kaunas",
    label: "Kaunas modernism district",
    checked: false,
    description: "Optional city coverage that can be enabled after license review.",
    href: "#relationship-picker",
    leading: <Building2 size={18} />,
    meta: [
      { id: "city", label: "City", tone: "accent" },
      { id: "review", label: "Needs review", tone: "warning" },
    ],
    trailing: "12 routes",
  },
  {
    id: "curonian-spit",
    label: "Curonian Spit national park",
    checked: false,
    description: "Disabled records remain visible when the consuming app wants review context.",
    disabled: true,
    leading: <Trees size={18} />,
    meta: [
      { id: "park", label: "Protected area", tone: "info" },
      { id: "disabled", label: "Disabled" },
    ],
    trailing: "permit pending",
  },
];

export const operationalDiagnosticMetrics: OperationalDiagnosticMetric[] = [
  {
    id: "score-dbview",
    label: "Score embed",
    value: "APP_STATE",
    detail: "proxied database browser",
    tone: "info",
    icon: <Database size={15} />,
  },
  {
    id: "elitua-db",
    label: "eLitua check",
    value: "success",
    detail: "diagnosis/test-db",
    tone: "success",
    icon: <ShieldCheck size={15} />,
  },
  {
    id: "latency",
    label: "Last run",
    value: "184 ms",
    detail: "app-owned polling",
    icon: <Clock size={15} />,
  },
];

export const operationalDiagnosticDetails: OperationalDiagnosticDetail[] = [
  { id: "source", label: "Source surfaces", value: "Score Database tab + eLitua Test DB page" },
  { id: "embed", label: "Embed target", value: "/dbview/?embed=1&table=APP_STATE" },
  { id: "endpoint", label: "Diagnostic endpoint", value: "/api/v1/diagnosis/test-db" },
  { id: "ownership", label: "Product-owned behavior", value: "Auth, proxying, polling, fetch, query execution and localization" },
];

export const markdownDocumentMeta: MarkdownDocumentMeta[] = [
  { id: "source", label: "Source", value: "Score task document" },
  { id: "task", label: "Task", value: "UI Framework extraction nudge" },
  { id: "format", label: "Format", value: "GitHub-flavored markdown" },
  { id: "ownership", label: "Product-owned", value: "Task fetch, permissions, filename, uploads and workflow actions" },
];

export const filePreviewMeta: FilePreviewMeta[] = [
  { id: "source", label: "Source", value: "Score task attachment" },
  { id: "size", label: "Size", value: "18 KB" },
  { id: "uploaded", label: "Uploaded by", value: "agent-codex-maestro" },
  { id: "ownership", label: "Product-owned", value: "Signed URL, fetch, permission and toast behavior" },
];

export const fileActionListItems: FileActionListItem[] = [
  {
    id: "project-brief",
    filename: "project-brief.md",
    subtitle: "text/markdown",
    kind: "document",
    badges: [
      { id: "markdown", label: "Markdown", tone: "info" },
      { id: "profile", label: "profile", tone: "success" },
    ],
    meta: [
      { id: "size", label: "18 KB" },
      { id: "date", label: "2026-06-30" },
      { id: "owner", label: "agent-codex-maestro" },
    ],
  },
  {
    id: "hero-image",
    filename: "project-hero.png",
    subtitle: "image/png",
    kind: "image",
    badges: [{ id: "image", label: "Image", tone: "success" }],
    meta: [
      { id: "size", label: "1.8 MB" },
      { id: "date", label: "2026-06-29" },
      { id: "owner", label: "designer" },
    ],
  },
  {
    id: "schema-export",
    filename: "schema-readiness.pdf",
    subtitle: "application/pdf",
    kind: "document",
    badges: [{ id: "evidence", label: "Evidence", tone: "accent" }],
    meta: [
      { id: "size", label: "642 KB" },
      { id: "date", label: "2026-06-28" },
      { id: "owner", label: "score-worker" },
    ],
  },
];

export const resourceTransferTargets: ResourceTransferTarget[] = [
  {
    id: "ui-framework",
    label: "UI Framework",
    description: "Shared extraction epic and review evidence.",
    meta: [
      { id: "project", label: "score", tone: "info" },
      { id: "current", label: "current", tone: "success" },
    ],
  },
  {
    id: "score-qa",
    label: "Score QA automation",
    description: "Verification artifacts for build, deploy, and runtime checks.",
    meta: [
      { id: "ready", label: "ready", tone: "success" },
      { id: "files", label: "3 files", tone: "neutral" },
    ],
  },
  {
    id: "elitua-admin",
    label: "eLitua admin workspace",
    description: "Future adoption work for admin media and profile assets.",
    meta: [
      { id: "cross-project", label: "cross-project", tone: "accent" },
      { id: "restricted", label: "restricted", tone: "warning" },
    ],
    disabled: true,
  },
];

export const scoreTaskDocumentMarkdown = `# Extraction Review Notes

This task document uses the same markdown preview pattern that Score renders
inside task detail. The shared component owns only neutral document chrome and
sanitized markdown presentation.

## Definition of Done

- Component, catalog demo, local spec, and extraction notes are present.
- Parser and sanitizer hooks can be replaced by the consuming app.
- Score keeps task loading, generated document content, permissions, and route
  behavior local.

> Product workflows can add comments, transitions, attachments, or review notes
> around this document without those rules entering the shared component.

| Surface | Shared Responsibility | Product Responsibility |
| --- | --- | --- |
| Body | Render sanitized markdown | Generate and persist content |
| Actions | Accept slots | Download filename, toasts, audit |
| State | Loading/error/empty chrome | Fetching, auth, retry policy |

\`\`\`ts
downloadMarkdown("task-281-document", markdown);
\`\`\`
`;

export const mediaAssetStats: MediaAssetStat[] = [
  {
    id: "assets",
    label: "Assets",
    value: "18",
    detail: "task + profile media",
    tone: "info",
  },
  {
    id: "images",
    label: "Images",
    value: "14",
    detail: "maps, profiles, screenshots",
    tone: "success",
  },
  {
    id: "documents",
    label: "Documents",
    value: "4",
    detail: "markdown and policy files",
  },
];

export const mediaAssetItems: MediaAssetItem[] = [
  {
    id: "score-task-map",
    title: "task-detail-map-upload.png",
    subtitle: "Score task attachment",
    description: "Authenticated image attachment displayed inside task detail with product-owned delete behavior.",
    kind: "image",
    previewSrc: demoHeroImage,
    previewAlt: "Lithuanian landscape used as sample task attachment",
    badges: [
      { id: "project", label: "score", tone: "info" },
      { id: "type", label: "image/png" },
    ],
    meta: [
      { id: "size", label: "Size", value: "412 KB" },
      { id: "uploaded", label: "Uploaded", value: "task-268" },
      { id: "visibility", label: "Visibility", value: "authenticated URL" },
    ],
  },
  {
    id: "score-task-markdown",
    title: "acceptance-notes.md",
    subtitle: "Score task document",
    description: "Document attachments use the same card grid while rendering file icons instead of image previews.",
    kind: "document",
    selected: true,
    badges: [
      { id: "project", label: "score", tone: "info" },
      { id: "type", label: "markdown" },
    ],
    meta: [
      { id: "size", label: "Size", value: "18 KB" },
      { id: "uploaded", label: "Uploaded", value: "codex-maestro" },
      { id: "action", label: "Action", value: "open/download slot" },
    ],
  },
  {
    id: "elitua-profile-picture",
    title: "guide-profile-hero.jpg",
    subtitle: "eLitua profile picture",
    description: "Profile picture upload creates file and picture records, then links the media id to profile state.",
    kind: "image",
    previewSrc: demoBrandImage,
    previewAlt: "Guide profile sample image",
    badges: [
      { id: "project", label: "eLitua", tone: "accent" },
      { id: "state", label: "profile media", tone: "success" },
    ],
    meta: [
      { id: "file", label: "File ID", value: "8204" },
      { id: "picture", label: "Picture ID", value: "184" },
      { id: "dimensions", label: "Dimensions", value: "1200 x 800" },
    ],
  },
  {
    id: "elitua-picture-record",
    title: "Picture #197",
    subtitle: "eLitua admin picture record",
    description: "Picture admin lists file id, dimensions and preview state before routing to a product-owned edit page.",
    kind: "file",
    badges: [
      { id: "project", label: "eLitua", tone: "accent" },
      { id: "preview", label: "preview" },
    ],
    meta: [
      { id: "file", label: "File ID", value: "197" },
      { id: "dimensions", label: "Dimensions", value: "1600 x 900" },
      { id: "route", label: "Route", value: "/admin/pictures/197" },
    ],
  },
];

export const agentManagementMetrics: AgentManagementMetric[] = [
  {
    id: "agents",
    label: "Agents",
    value: "4",
    detail: "configured actors",
    tone: "info",
    icon: <Bot size={15} />,
  },
  {
    id: "available",
    label: "Available",
    value: "2",
    detail: "can claim work",
    tone: "success",
    icon: <Activity size={15} />,
  },
  {
    id: "capacity",
    label: "Capacity gated",
    value: "1",
    detail: "usage reset pending",
    tone: "warning",
    icon: <Clock size={15} />,
  },
  {
    id: "runners",
    label: "Runners",
    value: "3",
    detail: "responsibility lanes",
    icon: <Wrench size={15} />,
  },
];

export const agentManagementAgents: AgentManagementAgent[] = [
  {
    id: "agent-codex-maestro",
    displayName: "Codex Maestro",
    purpose: "Senior orchestration, releases and UI Framework extraction nudges",
    role: "admin",
    provider: "codex",
    runnerId: "maestro-runner",
    enabled: true,
    state: "active",
    stateTone: "success",
    healthTone: "running",
    dayCapacity: "76%",
    dayReset: "18:00 UTC",
    weekCapacity: "61%",
    weekReset: "Mon 00:00 UTC",
    minimum: "35%",
    cooldownUntil: "None",
    available: true,
    availableAt: "now",
    releaseProjects: ["score", "emibs"],
  },
  {
    id: "agent-score-worker",
    displayName: "Score Worker",
    purpose: "Deterministic Score board execution via score-job tools",
    role: "developer",
    provider: "llama",
    runnerId: "board-runner",
    enabled: true,
    state: "idle",
    stateTone: "info",
    healthTone: "idle",
    dayCapacity: "52%",
    dayReset: "12:00 UTC",
    weekCapacity: "74%",
    weekReset: "Mon 00:00 UTC",
    minimum: "25%",
    cooldownUntil: "None",
    available: true,
    availableAt: "now",
    releaseProjects: [],
  },
  {
    id: "agent-codex-reviewer",
    displayName: "Codex Reviewer",
    purpose: "Review loop and approval checks",
    role: "manager",
    provider: "codex",
    runnerId: "review-runner",
    enabled: true,
    state: "suspended-usage",
    stateTone: "warning",
    healthTone: "capacity",
    dayCapacity: "8%",
    dayReset: "23:15 UTC",
    weekCapacity: "42%",
    weekReset: "Mon 00:00 UTC",
    minimum: "20%",
    cooldownUntil: "23:15 UTC",
    available: false,
    availableAt: "23:15 UTC",
    releaseProjects: ["score"],
  },
  {
    id: "agent-experimental-google",
    displayName: "Google Gemini Worker",
    purpose: "Disabled candidate provider for future runner lanes",
    role: "developer",
    provider: "google",
    runnerId: "",
    enabled: false,
    state: "disabled",
    stateTone: "neutral",
    healthTone: "disabled",
    dayCapacity: "Unknown",
    weekCapacity: "Unknown",
    minimum: "None",
    cooldownUntil: "None",
    available: false,
    availableAt: "No time reported",
    releaseProjects: [],
  },
];

export const agentManagementRunners: AgentManagementRunner[] = [
  {
    id: "maestro-runner",
    displayName: "Maestro runner",
    responsibilities: "Scheduled audits, extraction nudges, release verification and escalation decisions.",
    enabled: true,
  },
  {
    id: "board-runner",
    displayName: "Board runner",
    responsibilities: "Ready task claims, score-job execution and bounded worker dispatch.",
    enabled: true,
  },
  {
    id: "review-runner",
    displayName: "Review runner",
    responsibilities: "Review-loop checks, stale review escalation and merge-readiness signals.",
    enabled: true,
  },
];

export const subscriptionCapacityMetrics: SubscriptionCapacityMetric[] = [
  {
    id: "subscriptions",
    label: "Subscriptions",
    value: "3",
    detail: "2 active",
    tone: "warning",
    icon: <KeyRound size={15} />,
  },
  {
    id: "exhausted",
    label: "Exhausted",
    value: "1",
    detail: "Capacity gated",
    tone: "warning",
    icon: <AlertTriangle size={15} />,
  },
  {
    id: "errors",
    label: "Reporter errors",
    value: "1",
    detail: "Last check",
    tone: "danger",
    icon: <ShieldCheck size={15} />,
  },
  {
    id: "providers",
    label: "Providers",
    value: "2",
    detail: "codex, claude",
    tone: "neutral",
    icon: <Bot size={15} />,
  },
];

export const subscriptionCapacityRows: SubscriptionCapacityRow[] = [
  {
    id: "codex-primary",
    title: "Codex primary",
    subtitle: "sub-codex-primary",
    provider: "codex",
    status: "Active",
    statusTone: "success",
    statusDetail: "Checked 2026-06-30 07:36 UTC",
    capacity: "78%",
    capacityDetail: "Day 82% - Week 78%",
    reset: "2026-07-01 00:00 UTC",
    resetDetail: "Day 16h - Week 5d",
    agents: [
      { id: "maestro", label: "Codex Maestro", tone: "success" },
      { id: "worker", label: "Codex Worker", tone: "warning" },
    ],
    diagnostics: "No reporter error",
    diagnosticDetail: "shared subscription reporter",
    payload: '{\n  "source": "codex-capacity",\n  "dayCapacity": { "percent": 82 },\n  "weekCapacity": { "percent": 78 }\n}',
  },
  {
    id: "claude-review",
    title: "Claude review pool",
    subtitle: "sub-claude-review",
    provider: "claude",
    status: "Check error",
    statusTone: "danger",
    statusDetail: "Reporter failed 2026-06-30 07:34 UTC",
    capacity: "Unknown",
    capacityDetail: "Day unknown - Week unknown",
    reset: "Unknown",
    resetDetail: "Retry policy stays product-owned",
    agents: [{ id: "reviewer", label: "Reviewer", tone: "warning" }],
    diagnostics: "Reporter timed out",
    diagnosticDetail: "Score owns retry, alerting, and blocking semantics.",
    payload: '{\n  "error": "capacity reporter timeout",\n  "retryAfterSeconds": 300\n}',
  },
  {
    id: "codex-sandbox",
    title: "Codex sandbox",
    subtitle: "sub-codex-sandbox",
    provider: "codex",
    status: "Suspended",
    statusTone: "warning",
    statusDetail: "Manual suspension active",
    capacity: "0%",
    capacityDetail: "Day 0% - Week 31%",
    reset: "2026-06-30 12:00 UTC",
    resetDetail: "Suspension override",
    agents: [],
    diagnostics: "Suspended by admin",
    diagnosticDetail: "Policy and persistence stay in Score.",
  },
];

export const accessibilityAuditNotes: AccessibilityAuditNote[] = [
  {
    id: "semantic-tabs",
    body: "Component review tabs expose labels and keep preview state outside the audit panel.",
  },
  {
    id: "automated-only",
    body: "Automated checks are evidence, not approval; Score keeps manual review and adoption workflow local.",
  },
];

export const accessibilityAuditViolations: AccessibilityAuditViolation[] = [
  {
    id: "color-contrast",
    impact: "serious",
    help: "Elements must meet minimum color contrast ratio thresholds",
    description: "A generated theme preview produced a low-contrast badge inside the inspected canvas.",
    helpUrl: "https://dequeuniversity.com/rules/axe/4.10/color-contrast",
    nodes: [
      {
        target: [".ui-component-review__canvas", ".ui-badge--warning"],
        failureSummary: "Expected contrast ratio at least 4.5:1 for normal text.",
      },
    ],
  },
  {
    id: "button-name",
    impact: "moderate",
    help: "Buttons must have discernible text",
    description: "One icon-only action in the fixture is missing an accessible name.",
    helpUrl: "https://dequeuniversity.com/rules/axe/4.10/button-name",
    nodes: [
      {
        target: [".preview-toolbar button:nth-child(2)"],
        failureSummary: "Add aria-label or visible text supplied by the consuming app.",
      },
    ],
  },
];

export const agentProfileMetrics: AgentProfileMetric[] = [
  {
    id: "state",
    label: "State",
    value: "active",
    detail: "worker reported",
    tone: "success",
    icon: <Activity size={15} />,
  },
  {
    id: "day",
    label: "Day left",
    value: "76%",
    detail: "resets 18:00 UTC",
    tone: "info",
    icon: <Clock size={15} />,
  },
  {
    id: "week",
    label: "Week left",
    value: "61%",
    detail: "resets Monday",
    icon: <CalendarDays size={15} />,
  },
  {
    id: "available",
    label: "Available",
    value: "Yes",
    detail: "can claim UI Framework nudges",
    tone: "success",
    icon: <ShieldCheck size={15} />,
  },
];

export const agentProfileRoleOptions: AgentProfileFieldOption[] = [
  { value: "viewer", label: "viewer" },
  { value: "user", label: "user" },
  { value: "developer", label: "developer" },
  { value: "manager", label: "manager" },
  { value: "admin", label: "admin" },
];

export const agentProfileProviderOptions: AgentProfileFieldOption[] = [
  { value: "codex", label: "codex" },
  { value: "claude", label: "claude" },
  { value: "google", label: "google" },
  { value: "llama", label: "llama" },
  { value: "unassigned", label: "Unspecified" },
];

export const agentProfileGrants: AgentProfileGrant[] = [
  {
    id: "score",
    project: "score",
    allowed: true,
    detail: "Direct release grant for scope.ayc.io.",
  },
  {
    id: "emibs",
    project: "emibs",
    allowed: true,
    detail: "Can publish emibs-ui-lib catalog deployments.",
  },
  {
    id: "elitua",
    project: "elitua",
    allowed: false,
    detail: "No release grant; adoption work is tracked separately.",
  },
];

export const agentProfileFields: AgentProfileField[] = [
  { id: "purpose", label: "Purpose", value: "Senior orchestration, releases and UI Framework extraction nudges." },
  { id: "runner", label: "Runner", value: "maestro-runner", detail: "Scheduled single-flight jobs" },
  { id: "token", label: "Token note", value: "Runtime/provider login is done manually on the host." },
  { id: "status-note", label: "Status note", value: "Single-agent flow; other Codex workers are disabled." },
  { id: "last-seen", label: "Last seen", value: "2026-06-28 02:00 UTC" },
  { id: "created", label: "Created", value: "2026-06-25 07:20 UTC" },
  { id: "updated", label: "Updated", value: "2026-06-28 02:00 UTC" },
];

export const activityDashboardQueues: ActivityDashboardQueueItem[] = [
  { id: "ready", label: "Ready", value: "14", detail: "claimable work", tone: "success" },
  { id: "review", label: "Review", value: "5", detail: "waiting approval", tone: "warning" },
  { id: "stalled", label: "Stalled", value: "2", detail: "lease expired", tone: "danger" },
  { id: "processing", label: "Processing", value: "7", detail: "active leases", tone: "info" },
  { id: "triage", label: "Triage", value: "9", detail: "needs grooming", tone: "accent" },
  { id: "wake", label: "Wake", value: "3", detail: "cooldown done" },
];

export const activityDashboardMetrics: ActivityDashboardMetric[] = [
  { id: "ticks", label: "Ticks", value: "1,842", detail: "worker scheduler", icon: <Clock size={16} /> },
  { id: "claims", label: "Claims", value: "312", detail: "accepted dispatches", tone: "success", icon: <Bot size={16} /> },
  { id: "dispatches", label: "Dispatches", value: "288", detail: "agent runs", tone: "info", icon: <Activity size={16} /> },
  { id: "cooldowns", label: "Cooldowns", value: "18", detail: "capacity holds", tone: "warning", icon: <Database size={16} /> },
];

export const schedulerControlItems: SchedulerControlItem[] = [
  {
    id: "maestro-board-nudge",
    title: "Maestro board nudge",
    description: "Completes one actionable Score board unit per run.",
    enabled: true,
    schedule: "* * * * *",
    command: "agents/bin/score-scheduler run maestro-board-nudge",
    runner: "maestro-runner",
    workflow: "score-board",
    updatedAt: "Jun 28, 2026 03:48 UTC",
    logPath: "/engineering/local/logs/maestro-board-nudge.log",
    lockPath: "/engineering/local/run/maestro-board-nudge.lock",
    tags: ["maestro", "score", "single-flight"],
  },
  {
    id: "maestro-ui-framework-extract",
    title: "UI Framework extraction nudge",
    description: "Extracts one review-ready shared UI component or layout.",
    enabled: true,
    schedule: "*/3 * * * *",
    command: "agents/bin/score-scheduler run maestro-ui-framework-extract",
    runner: "maestro-runner",
    workflow: "ui-framework",
    updatedAt: "Jun 28, 2026 04:15 UTC",
    logPath: "/engineering/local/logs/maestro-ui-framework-extract.log",
    lockPath: "/engineering/local/run/maestro-ui-framework-extract.lock",
    tags: ["ui-lib", "emibs", "extraction"],
  },
  {
    id: "branch-keeper",
    title: "Branch keeper",
    description: "Audits merged task branches and escalates unique commits.",
    enabled: false,
    schedule: "17 * * * *",
    command: "agents/bin/score-scheduler run branch-keeper",
    runner: "ops-runner",
    workflow: "repo-hygiene",
    updatedAt: "Jun 27, 2026 21:10 UTC",
    logPath: "/engineering/local/logs/branch-keeper.log",
    lockPath: "/engineering/local/run/branch-keeper.lock",
    tags: ["git", "hygiene"],
  },
];

export const processRunHistoryItems: ProcessRunHistoryItem[] = [
  {
    id: "run-ui-framework-20260628-041500",
    title: "UI Framework extraction nudge",
    startedAt: "Jun 28, 2026 04:15 UTC",
    endedAt: "Jun 28, 2026 04:17 UTC",
    duration: "2m 08s",
    exitCode: 0,
    command: "agents/bin/score-scheduler run maestro-ui-framework-extract",
    summary: "Catalog component, demo, notes, Score follow-up and deploy verification completed.",
    meta: [
      { id: "scheduler", label: "Scheduler", value: "maestro-ui-framework-extract" },
      { id: "runner", label: "Runner", value: "maestro-runner" },
      { id: "log", label: "Log", value: "/engineering/local/logs/maestro-ui-framework-extract.log" },
    ],
  },
  {
    id: "run-board-nudge-20260628-041600",
    title: "Maestro board nudge",
    startedAt: "Jun 28, 2026 04:16 UTC",
    exitCode: null,
    status: "running",
    statusTone: "info",
    command: "agents/bin/score-scheduler run maestro-board-nudge",
    summary: "Claimed one ready task and is waiting for worker completion.",
    meta: [
      { id: "scheduler", label: "Scheduler", value: "maestro-board-nudge" },
      { id: "lock", label: "Lock", value: "/engineering/local/run/maestro-board-nudge.lock" },
    ],
  },
  {
    id: "run-branch-keeper-20260628-030000",
    title: "Branch keeper",
    startedAt: "Jun 28, 2026 03:00 UTC",
    endedAt: "Jun 28, 2026 03:01 UTC",
    duration: "51s",
    exitCode: 2,
    command: "agents/bin/score-scheduler run branch-keeper",
    summary: "Unique branch commits require Maestro review before cleanup.",
    output: "branch-keeper: escalated 1 stale branch with unique commits",
    meta: [
      { id: "scheduler", label: "Scheduler", value: "branch-keeper" },
      { id: "workflow", label: "Workflow", value: "repo-hygiene" },
    ],
  },
];

export const activityDashboardItems: ActivityDashboardFeedItem[] = [
  {
    id: "task-240",
    title: "Extract ActivityDashboard into emibs-ui-lib",
    href: "#live-activity",
    kind: "story",
    kindTone: "info",
    status: "done",
    statusTone: "success",
    project: "score",
    time: "now",
    description: "Catalog component, demo, spec and extraction note are ready for review.",
    icon: <Activity size={16} />,
  },
  {
    id: "task-239",
    title: "Refactor eLitua cookie consent to adopt CookieConsentBanner",
    href: "#cookie-consent",
    kind: "task",
    status: "ready",
    statusTone: "warning",
    project: "elitua",
    time: "12m ago",
    icon: <Cookie size={16} />,
  },
  {
    id: "task-215",
    title: "Refactor Score Maestro chat to adopt CommandConsole",
    href: "#command-console",
    kind: "task",
    status: "ready",
    statusTone: "warning",
    project: "score",
    time: "2h ago",
    icon: <TerminalSquare size={16} />,
  },
  {
    id: "task-206",
    title: "UI Framework",
    href: "#extractions",
    kind: "epic",
    kindTone: "accent",
    status: "created",
    project: "score",
    time: "updated today",
    meta: "36 extraction cycles",
    icon: <Columns3 size={16} />,
  },
];

export const accountProfileBadges: AccountProfileBadge[] = [
  { id: "verified", label: "email verified", tone: "success" },
  { id: "provider", label: "guide profile", tone: "accent" },
  { id: "autosave", label: "autosave ready", tone: "info" },
];

export const accountProfileStats: AccountProfileStat[] = [
  {
    id: "profile",
    label: "Profile completeness",
    value: "82%",
    detail: "identity, contact and languages",
    icon: <User size={15} />,
    tone: "success",
  },
  {
    id: "notify",
    label: "Email preference",
    value: "Daily",
    detail: "Score notification cadence",
    icon: <Bell size={15} />,
    tone: "info",
  },
  {
    id: "license",
    label: "Guide license",
    value: "LT-GD-001234",
    detail: "verified provider signal",
    icon: <Award size={15} />,
    tone: "accent",
  },
];

export const accountProfileLinks: AccountProfileLink[] = [
  {
    id: "password",
    label: "Change password",
    href: "#account-profile",
    icon: <KeyRound size={15} />,
  },
  {
    id: "sessions",
    label: "Manage sessions",
    href: "#account-sessions",
    icon: <ShieldCheck size={15} />,
  },
  {
    id: "public-profile",
    label: "View public profile",
    href: "#public-profile",
    icon: <Share2 size={15} />,
  },
];

export const accountSessions: AccountSessionItem[] = [
  {
    id: "current-desktop",
    title: "Chrome on Linux",
    description: "scope.ayc.io operator workspace from 127.0.0.1",
    device: "desktop",
    current: true,
    startedAt: "Started 27 Jun 2026, 20:12",
    expiresAt: "Expires in 28 days",
    meta: ["Vilnius account region"],
  },
  {
    id: "traveler-phone",
    title: "Safari on iPhone",
    description: "Traveler account session from mobile web",
    device: "mobile",
    startedAt: "Started 26 Jun 2026, 18:45",
    expiresAt: "Expires in 13 days",
    status: "trusted",
    statusTone: "success",
  },
  {
    id: "admin-tablet",
    title: "Edge on tablet",
    description: "Admin account session with stale refresh metadata",
    device: "tablet",
    startedAt: "Started 21 Jun 2026, 09:02",
    expiresAt: "Expires in 2 days",
    status: "review",
    statusTone: "warning",
  },
];

export const editorialArticleAuthor: EditorialArticleAuthor = {
  name: "Marta Kazlauskiene",
  role: "Senior travel writer",
  avatar: "MK",
  bio: "Travel writer and Lithuania enthusiast. She turns local expertise, route data and field notes into practical visitor guides.",
};

export const editorialArticleMeta: EditorialArticleMetaItem[] = [
  { id: "read-time", label: "15 min read", icon: <Clock size={14} /> },
  { id: "date", label: "10 February 2026" },
];

export const editorialArticleToc: EditorialArticleTocEntry[] = [
  { id: "why-visit", label: "Why visit now", href: "#why-visit", level: 2 },
  { id: "vilnius", label: "Vilnius", href: "#vilnius", level: 2 },
  { id: "trakai", label: "Trakai", href: "#trakai", level: 2 },
  { id: "practical", label: "Practical notes", href: "#practical", level: 2 },
];

export const tableOfContentsNavItems: TableOfContentsNavItem[] = [
  { id: "overview", label: "Overview", href: "#overview", level: 2, meta: "Intro" },
  { id: "why-visit", label: "Why visit Lithuania now", href: "#why-visit", level: 2 },
  { id: "seasonal-routes", label: "Seasonal routes", href: "#seasonal-routes", level: 3 },
  { id: "itinerary", label: "Sample itinerary", href: "#itinerary", level: 2 },
  { id: "local-guides", label: "Local guide context", href: "#local-guides", level: 3 },
  { id: "booking-notes", label: "Booking notes", href: "#booking-notes", level: 2 },
];

export const editorialArticleSections: EditorialArticleSection[] = [
  {
    id: "intro",
    type: "p",
    text: "Lithuania rewards visitors who want compact distances, strong local context and nature close to city routes. The article shell keeps long-form destination guidance readable without binding the component to one CMS.",
  },
  {
    id: "why-visit",
    type: "h2",
    text: "Why 2026 is the year to visit Lithuania",
  },
  {
    id: "why-visit-copy",
    type: "p",
    text: "New direct routes, stronger accommodation coverage and better mapped tourism records make it easier to plan a practical trip across Vilnius, Kaunas, Trakai, the coast and national parks.",
  },
  {
    id: "quote",
    type: "quote",
    text: "Lithuania is Europe's best-kept secret for travelers who want rich culture without heavy crowds.",
    attribution: "eLitua editorial desk",
  },
  {
    id: "vilnius",
    type: "h2",
    text: "Vilnius: the capital that rewards slow discovery",
  },
  {
    id: "vilnius-copy",
    type: "p",
    text: "The Old Town, Uzupis, market routes and guide-led history walks make Vilnius a natural starting point for a public tourism article, itinerary or guide profile story.",
  },
  {
    id: "guide-cta",
    type: "cta",
    title: "Explore Vilnius with a local guide",
    description: "Use the consuming app's route and booking flow while the article shell renders a consistent inline action row.",
    href: "#entity-browser",
    label: "View guides",
    icon: <ArrowRight size={15} />,
  },
  {
    id: "trakai",
    type: "h2",
    text: "Trakai and the lake routes",
  },
  {
    id: "trakai-list",
    type: "ul",
    items: [
      "Connect castle visits with lakeside stays and day-trip routes.",
      "Show nearby guides, places and transport notes as structured article sections.",
      "Keep subscription prompts, analytics and route behavior outside the UI shell.",
    ],
  },
  {
    id: "practical",
    type: "h2",
    text: "Practical notes",
  },
  {
    id: "practical-copy",
    type: "p",
    text: "The component accepts structured sections, tags, share actions and related articles so product teams can map local article data without copying layout code.",
  },
];

export const editorialArticleTags = ["Lithuania", "Destination guide", "Vilnius", "Trakai", "Itinerary"];

export const editorialArticleShareActions: EditorialArticleShareAction[] = [
  { id: "share", label: "Share", icon: <Share2 size={14} />, onClick: () => undefined },
  { id: "facebook", label: "Facebook", icon: <Facebook size={14} />, href: "#editorial-article" },
  { id: "copy", label: "Copy link", icon: <BookOpen size={14} />, onClick: () => undefined },
];

export const editorialArticleRelated: EditorialArticleRelatedItem[] = [
  {
    id: "food",
    title: "Best Lithuanian food to try",
    href: "#editorial-article",
    category: "Food and culture",
    meta: "8 min",
    imageSrc: demoImage("lake", 400, 260),
    imageAlt: "Regional table setting",
  },
  {
    id: "forest",
    title: "Forest bathing routes across Lithuania",
    href: "#editorial-article",
    category: "Nature",
    meta: "6 min",
    imageSrc: demoImage("forest", 400, 260),
    imageAlt: "Forest trail",
  },
  {
    id: "b2b",
    title: "Tourism data signals for operators",
    href: "#editorial-article",
    category: "B2B insights",
    meta: "11 min",
    fallback: <Database size={26} />,
  },
];

export const editorialListingCategories: EditorialListingCategory[] = [
  { id: "all", label: "All", count: "6" },
  { id: "destinations", label: "Destinations", count: "2" },
  { id: "itineraries", label: "Itineraries", count: "2" },
  { id: "culture", label: "Food and culture", count: "1" },
  { id: "b2b", label: "B2B insights", count: "1" },
];

export const editorialListingFeatured: EditorialListingArticle & { categoryId: string } = {
  id: "ultimate-guide",
  categoryId: "destinations",
  title: "Things to Do in Lithuania 2026: The Ultimate Guide",
  subtitle: "A practical route from Vilnius to the coast, with castles, national parks, food stops and local context.",
  excerpt:
    "Use the listing shell to lead a content hub with one high-signal story before visitors choose a category or open the article grid.",
  href: "#editorial-article",
  category: "Destination guides",
  imageSrc: demoImage("city", 1200, 520),
  imageAlt: "Vilnius old town rooftops",
  author: { name: "Marta Kazlauskiene", avatar: "MK" },
  meta: [
    { id: "read-time", label: "15 min read", icon: <Clock size={14} /> },
    { id: "date", label: "10 February 2026" },
  ],
};

export const editorialListingArticles: Array<EditorialListingArticle & { categoryId: string }> = [
  {
    id: "cycling",
    categoryId: "itineraries",
    title: "A cyclist's guide to Lithuania's lake routes",
    excerpt: "Plan calmer routes through Aukstaitija, Trakai and riverside towns with realistic day distances.",
    href: "#editorial-listing",
    category: "Itineraries",
    imageSrc: demoImage("mountain", 800, 500),
    imageAlt: "Forest road through a hilly landscape",
    author: { name: "Ruta Travels", avatar: "RT" },
    meta: [{ id: "read-time", label: "9 min", icon: <Bike size={14} /> }],
  },
  {
    id: "food",
    categoryId: "culture",
    title: "Lithuanian food worth planning a day around",
    excerpt: "From market halls to regional kitchens, map food stops into a route without losing the main destination.",
    href: "#editorial-listing",
    category: "Food and culture",
    imageSrc: demoImage("lake", 800, 500),
    imageAlt: "Regional table setting",
    author: { name: "eLitua desk", avatar: "EL" },
    meta: [{ id: "read-time", label: "8 min", icon: <Clock size={14} /> }],
  },
  {
    id: "forest",
    categoryId: "destinations",
    title: "Forest bathing and quiet nature stays",
    excerpt: "A compact guide to forest routes, local stays and places where a slower itinerary makes sense.",
    href: "#editorial-listing",
    category: "Destinations",
    imageSrc: demoImage("forest", 800, 500),
    imageAlt: "Forest trail",
    author: { name: "Marta Kazlauskiene", avatar: "MK" },
    meta: [{ id: "read-time", label: "6 min", icon: <Trees size={14} /> }],
  },
  {
    id: "operator-signals",
    categoryId: "b2b",
    title: "Tourism data signals operators should watch",
    excerpt: "Turn mapped visitor intent, guide coverage and booking gaps into operational priorities.",
    href: "#editorial-listing",
    category: "B2B insights",
    fallback: <Database size={30} />,
    author: { name: "Operator notes", avatar: "ON" },
    meta: [{ id: "read-time", label: "11 min", icon: <Database size={14} /> }],
  },
  {
    id: "weekend",
    categoryId: "itineraries",
    title: "A first weekend in Vilnius and Trakai",
    excerpt: "A simple two-day path for travelers who want history, food, water and strong local guide options.",
    href: "#editorial-listing",
    category: "Itineraries",
    imageSrc: demoImage("coast", 800, 500),
    imageAlt: "Historic European castle by water",
    author: { name: "Ruta Travels", avatar: "RT" },
    meta: [{ id: "read-time", label: "7 min", icon: <MapPinned size={14} /> }],
  },
];

export const legalDocumentMeta: LegalDocumentMetaItem[] = [
  { id: "updated", label: "Last updated 13 May 2026", icon: <CalendarDays size={14} /> },
  { id: "company", label: "Controller: eLitua MB", icon: <ShieldCheck size={14} /> },
];

export const legalDocumentBlocks: LegalDocumentBlock[] = [
  {
    id: "general",
    type: "h2",
    text: "1. General provisions",
  },
  {
    id: "general-copy",
    type: "p",
    text: (
      <>
        This policy shell is designed for public legal documents such as privacy policies, terms of service,
        marketplace rules, provider agreements, and cookie notices.
      </>
    ),
  },
  {
    id: "data",
    type: "h2",
    text: "2. Information covered by this document",
  },
  {
    id: "data-provided",
    type: "h3",
    text: "2.1. Information supplied by the user",
  },
  {
    id: "data-list",
    type: "ul",
    items: [
      <>
        <strong>Account details:</strong> name, email address, password state, profile settings, and communication
        preferences.
      </>,
      <>
        <strong>Profile content:</strong> public descriptions, guide credentials, accommodation records, route notes, and
        uploaded media.
      </>,
      <>
        <strong>Messages:</strong> support requests and correspondence sent through product-owned contact channels.
      </>,
    ],
  },
  {
    id: "technical",
    type: "h3",
    text: "2.2. Technical information",
  },
  {
    id: "technical-copy",
    type: "p",
    text: "Technical logs, session records, browser details, and security events can be described without binding the document shell to a storage model or analytics provider.",
  },
  {
    id: "rights",
    type: "h2",
    text: "3. User rights and requests",
  },
  {
    id: "rights-list",
    type: "ol",
    items: [
      "Request access to personal data held by the product.",
      "Ask for correction of inaccurate profile or account information.",
      "Request deletion or restriction when applicable law allows it.",
      "Withdraw optional consent without affecting earlier lawful processing.",
    ],
  },
  {
    id: "third-parties",
    type: "h2",
    text: "4. Third-party services",
  },
  {
    id: "third-parties-copy",
    type: "p",
    text: (
      <>
        Maps, payments, provider integrations, identity providers, analytics, and email delivery remain consuming-app
        responsibilities. The document shell only renders the reviewed copy and links.
      </>
    ),
  },
  {
    id: "request-callout",
    type: "callout",
    callout: {
      title: "Product-owned workflow",
      tone: "warning",
      children:
        "Consent capture, cookie preference state, acceptance checkboxes, version comparison, and export/print behavior stay outside the shared UI component.",
    },
  },
  {
    id: "updates",
    type: "h2",
    text: "5. Document updates",
  },
  {
    id: "updates-copy",
    type: "p",
    text: "The component supports revision metadata and structured clauses, while the consuming app owns notification rules, historical versions, and jurisdiction-specific text.",
  },
];

export const publicProfileBadges: PublicProfileBadge[] = [
  { id: "verified", label: "Verified identity", icon: <ShieldCheck size={16} />, tone: "success" },
  { id: "license", label: "LT-GD-001284", icon: <Award size={16} />, tone: "info" },
  { id: "local", label: "Local expert", icon: <MapPinned size={16} />, tone: "accent" },
];

export const publicProfileContactActions: PublicProfileAction[] = [
  { id: "phone", label: "+370 600 00124", href: "tel:+37060000124", icon: <Phone size={16} /> },
  { id: "email", label: "austeja@example.lt", href: "mailto:austeja@example.lt", icon: <Mail size={16} /> },
  { id: "website", label: "Website", href: "https://example.lt", icon: <Globe2 size={16} />, external: true },
];

export const publicProfileStats: PublicProfileStat[] = [
  { id: "languages", label: "Languages", value: "4", detail: "English, Lithuanian, Polish, German", icon: <Languages size={17} /> },
  { id: "routes", label: "Covered routes", value: "12", detail: "Vilnius, Trakai and forest day trips", icon: <MapPinned size={17} /> },
  { id: "since", label: "Licensed since", value: "2018", detail: "Active guide profile", icon: <ShieldCheck size={17} /> },
];

export const publicProfilePanels: PublicProfilePanel[] = [
  {
    id: "languages",
    title: "Languages",
    description: "A compact tag panel for visitor-facing profile attributes.",
    icon: <Languages size={18} />,
    tags: ["English", "Lithuanian", "Polish", "German"],
  },
  {
    id: "routes",
    title: "Covered routes",
    description: "Public profile cards can list regions, routes, venues or service areas.",
    icon: <MapPinned size={18} />,
    tags: ["Vilnius Old Town", "Trakai castle", "Aukstaitija forests", "Kaunas modernism"],
  },
  {
    id: "credentials",
    title: "Credentials",
    icon: <Award size={18} />,
    details: [
      { id: "license", label: "License", value: "LT-GD-001284" },
      { id: "country", label: "Country", value: "LT" },
      { id: "status", label: "Status", value: "Identity verified" },
    ],
  },
  {
    id: "introduction",
    title: "Introduction",
    description: "Freeform body content lets products add bios, policies or provider notes.",
    icon: <Users size={18} />,
    children: (
      <p>
        Austeja builds practical walking routes with local context, food stops and calm pacing for first-time visitors
        who want Lithuania to feel navigable from day one.
      </p>
    ),
  },
];

export const scoreAuthProviders: AuthProviderAction[] = [
  { id: "score-google", label: "Continue with Google", icon: <ShieldCheck size={19} />, featured: true },
];

export const elituaAuthProviders: AuthProviderAction[] = [
  { id: "elitua-google", label: "Continue with Google", icon: <ShieldCheck size={19} />, featured: true },
  { id: "elitua-microsoft", label: "Microsoft", icon: <Building2 size={18} /> },
  { id: "elitua-facebook", label: "Facebook", icon: <Facebook size={18} /> },
  { id: "elitua-account", label: "Local account", icon: <User size={18} /> },
];

export const paymentAccountStats: PaymentAccountStat[] = [
  {
    id: "earned",
    label: "Paid earnings",
    value: "1,284.00 EUR",
    detail: "settled provider payouts",
    tone: "success",
    icon: <CircleDollarSign size={15} />,
  },
  {
    id: "pending",
    label: "Pending",
    value: "342.50 EUR",
    detail: "processing this week",
    tone: "warning",
    icon: <Landmark size={15} />,
  },
  {
    id: "methods",
    label: "Methods",
    value: "2",
    detail: "default card configured",
    tone: "info",
    icon: <WalletCards size={15} />,
  },
];

export const integrationSetupMetrics: IntegrationSetupMetric[] = [
  {
    id: "status",
    label: "Status",
    value: "Active",
    detail: "credentials accepted",
    tone: "success",
    icon: <PlugZap size={15} />,
  },
  {
    id: "channel",
    label: "Channel",
    value: "Baltic tours",
    detail: "B2B reseller feed",
    tone: "info",
    icon: <Link2 size={15} />,
  },
  {
    id: "sync",
    label: "Last sync",
    value: "12m ago",
    detail: "availability refreshed",
    icon: <Clock size={15} />,
  },
  {
    id: "provider",
    label: "Provider",
    value: "Bokun",
    detail: "tour operator software",
    icon: <ShieldCheck size={15} />,
  },
];

export const paymentMethods: PaymentMethodItem[] = [
  {
    id: "visa",
    brand: "Visa",
    maskedNumber: "**** 4242",
    expiry: "04/2028",
    isDefault: true,
    meta: "Traveler checkout",
  },
  {
    id: "mastercard",
    brand: "Mastercard",
    maskedNumber: "**** 1881",
    expiry: "11/2027",
    meta: "Backup method",
  },
];

export const paymentHistoryRows: PaymentLedgerRow[] = [
  {
    id: "pay-1",
    date: "2026-06-18",
    description: "Vilnius guide booking deposit",
    detail: "Payment intent succeeded",
    amount: "84.00 EUR",
    status: "Completed",
    statusTone: "success",
  },
  {
    id: "pay-2",
    date: "2026-06-21",
    description: "Curonian coast stay reservation",
    detail: "Awaiting provider confirmation",
    amount: "240.00 EUR",
    status: "Pending",
    statusTone: "warning",
  },
  {
    id: "pay-3",
    date: "2026-06-24",
    description: "Bike route planner",
    detail: "Refund requested by traveler",
    amount: "35.00 EUR",
    status: "Refunded",
    statusTone: "info",
  },
];

export const payoutRows: PaymentLedgerRow[] = [
  {
    id: "payout-1",
    date: "2026-06-20",
    description: "Guide provider payout",
    detail: "Destination account verified",
    amount: "320.00 EUR",
    status: "Paid",
    statusTone: "success",
  },
  {
    id: "payout-2",
    date: "2026-06-26",
    description: "Accommodation provider payout",
    detail: "Bank transfer processing",
    amount: "342.50 EUR",
    status: "Processing",
    statusTone: "info",
  },
];

export const commandConsoleSessions: CommandConsoleSession[] = [
  { id: "framework", title: "UI Framework extraction", meta: "Updated 5m ago", active: true },
  { id: "release", title: "Release gate review", meta: "Updated 42m ago" },
  { id: "ops", title: "Daily operator summary", meta: "Updated 2h ago" },
];

export const commandConsoleMessages: CommandConsoleMessage[] = [
  {
    id: "m1",
    role: "user",
    body: "Extract the next reusable Score UI pattern into emibs-ui-lib.",
    meta: "agent-codex-maestro",
  },
  {
    id: "m2",
    role: "assistant",
    body: "Queued Score task #312. Candidate selected: Maestro command console chrome with session rail, transcript, and prompt composer.",
    href: "#command-console",
    hrefLabel: "task-312",
  },
  {
    id: "m3",
    role: "system",
    body: "Build passed. Catalog deployment verified at ui-lib.ayc.io.",
  },
];

export const mapViewportStats: MapViewportStat[] = [
  { id: "total", label: "Total", value: "9,314" },
  { id: "with-coordinates", label: "With coords", value: "8,901" },
  { id: "without-coordinates", label: "Missing coords", value: "413" },
];

export const mapViewportMarkers: MapViewportMarker[] = [
  { id: "vilnius", label: "Vilnius", x: 55, y: 38, selected: true },
  { id: "trakai", label: "Trakai", x: 43, y: 49 },
  { id: "kaunas", label: "Kaunas", x: 31, y: 44 },
  { id: "klaipeda", label: "Klaipeda", x: 14, y: 58 },
];

export const mapInfoCardBadges: MapInfoCardBadge[] = [
  { id: "selected", label: "selected", tone: "accent" },
  { id: "verified", label: "verified", tone: "success" },
];

export const mapInfoCardRows: MapInfoCardRow[] = [
  { id: "record", label: "Record", value: "geo-1842" },
  { id: "coordinates", label: "Coordinates", value: "54.6872, 25.2797", icon: <MapPinned size={13} /> },
  { id: "nearby-guides", label: "Guides", value: "18 nearby" },
  { id: "status", label: "Geo status", value: "confirmed" },
];

export const portalLandingStats: PortalLandingStat[] = [
  { id: "objects", value: "9,300+", label: "tourism objects" },
  { id: "coverage", value: "All LT", label: "guide coverage" },
  { id: "planner", value: "AI", label: "route planning" },
];

export const portalLandingHighlights: PortalLandingStat[] = [
  { id: "stays", value: "Where to stay", label: "Hotels, homesteads, apartments and campsites." },
  { id: "explore", value: "How to explore", label: "Guides, routes, maps and itinerary tools." },
];

export const portalLandingIntents: PortalLandingIntent[] = [
  {
    id: "weekend",
    title: "Weekend escape",
    description: "Forests, lakes, old towns and slow routes for a short Lithuania break.",
    href: "#entity-browser",
    icon: <Trees size={22} />,
  },
  {
    id: "cycling",
    title: "Cyclist routes",
    description: "Build a route around verified stays, campsites and mapped places.",
    href: "#explorer-workspace",
    icon: <Bike size={22} />,
  },
  {
    id: "guides",
    title: "Licensed guides",
    description: "Find local experts by region, language and travel style.",
    href: "#record-detail",
    icon: <Users size={22} />,
  },
  {
    id: "ai",
    title: "AI itinerary",
    description: "Turn dates, budget and interests into a practical trip plan.",
    href: "#portal-landing",
    icon: <BrainCircuit size={22} />,
  },
];

export const portalLandingFeatures: PortalLandingFeature[] = [
  {
    id: "coast",
    imageSrc: demoImage("dusk", 900, 560),
    imageAlt: "Curonian coast dunes and pine forest",
    meta: "Curonian coast",
    title: "Dunes, pine forests and Baltic air",
    description: "Start from the coast and connect stays, guides and nature stops into one route.",
    href: "#portal-landing",
  },
  {
    id: "vilnius",
    imageSrc: demoImage("city", 900, 560),
    imageAlt: "Vilnius old town rooftops",
    meta: "Vilnius",
    title: "Old town discovery with local context",
    description: "Explore historic places with verified guides and nearby accommodation options.",
    href: "#portal-landing",
  },
  {
    id: "lakes",
    imageSrc: demoImage("meadow", 900, 560),
    imageAlt: "Lake country forest and water",
    meta: "Lake country",
    title: "Water, forests and quiet stays",
    description: "Plan slower nature trips around lakes, camping points and family-friendly routes.",
    href: "#portal-landing",
  },
  {
    id: "culture",
    imageSrc: demoImage("coast", 900, 560),
    imageAlt: "Regional food and culture table",
    meta: "Food and culture",
    title: "Taste Lithuania by region",
    description: "Use planning tools to connect food stops, towns, stays and guide-led experiences.",
    href: "#portal-landing",
  },
];

export const portalLandingPlanner: PortalLandingPlanner = {
  label: (
    <>
      <Sparkles size={14} /> AI tourism
    </>
  ),
  title: "Build a trip from scattered data into one clear plan.",
  description: "Connect destinations, guide knowledge, accommodation and travel intent into structured day-by-day routes.",
  prompt: (
    <>
      <Search size={18} /> 3 days · family · forest · 100 EUR/day
    </>
  ),
  chips: ["Nature", "Culture", "Cycling", "Wellness"],
};

export const portalInfoStats: PortalInfoStat[] = [
  {
    id: "objects",
    value: "9,300+",
    label: "tourism objects",
    description: "Places, stays, camp sites and guide records in one portal.",
    icon: <MapPinned size={20} />,
  },
  {
    id: "years",
    value: "9",
    label: "years experience",
    description: "Local tourism data curation and platform operations.",
    icon: <Award size={20} />,
  },
  {
    id: "map",
    value: "1",
    label: "national map",
    description: "A single discovery surface for Lithuanian travel planning.",
    icon: <Landmark size={20} />,
  },
  {
    id: "ai",
    value: "AI",
    label: "assistant",
    description: "Trip planning support layered onto structured portal data.",
    icon: <BrainCircuit size={20} />,
  },
];

export const portalInfoSections: PortalInfoSection[] = [
  {
    id: "intro",
    paragraphs: [
      <>
        Public information pages explain how a portal combines tourism data, accommodation,
        guide knowledge and planning tools without turning the route into a blog article.
      </>,
      <>
        The shared component keeps the content readable while the consuming product owns localized copy,
        media choices, analytics and external-link policy.
      </>,
    ],
  },
  {
    id: "future",
    title: "Future travel planning",
    tone: "band",
    paragraphs: [
      <>
        A portal About route often needs to explain product direction, not just display marketing cards.
        This section supports longer strategic copy with enough rhythm for translated content.
      </>,
    ],
  },
  {
    id: "business",
    title: "Built for local travel businesses",
    paragraphs: [
      <>
        Operators, guides and destination owners need a clear explanation of how portal participation works.
      </>,
    ],
    items: [
      <>
        <strong>Structured visibility</strong> - profile, map and content data can be surfaced together.
      </>,
      <>
        <strong>Route context</strong> - stays, guides and places can support traveler decisions together.
      </>,
      <>
        <strong>Practical links</strong> - video, social and contact actions remain product-owned slots.
      </>,
    ],
    actions: (
      <a className="ui-portal-info__inline-link" href="#portal-info">
        <Link2 size={15} />
        Product-owned action
      </a>
    ),
  },
];

export const portalInfoAuthor: PortalInfoAuthor = {
  image: {
    src: demoBrandImage,
    alt: "Founder portrait",
  },
  eyebrow: "Founder note",
  name: "Valdemaras Stempkauskas",
  href: "#portal-info",
  title: "eLitua founder and Lithuanian tourism platform operator",
  description:
    "Founder details, social links, contact preferences, localization and organization schema remain in the consuming product.",
};

export const portalNavItems: PortalHeaderNavItem[] = [
  { id: "home", label: "Home", href: "#portal-header", icon: <Home size={15} />, active: true },
  { id: "stays", label: "Stays", href: "#entity-browser", icon: <Building2 size={15} /> },
  { id: "guides", label: "Guides", href: "#entity-browser", icon: <Users size={15} /> },
  { id: "places", label: "Places", href: "#explorer-workspace", icon: <MapIcon size={15} /> },
  { id: "blog", label: "Blog", href: "#portal-header", icon: <Newspaper size={15} /> },
  { id: "about", label: "About", href: "#portal-header", icon: <Info size={15} /> },
];

export const navigationMenuHeaderItems: NavigationMenuItem[] = [
  { id: "home", label: "Home", href: "#navigation-menu", icon: <Home size={16} />, active: true },
  { id: "stays", label: "Stays", href: "#entity-browser", icon: <Building2 size={16} /> },
  { id: "guides", label: "Guides", href: "#entity-browser", icon: <Users size={16} /> },
  { id: "places", label: "Places", href: "#explorer-workspace", icon: <MapIcon size={16} /> },
  { id: "blog", label: "Blog", href: "#editorial-listing", icon: <Newspaper size={16} /> },
];

export const navigationMenuGroups: NavigationMenuGroup[] = [
  {
    id: "discover",
    title: "Discover",
    description: "Public routes and entity browsers",
    items: [
      {
        id: "accommodations",
        label: "Accommodations",
        description: "Stays, hotels and rural homes",
        href: "#entity-browser",
        icon: <Building2 size={18} />,
        meta: "87",
      },
      {
        id: "local-guides",
        label: "Local guides",
        description: "Licensed operators and route hosts",
        href: "#public-profile",
        icon: <Users size={18} />,
        badge: "new",
      },
      {
        id: "places",
        label: "Places and routes",
        description: "Mapped points of interest",
        href: "#explorer-workspace",
        icon: <MapIcon size={18} />,
        active: true,
      },
    ],
  },
  {
    id: "traveler",
    title: "Traveler tools",
    description: "Account-aware links can be filtered before rendering",
    items: [
      {
        id: "favorites",
        label: "Favorites",
        description: "Saved entities and planned routes",
        href: "#navigation-menu",
        icon: <Heart size={18} />,
      },
      {
        id: "bookings",
        label: "Bookings",
        description: "Upcoming route reservations",
        href: "#navigation-menu",
        icon: <CalendarDays size={18} />,
        disabled: true,
      },
      {
        id: "contact",
        label: "Contact eLitua",
        description: "External mail route",
        href: "mailto:info@elitua.lt",
        icon: <Mail size={18} />,
        external: true,
      },
    ],
  },
  {
    id: "admin",
    title: "Admin",
    description: "Role-gated records stay product-owned",
    items: [
      {
        id: "admin-accommodations",
        label: "Manage accommodations",
        description: "Review imported stay records",
        href: "#entity-browser",
        icon: <Wrench size={18} />,
      },
      {
        id: "diagnostics",
        label: "Diagnostics",
        description: "Operational tools and health checks",
        href: "#operational-diagnostics",
        icon: <Database size={18} />,
      },
    ],
  },
];

export const portalMobileItems: PortalMobileNavigationItem[] = [
  { id: "home", label: "Home", href: "#portal-mobile-nav", icon: <Home size={22} />, active: true },
  { id: "map", label: "Map", href: "#explorer-workspace", icon: <MapPinned size={22} /> },
  { id: "stay", label: "Stay", href: "#entity-browser", icon: <Search size={22} /> },
  { id: "profile", label: "Profile", href: "#portal-mobile-nav", icon: <User size={22} /> },
];

export const portalMobileGroups: PortalMobileNavigationGroup[] = [
  {
    id: "discover",
    title: "Discover",
    items: [
      { id: "accommodations", label: "Accommodations", href: "#entity-browser", icon: <Building2 size={20} /> },
      { id: "guides", label: "Local guides", href: "#entity-browser", icon: <Users size={20} /> },
      { id: "places", label: "Places", href: "#explorer-workspace", icon: <MapIcon size={20} /> },
    ],
  },
  {
    id: "traveler",
    title: "Traveler tools",
    items: [
      { id: "favorites", label: "Favorites", href: "#portal-mobile-nav", icon: <Heart size={20} /> },
      { id: "bookings", label: "Bookings", href: "#portal-mobile-nav", icon: <CalendarDays size={20} /> },
      { id: "contact", label: "Contact eLitua", href: "mailto:info@elitua.lt", icon: <Mail size={20} /> },
    ],
  },
];

export const portalFooterLinks: PortalFooterLink[] = [
  { id: "about", label: "About", href: "#portal-footer", icon: <Info size={15} /> },
  { id: "privacy", label: "Privacy", href: "#portal-footer", icon: <ShieldCheck size={15} /> },
  { id: "terms", label: "Terms", href: "#portal-footer", icon: <BookOpen size={15} /> },
  { id: "contact", label: "Contact", href: "mailto:info@elitua.lt", icon: <Mail size={15} /> },
];

export const workspaceTabs: WorkspaceShellTab[] = [
  { id: "work", label: "Work", href: "#workspace-shell/work", icon: <Columns3 size={15} />, active: true },
  { id: "activity", label: "Activity", href: "#workspace-shell/activity", icon: <Activity size={15} /> },
  { id: "maestro", label: "Maestro", href: "#workspace-shell/maestro", icon: <MessageSquare size={15} /> },
  { id: "agents", label: "Agents", href: "#workspace-shell/agents", icon: <Bot size={15} />, badge: "3" },
  { id: "database", label: "Database", href: "#workspace-shell/database", icon: <Database size={15} /> },
];

export const tableRows = [
  { id: "agent-codex-maestro", type: "agent", status: "active", owner: "Maestro", load: "68%" },
  { id: "score-board", type: "feature", status: "review", owner: "UI", load: "4 tasks" },
  { id: "oracle-db-view", type: "app", status: "ready", owner: "Data", load: "read-only" },
  { id: "elitua-guides", type: "module", status: "paused", owner: "eLitua", load: "scope wait" },
];

export const kanbanColumns: KanbanColumn[] = [
  {
    id: "backlog",
    title: "Backlog",
    tasks: [
      {
        id: "UI-211",
        title: "Normalize entity browser filter density",
        owner: "agent-luna-ui",
        priority: "major",
        tone: "warning",
        age: "2h",
      },
    ],
  },
  {
    id: "processing",
    title: "Processing",
    tasks: [
      {
        id: "UI-214",
        title: "Extract board columns with 300px minimum track",
        owner: "agent-codex-maestro",
        priority: "critical",
        tone: "danger",
        age: "28m",
      },
      {
        id: "UI-219",
        title: "Create shadcn-style status controls",
        owner: "agent-mini-worker",
        priority: "minor",
        tone: "info",
        age: "8m",
      },
    ],
  },
  {
    id: "review",
    title: "Review",
    tasks: [
      {
        id: "UI-220",
        title: "Confirm pager API before returning to apps",
        owner: "Maestro",
        priority: "major",
        tone: "accent",
        age: "1h",
      },
    ],
  },
  { id: "done", title: "Done", tasks: [] },
];

export const entities = [
  {
    title: "Vilnius Old Town",
    subtitle: "Dense location card adapted from eLitua travel content patterns.",
    meta: "Lithuania / city",
    tags: ["guide", "geo", "published"],
  },
  {
    title: "Score agent roster",
    subtitle: "Operational entity with status, capacity and assignment signals.",
    meta: "Score / control plane",
    tags: ["agent", "capacity", "admin"],
  },
  {
    title: "Oracle score schema",
    subtitle: "Read-only browsing surface for tables, columns and JSON values.",
    meta: "Data / database",
    tags: ["schema", "readonly", "json"],
  },
];
