/**
 * Local stand-ins for the photographs catalog demos used to hot-link.
 *
 * Demos previously pointed at third-party hosts, so opening the catalog made
 * network requests to them: slow on a cold cache, broken offline, and a privacy
 * leak for a gated internal tool. Each scene below is a small inline SVG, so a
 * demo renders the same everywhere and costs no request.
 *
 * The scenes are deliberately abstract — a sky, a horizon and a few shapes —
 * because a demo needs "an image with this aspect and mood", not a specific
 * photograph.
 */

export type DemoScene = "city" | "lake" | "forest" | "coast" | "meadow" | "mountain" | "dusk" | "map";

type Palette = { sky: [string, string]; far: string; near: string; accent: string };

const palettes: Record<DemoScene, Palette> = {
  city: { sky: ["#f6c9a0", "#e98f6a"], far: "#a8563f", near: "#6d3326", accent: "#fde9c9" },
  lake: { sky: ["#bfe3f5", "#7fc0e0"], far: "#3f7f8f", near: "#1f5560", accent: "#e8f6fb" },
  forest: { sky: ["#d8ecc9", "#9cc98a"], far: "#4f8a4b", near: "#27552b", accent: "#f1f8e8" },
  coast: { sky: ["#cfe9f7", "#8fd0e6"], far: "#e2c58f", near: "#2d7f9e", accent: "#ffffff" },
  meadow: { sky: ["#e7f1c4", "#b9d97a"], far: "#7fae4a", near: "#4a7a2c", accent: "#fbf3b0" },
  mountain: { sky: ["#dfe6f3", "#aebbd6"], far: "#74819f", near: "#3d4763", accent: "#ffffff" },
  dusk: { sky: ["#4b3f72", "#c9698a"], far: "#3a2f5b", near: "#221a3a", accent: "#ffd9a8" },
  map: { sky: ["#eef3f1", "#dfe9e4"], far: "#c9dccf", near: "#a9c7b6", accent: "#2f7d67" },
};

function svgDataUri(svg: string): string {
  return `data:image/svg+xml,${encodeURIComponent(svg)}`;
}

/**
 * Returns an inline SVG image for a demo.
 *
 * @param scene  which palette and mood to draw
 * @param width  intrinsic width; with `height` it sets the aspect ratio
 * @param height intrinsic height
 */
export function demoImage(scene: DemoScene, width = 800, height = 500): string {
  const { sky, far, near, accent } = palettes[scene];
  const horizon = Math.round(height * 0.62);
  const sun = Math.round(Math.min(width, height) * 0.09);
  return svgDataUri(
    `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" preserveAspectRatio="xMidYMid slice">` +
      `<defs><linearGradient id="s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${sky[0]}"/><stop offset="1" stop-color="${sky[1]}"/></linearGradient></defs>` +
      `<rect width="${width}" height="${height}" fill="url(#s)"/>` +
      `<circle cx="${Math.round(width * 0.76)}" cy="${Math.round(height * 0.28)}" r="${sun}" fill="${accent}" opacity="0.85"/>` +
      `<path d="M0 ${horizon} L${Math.round(width * 0.22)} ${Math.round(height * 0.4)} L${Math.round(width * 0.45)} ${horizon - Math.round(height * 0.05)} L${Math.round(width * 0.68)} ${Math.round(height * 0.36)} L${width} ${horizon} L${width} ${height} L0 ${height} Z" fill="${far}"/>` +
      `<path d="M0 ${Math.round(height * 0.8)} Q${Math.round(width * 0.3)} ${Math.round(height * 0.66)} ${Math.round(width * 0.6)} ${Math.round(height * 0.8)} T${width} ${Math.round(height * 0.76)} L${width} ${height} L0 ${height} Z" fill="${near}"/>` +
      `</svg>`,
  );
}

/** Wide landscape banner used by the portal and editorial hero demos. */
export const demoHeroImage = demoImage("lake", 1024, 308);

/** Square brand mark used where a demo previews an uploaded logo or asset. */
export const demoBrandImage = demoImage("map", 400, 400);
