import type { ComponentPlaygroundValues } from "../components/data/ComponentPlaygroundPanel";

function stringValue(values: ComponentPlaygroundValues, name: string, fallback: string): string {
  const value = values[name];
  return typeof value === "string" ? value : fallback;
}

function numberValue(values: ComponentPlaygroundValues, name: string, fallback: number): number {
  const value = values[name];
  return typeof value === "number" ? value : fallback;
}

function booleanValue(values: ComponentPlaygroundValues, name: string, fallback: boolean): boolean {
  const value = values[name];
  return typeof value === "boolean" ? value : fallback;
}

function jsxStringProp(name: string, value: string): string {
  return `${name}=${JSON.stringify(value)}`;
}

function optionalStringProp(name: string, value: string, fallback: string): string | null {
  return value === fallback ? null : jsxStringProp(name, value);
}

function jsxElement(name: string, props: string[]): string {
  return `<${name}\n${props.map((prop) => `  ${prop}`).join("\n")}\n/>`;
}

export function buildComponentPlaygroundSnippet(values: ComponentPlaygroundValues): string {
  const label = stringValue(values, "label", "Email notifications");
  const tone = stringValue(values, "tone", "info");
  const count = numberValue(values, "count", 3);
  const enabled = booleanValue(values, "enabled", true);
  const detail = enabled ? `${count} checks visible` : "Controls disabled";
  const props = [
    optionalStringProp("label", label, "Email notifications"),
    optionalStringProp("detail", detail, "3 checks visible"),
    optionalStringProp("tone", enabled ? tone : "warning", "info"),
    "variant=\"bar\"",
  ].filter(Boolean) as string[];
  return jsxElement("StatusIndicator", props);
}
