import { describe, expect, it } from "vitest";
import { externalLinkRel } from "./externalLinkRel";

describe("externalLinkRel", () => {
  it("defaults a _blank anchor with no caller rel", () => {
    expect(externalLinkRel("_blank", undefined)).toBe("noopener noreferrer");
  });

  it("leaves a same-tab anchor without a rel", () => {
    expect(externalLinkRel(undefined, undefined)).toBeUndefined();
    expect(externalLinkRel("_self", undefined)).toBeUndefined();
  });

  it("never overrides a deliberate caller rel", () => {
    // A consumer who wants the referrer sent (same-origin analytics) must be
    // able to say so, even on a _blank link.
    expect(externalLinkRel("_blank", "noopener")).toBe("noopener");
    expect(externalLinkRel("_blank", "")).toBe("");
    expect(externalLinkRel(undefined, "author")).toBe("author");
  });
});
