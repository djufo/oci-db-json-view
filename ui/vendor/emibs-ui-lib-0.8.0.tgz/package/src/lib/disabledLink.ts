/**
 * Resolve the anchor attributes for a link affordance that can be disabled.
 *
 * ## The problem
 *
 * `<a>` has no `disabled` attribute. Several panels in this package render
 * their activation affordance as a `<button disabled>` when the caller supplies
 * a handler, but as a plain `<a href>` when the caller supplies a URL — and the
 * anchor branch used to ignore `disabled` entirely, taking only an `is-disabled`
 * class that dims it. A control that *looks* disabled and still navigates on
 * Enter or on click is worse than one that looks enabled, because the greying
 * is a promise the control does not keep.
 *
 * ## The decision (uif/issue-4673)
 *
 * A disabled link keeps its `<a>` element and its classes, but:
 *
 * - **`href` is dropped.** This is the load-bearing part. An `<a>` with no
 *   `href` is not a link for activation purposes: it leaves the tab order, so
 *   it cannot be reached or fired by keyboard, and it has no navigation
 *   behaviour to fire on click. Nothing else — not `aria-disabled`, not
 *   `pointer-events: none`, not a click handler that calls `preventDefault` —
 *   makes a control genuinely non-activating by BOTH keyboard and pointer.
 *   `aria-disabled` alone only announces; the anchor stays fully operable.
 * - **`role="link"` is restored.** Dropping `href` also drops the implicit
 *   `link` role (an hrefless `<a>` maps to `generic`), which would make the
 *   control vanish from a screen-reader's list of links rather than appear
 *   there as unavailable. The explicit role keeps it announced as a link.
 * - **`aria-disabled="true"` is set**, so the unavailability is announced and
 *   so the state hook that `src/theme/STATES.md` names for `disabled`
 *   (`:disabled, aria-disabled`) is present on the element.
 * - **`target`/`rel` are dropped**, because there is no navigation left to
 *   describe.
 *
 * The alternative — swapping the `<a>` for a `<span>` — is equivalent for
 * activation but loses the link role, so this package takes the anchor form.
 *
 * `disabled` deliberately does NOT become focusable-but-inert here: STATES.md
 * rule 5 defines `disabled` as "not focusable" and reserves the dimmed-yet-
 * focusable treatment for `busy`.
 */
export type DisableableLinkAttributes = {
  href?: string;
  role?: "link";
  "aria-disabled"?: true;
  rel?: string;
  target?: string;
};

export function disableableLinkAttributes(options: {
  href: string;
  disabled?: boolean;
  rel?: string;
  target?: string;
}): DisableableLinkAttributes {
  if (options.disabled) {
    return { role: "link", "aria-disabled": true };
  }

  return { href: options.href, rel: options.rel, target: options.target };
}
