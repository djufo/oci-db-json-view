// Notifications data layer — wire types + client configuration.
//
// These mirror the emibs-svc-notifications public JSON contract
// (internal/notifications/{types,service,stream}.go) exactly, so a config-driven
// client can talk to the live service, the contract-exact mock, or any app that
// embeds the same API. No provider identity lives here: appKey/recipientId/token
// are all supplied by the consuming app (issue-3752 / epic-3749 · S3).

/**
 * One durable, per-recipient notification, as returned by the service. Field
 * names and optionality track `Notification` in the service's types.go
 * (`Seq` is internal and never serialized, so it is absent here). Timestamps
 * arrive as RFC3339 strings.
 */
export type NotificationRecord = {
  id: string;
  appKey: string;
  recipientId: string;
  type: string;
  title: string;
  body: string;
  link?: string;
  read: boolean;
  createdAt: string;
  readAt?: string;
};

/** One page of notifications, newest first, from `GET /notifications`. */
export type NotificationListResult = {
  notifications: NotificationRecord[];
  nextCursor?: string;
};

/**
 * Bearer token supplied by the consuming app. A getter (sync or async) lets the
 * app refresh a short-lived token per request; a bare string is resolved once.
 * The token is never persisted or logged by this layer.
 */
export type NotificationsAuthToken =
  | string
  | (() => string | null | undefined | Promise<string | null | undefined>);

/**
 * Everything the client needs to reach one app+recipient scope. All of it is
 * config: eLitua (S4) or any app passes its own base URL, appKey, recipientId,
 * and token, so the component stays vendor-neutral.
 */
export type NotificationsClientConfig = {
  /** Service origin/base, e.g. `https://notifications.ayc.io` or the mock's URL. */
  baseUrl: string;
  /** The app scope; every request is bound to it and the token must permit it. */
  appKey: string;
  /** The recipient whose inbox this client reads. */
  recipientId: string;
  /** Bearer token or token getter; omitted only when the service is unauthenticated. */
  token?: NotificationsAuthToken;
  /** Default page size for list requests (service default applies when unset). */
  pageSize?: number;
  /** Injectable fetch (tests, non-browser hosts); defaults to global `fetch`. */
  fetchImpl?: typeof fetch;
};

/** Options for a single list page request. */
export type NotificationListParams = {
  cursor?: string;
  unreadOnly?: boolean;
  limit?: number;
  signal?: AbortSignal;
};
