// useNotifications — the one hook that drives NotificationBell + ActivityCenter.
//
// It loads the initial page + unread-count over REST, subscribes to the live SSE
// stream (prepending new notifications and applying authoritative unread-count
// updates), reconnects with the Last-Event-ID watermark after a drop, and
// exposes optimistic markRead / markAllRead. It is config-driven: pass a base
// URL, appKey, recipientId, and token; provider identity stays out (issue-3752).

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { createNotificationsClient, type NotificationsClient } from "./client";
import type {
  NotificationRecord,
  NotificationsClientConfig,
} from "./types";

/** Lifecycle of the initial REST load feeding the panel's loading/error states. */
export type NotificationsStatus = "idle" | "loading" | "ready" | "error";

export type UseNotificationsOptions = {
  /** Open the live SSE stream after the initial load (default true). */
  live?: boolean;
  /** Delay before a reconnect attempt after a stream drop, ms (default 3000). */
  reconnectDelayMs?: number;
};

export type UseNotificationsResult = {
  notifications: NotificationRecord[];
  unreadCount: number;
  status: NotificationsStatus;
  error: string | null;
  /** True while a live SSE connection is open. */
  connected: boolean;
  /** True when another page can be loaded via `loadMore`. */
  hasMore: boolean;
  /** True while `loadMore` is in flight. */
  loadingMore: boolean;
  /** Re-run the initial REST load (list + unread-count). */
  refresh: () => Promise<void>;
  /** Fetch and append the next page. */
  loadMore: () => Promise<void>;
  /** Optimistically mark one notification read, then persist; reverts on failure. */
  markRead: (id: string) => Promise<void>;
  /** Optimistically mark every notification read, then persist; reverts on failure. */
  markAllRead: () => Promise<void>;
};

export function useNotifications(
  config: NotificationsClientConfig,
  options: UseNotificationsOptions = {},
): UseNotificationsResult {
  const { live = true, reconnectDelayMs = 3000 } = options;

  const [notifications, setNotifications] = useState<NotificationRecord[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [status, setStatus] = useState<NotificationsStatus>("idle");
  const [error, setError] = useState<string | null>(null);
  const [connected, setConnected] = useState(false);
  const [nextCursor, setNextCursor] = useState<string | undefined>(undefined);
  const [loadingMore, setLoadingMore] = useState(false);

  // The client is recreated only when an identity field changes, so the stream
  // effect below re-subscribes on a real scope/endpoint change, not every render.
  const client = useMemo<NotificationsClient>(
    () => createNotificationsClient(config),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [config.baseUrl, config.appKey, config.recipientId, config.token, config.pageSize, config.fetchImpl],
  );

  // Latest live event id, used as the reconnect watermark.
  const lastEventIdRef = useRef<string | undefined>(undefined);
  // A render-fresh mirror of `notifications` so imperative handlers (markRead)
  // can read the current read/unread state without stale-closing over it.
  const notificationsRef = useRef(notifications);
  notificationsRef.current = notifications;
  // The live stream emits an authoritative absolute unread-count on connect and
  // on every change. Once it has, the one-shot REST count must not regress it.
  const streamCountSeenRef = useRef(false);
  // Monotonic scope generation. It is bumped whenever the client identity
  // (base URL / appKey / recipientId / token) changes, so an in-flight REST
  // response or a queued reconnect from a prior scope is ignored instead of
  // leaking another recipient's data into the newly-bound scope.
  const epochRef = useRef(0);

  const refresh = useCallback(async () => {
    const epoch = epochRef.current;
    setStatus("loading");
    setError(null);
    try {
      const [page, count] = await Promise.all([client.list(), client.unreadCount()]);
      if (epoch !== epochRef.current) {
        return; // Scope changed while loading; discard this stale page.
      }
      // Merge, not replace: a notification the SSE stream delivered during the
      // load (either connect order is possible) must not be dropped by the page.
      setNotifications((current) => mergeNewestFirst(page.notifications, current));
      setNextCursor(page.nextCursor);
      if (!streamCountSeenRef.current) {
        setUnreadCount(count);
      }
      setStatus("ready");
    } catch (cause) {
      if (epoch !== epochRef.current) {
        return;
      }
      setError(messageOf(cause));
      setStatus("error");
    }
  }, [client]);

  const loadMore = useCallback(async () => {
    if (!nextCursor) {
      return;
    }
    const epoch = epochRef.current;
    setLoadingMore(true);
    try {
      const page = await client.list({ cursor: nextCursor });
      if (epoch !== epochRef.current) {
        return;
      }
      setNotifications((current) => mergeNewestFirst(current, page.notifications));
      setNextCursor(page.nextCursor);
    } catch (cause) {
      if (epoch === epochRef.current) {
        setError(messageOf(cause));
      }
    } finally {
      if (epoch === epochRef.current) {
        setLoadingMore(false);
      }
    }
  }, [client, nextCursor]);

  const markRead = useCallback(
    async (id: string) => {
      const target = notificationsRef.current.find((item) => item.id === id);
      if (!target || target.read) {
        return;
      }
      const epoch = epochRef.current;
      // Optimistic: flip the row read and drop the unread count by one now.
      setNotifications((current) =>
        current.map((item) =>
          item.id === id ? { ...item, read: true, readAt: item.readAt ?? new Date().toISOString() } : item,
        ),
      );
      setUnreadCount((count) => Math.max(0, count - 1));
      try {
        await client.markRead(id);
      } catch (cause) {
        if (epoch !== epochRef.current) {
          return; // Scope rebound mid-flight; never revert into the new scope.
        }
        // Revert to the pre-mark snapshot; the server rejected it.
        setNotifications((current) =>
          current.map((item) => (item.id === id ? { ...item, read: target.read, readAt: target.readAt } : item)),
        );
        setUnreadCount((count) => count + 1);
        setError(messageOf(cause));
      }
    },
    [client],
  );

  const markAllRead = useCallback(async () => {
    const snapshot = { list: notifications, count: unreadCount };
    const epoch = epochRef.current;
    const now = new Date().toISOString();
    setNotifications((current) =>
      current.map((item) => (item.read ? item : { ...item, read: true, readAt: item.readAt ?? now })),
    );
    setUnreadCount(0);
    try {
      await client.markAllRead();
    } catch (cause) {
      if (epoch !== epochRef.current) {
        return; // Scope rebound mid-flight; do not restore the old snapshot.
      }
      setNotifications(snapshot.list);
      setUnreadCount(snapshot.count);
      setError(messageOf(cause));
    }
  }, [client, notifications, unreadCount]);

  // Rebind: when the client identity changes, hard-reset every scope-bound piece
  // of state BEFORE the (re)load and (re)subscribe run, so the previous
  // recipient's notifications, unread count, pagination cursor, and SSE
  // watermark can never bleed into the new scope. Runs before the load effect
  // below (declaration order) and on first mount (a harmless reset of empties).
  useEffect(() => {
    epochRef.current += 1;
    lastEventIdRef.current = undefined;
    streamCountSeenRef.current = false;
    setNotifications([]);
    setUnreadCount(0);
    setNextCursor(undefined);
    setError(null);
    setStatus("idle");
    setConnected(false);
  }, [client]);

  // Initial load, re-run when the client identity changes.
  useEffect(() => {
    void refresh();
  }, [refresh]);

  // Live stream with Last-Event-ID reconnect. A single effect owns the whole
  // connect → drain → reconnect loop and tears it down on unmount / re-scope.
  useEffect(() => {
    if (!live) {
      return;
    }
    let cancelled = false;
    let cancelStream: (() => void) | null = null;
    let reconnectTimer: ReturnType<typeof setTimeout> | null = null;

    const connect = () => {
      if (cancelled) {
        return;
      }
      cancelStream = client.stream({
        lastEventId: lastEventIdRef.current,
        onOpen: () => {
          if (!cancelled) {
            setConnected(true);
          }
        },
        onEvent: (event) => {
          if (cancelled) {
            return;
          }
          if (event.id) {
            lastEventIdRef.current = event.id;
          }
          if (event.type === "unread-count") {
            // The service sends the authoritative absolute total; trust it.
            streamCountSeenRef.current = true;
            setUnreadCount(event.unreadCount);
            return;
          }
          // A newly delivered (or replayed) notification: prepend, de-duplicating
          // by id so a reconnect replay can never double-insert.
          setNotifications((current) => mergeNewestFirst([event.notification], current));
        },
        onClose: scheduleReconnect,
        onError: () => {
          if (!cancelled) {
            setConnected(false);
          }
          scheduleReconnect();
        },
      });
    };

    function scheduleReconnect() {
      if (cancelled) {
        return;
      }
      setConnected(false);
      reconnectTimer = setTimeout(connect, reconnectDelayMs);
    }

    connect();

    return () => {
      cancelled = true;
      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
      }
      cancelStream?.();
      setConnected(false);
    };
  }, [client, live, reconnectDelayMs]);

  return {
    notifications,
    unreadCount,
    status,
    error,
    connected,
    hasMore: Boolean(nextCursor),
    loadingMore,
    refresh,
    loadMore,
    markRead,
    markAllRead,
  };
}

/**
 * Merge incoming records ahead of existing ones, newest-first, keeping each id
 * once (incoming wins). Both the SSE prepend and paged `loadMore` route through
 * here so ordering and de-duplication are defined in exactly one place.
 */
function mergeNewestFirst(
  incoming: NotificationRecord[],
  existing: NotificationRecord[],
): NotificationRecord[] {
  const seen = new Set<string>();
  const merged: NotificationRecord[] = [];
  for (const item of [...incoming, ...existing]) {
    if (seen.has(item.id)) {
      continue;
    }
    seen.add(item.id);
    merged.push(item);
  }
  return merged.sort((a, b) => {
    const byTime = Date.parse(b.createdAt) - Date.parse(a.createdAt);
    if (byTime !== 0 && !Number.isNaN(byTime)) {
      return byTime;
    }
    return a.id < b.id ? 1 : a.id > b.id ? -1 : 0;
  });
}

function messageOf(cause: unknown): string {
  if (cause instanceof Error) {
    return cause.message;
  }
  return "Something went wrong.";
}
