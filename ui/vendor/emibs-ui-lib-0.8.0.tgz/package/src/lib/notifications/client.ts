// Notifications client — the thin, config-driven transport over the service's
// REST + SSE contract (emibs-svc-notifications). It owns URL building, bearer
// auth, JSON decoding, and opening the live stream; it holds NO React state and
// NO product/vendor knowledge, so the same client serves eLitua (S4) and any
// other app. Reconnect/backoff policy lives in useNotifications, above this.

import { createNotificationsSseParser, type NotificationsStreamEvent } from "./sse";
import type {
  NotificationListParams,
  NotificationListResult,
  NotificationRecord,
  NotificationsClientConfig,
} from "./types";

/** Callbacks for one live stream connection. */
export type NotificationsStreamHandlers = {
  /** Fired once when the response opens with a 2xx (a good place to reset backoff). */
  onOpen?: () => void;
  /** Fired for every decoded `notification` / `unread-count` event, in order. */
  onEvent: (event: NotificationsStreamEvent) => void;
  /** Fired when the connection ends without an explicit abort (server close / network). */
  onClose?: () => void;
  /** Fired on a transport or non-2xx error (never for a caller-initiated abort). */
  onError?: (error: unknown) => void;
};

export type NotificationsStreamOptions = NotificationsStreamHandlers & {
  /** Resume cursor from the last event id seen; sent as `lastEventId` + header. */
  lastEventId?: string;
};

export type NotificationsClient = {
  list(params?: NotificationListParams): Promise<NotificationListResult>;
  markRead(id: string, options?: { signal?: AbortSignal }): Promise<void>;
  markAllRead(options?: { signal?: AbortSignal }): Promise<number>;
  unreadCount(options?: { signal?: AbortSignal }): Promise<number>;
  /** Open one live SSE connection. Returns a function that aborts it cleanly. */
  stream(options: NotificationsStreamOptions): () => void;
  readonly config: NotificationsClientConfig;
};

/** Build a client bound to one app+recipient scope from pure config. */
export function createNotificationsClient(config: NotificationsClientConfig): NotificationsClient {
  const doFetch = config.fetchImpl ?? globalThis.fetch;
  if (typeof doFetch !== "function") {
    throw new Error("notifications client requires a fetch implementation");
  }

  async function authHeaders(base: Record<string, string> = {}): Promise<Record<string, string>> {
    const token = await resolveToken(config.token);
    if (token) {
      return { ...base, Authorization: `Bearer ${token}` };
    }
    return base;
  }

  function url(path: string, params: Record<string, string | number | boolean | undefined>): string {
    const target = new URL(path, ensureTrailingSlash(config.baseUrl));
    target.searchParams.set("appKey", config.appKey);
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== "") {
        target.searchParams.set(key, String(value));
      }
    }
    return target.toString();
  }

  async function list(params: NotificationListParams = {}): Promise<NotificationListResult> {
    const response = await doFetch(
      url("notifications", {
        recipientId: config.recipientId,
        unreadOnly: params.unreadOnly ? "true" : undefined,
        cursor: params.cursor,
        limit: params.limit ?? config.pageSize,
      }),
      { method: "GET", headers: await authHeaders({ Accept: "application/json" }), signal: params.signal },
    );
    const body = await readJson(response, "list notifications");
    const notifications = Array.isArray((body as NotificationListResult).notifications)
      ? (body as NotificationListResult).notifications
      : [];
    const nextCursor = (body as NotificationListResult).nextCursor;
    return { notifications: notifications as NotificationRecord[], nextCursor: nextCursor || undefined };
  }

  async function markRead(id: string, options: { signal?: AbortSignal } = {}): Promise<void> {
    if (!id) {
      throw new Error("markRead requires a notification id");
    }
    const response = await doFetch(url(`notifications/${encodeURIComponent(id)}/read`, { recipientId: config.recipientId }), {
      method: "POST",
      headers: await authHeaders(),
      signal: options.signal,
    });
    // Success is 204 No Content; anything else is an error with the body detail.
    if (!response.ok) {
      throw await httpError(response, "mark notification read");
    }
  }

  async function markAllRead(options: { signal?: AbortSignal } = {}): Promise<number> {
    const response = await doFetch(url("notifications/read-all", { recipientId: config.recipientId }), {
      method: "POST",
      headers: await authHeaders({ Accept: "application/json" }),
      signal: options.signal,
    });
    const body = await readJson(response, "mark all notifications read");
    const marked = (body as { marked?: number }).marked;
    return typeof marked === "number" ? marked : 0;
  }

  async function unreadCount(options: { signal?: AbortSignal } = {}): Promise<number> {
    const response = await doFetch(url("notifications/unread-count", { recipientId: config.recipientId }), {
      method: "GET",
      headers: await authHeaders({ Accept: "application/json" }),
      signal: options.signal,
    });
    const body = await readJson(response, "count unread notifications");
    const count = (body as { unreadCount?: number }).unreadCount;
    return typeof count === "number" ? count : 0;
  }

  function stream(options: NotificationsStreamOptions): () => void {
    const controller = new AbortController();
    let aborted = false;

    void (async () => {
      try {
        const headers = await authHeaders({ Accept: "text/event-stream" });
        // The service accepts the reconnect cursor via the Last-Event-ID header
        // AND a `lastEventId` query param; we send both so browser and
        // non-browser transports resume at the same watermark.
        if (options.lastEventId) {
          headers["Last-Event-ID"] = options.lastEventId;
        }
        const response = await doFetch(
          url("notifications/stream", {
            recipientId: config.recipientId,
            lastEventId: options.lastEventId,
          }),
          { method: "GET", headers, signal: controller.signal },
        );
        if (!response.ok || !response.body) {
          throw await httpError(response, "open notifications stream");
        }
        options.onOpen?.();

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        const parser = createNotificationsSseParser();
        while (true) {
          const { done, value } = await reader.read();
          if (done) {
            for (const event of parser.end()) {
              options.onEvent(event);
            }
            break;
          }
          const events = parser.push(decoder.decode(value, { stream: true }));
          for (const event of events) {
            options.onEvent(event);
          }
        }
        if (!aborted) {
          options.onClose?.();
        }
      } catch (error) {
        if (aborted || isAbortError(error)) {
          return;
        }
        options.onError?.(error);
      }
    })();

    return () => {
      aborted = true;
      controller.abort();
    };
  }

  return { list, markRead, markAllRead, unreadCount, stream, config };
}

async function resolveToken(
  token: NotificationsClientConfig["token"],
): Promise<string | null> {
  if (!token) {
    return null;
  }
  const value = typeof token === "function" ? await token() : token;
  return value ? value : null;
}

function ensureTrailingSlash(base: string): string {
  return base.endsWith("/") ? base : `${base}/`;
}

async function readJson(response: Response, action: string): Promise<unknown> {
  if (!response.ok) {
    throw await httpError(response, action);
  }
  try {
    return await response.json();
  } catch {
    throw new Error(`${action}: response was not valid JSON`);
  }
}

async function httpError(response: Response, action: string): Promise<Error> {
  let detail = "";
  try {
    const body = (await response.json()) as { error?: string };
    detail = body?.error ?? "";
  } catch {
    detail = "";
  }
  const suffix = detail ? `: ${detail}` : "";
  return new Error(`${action} failed (${response.status})${suffix}`);
}

function isAbortError(error: unknown): boolean {
  return Boolean(error) && typeof error === "object" && (error as { name?: string }).name === "AbortError";
}
