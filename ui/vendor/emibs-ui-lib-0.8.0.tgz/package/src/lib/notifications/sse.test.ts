import { describe, expect, it } from "vitest";
import { createNotificationsSseParser } from "./sse";

const NOTIFICATION_JSON =
  '{"id":"n-1","appKey":"elitua","recipientId":"u-1","type":"task.assigned","title":"New task","body":"S3","read":false,"createdAt":"2026-08-12T10:00:00Z"}';

describe("createNotificationsSseParser", () => {
  it("parses an unread-count event with its id cursor", () => {
    const parser = createNotificationsSseParser();
    const events = parser.push("id: 42\nevent: unread-count\ndata: {\"unreadCount\":3}\n\n");
    expect(events).toEqual([{ type: "unread-count", unreadCount: 3, id: "42" }]);
  });

  it("parses a notification event and preserves its id watermark", () => {
    const parser = createNotificationsSseParser();
    const events = parser.push(`id: 7\nevent: notification\ndata: ${NOTIFICATION_JSON}\n\n`);
    expect(events).toHaveLength(1);
    expect(events[0]).toMatchObject({ type: "notification", id: "7" });
    if (events[0].type === "notification") {
      expect(events[0].notification.id).toBe("n-1");
      expect(events[0].notification.read).toBe(false);
    }
  });

  it("reassembles an event split across two chunks", () => {
    const parser = createNotificationsSseParser();
    expect(parser.push("event: unread-count\nda")).toEqual([]);
    const events = parser.push('ta: {"unreadCount":9}\n\n');
    expect(events).toEqual([{ type: "unread-count", unreadCount: 9, id: undefined }]);
  });

  it("ignores keepalive comments and blank frames", () => {
    const parser = createNotificationsSseParser();
    expect(parser.push(": keepalive\n\n")).toEqual([]);
    expect(parser.push("\n\n")).toEqual([]);
  });

  it("drops malformed data rather than emitting a bad event", () => {
    const parser = createNotificationsSseParser();
    expect(parser.push("event: unread-count\ndata: not-json\n\n")).toEqual([]);
    expect(parser.push("event: notification\ndata: {\"id\":123}\n\n")).toEqual([]);
  });

  it("normalizes CRLF framing", () => {
    const parser = createNotificationsSseParser();
    const events = parser.push("event: unread-count\r\ndata: {\"unreadCount\":1}\r\n\r\n");
    expect(events).toEqual([{ type: "unread-count", unreadCount: 1, id: undefined }]);
  });
});
