// Notifications SSE parser — a pure, transport-free reader for the live channel
// (`GET /notifications/stream`, see the service's stream.go). It is deliberately
// side-effect free: the client feeds it decoded chunks
// and it yields typed events, so the framing is unit-testable without a network.
//
// The service emits two event kinds, each with an `id:` cursor used for
// Last-Event-ID reconnect:
//   event: unread-count   data: {"unreadCount": <n>}
//   event: notification   data: {<NotificationRecord>}
// plus `: keepalive` comment frames, which carry no data and are ignored.

import type { NotificationRecord } from "./types";

/** Live unread-count update; `unreadCount` is the authoritative absolute total. */
export type NotificationsUnreadCountEvent = {
  type: "unread-count";
  unreadCount: number;
  /** SSE `id:` cursor for this frame, when present (used for reconnect). */
  id?: string;
};

/** A newly delivered (or replayed) notification. */
export type NotificationsNotificationEvent = {
  type: "notification";
  notification: NotificationRecord;
  /** SSE `id:` cursor for this frame; advances the reconnect watermark. */
  id?: string;
};

export type NotificationsStreamEvent =
  | NotificationsUnreadCountEvent
  | NotificationsNotificationEvent;

export type NotificationsSseParser = {
  /** Feed a decoded text chunk; returns any complete events it unlocked. */
  push(chunk: string): NotificationsStreamEvent[];
  /** Flush a trailing event at end-of-stream (mirrors chat parser semantics). */
  end(): NotificationsStreamEvent[];
};

/** Create a stateful SSE frame parser for the notifications stream. */
export function createNotificationsSseParser(): NotificationsSseParser {
  let buffer = "";

  return {
    push(chunk: string) {
      // Normalize CRLF/CR to LF so `\n\n` boundary detection is uniform.
      buffer += chunk.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
      const events: NotificationsStreamEvent[] = [];

      while (buffer.includes("\n\n")) {
        const boundary = buffer.indexOf("\n\n");
        const block = buffer.slice(0, boundary);
        buffer = buffer.slice(boundary + 2);
        const event = parseBlock(block);
        if (event) {
          events.push(event);
        }
      }

      return events;
    },
    end() {
      if (!buffer.trim()) {
        buffer = "";
        return [];
      }
      const event = parseBlock(buffer);
      buffer = "";
      return event ? [event] : [];
    },
  };
}

function parseBlock(block: string): NotificationsStreamEvent | null {
  let eventName = "message";
  let id: string | undefined;
  const dataLines: string[] = [];

  for (const rawLine of block.split("\n")) {
    // Blank lines and `:` comment/keepalive lines carry no fields.
    if (!rawLine || rawLine.startsWith(":")) {
      continue;
    }
    const colon = rawLine.indexOf(":");
    const field = colon >= 0 ? rawLine.slice(0, colon) : rawLine;
    // Per the SSE spec, a single leading space after the colon is stripped.
    const value = colon >= 0 ? rawLine.slice(colon + 1).replace(/^ /, "") : "";
    if (field === "event") {
      eventName = value;
    } else if (field === "id") {
      id = value;
    } else if (field === "data") {
      dataLines.push(value);
    }
  }

  const data = dataLines.join("\n");
  if (!data) {
    return null;
  }

  if (eventName === "unread-count") {
    const parsed = safeParse(data);
    const count = parsed?.unreadCount;
    if (typeof count !== "number" || !Number.isFinite(count)) {
      return null;
    }
    return { type: "unread-count", unreadCount: count, id };
  }

  if (eventName === "notification") {
    const notification = parseNotification(data);
    return notification ? { type: "notification", notification, id } : null;
  }

  return null;
}

function parseNotification(data: string): NotificationRecord | null {
  const parsed = safeParse(data);
  if (
    !parsed ||
    typeof parsed.id !== "string" ||
    typeof parsed.title !== "string" ||
    typeof parsed.read !== "boolean"
  ) {
    return null;
  }
  return parsed as unknown as NotificationRecord;
}

function safeParse(data: string): Record<string, unknown> | null {
  try {
    const value = JSON.parse(data);
    return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}
