import { describe, expect, it } from "vitest";
import { buildComponentPlaygroundSnippet } from "./componentPlaygroundSnippet";

describe("buildComponentPlaygroundSnippet", () => {
  it("omits default-controlled props", () => {
    expect(
      buildComponentPlaygroundSnippet({
        label: "Email notifications",
        tone: "info",
        count: 3,
        enabled: true,
      }),
    ).toBe(`<StatusIndicator
  variant="bar"
/>`);
  });

  it("includes only the props needed to reproduce the current state", () => {
    expect(
      buildComponentPlaygroundSnippet({
        label: "System alerts",
        tone: "success",
        count: 5,
        enabled: false,
      }),
    ).toBe(`<StatusIndicator
  label="System alerts"
  detail="Controls disabled"
  tone="warning"
  variant="bar"
/>`);
  });
});
