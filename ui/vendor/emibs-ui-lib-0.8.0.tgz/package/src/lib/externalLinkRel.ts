/**
 * Pick a safe default `rel` for an anchor whose `target` is consumer-supplied.
 *
 * Most components in this package own both attributes and already emit them as
 * a pair (`target={x ? "_blank" : undefined} rel={x ? "noreferrer" : undefined}`).
 * This helper is for the two seams that do NOT own them — `AccountMenu` and
 * `IconButton` — where the consumer passes `target` straight through to the
 * anchor and could set `_blank` while supplying no `rel` at all.
 *
 * An explicit caller `rel` always wins, including `rel=""`. Only an ABSENT
 * `rel` is defaulted, so this can never silently override a deliberate choice
 * (e.g. a consumer who wants the referrer sent to a same-origin destination).
 *
 * Note on `noopener`: per the HTML standard `noreferrer` already implies
 * `noopener`, so the existing `rel="noreferrer"` call sites in this package are
 * not missing anything. The fuller `noopener noreferrer` is used here — and in
 * `PublicProfilePage` — because it states the intent explicitly at a seam where
 * the destination is untrusted by construction.
 *
 * Lives in its own leaf module rather than the `src/lib` barrel for the same
 * reason as `cn`: the barrel re-exports higher layers, so a primitive importing
 * it would cross a layer boundary.
 */
export function externalLinkRel(target?: string, rel?: string): string | undefined {
  if (rel !== undefined) {
    return rel;
  }
  return target === "_blank" ? "noopener noreferrer" : undefined;
}
