import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Merge conditional class names and de-duplicate Tailwind utilities.
 *
 * `cn` lives in its own leaf module rather than in the public entry barrel
 * (`src/lib/index.ts`). The barrel re-exports higher layers (core, components,
 * forms), so importing it from a lower layer would route THROUGH those
 * re-exports and silently bypass the layer boundaries. Primitives and other
 * low layers import `cn` from here so the import-boundary guard (issue-584)
 * can forbid them from importing the layer-mixing barrel.
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
