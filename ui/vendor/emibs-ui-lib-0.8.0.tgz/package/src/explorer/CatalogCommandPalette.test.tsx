// @vitest-environment happy-dom

import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import CatalogCommandPalette from "./CatalogCommandPalette";

const reactActGlobal = globalThis as typeof globalThis & {
  IS_REACT_ACT_ENVIRONMENT?: boolean;
};
reactActGlobal.IS_REACT_ACT_ENVIRONMENT = true;

describe("CatalogCommandPalette", () => {
  let container: HTMLDivElement;
  let root: Root;

  beforeEach(() => {
    Object.defineProperty(HTMLElement.prototype, "scrollIntoView", {
      configurable: true,
      value: vi.fn(),
    });
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => {
      root.unmount();
    });
    container.remove();
    vi.restoreAllMocks();
  });

  it("fuzzy-searches mockups and activates the highlighted mockup result", () => {
    const onNavigateComponent = vi.fn();
    const onNavigateMockup = vi.fn();

    act(() => {
      root.render(
        <CatalogCommandPalette
          hrefForComponent={(id) => `#/c/${id}`}
          hrefForMockup={(id) => `#/m/${id}`}
          onApplyTheme={vi.fn()}
          onNavigateComponent={onNavigateComponent}
          onNavigateMockup={onNavigateMockup}
          onNavigatePage={vi.fn()}
          onOpenChange={vi.fn()}
          onQueryChange={vi.fn()}
          open
          pages={[]}
          query="opsdash"
          themes={[]}
        />,
      );
    });

    expect(container.textContent).toContain("Mockups");
    expect(container.textContent).toContain("Score operations dashboard");
    expect(container.textContent).not.toContain("No matches for");

    const dialog = container.querySelector<HTMLElement>('[role="dialog"]');
    expect(dialog).not.toBeNull();

    act(() => {
      dialog?.dispatchEvent(
        new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Enter" }),
      );
    });

    expect(onNavigateMockup).toHaveBeenCalledTimes(1);
    expect(onNavigateMockup).toHaveBeenCalledWith("score-operations-dashboard");
    expect(onNavigateComponent).not.toHaveBeenCalled();
  });
});
