// @vitest-environment happy-dom

/**
 * Sanitizer coverage for `SpecView`, which renders component `.SPEC.md` source
 * through `marked.parse` and into `dangerouslySetInnerHTML`.
 *
 * These assertions are only meaningful because of the shared setup at
 * `tests/setup/happyDomSanitizerEnv.ts` (wired via `vite.config.ts`), which
 * repairs the happy-dom defect that leaves DOMPurify inert. Read that file
 * before touching this one. Two rules follow directly from it:
 *
 * 1. ONE hostile payload per rendered string. happy-dom's `NodeIterator` stops
 *    advancing after DOMPurify's first node removal, so a second payload in the
 *    same input would be passed through untouched and this test would be
 *    asserting on happy-dom, not on `SpecView`.
 *
 * 2. Every case also asserts that legitimate markdown SURVIVED. Without that,
 *    the test passes just as happily against a component that renders nothing
 *    at all — which is exactly the vacuous pass an inert DOMPurify used to
 *    produce, and the reason this file could not honestly have been written
 *    before the shared setup existed.
 *
 * The benign marker deliberately sits BEFORE the payload in every case. For the
 * SVG vector, DOMPurify's removal of the nested `<script>` trips the iterator
 * desync above and truncates the tail of the document, so a marker placed after
 * the payload would go missing for environment reasons rather than component
 * ones.
 */

import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { SpecView } from "./CatalogExplorer";

const BENIGN = "# Component spec\n\nRenders a labelled control.\n";

type Case = {
  name: string;
  markdown: string;
  /** Substrings that must NOT survive sanitization. */
  forbidden: string[];
};

const cases: Case[] = [
  {
    name: "strips a <script> tag",
    markdown: `${BENIGN}\n<script>window.__pwned = 1;</script>\n`,
    forbidden: ["<script", "window.__pwned"],
  },
  {
    name: "strips an onerror attribute",
    markdown: `${BENIGN}\n<img src=x onerror="window.__pwned = 1">\n`,
    forbidden: ["onerror", "window.__pwned"],
  },
  {
    name: "strips a javascript: href",
    markdown: `${BENIGN}\n[click me](javascript:window.__pwned=1)\n`,
    forbidden: ["javascript:", "window.__pwned"],
  },
  {
    name: "strips an SVG-borne script vector",
    markdown: `${BENIGN}\n<svg><script>window.__pwned = 1</script></svg>\n`,
    forbidden: ["<script", "window.__pwned"],
  },
];

function render(markdown: string | null): string {
  return renderToStaticMarkup(<SpecView markdown={markdown} />);
}

describe("SpecView sanitizes SPEC markdown", () => {
  it.each(cases)("$name", ({ markdown, forbidden }) => {
    const markup = render(markdown);

    for (const needle of forbidden) {
      expect(markup).not.toContain(needle);
    }

    // The component still rendered real content, so the assertions above
    // cannot have passed by rendering nothing.
    expect(markup).toContain("<h1>Component spec</h1>");
    expect(markup).toContain("Renders a labelled control.");
  });

  it("preserves legitimate markdown structure and safe links", () => {
    const markup = render("## Usage\n\nSee [the docs](https://example.com/docs) for details.\n");

    expect(markup).toContain("<h2>Usage</h2>");
    expect(markup).toContain('href="https://example.com/docs"');
    expect(markup).toContain("the docs");
  });

  it("renders the empty note when there is no spec", () => {
    const markup = render(null);

    expect(markup).toContain("No .SPEC.md exists for this component yet.");
    expect(markup).not.toContain("xpl-spec");
  });
});
