// @vitest-environment happy-dom

import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { neutralLightTheme } from "../theme";
import { CatalogExplorer, ExplorerThemeToolbar } from "./CatalogExplorer";

function renderDensity(density: "comfortable" | "compact") {
  return renderToStaticMarkup(
    <ExplorerThemeToolbar
      themeId={neutralLightTheme.id}
      available={[neutralLightTheme]}
      studioActive={false}
      density={density}
      mode="system"
      onDensityChange={() => undefined}
      onModeChange={() => undefined}
      onFamilyChange={() => undefined}
      onOpenPalette={() => undefined}
    />,
  );
}

describe("Explorer density switcher", () => {
  it("states comfortable first, predicts compact, and exposes unpressed semantics", () => {
    const markup = renderDensity("comfortable");
    expect(markup).toContain('aria-label="Density: comfortable — switch to compact"');
    expect(markup).toContain('title="Density: comfortable — switch to compact"');
    expect(markup).toContain('aria-pressed="false"');
  });

  it("updates its current/next label and pressed state for compact density", () => {
    const markup = renderDensity("compact");
    expect(markup).toContain('aria-label="Density: compact — switch to comfortable"');
    expect(markup).toContain('title="Density: compact — switch to comfortable"');
    expect(markup).toContain('aria-pressed="true"');
  });

  it("resolves density aliases inside the active theme token scope", () => {
    window.location.hash = "#/?density=compact";
    const markup = renderToStaticMarkup(<CatalogExplorer />);
    const themeScope = markup.indexOf('class="ui-theme-scope"');
    const densityScope = markup.indexOf('class="ui-density-scope xpl"');

    expect(themeScope).toBeGreaterThanOrEqual(0);
    expect(densityScope).toBeGreaterThan(themeScope);
    expect(markup).toContain('--density-control-height:var(--density-control-height-compact)');
  });
});
