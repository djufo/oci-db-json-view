// Catalog Explorer — grouped/switchable/searchable shell + per-component inspect.
//
// Replaces the flat single-scroll catalog. Reads the registry (single source of
// truth) for navigation, gallery and the inspect page.
//
// Board: task-224 (navigation), task-231 (inspect page), task-228 (gallery),
// task-229 (hash routing + deep links).

import { type CSSProperties, type ReactNode, Suspense, lazy, useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { RunOptions } from "axe-core";
import { marked } from "marked";
import DOMPurify from "dompurify";
import {
  Check,
  ChevronDown,
  ChevronRight,
  Copy,
  Download,
  GitCompare,
  Link2,
  Menu,
  Monitor,
  Moon,
  Search,
  Palette,
  Pin,
  SlidersHorizontal,
  Smartphone,
  Square,
  Sun,
  Tablet,
  Trash2,
  Upload,
  X,
} from "lucide-react";
import { AXES, groupBy, matches } from "../catalog/groups";
import {
  buildCoverageReport,
  coverageFacets,
  coveragePercent,
} from "../catalog/coverage";
export { buildCoverageRows, coverageFacets } from "../catalog/coverage";
import { entries, getEntry, isMigrated } from "../catalog/registry";
import type {
  Category,
  ComponentEntry,
  EntryStatus,
  GroupAxis,
  PlaygroundControl,
  PlaygroundControlValue,
  PlaygroundProps,
  SourceApp,
} from "../catalog/types";
import { getMockup, mockupEntries } from "../compositions";
import type { MockupEntry, MockupSourceApp } from "../compositions";
import { CompareTrayPanel, type CompareTrayItem } from "../components/data/CompareTrayPanel";
import {
  DEFAULT_DENSITY,
  DensityScope,
  ThemeScope,
  getThemeToken,
  loadCustomThemes,
  neutralLightTheme,
  themes,
  themeFromJson,
  themeToCssRoot,
  themeToJson,
  themeToTsModule,
  themeTokenCategoryLabels,
  themeTokenDefinitions,
  type EmibsTheme,
  type Density,
  type ThemeTokenCategory,
} from "../theme";
import {
  DEFAULT_THEME_STUDIO_PREVIEW_SET_ID,
  ThemeStudioPage,
  isThemeStudioPreviewSetId,
  type ThemeStudioPreviewSetId,
} from "./ThemeStudio";
import { FormBuilderPage } from "../forms";
import { FormsOverviewPage } from "./FormsOverviewPage";
import { LazyPreview } from "./LazyPreview";
import { MockupSource } from "./MockupSource";
import { StatePreviewGrid } from "./StatePreviewGrid";

const EXPLORER_THEMES = themes;
type ExplorerThemeId = string;
const DEFAULT_EXPLORER_THEME_ID = neutralLightTheme.id;
const EXPLORER_THEME_STORAGE_KEY = "emibs-ui-lib:explorer-theme";
const COMPARE_PARAM = "compare";
const QUERY_PARAM = "q";
const AXIS_PARAM = "axis";
const FACET_PARAM_PREFIX = "f_";
const FACET_MODE_PARAM_PREFIX = "m_";
const DENSITY_PARAM = "density";
const MATRIX_ENTRY_IDS = ["action-group", "status-indicator", "search-field", "checkbox-control"] as const;
const CatalogCommandPalette = lazy(() => import("./CatalogCommandPalette"));

// ---------- routing ----------

type Route =
  | { kind: "gallery" }
  | { kind: "inspect"; id: string }
  | { kind: "coverage" }
  | { kind: "compare" }
  | { kind: "formBuilder" }
  | { kind: "forms" }
  | { kind: "matrix" }
  | { kind: "studio" }
  | { kind: "foundations" }
  | { kind: "mockups" }
  | { kind: "mockup"; id: string };

function parseRoute(hash: string): Route {
  const { path } = splitHash(hash);
  if (path.startsWith("/coverage")) return { kind: "coverage" };
  if (path.startsWith("/compare")) return { kind: "compare" };
  if (path.startsWith("/forms/builder")) return { kind: "formBuilder" };
  if (path.startsWith("/forms")) return { kind: "forms" };
  if (path.startsWith("/studio")) return { kind: "studio" };
  if (path.startsWith("/foundations")) return { kind: "foundations" };
  if (path.startsWith("/matrix")) return { kind: "matrix" };
  if (path.startsWith("/mockups")) return { kind: "mockups" };
  const mockup = path.match(/^\/m\/([\w-]+)/);
  if (mockup) return { kind: "mockup", id: mockup[1] };
  const m = path.match(/^\/c\/([\w-]+)/);
  if (m) return { kind: "inspect", id: m[1] };
  return { kind: "gallery" };
}

function splitHash(hash: string): { path: string; params: URLSearchParams } {
  const raw = hash.replace(/^#/, "") || "/";
  const queryStart = raw.indexOf("?");
  const path = queryStart >= 0 ? raw.slice(0, queryStart) || "/" : raw;
  const query = queryStart >= 0 ? raw.slice(queryStart + 1) : "";
  return { path, params: new URLSearchParams(query) };
}

type HashParamOverrides = Record<string, string | null>;

function hashForPath(path: string, themeId: ExplorerThemeId, extraParams?: HashParamOverrides): string {
  const hash = typeof window === "undefined" ? "#/" : window.location.hash || "#/";
  return hashForPathFromHash(hash, path, themeId, extraParams);
}

function currentCompareParam(hash: string): string | null {
  return encodeCompareIds(parseCompareIds(hash)) || null;
}

function parseCompareIds(hash: string): string[] {
  const raw = splitHash(hash).params.get(COMPARE_PARAM);
  if (!raw) return [];
  return normalizeCompareIds(raw.split(","));
}

function normalizeCompareIds(ids: readonly string[]): string[] {
  const seen = new Set<string>();
  const normalized: string[] = [];
  ids.forEach((raw) => {
    const id = raw.trim();
    if (!id || seen.has(id)) return;
    const entry = getEntry(id);
    if (!entry || !isMigrated(entry)) return;
    seen.add(id);
    normalized.push(id);
  });
  return normalized;
}

function encodeCompareIds(ids: readonly string[]): string {
  return normalizeCompareIds(ids).join(",");
}

function updateCompareHash(hash: string, ids: readonly string[]): string {
  const { path, params } = splitHash(hash);
  const encoded = encodeCompareIds(ids);
  if (encoded) {
    params.set(COMPARE_PARAM, encoded);
  } else {
    params.delete(COMPARE_PARAM);
  }
  const query = params.toString();
  return `#${path || "/"}${query ? `?${query}` : ""}`;
}

function parseThemeId(hash: string, available: readonly EmibsTheme[] = EXPLORER_THEMES): ExplorerThemeId {
  const candidate = splitHash(hash).params.get("theme");
  if (isExplorerThemeId(candidate, available)) return candidate;
  return getStoredThemeId(available) ?? getSystemDefaultThemeId();
}

function updateThemeHash(hash: string, themeId: ExplorerThemeId): string {
  const { path, params } = splitHash(hash);
  if (themeId === DEFAULT_EXPLORER_THEME_ID) {
    params.delete("theme");
  } else {
    params.set("theme", themeId);
  }
  const query = params.toString();
  return `#${path || "/"}${query ? `?${query}` : ""}`;
}

export function parseDensity(hash: string): Density {
  const candidate = splitHash(hash).params.get(DENSITY_PARAM);
  return candidate === "compact" || candidate === "comfortable" ? candidate : DEFAULT_DENSITY;
}

export function updateDensityHash(hash: string, density: Density): string {
  const { path, params } = splitHash(hash);
  if (density === DEFAULT_DENSITY) {
    params.delete(DENSITY_PARAM);
  } else {
    params.set(DENSITY_PARAM, density);
  }
  const query = params.toString();
  return `#${path || "/"}${query ? `?${query}` : ""}`;
}

function parseStudioPreviewSetId(hash: string): ThemeStudioPreviewSetId {
  const candidate = splitHash(hash).params.get("preview");
  return isThemeStudioPreviewSetId(candidate) ? candidate : DEFAULT_THEME_STUDIO_PREVIEW_SET_ID;
}

function updateStudioPreviewHash(hash: string, previewSetId: ThemeStudioPreviewSetId): string {
  const { path, params } = splitHash(hash);
  if (previewSetId === DEFAULT_THEME_STUDIO_PREVIEW_SET_ID) {
    params.delete("preview");
  } else {
    params.set("preview", previewSetId);
  }
  const query = params.toString();
  return `#${path || "/studio"}${query ? `?${query}` : ""}`;
}

function useHashValue(): [string, (nextHash: string) => void] {
  const [hash, setHash] = useState(() => window.location.hash || "#/");
  useEffect(() => {
    const on = () => setHash(window.location.hash || "#/");
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  const replaceHash = (nextHash: string) => {
    if (window.location.hash === nextHash) return;
    history.replaceState(null, "", nextHash);
    setHash(window.location.hash || "#/");
  };
  return [hash, replaceHash];
}

function themeById(themeId: ExplorerThemeId, available: readonly EmibsTheme[] = EXPLORER_THEMES): EmibsTheme {
  return available.find((theme) => theme.id === themeId) ?? neutralLightTheme;
}

function isExplorerThemeId(
  candidate: string | null,
  available: readonly EmibsTheme[] = EXPLORER_THEMES,
): candidate is ExplorerThemeId {
  return Boolean(candidate && available.some((theme) => theme.id === candidate));
}

function getStoredThemeId(available: readonly EmibsTheme[] = EXPLORER_THEMES): ExplorerThemeId | null {
  try {
    const candidate = window.localStorage.getItem(EXPLORER_THEME_STORAGE_KEY);
    return isExplorerThemeId(candidate, available) ? candidate : null;
  } catch {
    return null;
  }
}

function setStoredThemeId(themeId: ExplorerThemeId) {
  try {
    window.localStorage.setItem(EXPLORER_THEME_STORAGE_KEY, themeId);
  } catch {
    /* localStorage unavailable */
  }
}

function getSystemDefaultThemeId(): ExplorerThemeId {
  return window.matchMedia?.("(prefers-color-scheme: dark)").matches ? "neutral-dark" : DEFAULT_EXPLORER_THEME_ID;
}

function isApplePlatform(): boolean {
  if (typeof window === "undefined") return false;
  return /Mac|iPhone|iPad|iPod/.test(window.navigator.platform);
}

function isCommandPaletteShortcut(event: KeyboardEvent): boolean {
  if (event.key.toLowerCase() !== "k") return false;
  return isApplePlatform() ? event.metaKey : event.ctrlKey;
}

// ---------- color mode (light / dark / system) ----------
// Standard preference cascade: an explicit stored mode wins; "system" follows
// the OS via prefers-color-scheme (live). The mode governs which colorScheme
// variant of the active theme family is shown.

type ThemeMode = "light" | "dark" | "system";
const THEME_MODE_STORAGE_KEY = "emibs-ui-lib:theme-mode";

function getStoredMode(): ThemeMode {
  try {
    const value = window.localStorage.getItem(THEME_MODE_STORAGE_KEY);
    if (value === "light" || value === "dark" || value === "system") return value;
  } catch {
    /* localStorage unavailable */
  }
  return "system";
}

function setStoredMode(mode: ThemeMode) {
  try {
    window.localStorage.setItem(THEME_MODE_STORAGE_KEY, mode);
  } catch {
    /* localStorage unavailable */
  }
}

function systemPrefersDark(): boolean {
  return Boolean(window.matchMedia?.("(prefers-color-scheme: dark)").matches);
}

// Strip the trailing -light/-dark to get the family base (e.g. "catppuccin").
function themeFamilyBase(themeId: ExplorerThemeId): string {
  if (themeId.startsWith("custom-")) return themeId;
  return themeId.replace(/-(light|dark)$/, "");
}

// Resolve the active theme id for a mode: system → the OS scheme, else forced.
function resolveThemeForMode(themeId: ExplorerThemeId, mode: ThemeMode): ExplorerThemeId {
  if (themeId.startsWith("custom-")) return themeId;
  const scheme = mode === "system" ? (systemPrefersDark() ? "dark" : "light") : mode;
  const candidate = `${themeFamilyBase(themeId)}-${scheme}`;
  return isExplorerThemeId(candidate) ? candidate : themeId;
}

function themeFamilyLabel(theme: EmibsTheme): string {
  if (theme.id.startsWith("score-")) return "Score";
  if (theme.id.startsWith("elitua-")) return "eLitua";
  if (theme.id.startsWith("wander-")) return "Wander";
  if (theme.id.startsWith("reef-")) return "Reef";
  if (theme.id.startsWith("dusk-")) return "Dusk";
  if (theme.id.startsWith("santorini-")) return "Santorini";
  if (theme.id.startsWith("bondi-")) return "Bondi";
  if (theme.id.startsWith("amalfi-")) return "Amalfi";
  if (theme.id.startsWith("catppuccin-")) return "Catppuccin";
  if (theme.id.startsWith("tokyo-night-")) return "Tokyo Night";
  if (theme.id.startsWith("nord-")) return "Nord";
  if (theme.id.startsWith("rose-pine-")) return "Rosé Pine";
  if (theme.id.startsWith("solarized-")) return "Solarized";
  if (theme.id.startsWith("contrast-")) return "High contrast";
  if (theme.id.startsWith("custom-")) return "Custom";
  return "Neutral";
}

function groupedThemes(available: readonly EmibsTheme[] = EXPLORER_THEMES): { family: string; themes: readonly EmibsTheme[] }[] {
  const orderedGroups = [
    "Neutral", "eLitua", "Score", "Wander", "Reef", "Dusk", "Santorini", "Bondi", "Amalfi",
    "Catppuccin", "Tokyo Night", "Nord", "Rosé Pine", "Solarized", "High contrast",
  ]
    .map((family) => ({
      family,
      themes: available.filter((theme) => themeFamilyLabel(theme) === family),
    }))
    .filter((group) => group.themes.length > 0);
  const customGroups = available
    .filter((theme) => theme.id.startsWith("custom-"))
    .map((theme) => ({ family: theme.label, themes: [theme] }));
  return [...orderedGroups, ...customGroups];
}

const DEFAULT_PALETTE_COMPONENT_COUNT = 8;

type PalettePageKind = Route["kind"];

type PalettePageDefinition = {
  id: PalettePageKind;
  label: string;
  path: string;
  expectedKind: PalettePageKind;
};

const PALETTE_PAGES: readonly PalettePageDefinition[] = [
  { id: "gallery", label: "Gallery", path: "/", expectedKind: "gallery" },
  { id: "coverage", label: "Coverage", path: "/coverage", expectedKind: "coverage" },
  { id: "compare", label: "Compare", path: "/compare", expectedKind: "compare" },
  { id: "forms", label: "Forms", path: "/forms", expectedKind: "forms" },
  { id: "formBuilder", label: "Form Builder", path: "/forms/builder", expectedKind: "formBuilder" },
  { id: "foundations", label: "Foundations", path: "/foundations", expectedKind: "foundations" },
  { id: "matrix", label: "Matrix", path: "/matrix", expectedKind: "matrix" },
  { id: "studio", label: "Theme Studio", path: "/studio", expectedKind: "studio" },
  { id: "mockups", label: "Mockups", path: "/mockups", expectedKind: "mockups" },
];

function isPalettePageAvailable(page: PalettePageDefinition): boolean {
  const route = parseRoute(page.path);
  if (page.expectedKind === "gallery") return page.path === "/" && route.kind === "gallery";
  return route.kind === page.expectedKind;
}

// ---------- shared bits ----------

function SourceBadges({ entry }: { entry: ComponentEntry }) {
  return <SourceAppBadges sourceApp={entry.sourceApp} />;
}

function SourceAppBadges({ sourceApp }: { sourceApp: readonly (SourceApp | MockupSourceApp)[] }) {
  return (
    <span className="xpl-badges">
      {sourceApp.map((s) => (
        <span key={s} className={`xpl-badge xpl-badge--src-${s.toLowerCase()}`}>
          {s}
        </span>
      ))}
    </span>
  );
}

type AxeNode = { target: string[]; failureSummary?: string };
type AxeViolation = {
  id: string;
  impact?: string | null;
  description: string;
  help: string;
  helpUrl: string;
  nodes: AxeNode[];
};
type AxeAuditResult = {
  violations: AxeViolation[];
  passCount: number;
};

const AXE_WCAG_OPTIONS: RunOptions = {
  runOnly: { type: "tag", values: ["wcag2a", "wcag2aa", "wcag21a", "wcag21aa"] },
};

async function runAxe(node: HTMLElement): Promise<AxeAuditResult> {
  // Lazy-loaded so axe-core (heavy) ships as its own chunk, off the main bundle.
  const axe = (await import("axe-core")).default;
  const results = await axe.run(node, AXE_WCAG_OPTIONS);
  return {
    violations: results.violations as unknown as AxeViolation[],
    passCount: results.passes.length,
  };
}

function copyCssVars(source: HTMLElement, target: HTMLElement) {
  const styles = getComputedStyle(source);
  const copied = new Set<string>();
  themeTokenDefinitions.forEach((token) => {
    const value = styles.getPropertyValue(token.name);
    if (value) {
      target.style.setProperty(token.name, value);
      copied.add(token.name);
    }
  });
  for (let index = 0; index < styles.length; index += 1) {
    const property = styles.item(index);
    if (property.startsWith("--") && !copied.has(property)) {
      target.style.setProperty(property, styles.getPropertyValue(property));
    }
  }
}

function cloneAuditTarget(source: HTMLElement): HTMLElement {
  const clone = document.createElement("div");
  clone.className = "xpl-a11y-badge__clone";
  source.childNodes.forEach((child) => {
    clone.appendChild(child.cloneNode(true));
  });

  const walker = document.createTreeWalker(clone, NodeFilter.SHOW_ELEMENT);
  let current = walker.currentNode as Element | null;
  while (current) {
    current.removeAttribute("aria-hidden");
    current.removeAttribute("inert");
    current = walker.nextNode() as Element | null;
  }

  return clone;
}

async function runClonedAxe(source: HTMLElement): Promise<AxeAuditResult> {
  const sandbox = document.createElement("div");
  sandbox.className = "xpl-a11y-badge__sandbox";
  copyCssVars(source, sandbox);
  sandbox.appendChild(cloneAuditTarget(source));
  document.body.appendChild(sandbox);
  try {
    return await runAxe(sandbox);
  } finally {
    sandbox.remove();
  }
}

function A11yBadge({ entry, themeId }: { entry: ComponentEntry; themeId: ExplorerThemeId }) {
  const triggerRef = useRef<HTMLSpanElement>(null);
  const targetRef = useRef<HTMLDivElement>(null);
  const [active, setActive] = useState(false);
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [violations, setViolations] = useState<AxeViolation[]>([]);

  useEffect(() => {
    setActive(false);
    setStatus("idle");
    setViolations([]);
  }, [entry.id, themeId]);

  useEffect(() => {
    const trigger = triggerRef.current;
    if (!trigger) return;

    if (!("IntersectionObserver" in window)) {
      const timeout = globalThis.setTimeout(() => setActive(true), 220);
      return () => globalThis.clearTimeout(timeout);
    }

    const observer = new IntersectionObserver(
      (records) => {
        if (records.some((record) => record.isIntersecting)) {
          setActive(true);
          observer.disconnect();
        }
      },
      { rootMargin: "120px" },
    );
    observer.observe(trigger);
    return () => observer.disconnect();
  }, [entry.id, themeId]);

  useEffect(() => {
    if (!active || status !== "idle") return;
    const timeout = globalThis.setTimeout(() => {
      const target = targetRef.current;
      if (!target) return;
      setStatus("running");
      runClonedAxe(target)
        .then((result) => {
          setViolations(result.violations);
          setStatus("done");
        })
        .catch(() => {
          setStatus("error");
        });
    }, 120);
    return () => globalThis.clearTimeout(timeout);
  }, [active, status]);

  const issueCount = violations.length;
  const label =
    status === "done"
      ? issueCount
        ? `${issueCount} accessibility issue${issueCount === 1 ? "" : "s"}`
        : "Accessibility audit passed"
      : "Accessibility audit pending";

  return (
    <span ref={triggerRef} className="xpl-a11y-badge-wrap">
      {status !== "error" && (
        <span
          className={`xpl-a11y-badge ${
            status === "done" ? (issueCount ? "is-fail" : "is-pass") : "is-pending"
          }`}
          aria-label={`${entry.name}: ${label}`}
          title={label}
        >
          {status === "done" && issueCount === 0 ? <Check size={12} aria-hidden="true" /> : null}
          {status === "done" && issueCount > 0 ? `${issueCount} a11y` : status === "done" ? "a11y" : "a11y…"}
        </span>
      )}
      {active && (
        <div ref={targetRef} className="xpl-a11y-badge__target" inert={true} aria-hidden="true">
          {entry.render()}
        </div>
      )}
    </span>
  );
}

// ---------- sidebar ----------

type FacetKey = "category" | "sourceApp" | "pattern" | "status" | "hasSpec" | "theme";
type FacetMode = "or" | "and";
type FacetSelections = Record<FacetKey, string[]>;
type FacetModes = Record<FacetKey, FacetMode>;
export type CatalogViewState = {
  query: string;
  axis: GroupAxis;
  facets: FacetSelections;
  facetModes: FacetModes;
};

const DEFAULT_CATALOG_AXIS: GroupAxis = "category";

const emptyFacets = (): FacetSelections => ({
  category: [],
  sourceApp: [],
  pattern: [],
  status: [],
  hasSpec: [],
  theme: [],
});

const defaultFacetModes: FacetModes = {
  category: "or",
  sourceApp: "or",
  pattern: "or",
  status: "or",
  hasSpec: "or",
  theme: "or",
};

const categoryLabels: Record<Category, string> = {
  primitives: "Primitives",
  layout: "Layout",
  data: "Data",
  feedback: "Feedback",
  auth: "Auth",
};

const statusLabels: Record<EntryStatus, string> = {
  catalogued: "Catalogued",
  "demo-migrated": "Demo migrated",
  active: "Active",
  adopted: "Adopted",
};

const facetOrder: { key: FacetKey; label: string }[] = [
  { key: "category", label: "Category" },
  { key: "sourceApp", label: "Source" },
  { key: "pattern", label: "Pattern" },
  { key: "status", label: "Status" },
  { key: "hasSpec", label: "Spec" },
  { key: "theme", label: "Theme" },
];

type FacetOption = { value: string; label: string };
type FacetOptions = Record<FacetKey, FacetOption[]>;

function uniqueSorted(values: string[]): string[] {
  return Array.from(new Set(values)).sort((a, b) => a.localeCompare(b));
}

function buildFacetOptions(items: readonly ComponentEntry[]): FacetOptions {
  const categories = uniqueSorted(items.map((entry) => entry.category));
  const statuses = uniqueSorted(items.map((entry) => entry.status));
  return {
    category: categories.map((value) => ({ value, label: categoryLabels[value as Category] ?? value })),
    sourceApp: uniqueSorted(items.flatMap((entry) => entry.sourceApp)).map((value) => ({ value, label: value })),
    pattern: uniqueSorted(items.flatMap((entry) => entry.patterns)).map((value) => ({ value, label: value })),
    status: statuses.map((value) => ({ value, label: statusLabels[value as EntryStatus] ?? value })),
    hasSpec: [
      { value: "with-spec", label: "Has spec" },
      { value: "without-spec", label: "No spec" },
    ],
    theme: EXPLORER_THEMES.map((theme) => ({ value: theme.id, label: theme.label })),
  };
}

function isGroupAxis(candidate: string | null): candidate is GroupAxis {
  return Boolean(candidate && AXES.some((axis) => axis.axis === candidate));
}

function normalizeFacetValues(key: FacetKey, values: readonly string[], options: FacetOptions): string[] {
  const valid = new Set(options[key].map((option) => option.value));
  const seen = new Set<string>();
  const normalized: string[] = [];
  values.forEach((raw) => {
    const value = raw.trim();
    if (!value || seen.has(value) || !valid.has(value)) return;
    seen.add(value);
    normalized.push(value);
  });
  return normalized;
}

function sanitizeCatalogViewState(
  state: CatalogViewState,
  options: FacetOptions = buildFacetOptions(entries),
): CatalogViewState {
  const facets = emptyFacets();
  const facetModes: FacetModes = { ...defaultFacetModes };

  facetOrder.forEach(({ key }) => {
    facets[key] = normalizeFacetValues(key, state.facets[key] ?? [], options);
    facetModes[key] = state.facetModes[key] === "and" ? "and" : "or";
  });

  return {
    query: state.query,
    axis: isGroupAxis(state.axis) ? state.axis : DEFAULT_CATALOG_AXIS,
    facets,
    facetModes,
  };
}

export function parseCatalogViewState(
  hash: string,
  options: FacetOptions = buildFacetOptions(entries),
): CatalogViewState {
  const params = splitHash(hash).params;
  const facets = emptyFacets();
  const facetModes: FacetModes = { ...defaultFacetModes };

  facetOrder.forEach(({ key }) => {
    const rawFacet = params.get(`${FACET_PARAM_PREFIX}${key}`);
    facets[key] = rawFacet ? rawFacet.split(",") : [];
    facetModes[key] = params.get(`${FACET_MODE_PARAM_PREFIX}${key}`) === "and" ? "and" : "or";
  });

  return sanitizeCatalogViewState(
    {
      query: params.get(QUERY_PARAM) ?? "",
      axis: isGroupAxis(params.get(AXIS_PARAM)) ? (params.get(AXIS_PARAM) as GroupAxis) : DEFAULT_CATALOG_AXIS,
      facets,
      facetModes,
    },
    options,
  );
}

export function serializeCatalogViewState(
  state: CatalogViewState,
  options: FacetOptions = buildFacetOptions(entries),
): URLSearchParams {
  const normalized = sanitizeCatalogViewState(state, options);
  const params = new URLSearchParams();

  if (normalized.query) params.set(QUERY_PARAM, normalized.query);
  if (normalized.axis !== DEFAULT_CATALOG_AXIS) params.set(AXIS_PARAM, normalized.axis);

  facetOrder.forEach(({ key }) => {
    const selected = normalized.facets[key];
    if (selected.length > 0) params.set(`${FACET_PARAM_PREFIX}${key}`, selected.join(","));
  });

  facetOrder.forEach(({ key }) => {
    if (normalized.facetModes[key] !== defaultFacetModes[key]) {
      params.set(`${FACET_MODE_PARAM_PREFIX}${key}`, normalized.facetModes[key]);
    }
  });

  return params;
}

function isCatalogViewParamKey(key: string): boolean {
  return key === QUERY_PARAM || key === AXIS_PARAM || key.startsWith(FACET_PARAM_PREFIX) || key.startsWith(FACET_MODE_PARAM_PREFIX);
}

function replaceCatalogViewParams(
  params: URLSearchParams,
  state: CatalogViewState,
  options: FacetOptions = buildFacetOptions(entries),
) {
  Array.from(params.keys()).forEach((key) => {
    if (isCatalogViewParamKey(key)) params.delete(key);
  });

  serializeCatalogViewState(state, options).forEach((value, key) => {
    params.set(key, value);
  });
}

export function updateCatalogViewHash(
  hash: string,
  state: CatalogViewState,
  options: FacetOptions = buildFacetOptions(entries),
): string {
  const { path, params } = splitHash(hash);
  replaceCatalogViewParams(params, state, options);
  const query = params.toString();
  return `#${path || "/"}${query ? `?${query}` : ""}`;
}

export function hashForPathFromHash(
  hash: string,
  path: string,
  themeId: ExplorerThemeId,
  extraParams?: HashParamOverrides,
  options: FacetOptions = buildFacetOptions(entries),
): string {
  const params = new URLSearchParams();
  replaceCatalogViewParams(params, parseCatalogViewState(hash, options), options);

  const currentCompare = currentCompareParam(hash);
  if (currentCompare) params.set(COMPARE_PARAM, currentCompare);

  const currentDensity = parseDensity(hash);
  if (currentDensity !== DEFAULT_DENSITY) params.set(DENSITY_PARAM, currentDensity);

  Object.entries(extraParams ?? {}).forEach(([key, value]) => {
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
  });

  if (themeId !== DEFAULT_EXPLORER_THEME_ID) params.set("theme", themeId);
  const query = params.toString();
  return `#${path || "/"}${query ? `?${query}` : ""}`;
}

function compatibleThemeIds(entry: ComponentEntry): string[] {
  return EXPLORER_THEMES.filter((theme) => {
    const id = theme.id.toLowerCase();
    if (id.includes("neutral")) return true;
    if (id.includes("score")) return entry.sourceApp.includes("Score") || entry.sourceApp.includes("Shared");
    if (id.includes("elitua")) return entry.sourceApp.includes("eLitua") || entry.sourceApp.includes("Shared");
    return true;
  }).map((theme) => theme.id);
}

function valuesForFacet(entry: ComponentEntry, key: FacetKey): string[] {
  switch (key) {
    case "category":
      return [entry.category];
    case "sourceApp":
      return entry.sourceApp;
    case "pattern":
      return entry.patterns;
    case "status":
      return [entry.status];
    case "hasSpec":
      return [entry.hasSpec ? "with-spec" : "without-spec"];
    case "theme":
      return compatibleThemeIds(entry);
  }
}

function matchesFacets(entry: ComponentEntry, selections: FacetSelections, modes: FacetModes): boolean {
  return facetOrder.every(({ key }) => {
    const selected = selections[key];
    if (selected.length === 0) return true;
    const values = valuesForFacet(entry, key);
    return modes[key] === "and"
      ? selected.every((value) => values.includes(value))
      : selected.some((value) => values.includes(value));
  });
}

function filterEntries(items: ComponentEntry[], query: string, selections: FacetSelections, modes: FacetModes): ComponentEntry[] {
  return items.filter((entry) => matches(entry, query) && matchesFacets(entry, selections, modes));
}

function matchesThemeQuery(theme: EmibsTheme, query: string): boolean {
  const normalizedQuery = query.trim().toLowerCase();
  if (!normalizedQuery) return true;
  const haystack = `${theme.label} ${theme.id}`.toLowerCase();
  return normalizedQuery
    .split(/\s+/)
    .filter(Boolean)
    .every((term) => haystack.includes(term));
}

function hasFacetSelections(selections: FacetSelections): boolean {
  return facetOrder.some(({ key }) => selections[key].length > 0);
}

function FacetPanel({
  options,
  selections,
  modes,
  resultCount,
  onToggle,
  onSetMode,
  onClear,
}: {
  options: FacetOptions;
  selections: FacetSelections;
  modes: FacetModes;
  resultCount: number;
  onToggle: (key: FacetKey, value: string) => void;
  onSetMode: (key: FacetKey, mode: FacetMode) => void;
  onClear: () => void;
}) {
  const active = hasFacetSelections(selections);
  return (
    <section className="xpl-facets" aria-label="Catalog filters">
      <div className="xpl-facets__head">
        <strong>Filters</strong>
        <span>{resultCount} results</span>
      </div>
      {facetOrder.map(({ key, label }) => (
        <div key={key} className="xpl-facet">
          <div className="xpl-facet__head">
            <span>{label}</span>
            <span className="xpl-facet__mode" role="group" aria-label={`${label} mode`}>
              {(["or", "and"] as const).map((mode) => (
                <button
                  key={mode}
                  type="button"
                  className={modes[key] === mode ? "is-active" : ""}
                  onClick={() => onSetMode(key, mode)}
                >
                  {mode.toUpperCase()}
                </button>
              ))}
            </span>
          </div>
          <div className="xpl-facet__options">
            {options[key].map((option) => {
              const selected = selections[key].includes(option.value);
              return (
                <button
                  key={option.value}
                  type="button"
                  className={selected ? "is-selected" : ""}
                  onClick={() => onToggle(key, option.value)}
                  aria-pressed={selected}
                >
                  {option.label}
                </button>
              );
            })}
          </div>
        </div>
      ))}
      {active && (
        <button type="button" className="xpl-facets__clear" onClick={onClear}>
          Clear filters
        </button>
      )}
    </section>
  );
}

function Sidebar({
  axis,
  setAxis,
  query,
  setQuery,
  themeId,
  filteredEntries,
  facetOptions,
  facets,
  facetModes,
  onToggleFacet,
  onSetFacetMode,
  onClearFacets,
  activeId,
  activeRouteKind,
  open,
  onClose,
  onNavigate,
  onThemeSelect,
  themes: availableThemes,
}: {
  axis: GroupAxis;
  setAxis: (a: GroupAxis) => void;
  query: string;
  setQuery: (q: string) => void;
  themeId: ExplorerThemeId;
  themes: readonly EmibsTheme[];
  filteredEntries: ComponentEntry[];
  facetOptions: FacetOptions;
  facets: FacetSelections;
  facetModes: FacetModes;
  onToggleFacet: (key: FacetKey, value: string) => void;
  onSetFacetMode: (key: FacetKey, mode: FacetMode) => void;
  onClearFacets: () => void;
  activeId?: string;
  activeRouteKind: Route["kind"];
  open: boolean;
  onClose: () => void;
  onNavigate: () => void;
  onThemeSelect: (themeId: ExplorerThemeId) => void;
}) {
  const componentGroups = useMemo(() => {
    const entries = query.trim()
      ? filteredEntries
      : [...filteredEntries].sort((a, b) => a.name.localeCompare(b.name)).slice(0, DEFAULT_PALETTE_COMPONENT_COUNT);
    return groupBy(entries, axis);
  }, [axis, filteredEntries, query]);

  const noQuery = query.trim() === "";
  const normalizedQuery = query.trim().toLowerCase();
  const themeMatches = useMemo(
    () => availableThemes.filter((theme) => matchesThemeQuery(theme, query)),
    [availableThemes, query],
  );

  const pageCandidates = useMemo(() => PALETTE_PAGES.filter(isPalettePageAvailable), []);
  const pageMatches = useMemo(
    () =>
      pageCandidates.filter((page) => !normalizedQuery || page.label.toLowerCase().includes(normalizedQuery)),
    [pageCandidates, normalizedQuery],
  );
  const isPageActive = (page: PalettePageDefinition) =>
    activeRouteKind === page.expectedKind || (page.expectedKind === "mockups" && activeRouteKind === "mockup");

  const hasAnyMatches = componentGroups.some((group) => group.items.length > 0) || themeMatches.length > 0 || pageMatches.length > 0;
  const [collapsed, setCollapsed] = useState<Set<string>>(new Set());

  const toggle = (key: string) =>
    setCollapsed((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });

  return (
    <aside className={`xpl-side ${open ? "is-open" : ""}`} aria-label="Catalog navigation">
      <div className="xpl-brand-row">
        <a
          className="xpl-brand"
          href={hashForPath("/", themeId, { [QUERY_PARAM]: null })}
          onClick={() => {
            setQuery("");
            onNavigate();
          }}
        >
          <span className="xpl-brand__mark">E</span>
          <span>
            <strong>emibs-ui-lib</strong>
            <small>Catalog Explorer</small>
          </span>
        </a>
        <button type="button" className="xpl-side__close" aria-label="Close catalog navigation" onClick={onClose}>
          <X size={18} />
        </button>
      </div>

      <input
        className="xpl-search"
        type="search"
        placeholder="Search components, themes, pages…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        aria-label="Search catalog"
      />

      <div className="xpl-axes" role="tablist" aria-label="Group by">
        {AXES.map((a) => (
          <button
            key={a.axis}
            type="button"
            className={`xpl-axis ${axis === a.axis ? "is-active" : ""}`}
            onClick={() => setAxis(a.axis)}
          >
            {a.label}
          </button>
        ))}
      </div>

      <FacetPanel
        options={facetOptions}
        selections={facets}
        modes={facetModes}
        resultCount={filteredEntries.length}
        onToggle={onToggleFacet}
        onSetMode={onSetFacetMode}
        onClear={onClearFacets}
      />

      <nav className="xpl-nav" aria-label="Search results">
        {query.trim() && !hasAnyMatches && (
          <p className="xpl-nav__empty">No results match “{query}”.</p>
        )}

        {!hasAnyMatches ? null : (
          <>
            <section className="xpl-group">
              <div className="xpl-group__head">
                <span>Components</span>
                <span className="xpl-group__count">
                  {noQuery
                    ? Math.min(filteredEntries.length, DEFAULT_PALETTE_COMPONENT_COUNT)
                    : componentGroups.reduce((sum, group) => sum + group.items.length, 0)}
                </span>
              </div>
              {componentGroups.length === 0 && <p className="xpl-nav__empty">No components match “{query}”.</p>}
              {componentGroups.map((group) => {
                const isCollapsed = collapsed.has(group.key);
                return (
                  <div key={group.key} className="xpl-group">
                    <button type="button" className="xpl-group__head" onClick={() => toggle(group.key)}>
                      {isCollapsed ? <ChevronRight size={14} /> : <ChevronDown size={14} />}
                      <span>{group.label}</span>
                      <span className="xpl-group__count">{group.items.length}</span>
                    </button>
                    {!isCollapsed && (
                      <ul className="xpl-group__list">
                        {group.items.map((item) => (
                          <li key={item.id}>
                            <a
                              className={`xpl-nav__item ${activeId === item.id ? "is-active" : ""}`}
                              href={hashForPath(`/c/${item.id}`, themeId)}
                              onClick={onNavigate}
                            >
                              <span>{item.name}</span>
                              {getEntry(item.id) && isMigrated(getEntry(item.id)!) && (
                                <span className="xpl-dot" title="Demo migrated" />
                              )}
                            </a>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                );
              })}
            </section>

            <section className="xpl-group">
              <div className="xpl-group__head">
                <span>Themes</span>
                <span className="xpl-group__count">{themeMatches.length}</span>
              </div>
              {themeMatches.length === 0 && <p className="xpl-nav__empty">No themes match “{query}”.</p>}
              {themeMatches.length > 0 && (
                <ul className="xpl-group__list">
                  {themeMatches.map((theme) => (
                    <li key={theme.id}>
                      <button
                        type="button"
                        className={`xpl-nav__item ${themeId === theme.id ? "is-active" : ""}`}
                        onClick={() => {
                          onThemeSelect(theme.id);
                          onNavigate();
                        }}
                      >
                        <span>{theme.label}</span>
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </section>

            <section className="xpl-group">
              <div className="xpl-group__head">
                <span>Pages</span>
                <span className="xpl-group__count">{pageMatches.length}</span>
              </div>
              {pageMatches.length === 0 && <p className="xpl-nav__empty">No pages match “{query}”.</p>}
              {pageMatches.length > 0 && (
                <ul className="xpl-group__list">
                  {pageMatches.map((page) => (
                    <li key={page.id}>
                      <a
                        className={`xpl-nav__item ${
                          isPageActive(page) ? "is-active" : ""
                        }`}
                        href={hashForPath(page.path, themeId)}
                        onClick={onNavigate}
                      >
                        <span>{page.label}</span>
                      </a>
                    </li>
                  ))}
                </ul>
              )}
            </section>
          </>
        )}
      </nav>

      <div className="xpl-side__foot">
        <span>{entries.length} components</span>
      </div>
    </aside>
  );
}

// ---------- gallery ----------

function Gallery({
  axis,
  query,
  themeId,
  filteredEntries,
  filtersActive,
  compareIds,
  onToggleCompare,
}: {
  axis: GroupAxis;
  query: string;
  themeId: ExplorerThemeId;
  filteredEntries: ComponentEntry[];
  filtersActive: boolean;
  compareIds: readonly string[];
  onToggleCompare: (id: string) => void;
}) {
  const filtered = filteredEntries;
  const groups = useMemo(() => groupBy(filtered, axis), [filtered, axis]);
  const total = filtered.length;

  return (
    <div className="xpl-gallery">
      <header className="xpl-gallery__head">
        <h1>Component catalog</h1>
        <p>
          {total} component{total === 1 ? "" : "s"}
          {query ? ` matching “${query}”` : filtersActive ? " in the selected facets" : ""} · grouped by{" "}
          {AXES.find((a) => a.axis === axis)?.label.toLowerCase()}
        </p>
      </header>

      {groups.length === 0 && <p className="xpl-empty-note">No components match the current filters.</p>}

      {groups.map((group) => (
        <section key={group.key} className="xpl-gallery__group">
          <h2>
            {group.label} <span className="xpl-group__count">{group.items.length}</span>
          </h2>
          <div className="xpl-grid">
            {group.items.map((item) => {
              const entry = getEntry(item.id)!;
              const migrated = isMigrated(entry);
              const pinned = compareIds.includes(entry.id);
              return (
                <article key={item.id} className="xpl-card">
                  <div className="xpl-card__top">
                    <span className="xpl-card__title">
                      <strong>{entry.name}</strong>
                      {migrated ? (
                        <span className="xpl-dot" title="Demo migrated" />
                      ) : (
                        <span className="xpl-dot xpl-dot--pending" title="Migration pending" />
                      )}
                    </span>
                    {migrated && (
                      <button
                        type="button"
                        className={`xpl-card__pin ${pinned ? "is-active" : ""}`}
                        onClick={() => onToggleCompare(entry.id)}
                        aria-label={`${pinned ? "Unpin" : "Pin"} ${entry.name} for compare`}
                        aria-pressed={pinned}
                        title={`${pinned ? "Unpin" : "Pin"} for compare`}
                      >
                        <Pin size={13} aria-hidden="true" />
                        <span>{pinned ? "Pinned" : "Pin"}</span>
                      </button>
                    )}
                  </div>
                  <div className="xpl-card__preview" inert={true} aria-hidden="true">
                    {migrated ? (
                      <LazyPreview render={entry.render} />
                    ) : (
                      <div className="xpl-card__preview-pending">
                        <span>Demo pending</span>
                      </div>
                    )}
                  </div>
                  <span className="xpl-card__cat">{entry.category}</span>
                  <SourceBadges entry={entry} />
                  <a className="xpl-card__inspect" href={hashForPath(`/c/${item.id}`, themeId)}>
                    Inspect
                    <ChevronRight size={14} aria-hidden="true" />
                  </a>
                </article>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}

// ---------- coverage ----------

function CoverageStateBadge({ complete }: { complete: boolean }) {
  return (
    <span className={`xpl-coverage-pill ${complete ? "is-complete" : "is-missing"}`}>
      {complete ? "Ready" : "Gap"}
    </span>
  );
}

function CoveragePage({ themeId }: { themeId: ExplorerThemeId }) {
  const [category, setCategory] = useState<Category | "all">("all");

  // Category options are derived from the registry (only categories that
  // actually have entries appear), never a hardcoded list.
  const categoryOptions = useMemo(() => {
    const present = new Set(entries.map((entry) => entry.category));
    return (Object.keys(categoryLabels) as Category[])
      .filter((key) => present.has(key))
      .map((key) => ({ value: key, label: categoryLabels[key] }));
  }, []);

  const visibleEntries = useMemo(
    () => (category === "all" ? entries : entries.filter((entry) => entry.category === category)),
    [category],
  );
  const filtered = category !== "all";
  const scopeLabel = filtered ? categoryLabels[category] : "all categories";

  const report = useMemo(() => buildCoverageReport(visibleEntries), [visibleEntries]);
  const rows = report.rows;
  const totals = useMemo(
    () =>
      coverageFacets.map((facet) => {
        const completed = visibleEntries.filter((entry) => facet.complete(entry)).length;
        return { ...facet, completed, total: visibleEntries.length };
      }),
    [visibleEntries],
  );
  const overallCompleted = report.completed;
  const overallTotal = report.total;

  return (
    <div className="xpl-coverage">
      <header className="xpl-gallery__head xpl-coverage__head">
        <h1>Coverage dashboard</h1>
        <p>
          Registry-derived completeness across {visibleEntries.length}{" "}
          {filtered ? `${categoryLabels[category]} ` : "catalog "}
          {visibleEntries.length === 1 ? "entry" : "entries"}, sorted least complete first. The
          denominator is those entries and no others: a component that is exported but never
          catalogued is not counted as incomplete here, it is not counted at all. The build gate{" "}
          <code>scripts/check-catalog-registration.mjs</code> is what keeps that gap from growing.
        </p>
      </header>

      <div className="xpl-coverage__controls">
        <label className="xpl-coverage__filter" htmlFor="xpl-coverage-category">
          <span>Category</span>
          <select
            id="xpl-coverage-category"
            className="xpl-coverage__category-select"
            value={category}
            onChange={(event) => setCategory(event.target.value as Category | "all")}
          >
            <option value="all">All categories</option>
            {categoryOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
        <span className="xpl-coverage__filter-note" aria-live="polite">
          {rows.length} of {entries.length} entries shown
        </span>
      </div>

      <section className="xpl-coverage__summary" aria-label={`Coverage summary for ${scopeLabel}`}>
        <article className="xpl-coverage__metric">
          <strong>{coveragePercent(overallCompleted, overallTotal)}%</strong>
          <span>Overall coverage</span>
          <small>
            {overallCompleted}/{overallTotal} checks complete
          </small>
        </article>
        {totals.map((total) => (
          <article className="xpl-coverage__metric" key={total.key}>
            <strong>{coveragePercent(total.completed, total.total)}%</strong>
            <span>{total.label}</span>
            <small>
              {total.completed}/{total.total} entries
            </small>
          </article>
        ))}
      </section>

      <div className="xpl-coverage__table-wrap">
        <table className="xpl-coverage__table">
          <thead>
            <tr>
              <th scope="col">Component</th>
              <th scope="col">Status</th>
              {coverageFacets.map((facet) => (
                <th key={facet.key} scope="col">{facet.label}</th>
              ))}
              <th scope="col">Score</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.entry.id}>
                <th scope="row">
                  <a href={hashForPath(`/c/${row.entry.id}`, themeId)}>{row.entry.name}</a>
                  <span>{categoryLabels[row.entry.category]}</span>
                </th>
                <td>
                  <span className="xpl-coverage-pill xpl-coverage-pill--status">
                    {statusLabels[row.entry.status]}
                  </span>
                </td>
                {coverageFacets.map((facet) => (
                  <td key={facet.key}>
                    <CoverageStateBadge complete={facet.complete(row.entry)} />
                  </td>
                ))}
                <td>
                  <span className="xpl-coverage__score">
                    {row.completed}/{row.total}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ---------- mockups ----------

function MockupGallery({ themeId }: { themeId: ExplorerThemeId }) {
  return (
    <div className="xpl-gallery">
      <header className="xpl-gallery__head">
        <h1>Templates and mockups</h1>
        <p>
          {mockupEntries.filter((entry) => entry.sourcePath).length} page templates you can copy into a product, and{" "}
          {mockupEntries.filter((entry) => !entry.sourcePath).length} full-page mockups assembled from catalog components.
        </p>
      </header>
      <div className="xpl-mockup-grid">
        {mockupEntries.map((entry) => (
          <a key={entry.id} className="xpl-mockup-card" href={hashForPath(`/m/${entry.id}`, themeId)}>
            <div className="xpl-card__top">
              <strong>{entry.name}</strong>
              <span className={`xpl-dot ${entry.status === "draft" ? "xpl-dot--pending" : ""}`} title={entry.status} />
            </div>
            <p>{entry.description}</p>
            <SourceAppBadges sourceApp={entry.sourceApp} />
            {entry.sourcePath ? <span className="xpl-badge xpl-badge--cat">Template</span> : null}
            <dl className="xpl-mockup-card__facts">
              <div>
                <dt>Slots</dt>
                <dd>{entry.slots.length}</dd>
              </div>
              <div>
                <dt>Components</dt>
                <dd>{entry.componentIds.length}</dd>
              </div>
              <div>
                <dt>Status</dt>
                <dd>{entry.status}</dd>
              </div>
            </dl>
          </a>
        ))}
      </div>
    </div>
  );
}

function MockupInspectPage({ id, theme, themeId }: { id: string; theme: EmibsTheme; themeId: ExplorerThemeId }) {
  const entry = getMockup(id);
  const [width, setWidth] = useState("full");
  const [copied, setCopied] = useState(false);

  if (!entry) {
    return (
      <div className="xpl-inspect">
        <p className="xpl-empty-note">Unknown mockup "{id}". <a href="#/mockups">Back to mockups</a>.</p>
      </div>
    );
  }

  const widthChoice = WIDTHS.find((w) => w.id === width) ?? WIDTHS[WIDTHS.length - 1];
  const widthPx = widthChoice.px ?? null;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(`${location.origin}${location.pathname}${hashForPath(`/m/${entry.id}`, themeId)}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <div className="xpl-inspect xpl-inspect--mockup">
      <MockupMetaHeader entry={entry} copied={copied} onCopy={copyLink} />
      <CanvasWidthBar width={width} setWidth={setWidth} widthPx={widthPx} />
      <ThemeScope className="xpl-canvas xpl-canvas--mockup" theme={theme}>
        <div
          className={`xpl-mockup-frame xpl-mockup-frame--${widthChoice.id}`}
          style={widthPx ? { width: widthPx, maxWidth: "100%" } : undefined}
          aria-label={`${entry.name} ${widthChoice.label.toLowerCase()} preview frame`}
        >
          <div className="xpl-mockup-frame__chrome" aria-hidden="true">
            <span>{widthChoice.label}</span>
            <span>{widthPx ? `${widthPx}px` : "fluid"}</span>
          </div>
          <div className="xpl-mockup-frame__screen">
            <div className="xpl-canvas__stage xpl-canvas__stage--mockup">{entry.render()}</div>
          </div>
        </div>
      </ThemeScope>
      <MockupSource sourcePath={entry.sourcePath} />
    </div>
  );
}

function MockupMetaHeader({
  entry,
  copied,
  onCopy,
}: {
  entry: MockupEntry;
  copied: boolean;
  onCopy: () => void;
}) {
  return (
    <header className="xpl-meta">
      <nav className="xpl-crumb">
        <a href="#/mockups">Mockups</a>
        <ChevronRight size={13} />
        <strong>{entry.name}</strong>
      </nav>
      <div className="xpl-meta__row">
        <h1>{entry.name}</h1>
        <button type="button" className="xpl-copy" onClick={onCopy}>
          {copied ? <Check size={14} /> : <Link2 size={14} />}
          {copied ? "Copied" : "Copy link"}
        </button>
      </div>
      <p className="xpl-meta__description">{entry.description}</p>
      <div className="xpl-meta__tags">
        <span className="xpl-badge xpl-badge--cat">{entry.status}</span>
        <SourceAppBadges sourceApp={entry.sourceApp} />
        {entry.patterns.map((pattern) => (
          <span key={pattern} className="xpl-badge">
            {pattern}
          </span>
        ))}
      </div>
      <dl className="xpl-mockup-summary">
        <div>
          <dt>Slots</dt>
          <dd>{entry.slots.join(", ")}</dd>
        </div>
        <div>
          <dt>Components</dt>
          <dd>{entry.componentIds.join(", ")}</dd>
        </div>
      </dl>
    </header>
  );
}

// ---------- theme matrix ----------

function ThemeMatrixPage() {
  const matrixEntries = MATRIX_ENTRY_IDS.map((id) => getEntry(id)).filter((entry): entry is ComponentEntry =>
    Boolean(entry && isMigrated(entry)),
  );

  return (
    <div className="xpl-gallery xpl-matrix">
      <header className="xpl-gallery__head">
        <h1>Theme matrix</h1>
        <p>
          {matrixEntries.length} migrated component{matrixEntries.length === 1 ? "" : "s"} rendered across{" "}
          {EXPLORER_THEMES.length} selectable themes.
        </p>
      </header>

      <div className="xpl-matrix__grid">
        {EXPLORER_THEMES.map((theme) => (
          <ThemeScope key={theme.id} className="xpl-matrix__theme" theme={theme}>
            <header className="xpl-matrix__theme-head">
              <span
                className="xpl-theme-picker__swatch"
                style={{
                  background: getThemeToken(theme, "--accent"),
                  borderColor: getThemeToken(theme, "--border-strong"),
                }}
              />
              <div>
                <strong>{theme.label}</strong>
                <small>{theme.colorScheme}</small>
              </div>
            </header>
            <div className="xpl-matrix__stack">
              {matrixEntries.map((entry) => (
                <section key={entry.id} className="xpl-matrix__sample">
                  <h2>{entry.name}</h2>
                  <div className="xpl-matrix__sample-stage">{entry.render()}</div>
                </section>
              ))}
            </div>
          </ThemeScope>
        ))}
      </div>
    </div>
  );
}

// ---------- inspect ----------

const WIDTHS: { id: string; label: string; px: number | null; icon: ReactNode }[] = [
  { id: "mobile", label: "Mobile", px: 390, icon: <Smartphone size={15} /> },
  { id: "tablet", label: "Tablet", px: 768, icon: <Tablet size={15} /> },
  { id: "desktop", label: "Desktop", px: 1180, icon: <Monitor size={15} /> },
  { id: "full", label: "Full", px: null, icon: <Square size={15} /> },
];

type InspectTab = "preview" | "playground" | "variants" | "states" | "usage" | "props" | "audit" | "spec";

const INSPECT_TABS: { id: InspectTab; label: string }[] = [
  { id: "preview", label: "Preview" },
  { id: "playground", label: "Playground" },
  { id: "variants", label: "Variants" },
  { id: "states", label: "States" },
  { id: "usage", label: "Usage" },
  { id: "props", label: "Props" },
  { id: "audit", label: "Audit" },
  { id: "spec", label: "Spec" },
];

function CanvasWidthBar({
  width,
  setWidth,
  widthPx,
}: {
  width: string;
  setWidth: (width: string) => void;
  widthPx: number | null;
}) {
  return (
    <div className="xpl-canvas-bar">
      <div className="xpl-seg">
        {WIDTHS.map((w) => (
          <button
            key={w.id}
            type="button"
            className={width === w.id ? "is-active" : ""}
            onClick={() => setWidth(w.id)}
            title={w.label}
            aria-label={`${width === w.id ? "Current" : "Set"} canvas width to ${w.label}`}
            aria-pressed={width === w.id}
          >
            {w.icon}
          </button>
        ))}
      </div>
      <span className="xpl-canvas-bar__w">{widthPx ? `${widthPx}px` : "100%"}</span>
    </div>
  );
}

function playgroundDefaults(entry: ComponentEntry): PlaygroundProps {
  return Object.fromEntries(entry.playground?.controls.map((control) => [control.name, control.default]) ?? []);
}

function controlString(control: PlaygroundControl, value: PlaygroundControlValue | undefined): string {
  return typeof value === "string" ? value : String(control.default ?? "");
}

function controlNumber(control: PlaygroundControl, value: PlaygroundControlValue | undefined): number {
  return typeof value === "number" && Number.isFinite(value) ? value : Number(control.default);
}

function PlaygroundControlField({
  entryId,
  control,
  value,
  onChange,
}: {
  entryId: string;
  control: PlaygroundControl;
  value: PlaygroundControlValue | undefined;
  onChange: (value: PlaygroundControlValue) => void;
}) {
  const inputId = `xpl-playground-${entryId}-${control.name}`;

  if (control.kind === "boolean") {
    const checked = value === true;
    return (
      <label className="xpl-playground-control xpl-playground-control--toggle" htmlFor={inputId}>
        <span className="xpl-playground-control__label">{control.label}</span>
        <span className="xpl-playground-toggle">
          <input
            id={inputId}
            checked={checked}
            role="switch"
            type="checkbox"
            onChange={(event) => onChange(event.currentTarget.checked)}
          />
          <span aria-hidden="true" />
        </span>
      </label>
    );
  }

  if (control.kind === "enum" || control.kind === "node") {
    return (
      <label className="xpl-playground-control" htmlFor={inputId}>
        <span className="xpl-playground-control__label">{control.label}</span>
        <select id={inputId} value={controlString(control, value)} onChange={(event) => onChange(event.currentTarget.value)}>
          {control.options.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </label>
    );
  }

  if (control.kind === "number") {
    return (
      <label className="xpl-playground-control" htmlFor={inputId}>
        <span className="xpl-playground-control__label">{control.label}</span>
        <input
          id={inputId}
          type="number"
          value={controlNumber(control, value)}
          onChange={(event) => onChange(Number.isNaN(event.currentTarget.valueAsNumber) ? control.default : event.currentTarget.valueAsNumber)}
        />
      </label>
    );
  }

  return (
    <label className="xpl-playground-control" htmlFor={inputId}>
      <span className="xpl-playground-control__label">{control.label}</span>
      <input id={inputId} type="text" value={controlString(control, value)} onChange={(event) => onChange(event.currentTarget.value)} />
    </label>
  );
}

function PlaygroundView({
  entry,
  theme,
  width,
  setWidth,
  widthPx,
}: {
  entry: ComponentEntry;
  theme: EmibsTheme;
  width: string;
  setWidth: (width: string) => void;
  widthPx: number | null;
}) {
  const defaults = useMemo(() => playgroundDefaults(entry), [entry]);
  const [values, setValues] = useState<PlaygroundProps>(defaults);
  const [copiedSnippet, setCopiedSnippet] = useState(false);

  useEffect(() => {
    setValues(defaults);
    setCopiedSnippet(false);
  }, [defaults]);

  if (!entry.playground) {
    return <p className="xpl-empty-note">No playground controls registered for this component yet.</p>;
  }

  const snippet = entry.playground.toSnippet(values);

  const setControlValue = (name: string, value: PlaygroundControlValue) => {
    setValues((current) => ({ ...current, [name]: value }));
  };

  const copySnippet = async () => {
    try {
      await navigator.clipboard.writeText(snippet);
      setCopiedSnippet(true);
      window.setTimeout(() => setCopiedSnippet(false), 1400);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <>
      <CanvasWidthBar width={width} setWidth={setWidth} widthPx={widthPx} />
      <div className="xpl-playground">
        <aside className="xpl-playground__rail" aria-label={`${entry.name} playground controls`}>
          <div className="xpl-playground__rail-head">
            <h2>Controls</h2>
            <button type="button" className="xpl-copy" onClick={() => setValues(defaults)}>
              Reset
            </button>
          </div>
          <div className="xpl-playground__controls">
            {entry.playground.controls.map((control) => (
              <PlaygroundControlField
                key={control.name}
                entryId={entry.id}
                control={control}
                value={values[control.name]}
                onChange={(value) => setControlValue(control.name, value)}
              />
            ))}
          </div>
        </aside>
        <div className="xpl-playground__main">
          <ThemeScope className="xpl-canvas xpl-playground__canvas" theme={theme}>
            <div className="xpl-canvas__stage" style={widthPx ? { width: widthPx, maxWidth: "100%" } : undefined}>
              {entry.playground.renderWith(values, setControlValue)}
            </div>
          </ThemeScope>
          <section className="xpl-usage__block xpl-playground__snippet">
            <div className="xpl-playground__snippet-head">
              <h2>JSX</h2>
              <button type="button" className="xpl-copy" onClick={copySnippet}>
                {copiedSnippet ? <Check size={14} /> : <Copy size={14} />}
                {copiedSnippet ? "Copied" : "Copy"}
              </button>
            </div>
            <pre>
              <code>{snippet}</code>
            </pre>
          </section>
        </div>
      </div>
    </>
  );
}

/**
 * Renders a component's `.SPEC.md` as HTML.
 *
 * `markdown` is the ONLY input: there is deliberately no `renderMarkdown` or
 * `sanitizeHtml` prop, so a caller cannot supply the markdown-to-HTML step or
 * narrow/replace the sanitizer. `DOMPurify.sanitize` therefore always runs
 * last, on whatever `marked.parse` produced, and is unconditional — there is no
 * bypass seam of the kind `MarkdownDocumentPanel` had to close. Keep it that
 * way: if this ever grows a caller-supplied renderer, the DOMPurify pass must
 * still run last on its output.
 *
 * Exported for `CatalogExplorer.spec-sanitize.test.tsx`, matching how this
 * module already exports internals (`ExplorerThemeToolbar`, `parseDensity`) for
 * direct test coverage.
 */
export function SpecView({ markdown }: { markdown: string | null }) {
  const html = useMemo(() => {
    if (!markdown) return null;
    return DOMPurify.sanitize(marked.parse(markdown) as string);
  }, [markdown]);
  if (!html) {
    return <p className="xpl-empty-note">No .SPEC.md exists for this component yet.</p>;
  }
  return <div className="xpl-spec" dangerouslySetInnerHTML={{ __html: html }} />;
}

function VariantsGrid({ entry }: { entry: ComponentEntry }) {
  if (!entry.variants?.length) {
    return <p className="xpl-empty-note">No labelled variants registered for this component.</p>;
  }
  return (
    <div className="xpl-variants">
      {entry.variants.map((v) => (
        <figure key={v.label} className="xpl-variant">
          <div className="xpl-variant__stage">{v.render()}</div>
          <figcaption>{v.label}</figcaption>
        </figure>
      ))}
    </div>
  );
}

function UsageView({ entry }: { entry: ComponentEntry }) {
  if (!entry.usage) {
    return <p className="xpl-empty-note">No usage snippets registered for this component yet.</p>;
  }
  return (
    <div className="xpl-usage">
      <section className="xpl-usage__block">
        <h2>Import</h2>
        <pre>
          <code>{entry.usage.import}</code>
        </pre>
      </section>
      <section className="xpl-usage__block">
        <h2>Default usage</h2>
        <pre>
          <code>{entry.usage.snippet}</code>
        </pre>
      </section>
      {entry.usage.variants?.length ? (
        <section className="xpl-usage__block">
          <h2>Variants</h2>
          <div className="xpl-usage__variants">
            {entry.usage.variants.map((variant) => (
              <figure key={variant.label} className="xpl-usage__variant">
                <figcaption>{variant.label}</figcaption>
                <pre>
                  <code>{variant.snippet}</code>
                </pre>
              </figure>
            ))}
          </div>
        </section>
      ) : null}
    </div>
  );
}

function PropsView({ entry }: { entry: ComponentEntry }) {
  if (!entry.propDocs?.length) {
    return (
      <p className="xpl-empty-note">
        No Props/API reference registered for this component yet. See the Spec tab for prose, or the
        component's TypeScript Props type in source.
      </p>
    );
  }
  return (
    <div className="xpl-props">
      <table className="xpl-props__table">
        <thead>
          <tr>
            <th scope="col">Prop</th>
            <th scope="col">Type</th>
            <th scope="col">Default</th>
            <th scope="col">Description</th>
          </tr>
        </thead>
        <tbody>
          {entry.propDocs.map((prop) => (
            <tr key={prop.name}>
              <td>
                <code className="xpl-props__name">{prop.name}</code>
                {prop.required ? <span className="xpl-props__req" title="Required">required</span> : null}
              </td>
              <td>
                <code className="xpl-props__type">{prop.type}</code>
              </td>
              <td>{prop.default ? <code className="xpl-props__default">{prop.default}</code> : <span className="xpl-props__dash">—</span>}</td>
              <td>{prop.description}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const FOUNDATION_CATEGORY_BLURBS: Record<string, string> = {
  color: "Semantic color roles. Components reference these, never raw hex.",
  space: "Spacing scale for padding, gaps, and layout rhythm.",
  radius: "Corner radii from subtle to pill.",
  type: "Font families and the type size scale.",
};

function formatFoundationCategory(category: string): string {
  return category
    .split(/[-_\s]+/)
    .filter(Boolean)
    .map((part) => part.slice(0, 1).toUpperCase() + part.slice(1))
    .join(" ");
}

function useResolvedThemeValues(theme: EmibsTheme) {
  const scopeRef = useRef<HTMLDivElement>(null);
  const [values, setValues] = useState<Record<string, string>>({});

  useEffect(() => {
    const scope = scopeRef.current;
    if (!scope) return;
    const computed = getComputedStyle(scope);
    const next: Record<string, string> = {};
    themeTokenDefinitions.forEach((token) => {
      next[token.name] = computed.getPropertyValue(token.name).trim() || getThemeToken(theme, token.name);
    });
    setValues(next);
  }, [theme]);

  return { scopeRef, values };
}

function groupedFoundationTokens() {
  return themeTokenDefinitions.reduce<{ category: ThemeTokenCategory; tokens: (typeof themeTokenDefinitions)[number][] }[]>(
    (groups, token) => {
      const existing = groups.find((group) => group.category === token.category);
      if (existing) {
        existing.tokens.push(token);
      } else {
        groups.push({ category: token.category, tokens: [token] });
      }
      return groups;
    },
    [],
  );
}

function FoundationTokenRow({
  token,
  value,
  copied,
  onCopy,
}: {
  token: (typeof themeTokenDefinitions)[number];
  value: string;
  copied: boolean;
  onCopy: () => void;
}) {
  let preview: ReactNode;
  if (token.valueKind === "color") {
    preview = <span className="xpl-found__swatch" style={{ background: value }} aria-hidden />;
  } else if (token.category === "radius") {
    preview = <span className="xpl-found__radius" style={{ borderRadius: value }} aria-hidden />;
  } else if (token.category === "space") {
    preview = <span className="xpl-found__bar" style={{ width: value }} aria-hidden />;
  } else if (token.valueKind === "fontFamily") {
    preview = <span className="xpl-found__font" style={{ fontFamily: value }}>Ag</span>;
  } else {
    preview = <span className="xpl-found__font" style={{ fontSize: value }}>Ag</span>;
  }
  return (
    <button
      type="button"
      className={`xpl-found__row ${copied ? "is-copied" : ""}`}
      onClick={onCopy}
      aria-label={`Copy ${token.name} token and value`}
    >
      <div className="xpl-found__preview">{preview}</div>
      <div className="xpl-found__info">
        <code className="xpl-found__name">{token.name}</code>
        <span className="xpl-found__label">{token.label}</span>
      </div>
      <code className="xpl-found__value">{value}</code>
      <span className="xpl-found__copy" aria-live="polite">
        {copied ? (
          <>
            <Check size={13} />
            Copied
          </>
        ) : (
          <>
            <Link2 size={13} />
            Copy
          </>
        )}
      </span>
    </button>
  );
}

type ThemeExportFormat = "css" | "ts" | "json";

const EXPORT_FORMAT_META: Record<ThemeExportFormat, { label: string; extension: string; mime: string }> = {
  css: { label: "CSS :root", extension: "css", mime: "text/css" },
  ts: { label: "TS module", extension: "ts", mime: "text/plain" },
  json: { label: "JSON", extension: "json", mime: "application/json" },
};

function serializeTheme(theme: EmibsTheme, format: ThemeExportFormat): string {
  if (format === "css") return themeToCssRoot(theme);
  if (format === "ts") return themeToTsModule(theme);
  return themeToJson(theme);
}

function ThemeExportPanel({ theme }: { theme: EmibsTheme }) {
  const [format, setFormat] = useState<ThemeExportFormat>("css");
  const [copied, setCopied] = useState(false);
  const code = useMemo(() => serializeTheme(theme, format), [format, theme]);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(code);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1400);
    } catch {
      /* clipboard unavailable */
    }
  };
  const download = () => {
    const meta = EXPORT_FORMAT_META[format];
    try {
      const blob = new Blob([code], { type: `${meta.mime};charset=utf-8` });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `${theme.id}.${meta.extension}`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
    } catch {
      /* download unavailable */
    }
  };
  return (
    <section className="xpl-found__section xpl-export">
      <div className="xpl-found__section-head">
        <h2>Export</h2>
        <p>
          Take {theme.label} into Score, eLitua, or any product as CSS custom properties, a typed EmibsTheme module,
          or portable <code>emibs-theme/1</code> JSON you can re-import below.
        </p>
      </div>
      <div className="xpl-export__bar">
        <div className="xpl-seg">
          {(Object.keys(EXPORT_FORMAT_META) as ThemeExportFormat[]).map((id) => (
            <button key={id} className={format === id ? "is-active" : ""} onClick={() => setFormat(id)}>
              {EXPORT_FORMAT_META[id].label}
            </button>
          ))}
        </div>
        <div className="xpl-export__actions">
          <button type="button" className="xpl-copy" onClick={copy}>
            {copied ? <Check size={14} /> : <Copy size={14} />}
            {copied ? "Copied" : "Copy"}
          </button>
          <button type="button" className="xpl-copy" onClick={download}>
            <Download size={14} />
            Download
          </button>
        </div>
      </div>
      <pre className="xpl-export__code">
        <code>{code}</code>
      </pre>
    </section>
  );
}

function ThemeImportPanel({
  importedThemes,
  activeThemeId,
  onImport,
  onSelect,
  onRemove,
}: {
  importedThemes: readonly EmibsTheme[];
  activeThemeId: ExplorerThemeId;
  onImport: (theme: EmibsTheme) => void;
  onSelect: (themeId: ExplorerThemeId) => void;
  onRemove: (themeId: ExplorerThemeId) => void;
}) {
  const [text, setText] = useState("");
  const [errors, setErrors] = useState<string[]>([]);
  const [imported, setImported] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const runImport = (raw: string) => {
    const result = themeFromJson(raw);
    if (!result.ok) {
      setImported(null);
      setErrors(result.errors);
      return;
    }
    // The parser is registry-agnostic; the catalog additionally refuses ids that
    // would silently shadow a built-in theme (proposal gap: id collisions).
    if (EXPLORER_THEMES.some((theme) => theme.id === result.theme.id)) {
      setImported(null);
      setErrors([`Theme id "${result.theme.id}" collides with a built-in theme — change the id before importing.`]);
      return;
    }
    setErrors([]);
    setImported(result.theme.label);
    onImport(result.theme);
    onSelect(result.theme.id);
  };

  const importFromText = () => {
    if (!text.trim()) {
      setImported(null);
      setErrors(["Paste an emibs-theme/1 JSON export, or upload a .json file."]);
      return;
    }
    runImport(text);
  };

  const importFromFile = async (file: File | undefined) => {
    if (!file) return;
    try {
      const content = await file.text();
      setText(content);
      runImport(content);
    } catch {
      setImported(null);
      setErrors(["Could not read the selected file."]);
    }
  };

  return (
    <section className="xpl-found__section xpl-import">
      <div className="xpl-found__section-head">
        <h2>Import</h2>
        <p>
          Paste an <code>emibs-theme/1</code> JSON export or upload a file to register it as a runtime theme, previewable
          alongside the built-ins for this session.
        </p>
      </div>
      <textarea
        className="xpl-import__input"
        value={text}
        spellCheck={false}
        rows={6}
        placeholder={'{\n  "format": "emibs-theme/1",\n  "id": "my-brand",\n  "label": "My brand",\n  "colorScheme": "light",\n  "tokens": [ … ]\n}'}
        aria-label="Theme JSON to import"
        onChange={(event) => setText(event.currentTarget.value)}
      />
      <div className="xpl-import__bar">
        <button type="button" className="xpl-copy" onClick={importFromText}>
          <Check size={14} />
          Import theme
        </button>
        <button type="button" className="xpl-copy" onClick={() => fileInputRef.current?.click()}>
          <Upload size={14} />
          Upload file
        </button>
        <input
          ref={fileInputRef}
          type="file"
          accept="application/json,.json"
          className="xpl-import__file"
          onChange={(event) => {
            void importFromFile(event.currentTarget.files?.[0]);
            event.currentTarget.value = "";
          }}
        />
      </div>
      {errors.length > 0 ? (
        <ul className="xpl-import__errors" aria-live="assertive" aria-atomic="true">
          {errors.map((error, index) => (
            <li key={index}>{error}</li>
          ))}
        </ul>
      ) : null}
      {imported && errors.length === 0 ? (
        <p className="xpl-import__ok" role="status">
          Imported “{imported}” and applied it as the active theme.
        </p>
      ) : null}
      {importedThemes.length > 0 ? (
        <ul className="xpl-import__list">
          {importedThemes.map((theme) => {
            const active = theme.id === activeThemeId;
            return (
              <li key={theme.id} className={active ? "is-active" : ""}>
                <span
                  className="xpl-import__swatch"
                  aria-hidden="true"
                  style={{ background: getThemeToken(theme, "--accent"), borderColor: getThemeToken(theme, "--border-strong") }}
                />
                <span className="xpl-import__meta">
                  <strong>{theme.label}</strong>
                  <code>
                    {theme.id} · {theme.colorScheme}
                  </code>
                </span>
                <button type="button" onClick={() => onSelect(theme.id)} disabled={active}>
                  {active ? "Active" : "Apply"}
                </button>
                <button
                  type="button"
                  className="xpl-import__remove"
                  aria-label={`Remove imported theme ${theme.label}`}
                  onClick={() => onRemove(theme.id)}
                >
                  <Trash2 size={14} />
                </button>
              </li>
            );
          })}
        </ul>
      ) : null}
    </section>
  );
}

function FoundationsPage({
  theme,
  importedThemes,
  onImportTheme,
  onSelectTheme,
  onRemoveImportedTheme,
}: {
  theme: EmibsTheme;
  importedThemes: readonly EmibsTheme[];
  onImportTheme: (theme: EmibsTheme) => void;
  onSelectTheme: (themeId: ExplorerThemeId) => void;
  onRemoveImportedTheme: (themeId: ExplorerThemeId) => void;
}) {
  const { scopeRef, values } = useResolvedThemeValues(theme);
  const [copiedToken, setCopiedToken] = useState<string | null>(null);
  const groups = useMemo(() => groupedFoundationTokens(), []);

  const copyToken = async (token: (typeof themeTokenDefinitions)[number], value: string) => {
    try {
      await navigator.clipboard.writeText(`${token.name}: ${value}`);
      setCopiedToken(token.name);
      window.setTimeout(() => setCopiedToken(null), 1400);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <div className="xpl-found" ref={scopeRef}>
      <header className="xpl-found__head">
        <h1>Foundations</h1>
        <p>
          The design-token reference for the active theme (<strong>{theme.label}</strong>). Every
          catalogued component is built from these {themeTokenDefinitions.length} tokens — switch the
          theme in the toolbar to see them re-map live.
        </p>
      </header>
      {groups.map(({ category, tokens }) => {
        const label = themeTokenCategoryLabels[category] ?? formatFoundationCategory(category);
        return (
          <section key={category} className="xpl-found__section">
            <div className="xpl-found__section-head">
              <h2>{label}</h2>
              <p>{FOUNDATION_CATEGORY_BLURBS[category] ?? `${label} tokens from the active theme.`}</p>
            </div>
            <div className="xpl-found__grid">
              {tokens.map((token) => {
                const value = values[token.name] ?? getThemeToken(theme, token.name);
                return (
                  <FoundationTokenRow
                    key={token.name}
                    token={token}
                    value={value}
                    copied={copiedToken === token.name}
                    onCopy={() => copyToken(token, value)}
                  />
                );
              })}
            </div>
          </section>
        );
      })}
      <ThemeExportPanel theme={theme} />
      <ThemeImportPanel
        importedThemes={importedThemes}
        activeThemeId={theme.id}
        onImport={onImportTheme}
        onSelect={onSelectTheme}
        onRemove={onRemoveImportedTheme}
      />
    </div>
  );
}

function AuditView({ entry, theme }: { entry: ComponentEntry; theme: EmibsTheme }) {
  const canvasRef = useRef<HTMLDivElement>(null);
  const [status, setStatus] = useState<"idle" | "running" | "done" | "error">("idle");
  const [violations, setViolations] = useState<AxeViolation[]>([]);
  const [passCount, setPassCount] = useState(0);
  const migrated = isMigrated(entry);

  const runAudit = async () => {
    if (!canvasRef.current) return;
    setStatus("running");
    try {
      const results = await runAxe(canvasRef.current);
      setViolations(results.violations);
      setPassCount(results.passCount);
      setStatus("done");
    } catch {
      setStatus("error");
    }
  };

  useEffect(() => {
    if (!migrated) return;
    const t = window.setTimeout(() => {
      void runAudit();
    }, 140);
    return () => window.clearTimeout(t);
  }, [entry.id, theme.id, migrated]);

  if (!migrated) {
    return (
      <p className="xpl-empty-note">
        This component's demo isn't migrated yet, so there's nothing to audit. See the Spec tab.
      </p>
    );
  }

  return (
    <div className="xpl-audit">
      <div className="xpl-audit__bar">
        <button type="button" className="xpl-copy" onClick={() => void runAudit()} disabled={status === "running"}>
          {status === "running" ? "Auditing…" : "Re-run audit"}
        </button>
        {status === "done" && (
          <span className={`xpl-audit__summary ${violations.length ? "is-fail" : "is-pass"}`}>
            {violations.length
              ? `${violations.length} violation${violations.length === 1 ? "" : "s"}`
              : "No violations"}{" "}
            · {passCount} checks passed
          </span>
        )}
        {status === "error" && <span className="xpl-audit__summary is-fail">Audit engine failed to load</span>}
      </div>
      <ThemeScope className="xpl-canvas xpl-audit__canvas" theme={theme}>
        <div className="xpl-canvas__stage" ref={canvasRef}>
          {entry.render()}
        </div>
      </ThemeScope>
      {status === "done" && violations.length > 0 && (
        <ul className="xpl-audit__list">
          {violations.map((v) => (
            <li key={v.id} className={`xpl-audit__item xpl-audit__item--${v.impact ?? "minor"}`}>
              <div className="xpl-audit__item-head">
                <span className="xpl-audit__impact">{v.impact ?? "n/a"}</span>
                <strong>{v.help}</strong>
                <a href={v.helpUrl} target="_blank" rel="noreferrer">
                  docs
                </a>
              </div>
              <p>{v.description}</p>
              <code className="xpl-audit__sel">{v.nodes.map((n) => n.target.join(" ")).join(", ")}</code>
            </li>
          ))}
        </ul>
      )}
      {status === "done" && violations.length === 0 && (
        <p className="xpl-audit__ok">No WCAG 2.1 A/AA violations detected in this demo's rendered DOM.</p>
      )}
    </div>
  );
}

function InspectPage({
  id,
  theme,
  themeId,
  compareIds,
  onToggleCompare,
}: {
  id: string;
  theme: EmibsTheme;
  themeId: ExplorerThemeId;
  compareIds: readonly string[];
  onToggleCompare: (id: string) => void;
}) {
  const entry = getEntry(id);
  const [width, setWidth] = useState("full");
  const [tab, setTab] = useState<InspectTab>("preview");
  const [copied, setCopied] = useState(false);

  if (!entry) {
    return (
      <div className="xpl-inspect">
        <p className="xpl-empty-note">Unknown component “{id}”. <a href="#/">Back to catalog</a>.</p>
      </div>
    );
  }

  const widthPx = WIDTHS.find((w) => w.id === width)?.px ?? null;
  const migrated = isMigrated(entry);
  const pinned = compareIds.includes(entry.id);

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(`${location.origin}${location.pathname}${hashForPath(`/c/${entry.id}`, themeId)}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 1400);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <div className="xpl-inspect">
      <header className="xpl-meta">
        <nav className="xpl-crumb">
          <a href="#/">Catalog</a>
          <ChevronRight size={13} />
          <span>{entry.category}</span>
          <ChevronRight size={13} />
          <strong>{entry.name}</strong>
        </nav>
        <div className="xpl-meta__row">
          <h1>{entry.name}</h1>
          {migrated && (
            <button
              type="button"
              className={`xpl-copy xpl-pin-action ${pinned ? "is-active" : ""}`}
              onClick={() => onToggleCompare(entry.id)}
              aria-label={`${pinned ? "Unpin" : "Pin"} ${entry.name} for compare`}
              aria-pressed={pinned}
            >
              <Pin size={14} />
              {pinned ? "Pinned" : "Pin"}
            </button>
          )}
          <button type="button" className="xpl-copy" onClick={copyLink}>
            {copied ? <Check size={14} /> : <Link2 size={14} />}
            {copied ? "Copied" : "Copy link"}
          </button>
        </div>
        <div className="xpl-meta__tags">
          <span className="xpl-badge xpl-badge--cat">{entry.category}</span>
          <SourceBadges entry={entry} />
          {migrated ? <A11yBadge entry={entry} themeId={themeId} /> : null}
          {entry.patterns.map((p) => (
            <span key={p} className="xpl-badge">
              {p}
            </span>
          ))}
        </div>
      </header>

      <div className="xpl-tabs" role="tablist">
        {INSPECT_TABS.map((item) => (
          <button
            key={item.id}
            type="button"
            role="tab"
            aria-selected={tab === item.id}
            className={tab === item.id ? "is-active" : ""}
            onClick={() => setTab(item.id)}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === "preview" && (
        <>
          <CanvasWidthBar width={width} setWidth={setWidth} widthPx={widthPx} />
          <ThemeScope className="xpl-canvas" theme={theme}>
            <div
              className="xpl-canvas__stage"
              style={widthPx ? { width: widthPx, maxWidth: "100%" } : undefined}
            >
              {migrated ? (
                entry.render()
              ) : (
                <div className="xpl-pending">
                  <strong>Demo migration pending</strong>
                  <p>
                    This component is catalogued and searchable. Its isolated demo is
                    still being migrated into the registry — see the Spec tab.
                  </p>
                </div>
              )}
            </div>
          </ThemeScope>
        </>
      )}

      {tab === "playground" && <PlaygroundView entry={entry} theme={theme} width={width} setWidth={setWidth} widthPx={widthPx} />}
      {tab === "variants" && <VariantsGrid entry={entry} />}
      {tab === "states" && (
        <section className="xpl-states-surface" aria-label={`${entry.name} states`}>
          <StatePreviewGrid entry={entry} />
        </section>
      )}
      {tab === "usage" && <UsageView entry={entry} />}
      {tab === "props" && <PropsView entry={entry} />}
      {tab === "audit" && <AuditView entry={entry} theme={theme} />}
      {tab === "spec" && <SpecView markdown={entry.specContent} />}
    </div>
  );
}

function CompareTrayDock({
  compareIds,
  hash,
  route,
  themeId,
  onToggleCompare,
  onRemoveCompare,
  onClearCompare,
}: {
  compareIds: readonly string[];
  hash: string;
  route: Route;
  themeId: ExplorerThemeId;
  onToggleCompare: (id: string) => void;
  onRemoveCompare: (id: string) => void;
  onClearCompare: () => void;
}) {
  const currentEntry = route.kind === "inspect" ? getEntry(route.id) : null;
  const currentMigrated = currentEntry ? isMigrated(currentEntry) : false;
  const currentPinned = currentEntry ? compareIds.includes(currentEntry.id) : false;
  const items = useMemo<CompareTrayItem[]>(
    () =>
      compareIds.flatMap((id) => {
        const entry = getEntry(id);
        if (!entry || !isMigrated(entry)) return [];
        return [
          {
            id: entry.id,
            title: entry.name,
            description: entry.patterns.slice(0, 2).join(", "),
            meta: entry.category,
            href: hashForPath(`/c/${entry.id}`, themeId),
            badges: entry.sourceApp.map((source) => ({
              id: `${entry.id}-${source}`,
              label: source,
              tone: source === "Score" ? "info" : source === "eLitua" ? "accent" : "neutral",
            })),
            preview: entry.render(),
            previewInert: true,
            previewLabel: `${entry.name} preview`,
            removeLabel: `Remove ${entry.name} from compare tray`,
            onRemove: () => onRemoveCompare(entry.id),
          },
        ];
      }),
    [compareIds, hash, onRemoveCompare, themeId],
  );
  const count = items.length;
  const description =
    count === 0
      ? "Pin migrated components from gallery cards or inspect pages. Pinned ids stay in the URL."
      : count === 1
        ? "One component is pinned. Add another migrated component to compare labels and previews."
        : `${count} components pinned from the current URL.`;

  return (
    <CompareTrayPanel
      className="xpl-compare-tray"
      density="compact"
      title="Compare tray"
      description={description}
      icon={<GitCompare size={18} />}
      resultCount={`${count} pinned`}
      currentAction={
        currentEntry
          ? {
              active: currentPinned,
              activeLabel: "Pinned",
              ariaLabel: currentMigrated
                ? `${currentPinned ? "Unpin" : "Pin"} ${currentEntry.name} for compare`
                : `${currentEntry.name} cannot be pinned until its demo is migrated`,
              disabled: !currentMigrated,
              icon: <Pin size={15} />,
              label: currentMigrated ? "Pin current" : "Demo pending",
              onClick: currentMigrated ? () => onToggleCompare(currentEntry.id) : undefined,
            }
          : undefined
      }
      actions={
        count > 0 ? (
          <>
            <a
              className="xpl-compare-open"
              href={hashForPath("/compare", themeId)}
              aria-label={`Open side-by-side compare view with ${count} pinned component${count === 1 ? "" : "s"}`}
            >
              <GitCompare size={14} aria-hidden="true" />
              Open compare
            </a>
            <button type="button" className="xpl-compare-clear" onClick={onClearCompare}>
              <Trash2 size={14} aria-hidden="true" />
              Clear all
            </button>
          </>
        ) : null
      }
      items={items}
      emptyLabel="No pinned components yet. Pin a migrated component to start a URL-backed compare set."
    />
  );
}

// ---------- compare canvas ----------

function CompareColumn({
  id,
  themeId,
  onRemove,
}: {
  id: string;
  themeId: ExplorerThemeId;
  onRemove: () => void;
}) {
  const entry = getEntry(id);
  const migrated = entry ? isMigrated(entry) : false;
  const name = entry?.name ?? id;

  return (
    <article className={`xpl-compare-col ${!entry || !migrated ? "xpl-compare-col--unavailable" : ""}`}>
      <header className="xpl-compare-col__head">
        <div className="xpl-compare-col__title">
          {entry ? (
            <a href={hashForPath(`/c/${entry.id}`, themeId)} aria-label={`Inspect ${entry.name}`}>
              {entry.name}
            </a>
          ) : (
            <strong>{id}</strong>
          )}
          <span className="xpl-compare-col__cat">{entry ? categoryLabels[entry.category] : "unknown id"}</span>
        </div>
        {entry && <SourceBadges entry={entry} />}
        <button
          type="button"
          className="xpl-compare-col__remove"
          onClick={onRemove}
          aria-label={`Remove ${name} from compare`}
          title="Remove from compare"
        >
          <X size={14} aria-hidden="true" />
        </button>
      </header>
      {entry && migrated ? (
        <div className="xpl-compare-col__stage" inert={true} aria-hidden="true">
          {entry.render()}
        </div>
      ) : (
        <div className="xpl-compare-col__stage xpl-compare-col__stage--pending">
          <span>{entry ? "Demo migration pending — preview unavailable." : "This component id is not in the registry."}</span>
        </div>
      )}
    </article>
  );
}

function ComparePage({
  compareIds,
  theme,
  themeId,
  onRemoveCompare,
  onClearCompare,
}: {
  compareIds: readonly string[];
  theme: EmibsTheme;
  themeId: ExplorerThemeId;
  onRemoveCompare: (id: string) => void;
  onClearCompare: () => void;
}) {
  const [width, setWidth] = useState("full");
  const widthPx = WIDTHS.find((w) => w.id === width)?.px ?? null;
  const count = compareIds.length;

  const description =
    count === 0
      ? "Nothing is pinned yet. Pin migrated components from gallery cards or inspect pages to compare them here."
      : count === 1
        ? "One component is pinned. Pin another migrated component to compare side by side."
        : `${count} pinned components rendered side by side on one themed canvas — the active theme and one shared width apply to every preview.`;

  return (
    <div className="xpl-compare">
      <header className="xpl-gallery__head xpl-compare__head">
        <h1>Compare</h1>
        <p>{description}</p>
      </header>

      {count === 0 ? (
        <p className="xpl-empty-note">
          No pinned components. <a href={hashForPath("/", themeId)}>Back to catalog</a> to pin a migrated component.
        </p>
      ) : (
        <>
          <div className="xpl-compare__bar">
            <CanvasWidthBar width={width} setWidth={setWidth} widthPx={widthPx} />
            <button type="button" className="xpl-compare-clear" onClick={onClearCompare}>
              <Trash2 size={14} aria-hidden="true" />
              Clear all
            </button>
          </div>
          <ThemeScope className="xpl-canvas xpl-compare-canvas" theme={theme}>
            <div
              className={`xpl-compare-row ${widthPx ? "xpl-compare-row--fixed" : ""}`}
              style={widthPx ? ({ "--xpl-compare-w": `${widthPx}px` } as CSSProperties) : undefined}
            >
              {compareIds.map((id) => (
                <CompareColumn key={id} id={id} themeId={themeId} onRemove={() => onRemoveCompare(id)} />
              ))}
            </div>
          </ThemeScope>
        </>
      )}
    </div>
  );
}

// ---------- root ----------

const THEME_MODES: { mode: ThemeMode; label: string; icon: ReactNode; hint: string }[] = [
  { mode: "light", label: "Light", icon: <Sun size={15} aria-hidden="true" />, hint: "Force light" },
  { mode: "dark", label: "Dark", icon: <Moon size={15} aria-hidden="true" />, hint: "Force dark" },
  { mode: "system", label: "System", icon: <Monitor size={15} aria-hidden="true" />, hint: "Follow your OS setting" },
];

export function ExplorerThemeToolbar({
  themeId,
  available,
  studioActive,
  density,
  mode,
  onDensityChange,
  onModeChange,
  onFamilyChange,
  onOpenPalette,
}: {
  themeId: ExplorerThemeId;
  available: readonly EmibsTheme[];
  studioActive: boolean;
  density: Density;
  mode: ThemeMode;
  onDensityChange: (density: Density) => void;
  onModeChange: (mode: ThemeMode) => void;
  onFamilyChange: (base: string) => void;
  onOpenPalette: () => void;
}) {
  const nextDensity: Density = density === "comfortable" ? "compact" : "comfortable";
  const densityLabel = `Density: ${density} — switch to ${nextDensity}`;
  return (
    <div className="xpl-toolbar" role="toolbar" aria-label="Catalog controls">
      <button type="button" className="xpl-command-toggle" onClick={onOpenPalette}>
        <Search size={14} />
        <span>Search</span>
      </button>
      <div className="xpl-toolbar__spacer" />
      <a className={`xpl-toolbar-link ${studioActive ? "is-active" : ""}`} href={hashForPath("/studio", themeId)}>
        <Palette size={15} />
        <span>Theme Studio</span>
      </a>
      <button
        type="button"
        className="xpl-density-toggle"
        aria-label={densityLabel}
        aria-pressed={density === "compact"}
        title={densityLabel}
        onClick={() => onDensityChange(nextDensity)}
      >
        <SlidersHorizontal size={15} aria-hidden="true" />
        <span>{density === "comfortable" ? "Comfortable" : "Compact"}</span>
      </button>
      <div className="xpl-mode" role="group" aria-label="Color mode">
        {THEME_MODES.map((m) => (
          <button
            key={m.mode}
            type="button"
            className={mode === m.mode ? "is-active" : ""}
            aria-pressed={mode === m.mode}
            title={m.hint}
            onClick={() => onModeChange(m.mode)}
          >
            {m.icon}
            <span>{m.label}</span>
          </button>
        ))}
      </div>
      <div className="xpl-theme-picker" role="group" aria-label="Theme family">
        <label className="xpl-theme-picker__label" htmlFor="xpl-theme-family">
          Theme
        </label>
        <span
          className="xpl-theme-select__swatch"
          aria-hidden="true"
          style={{
            background: getThemeToken(themeById(themeId, available), "--accent"),
            borderColor: getThemeToken(themeById(themeId, available), "--border-strong"),
          }}
        />
        <select
          id="xpl-theme-family"
          className="xpl-theme-select"
          value={themeFamilyBase(themeId)}
          onChange={(event) => onFamilyChange(event.target.value)}
        >
          {groupedThemes(available).map((group) => {
            const base = themeFamilyBase(group.themes[0].id);
            return (
              <option key={base} value={base}>
                {group.family}
              </option>
            );
          })}
        </select>
      </div>
    </div>
  );
}

export function CatalogExplorer() {
  const [hash, setHash] = useHashValue();
  const route = parseRoute(hash);
  // Runtime themes imported this session (issue-295). Combined with the built-in
  // catalog so imported themes resolve, preview, and appear alongside built-ins.
  const [importedThemes, setImportedThemes] = useState<EmibsTheme[]>([]);
  const [customThemes, setCustomThemes] = useState<EmibsTheme[]>(() => loadCustomThemes());
  const availableThemes = useMemo(() => [...EXPLORER_THEMES, ...customThemes, ...importedThemes], [customThemes, importedThemes]);
  const themeId = parseThemeId(hash, availableThemes);
  const density = parseDensity(hash);
  const activeTheme = themeById(themeId, availableThemes);
  const studioPreviewSetId = parseStudioPreviewSetId(hash);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const [paletteQuery, setPaletteQuery] = useState("");
  const [mode, setMode] = useState<ThemeMode>(getStoredMode);

  const compareIds = useMemo(() => parseCompareIds(hash), [hash]);
  const facetOptions = useMemo(() => buildFacetOptions(entries), []);
  const viewState = useMemo(() => parseCatalogViewState(hash, facetOptions), [facetOptions, hash]);
  const { axis, query, facets, facetModes } = viewState;
  const filteredEntries = useMemo(() => filterEntries(entries, query, facets, facetModes), [query, facets, facetModes]);
  const filtersActive = hasFacetSelections(facets);
  const openCommandPalette = useCallback(() => {
    setSidebarOpen(false);
    setPaletteQuery("");
    setPaletteOpen(true);
  }, []);
  const setCommandPaletteOpen = useCallback((open: boolean) => {
    setPaletteOpen(open);
    if (!open) {
      setPaletteQuery("");
    }
  }, []);
  const updateViewState = useCallback(
    (next: CatalogViewState) => {
      setHash(updateCatalogViewHash(hash, next, facetOptions));
    },
    [facetOptions, hash, setHash],
  );
  const setViewAxis = useCallback(
    (nextAxis: GroupAxis) => {
      updateViewState({ ...viewState, axis: nextAxis });
    },
    [updateViewState, viewState],
  );
  const setViewQuery = useCallback(
    (nextQuery: string) => {
      updateViewState({ ...viewState, query: nextQuery });
    },
    [updateViewState, viewState],
  );
  const navigateToComponent = useCallback((id: string) => {
    setHash(hashForPath(`/c/${id}`, themeId));
  }, [setHash, themeId]);
  const hrefForComponent = useCallback((id: string) => hashForPath(`/c/${id}`, themeId), [themeId]);
  const navigateToMockup = useCallback((id: string) => {
    setHash(hashForPath(`/m/${id}`, themeId));
  }, [setHash, themeId]);
  const hrefForMockup = useCallback((id: string) => hashForPath(`/m/${id}`, themeId), [themeId]);
  // Palette Themes/Pages groups (issue-528 / epic issue-517 criteria #2 and #4) reuse the
  // sidebar helpers: matchesThemeQuery, PALETTE_PAGES + isPalettePageAvailable.
  const paletteThemes = useMemo(
    () =>
      availableThemes
        .filter((theme) => matchesThemeQuery(theme, paletteQuery))
        .map((theme) => ({ id: theme.id, label: theme.label, active: theme.id === themeId })),
    [availableThemes, paletteQuery, themeId],
  );
  const palettePages = useMemo(() => {
    const normalizedQuery = paletteQuery.trim().toLowerCase();
    return PALETTE_PAGES.filter(isPalettePageAvailable)
      .filter((page) => !normalizedQuery || page.label.toLowerCase().includes(normalizedQuery))
      .map((page) => ({
        id: page.id,
        label: page.label,
        href: hashForPath(page.path, themeId),
        active: route.kind === page.expectedKind || (page.expectedKind === "mockups" && route.kind === "mockup"),
      }));
  }, [hash, paletteQuery, route.kind, themeId]);
  const navigateToPage = useCallback(
    (pageId: string) => {
      const page = PALETTE_PAGES.find((candidate) => candidate.id === pageId);
      if (page) {
        setHash(hashForPath(page.path, themeId));
      }
    },
    [setHash, themeId],
  );

  useEffect(() => {
    setStoredThemeId(themeId);
    const hashTheme = splitHash(hash).params.get("theme");
    if (!isExplorerThemeId(hashTheme, availableThemes) && themeId !== DEFAULT_EXPLORER_THEME_ID) {
      setHash(updateThemeHash(hash, themeId));
    }
  }, [availableThemes, hash, setHash, themeId]);

  useEffect(() => {
    const rawCompare = splitHash(hash).params.get(COMPARE_PARAM) ?? "";
    const normalizedCompare = encodeCompareIds(compareIds);
    if (rawCompare !== normalizedCompare) {
      setHash(updateCompareHash(hash, compareIds));
    }
  }, [compareIds, hash, setHash]);

  useEffect(() => {
    const normalizedHash = updateCatalogViewHash(hash, viewState, facetOptions);
    if (hash !== normalizedHash) {
      setHash(normalizedHash);
    }
  }, [facetOptions, hash, setHash, viewState]);

  useEffect(() => {
    const onCommandPaletteShortcut = (event: KeyboardEvent) => {
      if (isCommandPaletteShortcut(event)) {
        event.preventDefault();
        event.stopPropagation();
        openCommandPalette();
        return;
      }

      if (event.key === "Escape") {
        setPaletteOpen(false);
      }
    };

    window.addEventListener("keydown", onCommandPaletteShortcut);
    return () => window.removeEventListener("keydown", onCommandPaletteShortcut);
  }, [openCommandPalette]);

  // In system mode, follow the OS color scheme live.
  useEffect(() => {
    if (mode !== "system") return;
    const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
    if (!mq) return;
    const onChange = () => {
      const next = resolveThemeForMode(themeId, "system");
      if (next !== themeId) {
        setStoredThemeId(next);
        setHash(updateThemeHash(hash, next));
      }
    };
    onChange();
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, [mode, themeId, hash, setHash]);

  const applyMode = (nextMode: ThemeMode) => {
    setMode(nextMode);
    setStoredMode(nextMode);
    const next = resolveThemeForMode(themeId, nextMode);
    if (next !== themeId) {
      setStoredThemeId(next);
      setHash(updateThemeHash(hash, next));
    }
  };

  // Switch theme family while keeping the current color mode (light/dark/system).
  const applyFamily = (base: string) => {
    const next = base.startsWith("custom-") ? base : resolveThemeForMode(`${base}-light`, mode);
    if (next !== themeId) {
      setStoredThemeId(next);
      setHash(updateThemeHash(hash, next));
    }
  };

  const applyPaletteTheme = (nextThemeId: ExplorerThemeId) => {
    setStoredThemeId(nextThemeId);
    setSidebarOpen(false);
    if (nextThemeId !== themeId) {
      setHash(updateThemeHash(hash, nextThemeId));
    }
  };

  const importTheme = useCallback((theme: EmibsTheme) => {
    // Replace any prior import with the same id so re-importing updates in place.
    setImportedThemes((previous) => [...previous.filter((existing) => existing.id !== theme.id), theme]);
  }, []);

  const removeImportedTheme = useCallback(
    (id: ExplorerThemeId) => {
      setImportedThemes((previous) => previous.filter((existing) => existing.id !== id));
      if (themeId === id) {
        setStoredThemeId(DEFAULT_EXPLORER_THEME_ID);
        setHash(updateThemeHash(hash, DEFAULT_EXPLORER_THEME_ID));
      }
    },
    [hash, setHash, themeId],
  );

  const toggleFacet = (key: FacetKey, value: string) => {
    const selected = facets[key];
    const next = selected.includes(value)
      ? selected.filter((item) => item !== value)
      : [...selected, value];
    updateViewState({ ...viewState, facets: { ...facets, [key]: next } });
  };

  const setFacetMode = (key: FacetKey, mode: FacetMode) => {
    updateViewState({ ...viewState, facetModes: { ...facetModes, [key]: mode } });
  };

  const clearFacets = () => {
    updateViewState({ ...viewState, facets: emptyFacets() });
  };

  const applyDensity = (nextDensity: Density) => {
    setHash(updateDensityHash(hash, nextDensity));
  };

  const setCompareIds = useCallback(
    (ids: readonly string[]) => {
      setHash(updateCompareHash(hash, ids));
    },
    [hash, setHash],
  );

  const toggleCompare = useCallback(
    (id: string) => {
      const entry = getEntry(id);
      if (!entry || !isMigrated(entry)) return;
      const next = compareIds.includes(id) ? compareIds.filter((item) => item !== id) : [...compareIds, id];
      setCompareIds(next);
    },
    [compareIds, setCompareIds],
  );

  const removeCompare = useCallback(
    (id: string) => {
      setCompareIds(compareIds.filter((item) => item !== id));
    },
    [compareIds, setCompareIds],
  );

  useEffect(() => {
    setSidebarOpen(false);
  }, [hash]);

  useEffect(() => {
    if (!sidebarOpen) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setSidebarOpen(false);
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [sidebarOpen]);

  const commandPaletteShortcutHint = isApplePlatform() ? "⌘ K" : "Ctrl K";
  const commandPalette = paletteOpen ? (
    <ThemeScope className="xpl xpl-command-palette-scope" theme={activeTheme}>
      <Suspense fallback={null}>
        <CatalogCommandPalette
          hrefForComponent={hrefForComponent}
          hrefForMockup={hrefForMockup}
          onApplyTheme={applyPaletteTheme}
          onNavigateComponent={navigateToComponent}
          onNavigateMockup={navigateToMockup}
          onNavigatePage={navigateToPage}
          onOpenChange={setCommandPaletteOpen}
          onQueryChange={setPaletteQuery}
          open={paletteOpen}
          pages={palettePages}
          query={paletteQuery}
          shortcutHint={commandPaletteShortcutHint}
          themes={paletteThemes}
        />
      </Suspense>
    </ThemeScope>
  ) : null;

  return (
    <ThemeScope theme={activeTheme}>
      <DensityScope className="xpl" density={density}>
      <header className="xpl-mobile-bar">
        <button
          type="button"
          className="xpl-mobile-menu"
          aria-label="Open catalog navigation"
          aria-expanded={sidebarOpen}
          onClick={() => setSidebarOpen(true)}
        >
          <Menu size={20} />
        </button>
        <a className="xpl-mobile-brand" href={hashForPath("/", themeId)}>
          <span className="xpl-brand__mark">E</span>
          <span>Catalog Explorer</span>
        </a>
      </header>
      <Sidebar
        axis={axis}
        setAxis={setViewAxis}
        query={query}
        setQuery={setViewQuery}
        themeId={themeId}
        themes={availableThemes}
        filteredEntries={filteredEntries}
        facetOptions={facetOptions}
        facets={facets}
        facetModes={facetModes}
        onToggleFacet={toggleFacet}
        onSetFacetMode={setFacetMode}
        onClearFacets={clearFacets}
        activeId={route.kind === "inspect" ? route.id : undefined}
        activeRouteKind={route.kind}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onNavigate={() => setSidebarOpen(false)}
        onThemeSelect={applyPaletteTheme}
      />
      <button
        type="button"
        className={`xpl-backdrop ${sidebarOpen ? "is-open" : ""}`}
        aria-label="Close catalog navigation"
        onClick={() => setSidebarOpen(false)}
      />
      {commandPalette}
      <div className="xpl-main">
        <ExplorerThemeToolbar
          themeId={themeId}
          available={availableThemes}
          studioActive={route.kind === "studio"}
          density={density}
          mode={mode}
          onDensityChange={applyDensity}
          onModeChange={applyMode}
          onFamilyChange={applyFamily}
          onOpenPalette={openCommandPalette}
        />
        {route.kind !== "compare" && (
          <CompareTrayDock
            compareIds={compareIds}
            hash={hash}
            route={route}
            themeId={themeId}
            onToggleCompare={toggleCompare}
            onRemoveCompare={removeCompare}
            onClearCompare={() => setCompareIds([])}
          />
        )}
        {route.kind === "compare" ? (
          <ComparePage
            compareIds={compareIds}
            theme={activeTheme}
            themeId={themeId}
            onRemoveCompare={removeCompare}
            onClearCompare={() => setCompareIds([])}
          />
        ) : route.kind === "mockup" ? (
          <MockupInspectPage id={route.id} theme={activeTheme} themeId={themeId} />
        ) : route.kind === "mockups" ? (
          <MockupGallery themeId={themeId} />
        ) : route.kind === "coverage" ? (
          <CoveragePage themeId={themeId} />
        ) : route.kind === "formBuilder" ? (
          <FormBuilderPage />
        ) : route.kind === "forms" ? (
          <FormsOverviewPage />
        ) : route.kind === "matrix" ? (
          <ThemeMatrixPage />
        ) : route.kind === "foundations" ? (
          <FoundationsPage
            theme={activeTheme}
            importedThemes={importedThemes}
            onImportTheme={importTheme}
            onSelectTheme={applyPaletteTheme}
            onRemoveImportedTheme={removeImportedTheme}
          />
        ) : route.kind === "studio" ? (
          <ThemeStudioPage
            theme={activeTheme}
            previewSetId={studioPreviewSetId}
            onPreviewSetChange={(previewSetId) => setHash(updateStudioPreviewHash(hash, previewSetId))}
            onCustomThemesChange={(nextCustomThemes) => setCustomThemes([...nextCustomThemes])}
          />
        ) : route.kind === "inspect" ? (
          <InspectPage
            id={route.id}
            theme={activeTheme}
            themeId={themeId}
            compareIds={compareIds}
            onToggleCompare={toggleCompare}
          />
        ) : (
          <Gallery
            axis={axis}
            query={query}
            themeId={themeId}
            filteredEntries={filteredEntries}
            filtersActive={filtersActive}
            compareIds={compareIds}
            onToggleCompare={toggleCompare}
          />
        )}
      </div>
      </DensityScope>
    </ThemeScope>
  );
}

export default CatalogExplorer;
