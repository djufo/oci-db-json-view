import { beforeEach, describe, expect, it, vi } from "vitest";
import {
  CUSTOM_THEME_STORAGE_KEY,
  createCustomTheme,
  loadCustomThemes,
  persistCustomThemes,
  readCustomThemes,
  neutralLightTheme,
  themeTokenDefinitions,
} from "../theme";
import {
  THEME_STUDIO_EDITABLE_TOKEN_NAMES,
  THEME_STUDIO_TOKEN_CATEGORY_ORDER,
  describeCustomThemeLoadReport,
  loadThemeStudioSettings,
  persistThemeStudioSettings,
} from "./ThemeStudio";
import type { CustomThemeLoadReport } from "../theme";

/** A clean load of an empty store. `version` is the store the report was read
 *  from (uif/issue-4701); these cases are about the WORDING, so it is the
 *  absent-store one throughout. */
const emptyReport: CustomThemeLoadReport = {
  themes: [],
  migrated: [],
  unreadable: [],
  version: { source: null },
};

describe("ThemeStudio", () => {
  beforeEach(() => {
    vi.unstubAllGlobals();
  });

  it("keeps the complete emibs-theme/2 vocabulary and category order editable", () => {
    expect([...THEME_STUDIO_EDITABLE_TOKEN_NAMES]).toEqual(
      themeTokenDefinitions.map((definition) => definition.name),
    );
    expect(THEME_STUDIO_EDITABLE_TOKEN_NAMES.size).toBe(themeTokenDefinitions.length);
    expect(THEME_STUDIO_TOKEN_CATEGORY_ORDER).toEqual([
      "color",
      "semantic",
      "state",
      "space",
      "density",
      "radius",
      "type",
    ]);
  });

  it("saves a full token snapshot for custom themes", () => {
    const theme = createCustomTheme({
      sourceTheme: neutralLightTheme,
      customThemes: [],
      drafts: {
        "--bg": "#ffffff",
        "--accent": "#006a63",
      },
      label: "Neutral custom",
      baseThemeId: neutralLightTheme.id,
      savedAt: "2026-07-06T00:00:00.000Z",
    });

    expect(theme.tokens).toHaveLength(neutralLightTheme.tokens.length);
    expect(theme.tokens).toEqual(neutralLightTheme.tokens.map((token) => ({
      name: token.name,
      value:
        token.name === "--bg"
          ? "#ffffff"
          : token.name === "--accent"
            ? "#006a63"
            : token.value,
    })));
  });

  it("forks edited custom themes from the selected custom theme", () => {
    const baseTheme = createCustomTheme({
      sourceTheme: neutralLightTheme,
      customThemes: [],
      drafts: { "--bg": "#ffffff" },
      label: "Neutral custom",
      baseThemeId: neutralLightTheme.id,
      savedAt: "2026-07-06T00:00:00.000Z",
    });

    const forkedTheme = createCustomTheme({
      sourceTheme: baseTheme,
      customThemes: [baseTheme],
      drafts: { "--accent": "#006a63" },
      label: "Neutral custom copy",
      baseThemeId: baseTheme.id,
      savedAt: "2026-07-06T00:00:00.000Z",
    });

    expect(forkedTheme.baseThemeId).toBe(baseTheme.id);
    expect(forkedTheme.tokens.find((token) => token.name === "--bg")?.value).toBe("#ffffff");
    expect(forkedTheme.tokens.find((token) => token.name === "--accent")?.value).toBe("#006a63");
  });

  it("persists and reloads custom themes with versioned storage", () => {
    const storedTheme = createCustomTheme({
      sourceTheme: neutralLightTheme,
      customThemes: [],
      drafts: { "--text": "#1a1a1a" },
      label: "Neutral custom",
      baseThemeId: neutralLightTheme.id,
      savedAt: "2026-07-06T00:00:00.000Z",
    });

    const storage = new Map<string, string>();
    vi.stubGlobal("window", {
      localStorage: {
        getItem: (key: string) => storage.get(key) ?? null,
        setItem: (key: string, value: string) => {
          storage.set(key, value);
        },
        removeItem: (key: string) => {
          storage.delete(key);
        },
        clear: () => {
          storage.clear();
        },
      },
    });

    // Every write carries the version of the read it was derived from — here,
    // the empty store this test just stubbed (uif/issue-4701).
    persistCustomThemes([storedTheme], readCustomThemes().version);
    expect(storage.has(CUSTOM_THEME_STORAGE_KEY)).toBe(true);
    expect(loadCustomThemes()).toEqual([storedTheme]);
  });

  it("ignores corrupt custom theme payloads", () => {
    const storage = new Map<string, string>([
      [CUSTOM_THEME_STORAGE_KEY, JSON.stringify({ version: 99, themes: [{ bad: true }] })],
    ]);
    vi.stubGlobal("window", {
      localStorage: {
        getItem: (key: string) => storage.get(key) ?? null,
        setItem: (key: string, value: string) => {
          storage.set(key, value);
        },
        removeItem: (key: string) => {
          storage.delete(key);
        },
        clear: () => {
          storage.clear();
        },
      },
    });

    expect(loadCustomThemes()).toEqual([]);
  });

  // uif/issue-4671: a filled theme loads silently; an unreadable one is named.
  it("says nothing for a clean or migrated load and names every unreadable theme", () => {
    expect(describeCustomThemeLoadReport({ ...emptyReport })).toBeNull();
    expect(
      describeCustomThemeLoadReport({
        ...emptyReport,
        migrated: [{ label: "My brand", filled: ["--text-inverse"], dropped: ["--retired"] }],
      }),
    ).toBeNull();

    expect(
      describeCustomThemeLoadReport({
        ...emptyReport,
        unreadable: [{ label: "My brand", errors: ['Token "--bg" must have a non-empty string value.'] }],
      }),
    ).toBe(
      'Could not load My brand — Token "--bg" must have a non-empty string value. It is still in storage, not deleted.',
    );

    expect(
      describeCustomThemeLoadReport({
        ...emptyReport,
        unreadable: [
          { label: "My brand", errors: ["Stored entry is not a theme object."] },
          { label: null, errors: ["Stored entry is not a theme object."] },
        ],
      }),
    ).toBe("Could not load 2 saved themes (My brand, an unnamed theme). They are still in storage, not deleted.");
  });

  it("restores unexpired route-scoped collapsed panels and discards expired settings", () => {
    const storage = new Map<string, string>();
    vi.stubGlobal("window", {
      localStorage: {
        getItem: (key: string) => storage.get(key) ?? null,
        setItem: (key: string, value: string) => {
          storage.set(key, value);
        },
        removeItem: (key: string) => {
          storage.delete(key);
        },
      },
    });

    persistThemeStudioSettings({
      collapsedCategories: { color: true },
      collapsedSurfaces: { "review:component-review-panel": true },
      savedAt: new Date().toISOString(),
    });
    expect(loadThemeStudioSettings().collapsedSurfaces).toEqual({ "review:component-review-panel": true });

    persistThemeStudioSettings({
      collapsedCategories: { color: true },
      collapsedSurfaces: { "review:component-review-panel": true },
      savedAt: "2020-01-01T00:00:00.000Z",
    });
    expect(loadThemeStudioSettings().collapsedSurfaces).toEqual({});
  });
});
