import { useMemo } from "react";
import { CommandPalette, type CommandPaletteGroup } from "../components/primitives/CommandPalette";
import { matches } from "../catalog/groups";
import { entries, entryById } from "../catalog/registry";
import { mockupEntries } from "../compositions/registry";

export type CatalogCommandPaletteTheme = {
  id: string;
  label: string;
  active?: boolean;
};

export type CatalogCommandPalettePage = {
  id: string;
  label: string;
  href: string;
  active?: boolean;
};

export type CatalogCommandPaletteProps = {
  open: boolean;
  query: string;
  onQueryChange: (query: string) => void;
  onOpenChange: (open: boolean) => void;
  hrefForComponent: (id: string) => string;
  onNavigateComponent: (id: string) => void;
  hrefForMockup: (id: string) => string;
  onNavigateMockup: (id: string) => void;
  /** Themes already filtered against `query` by the host (matchesThemeQuery). */
  themes: readonly CatalogCommandPaletteTheme[];
  onApplyTheme: (themeId: string) => void;
  /** Available pages already filtered against `query` by the host (PALETTE_PAGES + isPalettePageAvailable). */
  pages: readonly CatalogCommandPalettePage[];
  onNavigatePage: (pageId: string) => void;
  shortcutHint?: string;
};

const DEFAULT_COMPONENT_LIMIT = 8;
const MATCHED_COMPONENT_LIMIT = 12;

function componentMetaLabel(category: string, patterns: readonly string[]): string {
  return [category, ...patterns.slice(0, 2)].join(" / ");
}

export default function CatalogCommandPalette({
  open,
  query,
  onQueryChange,
  onOpenChange,
  hrefForComponent,
  onNavigateComponent,
  hrefForMockup,
  onNavigateMockup,
  themes,
  onApplyTheme,
  pages,
  onNavigatePage,
  shortcutHint = "Ctrl K",
}: CatalogCommandPaletteProps) {
  const componentResults = useMemo(() => {
    const normalizedQuery = query.trim();
    const source = normalizedQuery ? entries.filter((entry) => matches(entry, normalizedQuery)) : entries;
    return [...source]
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, normalizedQuery ? MATCHED_COMPONENT_LIMIT : DEFAULT_COMPONENT_LIMIT);
  }, [query]);
  const mockupResults = useMemo(() => {
    const normalizedQuery = query.trim();
    const source = normalizedQuery ? mockupEntries.filter((entry) => matches(entry, normalizedQuery)) : mockupEntries;
    return [...source]
      .sort((a, b) => a.name.localeCompare(b.name))
      .slice(0, normalizedQuery ? MATCHED_COMPONENT_LIMIT : DEFAULT_COMPONENT_LIMIT);
  }, [query]);

  const groups = useMemo<CommandPaletteGroup[]>(
    () => [
      {
        id: "components",
        title: "Components",
        emptyLabel: query.trim() ? `No components match "${query}".` : "Start typing to search components.",
        items: componentResults.map((entry) => ({
          id: entry.id,
          href: hrefForComponent(entry.id),
          label: entry.name,
          description: componentMetaLabel(entry.category, entry.patterns),
          meta: entry.status,
          onSelect: () => {
            const selectedEntry = entryById[entry.id];
            if (selectedEntry) {
              onNavigateComponent(selectedEntry.id);
            }
          },
        })),
      },
      {
        id: "themes",
        title: "Themes",
        emptyLabel: query.trim() ? `No themes match "${query}".` : "No themes available.",
        items: themes.map((theme) => ({
          id: theme.id,
          label: theme.label,
          meta: theme.active ? "active" : undefined,
          active: theme.active,
          onSelect: () => onApplyTheme(theme.id),
        })),
      },
      {
        id: "pages",
        title: "Pages",
        emptyLabel: query.trim() ? `No pages match "${query}".` : "No pages available.",
        items: pages.map((page) => ({
          id: page.id,
          href: page.href,
          label: page.label,
          active: page.active,
          onSelect: () => onNavigatePage(page.id),
        })),
      },
      {
        id: "mockups",
        title: "Mockups",
        emptyLabel: query.trim() ? `No mockups match "${query}".` : "No mockups available.",
        items: mockupResults.map((mockup) => ({
          id: mockup.id,
          href: hrefForMockup(mockup.id),
          label: mockup.name,
          description: mockup.description,
          meta: mockup.status,
          onSelect: () => onNavigateMockup(mockup.id),
        })),
      },
    ],
    [componentResults, hrefForComponent, hrefForMockup, mockupResults, onApplyTheme, onNavigateComponent, onNavigateMockup, onNavigatePage, pages, query, themes],
  );

  const noMatches =
    Boolean(query.trim()) && componentResults.length === 0 && themes.length === 0 && pages.length === 0 && mockupResults.length === 0;

  return (
    <CommandPalette
      closeText="Esc"
      groups={groups}
      noMatchesLabel={noMatches ? `No matches for "${query}".` : undefined}
      onOpenChange={onOpenChange}
      onQueryChange={onQueryChange}
      open={open}
      placeholder="Search components, themes, pages, mockups"
      query={query}
      shortcutHint={shortcutHint}
    />
  );
}
