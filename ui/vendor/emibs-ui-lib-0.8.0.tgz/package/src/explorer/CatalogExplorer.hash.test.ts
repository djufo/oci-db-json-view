import { describe, expect, it } from "vitest";
import {
  buildCoverageRows,
  coverageFacets,
  hashForPathFromHash,
  parseDensity,
  parseCatalogViewState,
  serializeCatalogViewState,
  updateCatalogViewHash,
  updateDensityHash,
  type CatalogViewState,
} from "./CatalogExplorer";
import { entries } from "../catalog/registry";

const emptyFacets = (): CatalogViewState["facets"] => ({
  category: [],
  sourceApp: [],
  pattern: [],
  status: [],
  hasSpec: [],
  theme: [],
});

const defaultFacetModes = (): CatalogViewState["facetModes"] => ({
  category: "or",
  sourceApp: "or",
  pattern: "or",
  status: "or",
  hasSpec: "or",
  theme: "or",
});

function viewState(overrides: Partial<CatalogViewState> = {}): CatalogViewState {
  return {
    query: "",
    axis: "category",
    facets: emptyFacets(),
    facetModes: defaultFacetModes(),
    ...overrides,
  };
}

function paramsOf(hash: string): URLSearchParams {
  return new URLSearchParams(hash.includes("?") ? hash.slice(hash.indexOf("?") + 1) : "");
}

function pathOf(hash: string): string {
  const raw = hash.replace(/^#/, "");
  return raw.includes("?") ? raw.slice(0, raw.indexOf("?")) : raw;
}

describe("Catalog Explorer hash view state", () => {
  it("round-trips query, axis, facets and non-default facet modes while preserving sibling params", () => {
    const state = viewState({
      query: "card panel",
      axis: "status",
      facets: {
        ...emptyFacets(),
        category: ["data"],
        sourceApp: ["Score", "Shared"],
        hasSpec: ["with-spec"],
        theme: ["score-light"],
      },
      facetModes: {
        ...defaultFacetModes(),
        sourceApp: "and",
        theme: "and",
      },
    });

    const hash = updateCatalogViewHash("#/mockups?theme=score-dark&compare=account-menu", state);
    const params = paramsOf(hash);

    expect(pathOf(hash)).toBe("/mockups");
    expect(params.get("theme")).toBe("score-dark");
    expect(params.get("compare")).toBe("account-menu");
    expect(params.get("q")).toBe("card panel");
    expect(params.get("axis")).toBe("status");
    expect(params.get("f_category")).toBe("data");
    expect(params.get("f_sourceApp")).toBe("Score,Shared");
    expect(params.get("f_hasSpec")).toBe("with-spec");
    expect(params.get("f_theme")).toBe("score-light");
    expect(params.get("m_sourceApp")).toBe("and");
    expect(params.get("m_theme")).toBe("and");
    expect(parseCatalogViewState(hash)).toEqual(state);
  });

  it("omits every default view param", () => {
    expect(serializeCatalogViewState(viewState()).toString()).toBe("");
    expect(updateCatalogViewHash("#/?q=button&axis=status&f_category=data&m_sourceApp=and&f_unknown=x", viewState())).toBe(
      "#/",
    );
  });

  it("drops unknown axes, facet keys, facet values and mode values without throwing", () => {
    const hash =
      "#/?q=find&axis=unknown&f_category=data,missing,data&f_sourceApp=Nope,Score&f_nope=x&m_category=xor&m_status=and&m_nope=and";

    const parsed = parseCatalogViewState(hash);

    expect(parsed).toEqual(
      viewState({
        query: "find",
        facets: {
          ...emptyFacets(),
          category: ["data"],
          sourceApp: ["Score"],
        },
        facetModes: {
          ...defaultFacetModes(),
          status: "and",
        },
      }),
    );

    const cleaned = updateCatalogViewHash(hash, parsed);
    const params = paramsOf(cleaned);
    expect(params.get("axis")).toBeNull();
    expect(params.get("f_category")).toBe("data");
    expect(params.get("f_sourceApp")).toBe("Score");
    expect(params.get("f_nope")).toBeNull();
    expect(params.get("m_category")).toBeNull();
    expect(params.get("m_status")).toBe("and");
    expect(params.get("m_nope")).toBeNull();
  });

  it("folds valid view params into generated route hashes with theme and compare", () => {
    const hash = hashForPathFromHash(
      "#/?q=account&axis=sourceApp&f_sourceApp=Score&m_sourceApp=and&compare=account-menu&theme=score-dark&density=compact&f_nope=x",
      "/c/account-menu",
      "score-dark",
    );
    const params = paramsOf(hash);

    expect(pathOf(hash)).toBe("/c/account-menu");
    expect(params.get("q")).toBe("account");
    expect(params.get("axis")).toBe("sourceApp");
    expect(params.get("f_sourceApp")).toBe("Score");
    expect(params.get("m_sourceApp")).toBe("and");
    expect(params.get("compare")).toBe("account-menu");
    expect(params.get("theme")).toBe("score-dark");
    expect(params.get("density")).toBe("compact");
    expect(params.get("f_nope")).toBeNull();
  });
});

describe("Catalog Explorer density hash state", () => {
  it("parses supported density values and defaults invalid values to comfortable", () => {
    expect(parseDensity("#/coverage?density=compact")).toBe("compact");
    expect(parseDensity("#/coverage?density=comfortable")).toBe("comfortable");
    expect(parseDensity("#/coverage?density=packed")).toBe("comfortable");
    expect(parseDensity("#/coverage")).toBe("comfortable");
  });

  it("updates density without clobbering route or sibling parameters", () => {
    const compact = updateDensityHash(
      "#/studio?q=button&theme=score-dark&compare=account-menu&preview=review&f_category=data",
      "compact",
    );
    expect(pathOf(compact)).toBe("/studio");
    expect(paramsOf(compact).get("density")).toBe("compact");
    expect(paramsOf(compact).get("q")).toBe("button");
    expect(paramsOf(compact).get("theme")).toBe("score-dark");
    expect(paramsOf(compact).get("compare")).toBe("account-menu");
    expect(paramsOf(compact).get("preview")).toBe("review");
    expect(paramsOf(compact).get("f_category")).toBe("data");

    const comfortable = updateDensityHash(compact, "comfortable");
    expect(paramsOf(comfortable).get("density")).toBeNull();
    expect(paramsOf(comfortable).get("theme")).toBe("score-dark");
  });
});

describe("Catalog Explorer coverage", () => {
  it("derives every registry facet and orders entries least complete first", () => {
    const rows = buildCoverageRows(entries);

    expect(rows).toHaveLength(entries.length);
    expect(coverageFacets.map((facet) => facet.key)).toEqual(["demo", "variants", "usage", "props", "states", "spec"]);
    expect(rows.every((row) => row.total === coverageFacets.length)).toBe(true);
    expect(rows.map((row) => row.completed)).toEqual([...rows].map((row) => row.completed).sort((a, b) => a - b));
  });
});
