# ThemeStudioPage

## Purpose

`ThemeStudioPage` provides the Explorer's live theme-token editor at `#/studio`.
It lets reviewers edit the complete `emibs-theme/2` vocabulary, preview the
result immediately through `ThemeScope`, and save the current valid draft as a
custom theme in local storage.

## Contract

- The editor exposes exactly one mutable row for every `themeTokenDefinitions`
  entry, ordered by color, semantic, interaction-state, space, density, radius,
  and type categories.
- Draft edits are local to the page and update the preview immediately.
- Valid drafts are layered over the active theme for preview only.
- Token categories and explicitly collapse-capable, live wide preview panels
  render as collapsible sections. Narrow surfaces, static wide surfaces, and
  all derived-theme previews render non-interactive headers. The panel
  preference key is deterministic from the `#/studio` preview-set and surface
  hierarchy (for example `review:component-review-panel`), so it restores after
  rebuilds without depending on generated runtime ids.
- Studio preferences are serialized in the route-scoped, versioned local store
  with `savedAt`; corrupt or settings older than one year are discarded.
- A collapse-capable preview panel's chevron and label share the same muted
  header surface. Its accessible name states both the current
  expanded/collapsed state and the next action.
- Saving and derived-theme review use the same complete ordered
  `emibs-theme/2` token snapshot; no partial Studio serializer exists.
- Custom themes and the selected saved-theme id are namespaced and versioned in
  local storage. A valid saved selection is restored after reload; corrupt,
  foreign, or missing selections fall back to the active theme.
- Saved custom themes carry a `savedAt` timestamp as PROVENANCE ONLY. A custom
  theme NEVER expires: no retention window withholds it from a load and none
  removes it from the store. It leaves storage only when the user deletes it.
  Studio *preferences* (collapsed sections) still age out after a year — that
  state is machine-generated and costs a chevron to forget, where a custom theme
  is a user-authored, user-named document.
- No saved theme is destroyed without the user being told, and no deletion
  happens as a side effect of an unrelated action. `readCustomThemes` therefore
  withholds nothing: every stored record is either returned as a usable theme or
  named as unreadable, because a record it omits is the record the next
  unrelated Save deletes.
- A saved custom theme is migrated to the current token vocabulary on load, not
  discarded: tokens added since it was saved are filled from their
  `emibs-theme/2` defaults (the same backfill `themeFromJson` applies to a `/1`
  payload), and tokens retired since it was saved are dropped. Migration is in
  memory — a load never rewrites the store.
- A saved theme that genuinely cannot be read — a malformed or duplicated token
  value, or a missing `emibs-theme/1` token — is never dropped in silence. It is
  named, with its first reason, in the custom-theme `aria-live` status line, and
  the stored record is carried forward by later saves rather than overwritten.
- Persisting re-emits an unchanged stored record's ORIGINAL BYTES rather than
  re-serializing it, so anything the current vocabulary cannot represent — a
  retired token, an unknown field, a duplicate JSON key, a number `JSON.parse`
  cannot round-trip — survives every later Save and Delete. The in-memory theme
  still excludes a retired token from `themeToStyle` and from export.
- If the stored value cannot be parsed, or its envelope is not the one this
  build writes, Save and Delete are REFUSED rather than overwriting it. The
  refusal names the reason in the same `aria-live` status line, on mount as well
  as on the attempt, and no in-memory state changes so the edit is not lost.

## Product-Owned Behavior

Catalog Explorer owns theme resolution, route state, preview-set selection,
analytics, permissions, and any export or download flows. The Studio surface
only manages local drafts and custom-theme persistence.
