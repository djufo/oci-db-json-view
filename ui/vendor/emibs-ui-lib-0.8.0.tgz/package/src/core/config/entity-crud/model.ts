import {
  FIELD_TYPES,
  type FieldOption,
  type FieldType,
  type FieldValidation,
  type FieldWidth,
  type FormFieldSpec,
  type FormSectionSpec,
  type FormSpec,
} from "../formSpec";

export type EntityRecord = Record<string, unknown>;
export type EntityId = string | number;
export type EntityFieldName<T extends EntityRecord> = Extract<keyof T, string>;

export type EntityRelationCardinality = "one" | "many";

export interface EntityRelationRef {
  readonly id: string;
  readonly target: string;
  readonly cardinality: EntityRelationCardinality;
}

export interface EntityModelField<
  TRecord extends EntityRecord,
  TName extends EntityFieldName<TRecord> = EntityFieldName<TRecord>,
> {
  readonly name: TName;
  readonly type: FieldType;
  readonly label?: string;
  readonly description?: string;
  readonly placeholder?: string;
  readonly options?: readonly FieldOption[];
  readonly default?: TRecord[TName];
  readonly required?: boolean;
  readonly validation?: FieldValidation;
  readonly width?: FieldWidth;
  readonly section?: string;
  readonly order?: number;
  readonly readOnly?: boolean;
  readonly relation?: EntityRelationRef;
}

export interface EntityDisplayColumn<
  TRecord extends EntityRecord,
  TName extends EntityFieldName<TRecord> = EntityFieldName<TRecord>,
> {
  readonly id?: string;
  readonly field: TName;
  readonly label?: string;
  readonly sortable?: boolean;
  readonly align?: "start" | "center" | "end";
}

interface EntityFilterBase<
  TRecord extends EntityRecord,
  TName extends EntityFieldName<TRecord> = EntityFieldName<TRecord>,
> {
  readonly id?: string;
  readonly field: TName;
  readonly label?: string;
  readonly description?: string;
}

export interface EntityTextFilter<
  TRecord extends EntityRecord,
  TName extends EntityFieldName<TRecord> = EntityFieldName<TRecord>,
> extends EntityFilterBase<TRecord, TName> {
  readonly kind: "text";
  readonly placeholder?: string;
}

export interface EntitySelectFilter<
  TRecord extends EntityRecord,
  TName extends EntityFieldName<TRecord> = EntityFieldName<TRecord>,
> extends EntityFilterBase<TRecord, TName> {
  readonly kind: "select";
  readonly options: readonly FieldOption[];
  readonly allLabel?: string;
}

export interface EntityFacetFilter<
  TRecord extends EntityRecord,
  TName extends EntityFieldName<TRecord> = EntityFieldName<TRecord>,
> extends EntityFilterBase<TRecord, TName> {
  readonly kind: "facet";
  readonly options: readonly FieldOption[];
  readonly mode?: "any" | "all";
}

export type EntityFilter<TRecord extends EntityRecord> =
  | EntityTextFilter<TRecord>
  | EntitySelectFilter<TRecord>
  | EntityFacetFilter<TRecord>;

export interface EntityRelation<
  TRecord extends EntityRecord,
  TName extends EntityFieldName<TRecord> = EntityFieldName<TRecord>,
> {
  readonly id: string;
  readonly field: TName;
  readonly target: string;
  readonly label?: string;
  readonly description?: string;
  readonly cardinality: EntityRelationCardinality;
}

export interface EntityModel<TRecord extends EntityRecord> {
  readonly id: string;
  readonly label: string;
  readonly pluralLabel?: string;
  readonly description?: string;
  readonly identity: EntityFieldName<TRecord>;
  readonly labelField: EntityFieldName<TRecord>;
  readonly fields: readonly EntityModelField<TRecord>[];
  readonly displayColumns: readonly EntityDisplayColumn<TRecord>[];
  readonly filters?: readonly EntityFilter<TRecord>[];
  readonly relations?: readonly EntityRelation<TRecord>[];
  readonly sections?: readonly FormSectionSpec[];
}

export interface EntityFormFieldSpec<TName extends string = string> extends FormFieldSpec<TName> {
  readonly readOnly?: boolean;
  readonly relation?: EntityRelationRef;
}

export interface EntityFormSpec<TValues extends object = EntityRecord> extends Omit<FormSpec<TValues>, "fields"> {
  readonly fields: readonly EntityFormFieldSpec<Extract<keyof TValues, string>>[];
}

export type EntityFormMode = "create" | "edit";

export interface ModelToFormSpecOptions {
  readonly mode?: EntityFormMode;
}

export function modelToFormSpec<TRecord extends EntityRecord>(
  model: EntityModel<TRecord>,
  options: ModelToFormSpecOptions = {},
): EntityFormSpec<TRecord> {
  const mode = options.mode ?? "create";
  const fields = model.fields.map((field) => {
    const relation = field.relation ?? relationRefForField(model, field.name);
    const required = field.required ?? field.validation?.required;
    const formField: EntityFormFieldSpec<Extract<keyof TRecord, string>> = {
      name: field.name,
      type: field.type,
      label: field.label,
      description: field.description,
      placeholder: field.placeholder,
      options: field.options,
      default: field.default,
      required,
      validation: required
        ? { ...field.validation, required: true }
        : field.validation,
      width: field.width,
      section: field.section,
      order: field.order,
      readOnly: field.readOnly || (mode === "edit" && field.name === model.identity) || undefined,
      relation,
    };
    return pruneUndefined(formField);
  });

  return pruneUndefined({
    fields,
    sections: model.sections,
  }) as EntityFormSpec<TRecord>;
}

export function filterId<TRecord extends EntityRecord>(filter: EntityFilter<TRecord>): string {
  return filter.id ?? filter.field;
}

export function displayColumnId<TRecord extends EntityRecord>(column: EntityDisplayColumn<TRecord>): string {
  return column.id ?? column.field;
}

export function fieldLabel<TRecord extends EntityRecord>(
  model: EntityModel<TRecord>,
  fieldName: EntityFieldName<TRecord>,
): string {
  const field = model.fields.find((entry) => entry.name === fieldName);
  return field?.label ?? humanizeEntityName(fieldName);
}

export function displayColumnLabel<TRecord extends EntityRecord>(
  model: EntityModel<TRecord>,
  column: EntityDisplayColumn<TRecord>,
): string {
  return column.label ?? fieldLabel(model, column.field);
}

export function relationForField<TRecord extends EntityRecord>(
  model: EntityModel<TRecord>,
  fieldName: EntityFieldName<TRecord>,
): EntityRelation<TRecord> | undefined {
  return model.relations?.find((relation) => relation.field === fieldName);
}

export function getEntityId<TRecord extends EntityRecord>(
  model: EntityModel<TRecord>,
  record: TRecord,
): EntityId {
  const value = record[model.identity];
  if (typeof value === "string" || typeof value === "number") return value;
  return String(value ?? "");
}

export function getEntityLabel<TRecord extends EntityRecord>(
  model: EntityModel<TRecord>,
  record: TRecord,
): string {
  const value = record[model.labelField];
  return value === null || value === undefined || value === "" ? String(getEntityId(model, record)) : String(value);
}

export function isEntityFieldType(value: FieldType): boolean {
  return (FIELD_TYPES as readonly FieldType[]).includes(value);
}

function relationRefForField<TRecord extends EntityRecord>(
  model: EntityModel<TRecord>,
  fieldName: EntityFieldName<TRecord>,
): EntityRelationRef | undefined {
  const relation = relationForField(model, fieldName);
  if (!relation) return undefined;
  return {
    id: relation.id,
    target: relation.target,
    cardinality: relation.cardinality,
  };
}

function humanizeEntityName(name: string): string {
  const words = name
    .replace(/[_-]+/g, " ")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return name;
  return words.map((word, index) => (index === 0 ? word.charAt(0).toUpperCase() + word.slice(1) : word)).join(" ");
}

function pruneUndefined<T extends object>(value: T): T {
  return Object.fromEntries(Object.entries(value).filter(([, entry]) => entry !== undefined)) as T;
}
