import type { EntityModel } from "./model";

export interface ExampleOwnerRecord extends Record<string, unknown> {
  id: string;
  name: string;
  email: string;
  role: "ops" | "delivery" | "finance";
  active: boolean;
}

export interface ExampleProjectRecord extends Record<string, unknown> {
  id: string;
  name: string;
  status: "planned" | "active" | "paused";
  ownerId: string;
  budget: number;
  launchDate: string;
  tags: string[];
  description: string;
}

export const exampleOwnerRows: readonly ExampleOwnerRecord[] = [
  {
    id: "owner-1",
    name: "Avery Chen",
    email: "avery@example.test",
    role: "ops",
    active: true,
  },
  {
    id: "owner-2",
    name: "Mina Rao",
    email: "mina@example.test",
    role: "delivery",
    active: true,
  },
  {
    id: "owner-3",
    name: "Jon Bell",
    email: "jon@example.test",
    role: "finance",
    active: false,
  },
];

export const exampleProjectRows: readonly ExampleProjectRecord[] = [
  {
    id: "project-1",
    name: "Atlas Portal",
    status: "active",
    ownerId: "owner-1",
    budget: 42000,
    launchDate: "2026-08-15",
    tags: ["portal", "priority"],
    description: "Customer portal rollout.",
  },
  {
    id: "project-2",
    name: "Ledger Sync",
    status: "planned",
    ownerId: "owner-3",
    budget: 18000,
    launchDate: "2026-09-01",
    tags: ["finance"],
    description: "Back-office ledger integration.",
  },
  {
    id: "project-3",
    name: "Field Ops",
    status: "paused",
    ownerId: "owner-2",
    budget: 26000,
    launchDate: "2026-10-10",
    tags: ["ops"],
    description: "Mobile field operations workflow.",
  },
];

export const exampleOwnerModel: EntityModel<ExampleOwnerRecord> = {
  id: "owner",
  label: "Owner",
  pluralLabel: "Owners",
  description: "People who can own generated resources.",
  identity: "id",
  labelField: "name",
  sections: [
    { id: "identity", title: "Identity", order: 1 },
    { id: "access", title: "Access", order: 2 },
  ],
  fields: [
    { name: "id", type: "text", label: "Owner ID", section: "identity", width: "half" },
    {
      name: "name",
      type: "text",
      label: "Name",
      section: "identity",
      width: "half",
      required: true,
      validation: { required: true, minLength: 2 },
    },
    {
      name: "email",
      type: "text",
      label: "Email",
      section: "identity",
      width: "half",
      required: true,
      validation: { required: true, format: "email" },
    },
    {
      name: "role",
      type: "select",
      label: "Role",
      section: "access",
      width: "half",
      options: [
        { value: "ops", label: "Ops" },
        { value: "delivery", label: "Delivery" },
        { value: "finance", label: "Finance" },
      ],
      default: "ops",
    },
    {
      name: "active",
      type: "switch",
      label: "Active",
      section: "access",
      default: true,
    },
  ],
  displayColumns: [
    { field: "name", sortable: true },
    { field: "email", sortable: true },
    { field: "role", label: "Role", sortable: true },
  ],
  filters: [
    { kind: "text", field: "name", label: "Owner", placeholder: "Search owners" },
    {
      kind: "select",
      field: "role",
      label: "Role",
      allLabel: "All roles",
      options: [
        { value: "ops", label: "Ops" },
        { value: "delivery", label: "Delivery" },
        { value: "finance", label: "Finance" },
      ],
    },
  ],
};

export const exampleProjectModel: EntityModel<ExampleProjectRecord> = {
  id: "project",
  label: "Project",
  pluralLabel: "Projects",
  description: "Generated project admin backed by a mock CRUD adapter.",
  identity: "id",
  labelField: "name",
  sections: [
    { id: "identity", title: "Identity", order: 1 },
    { id: "planning", title: "Planning", order: 2 },
  ],
  relations: [
    {
      id: "project-owner",
      field: "ownerId",
      target: "owner",
      label: "Owner",
      description: "Select the owner responsible for this project.",
      cardinality: "one",
    },
  ],
  fields: [
    { name: "id", type: "text", label: "Project ID", section: "identity", width: "half" },
    {
      name: "name",
      type: "text",
      label: "Name",
      section: "identity",
      width: "half",
      required: true,
      validation: { required: true, minLength: 2 },
    },
    {
      name: "status",
      type: "select",
      label: "Status",
      section: "planning",
      width: "half",
      default: "planned",
      options: [
        { value: "planned", label: "Planned" },
        { value: "active", label: "Active" },
        { value: "paused", label: "Paused" },
      ],
    },
    {
      name: "ownerId",
      type: "select",
      label: "Owner",
      description: "Stored value is the related owner id.",
      section: "planning",
      width: "half",
      relation: { id: "project-owner", target: "owner", cardinality: "one" },
      options: exampleOwnerRows.map((owner) => ({ value: owner.id, label: owner.name })),
    },
    {
      name: "budget",
      type: "number",
      label: "Budget",
      section: "planning",
      width: "half",
      default: 0,
      validation: { min: 0 },
    },
    {
      name: "launchDate",
      type: "date",
      label: "Launch date",
      section: "planning",
      width: "half",
    },
    {
      name: "tags",
      type: "tags",
      label: "Tags",
      section: "planning",
      width: "full",
      default: [],
    },
    {
      name: "description",
      type: "textarea",
      label: "Description",
      section: "planning",
      width: "full",
    },
  ],
  displayColumns: [
    { field: "name", sortable: true },
    { field: "status", sortable: true },
    { field: "ownerId", label: "Owner", sortable: true },
    { field: "budget", label: "Budget", sortable: true, align: "end" },
  ],
  filters: [
    { kind: "text", field: "name", label: "Project", placeholder: "Search projects" },
    {
      kind: "select",
      field: "status",
      label: "Status",
      allLabel: "All statuses",
      options: [
        { value: "planned", label: "Planned" },
        { value: "active", label: "Active" },
        { value: "paused", label: "Paused" },
      ],
    },
    {
      kind: "facet",
      field: "ownerId",
      label: "Owner",
      options: exampleOwnerRows.map((owner) => ({ value: owner.id, label: owner.name })),
    },
  ],
};
