// core/config — the declarative FormSpec (issue-600, epic issue-553).
//
// A FormSpec is the PRESENTATION-FREE description of a form: which fields it
// has, what control surface each field wants, how they group into sections, and
// their author-facing chrome (label / description / placeholder / width). It is
// decoupled from BOTH the form engine and the primitives library, so the
// AutoForm renderer (story B, issue-601) can swap a primitive for another with
// no/minimal spec change (issue-569 extraction test).
//
// Boundary rules (ARCHITECTURE.md → Core): no JSX, no React import, no imports
// of src/components/**. Types + pure data only.

/** Default value map when a spec is not bound to a concrete values type. */
export type FormValues = Record<string, unknown>;

/**
 * The control surface a field can bind to. Each member maps 1:1 to a
 * Field-contract primitive in the renderer's type→control registry (story B):
 *   text → TextInput, number → NumberInput, select → SelectControl,
 *   combobox → ComboboxField, checkbox → CheckboxControl, switch → SwitchControl,
 *   radio → RadioGroup, date → DateField, file → FileUploadControl,
 *   tags → TagInput, textarea → TextareaControl.
 */
export const FIELD_TYPES = [
  "text",
  "number",
  "select",
  "combobox",
  "checkbox",
  "switch",
  "radio",
  "date",
  "file",
  "tags",
  "textarea",
] as const;

export type FieldType = (typeof FIELD_TYPES)[number];

/** Type guard: is `value` one of the known control types? */
export function isFieldType(value: unknown): value is FieldType {
  return typeof value === "string" && (FIELD_TYPES as readonly string[]).includes(value);
}

/** A selectable choice for select / combobox / radio controls. */
export interface FieldOption {
  /** The value stored in form state when this option is chosen. */
  readonly value: string | number;
  /** Human-facing text for the option. */
  readonly label: string;
  /** Render the option but block selection. */
  readonly disabled?: boolean;
}

/** Column span a field occupies in a section grid. The renderer decides the
 *  concrete CSS; "full" is the "wide" span, the rest are fractional. */
export type FieldWidth = "full" | "half" | "third" | "quarter";

/**
 * Best-effort validation HINTS for the renderer (required marker, native
 * min/max/maxlength attributes, input mode). These are for presentation only —
 * the authoritative validation is the schema/resolver wired into the engine.
 * Derivation carries what it can read off the schema; anything unknown is
 * simply omitted.
 */
export interface FieldValidation {
  /** The field must hold a value (not optional / has no default). */
  readonly required?: boolean;
  /** Numeric lower bound (inclusive). */
  readonly min?: number;
  /** Numeric upper bound (inclusive). */
  readonly max?: number;
  /** Minimum string length. */
  readonly minLength?: number;
  /** Maximum string length. */
  readonly maxLength?: number;
  /** Named string format (e.g. "email", "url", "uuid") when the schema has one. */
  readonly format?: string;
}

/** One field in a form: its data binding plus author-facing chrome. */
export interface FormFieldSpec<TName extends string = string> {
  /** Addresses this field's slot in the form value map. */
  readonly name: TName;
  /** Which control renders it (drives the type→control registry lookup). */
  readonly type: FieldType;
  /** Author-facing label; renderer falls back to a humanized name when absent. */
  readonly label?: string;
  /** Longer helper/hint text shown with the control. */
  readonly description?: string;
  /** Placeholder shown in empty text-like controls. */
  readonly placeholder?: string;
  /** Choices for select / combobox / radio controls. */
  readonly options?: readonly FieldOption[];
  /** Initial value seeded into the engine when the form has none. */
  readonly default?: unknown;
  /** Whether the field is required (also surfaced in `validation.required`). */
  readonly required?: boolean;
  /** Renderer-facing validation hints; the schema remains authoritative. */
  readonly validation?: FieldValidation;
  /** Column span within its section grid. */
  readonly width?: FieldWidth;
  /** id of the section this field belongs to (see FormSpec.sections). */
  readonly section?: string;
  /** Explicit ordering within the form / its section (ascending). */
  readonly order?: number;
  /** RESERVED for the next epic (conditional fields): a reference to a named
   *  condition rule. Carried through untouched; NO evaluation logic here yet. */
  readonly condition?: string;
}

/** A titled group of fields. Fields join a section via `FormFieldSpec.section`. */
export interface FormSectionSpec {
  /** Stable id referenced by `FormFieldSpec.section`. */
  readonly id: string;
  /** Section heading. */
  readonly title?: string;
  /** Section subheading / helper copy. */
  readonly description?: string;
  /** Explicit ordering among sections (ascending). */
  readonly order?: number;
}

/**
 * The complete declarative description of a form. `TValues` binds the field
 * names to a concrete value map (e.g. a schema's output type) so authoring an
 * unknown field name is a type error and `schema → values` types flow through
 * to the renderer and submit handler.
 */
export interface FormSpec<TValues extends object = FormValues> {
  readonly fields: readonly FormFieldSpec<Extract<keyof TValues, string>>[];
  readonly sections?: readonly FormSectionSpec[];
}

/** A partial spec used to override a single derived field (all keys but `name`). */
export type FieldOverride = Partial<Omit<FormFieldSpec, "name">>;

// ---------- presentation-free helpers (consumed by the AutoForm renderer) ----------

/**
 * Title-case a value-key / field name into a human label
 * (`first_name` / `firstName` → "First name"). The renderer uses this when a
 * field has no explicit `label` (derivation only sets `label` from `.meta`).
 */
export function humanizeName(name: string): string {
  const words = name
    .replace(/[_-]+/g, " ")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return name;
  return words.map((w, i) => (i === 0 ? w.charAt(0).toUpperCase() + w.slice(1) : w)).join(" ");
}

/** The type-appropriate empty seed value for a control type. */
export function emptyValueForType(type: FieldType): unknown {
  if (type === "checkbox" || type === "switch") return false;
  if (type === "tags") return [];
  return "";
}

/**
 * Seed the initial form values from a spec: each field's `default`, or a
 * type-safe empty for its control type. This is the value map AutoForm hands to
 * the engine before merging any caller-supplied `defaultValues`.
 */
export function defaultValuesFromSpec<T extends object = FormValues>(spec: FormSpec<T>): FormValues {
  const values: FormValues = {};
  for (const field of spec.fields) {
    values[field.name] = field.default ?? emptyValueForType(field.type);
  }
  return values;
}
