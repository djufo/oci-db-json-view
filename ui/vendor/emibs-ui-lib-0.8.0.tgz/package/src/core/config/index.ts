// core/config — decoupled, declarative CONFIGURATION.
//
// This barrel is the public entry for presentation-free configuration that is
// decoupled from BOTH the form and the primitives library (see
// ARCHITECTURE.md → Core). It hosts the FormSpec schema (issue-600) and its
// schema-first derivation; validation config, field config, and entity models
// (issue-558) land here in their own stories.
//
// Boundary rules (enforced by ARCHITECTURE.md → Core):
//   - No JSX and no imports of src/components/**.
//   - Types, pure functions, and hooks only. No per-primitive local state.

// FormSpec (issue-600): the declarative, presentation-free form description the
// AutoForm renderer (issue-601) consumes.
export {
  FIELD_TYPES,
  isFieldType,
  humanizeName,
  emptyValueForType,
  defaultValuesFromSpec,
  type FieldType,
  type FieldOption,
  type FieldWidth,
  type FieldValidation,
  type FormFieldSpec,
  type FormSectionSpec,
  type FormSpec,
  type FormValues,
  type FieldOverride,
} from "./formSpec";

// Schema-first derivation (issue-600): turn a Zod object schema into a FormSpec.
export {
  zodToSpec,
  type ZodToSpecOptions,
  type UnknownTypePolicy,
} from "./zodToSpec";

// Entity CRUD generation (issue-558): one presentation-free model drives form,
// list/detail, and adapter-backed resource management in the Forms layer.
export * from "./entity-crud";
