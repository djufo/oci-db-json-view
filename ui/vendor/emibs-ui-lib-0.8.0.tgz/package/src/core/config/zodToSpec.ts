// core/config — schema-first FormSpec derivation (issue-600, epic issue-553).
//
// `zodToSpec` turns a Zod object schema into a declarative FormSpec: it maps
// each field's Zod type to a control type, carries defaults/description/options,
// derives best-effort validation hints, and lets authors override any field via
// `.meta({ control, label, ... })` on the schema or an `overrides` map. The Zod
// schema stays the single source of truth for VALIDATION — it is handed to the
// engine resolver unchanged (standardSchemaResolver); this module only reads the
// schema's SHAPE to build presentation config.
//
// Boundary rules (ARCHITECTURE.md → Core): no JSX, no React import, no imports
// of src/components/**. Pure functions + types only.
//
// Zod introspection note: this reads Zod v4 internals (`_def.type`, `_def.
// innerType`, `_def.entries`, `_def.checks`) through a narrow structural view so
// a Zod internals shuffle surfaces as a typed local change here, not everywhere.

import type { z } from "zod";

import {
  isFieldType,
  type FieldOption,
  type FieldOverride,
  type FieldType,
  type FieldValidation,
  type FieldWidth,
  type FormFieldSpec,
  type FormSectionSpec,
  type FormSpec,
} from "./formSpec";

// --- options ----------------------------------------------------------------

/** How to treat a field whose Zod type has no control mapping. */
export type UnknownTypePolicy = "throw" | "text";

export interface ZodToSpecOptions<TValues extends object> {
  /** Per-field overrides merged over the derived field (control type, label,
   *  width, section, order, options, …). Field name must exist in the schema. */
  readonly overrides?: Partial<Record<Extract<keyof TValues, string>, FieldOverride>>;
  /** Section definitions carried onto the FormSpec. Fields join a section via
   *  an override's / meta's `section` id. */
  readonly sections?: readonly FormSectionSpec[];
  /** Unmappable Zod type: "throw" (default, fail loudly) names the offending
   *  field and type; "text" degrades to a text control (documented fallback). */
  readonly onUnknown?: UnknownTypePolicy;
}

// --- narrow structural view of Zod v4 internals -----------------------------

interface ZodCheckDef {
  readonly check?: string;
  readonly minimum?: number;
  readonly maximum?: number;
  readonly value?: number;
  readonly inclusive?: boolean;
  readonly format?: string;
}

interface ZodCheck {
  readonly _zod?: { readonly def?: ZodCheckDef };
  readonly def?: ZodCheckDef;
}

interface ZodDef {
  readonly type?: string;
  readonly innerType?: AnyZod;
  readonly element?: AnyZod;
  readonly defaultValue?: unknown;
  readonly entries?: Record<string, string | number>;
  readonly values?: readonly unknown[];
  readonly options?: readonly AnyZod[];
  readonly format?: string;
  readonly checks?: readonly ZodCheck[];
  readonly shape?: Record<string, AnyZod>;
}

interface AnyZod {
  readonly _def?: ZodDef;
  readonly def?: ZodDef;
  readonly description?: string;
  readonly meta?: () => Record<string, unknown> | undefined;
}

/** Wrapper Zod types that decorate an inner schema; unwrapped to find the core. */
const WRAPPER_TYPES = new Set([
  "optional",
  "nullable",
  "default",
  "prefault",
  "catch",
  "readonly",
  "nonoptional",
]);

function defOf(node: AnyZod): ZodDef {
  return node._def ?? node.def ?? {};
}

function metaOf(node: AnyZod): Record<string, unknown> | undefined {
  try {
    return typeof node.meta === "function" ? node.meta() : undefined;
  } catch {
    return undefined;
  }
}

interface Unwrapped {
  /** the innermost non-wrapper schema */
  readonly core: AnyZod;
  readonly coreType: string;
  /** false when an `optional`/`default` wrapper was seen */
  readonly required: boolean;
  /** first default value found while unwrapping, if any */
  readonly defaultValue: unknown;
  readonly hasDefault: boolean;
  /** description, preferring the outermost that defines one */
  readonly description: string | undefined;
  /** merged `.meta()`, outer level winning on key conflicts */
  readonly meta: Record<string, unknown>;
}

function unwrap(node: AnyZod): Unwrapped {
  let current = node;
  let required = true;
  let defaultValue: unknown;
  let hasDefault = false;
  let description: string | undefined;
  const meta: Record<string, unknown> = {};

  const absorb = (n: AnyZod): void => {
    if (description === undefined && typeof n.description === "string") description = n.description;
    const m = metaOf(n);
    if (m) for (const [k, v] of Object.entries(m)) if (!(k in meta)) meta[k] = v;
  };

  // Guard against pathological cyclic wrappers.
  for (let guard = 0; guard < 64; guard += 1) {
    absorb(current);
    const def = defOf(current);
    const type = def.type ?? "";
    if (!WRAPPER_TYPES.has(type) || !def.innerType) {
      return {
        core: current,
        coreType: type,
        required,
        defaultValue,
        hasDefault,
        description,
        meta,
      };
    }
    if (type === "optional") required = false;
    if (type === "default" || type === "prefault") {
      required = false;
      if (!hasDefault) {
        const raw = def.defaultValue;
        defaultValue = typeof raw === "function" ? (raw as () => unknown)() : raw;
        hasDefault = true;
      }
    }
    if (type === "nonoptional") required = true;
    current = def.innerType;
  }

  const def = defOf(current);
  return {
    core: current,
    coreType: def.type ?? "",
    required,
    defaultValue,
    hasDefault,
    description,
    meta,
  };
}

// --- control-type mapping ---------------------------------------------------

/** Documented default control per core Zod type (before meta/override). */
function defaultControlFor(coreType: string, core: AnyZod): FieldType | undefined {
  switch (coreType) {
    case "string":
      return "text";
    case "number":
    case "bigint":
    case "nan":
      return "number";
    case "boolean":
      return "checkbox";
    case "date":
      return "date";
    case "enum":
      return "select";
    case "union":
      // A union of literals / enums is a plain choice → select; anything else
      // has no single control mapping (falls through to unknown handling).
      return optionsFromUnion(core) ? "select" : undefined;
    case "array":
      return "tags";
    case "literal": {
      const first = defOf(core).values?.[0];
      if (typeof first === "boolean") return "checkbox";
      if (typeof first === "number") return "number";
      return "text";
    }
    default:
      return undefined;
  }
}

function optionsFromEnum(core: AnyZod): readonly FieldOption[] | undefined {
  const entries = defOf(core).entries;
  if (!entries) return undefined;
  const options: FieldOption[] = [];
  for (const value of Object.values(entries)) {
    // Zod stores numeric enums as both name→value and value→name; keep the
    // branch whose value is the canonical option value.
    options.push({ value, label: String(value) });
  }
  // De-duplicate (numeric enums produce reverse mappings).
  const seen = new Set<string | number>();
  return options.filter((o) => (seen.has(o.value) ? false : (seen.add(o.value), true)));
}

/** A union whose every member is a literal / enum → a flat select option list. */
function optionsFromUnion(core: AnyZod): readonly FieldOption[] | undefined {
  const members = defOf(core).options;
  if (!Array.isArray(members) || members.length === 0) return undefined;
  const options: FieldOption[] = [];
  for (const member of members) {
    const d = defOf(member);
    if (d.type === "literal") {
      for (const v of d.values ?? []) {
        if (typeof v === "string" || typeof v === "number") options.push({ value: v, label: String(v) });
        else return undefined; // non-primitive literal: not a plain choice union
      }
    } else if (d.type === "enum") {
      const enumOptions = optionsFromEnum(member);
      if (!enumOptions) return undefined;
      options.push(...enumOptions);
    } else {
      return undefined; // a non-choice member: not derivable to a select
    }
  }
  return options.length > 0 ? options : undefined;
}

/** An array of an enum element → the tag vocabulary (seed options for `tags`). */
function optionsFromArrayEnum(core: AnyZod): readonly FieldOption[] | undefined {
  const element = defOf(core).element;
  if (!element) return undefined;
  return defOf(element).type === "enum" ? optionsFromEnum(element) : undefined;
}

// --- validation-hint extraction ---------------------------------------------

function checkDef(check: ZodCheck): ZodCheckDef | undefined {
  return check._zod?.def ?? check.def;
}

function validationFor(core: AnyZod, coreType: string, required: boolean): FieldValidation {
  const validation: { -readonly [K in keyof FieldValidation]?: FieldValidation[K] } = {};
  if (required) validation.required = true;

  const def = defOf(core);
  if (typeof def.format === "string") validation.format = def.format;

  for (const check of def.checks ?? []) {
    const d = checkDef(check);
    if (!d) continue;
    switch (d.check) {
      case "min_length":
        if (typeof d.minimum === "number") validation.minLength = d.minimum;
        break;
      case "max_length":
        if (typeof d.maximum === "number") validation.maxLength = d.maximum;
        break;
      case "greater_than":
        if (typeof d.value === "number") validation.min = d.value;
        break;
      case "less_than":
        if (typeof d.value === "number") validation.max = d.value;
        break;
      case "string_format":
        if (typeof d.format === "string" && validation.format === undefined) {
          validation.format = d.format;
        }
        break;
      default:
        break;
    }
  }

  return validation;
}

// --- meta → field chrome ----------------------------------------------------

function stringMeta(meta: Record<string, unknown>, key: string): string | undefined {
  const v = meta[key];
  return typeof v === "string" ? v : undefined;
}

const WIDTHS: readonly FieldWidth[] = ["full", "half", "third", "quarter"];
function widthMeta(meta: Record<string, unknown>): FieldWidth | undefined {
  const v = meta.width;
  return typeof v === "string" && (WIDTHS as readonly string[]).includes(v)
    ? (v as FieldWidth)
    : undefined;
}

// --- object-shape access ----------------------------------------------------

function objectShape(schema: AnyZod): Record<string, AnyZod> | undefined {
  const def = defOf(schema);
  if (def.type !== "object" || !def.shape) return undefined;
  return def.shape;
}

// --- derivation -------------------------------------------------------------

/**
 * Derive a declarative FormSpec from a Zod object schema. Field control types,
 * defaults, options, descriptions, and validation hints are read from the
 * schema; `.meta({ control, label, placeholder, width, section, order })` and
 * the `overrides` map let authors steer any field. Field VALUE types flow from
 * the schema output, so the returned spec, the engine resolver, and the submit
 * handler all share one type.
 *
 * @throws if `schema` is not a Zod object, or (with the default `onUnknown:
 *   "throw"`) if a field's Zod type has no control mapping.
 */
export function zodToSpec<T extends z.ZodType>(
  schema: T,
  options: ZodToSpecOptions<z.output<T> & object> = {},
): FormSpec<z.output<T> & object> {
  type Values = z.output<T> & object;
  type Name = Extract<keyof Values, string>;

  const shape = objectShape(schema as unknown as AnyZod);
  if (!shape) {
    throw new Error("zodToSpec: expected a Zod object schema (z.object({ … })).");
  }

  const { overrides = {}, sections, onUnknown = "throw" } = options;
  const fields: FormFieldSpec<Name>[] = [];

  for (const [name, fieldSchema] of Object.entries(shape)) {
    const u = unwrap(fieldSchema);
    const metaControl = isFieldType(u.meta.control) ? u.meta.control : undefined;
    let control = metaControl ?? defaultControlFor(u.coreType, u.core);

    if (!control) {
      if (onUnknown === "throw") {
        throw new Error(
          `zodToSpec: field "${name}" has an unsupported Zod type "${u.coreType || "unknown"}". ` +
            `Add .meta({ control: … }) on the field, an overrides["${name}"].type, ` +
            `or pass { onUnknown: "text" } to degrade to a text control.`,
        );
      }
      control = "text";
    }

    const validation = validationFor(u.core, u.coreType, u.required);
    const options_ =
      optionsFromEnum(u.core) ?? optionsFromUnion(u.core) ?? optionsFromArrayEnum(u.core);
    const description = u.description ?? stringMeta(u.meta, "description");
    const orderMeta = typeof u.meta.order === "number" ? (u.meta.order as number) : undefined;

    const derived: FormFieldSpec<Name> = {
      name: name as Name,
      type: control,
      ...(stringMeta(u.meta, "label") ? { label: stringMeta(u.meta, "label")! } : {}),
      ...(description !== undefined ? { description } : {}),
      ...(stringMeta(u.meta, "placeholder")
        ? { placeholder: stringMeta(u.meta, "placeholder")! }
        : {}),
      ...(options_ ? { options: options_ } : {}),
      ...(u.hasDefault ? { default: u.defaultValue } : {}),
      required: u.required,
      validation,
      ...(widthMeta(u.meta) ? { width: widthMeta(u.meta) } : {}),
      ...(stringMeta(u.meta, "section") ? { section: stringMeta(u.meta, "section")! } : {}),
      ...(orderMeta !== undefined ? { order: orderMeta } : {}),
    };

    const override = (overrides as Record<string, FieldOverride | undefined>)[name];
    fields.push(override ? mergeField(derived, override) : derived);
  }

  const spec: FormSpec<Values> = {
    fields,
    ...(sections ? { sections } : {}),
  };
  return spec;
}

/** Merge a field override over a derived field (override wins; validation is
 *  shallow-merged so a partial validation override keeps derived hints). */
function mergeField<TName extends string>(
  base: FormFieldSpec<TName>,
  override: FieldOverride,
): FormFieldSpec<TName> {
  const merged = { ...base, ...override, name: base.name } as FormFieldSpec<TName>;
  if (override.validation && base.validation) {
    return { ...merged, validation: { ...base.validation, ...override.validation } };
  }
  return merged;
}
