// core/orchestration — cross-component / application ORCHESTRATION.
//
// This barrel is the public entry for presentation-free logic that inherently
// spans many components and evolves WITH the application, not the primitives
// (see ARCHITECTURE.md → Core): the form engine coordinating many fields
// (issue-552), wizard/multi-step flow (issue-555), async-resource loading,
// list pagination/filtering/sorting, and CRUD adapters (issue-558).
//
// Boundary rules (enforced by ARCHITECTURE.md → Core):
//   - No JSX and no imports of src/components/**.
//   - Types, pure functions, and hooks only. No per-primitive local state.

// Forms engine (issue-552 / issue-592): the headless form state core — the
// first resident of orchestration. Presentation-free; the <Form> wrapper lives
// in src/forms.
export * from "./forms";

// Entity CRUD adapters (issue-558): presentation-free resource orchestration
// contracts and the in-memory mock adapter used by catalog/demo wiring.
export * from "./entity-crud";
