// core/orchestration/forms — headless form store implementation.
//
// Presentation-free. Maintains cached immutable snapshots per field and one for
// the form so that a change to field B leaves field A's snapshot reference
// untouched: subscribers reading A bail out on Object.is and do not re-render.
//
// This module also owns validation (via a pluggable Resolver + timing modes)
// and the submit lifecycle (validate → onSubmit → server-error reconcile →
// focus). All of it stays DOM-free: focus is expressed as a "pending focus"
// request the field binding consumes; no element is touched here.

import {
  DEFAULT_FIELD_STATUS,
  fieldStatusesEqual,
  isStatusActive,
  resolveFieldStatus,
  type FieldRule,
  type FieldRules,
  type FieldStatus,
} from "./conditions";
import {
  cloneValue,
  formatPath,
  getPath,
  hasPath,
  normalizePath,
  parentPaths,
  parsePath,
  setPath,
  unsetPath,
  valuesEqual,
} from "./path";
import {
  extractServerValidationErrors,
  ROOT_ERROR_KEY,
  type FieldErrors,
} from "./resolver";
import type {
  CreateFormStoreOptions,
  FieldArrayMutationOptions,
  FieldArrayState,
  FieldState,
  FieldValues,
  FormState,
  FormStore,
  RegisterOptions,
  ReValidateMode,
  SetValueOptions,
  SubmitErrorHandler,
  SubmitHandler,
  ValidationMode,
} from "./types";

interface FieldMeta {
  registered: boolean;
  touched: boolean;
  visited: boolean;
  hasValue: boolean;
  hasInitial: boolean;
}

function emptyMeta(): FieldMeta {
  return { registered: false, touched: false, visited: false, hasValue: false, hasInitial: false };
}

function fieldStatesEqual(a: FieldState, b: FieldState): boolean {
  return (
    valuesEqual(a.value, b.value) &&
    a.touched === b.touched &&
    a.dirty === b.dirty &&
    a.visited === b.visited &&
    a.error === b.error
  );
}

function formStatesEqual(a: FormState, b: FormState): boolean {
  return (
    a.isDirty === b.isDirty &&
    a.isValid === b.isValid &&
    a.isValidating === b.isValidating &&
    a.isSubmitting === b.isSubmitting &&
    a.submitCount === b.submitCount &&
    a.submitError === b.submitError
  );
}

function arrayStatesEqual(a: FieldArrayState, b: FieldArrayState): boolean {
  return (
    a.name === b.name &&
    a.error === b.error &&
    a.fields.length === b.fields.length &&
    a.fields.every((field, index) => {
      const other = b.fields[index];
      return field.id === other.id && field.name === other.name && field.index === other.index;
    })
  );
}

function normalizeName(name: string): string {
  return name === ROOT_ERROR_KEY ? ROOT_ERROR_KEY : normalizePath(name);
}

function normalizeErrorMap(input: FieldErrors): FieldErrors {
  const out: FieldErrors = {};
  for (const [name, message] of Object.entries(input)) {
    out[normalizeName(name)] = message;
  }
  return out;
}

function hasIndexedSegment(name: string): boolean {
  return parsePath(name).some((segment) => typeof segment === "number");
}

export function createFormStore<TValues extends object = FieldValues>(
  options: CreateFormStoreOptions<TValues> = {},
): FormStore<TValues> {
  let initial: Record<string, unknown> = cloneValue(options.defaultValues ?? {}) as Record<string, unknown>;
  let values: Record<string, unknown> = cloneValue(initial) as Record<string, unknown>;
  let valuesSnapshotSource: Record<string, unknown> | null = null;
  let valuesSnapshot: TValues | null = null;
  const meta = new Map<string, FieldMeta>();
  for (const key of Object.keys(initial)) {
    const m = emptyMeta();
    m.hasValue = true;
    m.hasInitial = true;
    meta.set(key, m);
  }

  const resolver = options.resolver;
  const mode: ValidationMode = options.mode ?? "onSubmit";
  const reValidateMode: ReValidateMode = options.reValidateMode ?? "onChange";
  const asyncDebounceMs = options.asyncDebounceMs ?? 0;

  // Condition + computed-field rules. `ruleNames` is the (small) set of fields
  // carrying any rule; `computedNames` those with a derived value.
  const rules = Object.fromEntries(
    Object.entries(options.rules ?? {}).map(([name, rule]) => [normalizeName(name), rule]),
  ) as FieldRules<TValues>;
  const ruleOf = (name: string): FieldRule<TValues> | undefined =>
    (rules as Record<string, FieldRule<TValues> | undefined>)[normalizeName(name)];
  const ruleNames: string[] = Object.keys(rules).filter((k) => ruleOf(k) !== undefined);
  const computedNames: string[] = ruleNames.filter((k) => ruleOf(k)?.compute !== undefined);

  const errors = new Map<string, string>();
  let submitError: string | undefined;
  let submitting = false;
  let submitCount = 0;
  let submittedOnce = false;
  let pendingFocus: string | null = null;

  // Async-validation bookkeeping: per-field debounce timers plus an in-flight
  // counter so isValidating reflects any scheduled or awaited validation, and a
  // monotonic token so a stale async result never clobbers a newer one.
  const debounceTimers = new Map<string, ReturnType<typeof setTimeout>>();
  let pendingValidations = 0;
  let validationToken = 0;

  const fieldSnapshots = new Map<string, FieldState>();
  const statusSnapshots = new Map<string, FieldStatus>();
  const arrayKeys = new Map<string, string[]>();
  const arraySnapshots = new Map<string, FieldArrayState>();
  let nextArrayKey = 0;
  let formSnapshot: FormState | null = null;

  const listeners = new Set<() => void>();

  function metaOf(name: string): FieldMeta {
    name = normalizeName(name);
    let m = meta.get(name);
    if (!m) {
      m = emptyMeta();
      m.hasInitial = hasPath(initial, name);
      m.hasValue = hasPath(values, name);
      meta.set(name, m);
    }
    return m;
  }

  function currentValue(name: string): unknown {
    const key = normalizeName(name);
    return hasPath(values, key) ? getPath(values, key) : getPath(initial, key);
  }

  function snapshotValues(): TValues {
    if (valuesSnapshotSource !== values) {
      valuesSnapshotSource = values;
      valuesSnapshot = cloneValue(values) as TValues;
    }
    return valuesSnapshot as TValues;
  }

  function computeFieldState(name: string): FieldState {
    const key = normalizeName(name);
    const m = meta.get(key) ?? emptyMeta();
    const hasCurrent = hasPath(values, key);
    const hasInitial = hasPath(initial, key);
    const value = hasCurrent ? getPath(values, key) : hasInitial ? getPath(initial, key) : undefined;
    const initialValue = hasInitial ? getPath(initial, key) : undefined;
    const dirty = hasInitial || hasCurrent ? !valuesEqual(value, initialValue) : false;
    return Object.freeze({
      value,
      touched: m.touched,
      dirty,
      visited: m.visited,
      error: errors.get(key),
    });
  }

  function readFieldSnapshot(name: string): FieldState {
    name = normalizeName(name);
    const cached = fieldSnapshots.get(name);
    if (cached) return cached;
    const fresh = computeFieldState(name);
    fieldSnapshots.set(name, fresh);
    return fresh;
  }

  /** Recompute one field's cached snapshot; return true if the reference changed. */
  function refreshFieldSnapshot(name: string): boolean {
    name = normalizeName(name);
    const next = computeFieldState(name);
    const cached = fieldSnapshots.get(name);
    if (cached && fieldStatesEqual(cached, next)) return false;
    fieldSnapshots.set(name, next);
    return true;
  }

  // --- conditions + computed fields ------------------------------------------

  function computeFieldStatus(name: string, values: TValues): FieldStatus {
    name = normalizeName(name);
    const rule = ruleOf(name);
    if (!rule) return DEFAULT_FIELD_STATUS;
    return Object.freeze(resolveFieldStatus(rule, values));
  }

  function readFieldStatus(name: string): FieldStatus {
    name = normalizeName(name);
    const cached = statusSnapshots.get(name);
    if (cached) return cached;
    const fresh = computeFieldStatus(name, snapshotValues());
    statusSnapshots.set(name, fresh);
    return fresh;
  }

  /** Recompute a field's cached status snapshot; true if the reference changed. */
  function refreshFieldStatusSnapshot(name: string, values: TValues): boolean {
    name = normalizeName(name);
    const next = computeFieldStatus(name, values);
    const cached = statusSnapshots.get(name);
    if (cached && fieldStatusesEqual(cached, next)) return false;
    statusSnapshots.set(name, next);
    return true;
  }

  /** A field is active (validated + submitted) when visible and not disabled.
   *  Nested names inherit inactive status from any ruled parent path. */
  function isFieldActive(name: string): boolean {
    const key = normalizeName(name);
    for (const candidate of [key, ...parentPaths(key)]) {
      if (ruleOf(candidate) && !isStatusActive(readFieldStatus(candidate))) return false;
    }
    return true;
  }

  /** Recompute every computed field to a fixpoint (chained computes settle in a
   *  bounded number of passes). Writes changed values in-place and returns the
   *  set of computed field names whose value actually changed. */
  function applyDerivedValues(): Set<string> {
    const changed = new Set<string>();
    if (computedNames.length === 0) return changed;
    const maxPasses = computedNames.length + 1;
    for (let pass = 0; pass < maxPasses; pass += 1) {
      let anyChange = false;
      const view = snapshotValues();
      for (const name of computedNames) {
        const next = ruleOf(name)!.compute!(view);
        const prev = currentValue(name);
        if (!valuesEqual(next, prev)) {
          values = setPath(values, name, next);
          metaOf(name).hasValue = true;
          changed.add(name);
          anyChange = true;
        }
      }
      if (!anyChange) break;
    }
    return changed;
  }

  /** Drop fields whose effective status is hidden or disabled, so the
   *  submitted shape omits values the user could not see or edit. */
  function activeValues(values: TValues): Partial<TValues> {
    if (ruleNames.length === 0) return values;
    let out = cloneValue(values) as Partial<TValues>;
    for (const name of ruleNames) {
      if (!isFieldActive(name)) out = unsetPath(out, name);
    }
    return out;
  }

  /** Refresh every ruled field's status snapshot against `values`; returns true
   *  if any status reference changed. */
  function refreshAllStatuses(values: TValues): boolean {
    let changed = false;
    for (const name of ruleNames) changed = refreshFieldStatusSnapshot(name, values) || changed;
    return changed;
  }

  /** Commit path used after a value mutation: recompute computed fields, refresh
   *  the primary field plus any derived fields plus all rule statuses plus the
   *  form snapshot, and notify at most once. */
  function commitDerived(primary: string | null): void {
    const derived = applyDerivedValues();
    let changed = false;
    if (primary !== null) changed = refreshFieldSnapshot(primary) || changed;
    for (const name of derived) changed = refreshFieldSnapshot(name) || changed;
    changed = refreshAllStatuses(snapshotValues()) || changed;
    changed = refreshAllArraySnapshots() || changed;
    changed = refreshFormSnapshot() || changed;
    if (changed) notify();
  }

  function computeFormState(): FormState {
    let isDirty = false;
    for (const [name, m] of meta) {
      if (!(m.hasInitial || m.hasValue)) continue;
      const value = currentValue(name);
      const initialValue = hasPath(initial, name) ? getPath(initial, name) : undefined;
      if (!valuesEqual(value, initialValue)) {
        isDirty = true;
        break;
      }
    }
    return Object.freeze({
      isDirty,
      isValid: errors.size === 0,
      isValidating: pendingValidations > 0,
      isSubmitting: submitting,
      submitCount,
      submitError,
    });
  }

  /** Recompute the cached form snapshot; return true if the reference changed. */
  function refreshFormSnapshot(): boolean {
    const next = computeFormState();
    if (formSnapshot && formStatesEqual(formSnapshot, next)) return false;
    formSnapshot = next;
    return true;
  }

  // --- field arrays ---------------------------------------------------------

  function makeArrayKey(): string {
    nextArrayKey += 1;
    return `fa_${nextArrayKey.toString(36)}`;
  }

  function readArrayValue(name: string): unknown[] {
    const value = currentValue(name);
    return Array.isArray(value) ? value : [];
  }

  function ensureArrayKeys(name: string, length: number): string[] {
    const key = normalizeName(name);
    const existing = arrayKeys.get(key) ?? [];
    if (existing.length < length) {
      const next = [...existing];
      while (next.length < length) next.push(makeArrayKey());
      arrayKeys.set(key, next);
      return next;
    }
    if (existing.length > length) {
      const next = existing.slice(0, length);
      arrayKeys.set(key, next);
      return next;
    }
    if (!arrayKeys.has(key)) arrayKeys.set(key, existing);
    return existing;
  }

  function computeArrayState(name: string): FieldArrayState {
    const key = normalizeName(name);
    const array = readArrayValue(key);
    const keys = ensureArrayKeys(key, array.length);
    return Object.freeze({
      name: key,
      error: errors.get(key),
      fields: Object.freeze(
        keys.map((id, index) =>
          Object.freeze({
            id,
            index,
            name: `${key}.${index}`,
          }),
        ),
      ),
    });
  }

  function readArraySnapshot(name: string): FieldArrayState {
    const key = normalizeName(name);
    const cached = arraySnapshots.get(key);
    if (cached) return cached;
    const fresh = computeArrayState(key);
    arraySnapshots.set(key, fresh);
    return fresh;
  }

  function refreshArraySnapshot(name: string): boolean {
    const key = normalizeName(name);
    const next = computeArrayState(key);
    const cached = arraySnapshots.get(key);
    if (cached && arrayStatesEqual(cached, next)) return false;
    arraySnapshots.set(key, next);
    return true;
  }

  function refreshAllArraySnapshots(): boolean {
    let changed = false;
    for (const name of arraySnapshots.keys()) changed = refreshArraySnapshot(name) || changed;
    return changed;
  }

  function isNestedArrayPath(path: string, arrayName: string): boolean {
    return path.startsWith(`${arrayName}.`) && typeof parsePath(path)[parsePath(arrayName).length] === "number";
  }

  function rebaseArrayIndexedKeys(
    target: Map<string, unknown>,
    arrayName: string,
    mapIndex: (index: number) => number | null,
  ): Set<string> {
    const affected = new Set<string>();
    const entries = [...target.entries()];
    const rebased: Array<[string, unknown]> = [];
    const prefixLength = parsePath(arrayName).length;
    for (const [key, value] of entries) {
      if (!isNestedArrayPath(key, arrayName)) continue;
      const segments = parsePath(key);
      const oldIndex = segments[prefixLength] as number;
      const nextIndex = mapIndex(oldIndex);
      affected.add(key);
      if (nextIndex !== null) {
        const nextName = formatPath([
          ...segments.slice(0, prefixLength),
          nextIndex,
          ...segments.slice(prefixLength + 1),
        ]);
        rebased.push([nextName, value]);
        affected.add(nextName);
      }
    }
    for (const [key] of entries) {
      if (affected.has(key)) target.delete(key);
    }
    for (const [key, value] of rebased) target.set(key, value);
    return affected;
  }

  function rebaseArrayMeta(
    arrayName: string,
    mapIndex: (index: number) => number | null,
  ): Set<string> {
    const affected = new Set<string>();
    for (const name of rebaseArrayIndexedKeys(meta as unknown as Map<string, unknown>, arrayName, mapIndex)) {
      affected.add(name);
    }
    for (const name of rebaseArrayIndexedKeys(errors as unknown as Map<string, unknown>, arrayName, mapIndex)) {
      affected.add(name);
    }
    for (const name of rebaseArrayIndexedKeys(fieldSnapshots as unknown as Map<string, unknown>, arrayName, mapIndex)) {
      affected.add(name);
    }
    for (const name of rebaseArrayIndexedKeys(statusSnapshots as unknown as Map<string, unknown>, arrayName, mapIndex)) {
      affected.add(name);
    }
    for (const [key, timer] of [...debounceTimers.entries()]) {
      if (!isNestedArrayPath(key, arrayName)) continue;
      clearTimeout(timer);
      debounceTimers.delete(key);
      pendingValidations -= 1;
      affected.add(key);
    }
    return affected;
  }

  function replaceArrayMeta(arrayName: string): Set<string> {
    return rebaseArrayMeta(arrayName, () => null);
  }

  function commitArrayMutation(name: string, affected: Set<string>): void {
    affected.add(name);
    commitMany(affected);
  }

  function mutateArray(
    name: string,
    mutate: (items: unknown[], keys: string[]) => void,
    options?: FieldArrayMutationOptions,
    affected: Set<string> = new Set<string>(),
  ): void {
    const key = normalizeName(name);
    const current = [...readArrayValue(key)];
    const keys = [...ensureArrayKeys(key, current.length)];
    mutate(current, keys);
    values = setPath(values, key, current);
    const m = metaOf(key);
    m.hasValue = true;
    if (options?.shouldTouch ?? true) m.touched = true;
    arrayKeys.set(key, keys);
    commitArrayMutation(key, affected);
    const validate = options?.shouldValidate ?? shouldValidateOnChange(key);
    if (validate) void scheduleValidateField(key, options?.shouldValidate === true);
  }

  function notify(): void {
    for (const listener of listeners) listener();
  }

  /** After a mutation touching `name`, refresh affected snapshots and notify
   *  once if anything actually changed. */
  function commit(name: string | null): void {
    let changed = false;
    if (name !== null) changed = refreshFieldSnapshot(name) || changed;
    changed = refreshAllArraySnapshots() || changed;
    changed = refreshFormSnapshot() || changed;
    if (changed) notify();
  }

  /** Refresh a set of field snapshots plus the form snapshot; notify once. */
  function commitMany(names: Iterable<string>): void {
    let changed = false;
    for (const name of names) changed = refreshFieldSnapshot(name) || changed;
    changed = refreshAllArraySnapshots() || changed;
    changed = refreshFormSnapshot() || changed;
    if (changed) notify();
  }

  // --- error application -----------------------------------------------------

  function applyErrorMap(next: FieldErrors, scope: Iterable<string>): void {
    const normalizedNext = normalizeErrorMap(next);
    const affected = new Set<string>();
    for (const rawName of scope) {
      const name = normalizeName(rawName);
      const message = normalizedNext[name];
      const had = errors.has(name);
      if (message) {
        if (errors.get(name) !== message) {
          errors.set(name, message);
          affected.add(name);
        }
      } else if (had) {
        errors.delete(name);
        affected.add(name);
      }
    }
    commitMany(affected);
  }

  // --- validation ------------------------------------------------------------

  function runResolver(): Promise<{ errors: FieldErrors; values: TValues }> {
    if (!resolver) return Promise.resolve({ errors: {}, values: snapshotValues() });
    const result = resolver(snapshotValues());
    return Promise.resolve(result).then((r) => ({ errors: r.errors, values: r.values }));
  }

  let lastSanitized: TValues | null = null;

  async function validateAll(): Promise<boolean> {
    if (!resolver) return errors.size === 0;
    const token = ++validationToken;
    pendingValidations += 1;
    commit(null);
    try {
      const result = await runResolver();
      if (token !== validationToken) return errors.size === 0; // superseded
      lastSanitized = result.values;
      const resultErrors = normalizeErrorMap(result.errors);
      // Replace the entire field-error set with the resolver's verdict.
      const scope = new Set<string>([...errors.keys(), ...Object.keys(resultErrors)]);
      scope.delete(ROOT_ERROR_KEY);
      // Hidden/disabled fields skip validation: drop their errors so they never
      // block submit, and existing errors on a field that just went inactive
      // clear (it stays in scope but out of the applied map).
      const fieldOnly: FieldErrors = {};
      for (const [k, v] of Object.entries(resultErrors)) {
        if (k === ROOT_ERROR_KEY || !isFieldActive(k)) continue;
        fieldOnly[k] = v;
      }
      applyErrorMap(fieldOnly, scope);
      submitError = resultErrors[ROOT_ERROR_KEY];
      return Object.keys(fieldOnly).length === 0 && submitError === undefined;
    } finally {
      pendingValidations -= 1;
      commit(null);
    }
  }

  async function runValidateField(name: string): Promise<void> {
    if (!resolver) return;
    const token = ++validationToken;
    pendingValidations += 1;
    commit(null);
    try {
      const result = await runResolver();
      if (token !== validationToken) return; // superseded by a newer request
      const resultErrors = normalizeErrorMap(result.errors);
      // Update this field plus any field already showing an error (so fixing a
      // value clears it and cross-field siblings re-report), without surfacing
      // NEW errors for other, still-untouched fields.
      const scope = new Set<string>([normalizeName(name), ...errors.keys()]);
      scope.delete(ROOT_ERROR_KEY);
      // Hidden/disabled fields skip validation (see validateAll).
      const active: FieldErrors = {};
      for (const [k, v] of Object.entries(resultErrors)) if (isFieldActive(k)) active[k] = v;
      applyErrorMap(active, scope);
    } finally {
      pendingValidations -= 1;
      commit(null);
    }
  }

  function scheduleValidateField(name: string, immediate: boolean): Promise<void> {
    name = normalizeName(name);
    const existing = debounceTimers.get(name);
    if (existing) {
      clearTimeout(existing);
      debounceTimers.delete(name);
      pendingValidations -= 1; // drop the superseded scheduled slot
    }
    if (immediate || asyncDebounceMs <= 0) {
      return runValidateField(name);
    }
    pendingValidations += 1;
    commit(null);
    return new Promise<void>((resolve) => {
      const timer = setTimeout(() => {
        debounceTimers.delete(name);
        pendingValidations -= 1;
        void runValidateField(name).then(resolve);
      }, asyncDebounceMs);
      debounceTimers.set(name, timer);
    });
  }

  function isReValidating(name: string): boolean {
    return errors.has(normalizeName(name)) || submittedOnce;
  }

  function shouldValidateOnChange(name: string): boolean {
    if (!resolver) return false;
    return isReValidating(name)
      ? reValidateMode === "onChange"
      : mode === "onChange" || mode === "all";
  }

  function shouldValidateOnBlur(name: string): boolean {
    if (!resolver) return false;
    return isReValidating(name)
      ? reValidateMode === "onBlur"
      : mode === "onBlur" || mode === "all";
  }

  function firstErroredField(): string | null {
    for (const name of meta.keys()) {
      if (errors.has(name)) return name;
    }
    // fall back to registration insertion order for any error not in meta
    const first = errors.keys().next();
    return first.done ? null : first.value;
  }

  // Seed computed fields' initial values so they start non-dirty and appear in
  // getValues()/snapshots even before any component registers them.
  for (let pass = 0; computedNames.length > 0 && pass <= computedNames.length; pass += 1) {
    let anyChange = false;
    const view = snapshotValues();
    for (const name of computedNames) {
      const next = ruleOf(name)!.compute!(view);
      const m = metaOf(name);
      if (!m.hasInitial || !valuesEqual(getPath(initial, name), next)) {
        initial = setPath(initial, name, next);
        m.hasInitial = true;
      }
      if (!m.hasValue || !valuesEqual(getPath(values, name), next)) {
        values = setPath(values, name, next);
        m.hasValue = true;
        anyChange = true;
      }
    }
    if (!anyChange) break;
  }

  const store: FormStore<TValues> = {
    register(name, opts?: RegisterOptions) {
      const key = normalizeName(name);
      const m = metaOf(key);
      m.registered = true;
      if (opts && "defaultValue" in opts && !hasPath(initial, key)) {
        initial = setPath(initial, key, opts.defaultValue);
        m.hasInitial = true;
        if (!hasPath(values, key)) {
          values = setPath(values, key, opts.defaultValue);
          m.hasValue = true;
        }
      }
      commitDerived(key);
    },

    unregister(name) {
      const key = normalizeName(name);
      if (!meta.has(key)) return;
      meta.delete(key);
      if (!hasIndexedSegment(key)) {
        values = unsetPath(values, key);
        valuesSnapshotSource = null;
        valuesSnapshot = null;
        initial = unsetPath(initial, key);
      }
      fieldSnapshots.delete(key);
      statusSnapshots.delete(key);
      arraySnapshots.delete(key);
      arrayKeys.delete(key);
      const timer = debounceTimers.get(key);
      if (timer) {
        clearTimeout(timer);
        debounceTimers.delete(key);
        pendingValidations -= 1;
      }
      const hadError = errors.delete(key);
      commit(null);
      if (hadError) commitMany([key]);
    },

    isRegistered(name) {
      return meta.get(normalizeName(name))?.registered ?? false;
    },

    getRegisteredNames() {
      const names: string[] = [];
      for (const [name, m] of meta) if (m.registered) names.push(name);
      return names;
    },

    getValue(name) {
      return currentValue(name) as never;
    },

    getValues() {
      return snapshotValues();
    },

    getSubmitValues() {
      return activeValues(snapshotValues());
    },

    getFieldArrayState(name) {
      return readArraySnapshot(name);
    },

    appendFieldArrayItem(name, value, opts) {
      mutateArray(name, (items, keys) => {
        items.push(value);
        keys.push(makeArrayKey());
      }, opts);
    },

    insertFieldArrayItem(name, index, value, opts) {
      const key = normalizeName(name);
      const length = readArrayValue(key).length;
      const target = Math.max(0, Math.min(index, length));
      const affected = rebaseArrayMeta(key, (oldIndex) => (oldIndex >= target ? oldIndex + 1 : oldIndex));
      mutateArray(
        key,
        (items, keys) => {
          items.splice(target, 0, value);
          keys.splice(target, 0, makeArrayKey());
        },
        opts,
        affected,
      );
    },

    removeFieldArrayItem(name, index, opts) {
      const key = normalizeName(name);
      const length = readArrayValue(key).length;
      if (index < 0 || index >= length) return;
      const affected = rebaseArrayMeta(key, (oldIndex) => {
        if (oldIndex === index) return null;
        return oldIndex > index ? oldIndex - 1 : oldIndex;
      });
      mutateArray(
        key,
        (items, keys) => {
          items.splice(index, 1);
          keys.splice(index, 1);
        },
        opts,
        affected,
      );
    },

    moveFieldArrayItem(name, fromIndex, toIndex, opts) {
      const key = normalizeName(name);
      const length = readArrayValue(key).length;
      if (fromIndex < 0 || fromIndex >= length || toIndex < 0 || toIndex >= length || fromIndex === toIndex) return;
      const affected = rebaseArrayMeta(key, (oldIndex) => {
        if (oldIndex === fromIndex) return toIndex;
        if (fromIndex < toIndex && oldIndex > fromIndex && oldIndex <= toIndex) return oldIndex - 1;
        if (fromIndex > toIndex && oldIndex >= toIndex && oldIndex < fromIndex) return oldIndex + 1;
        return oldIndex;
      });
      mutateArray(
        key,
        (items, keys) => {
          const [item] = items.splice(fromIndex, 1);
          const [rowKey] = keys.splice(fromIndex, 1);
          items.splice(toIndex, 0, item);
          keys.splice(toIndex, 0, rowKey);
        },
        opts,
        affected,
      );
    },

    replaceFieldArrayItems(name, nextValues, opts) {
      const key = normalizeName(name);
      const affected = replaceArrayMeta(key);
      mutateArray(
        key,
        (items, keys) => {
          items.splice(0, items.length, ...nextValues);
          keys.splice(0, keys.length, ...nextValues.map(() => makeArrayKey()));
        },
        opts,
        affected,
      );
    },

    getFieldStatus(name) {
      return readFieldStatus(name);
    },

    setValue(name, value, opts?: SetValueOptions) {
      const key = normalizeName(name);
      const m = metaOf(key);
      values = setPath(values, key, value);
      m.hasValue = true;
      if (opts?.shouldTouch) m.touched = true;
      commitDerived(key);
      const validate = opts?.shouldValidate ?? shouldValidateOnChange(key);
      if (validate) void scheduleValidateField(key, opts?.shouldValidate === true);
    },

    setTouched(name, touched = true) {
      const key = normalizeName(name);
      const m = metaOf(key);
      if (m.touched === touched) return;
      m.touched = touched;
      commit(key);
      if (touched && shouldValidateOnBlur(key)) void scheduleValidateField(key, true);
    },

    setVisited(name, visited = true) {
      const key = normalizeName(name);
      const m = metaOf(key);
      if (m.visited === visited) return;
      m.visited = visited;
      commit(key);
    },

    getError(name) {
      return errors.get(normalizeName(name));
    },

    getErrors() {
      return Object.fromEntries(errors);
    },

    setError(name, message) {
      const key = normalizeName(name);
      if (errors.get(key) === message) return;
      errors.set(key, message);
      commitMany([key]);
    },

    clearErrors(name) {
      if (name === undefined) {
        if (errors.size === 0 && submitError === undefined) return;
        const affected = [...errors.keys()];
        errors.clear();
        submitError = undefined;
        commitMany(affected);
        return;
      }
      const key = normalizeName(name);
      if (errors.delete(key)) commitMany([key]);
    },

    setSubmitError(message) {
      if (submitError === message) return;
      submitError = message;
      commit(null);
    },

    validate() {
      return validateAll();
    },

    validateField(name, opts) {
      return scheduleValidateField(name, opts?.immediate ?? true);
    },

    reset(nextValues) {
      if (nextValues) {
        for (const [key, value] of Object.entries(nextValues)) {
          const name = normalizeName(key);
          initial = setPath(initial, name, value);
          const m = metaOf(name);
          m.hasInitial = true;
        }
      }
      for (const [name, m] of meta) {
        if (hasPath(initial, name)) {
          values = setPath(values, name, cloneValue(getPath(initial, name)));
          m.hasValue = true;
        } else {
          values = unsetPath(values, name);
          m.hasValue = false;
        }
        m.touched = false;
        m.visited = false;
      }
      values = cloneValue(initial) as Record<string, unknown>;
      // Re-derive computed fields against the restored initial values so they
      // stay non-dirty after reset even when a dependency's initial changed.
      for (let pass = 0; computedNames.length > 0 && pass <= computedNames.length; pass += 1) {
        let anyChange = false;
        const view = snapshotValues();
        for (const name of computedNames) {
          const next = ruleOf(name)!.compute!(view);
          if (!valuesEqual(getPath(values, name), next)) anyChange = true;
          values = setPath(values, name, next);
          initial = setPath(initial, name, cloneValue(next));
          metaOf(name).hasValue = true;
          metaOf(name).hasInitial = true;
        }
        if (!anyChange) break;
      }
      for (const name of arrayKeys.keys()) ensureArrayKeys(name, readArrayValue(name).length);
      for (const timer of debounceTimers.values()) clearTimeout(timer);
      debounceTimers.clear();
      pendingValidations = 0;
      validationToken += 1; // invalidate any in-flight async validation
      const clearedErrors = [...errors.keys()];
      errors.clear();
      submitError = undefined;
      submitting = false;
      submitCount = 0;
      submittedOnce = false;
      pendingFocus = null;
      // Rebuild every cached snapshot; notify once.
      let changed = false;
      const names = new Set<string>([...meta.keys(), ...clearedErrors]);
      for (const name of names) changed = refreshFieldSnapshot(name) || changed;
      changed = refreshAllStatuses(snapshotValues()) || changed;
      changed = refreshAllArraySnapshots() || changed;
      changed = refreshFormSnapshot() || changed;
      if (changed) notify();
    },

    setSubmitting(isSubmitting) {
      if (submitting === isSubmitting) return;
      submitting = isSubmitting;
      commit(null);
    },

    countSubmit() {
      submitCount += 1;
      submittedOnce = true;
      commit(null);
    },

    handleSubmit(onValid: SubmitHandler<TValues>, onInvalid?: SubmitErrorHandler) {
      return async (event?: { preventDefault?: () => void }) => {
        event?.preventDefault?.();
        submittedOnce = true;
        submitCount += 1;
        submitError = undefined;
        submitting = true;
        commit(null);

        let valid: boolean;
        try {
          valid = await validateAll();
        } catch {
          valid = false;
        }

        if (!valid) {
          submitting = false;
          commit(null);
          const focus = firstErroredField();
          if (focus) store.setFocus(focus);
          onInvalid?.(store.getErrors());
          return;
        }

        try {
          await onValid(activeValues((lastSanitized ?? snapshotValues()) as TValues) as TValues);
          // success: clear any lingering field/form errors from prior attempts.
          const affected = [...errors.keys()];
          errors.clear();
          submitError = undefined;
          submitting = false;
          commitMany(affected);
          if (affected.length === 0) commit(null);
        } catch (thrown) {
          const server = extractServerValidationErrors(thrown);
          submitting = false;
          if (server) {
            const affected: string[] = [];
            for (const [name, message] of Object.entries(server.fieldErrors ?? {})) {
              const key = normalizeName(name);
              errors.set(key, message);
              affected.push(key);
            }
            submitError =
              server.formError ?? (affected.length > 0 ? undefined : "Submission failed.");
            commitMany(affected);
            if (affected.length === 0) commit(null);
            const focus = firstErroredField();
            if (focus) store.setFocus(focus);
          } else {
            submitError = thrown instanceof Error ? thrown.message : "Submission failed.";
            commit(null);
          }
        }
      };
    },

    setFocus(name) {
      pendingFocus = normalizeName(name);
      notify();
    },

    getPendingFocus() {
      return pendingFocus;
    },

    clearFocus() {
      if (pendingFocus === null) return;
      pendingFocus = null;
      notify();
    },

    getFieldState(name) {
      return readFieldSnapshot(name) as never;
    },

    getFormState() {
      if (!formSnapshot) formSnapshot = computeFormState();
      return formSnapshot;
    },

    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
  };

  return store;
}
