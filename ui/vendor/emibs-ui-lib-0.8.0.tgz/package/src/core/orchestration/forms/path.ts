// core/orchestration/forms — nested field path utilities.
//
// The form engine addresses nested values by string paths. Bracket and dotted
// array notation are accepted at the API edge, then normalized to dotted numeric
// segments internally (lineItems[2].qty -> lineItems.2.qty).

export type PathSegment = string | number;

const PATH_TOKEN = /[^.[\]]+|\[(?:"([^"]*)"|'([^']*)'|([^\]]+))\]/g;

export function parsePath(path: string): PathSegment[] {
  if (path === "") return [];
  const segments: PathSegment[] = [];
  let match: RegExpExecArray | null;
  PATH_TOKEN.lastIndex = 0;
  while ((match = PATH_TOKEN.exec(path)) !== null) {
    const raw = match[1] ?? match[2] ?? match[3] ?? match[0];
    if (/^(0|[1-9]\d*)$/.test(raw)) {
      segments.push(Number(raw));
    } else if (raw.length > 0) {
      segments.push(raw);
    }
  }
  return segments;
}

export function formatPath(segments: readonly PathSegment[]): string {
  return segments.map(String).join(".");
}

export function normalizePath(path: string): string {
  return formatPath(parsePath(path));
}

export function parentPaths(path: string): string[] {
  const segments = parsePath(path);
  const parents: string[] = [];
  for (let length = segments.length - 1; length > 0; length -= 1) {
    parents.push(formatPath(segments.slice(0, length)));
  }
  return parents;
}

export function cloneValue<T>(value: T): T {
  if (Array.isArray(value)) return value.map((item) => cloneValue(item)) as T;
  if (isPlainObject(value)) {
    const out: Record<string, unknown> = {};
    for (const [key, child] of Object.entries(value)) out[key] = cloneValue(child);
    return out as T;
  }
  return value;
}

export function valuesEqual(a: unknown, b: unknown): boolean {
  if (Object.is(a, b)) return true;
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    return a.every((item, index) => valuesEqual(item, b[index]));
  }
  if (isPlainObject(a) || isPlainObject(b)) {
    if (!isPlainObject(a) || !isPlainObject(b)) return false;
    const aKeys = Object.keys(a);
    const bKeys = Object.keys(b);
    if (aKeys.length !== bKeys.length) return false;
    return aKeys.every((key) => Object.prototype.hasOwnProperty.call(b, key) && valuesEqual(a[key], b[key]));
  }
  return false;
}

export function hasPath(root: unknown, path: string): boolean {
  const segments = parsePath(path);
  if (segments.length === 0) return root !== undefined;
  let current = root;
  for (const segment of segments) {
    if (current === null || current === undefined) return false;
    if (Array.isArray(current)) {
      if (typeof segment !== "number" || segment < 0 || segment >= current.length) return false;
      current = current[segment];
      continue;
    }
    if (typeof current !== "object") return false;
    if (!Object.prototype.hasOwnProperty.call(current, String(segment))) return false;
    current = (current as Record<string, unknown>)[String(segment)];
  }
  return true;
}

export function getPath(root: unknown, path: string): unknown {
  const segments = parsePath(path);
  if (segments.length === 0) return root;
  let current = root;
  for (const segment of segments) {
    if (current === null || current === undefined) return undefined;
    if (Array.isArray(current)) {
      current = typeof segment === "number" ? current[segment] : undefined;
      continue;
    }
    if (typeof current !== "object") return undefined;
    current = (current as Record<string, unknown>)[String(segment)];
  }
  return current;
}

export function setPath<T>(root: T, path: string, value: unknown): T {
  const segments = parsePath(path);
  if (segments.length === 0) return value as T;
  return setAt(root, segments, value) as T;
}

export function unsetPath<T>(root: T, path: string): T {
  const segments = parsePath(path);
  if (segments.length === 0) return {} as T;
  return unsetAt(root, segments) as T;
}

function setAt(current: unknown, segments: readonly PathSegment[], value: unknown): unknown {
  const [segment, ...rest] = segments;
  const next = cloneContainer(current, segment);
  if (rest.length === 0) {
    assignSegment(next, segment, value);
    return next;
  }
  assignSegment(next, segment, setAt(readSegment(next, segment), rest, value));
  return next;
}

function unsetAt(current: unknown, segments: readonly PathSegment[]): unknown {
  const [segment, ...rest] = segments;
  const next = cloneContainer(current, segment);
  if (rest.length === 0) {
    if (Array.isArray(next) && typeof segment === "number") {
      next.splice(segment, 1);
    } else {
      delete (next as Record<string, unknown>)[String(segment)];
    }
    return next;
  }
  assignSegment(next, segment, unsetAt(readSegment(next, segment), rest));
  return next;
}

function cloneContainer(value: unknown, segment: PathSegment): unknown[] | Record<string, unknown> {
  if (Array.isArray(value)) return [...value];
  if (isPlainObject(value)) return { ...(value as Record<string, unknown>) };
  return typeof segment === "number" ? [] : {};
}

function assignSegment(container: unknown[] | Record<string, unknown>, segment: PathSegment, value: unknown): void {
  if (Array.isArray(container) && typeof segment === "number") {
    container[segment] = value;
    return;
  }
  (container as Record<string, unknown>)[String(segment)] = value;
}

function readSegment(container: unknown[] | Record<string, unknown>, segment: PathSegment): unknown {
  if (Array.isArray(container) && typeof segment === "number") return container[segment];
  return (container as Record<string, unknown>)[String(segment)];
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) return false;
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || proto === null;
}
