// core/orchestration/forms — validation resolver contract + Standard Schema adapter.
//
// The engine never depends on a validation library directly; it calls a
// pluggable `Resolver`. The reference adapter, `standardSchemaResolver`, turns
// ANY Standard Schema (zod is the reference vendor) into a Resolver, so the
// schema is the single source of truth: it parses/sanitizes input and reports
// field-addressed errors. Swapping to valibot/arktype later is a schema change,
// not an engine change.
//
// Presentation-free: pure functions + types, no JSX, no DOM.

import type { StandardSchemaV1 } from "./standardSchema";

/** Field-addressed validation messages: field name (dotted path for nested) →
 *  message. The empty-string key `""` addresses a form-level (root) error. */
export type FieldErrors = Record<string, string>;

/** Key used for root/form-level issues that carry no field path. */
export const ROOT_ERROR_KEY = "" as const;

/** Outcome of running a resolver over the current values. */
export interface ResolverResult<TValues extends object> {
  /** Parsed/sanitized values (schema output) when valid; the raw input echoed
   *  back when invalid so callers always have a values object to read. */
  readonly values: TValues;
  /** name → message; empty object when the values pass validation. */
  readonly errors: FieldErrors;
}

/**
 * Pluggable validation seam. Given the current values, return the sanitized
 * values and any field-addressed errors. May be sync or async (async enables
 * remote/uniqueness checks; the engine debounces those per its timing config).
 */
export type Resolver<TValues extends object> = (
  values: TValues,
) => ResolverResult<TValues> | Promise<ResolverResult<TValues>>;

function segmentKey(segment: PropertyKey | StandardSchemaV1.PathSegment): string {
  return typeof segment === "object" ? String(segment.key) : String(segment);
}

/** Convert a Standard Schema issue path to a dotted field name (or ROOT). */
function pathToName(path: StandardSchemaV1.Issue["path"]): string {
  if (!path || path.length === 0) return ROOT_ERROR_KEY;
  return path.map(segmentKey).join(".");
}

/** Map a failed Standard Schema result to first-error-wins field messages. */
function issuesToErrors(issues: ReadonlyArray<StandardSchemaV1.Issue>): FieldErrors {
  const errors: FieldErrors = {};
  for (const issue of issues) {
    const name = pathToName(issue.path);
    // First message per field wins (matches native constraint-validation UX).
    if (!(name in errors)) errors[name] = issue.message;
  }
  return errors;
}

function toResolverResult<TValues extends object>(
  input: TValues,
  result: StandardSchemaV1.Result<unknown>,
): ResolverResult<TValues> {
  if (result.issues && result.issues.length > 0) {
    return { values: input, errors: issuesToErrors(result.issues) };
  }
  return { values: (result as StandardSchemaV1.SuccessResult<TValues>).value, errors: {} };
}

/**
 * Adapt a Standard Schema into a `Resolver`. zod is the reference vendor; any
 * Standard-Schema-compatible library works identically. The engine infers its
 * value type from the schema's output when this resolver is used.
 */
export function standardSchemaResolver<Schema extends StandardSchemaV1>(
  schema: Schema,
): Resolver<StandardSchemaV1.InferOutput<Schema> & object> {
  type Out = StandardSchemaV1.InferOutput<Schema> & object;
  return (values: Out) => {
    const result = schema["~standard"].validate(values);
    if (result instanceof Promise) {
      return result.then((r) => toResolverResult<Out>(values, r));
    }
    return toResolverResult<Out>(values, result);
  };
}

// --- server-error reconciliation (story C: submit lifecycle) ----------------

/** Field/form errors returned by a backend submit (e.g. a 422 response). */
export interface ServerValidationErrors {
  /** name → message, mapped back onto the matching fields. */
  fieldErrors?: FieldErrors;
  /** form-level message surfaced above the fields. */
  formError?: string;
}

/**
 * Error thrown from an `onSubmit` handler to hand field/form errors back to the
 * engine for reconciliation. `handleSubmit` catches it, maps `fieldErrors` onto
 * the named fields, and surfaces `formError` at the form level.
 */
export class FormSubmissionError extends Error implements ServerValidationErrors {
  readonly fieldErrors?: FieldErrors;
  readonly formError?: string;

  constructor(init: ServerValidationErrors & { message?: string } = {}) {
    super(init.message ?? init.formError ?? "Submission failed.");
    this.name = "FormSubmissionError";
    this.fieldErrors = init.fieldErrors;
    this.formError = init.formError;
  }
}

export function isFormSubmissionError(value: unknown): value is FormSubmissionError {
  return value instanceof FormSubmissionError;
}

/**
 * Best-effort extraction of server validation errors from a thrown value:
 * a `FormSubmissionError`, or any object exposing `fieldErrors` / `formError`.
 * Returns null when the value carries no reconcilable field/form errors.
 */
export function extractServerValidationErrors(value: unknown): ServerValidationErrors | null {
  if (isFormSubmissionError(value)) {
    return { fieldErrors: value.fieldErrors, formError: value.formError };
  }
  if (value !== null && typeof value === "object") {
    const record = value as { fieldErrors?: unknown; formError?: unknown };
    const hasFieldErrors =
      record.fieldErrors !== null &&
      typeof record.fieldErrors === "object" &&
      record.fieldErrors !== undefined;
    const hasFormError = typeof record.formError === "string";
    if (hasFieldErrors || hasFormError) {
      return {
        fieldErrors: hasFieldErrors ? (record.fieldErrors as FieldErrors) : undefined,
        formError: hasFormError ? (record.formError as string) : undefined,
      };
    }
  }
  return null;
}
