// core/orchestration/forms — declarative condition model + computed fields.
//
// Presentation-free (per issue-569): pure data + pure functions, no JSX, no
// DOM. The engine (store.ts) consumes this to derive each field's EFFECTIVE
// visible/disabled/required status and to recompute derived values; the React
// edge (src/forms) only reads the resulting status snapshots.
//
// A rule expresses, per field, when it is visible / disabled / required as a
// declarative condition tree ({field, op, value} leaves joined by all/any/not
// groups) with a function escape hatch, plus an optional `compute` that derives
// the field's value from the other fields.

import { getPath } from "./path";
import type { FieldValues } from "./types";

/** Comparison operators for a single-field condition leaf. */
export type ConditionOp =
  | "eq"
  | "neq"
  | "in"
  | "notIn"
  | "gt"
  | "gte"
  | "lt"
  | "lte"
  | "truthy"
  | "falsy"
  | "contains";

/** A single-field condition leaf: compare one field's value with `value`.
 *  `truthy`/`falsy` ignore `value`; `in`/`notIn` expect an array `value`;
 *  `contains` tests membership when the field value is a string or array. */
export interface FieldCondition<TValues extends object = FieldValues> {
  readonly field: string;
  readonly op: ConditionOp;
  readonly value?: unknown;
}

/** Boolean grouping of nested condition nodes.
 *  - `all`: every child must hold (AND)
 *  - `any`: at least one child must hold (OR)
 *  - `not`: the child must NOT hold
 *  Multiple keys on one group are themselves AND-ed together. */
export interface ConditionGroup<TValues extends object = FieldValues> {
  readonly all?: ReadonlyArray<ConditionNode<TValues>>;
  readonly any?: ReadonlyArray<ConditionNode<TValues>>;
  readonly not?: ConditionNode<TValues>;
}

/** A leaf or a group. */
export type ConditionNode<TValues extends object = FieldValues> =
  | FieldCondition<TValues>
  | ConditionGroup<TValues>;

/** Function escape hatch: read the whole value map, return a boolean. */
export type ConditionFn<TValues extends object = FieldValues> = (values: TValues) => boolean;

/** A condition expression: a declarative tree, a predicate function, or a plain
 *  boolean constant. */
export type ConditionExpr<TValues extends object = FieldValues> =
  | ConditionNode<TValues>
  | ConditionFn<TValues>
  | boolean;

/** Rule attached to a field: when it is visible / disabled / required, plus an
 *  optional derived value. Absent `visible` defaults to visible; absent
 *  `disabled`/`required` default to false. */
export interface FieldRule<TValues extends object = FieldValues> {
  /** when the field is shown (default: always visible) */
  readonly visible?: ConditionExpr<TValues>;
  /** when the field is disabled (default: never) */
  readonly disabled?: ConditionExpr<TValues>;
  /** when the field is required (default: never) */
  readonly required?: ConditionExpr<TValues>;
  /** derive this field's value from the others; recomputed on dependency change */
  readonly compute?: (values: TValues) => unknown;
  /** optional explicit dependency list for `compute` (documentation/perf hint;
   *  the engine recomputes computed fields on any value change regardless) */
  readonly deps?: ReadonlyArray<string>;
}

/** Field name → rule. */
export type FieldRules<TValues extends object = FieldValues> = {
  readonly [name: string]: FieldRule<TValues> | undefined;
};

/** A field's EFFECTIVE status after evaluating its rule against current values.
 *  Reference is stable across reads until one of the flags changes — the
 *  selector bail-out contract, matching FieldState. */
export interface FieldStatus {
  /** the field is shown */
  readonly visible: boolean;
  /** the field is present but not editable */
  readonly disabled: boolean;
  /** the field is required (drives asterisks / aria-required at the edge) */
  readonly required: boolean;
}

/** The status of a field with no rule: visible, enabled, optional. */
export const DEFAULT_FIELD_STATUS: FieldStatus = Object.freeze({
  visible: true,
  disabled: false,
  required: false,
});

function isGroup<TValues extends object>(
  node: ConditionNode<TValues>,
): node is ConditionGroup<TValues> {
  return !("field" in node && "op" in node);
}

function compare(op: ConditionOp, fieldValue: unknown, value: unknown): boolean {
  switch (op) {
    case "eq":
      return Object.is(fieldValue, value) || fieldValue === value;
    case "neq":
      return !(Object.is(fieldValue, value) || fieldValue === value);
    case "in":
      return Array.isArray(value) && value.some((v) => v === fieldValue);
    case "notIn":
      return !(Array.isArray(value) && value.some((v) => v === fieldValue));
    case "gt":
      return (fieldValue as number) > (value as number);
    case "gte":
      return (fieldValue as number) >= (value as number);
    case "lt":
      return (fieldValue as number) < (value as number);
    case "lte":
      return (fieldValue as number) <= (value as number);
    case "truthy":
      return Boolean(fieldValue);
    case "falsy":
      return !fieldValue;
    case "contains":
      if (typeof fieldValue === "string") return fieldValue.includes(String(value));
      if (Array.isArray(fieldValue)) return fieldValue.some((v) => v === value);
      return false;
    default:
      return false;
  }
}

function evaluateNode<TValues extends object>(
  node: ConditionNode<TValues>,
  values: TValues,
): boolean {
  if (isGroup(node)) {
    if (node.all && !node.all.every((child) => evaluateNode(child, values))) return false;
    if (node.any && !node.any.some((child) => evaluateNode(child, values))) return false;
    if (node.not && evaluateNode(node.not, values)) return false;
    return true;
  }
  const fieldValue = getPath(values, node.field);
  return compare(node.op, fieldValue, node.value);
}

/** Evaluate a condition expression against the current values. Boolean/function
 *  forms are honored directly; a tree is walked by evaluateNode. */
export function evaluateCondition<TValues extends object>(
  expr: ConditionExpr<TValues>,
  values: TValues,
): boolean {
  if (typeof expr === "boolean") return expr;
  if (typeof expr === "function") return expr(values);
  return evaluateNode(expr, values);
}

/** Resolve a field's effective status from its rule (or the default when the
 *  field has no rule). Absent `visible` ⇒ visible; absent disabled/required ⇒
 *  false. */
export function resolveFieldStatus<TValues extends object>(
  rule: FieldRule<TValues> | undefined,
  values: TValues,
): FieldStatus {
  if (!rule) return DEFAULT_FIELD_STATUS;
  return {
    visible: rule.visible === undefined ? true : evaluateCondition(rule.visible, values),
    disabled: rule.disabled === undefined ? false : evaluateCondition(rule.disabled, values),
    required: rule.required === undefined ? false : evaluateCondition(rule.required, values),
  };
}

/** A field is ACTIVE (its errors block submit, its value is submitted) when it
 *  is visible and not disabled. Hidden/disabled fields are excluded from
 *  validation and from the submitted value shape. */
export function isStatusActive(status: FieldStatus): boolean {
  return status.visible && !status.disabled;
}

/** Structural equality for status snapshots (drives the cache's bail-out). */
export function fieldStatusesEqual(a: FieldStatus, b: FieldStatus): boolean {
  return a.visible === b.visible && a.disabled === b.disabled && a.required === b.required;
}
