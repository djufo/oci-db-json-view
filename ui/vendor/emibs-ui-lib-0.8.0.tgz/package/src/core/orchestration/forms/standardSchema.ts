// core/orchestration/forms — Standard Schema V1 contract (inlined).
//
// The form engine validates through the Standard Schema interface
// (https://standardschema.dev) rather than binding to any one validation
// library. zod (>= 3.24) ships `~standard`, so a zod schema IS a Standard
// Schema and drops straight in; valibot/arktype/etc. could be added later
// without touching the engine. The spec is a handful of type-only declarations,
// so we inline it here to avoid a runtime dependency on `@standard-schema/spec`.
//
// Presentation-free: pure types, no JSX, no DOM.

/** A schema that conforms to the Standard Schema v1 interface. */
export interface StandardSchemaV1<Input = unknown, Output = Input> {
  readonly "~standard": StandardSchemaV1.Props<Input, Output>;
}

// eslint-disable-next-line @typescript-eslint/no-namespace
export declare namespace StandardSchemaV1 {
  /** The validation properties every Standard Schema exposes under `~standard`. */
  export interface Props<Input = unknown, Output = Input> {
    readonly version: 1;
    readonly vendor: string;
    readonly validate: (value: unknown) => Result<Output> | Promise<Result<Output>>;
    readonly types?: Types<Input, Output> | undefined;
  }

  export type Result<Output> = SuccessResult<Output> | FailureResult;

  export interface SuccessResult<Output> {
    readonly value: Output;
    readonly issues?: undefined;
  }

  export interface FailureResult {
    readonly issues: ReadonlyArray<Issue>;
  }

  export interface Issue {
    readonly message: string;
    readonly path?: ReadonlyArray<PropertyKey | PathSegment> | undefined;
  }

  export interface PathSegment {
    readonly key: PropertyKey;
  }

  export interface Types<Input = unknown, Output = Input> {
    readonly input: Input;
    readonly output: Output;
  }

  /** Infer a schema's accepted input type. */
  export type InferInput<Schema extends StandardSchemaV1> = NonNullable<
    Schema["~standard"]["types"]
  >["input"];

  /** Infer a schema's parsed/sanitized output type. */
  export type InferOutput<Schema extends StandardSchemaV1> = NonNullable<
    Schema["~standard"]["types"]
  >["output"];
}
