// core/orchestration/forms — headless form engine types.
//
// Presentation-free: these are pure data + function contracts. No JSX, no DOM
// rendering. The only React touchpoints for the whole feature (the <Form>
// wrapper, useField binding, EditableFormPanel composition) live in src/forms
// and compose this engine.

import type { FieldRules, FieldStatus } from "./conditions";
import type { FieldErrors, Resolver } from "./resolver";

/** Default form value map. Field names address slots in this record.
 *  Generics across the engine bound `TValues extends object`, so a value map
 *  declared as an `interface` (no index signature) is accepted just as well as
 *  a `type`; this alias is only the default when no explicit map is supplied. */
export type FieldValues = Record<string, unknown>;

/** Public field address. Top-level keys and nested paths both flow through this
 *  type; nested array indexes may be dotted or bracketed at the API edge. */
export type FieldPath = string;

/** When the engine FIRST validates a field, before it has an error:
 *  - onChange: on every value change
 *  - onBlur:   on blur
 *  - onSubmit: only when the form is submitted (default)
 *  - all:      on both change and blur */
export type ValidationMode = "onChange" | "onBlur" | "onSubmit" | "all";

/** Once a field is showing an error (or the form has been submitted once), when
 *  to RE-validate it:
 *  - onChange: on every value change (default)
 *  - onBlur:   on blur
 *  - onSubmit: only on the next submit */
export type ReValidateMode = "onChange" | "onBlur" | "onSubmit";

/** Immutable per-field snapshot. Its reference is stable across reads until the
 *  field actually changes — that reference stability is the selector bail-out
 *  contract that keeps a keystroke in one field from re-rendering its siblings. */
export interface FieldState<T = unknown> {
  readonly value: T;
  /** the field has been focused and blurred at least once */
  readonly touched: boolean;
  /** the current value differs from the field's initial value */
  readonly dirty: boolean;
  /** the field has been focused at least once */
  readonly visited: boolean;
  /** current validation message for this field, or undefined when valid */
  readonly error: string | undefined;
}

/** Immutable form-level snapshot. Reference is stable until one of these flags
 *  changes, so form-level subscribers bail out on unrelated field edits. */
export interface FormState {
  /** any registered field differs from its initial value */
  readonly isDirty: boolean;
  /** no field currently holds a validation error */
  readonly isValid: boolean;
  /** an async validation is in flight (debounced or awaiting a resolver) */
  readonly isValidating: boolean;
  /** a submit is in flight */
  readonly isSubmitting: boolean;
  /** number of times submit has been counted */
  readonly submitCount: number;
  /** form-level message (schema root issue or reconciled server error) */
  readonly submitError: string | undefined;
}

export interface RegisterOptions<T = unknown> {
  /** initial value seeded when the form has none for this field yet */
  defaultValue?: T;
}

export interface SetValueOptions {
  /** also mark the field touched (default false) */
  shouldTouch?: boolean;
  /** override the timing mode for this call: force-run (true) or skip (false)
   *  the field's validation after setting; defaults to the configured mode */
  shouldValidate?: boolean;
}

export interface FieldArrayMutationOptions extends SetValueOptions {
  /** default true for user-driven array mutations */
  shouldTouch?: boolean;
}

export interface FieldArrayRow {
  readonly id: string;
  readonly name: string;
  readonly index: number;
}

export interface FieldArrayState {
  readonly name: string;
  readonly fields: readonly FieldArrayRow[];
  readonly error: string | undefined;
}

export interface CreateFormStoreOptions<TValues extends object> {
  /** initial values; reset() restores these (plus any register defaultValues) */
  defaultValues?: Partial<TValues>;
  /** pluggable validation seam; when omitted the form never reports errors */
  resolver?: Resolver<TValues>;
  /** when a field is first validated (default "onSubmit") */
  mode?: ValidationMode;
  /** when an already-errored field re-validates (default "onChange") */
  reValidateMode?: ReValidateMode;
  /** debounce (ms) applied to change-triggered validation; useful for async
   *  resolvers so a remote check does not fire on every keystroke (default 0) */
  asyncDebounceMs?: number;
  /** declarative per-field condition + computed-value rules. Drives effective
   *  visible/disabled/required status, derived values, and the "hidden/disabled
   *  fields skip validation and are excluded from submit values" rule. */
  rules?: FieldRules<TValues>;
}

/** Handler invoked by handleSubmit once values pass validation. Receives the
 *  schema-sanitized values. May be async; throw a FormSubmissionError (or an
 *  object with fieldErrors/formError) to reconcile server errors. */
export type SubmitHandler<TValues extends object> = (values: TValues) => void | Promise<void>;

/** Invoked by handleSubmit when validation blocks the submit. */
export type SubmitErrorHandler = (errors: FieldErrors) => void;

/**
 * Headless, framework-agnostic form store. Owns per-field and form-level state
 * behind cached immutable snapshots and a single subscribe channel. Contains no
 * rendering; React bindings (useForm, useFieldState, <Form>, useField) sit on top.
 */
export interface FormStore<TValues extends object = FieldValues> {
  // registration -----------------------------------------------------------
  register<T = unknown>(name: FieldPath, options?: RegisterOptions<T>): void;
  unregister(name: FieldPath): void;
  isRegistered(name: string): boolean;
  getRegisteredNames(): FieldPath[];

  // values -----------------------------------------------------------------
  getValue<T = unknown>(name: FieldPath): T;
  getValues(): TValues;
  /** values as they would be submitted: computed fields resolved, and fields
   *  whose effective status is hidden or disabled dropped. */
  getSubmitValues(): Partial<TValues>;
  setValue<T = unknown>(name: FieldPath, value: T, options?: SetValueOptions): void;

  // arrays -----------------------------------------------------------------
  getFieldArrayState(name: FieldPath): FieldArrayState;
  appendFieldArrayItem<T = unknown>(name: FieldPath, value: T, options?: FieldArrayMutationOptions): void;
  insertFieldArrayItem<T = unknown>(
    name: FieldPath,
    index: number,
    value: T,
    options?: FieldArrayMutationOptions,
  ): void;
  removeFieldArrayItem(name: FieldPath, index: number, options?: FieldArrayMutationOptions): void;
  moveFieldArrayItem(name: FieldPath, fromIndex: number, toIndex: number, options?: FieldArrayMutationOptions): void;
  replaceFieldArrayItems<T = unknown>(
    name: FieldPath,
    values: readonly T[],
    options?: FieldArrayMutationOptions,
  ): void;

  // conditions + computed fields -------------------------------------------
  /** effective visible/disabled/required for a field. Cached; the reference is
   *  stable until the status actually changes, so a selector subscriber bails
   *  out on Object.is exactly like getFieldState. */
  getFieldStatus(name: FieldPath): FieldStatus;

  // field meta -------------------------------------------------------------
  setTouched(name: FieldPath, touched?: boolean): void;
  setVisited(name: FieldPath, visited?: boolean): void;

  // errors -----------------------------------------------------------------
  getError(name: FieldPath): string | undefined;
  getErrors(): FieldErrors;
  setError(name: FieldPath, message: string): void;
  /** clear one field's error, or all field + form errors when no name given */
  clearErrors(name?: FieldPath): void;
  setSubmitError(message: string | undefined): void;

  // validation -------------------------------------------------------------
  /** validate the whole form; applies errors and returns whether it is valid */
  validate(): Promise<boolean>;
  /** validate a single field (plus any already-errored fields, for cross-field
   *  rules); honors the async debounce for change-triggered calls */
  validateField(name: FieldPath, options?: { immediate?: boolean }): Promise<void>;

  // lifecycle --------------------------------------------------------------
  /** restore initial values; clears touched/visited/dirty, errors, submitError,
   *  submitCount, and the submitting flag */
  reset(nextValues?: Partial<TValues>): void;

  // submit -----------------------------------------------------------------
  setSubmitting(isSubmitting: boolean): void;
  countSubmit(): void;
  /** build a submit handler: validate → onValid(sanitized) → manage flags;
   *  reconciles thrown server errors and focuses the first errored field */
  handleSubmit(
    onValid: SubmitHandler<TValues>,
    onInvalid?: SubmitErrorHandler,
  ): (event?: { preventDefault?: () => void }) => Promise<void>;

  // focus (DOM-free request; the field binding consumes it) ----------------
  setFocus(name: FieldPath): void;
  getPendingFocus(): string | null;
  clearFocus(): void;

  // snapshots (cached; stable references power selector bail-out) -----------
  getFieldState<T = unknown>(name: FieldPath): FieldState<T>;
  getFormState(): FormState;

  // subscription -----------------------------------------------------------
  /** fires on any change; consumers bail out via snapshot reference equality */
  subscribe(listener: () => void): () => void;
}
