// core/orchestration/forms — change-value extraction.
//
// Field bindings accept EITHER a DOM change event (native inputs) OR a raw
// value (custom controls whose onChange emits the value directly). This reader
// normalizes both so register() and useField() share one contract.
//
// Presentation-free: a pure function, no JSX. It inspects a possible
// event.target shape without importing React or DOM lib types.

/** Read the effective next value from a change event or a raw value. */
export function readChangeValue(eventOrValue: unknown): unknown {
  if (
    eventOrValue !== null &&
    typeof eventOrValue === "object" &&
    "target" in eventOrValue &&
    (eventOrValue as { target?: unknown }).target !== null &&
    typeof (eventOrValue as { target?: unknown }).target === "object"
  ) {
    const target = (eventOrValue as { target: Record<string, unknown> }).target;
    if (
      "type" in target &&
      (target.type === "checkbox" || target.type === "radio") &&
      "checked" in target
    ) {
      return target.checked;
    }
    if ("value" in target) return target.value;
  }
  return eventOrValue;
}
