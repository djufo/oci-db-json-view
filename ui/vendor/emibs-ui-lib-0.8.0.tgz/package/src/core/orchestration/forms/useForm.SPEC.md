# useForm

`useForm` is the headless form engine's React binding — the one place a
component acquires a form store and the stable API over it. It is `core`, so it
is presentation-free: hooks and pure functions, no JSX. The rendering layer
(`<Form>`, `useField`, `<FormField>`, `<AutoForm>`, `<FormPanel>`) sits on top
of it in `src/forms`.

## Contract

- **Two call shapes.** `useForm<TValues>({ resolver?, mode?, ... })` takes the
  value type explicitly. `useForm({ schema })` infers `TValues` from a Standard
  Schema's *output* and makes that schema the resolver via
  `standardSchemaResolver` — one source of truth for shape and validation
  rather than a type and a validator that can disagree.
- **The store is created once.** It is held in a ref and survives every
  re-render; the returned API is stable. Changing the options object after the
  first render does not rebuild the store.
- **Attachment.** `register(name, options)` returns props to spread onto an
  input. Uncontrolled by default (`defaultValue`, no `value`); pass
  `{ controlled: true }` for the controlled escape hatch, which adds `value`.
  `unregister(name)` detaches.
- **Values.** `setValue` / `getValue` / `getValues` / `reset`.
- **Validation.** `trigger()` validates the whole form and resolves to its
  validity; `trigger(name)` validates one field and resolves when its async
  check settles, returning nothing — a per-field call answers "is this field
  settled", not "is the form valid". `getError` / `setError` / `clearErrors`
  read and write messages directly.
- **Submission.** `handleSubmit(onValid, onInvalid?)` returns an event handler
  that validates, then calls `onValid` with sanitized values, then reconciles
  errors and moves focus to the first invalid field. `setFocus(name)` does that
  focusing on demand.
- **Escape hatch.** `store` exposes the underlying headless store, which is what
  `<Form>`'s context and the selector hooks subscribe to.

## Subscription semantics

State is read through `useSyncExternalStore`, so a component re-renders when the
slice it actually read changes — not on every keystroke anywhere in the form.

## Non-goals

- No markup, no field chrome, no error rendering. Anything visible belongs to
  `src/forms`.
- Not a schema library. Validation is delegated to whatever Standard Schema or
  resolver is supplied.
- No persistence, no submission transport. `handleSubmit` hands sanitized values
  to a caller and stops there.
