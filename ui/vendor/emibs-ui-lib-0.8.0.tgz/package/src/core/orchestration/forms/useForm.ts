// core/orchestration/forms — React bindings for the headless form store.
//
// Hooks only, no JSX (allowed in core per ARCHITECTURE.md → Core: "types,
// hooks, pure functions only"). The <Form>/useField/EditableFormPanel wiring in
// src/forms is where JSX lives. Importing React here is a hook dependency, not
// a component import.

import { useCallback, useMemo, useRef, useSyncExternalStore } from "react";

import type { FieldStatus } from "./conditions";
import { readChangeValue } from "./event";
import { standardSchemaResolver, type FieldErrors } from "./resolver";
import type { StandardSchemaV1 } from "./standardSchema";
import { createFormStore } from "./store";
import type {
  CreateFormStoreOptions,
  FieldArrayMutationOptions,
  FieldArrayRow,
  FieldState,
  FieldValues,
  FormState,
  FormStore,
  RegisterOptions,
  SetValueOptions,
  SubmitErrorHandler,
  SubmitHandler,
} from "./types";

/** Props returned by register(), spread onto an input.
 *  Uncontrolled by default (no `value`); pass `{ controlled: true }` for the
 *  controlled escape hatch, which adds `value`. The higher-level Field binding
 *  (useField, src/forms) sits on top of this low-level attachment surface. */
export interface FieldRegistration<T = unknown> {
  name: string;
  onChange: (eventOrValue: unknown) => void;
  onBlur: () => void;
  onFocus: () => void;
  /** present in uncontrolled mode only */
  defaultValue?: T;
  /** present in controlled mode only */
  value?: T;
}

export interface RegisterFieldOptions<T = unknown> extends RegisterOptions<T> {
  /** controlled escape hatch: include a `value` prop bound to store state */
  controlled?: boolean;
}

export interface UseFormReturn<TValues extends object = FieldValues> {
  /** attach a field: registers it and returns props to spread onto an input */
  register<T = unknown>(name: string, options?: RegisterFieldOptions<T>): FieldRegistration<T>;
  unregister(name: string): void;
  setValue<T = unknown>(name: string, value: T, options?: SetValueOptions): void;
  getValue<T = unknown>(name: string): T;
  getValues(): TValues;
  reset(nextValues?: Partial<TValues>): void;

  // validation + errors ----------------------------------------------------
  /** validate the whole form (no name) or a single field; returns validity for
   *  the whole-form form. Field triggers resolve when the async check settles. */
  trigger(): Promise<boolean>;
  trigger(name: string): Promise<void>;
  getError(name: string): string | undefined;
  setError(name: string, message: string): void;
  clearErrors(name?: string): void;

  // submit -----------------------------------------------------------------
  /** build a submit handler (validate → onValid(sanitized) → reconcile/focus) */
  handleSubmit(
    onValid: SubmitHandler<TValues>,
    onInvalid?: SubmitErrorHandler,
  ): (event?: { preventDefault?: () => void }) => Promise<void>;
  setFocus(name: string): void;

  /** the underlying headless store (used by <Form> context and selector hooks) */
  readonly store: FormStore<TValues>;
}

export interface UseFieldArrayOptions<TValues extends object = FieldValues> {
  form: UseFormReturn<TValues>;
  name: string;
}

export interface UseFieldArrayReturn<TItem = unknown> {
  readonly name: string;
  readonly fields: readonly FieldArrayRow[];
  readonly error: string | undefined;
  append(value: TItem, options?: FieldArrayMutationOptions): void;
  insert(index: number, value: TItem, options?: FieldArrayMutationOptions): void;
  remove(index: number, options?: FieldArrayMutationOptions): void;
  move(fromIndex: number, toIndex: number, options?: FieldArrayMutationOptions): void;
  replace(values: readonly TItem[], options?: FieldArrayMutationOptions): void;
}

/** Options shared by every useForm call, in addition to store options. */
type UseFormOptions<TValues extends object> = CreateFormStoreOptions<TValues>;

/** useForm options when a Standard Schema drives validation + value inference. */
export type UseFormWithSchemaOptions<Schema extends StandardSchemaV1> = {
  schema: Schema;
} & Omit<CreateFormStoreOptions<StandardSchemaV1.InferOutput<Schema> & object>, "resolver">;

/**
 * Create (once) and bind a headless form store to a component. Returns a stable
 * API; the store persists across renders.
 *
 * Two forms:
 *   - useForm<TValues>({ resolver?, mode?, ... })   — explicit value type
 *   - useForm({ schema: z.object({...}) })          — value type INFERRED from
 *     the schema's output; the schema becomes the resolver (single source of
 *     truth) via standardSchemaResolver.
 */
export function useForm<Schema extends StandardSchemaV1>(
  options: UseFormWithSchemaOptions<Schema>,
): UseFormReturn<StandardSchemaV1.InferOutput<Schema> & object>;
export function useForm<TValues extends object = FieldValues>(
  options?: UseFormOptions<TValues>,
): UseFormReturn<TValues>;
export function useForm<TValues extends object = FieldValues>(
  options: (UseFormOptions<TValues> & { schema?: StandardSchemaV1 }) = {},
): UseFormReturn<TValues> {
  const storeRef = useRef<FormStore<TValues> | null>(null);
  if (storeRef.current === null) {
    const { schema, resolver, ...rest } = options;
    const effectiveResolver =
      resolver ??
      (schema
        ? (standardSchemaResolver(schema) as unknown as CreateFormStoreOptions<TValues>["resolver"])
        : undefined);
    storeRef.current = createFormStore<TValues>({ ...rest, resolver: effectiveResolver });
  }
  const store = storeRef.current;

  const register = useCallback(
    <T = unknown,>(name: string, opts?: RegisterFieldOptions<T>): FieldRegistration<T> => {
      store.register<T>(name, opts);
      const registration: FieldRegistration<T> = {
        name,
        onChange: (eventOrValue) =>
          store.setValue<T>(name, readChangeValue(eventOrValue) as T),
        onBlur: () => store.setTouched(name, true),
        onFocus: () => store.setVisited(name, true),
      };
      if (opts?.controlled) {
        registration.value = store.getValue<T>(name);
      } else {
        registration.defaultValue = store.getValue<T>(name);
      }
      return registration;
    },
    [store],
  );

  const unregister = useCallback<UseFormReturn<TValues>["unregister"]>((name) => store.unregister(name), [store]);
  const setValue = useCallback<UseFormReturn<TValues>["setValue"]>(
    (name, value, opts) => store.setValue(name, value, opts),
    [store],
  );
  const getValue = useCallback<UseFormReturn<TValues>["getValue"]>((name) => store.getValue(name), [store]);
  const getValues = useCallback<UseFormReturn<TValues>["getValues"]>(() => store.getValues(), [store]);
  const reset = useCallback<UseFormReturn<TValues>["reset"]>((next) => store.reset(next), [store]);
  const trigger = useCallback(
    (name?: string) =>
      (name === undefined ? store.validate() : store.validateField(name)) as Promise<boolean> & Promise<void>,
    [store],
  ) as UseFormReturn<TValues>["trigger"];
  const getError = useCallback<UseFormReturn<TValues>["getError"]>((name) => store.getError(name), [store]);
  const setError = useCallback<UseFormReturn<TValues>["setError"]>((name, message) => store.setError(name, message), [store]);
  const clearErrors = useCallback<UseFormReturn<TValues>["clearErrors"]>((name) => store.clearErrors(name), [store]);
  const handleSubmit = useCallback<UseFormReturn<TValues>["handleSubmit"]>(
    (onValid, onInvalid) => store.handleSubmit(onValid, onInvalid),
    [store],
  );
  const setFocus = useCallback<UseFormReturn<TValues>["setFocus"]>((name) => store.setFocus(name), [store]);

  const apiRef = useRef<UseFormReturn<TValues> | null>(null);
  if (apiRef.current === null) {
    apiRef.current = {
      register,
      unregister,
      setValue,
      getValue,
      getValues,
      reset,
      trigger,
      getError,
      setError,
      clearErrors,
      handleSubmit,
      setFocus,
      store,
    };
  }
  return apiRef.current;
}

/**
 * Subscribe to a single field's state. Re-renders only when THAT field changes
 * — a keystroke in a sibling field leaves this field's snapshot reference
 * untouched, so useSyncExternalStore bails out on Object.is. This is the
 * per-field perf contract.
 */
export function useFieldState<TValues extends object, T = unknown>(
  form: UseFormReturn<TValues>,
  name: string,
): FieldState<T> {
  const { store } = form;
  const getSnapshot = useCallback(() => store.getFieldState<T>(name), [store, name]);
  return useSyncExternalStore(store.subscribe, getSnapshot, getSnapshot);
}

/**
 * Subscribe to a single field's EFFECTIVE status (visible/disabled/required)
 * derived from the condition rules. Re-renders only when that field's status
 * changes — a value edit that doesn't flip any of the three flags leaves the
 * cached status reference intact, so useSyncExternalStore bails on Object.is.
 */
export function useFieldStatus<TValues extends object>(
  form: UseFormReturn<TValues>,
  name: string,
): FieldStatus {
  const { store } = form;
  const getSnapshot = useCallback(() => store.getFieldStatus(name), [store, name]);
  return useSyncExternalStore(store.subscribe, getSnapshot, getSnapshot);
}

/**
 * Subscribe to a field array's structural state. Row value edits do not change
 * this snapshot; only append/insert/remove/move/replace or the array-level
 * error produce a new reference.
 */
export function useFieldArray<TValues extends object = FieldValues, TItem = unknown>({
  form,
  name,
}: UseFieldArrayOptions<TValues>): UseFieldArrayReturn<TItem> {
  const { store } = form;
  const getSnapshot = useCallback(() => store.getFieldArrayState(name), [store, name]);
  const state = useSyncExternalStore(store.subscribe, getSnapshot, getSnapshot);

  const append = useCallback<UseFieldArrayReturn<TItem>["append"]>(
    (value, options) => store.appendFieldArrayItem(name, value, options),
    [store, name],
  );
  const insert = useCallback<UseFieldArrayReturn<TItem>["insert"]>(
    (index, value, options) => store.insertFieldArrayItem(name, index, value, options),
    [store, name],
  );
  const remove = useCallback<UseFieldArrayReturn<TItem>["remove"]>(
    (index, options) => store.removeFieldArrayItem(name, index, options),
    [store, name],
  );
  const move = useCallback<UseFieldArrayReturn<TItem>["move"]>(
    (fromIndex, toIndex, options) => store.moveFieldArrayItem(name, fromIndex, toIndex, options),
    [store, name],
  );
  const replace = useCallback<UseFieldArrayReturn<TItem>["replace"]>(
    (values, options) => store.replaceFieldArrayItems(name, values, options),
    [store, name],
  );

  return useMemo(
    () => ({
      name: state.name,
      fields: state.fields,
      error: state.error,
      append,
      insert,
      remove,
      move,
      replace,
    }),
    [append, insert, move, remove, replace, state.error, state.fields, state.name],
  );
}

/**
 * Subscribe to form-level state (isDirty/isValid/isValidating/isSubmitting/
 * submitCount/submitError). Bails out unless one of those flags actually changes.
 */
export function useFormState<TValues extends object>(form: UseFormReturn<TValues>): FormState {
  const { store } = form;
  return useSyncExternalStore(store.subscribe, store.getFormState, store.getFormState);
}

/**
 * General selector subscription. `selector` reads any slice off the store;
 * `isEqual` (default Object.is) decides when the slice changed. Re-renders only
 * on a changed slice — the reactive-selector-state contract for derived reads.
 */
export function useFormSelector<TValues extends object, T>(
  form: UseFormReturn<TValues>,
  selector: (store: FormStore<TValues>) => T,
  isEqual: (a: T, b: T) => boolean = Object.is,
): T {
  const { store } = form;
  const lastRef = useRef<{ value: T } | null>(null);
  const getSnapshot = useCallback(() => {
    const next = selector(store);
    if (lastRef.current !== null && isEqual(lastRef.current.value, next)) {
      return lastRef.current.value;
    }
    lastRef.current = { value: next };
    return next;
  }, [store, selector, isEqual]);
  return useSyncExternalStore(store.subscribe, getSnapshot, getSnapshot);
}

export type { FieldErrors };
