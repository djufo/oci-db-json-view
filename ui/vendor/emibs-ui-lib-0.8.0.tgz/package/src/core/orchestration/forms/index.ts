// core/orchestration/forms — public barrel for the headless form engine.
// Presentation-free. The React wrappers (<Form>, useField, EditableFormPanel
// composition) live in src/forms and compose this engine; consumers reach the
// whole feature through src/forms/index.ts.

export { createFormStore } from "./store";
export {
  useForm,
  useFieldState,
  useFieldStatus,
  useFieldArray,
  useFormState,
  useFormSelector,
} from "./useForm";
export {
  evaluateCondition,
  resolveFieldStatus,
  isStatusActive,
  DEFAULT_FIELD_STATUS,
} from "./conditions";
export { readChangeValue } from "./event";
export {
  standardSchemaResolver,
  FormSubmissionError,
  isFormSubmissionError,
  extractServerValidationErrors,
  ROOT_ERROR_KEY,
} from "./resolver";
export type {
  FieldRegistration,
  RegisterFieldOptions,
  UseFieldArrayOptions,
  UseFieldArrayReturn,
  UseFormReturn,
  UseFormWithSchemaOptions,
} from "./useForm";
export type {
  CreateFormStoreOptions,
  FieldArrayMutationOptions,
  FieldArrayRow,
  FieldArrayState,
  FieldPath,
  FieldState,
  FieldValues,
  FormState,
  FormStore,
  RegisterOptions,
  ReValidateMode,
  SetValueOptions,
  SubmitErrorHandler,
  SubmitHandler,
  ValidationMode,
} from "./types";
export type {
  FieldErrors,
  Resolver,
  ResolverResult,
  ServerValidationErrors,
} from "./resolver";
export type {
  ConditionOp,
  ConditionExpr,
  ConditionNode,
  ConditionGroup,
  ConditionFn,
  FieldCondition,
  FieldRule,
  FieldRules,
  FieldStatus,
} from "./conditions";
export type { StandardSchemaV1 } from "./standardSchema";
