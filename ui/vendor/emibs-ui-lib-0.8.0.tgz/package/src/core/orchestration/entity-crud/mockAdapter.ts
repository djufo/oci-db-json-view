import type {
  EntityCrudSort,
  EntityFilterValue,
  EntityFilterValues,
  EntityListRequest,
  EntityListResult,
  MockCrudAdapter,
} from "./adapter";
import type { EntityFieldName, EntityId, EntityRecord } from "../../config/entity-crud";

export interface MockCrudAdapterOptions<TRecord extends EntityRecord> {
  readonly identity?: EntityFieldName<TRecord>;
  readonly idPrefix?: string;
}

export function createMockAdapter<TRecord extends EntityRecord>(
  seed: readonly TRecord[],
  options: MockCrudAdapterOptions<TRecord> = {},
): MockCrudAdapter<TRecord> {
  const identity = options.identity ?? ("id" as EntityFieldName<TRecord>);
  const idPrefix = options.idPrefix ?? "record";
  const rows = seed.map(cloneRecord);
  let nextId = rows.length + 1;

  const adapter: MockCrudAdapter<TRecord> = {
    async list(request) {
      return listRows(rows, request);
    },

    async get(id) {
      const row = rows.find((entry) => sameId(entry[identity], id));
      return row ? cloneRecord(row) : null;
    },

    async create(values) {
      const record = { ...values } as TRecord;
      const currentId = record[identity];
      if (currentId === undefined || currentId === null || currentId === "") {
        record[identity] = `${idPrefix}-${nextId++}` as TRecord[typeof identity];
      }
      rows.push(cloneRecord(record));
      return cloneRecord(record);
    },

    async update(id, values) {
      const index = rows.findIndex((entry) => sameId(entry[identity], id));
      if (index < 0) {
        throw new Error(`Record ${String(id)} was not found.`);
      }
      const next = { ...rows[index], ...values, [identity]: rows[index][identity] } as TRecord;
      rows[index] = cloneRecord(next);
      return cloneRecord(next);
    },

    async remove(id) {
      const index = rows.findIndex((entry) => sameId(entry[identity], id));
      if (index < 0) {
        throw new Error(`Record ${String(id)} was not found.`);
      }
      rows.splice(index, 1);
    },

    snapshot() {
      return rows.map(cloneRecord);
    },
  };

  return adapter;
}

function listRows<TRecord extends EntityRecord>(
  rows: readonly TRecord[],
  request: EntityListRequest<TRecord>,
): EntityListResult<TRecord> {
  const page = Math.max(1, request.page);
  const pageSize = Math.max(1, request.pageSize);
  const filtered = rows.filter((row) => matchesFilters(row, request.filter));
  const sorted = sortRows(filtered, request.sort ?? null);
  const start = (page - 1) * pageSize;
  const pageRows = sorted.slice(start, start + pageSize).map(cloneRecord);
  return {
    rows: pageRows,
    total: sorted.length,
  };
}

function sortRows<TRecord extends EntityRecord>(
  rows: readonly TRecord[],
  sort: EntityCrudSort<TRecord> | null,
): TRecord[] {
  const next = [...rows];
  if (!sort) return next;
  const direction = sort.direction === "asc" ? 1 : -1;
  next.sort((a, b) => compareValues(a[sort.field], b[sort.field]) * direction);
  return next;
}

function matchesFilters<TRecord extends EntityRecord>(
  row: TRecord,
  filters: EntityFilterValues<TRecord> | undefined,
): boolean {
  if (!filters) return true;
  for (const [field, criterion] of Object.entries(filters)) {
    if (isEmptyFilterValue(criterion)) continue;
    if (!matchesFilterValue(row[field], criterion)) return false;
  }
  return true;
}

function matchesFilterValue(rowValue: unknown, criterion: EntityFilterValue): boolean {
  if (Array.isArray(criterion)) {
    const allowed = criterion.map((value) => String(value));
    if (Array.isArray(rowValue)) {
      return rowValue.some((value) => allowed.includes(String(value)));
    }
    return allowed.includes(String(rowValue));
  }
  if (typeof criterion === "string") {
    if (Array.isArray(rowValue)) {
      return rowValue.some((value) => String(value).toLowerCase().includes(criterion.toLowerCase()));
    }
    return String(rowValue ?? "").toLowerCase().includes(criterion.toLowerCase());
  }
  return String(rowValue) === String(criterion);
}

function isEmptyFilterValue(value: EntityFilterValue): boolean {
  return (
    value === undefined ||
    value === null ||
    value === "" ||
    (Array.isArray(value) && value.length === 0)
  );
}

function compareValues(a: unknown, b: unknown): number {
  if (typeof a === "number" && typeof b === "number") return a - b;
  if (typeof a === "boolean" && typeof b === "boolean") return Number(a) - Number(b);
  return String(a ?? "").localeCompare(String(b ?? ""), undefined, { numeric: true });
}

function sameId(value: unknown, id: EntityId): boolean {
  return String(value) === String(id);
}

function cloneRecord<TRecord extends EntityRecord>(record: TRecord): TRecord {
  return { ...record };
}
