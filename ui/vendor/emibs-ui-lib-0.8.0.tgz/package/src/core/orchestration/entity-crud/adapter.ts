import type { EntityFieldName, EntityId, EntityRecord } from "../../config/entity-crud";

export type EntityCrudSortDirection = "asc" | "desc";

export interface EntityCrudSort<TRecord extends EntityRecord> {
  readonly field: EntityFieldName<TRecord>;
  readonly direction: EntityCrudSortDirection;
}

export type EntityFilterValue =
  | string
  | number
  | boolean
  | readonly (string | number | boolean)[]
  | null
  | undefined;

export type EntityFilterValues<TRecord extends EntityRecord = EntityRecord> = Partial<
  Record<EntityFieldName<TRecord> | string, EntityFilterValue>
>;

export interface EntityListRequest<TRecord extends EntityRecord> {
  readonly page: number;
  readonly pageSize: number;
  readonly sort?: EntityCrudSort<TRecord> | null;
  readonly filter?: EntityFilterValues<TRecord>;
}

export interface EntityListResult<TRecord extends EntityRecord> {
  readonly rows: readonly TRecord[];
  readonly total: number;
}

export interface CrudAdapter<TRecord extends EntityRecord> {
  list(request: EntityListRequest<TRecord>): Promise<EntityListResult<TRecord>>;
  get(id: EntityId): Promise<TRecord | null>;
  create(values: Partial<TRecord>): Promise<TRecord>;
  update(id: EntityId, values: Partial<TRecord>): Promise<TRecord>;
  remove(id: EntityId): Promise<void>;
}

export interface MockCrudAdapter<TRecord extends EntityRecord> extends CrudAdapter<TRecord> {
  snapshot(): readonly TRecord[];
}
