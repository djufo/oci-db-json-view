// core — the decoupled-logic home for emibs-ui-lib.
//
// Two sub-areas, each with its own barrel (see ARCHITECTURE.md → Core and the
// "Folder shape" note there):
//   - config        declarative configuration decoupled from form + primitives.
//   - orchestration  cross-component / application coordination logic.
//
// The whole layer is presentation-free: no JSX, no imports of src/components/**.
// Primitives must NOT import this layer; higher layers (components, forms,
// catalog/explorer) may. The library's public surface (src/lib) re-exports this
// barrel so consumers reach core through the package entry, not deep paths.
export * from "./config";
export * from "./orchestration";
