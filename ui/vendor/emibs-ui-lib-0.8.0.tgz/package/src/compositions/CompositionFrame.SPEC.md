# CompositionFrame

`CompositionFrame` is the grid shell every composed app mockup in
`src/compositions/registry.tsx` is laid out in. It owns placement only: the
mockups own their content.

## Contract

- `layout` describes one CSS grid — `columns`, optional `rows`, `areas` (one
  string per grid row, quoted into `grid-template-areas` by the frame), optional
  `gap` and `minHeight`. The frame writes these to inline style because a
  composition's grid is data, not a fixed set of variants.
- `slots` is the ordered list of regions. Each carries an `id` (React key), the
  `area` it occupies, an optional `label`, an optional `className`, and a
  `render()` thunk. Rendering is a thunk so a slot's subtree is only built when
  the frame renders it.
- `chrome` selects the slot's surface: the default `"panel"` adds the framed
  panel treatment, `"none"` leaves the slot bare for content that brings its own
  surface (a full-bleed shell, a nested frame). This is the only visual choice
  the frame offers.
- `ariaLabel` names the outer `<section>`; it defaults to
  `"Composed app mockup"`.

## Semantics

The frame renders a labelled outer `<section>` containing the grid, and one
`<section>` per slot. A slot whose `label` is a plain string also becomes that
slot section's accessible name; a `ReactNode` label is rendered but is not
lifted into `aria-label`, because only a string can be.

## Non-goals

- No responsive behaviour of its own. A composition that needs to reflow states
  that in its own `layout` values.
- No slot state — no selection, collapse, resize, or drag. A slot that needs
  those brings a component that has them.
- Not a page shell. Product page chrome is `WorkspaceShell`; this frame exists
  to arrange catalogued components into a reviewable mockup.
