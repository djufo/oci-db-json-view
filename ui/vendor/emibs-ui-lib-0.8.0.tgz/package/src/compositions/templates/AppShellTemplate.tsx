// App template: FRAME + SHELL
//
// The whole app around a page. AppFrame owns the theme, the density and the
// user's saved appearance choice; WorkspaceShell is the chrome; the page goes
// inside. This is the entire root of a house-style app — it needs no CSS.
import { type ReactNode } from "react";
import { AppFrame } from "../../components/layout/AppFrame";
import { AppearanceControls } from "../../components/layout/AppearanceControls";
import { WorkspaceShell } from "../../components/layout/WorkspaceShell";

export type AppShellTemplateProps = {
  /** Which tab is current. */
  active?: "overview" | "jobs" | "settings";
  /** Persist the appearance choice under this prefix. Omit for an in-memory demo. */
  storageKey?: string;
  children: ReactNode;
};

export function AppShellTemplate({ active = "jobs", storageKey, children }: AppShellTemplateProps) {
  return (
    <AppFrame defaultDensity="compact" storageKey={storageKey}>
      <WorkspaceShell
        actions={<AppearanceControls showDensity />}
        brand="Crawler"
        identity="ona@example.org"
        subtitle="Workspace"
        tabs={[
          { id: "overview", label: "Overview", href: "#", active: active === "overview" },
          { id: "jobs", label: "Jobs", href: "#", active: active === "jobs" },
          { id: "settings", label: "Settings", href: "#", active: active === "settings" },
        ]}
      >
        {children}
      </WorkspaceShell>
    </AppFrame>
  );
}
