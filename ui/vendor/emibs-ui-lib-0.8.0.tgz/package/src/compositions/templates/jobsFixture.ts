// Sample data shared by the page-template recipes. A real page loads this
// from its API; the recipes only need something table-shaped to show.

export type Job = {
  id: string;
  name: string;
  owner: string;
  status: "running" | "done" | "failed" | "queued";
  pages: number;
  updated: string;
};

export const jobs: Job[] = [
  { id: "j-1042", name: "Docs site refresh", owner: "Ona", status: "running", pages: 1284, updated: "2 min ago" },
  { id: "j-1041", name: "Partner catalogue", owner: "Marek", status: "done", pages: 9310, updated: "1 h ago" },
  { id: "j-1040", name: "Pricing pages", owner: "Ona", status: "failed", pages: 212, updated: "3 h ago" },
  { id: "j-1039", name: "Help centre", owner: "Lukas", status: "queued", pages: 0, updated: "yesterday" },
];

export const jobStatusTone = { running: "info", done: "success", failed: "danger", queued: "neutral" } as const;
