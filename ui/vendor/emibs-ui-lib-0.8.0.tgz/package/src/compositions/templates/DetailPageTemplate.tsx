// Page template: DETAIL
//
// One record: heading with a way back and its status, headline numbers, then
// supporting facts beside the main body. PageColumns stacks the two regions on
// a narrow screen.
import { MetricGrid } from "../../components/data/MetricGrid";
import { PageHeader } from "../../components/layout/PageHeader";
import { PageColumns, PageScaffold } from "../../components/layout/PageScaffold";
import { SectionCard } from "../../components/layout/SectionCard";
import { DescriptionList } from "../../components/primitives/DescriptionList";

export function DetailPageTemplate() {
  return (
    <PageScaffold
      header={
        <PageHeader
          back={{ label: "Jobs", href: "#" }}
          badges={[{ id: "status", label: "running", tone: "info" }]}
          density="compact"
          description="Started by Ona, 2 minutes ago."
          eyebrow="Job j-1042"
          title="Docs site refresh"
        />
      }
    >
      <MetricGrid
        columns={4}
        density="compact"
        items={[
          { id: "pages", label: "Pages", value: "1,284" },
          { id: "queued", label: "Queued", value: "316", tone: "info" },
          { id: "failed", label: "Failed", value: "4", tone: "danger" },
          { id: "rate", label: "Rate", value: "42/min" },
        ]}
      />
      <PageColumns layout="aside-main">
        <SectionCard density="compact" title="Configuration">
          <DescriptionList
            columns={1}
            density="compact"
            items={[
              { id: "seed", label: "Seed", value: "docs.example.org" },
              { id: "depth", label: "Depth", value: "4" },
              { id: "scope", label: "Scope", value: "Same host" },
            ]}
          />
        </SectionCard>
        <SectionCard density="compact" description="Most recent first." title="Activity">
          <DescriptionList
            columns={1}
            density="compact"
            items={[
              { id: "a", label: "09:42", value: "Fetched 120 pages" },
              { id: "b", label: "09:40", value: "Queue grew by 316 links" },
              { id: "c", label: "09:39", value: "Crawl started" },
            ]}
          />
        </SectionCard>
      </PageColumns>
    </PageScaffold>
  );
}
