// App template: CONSOLE (rail navigation + inspector)
//
// For an operator console with many sections: an icon rail down the left, the
// page in the middle, and the inspected record in a column on the right. The
// rail, the page and the inspector scroll independently, so navigation and the
// record stay put while the page moves. On a phone the rail becomes a bottom
// bar and the inspector drops under the page.
import { Activity, Bot, FileText, LayoutDashboard, Settings, ShieldCheck } from "lucide-react";
import { useState, type ReactNode } from "react";
import { AppFrame } from "../../components/layout/AppFrame";
import { AppearanceControls } from "../../components/layout/AppearanceControls";
import { InspectorRail } from "../../components/layout/InspectorRail";
import { WorkspaceShell } from "../../components/layout/WorkspaceShell";
import { DescriptionList } from "../../components/primitives/DescriptionList";

export type ConsoleShellTemplateProps = {
  /** Show the inspector column for a selected record. */
  inspecting?: boolean;
  /** Persist the appearance choice under this prefix. Omit for an in-memory demo. */
  storageKey?: string;
  children: ReactNode;
};

export function ConsoleShellTemplate({ inspecting = true, storageKey, children }: ConsoleShellTemplateProps) {
  const [inspectorTab, setInspectorTab] = useState("overview");
  const [open, setOpen] = useState(inspecting);

  return (
    <AppFrame defaultDensity="compact" storageKey={storageKey}>
      <WorkspaceShell
        actions={<AppearanceControls />}
        brand="Crawler"
        identity="ona@example.org"
        inspector={
          open ? (
            <InspectorRail
              activeTab={inspectorTab}
              eyebrow="job"
              onClose={() => setOpen(false)}
              onTabChange={setInspectorTab}
              tabs={[
                {
                  id: "overview",
                  label: "Overview",
                  content: (
                    <DescriptionList
                      columns={1}
                      density="compact"
                      items={[
                        { id: "owner", label: "Owner", value: "Ona" },
                        { id: "pages", label: "Pages", value: "1,284" },
                        { id: "status", label: "Status", value: "Running" },
                      ]}
                    />
                  ),
                },
                { id: "audit", label: "Audit", content: <p>Started 2 minutes ago by Ona.</p> },
              ]}
              targetId="j-1042"
              title="Docs site refresh"
            />
          ) : undefined
        }
        navigation="rail"
        railItems="icons"
        subtitle="Console"
        tabLabel="Console sections"
        tabs={[
          { id: "overview", label: "Overview", href: "#", icon: <LayoutDashboard size={18} aria-hidden="true" /> },
          { id: "jobs", label: "Jobs", href: "#", icon: <Activity size={18} aria-hidden="true" />, active: true },
          { id: "agents", label: "Agents", href: "#", icon: <Bot size={18} aria-hidden="true" /> },
          { id: "documents", label: "Documents", href: "#", icon: <FileText size={18} aria-hidden="true" /> },
          { id: "settings", label: "Settings", href: "#", icon: <Settings size={18} aria-hidden="true" />, group: "footer" },
          { id: "admin", label: "Admin", href: "#", icon: <ShieldCheck size={18} aria-hidden="true" />, group: "footer" },
        ]}
      >
        {children}
      </WorkspaceShell>
    </AppFrame>
  );
}
