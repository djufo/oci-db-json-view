// Page template: DASHBOARD
//
// An overview: headline numbers first, then two panels side by side. Use it
// for a landing page that answers "is everything all right?" at a glance.
import { RefreshCw } from "lucide-react";
import { DataTable, type DataTableColumn } from "../../components/data/DataTable";
import { MetricGrid } from "../../components/data/MetricGrid";
import { NoticeBanner } from "../../components/feedback/NoticeBanner";
import { PageHeader } from "../../components/layout/PageHeader";
import { PageColumns, PageScaffold } from "../../components/layout/PageScaffold";
import { SectionCard } from "../../components/layout/SectionCard";
import { Badge } from "../../components/primitives/Badge";
import { Button } from "../../components/primitives/Button";
import { DescriptionList } from "../../components/primitives/DescriptionList";
import { jobs, jobStatusTone, type Job } from "./jobsFixture";

const columns: DataTableColumn<Job>[] = [
  { id: "name", header: "Job", accessor: (job) => job.name, rowHeader: true, sortable: false },
  { id: "status", header: "Status", accessor: (job) => job.status, sortable: false, cell: (job) => <Badge tone={jobStatusTone[job.status]}>{job.status}</Badge> },
  { id: "updated", header: "Updated", accessor: (job) => job.updated, sortable: false },
];

export function DashboardPageTemplate() {
  return (
    <PageScaffold
      header={
        <PageHeader
          actions={
            <Button size="sm" variant="secondary">
              <RefreshCw size={15} aria-hidden="true" /> Refresh
            </Button>
          }
          density="compact"
          description="Crawler health across this workspace."
          eyebrow="Crawler"
          title="Overview"
        />
      }
      notice={
        <NoticeBanner density="compact" title="One job needs attention" tone="warning">
          Pricing pages failed 3 hours ago.
        </NoticeBanner>
      }
    >
      <MetricGrid
        columns={4}
        density="compact"
        items={[
          { id: "running", label: "Running", value: "1", tone: "info" },
          { id: "queued", label: "Queued", value: "1" },
          { id: "failed", label: "Failed today", value: "1", tone: "danger" },
          { id: "pages", label: "Pages today", value: "10,806", tone: "success" },
        ]}
      />
      <PageColumns layout="main-aside">
        <SectionCard density="compact" title="Recent jobs">
          <DataTable ariaLabel="Recent jobs" columns={columns} data={jobs} density="compact" getRowId={(job) => job.id} showPagination={false} />
        </SectionCard>
        <SectionCard density="compact" title="Service">
          <DescriptionList
            columns={1}
            density="compact"
            items={[
              { id: "workers", label: "Workers", value: "4 of 4 healthy" },
              { id: "queue", label: "Queue depth", value: "316" },
              { id: "version", label: "Version", value: "2.14.0" },
            ]}
          />
        </SectionCard>
      </PageColumns>
    </PageScaffold>
  );
}
