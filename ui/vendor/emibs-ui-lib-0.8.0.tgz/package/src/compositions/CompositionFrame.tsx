import { type CSSProperties, type ReactNode } from "react";
import { cn } from "../lib";

export type CompositionLayout = {
  columns: string;
  rows?: string;
  areas: string[];
  gap?: string | number;
  minHeight?: string | number;
};

export type CompositionSlot = {
  id: string;
  area: string;
  label?: ReactNode;
  chrome?: "none" | "panel";
  className?: string;
  render: () => ReactNode;
};

export type CompositionFrameProps = {
  layout: CompositionLayout;
  slots: CompositionSlot[];
  ariaLabel?: string;
  className?: string;
};

export function CompositionFrame({
  layout,
  slots,
  ariaLabel = "Composed app mockup",
  className,
}: CompositionFrameProps) {
  const style: CSSProperties = {
    gridTemplateColumns: layout.columns,
    gridTemplateRows: layout.rows,
    gridTemplateAreas: layout.areas.map((row) => `"${row}"`).join(" "),
    gap: layout.gap,
    minHeight: layout.minHeight,
  };

  return (
    <section className={cn("ui-composition-frame", className)} aria-label={ariaLabel}>
      <div className="ui-composition-frame__grid" style={style}>
        {slots.map((slot) => (
          <section
            key={slot.id}
            className={cn(
              "ui-composition-frame__slot",
              slot.chrome !== "none" && "ui-composition-frame__slot--panel",
              slot.className,
            )}
            style={{ gridArea: slot.area }}
            aria-label={typeof slot.label === "string" ? slot.label : undefined}
          >
            {slot.label ? <div className="ui-composition-frame__slot-label">{slot.label}</div> : null}
            <div className="ui-composition-frame__slot-body">{slot.render()}</div>
          </section>
        ))}
      </div>
    </section>
  );
}
