import type { ReactNode } from "react";

export type MockupSourceApp = "Score" | "eLitua" | "Shared";

export type MockupStatus = "draft" | "reviewable" | "adopted";

export type MockupMeta = {
  id: string;
  name: string;
  description: string;
  sourceApp: MockupSourceApp[];
  patterns: string[];
  status: MockupStatus;
  componentIds: string[];
  slots: string[];
};

export type MockupEntry = MockupMeta & {
  render: () => ReactNode;
};
