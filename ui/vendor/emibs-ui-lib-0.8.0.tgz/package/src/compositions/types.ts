import type { ReactNode } from "react";

export type MockupSourceApp = "Score" | "eLitua" | "Shared";

export type MockupStatus = "draft" | "reviewable" | "adopted";

export type MockupMeta = {
  id: string;
  name: string;
  description: string;
  sourceApp: MockupSourceApp[];
  patterns: string[];
  status: MockupStatus;
  componentIds: string[];
  slots: string[];
  /**
   * `src`-relative path of the single file that implements this mockup, when it
   * is a copyable recipe. The catalog shows that file's source beside the page.
   */
  sourcePath?: string;
};

export type MockupEntry = MockupMeta & {
  render: () => ReactNode;
};
