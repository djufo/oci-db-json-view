# FormPanel

An engine-driven form rendered through the existing `EditableFormPanel` layout
shell. The headless engine (`useForm`) supplies state, validation, and errors;
`EditableFormPanel` supplies the layout (header, badges, section chrome, action
strip, footer). Each field spec becomes an accessible `<FormField>` (Field
primitive → aria wiring), the form-level submit error surfaces as a panel
message, and the panel's native submit routes through the engine's
`handleSubmit` (validate → `onSubmit(sanitized)` → server-error reconcile →
focus).

Use `FormPanel` when you want to hand-author each field (labels, custom controls
via the `render` slot) but keep the engine + panel chrome. Use `AutoForm` when
the fields should be generated from a `FormSpec`/schema.

Owning epic: issue-552 (headless form engine), story issue-595 (Field-contract
binding + EditableFormPanel `<Form>`).

## Import

```tsx
import { FormPanel, useForm } from "emibs-ui-lib/forms";
```

## Props

| Prop | Type | Description |
| --- | --- | --- |
| `form` | `UseFormReturn<TValues>` | The engine instance from `useForm` (required). |
| `onSubmit` | `SubmitHandler<TValues>` | Valid-submit handler; receives sanitized values (required). |
| `onInvalid` | `SubmitErrorHandler` | Called when validation blocks the submit. |
| `sections` | `FormPanelSectionSpec[]` | Titled groups of field specs. Each field: `name`, `label`, `type`, `required`, `wide`, and an optional `render(binding)` for a custom control. |
| `showErrorSummary` / `errorSummaryTitle` / `errorSummaryDescription` | summary chrome | The default submit-failure summary lists current field errors as links that focus the matching field. |
| `successMessage` | `ReactNode` | Optional post-submit confirmation rendered in a `role="status"` live region. |
| `showOptionalLabels` / `announceErrors` | boolean | Toggle the optional field convention and hidden polite error announcer. |
| `title` / `eyebrow` / `subtitle` / `badges` / `messages` / `actions` / `footer` / `variant` | panel chrome | Passed to `EditableFormPanel`. |

## Accessibility

The Field primitive wraps each control with label association, `aria-invalid` on
error, `aria-describedby` → description/hint/error, and a stable generated field
id (`form-field-<name>`) used by summary links and focus requests. Required
fields render the shared `*` marker with screen-reader text; optional fields
render `Optional` when `showOptionalLabels` is enabled.

Field errors are also mirrored into a hidden `role="status"` / `aria-live="polite"`
announcer that de-duplicates unchanged error states. On submit failure,
`ErrorSummary` renders at the top of the panel messages, lists current field
errors as in-page links, and focuses the matching field through the same Field
contract id. The form-level submit error is surfaced as an `EditableFormPanel`
message.

Server validation errors use the engine payload shape:

```ts
throw new FormSubmissionError({
  formError: "Could not save.",
  fieldErrors: { email: "Email already exists" },
});
```
