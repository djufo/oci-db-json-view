// src/forms — <ArrayField>: accessible repeatable-group composition.
//
// The headless row state lives in core/useFieldArray. This component only owns
// the form-edge rendering: row list semantics, add/remove/reorder buttons,
// keyboard reorder, array-level error display through Field, and focus handoff.

import {
  useId,
  useRef,
  type KeyboardEvent,
  type ReactNode,
} from "react";
import { ArrowDown, ArrowUp, Plus, Trash2 } from "lucide-react";

import {
  useFieldArray,
  type FieldArrayMutationOptions,
  type FieldArrayRow,
  type FieldValues,
  type UseFormReturn,
} from "../core/orchestration/forms";
import { Button, Field } from "../lib";
import { useOptionalFormContext } from "./Form";

export interface ArrayFieldRowRenderContext {
  row: FieldArrayRow;
  id: string;
  name: string;
  index: number;
  remove: () => void;
  moveUp: () => void;
  moveDown: () => void;
}

export interface ArrayFieldProps<
  TValues extends object = FieldValues,
  TItem = Record<string, unknown>,
> {
  name: string;
  label: ReactNode;
  form?: UseFormReturn<TValues>;
  description?: ReactNode;
  hint?: ReactNode;
  required?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  wide?: boolean;
  labelHidden?: boolean;
  className?: string;
  addLabel?: ReactNode;
  emptyLabel?: ReactNode;
  rowLabel?: (index: number) => ReactNode;
  removeLabel?: (index: number) => string;
  moveUpLabel?: (index: number) => string;
  moveDownLabel?: (index: number) => string;
  createItem?: () => TItem;
  mutationOptions?: FieldArrayMutationOptions;
  /** Return the nested field to focus after add/remove/reorder. */
  getFocusName?: (rowName: string, index: number) => string | undefined;
  children: (context: ArrayFieldRowRenderContext) => ReactNode;
}

export function ArrayField<
  TValues extends object = FieldValues,
  TItem = Record<string, unknown>,
>({
  name,
  label,
  form: explicitForm,
  description,
  hint,
  required,
  disabled = false,
  readOnly = false,
  wide,
  labelHidden,
  className,
  addLabel = "Add row",
  emptyLabel = "No rows.",
  rowLabel = (index) => `Row ${index + 1}`,
  removeLabel = (index) => `Remove row ${index + 1}`,
  moveUpLabel = (index) => `Move row ${index + 1} up`,
  moveDownLabel = (index) => `Move row ${index + 1} down`,
  createItem = () => ({} as TItem),
  mutationOptions,
  getFocusName,
  children,
}: ArrayFieldProps<TValues, TItem>) {
  const contextForm = useOptionalFormContext<TValues>();
  const form = explicitForm ?? contextForm;
  if (!form) {
    throw new Error("ArrayField requires a <Form>/<FormProvider> or an explicit `form` prop.");
  }

  const listId = useId();
  const addButtonRef = useRef<HTMLButtonElement | null>(null);
  const fieldArray = useFieldArray<TValues, TItem>({ form, name });
  const canMutate = !disabled && !readOnly;

  const focusRow = (index: number) => {
    const rowName = `${fieldArray.name}.${index}`;
    const focusName = getFocusName?.(rowName, index);
    if (focusName) {
      form.setFocus(focusName);
      return;
    }
    addButtonRef.current?.focus();
  };

  const append = () => {
    const index = fieldArray.fields.length;
    fieldArray.append(createItem(), mutationOptions);
    focusRow(index);
  };

  const remove = (index: number) => {
    fieldArray.remove(index, mutationOptions);
    const nextIndex = Math.min(index, fieldArray.fields.length - 2);
    if (nextIndex >= 0) focusRow(nextIndex);
    else addButtonRef.current?.focus();
  };

  const move = (fromIndex: number, toIndex: number) => {
    fieldArray.move(fromIndex, toIndex, mutationOptions);
    focusRow(toIndex);
  };

  const onRowKeyDown = (event: KeyboardEvent<HTMLDivElement>, index: number) => {
    if (!canMutate || !event.altKey) return;
    if (event.key === "ArrowUp" && index > 0) {
      event.preventDefault();
      move(index, index - 1);
    }
    if (event.key === "ArrowDown" && index < fieldArray.fields.length - 1) {
      event.preventDefault();
      move(index, index + 1);
    }
  };

  const control = (
    <div
      id={listId}
      role="group"
      aria-label={typeof label === "string" ? label : undefined}
      aria-live="polite"
      className="ui-editable-form__section-body"
    >
      <div className="ui-editable-form__action-strip">
        <button
          ref={addButtonRef}
          type="button"
          className="ui-button ui-button--secondary ui-button--sm"
          disabled={!canMutate}
          onClick={append}
        >
          <Plus size={15} aria-hidden="true" />
          {addLabel}
        </button>
        <span className="ui-field__meta" aria-live="polite">
          {fieldArray.fields.length} {fieldArray.fields.length === 1 ? "row" : "rows"}
        </span>
      </div>
      <div className="ui-editable-form__result-list" role="list">
        {fieldArray.fields.length === 0 ? (
          <p className="ui-editable-form__result-empty">{emptyLabel}</p>
        ) : null}
        {fieldArray.fields.map((row, index) => (
          <div
            className="ui-editable-form__result-item"
            key={row.id}
            role="listitem"
            tabIndex={0}
            aria-label={typeof rowLabel(index) === "string" ? String(rowLabel(index)) : undefined}
            onKeyDown={(event) => onRowKeyDown(event, index)}
          >
            <div className="ui-editable-form__result-content">
              <strong>{rowLabel(index)}</strong>
              {children({
                row,
                id: row.id,
                name: row.name,
                index,
                remove: () => remove(index),
                moveUp: () => move(index, index - 1),
                moveDown: () => move(index, index + 1),
              })}
            </div>
            <span className="ui-editable-form__result-action">
              <Button
                type="button"
                size="sm"
                variant="ghost"
                disabled={!canMutate || index === 0}
                aria-label={moveUpLabel(index)}
                onClick={() => move(index, index - 1)}
              >
                <ArrowUp size={15} aria-hidden="true" />
                Up
              </Button>
              <Button
                type="button"
                size="sm"
                variant="ghost"
                disabled={!canMutate || index === fieldArray.fields.length - 1}
                aria-label={moveDownLabel(index)}
                onClick={() => move(index, index + 1)}
              >
                <ArrowDown size={15} aria-hidden="true" />
                Down
              </Button>
              <Button
                type="button"
                size="sm"
                variant="danger"
                disabled={!canMutate}
                aria-label={removeLabel(index)}
                onClick={() => remove(index)}
              >
                <Trash2 size={15} aria-hidden="true" />
                Remove
              </Button>
            </span>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <Field
      id={listId}
      name={fieldArray.name}
      label={label}
      description={description}
      hint={hint}
      error={fieldArray.error}
      required={required}
      disabled={disabled}
      readOnly={readOnly}
      wide={wide}
      labelHidden={labelHidden}
      className={className}
      control={control}
    />
  );
}
