import { useMemo, useState } from "react";
import { z } from "zod";

import {
  Button,
  Card,
  CardBody,
  CardDescription,
  CardHeader,
  CardTitle,
  SegmentedControl,
  ValidationSummary,
  type ValidationSummaryItem,
} from "../lib";
import { FormField } from "./FormField";
import { FormPanel, type FormPanelFieldSpec } from "./FormPanel";
import { type FieldBinding } from "./useField";
import { FormWizard, type WizardStep } from "./wizard";
import {
  FormSubmissionError,
  useForm,
  useFormSelector,
  useFormState,
  type FieldErrors,
  type ValidationMode,
} from "../core/orchestration/forms";
import type { FieldStatus } from "../core/orchestration/forms";

const selectClassName = "ui-input ui-select";
const checkboxStyle = {
  minInlineSize: "1.1rem",
  minBlockSize: "1.1rem",
  accentColor: "var(--accent, currentColor)",
};

function fieldStatusEqual(a: FieldStatus, b: FieldStatus) {
  return a.visible === b.visible && a.disabled === b.disabled && a.required === b.required;
}

function fieldErrorsEqual(a: FieldErrors, b: FieldErrors) {
  const aKeys = Object.keys(a);
  const bKeys = Object.keys(b);
  if (aKeys.length !== bKeys.length) return false;
  return aKeys.every((key) => a[key] === b[key]);
}

function TextValue({ children }: { children: unknown }) {
  return <span>{children === undefined || children === "" ? "Not set" : String(children)}</span>;
}

function BoundSelect<TValue extends string | number>({
  binding,
  options,
}: {
  binding: FieldBinding<TValue>;
  options: readonly { value: TValue; label: string }[];
}) {
  return (
    <select
      ref={binding.ref as (element: HTMLSelectElement | null) => void}
      className={selectClassName}
      value={String(binding.value ?? options[0]?.value ?? "")}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
      onChange={(event) => {
        const raw = event.currentTarget.value;
        const sample = options[0]?.value;
        binding.onChange(typeof sample === "number" ? Number(raw) : raw);
      }}
    >
      {options.map((option) => (
        <option key={String(option.value)} value={String(option.value)}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

function BoundCheckbox({ binding }: { binding: FieldBinding<boolean> }) {
  return (
    <input
      ref={binding.ref as (element: HTMLInputElement | null) => void}
      type="checkbox"
      checked={Boolean(binding.value)}
      style={checkboxStyle}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
      onChange={(event) => binding.onChange(event.currentTarget.checked)}
    />
  );
}

const wizardSchema = z.object({
  fullName: z.string().min(2, "Enter the traveller name."),
  email: z.string().min(1, "Email is required.").email("Enter a valid email."),
  tripPurpose: z.enum(["leisure", "business"]),
  companyName: z.string().optional(),
  destination: z.enum(["vilnius", "kaunas", "klaipeda"]),
  startDate: z.string().min(1, "Choose a start date."),
  budget: z.coerce.number().min(200, "Budget must be at least 200 EUR."),
  notes: z.string().optional(),
}).superRefine((values, ctx) => {
  if (values.tripPurpose === "business" && !values.companyName?.trim()) {
    ctx.addIssue({
      code: "custom",
      path: ["companyName"],
      message: "Company name is required for business travel.",
    });
  }
});

type WizardValues = z.infer<typeof wizardSchema>;

const wizardSteps: WizardStep<WizardValues>[] = [
  {
    id: "traveller",
    label: "Traveller",
    description: "Identity",
    fields: ["fullName", "email", "tripPurpose"],
    next: (values) => (values.tripPurpose === "business" ? "company" : "itinerary"),
  },
  {
    id: "company",
    label: "Company",
    description: "Branch",
    fields: ["companyName"],
    next: () => "itinerary",
  },
  {
    id: "itinerary",
    label: "Itinerary",
    description: "Plan",
    fields: ["destination", "startDate", "budget"],
  },
  {
    id: "review",
    label: "Review",
    description: "Submit",
  },
];

const destinationOptions = [
  { value: "vilnius", label: "Vilnius" },
  { value: "kaunas", label: "Kaunas" },
  { value: "klaipeda", label: "Klaipeda coast" },
] as const;

export function FormWizardCatalogDemo({
  initialTripPurpose = "leisure",
}: {
  initialTripPurpose?: WizardValues["tripPurpose"];
} = {}) {
  const form = useForm({
    schema: wizardSchema,
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: {
      fullName: "",
      email: "",
      tripPurpose: initialTripPurpose,
      companyName: "",
      destination: "vilnius",
      startDate: "",
      budget: 450,
      notes: "",
    },
  });
  const formState = useFormState(form);
  const values = useFormSelector(form, (store) => store.getValues());
  const [submitted, setSubmitted] = useState<WizardValues | null>(null);

  return (
    <div className="xpl-stack" style={{ maxWidth: 760 }}>
      <FormWizard
        form={form}
        steps={wizardSteps}
        labels={{ finish: "Submit review" }}
        onComplete={(nextValues) => setSubmitted(nextValues)}
      >
        {({ step }) => (
          <Card>
            <CardHeader>
              <CardTitle>{step.label}</CardTitle>
              <CardDescription>
                Step {wizardSteps.findIndex((item) => item.id === step.id) + 1} validates only its owned fields before moving on.
              </CardDescription>
            </CardHeader>
            <CardBody>
              {step.id === "traveller" ? <WizardTravellerStep /> : null}
              {step.id === "company" ? <WizardCompanyStep /> : null}
              {step.id === "itinerary" ? <WizardItineraryStep /> : null}
              {step.id === "review" ? <WizardReviewStep values={values} /> : null}
            </CardBody>
          </Card>
        )}
      </FormWizard>
      {submitted ? (
        <ValidationSummary
          tone="success"
          title="Wizard submitted"
          description={`Review payload accepted for ${submitted.fullName || submitted.email}.`}
          items={[]}
        />
      ) : null}
      <p style={{ margin: 0, color: "var(--text-muted, #71717a)", fontSize: "var(--type-sm, 0.875rem)" }}>
        {formState.isValid ? "Current step has no visible errors." : "Resolve the highlighted fields before continuing."}
      </p>
    </div>
  );
}

function WizardTravellerStep() {
  return (
    <div className="ui-editable-form__grid">
      <FormField<WizardValues> name="fullName" label="Traveller name" required placeholder="Austeja Petrauskaite" />
      <FormField<WizardValues> name="email" label="Contact email" type="email" required placeholder="austeja@example.lt" />
      <FormField<WizardValues> name="tripPurpose" label="Trip purpose" required>
        {(binding) => (
          <BoundSelect
            binding={binding as FieldBinding<WizardValues["tripPurpose"]>}
            options={[
              { value: "leisure", label: "Leisure" },
              { value: "business", label: "Business" },
            ]}
          />
        )}
      </FormField>
    </div>
  );
}

function WizardCompanyStep() {
  return (
    <div className="ui-editable-form__grid">
      <FormField<WizardValues> name="companyName" label="Company name" required placeholder="Baltic Operations" />
      <FormField<WizardValues> name="notes" label="Procurement note" placeholder="Cost center or approval note" wide />
    </div>
  );
}

function WizardItineraryStep() {
  return (
    <div className="ui-editable-form__grid">
      <FormField<WizardValues> name="destination" label="Destination" required>
        {(binding) => <BoundSelect binding={binding as FieldBinding<WizardValues["destination"]>} options={destinationOptions} />}
      </FormField>
      <FormField<WizardValues> name="startDate" label="Start date" type="date" required />
      <FormField<WizardValues> name="budget" label="Budget" type="number" required />
    </div>
  );
}

function WizardReviewStep({ values }: { values: WizardValues }) {
  return (
    <div className="xpl-stack">
      <div className="ui-editable-form__grid">
        <ReadOnlySummary label="Traveller" value={values.fullName} />
        <ReadOnlySummary label="Email" value={values.email} />
        <ReadOnlySummary label="Purpose" value={values.tripPurpose} />
        {values.tripPurpose === "business" ? <ReadOnlySummary label="Company" value={values.companyName} /> : null}
        <ReadOnlySummary label="Destination" value={values.destination} />
        <ReadOnlySummary label="Start date" value={values.startDate} />
        <ReadOnlySummary label="Budget" value={`${values.budget} EUR`} />
      </div>
    </div>
  );
}

function ReadOnlySummary({ label, value }: { label: string; value: unknown }) {
  return (
    <div className="ui-field">
      <span className="ui-field__top">
        <span className="ui-field__label">{label}</span>
      </span>
      <span className="ui-input" style={{ display: "block", minHeight: "2.5rem" }}>
        <TextValue>{value}</TextValue>
      </span>
    </div>
  );
}

const tripSchema = z.object({
  tripType: z.enum(["self", "guided"]),
  destination: z.enum(["vilnius", "kaunas", "klaipeda"]),
  guests: z.number().min(1).max(6),
  nights: z.number().min(1).max(14),
  activity: z.string().min(1, "Choose an activity."),
  privateGuide: z.boolean(),
  guideLanguage: z.string().optional(),
  contactEmail: z.string().min(1, "Contact email is required.").email("Enter a valid email."),
  totalEstimate: z.number(),
}).superRefine((values, ctx) => {
  if (values.tripType === "guided" && values.privateGuide && !values.guideLanguage) {
    ctx.addIssue({
      code: "custom",
      path: ["guideLanguage"],
      message: "Choose a guide language.",
    });
  }
});

type TripValues = z.infer<typeof tripSchema>;

const activityByDestination: Record<TripValues["destination"], { value: string; label: string }[]> = {
  vilnius: [
    { value: "old-town", label: "Old Town walk" },
    { value: "food", label: "Food route" },
  ],
  kaunas: [
    { value: "modernism", label: "Modernism tour" },
    { value: "river", label: "River path" },
  ],
  klaipeda: [
    { value: "coast", label: "Coast day" },
    { value: "ferry", label: "Curonian ferry" },
  ],
};

function estimateTrip(values: TripValues) {
  const baseByDestination: Record<TripValues["destination"], number> = {
    vilnius: 88,
    kaunas: 76,
    klaipeda: 96,
  };
  const guided = values.tripType === "guided" ? 120 : 0;
  const privateGuide = values.privateGuide ? 180 : 0;
  return values.guests * values.nights * baseByDestination[values.destination] + guided + privateGuide;
}

export function ConditionalFormCatalogDemo({
  initialTripType = "guided",
  initialPrivateGuide = false,
  idPrefix,
}: {
  initialTripType?: TripValues["tripType"];
  initialPrivateGuide?: boolean;
  idPrefix?: string;
} = {}) {
  const form = useForm({
    schema: tripSchema,
    mode: "onChange",
    reValidateMode: "onChange",
    defaultValues: {
      tripType: initialTripType,
      destination: "vilnius",
      guests: 2,
      nights: 3,
      activity: "old-town",
      privateGuide: initialPrivateGuide,
      guideLanguage: "",
      contactEmail: "",
      totalEstimate: 0,
    },
    rules: {
      privateGuide: {
        visible: { field: "tripType", op: "eq", value: "guided" },
      },
      guideLanguage: {
        visible: {
          all: [
            { field: "tripType", op: "eq", value: "guided" },
            { field: "privateGuide", op: "truthy" },
          ],
        },
        required: true,
      },
      totalEstimate: {
        compute: (values) => estimateTrip(values),
      },
    },
  });
  const values = useFormSelector(form, (store) => store.getValues());
  const formState = useFormState(form);
  const privateGuideStatus = useFormSelector(form, (store) => store.getFieldStatus("privateGuide"), fieldStatusEqual);
  const guideLanguageStatus = useFormSelector(form, (store) => store.getFieldStatus("guideLanguage"), fieldStatusEqual);
  const [submitted, setSubmitted] = useState<Partial<TripValues> | null>(null);

  const activityOptions = activityByDestination[values.destination] ?? activityByDestination.vilnius;
  const visibilityAnnouncement = useMemo(() => {
    const privateGuideState = privateGuideStatus.visible ? "shown" : "hidden";
    const guideLanguageState = guideLanguageStatus.visible ? "shown" : "hidden";
    return `Private guide field ${privateGuideState}. Guide language field ${guideLanguageState}.`;
  }, [guideLanguageStatus.visible, privateGuideStatus.visible]);
  const fields = useMemo<FormPanelFieldSpec<TripValues>[]>(() => {
    const nextFields: FormPanelFieldSpec<TripValues>[] = [
      {
        name: "tripType",
        label: "Trip type",
        required: true,
        render: (binding) => (
          <BoundSelect
            binding={binding as FieldBinding<TripValues["tripType"]>}
            options={[
              { value: "self", label: "Self guided" },
              { value: "guided", label: "Guided package" },
            ]}
          />
        ),
      },
      {
        name: "destination",
        label: "Destination",
        required: true,
        render: (binding) => (
          <BoundSelect
            binding={binding as FieldBinding<TripValues["destination"]>}
            options={destinationOptions}
          />
        ),
      },
      {
        name: "activity",
        label: "Activity",
        required: true,
        description: `Options depend on ${values.destination}.`,
        render: (binding) => <BoundSelect binding={binding as FieldBinding<string>} options={activityOptions} />,
      },
      {
        name: "guests",
        label: "Guests",
        required: true,
        render: (binding) => (
          <BoundSelect
            binding={binding as FieldBinding<number>}
            options={[
              { value: 1, label: "1 guest" },
              { value: 2, label: "2 guests" },
              { value: 4, label: "4 guests" },
              { value: 6, label: "6 guests" },
            ]}
          />
        ),
      },
      {
        name: "nights",
        label: "Nights",
        required: true,
        render: (binding) => (
          <BoundSelect
            binding={binding as FieldBinding<number>}
            options={[
              { value: 1, label: "1 night" },
              { value: 3, label: "3 nights" },
              { value: 5, label: "5 nights" },
              { value: 7, label: "7 nights" },
            ]}
          />
        ),
      },
    ];

    if (privateGuideStatus.visible) {
      nextFields.push({
        name: "privateGuide",
        label: "Private guide",
        description: "Reveal a language field when selected.",
        render: (binding) => <BoundCheckbox binding={binding as FieldBinding<boolean>} />,
      });
    }
    if (guideLanguageStatus.visible) {
      nextFields.push({
        name: "guideLanguage",
        label: "Guide language",
        required: guideLanguageStatus.required,
        render: (binding) => (
          <BoundSelect
            binding={binding as FieldBinding<string>}
            options={[
              { value: "", label: "Choose language" },
              { value: "lt", label: "Lithuanian" },
              { value: "en", label: "English" },
              { value: "de", label: "German" },
            ]}
          />
        ),
      });
    }

    nextFields.push(
      { name: "contactEmail", label: "Contact email", type: "email", required: true, wide: true },
      { name: "totalEstimate", label: "Computed total", type: "number", readOnly: true, hint: "Derived from trip type, destination, party size and guide options." },
    );
    return nextFields;
  }, [activityOptions, guideLanguageStatus.required, guideLanguageStatus.visible, privateGuideStatus.visible, values.destination]);

  return (
    <div style={{ maxWidth: 760 }}>
      <div className="ui-sr-only" role="status" aria-live="polite" aria-atomic="true">
        {visibilityAnnouncement}
      </div>
      <FormPanel
        form={form}
        idPrefix={idPrefix}
        eyebrow="Dynamic forms"
        title="Trip request"
        subtitle="Conditional visibility, dependent options and computed total use the shipped form rules engine."
        badges={[
          { id: "valid", label: formState.isValid ? "valid" : "invalid", tone: formState.isValid ? "success" : "warning" },
          { id: "estimate", label: `${values.totalEstimate} EUR`, tone: "info" },
        ]}
        sections={[
          {
            id: "trip",
            title: "Package",
            fields,
          },
        ]}
        messages={
          submitted
            ? [{ id: "submitted", tone: "success", children: `Request ready at ${submitted.totalEstimate} EUR.` }]
            : []
        }
        onSubmit={(submitValues) => setSubmitted(submitValues)}
        actions={
          <>
            <Button type="button" size="sm" variant="secondary" onClick={() => {
              form.reset();
              setSubmitted(null);
            }}>
              Reset
            </Button>
            <Button type="submit" size="sm">Preview request</Button>
          </>
        }
      />
    </div>
  );
}

const validationSchema = z.object({
  fullName: z.string().min(2, "Enter at least 2 characters."),
  email: z.string().min(1, "Email is required.").email("Enter a valid email."),
  role: z.enum(["owner", "editor", "viewer"]),
  teamName: z.string().optional(),
  message: z.string().min(12, "Add a short request summary."),
});

type ValidationValues = z.infer<typeof validationSchema>;

const VALIDATION_SERVER_EMAIL = "reserved@example.com";

const modeOptions = [
  { id: "onChange", label: "Change" },
  { id: "onBlur", label: "Blur" },
  { id: "onSubmit", label: "Submit" },
];

export function ValidationErrorUxCatalogDemo({
  initialMode = "onSubmit",
  idPrefix,
}: {
  initialMode?: ValidationMode;
  idPrefix?: string;
} = {}) {
  const [mode, setMode] = useState<ValidationMode>(initialMode);

  return (
    <div className="xpl-stack" style={{ maxWidth: 760 }}>
      <SegmentedControl
        ariaLabel="Validation timing"
        value={mode}
        options={modeOptions}
        onValueChange={(next) => setMode(next as ValidationMode)}
      />
      <ValidationErrorUxForm key={mode} mode={mode} idPrefix={idPrefix} />
    </div>
  );
}

function ValidationErrorUxForm({ mode, idPrefix }: { mode: ValidationMode; idPrefix?: string }) {
  const form = useForm({
    schema: validationSchema,
    mode,
    reValidateMode: "onChange",
    defaultValues: {
      fullName: "",
      email: "",
      role: "editor",
      teamName: "",
      message: "",
    },
  });
  const formState = useFormState(form);
  const errors = useFormSelector(form, (store) => store.getErrors(), fieldErrorsEqual);
  const [showSummary, setShowSummary] = useState(false);
  const [successEmail, setSuccessEmail] = useState<string | null>(null);

  const summaryItems: ValidationSummaryItem[] = Object.entries(errors).map(([name, message]) => ({
    id: name,
    label: validationLabels[name] ?? name,
    message,
  }));
  const shouldShowSummary = showSummary || summaryItems.length > 0 || Boolean(formState.submitError);

  return (
    <FormPanel
      form={form}
      idPrefix={idPrefix}
      eyebrow="Validation UX"
      title="Invite collaborator"
      subtitle={`Current timing: ${validationModeLabel[mode]}. Submit ${VALIDATION_SERVER_EMAIL} to simulate a 422 response.`}
      badges={[
        { id: "mode", label: validationModeLabel[mode], tone: "info" },
        { id: "submits", label: `submits: ${formState.submitCount}`, tone: "neutral" },
        { id: "state", label: formState.isValid ? "valid" : "invalid", tone: formState.isValid ? "success" : "warning" },
      ]}
      messages={
        successEmail
          ? [{ id: "success", tone: "success", children: `Invitation queued for ${successEmail}.` }]
          : []
      }
      sections={[
        {
          id: "collaborator",
          title: "Collaborator",
          description: "Required fields mark their chrome; team name is optional.",
          fields: [
            { name: "fullName", label: "Full name", required: true, placeholder: "Ruta Paulauskaite" },
            { name: "email", label: "Email", type: "email", required: true, placeholder: "reserved@example.com" },
            {
              name: "role",
              label: "Role",
              required: true,
              render: (binding) => (
                <BoundSelect
                  binding={binding as FieldBinding<ValidationValues["role"]>}
                  options={[
                    { value: "owner", label: "Owner" },
                    { value: "editor", label: "Editor" },
                    { value: "viewer", label: "Viewer" },
                  ]}
                />
              ),
            },
            { name: "teamName", label: "Team name (optional)", placeholder: "Operations" },
            { name: "message", label: "Request summary", required: true, wide: true, placeholder: "Access needed for the July review window." },
          ],
        },
      ]}
      onInvalid={() => {
        setShowSummary(true);
        setSuccessEmail(null);
      }}
      onSubmit={async (values) => {
        setSuccessEmail(null);
        await new Promise((resolve) => setTimeout(resolve, 300));
        if (values.email.toLowerCase() === VALIDATION_SERVER_EMAIL) {
          setShowSummary(true);
          throw new FormSubmissionError({
            formError: "The server rejected this invitation.",
            fieldErrors: {
              email: "This address is reserved by another workspace.",
            },
          });
        }
        setShowSummary(false);
        setSuccessEmail(values.email);
      }}
      actions={
        <>
          <Button
            type="button"
            size="sm"
            variant="secondary"
            onClick={() => {
              form.reset();
              setShowSummary(false);
              setSuccessEmail(null);
            }}
          >
            Reset
          </Button>
          <Button type="submit" size="sm" disabled={formState.isSubmitting}>
            {formState.isSubmitting ? "Sending..." : "Send invite"}
          </Button>
        </>
      }
      footer={
        shouldShowSummary ? (
          <ValidationSummary
            title={summaryItems.length > 0 ? "Resolve these fields" : "Validation status"}
            description={formState.submitError}
            items={summaryItems}
            onItemSelect={(item) => form.setFocus(item.id as keyof ValidationValues & string)}
          />
        ) : null
      }
    />
  );
}

const validationLabels: Record<string, string> = {
  fullName: "Full name",
  email: "Email",
  role: "Role",
  teamName: "Team name",
  message: "Request summary",
};

const validationModeLabel: Record<ValidationMode, string> = {
  onChange: "onChange",
  onBlur: "onBlur",
  onSubmit: "onSubmit",
  all: "all",
};

export { LineItemsArrayFieldDemo as FieldArrayFormCatalogDemo } from "./examples";
