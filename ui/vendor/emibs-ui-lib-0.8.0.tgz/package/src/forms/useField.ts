// src/forms — the Field-contract binding hook.
//
// useField connects a registered engine field to any control implementing the
// issue-551 FieldControl contract: it hands back value/onChange/onBlur (+ focus
// visited tracking), the field's live error/touched/dirty, and a ref the engine
// uses to focus the first errored field after a failed submit. The presentation
// (aria-invalid, aria-describedby → error) is applied by the Field primitive
// that <FormField> wraps around the control — no per-form wiring.

import { useCallback, useEffect, useRef } from "react";

import {
  readChangeValue,
  useFieldState,
  useFormSelector,
  type FieldValues,
  type UseFormReturn,
} from "../core/orchestration/forms";
import { normalizePath } from "../core/orchestration/forms/path";
import { useOptionalFormContext } from "./Form";

/** The bound state + handlers for one field, ready to spread onto a control. */
export interface FieldBinding<T = unknown> {
  name: string;
  value: T;
  onChange: (eventOrValue: unknown) => void;
  onBlur: () => void;
  onFocus: () => void;
  /** attach to the focusable element so the engine can focus it on error */
  ref: (element: HTMLElement | null) => void;
  error: string | undefined;
  invalid: boolean;
  touched: boolean;
  dirty: boolean;
}

export interface UseFieldOptions<T = unknown, TValues extends object = FieldValues> {
  /** engine to bind to; defaults to the enclosing <Form>/<FormProvider> */
  form?: UseFormReturn<TValues>;
  /** seed value when the field has none yet */
  defaultValue?: T;
  /** stable DOM id for focus fallback when a wrapped control cannot expose a ref */
  focusId?: string;
}

/**
 * Bind a field by name to its engine. Registers the field, subscribes to only
 * that field's slice (sibling keystrokes don't re-render it), and wires focus.
 */
export function useField<
  TValues extends object = FieldValues,
  K extends string = string,
  T = unknown,
>(name: K, options: UseFieldOptions<T, TValues> = {}): FieldBinding<T> {
  const contextForm = useOptionalFormContext<TValues>();
  const form = options.form ?? contextForm;
  if (!form) {
    throw new Error("useField requires a <Form>/<FormProvider> or an explicit `form` option.");
  }
  const { store } = form;
  const { defaultValue, focusId } = options;
  const normalizedName = normalizePath(name);

  // Seed registration synchronously so the first render has the default value;
  // register() is idempotent (it only seeds a default the first time).
  if (!store.isRegistered(name)) {
    store.register(name, defaultValue !== undefined ? { defaultValue } : undefined);
  }
  useEffect(() => {
    store.register(name, defaultValue !== undefined ? { defaultValue } : undefined);
    return () => store.unregister(name);
    // defaultValue intentionally excluded: re-seeding on every value identity
    // change is not desired; register only seeds when the field has no initial.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [store, name]);

  const fieldState = useFieldState<TValues, T>(form, name);

  const onChange = useCallback(
    (eventOrValue: unknown) => store.setValue(name, readChangeValue(eventOrValue) as T),
    [store, name],
  );
  const onBlur = useCallback(() => store.setTouched(name, true), [store, name]);
  const onFocus = useCallback(() => store.setVisited(name, true), [store, name]);

  const elementRef = useRef<HTMLElement | null>(null);
  const ref = useCallback((element: HTMLElement | null) => {
    elementRef.current = element;
  }, []);

  // Consume the engine's DOM-free focus request: when the engine asks to focus
  // this field (e.g. first error after a blocked submit), focus the element.
  const pendingFocus = useFormSelector(form, (s) => s.getPendingFocus());
  useEffect(() => {
    if (pendingFocus === normalizedName && elementRef.current) {
      elementRef.current.focus();
      store.clearFocus();
      return;
    }
    if (pendingFocus === normalizedName && focusId && typeof document !== "undefined") {
      const element = document.getElementById(focusId) as HTMLElement | null;
      if (element && typeof element.focus === "function") {
        element.focus();
        store.clearFocus();
      }
    }
  }, [focusId, pendingFocus, normalizedName, store]);

  return {
    name,
    value: fieldState.value,
    onChange,
    onBlur,
    onFocus,
    ref,
    error: fieldState.error,
    invalid: fieldState.error !== undefined,
    touched: fieldState.touched,
    dirty: fieldState.dirty,
  };
}
