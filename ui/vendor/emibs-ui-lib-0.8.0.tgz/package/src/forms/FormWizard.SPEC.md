# FormWizard

Multi-step form composition built on the headless Forms engine.

- Owns step navigation, per-step validation gates, branching, review, and submit handoff.
- Consumes `useForm` state and keeps schemas/resolvers product-owned.
- Exports from `src/forms/index.ts`; consumers should import `FormWizard` and wizard types from `emibs-ui-lib/forms`.

