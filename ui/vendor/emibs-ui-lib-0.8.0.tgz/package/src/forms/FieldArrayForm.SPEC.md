# Field Array Form

Catalog demo for repeatable nested fields through `ArrayField`.

- Uses stable row keys from `useFieldArray`.
- Supports add, remove, move up/down, and Alt+Arrow keyboard reorder.
- Announces row-count changes and keeps nested field validation wired through `FormField`.

