# FormBuilder

Visual authoring surface for the flat `FormSpec` used by `AutoForm`.

The builder owns only in-memory design state. It does not persist forms, call a
backend, or evaluate conditional rules. Every canvas operation mutates the same
`FormSpec` shape that `AutoForm` consumes: fields remain flat, sections are
declared separately, and field order/section membership are stored on each field.

## Import

```tsx
import { FormBuilder } from "emibs-ui-lib/forms";
```

## Behavior

- Palette items are derived from the AutoForm type-to-control registry, unless
  the caller narrows them (see Palette scope).
- Canvas operations add, remove, reorder, and move fields while preserving unique
  field names and valid section references.
- The config panel edits label, name, type, required state, validation hints,
  options, default value, width, and condition reference.
- The preview renders the current spec through `AutoForm`; it is not a duplicate
  renderer.
- Exported JSON is the builder state. Importing that JSON reconstructs the same
  sections, fields, order, and configuration.

## Palette scope

`availableFieldTypes` narrows or reorders the types the palette offers, for a
product whose backend cannot accept every control the registry can render — a
survey surface with no file storage, say. Omitting it derives the same list from
the AutoForm control registry the builder has always derived, in the same order.

The list governs two places, and only those two: the palette grid, and the
config panel's Type select. A field whose type is outside the list — imported
JSON, or an `initialSpec` handed in by the caller — still reports its real type
in that select, because a select whose value is missing from its options names
the wrong type; the caller's list still bounds what the field can be changed
into. An empty list is honoured rather than reinterpreted: the palette is empty
and the per-section add-field command is withdrawn with it, because there is no
type left to add.

## Boundaries

Server persistence, collaborative editing, and condition evaluation are outside
this surface. Pattern validation is also outside this slice until `FormSpec`
defines a pattern field.

There is no export callback, deliberately. The copy and download buttons act on
two pure functions of the current spec, both exported from the same entry point
as the builder:

```tsx
import { FormBuilder, autoFormCodeSnippet, serializeFormSpec } from "emibs-ui-lib/forms";

const [spec, setSpec] = useState(contactRegistrationSeedSpec);
<FormBuilder initialSpec={spec} onSpecChange={setSpec} />;
// product-owned export, from state the product already holds:
await myExportService.save(serializeFormSpec(spec), autoFormCodeSnippet(spec));
```

A callback shaped `(spec, code) => void` would hand the caller nothing it cannot
already derive from `onSpecChange`, and being void-returning it could not stand
in for the built-in buttons either — so it would document a product-owned export
path that does not exist. A product that must own the export CHROME (rather than
the behaviour behind it) needs a slot or a visibility prop, which is a different
prop with a different shape and belongs to whichever requirement asks for it;
that is the same split `PayloadBlock` and `ComponentPlaygroundPanel` already
make, where the host owns the clipboard outright and the component only renders
the command when handed one.
