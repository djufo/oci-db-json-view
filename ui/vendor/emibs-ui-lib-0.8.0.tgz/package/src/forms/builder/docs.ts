import { autoFormCodeSnippet, serializeFormSpec } from "./builderModel";
import { contactRegistrationSeedSpec } from "./seed";

export const FORM_BUILDER_DOCS = {
  title: "Visual Form Builder",
  summary:
    "Build a flat FormSpec with sections, ordered fields, field config, live AutoForm preview, and JSON/code export from one screen.",
  workflow: [
    "Add a control from the palette; the field is inserted into the selected section with a unique stable name.",
    "Select a canvas field to edit label, name, type, validation hints, options, default value, width, and condition reference.",
    "Use pointer drag/drop or keyboard move controls to reorder fields within or across sections.",
    "Preview uses AutoForm with the same spec, then export JSON or copy the public AutoForm usage snippet.",
  ],
  roundTrip:
    "Exported JSON is the builder state. Importing that JSON recreates sections, fields, order, config, and the AutoForm preview without loss.",
  exampleJson: serializeFormSpec(contactRegistrationSeedSpec),
  exampleCode: autoFormCodeSnippet(contactRegistrationSeedSpec),
} as const;
