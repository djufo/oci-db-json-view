import type { FormSpec } from "../../core/config";

export const contactRegistrationSeedSpec: FormSpec = {
  sections: [
    {
      id: "contact",
      title: "Contact",
      description: "How the team can reach the registrant.",
      order: 0,
    },
    {
      id: "preferences",
      title: "Preferences",
      description: "Routing and consent fields.",
      order: 1,
    },
  ],
  fields: [
    {
      name: "full_name",
      type: "text",
      label: "Full name",
      placeholder: "Ada Lovelace",
      required: true,
      validation: { required: true, minLength: 2 },
      section: "contact",
      order: 0,
      width: "half",
    },
    {
      name: "email",
      type: "text",
      label: "Email",
      placeholder: "ada@example.com",
      required: true,
      validation: { required: true, format: "email" },
      section: "contact",
      order: 1,
      width: "half",
    },
    {
      name: "topic",
      type: "select",
      label: "Topic",
      required: true,
      validation: { required: true },
      options: [
        { value: "support", label: "Support" },
        { value: "sales", label: "Sales" },
        { value: "partnership", label: "Partnership" },
      ],
      default: "support",
      section: "preferences",
      order: 0,
      width: "half",
    },
    {
      name: "newsletter",
      type: "switch",
      label: "Newsletter updates",
      description: "Send occasional product and event updates.",
      default: true,
      section: "preferences",
      order: 1,
      width: "half",
    },
    {
      name: "message",
      type: "textarea",
      label: "Message",
      placeholder: "What should we know before replying?",
      validation: { maxLength: 500 },
      section: "preferences",
      order: 2,
      width: "full",
    },
  ],
};

export function cloneSeedSpec(): FormSpec {
  return JSON.parse(JSON.stringify(contactRegistrationSeedSpec)) as FormSpec;
}
