import {
  emptyValueForType,
  humanizeName,
  isFieldType,
  type FieldOption,
  type FieldType,
  type FieldValidation,
  type FieldWidth,
  type FormFieldSpec,
  type FormSectionSpec,
  type FormSpec,
  type FormValues,
} from "../../core/config";
import type { FieldErrors, Resolver } from "../../core/orchestration/forms";
import {
  createFormSpecError,
  type FormSpecValidationOptions,
} from "../validationMessages";

type Mutable<T> = { -readonly [K in keyof T]: T[K] };

export const BUILDER_UNSECTIONED_ID = "__builder-unsectioned";

export const BUILDER_FIELD_WIDTHS = ["full", "half", "third", "quarter"] as const satisfies readonly FieldWidth[];
export const CHOICE_FIELD_TYPES = ["select", "combobox", "radio", "tags"] as const satisfies readonly FieldType[];
export const BOOLEAN_FIELD_TYPES = ["checkbox", "switch"] as const satisfies readonly FieldType[];
export const STRING_VALIDATED_FIELD_TYPES = ["text", "textarea"] as const satisfies readonly FieldType[];

export interface BuilderSectionView {
  id: string;
  title: string;
  description?: string;
  declared?: FormSectionSpec;
  fields: FormFieldSpec[];
}

export type FormSpecParseResult =
  | { ok: true; spec: FormSpec }
  | { ok: false; error: string };

export function isChoiceFieldType(type: FieldType): boolean {
  return (CHOICE_FIELD_TYPES as readonly FieldType[]).includes(type);
}

export function isBooleanFieldType(type: FieldType): boolean {
  return (BOOLEAN_FIELD_TYPES as readonly FieldType[]).includes(type);
}

export function fieldTypeLabel(type: FieldType): string {
  if (type === "textarea") return "Text area";
  if (type === "checkbox") return "Checkbox";
  if (type === "combobox") return "Combobox";
  return humanizeName(type);
}

export function sanitizeFieldName(input: string): string {
  const cleaned = input
    .trim()
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^A-Za-z0-9_]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .replace(/_{2,}/g, "_")
    .toLowerCase();
  if (!cleaned) return "";
  return /^[a-zA-Z_]/.test(cleaned) ? cleaned : `field_${cleaned}`;
}

export function uniqueFieldName(type: FieldType, spec: FormSpec): string {
  const existing = new Set(spec.fields.map((field) => field.name));
  const base = sanitizeFieldName(type) || "field";
  let candidate = base;
  let index = 2;
  while (existing.has(candidate)) {
    candidate = `${base}_${index}`;
    index += 1;
  }
  return candidate;
}

export function defaultOptionsForType(type: FieldType): FieldOption[] {
  const label = fieldTypeLabel(type);
  return [
    { value: "option_1", label: `${label} option 1` },
    { value: "option_2", label: `${label} option 2` },
  ];
}

export function defaultValueForFieldType(type: FieldType, options?: readonly FieldOption[]): unknown {
  if (type === "file") return [];
  if (type === "tags") return [];
  if (type === "select" || type === "radio" || type === "combobox") return options?.[0]?.value ?? "";
  return emptyValueForType(type);
}

export function createDefaultField(type: FieldType, spec: FormSpec, section?: string): FormFieldSpec {
  const options = isChoiceFieldType(type) ? defaultOptionsForType(type) : undefined;
  const field: Mutable<FormFieldSpec> = {
    name: uniqueFieldName(type, spec),
    type,
    label: fieldTypeLabel(type),
    section,
    order: nextOrderForSection(spec, section),
    width: type === "textarea" || type === "file" || type === "tags" ? "full" : "half",
  };
  if (options) field.options = options;
  field.default = defaultValueForFieldType(type, options);
  return field;
}

export function orderedSections(spec: FormSpec): FormSectionSpec[] {
  return [...(spec.sections ?? [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0) || a.id.localeCompare(b.id));
}

export function orderedFieldsForSection(spec: FormSpec, sectionId?: string): FormFieldSpec[] {
  return spec.fields
    .map((field, index) => ({ field, index }))
    .filter(({ field }) => (sectionId ? field.section === sectionId : !field.section || !sectionExists(spec, field.section)))
    .sort((a, b) => (a.field.order ?? a.index) - (b.field.order ?? b.index) || a.index - b.index)
    .map(({ field }) => field);
}

export function getBuilderSections(spec: FormSpec): BuilderSectionView[] {
  const sections: BuilderSectionView[] = orderedSections(spec).map((section) => ({
    id: section.id,
    title: section.title || humanizeName(section.id),
    description: section.description,
    declared: section,
    fields: orderedFieldsForSection(spec, section.id),
  }));
  const unsectioned = orderedFieldsForSection(spec, undefined);
  if (unsectioned.length > 0 || sections.length === 0) {
    sections.push({
      id: BUILDER_UNSECTIONED_ID,
      title: sections.length === 0 ? "Fields" : "Unsectioned fields",
      fields: unsectioned,
    });
  }
  return sections;
}

export function normalizeSpecOrders(spec: FormSpec): FormSpec {
  const sections = orderedSections(spec).map((section, index) => ({ ...section, order: index }));
  const sectionIds = new Set(sections.map((section) => section.id));
  const orderedFields: FormFieldSpec[] = [];

  for (const section of sections) {
    orderedFieldsForSection(spec, section.id).forEach((field, index) => {
      orderedFields.push({ ...field, section: section.id, order: index });
    });
  }

  orderedFieldsForSection(spec, undefined).forEach((field, index) => {
    const next: Mutable<FormFieldSpec> = { ...field, order: index };
    if (!next.section || !sectionIds.has(next.section)) delete next.section;
    orderedFields.push(next);
  });

  return {
    fields: orderedFields,
    sections: sections.length > 0 ? sections : undefined,
  };
}

export function addFieldToSpec(spec: FormSpec, type: FieldType, section?: string): FormSpec {
  const targetSection = sectionExists(spec, section) ? section : undefined;
  return normalizeSpecOrders({
    ...spec,
    fields: [...spec.fields, createDefaultField(type, spec, targetSection)],
  });
}

export function removeFieldFromSpec(spec: FormSpec, fieldName: string): FormSpec {
  return normalizeSpecOrders({
    ...spec,
    fields: spec.fields.filter((field) => field.name !== fieldName),
  });
}

export function moveFieldInSpec(spec: FormSpec, fieldName: string, targetSection?: string, targetIndex = 0): FormSpec {
  const normalized = normalizeSpecOrders(spec);
  const moving = normalized.fields.find((field) => field.name === fieldName);
  if (!moving) return normalized;
  const normalizedTargetSection = sectionExists(normalized, targetSection) ? targetSection : undefined;
  const buckets = buildFieldBuckets(normalized, fieldName);
  const targetKey = sectionKey(normalizedTargetSection);
  const target = buckets.get(targetKey) ?? [];
  const insertAt = clamp(targetIndex, 0, target.length);
  target.splice(insertAt, 0, { ...moving, section: normalizedTargetSection });
  buckets.set(targetKey, target);
  return rebuildSpecFromBuckets(normalized, buckets);
}

export function moveFieldByOffset(spec: FormSpec, fieldName: string, offset: -1 | 1): FormSpec {
  const sections = getBuilderSections(normalizeSpecOrders(spec));
  const placements = sections.flatMap((section) =>
    section.fields.map((field, index) => ({
      name: field.name,
      sectionId: section.id === BUILDER_UNSECTIONED_ID ? undefined : section.id,
      index,
    })),
  );
  const currentIndex = placements.findIndex((placement) => placement.name === fieldName);
  if (currentIndex < 0) return spec;
  const targetPlacement = placements[currentIndex + offset];
  if (!targetPlacement) return spec;

  const targetSectionFields = orderedFieldsForSection(spec, targetPlacement.sectionId).filter((field) => field.name !== fieldName);
  const targetIndex = targetSectionFields.findIndex((field) => field.name === targetPlacement.name);
  return moveFieldInSpec(
    spec,
    fieldName,
    targetPlacement.sectionId,
    targetIndex + (offset > 0 ? 1 : 0),
  );
}

export function addSectionToSpec(spec: FormSpec, title = "New section"): FormSpec {
  const sections = orderedSections(spec);
  const section: FormSectionSpec = {
    id: uniqueSectionId(title, sections),
    title,
    order: sections.length,
  };
  return normalizeSpecOrders({
    ...spec,
    sections: [...sections, section],
  });
}

export function renameSectionInSpec(spec: FormSpec, sectionId: string, title: string): FormSpec {
  return normalizeSpecOrders({
    ...spec,
    sections: (spec.sections ?? []).map((section) =>
      section.id === sectionId ? { ...section, title: title.trim() || humanizeName(section.id) } : section,
    ),
  });
}

export function removeSectionFromSpec(spec: FormSpec, sectionId: string): FormSpec {
  return normalizeSpecOrders({
    ...spec,
    sections: (spec.sections ?? []).filter((section) => section.id !== sectionId),
    fields: spec.fields.map((field) => {
      if (field.section !== sectionId) return field;
      const next: Mutable<FormFieldSpec> = { ...field };
      delete next.section;
      return next;
    }),
  });
}

export function updateFieldInSpec(
  spec: FormSpec,
  fieldName: string,
  updater: (field: FormFieldSpec) => FormFieldSpec,
): FormSpec {
  return normalizeSpecOrders({
    ...spec,
    fields: spec.fields.map((field) => {
      if (field.name !== fieldName) return field;
      const next = updater(field);
      return normalizeFieldForType(next, next.type);
    }),
  });
}

export function changeFieldTypeInSpec(spec: FormSpec, fieldName: string, type: FieldType): FormSpec {
  return updateFieldInSpec(spec, fieldName, (field) => normalizeFieldForType({ ...field, type }, type));
}

export function setFieldRequired(field: FormFieldSpec, required: boolean): FormFieldSpec {
  const validation = { ...(field.validation ?? {}) } as Mutable<FieldValidation>;
  if (required) {
    validation.required = true;
  } else {
    delete validation.required;
  }
  return {
    ...field,
    required,
    validation: Object.keys(validation).length > 0 ? validation : undefined,
  };
}

export function fieldNameError(spec: FormSpec, currentName: string, candidate: string): string | undefined {
  const name = sanitizeFieldName(candidate);
  if (!name) return "Use a field name with at least one letter or number.";
  const duplicate = spec.fields.some((field) => field.name !== currentName && field.name === name);
  return duplicate ? `A field named "${name}" already exists.` : undefined;
}

export function renameFieldInSpec(
  spec: FormSpec,
  currentName: string,
  candidate: string,
): { spec: FormSpec; name: string; error?: string } {
  const name = sanitizeFieldName(candidate);
  const error = fieldNameError(spec, currentName, candidate);
  if (error) return { spec, name, error };
  return {
    name,
    spec: normalizeSpecOrders({
      ...spec,
      fields: spec.fields.map((field) => {
        if (field.name === currentName) return { ...field, name };
        return field.condition === currentName ? { ...field, condition: name } : field;
      }),
    }),
  };
}

export function serializeFormSpec(spec: FormSpec): string {
  return JSON.stringify(spec, null, 2);
}

export function autoFormCodeSnippet(spec: FormSpec): string {
  return `import { AutoForm } from "emibs-ui-lib/forms";

const spec = ${serializeFormSpec(spec)};

export function DesignedForm({ onSubmit }) {
  return <AutoForm spec={spec} title="Designed form" submitLabel="Submit" onSubmit={onSubmit} />;
}`;
}

export function parseFormSpecJson(input: string): FormSpecParseResult {
  let parsed: unknown;
  try {
    parsed = JSON.parse(input);
  } catch {
    return { ok: false, error: "Paste valid JSON before importing." };
  }
  const validationError = validateFormSpec(parsed);
  if (validationError) return { ok: false, error: validationError };
  return { ok: true, spec: parsed as FormSpec };
}

export function createFormSpecResolver<TValues extends FormValues = FormValues>(
  spec: FormSpec,
  options?: FormSpecValidationOptions,
): Resolver<TValues> {
  return (values) => ({
    values,
    errors: validateValuesAgainstSpec(spec, values, options),
  });
}

export function validateValuesAgainstSpec(
  spec: FormSpec,
  values: Record<string, unknown>,
  options?: FormSpecValidationOptions,
): FieldErrors {
  const errors: FieldErrors = {};
  for (const field of spec.fields) {
    const value = values[field.name];
    const required = field.required === true || field.validation?.required === true;
    if (required && isEmptyValue(field, value)) {
      errors[field.name] = createFormSpecError(field, "required", value, options);
      continue;
    }
    if (isEmptyValue(field, value)) continue;

    if (field.type === "number") {
      const numeric = typeof value === "number" ? value : Number(value);
      if (!Number.isFinite(numeric)) {
        errors[field.name] = createFormSpecError(field, "number", value, options);
        continue;
      }
      if (field.validation?.min !== undefined && numeric < field.validation.min) {
        errors[field.name] = createFormSpecError(field, "min", value, options, field.validation.min);
      }
      if (field.validation?.max !== undefined && numeric > field.validation.max) {
        errors[field.name] = createFormSpecError(field, "max", value, options, field.validation.max);
      }
      continue;
    }

    if (typeof value === "string") {
      if (field.validation?.minLength !== undefined && value.length < field.validation.minLength) {
        errors[field.name] = createFormSpecError(field, "minLength", value, options, field.validation.minLength);
      }
      if (field.validation?.maxLength !== undefined && value.length > field.validation.maxLength) {
        errors[field.name] = createFormSpecError(field, "maxLength", value, options, field.validation.maxLength);
      }
      if (field.validation?.format === "email" && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        errors[field.name] = createFormSpecError(field, "email", value, options);
      }
      if (field.validation?.format === "url") {
        try {
          new URL(value);
        } catch {
          errors[field.name] = createFormSpecError(field, "url", value, options);
        }
      }
    }
  }
  return errors;
}

function normalizeFieldForType(field: FormFieldSpec, type: FieldType): FormFieldSpec {
  const next = { ...field, type } as Mutable<FormFieldSpec>;
  if (isChoiceFieldType(type)) {
    next.options = next.options && next.options.length > 0 ? next.options : defaultOptionsForType(type);
  } else {
    delete next.options;
  }

  const validation = normalizeValidationForType(next.validation, type, next.required === true);
  if (validation) {
    next.validation = validation;
  } else {
    delete next.validation;
  }

  const defaultValue = coerceDefaultForType(type, next.default, next.options);
  if (defaultValue === undefined) {
    delete next.default;
  } else {
    next.default = defaultValue;
  }
  return next;
}

function normalizeValidationForType(
  validation: FieldValidation | undefined,
  type: FieldType,
  required: boolean,
): FieldValidation | undefined {
  const next: Mutable<FieldValidation> = {};
  if (required || validation?.required) next.required = true;
  if (type === "number") {
    if (typeof validation?.min === "number") next.min = validation.min;
    if (typeof validation?.max === "number") next.max = validation.max;
  }
  if ((STRING_VALIDATED_FIELD_TYPES as readonly FieldType[]).includes(type)) {
    if (typeof validation?.minLength === "number") next.minLength = validation.minLength;
    if (typeof validation?.maxLength === "number") next.maxLength = validation.maxLength;
    if (typeof validation?.format === "string") next.format = validation.format;
  }
  return Object.keys(next).length > 0 ? next : undefined;
}

function coerceDefaultForType(type: FieldType, value: unknown, options?: readonly FieldOption[]): unknown {
  if (type === "file") return undefined;
  if (isBooleanFieldType(type)) return value === true || value === "true";
  if (type === "tags") {
    if (Array.isArray(value)) return value.map(String);
    if (typeof value === "string") return value.split(",").map((item) => item.trim()).filter(Boolean);
    return [];
  }
  if (type === "number") {
    if (typeof value === "number" && Number.isFinite(value)) return value;
    if (typeof value === "string" && value.trim() !== "") {
      const numeric = Number(value);
      return Number.isFinite(numeric) ? numeric : undefined;
    }
    return undefined;
  }
  if (type === "select" || type === "radio" || type === "combobox") {
    const fallback = options?.[0]?.value ?? "";
    return value === undefined || value === null ? fallback : String(value);
  }
  return value === undefined || value === null ? "" : String(value);
}

function validateFormSpec(value: unknown): string | undefined {
  if (!isRecord(value)) return "Imported JSON must be a FormSpec object.";
  if (!Array.isArray(value.fields)) return "Imported FormSpec must include a fields array.";
  if (value.sections !== undefined && !Array.isArray(value.sections)) {
    return "FormSpec sections must be an array when provided.";
  }

  const sectionIds = new Set<string>();
  for (const [index, section] of ((value.sections as unknown[] | undefined) ?? []).entries()) {
    if (!isRecord(section)) return `Section ${index + 1} must be an object.`;
    if (typeof section.id !== "string" || !section.id.trim()) return `Section ${index + 1} needs a non-empty id.`;
    if (sectionIds.has(section.id)) return `Section id "${section.id}" is duplicated.`;
    sectionIds.add(section.id);
    if (section.title !== undefined && typeof section.title !== "string") return `Section "${section.id}" title must be text.`;
    if (section.description !== undefined && typeof section.description !== "string") {
      return `Section "${section.id}" description must be text.`;
    }
    if (section.order !== undefined && typeof section.order !== "number") return `Section "${section.id}" order must be numeric.`;
  }

  const fieldNames = new Set<string>();
  for (const [index, field] of value.fields.entries()) {
    if (!isRecord(field)) return `Field ${index + 1} must be an object.`;
    if (typeof field.name !== "string" || !field.name.trim()) return `Field ${index + 1} needs a non-empty name.`;
    if (fieldNames.has(field.name)) return `Field name "${field.name}" is duplicated.`;
    fieldNames.add(field.name);
    if (!isFieldType(field.type)) return `Field "${field.name}" has an unknown type.`;
    if (field.label !== undefined && typeof field.label !== "string") return `Field "${field.name}" label must be text.`;
    if (field.description !== undefined && typeof field.description !== "string") {
      return `Field "${field.name}" description must be text.`;
    }
    if (field.placeholder !== undefined && typeof field.placeholder !== "string") {
      return `Field "${field.name}" placeholder must be text.`;
    }
    if (field.section !== undefined && (typeof field.section !== "string" || !sectionIds.has(field.section))) {
      return `Field "${field.name}" references an unknown section.`;
    }
    if (field.width !== undefined && !(BUILDER_FIELD_WIDTHS as readonly string[]).includes(String(field.width))) {
      return `Field "${field.name}" has an unknown width.`;
    }
    if (field.order !== undefined && typeof field.order !== "number") return `Field "${field.name}" order must be numeric.`;
    if (field.required !== undefined && typeof field.required !== "boolean") return `Field "${field.name}" required must be boolean.`;
    if (field.condition !== undefined && typeof field.condition !== "string") {
      return `Field "${field.name}" condition reference must be text.`;
    }
    const optionError = validateFieldOptions(field.name, field.options);
    if (optionError) return optionError;
    const validationError = validateFieldValidation(field.name, field.validation);
    if (validationError) return validationError;
  }

  for (const field of value.fields) {
    if (isRecord(field) && typeof field.condition === "string" && field.condition && !fieldNames.has(field.condition)) {
      return `Field "${field.name}" condition references an unknown field.`;
    }
  }
  return undefined;
}

function validateFieldOptions(fieldName: string, value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (!Array.isArray(value)) return `Field "${fieldName}" options must be an array.`;
  for (const [index, option] of value.entries()) {
    if (!isRecord(option)) return `Option ${index + 1} for "${fieldName}" must be an object.`;
    if (typeof option.label !== "string") return `Option ${index + 1} for "${fieldName}" needs a text label.`;
    if (typeof option.value !== "string" && typeof option.value !== "number") {
      return `Option ${index + 1} for "${fieldName}" needs a string or number value.`;
    }
    if (option.disabled !== undefined && typeof option.disabled !== "boolean") {
      return `Option ${index + 1} for "${fieldName}" disabled must be boolean.`;
    }
  }
  return undefined;
}

function validateFieldValidation(fieldName: string, value: unknown): string | undefined {
  if (value === undefined) return undefined;
  if (!isRecord(value)) return `Field "${fieldName}" validation must be an object.`;
  const numericKeys = ["min", "max", "minLength", "maxLength"];
  for (const key of numericKeys) {
    if (value[key] !== undefined && typeof value[key] !== "number") {
      return `Field "${fieldName}" validation.${key} must be numeric.`;
    }
  }
  if (value.required !== undefined && typeof value.required !== "boolean") {
    return `Field "${fieldName}" validation.required must be boolean.`;
  }
  if (value.format !== undefined && typeof value.format !== "string") {
    return `Field "${fieldName}" validation.format must be text.`;
  }
  return undefined;
}

function isEmptyValue(field: FormFieldSpec, value: unknown): boolean {
  if (value === undefined || value === null) return true;
  if (typeof value === "string") return value.trim() === "";
  if (Array.isArray(value)) return value.length === 0;
  if (isBooleanFieldType(field.type)) return value !== true;
  return false;
}

function nextOrderForSection(spec: FormSpec, section?: string): number {
  return orderedFieldsForSection(spec, section).length;
}

function uniqueSectionId(title: string, sections: readonly FormSectionSpec[]): string {
  const existing = new Set(sections.map((section) => section.id));
  const base = sanitizeFieldName(title) || "section";
  let candidate = base;
  let index = 2;
  while (existing.has(candidate)) {
    candidate = `${base}_${index}`;
    index += 1;
  }
  return candidate;
}

function sectionExists(spec: FormSpec, section?: string): section is string {
  return Boolean(section && spec.sections?.some((item) => item.id === section));
}

function sectionKey(section?: string): string {
  return section ?? BUILDER_UNSECTIONED_ID;
}

function keyToSection(key: string): string | undefined {
  return key === BUILDER_UNSECTIONED_ID ? undefined : key;
}

function buildFieldBuckets(spec: FormSpec, excludeName?: string): Map<string, FormFieldSpec[]> {
  const buckets = new Map<string, FormFieldSpec[]>();
  for (const section of orderedSections(spec)) {
    buckets.set(section.id, orderedFieldsForSection(spec, section.id).filter((field) => field.name !== excludeName));
  }
  buckets.set(BUILDER_UNSECTIONED_ID, orderedFieldsForSection(spec, undefined).filter((field) => field.name !== excludeName));
  return buckets;
}

function rebuildSpecFromBuckets(spec: FormSpec, buckets: Map<string, FormFieldSpec[]>): FormSpec {
  const fields: FormFieldSpec[] = [];
  for (const section of orderedSections(spec)) {
    (buckets.get(section.id) ?? []).forEach((field, index) => {
      fields.push({ ...field, section: section.id, order: index });
    });
  }
  (buckets.get(BUILDER_UNSECTIONED_ID) ?? []).forEach((field, index) => {
    const next: Mutable<FormFieldSpec> = { ...field, order: index };
    delete next.section;
    fields.push(next);
  });
  return {
    ...spec,
    fields,
    sections: spec.sections,
  };
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(Math.max(value, min), max);
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return value !== null && typeof value === "object" && !Array.isArray(value);
}
