import { useCallback, useEffect, useRef, useState } from "react";

import type { FieldValues, UseFormReturn } from "../../core/orchestration/forms";
import { applyFormSnapshot, cloneValue, valuesEqual } from "./values";

export interface UseUndoStackReturn {
  canUndo: boolean;
  undo(): void;
  clear(): void;
}

export function useUndoStack<TValues extends object = FieldValues>(
  form: UseFormReturn<TValues>,
): UseUndoStackReturn {
  const [canUndo, setCanUndo] = useState(false);
  const currentRef = useRef<TValues>(cloneValue(form.store.getValues()));
  const previousRef = useRef<TValues | null>(null);
  const restoringRef = useRef(false);

  useEffect(() => {
    return form.store.subscribe(() => {
      const next = cloneValue(form.store.getValues());
      if (valuesEqual(currentRef.current, next)) return;
      if (restoringRef.current) {
        currentRef.current = next;
        return;
      }
      if (form.store.getFormState().isDirty) {
        previousRef.current = currentRef.current;
        setCanUndo(true);
      } else {
        previousRef.current = null;
        setCanUndo(false);
      }
      currentRef.current = next;
    });
  }, [form.store]);

  const clear = useCallback(() => {
    previousRef.current = null;
    currentRef.current = cloneValue(form.store.getValues());
    setCanUndo(false);
  }, [form.store]);

  const undo = useCallback(() => {
    const previous = previousRef.current;
    if (!previous) return;
    restoringRef.current = true;
    previousRef.current = null;
    setCanUndo(false);
    applyFormSnapshot(form, previous, { shouldValidate: false });
    currentRef.current = cloneValue(form.store.getValues());
    restoringRef.current = false;
  }, [form]);

  return { canUndo, undo, clear };
}
