# Forms Persistence

Persistence is an extraction-ready Forms slice for autosave, named drafts,
dirty navigation guards, optimistic submit rollback, and single-step undo.

## Contract

- `StorageAdapter` is the only backend seam: `get(key)`, `set(key, value)`,
  and `remove(key)` may be sync or async.
- `localStorageAdapter` JSON-serializes values and is the browser default.
- `useAutosave(form, { adapter, key, debounceMs })` subscribes to the form
  engine, skips pristine forms, debounces dirty values, and exposes
  `idle | saving | saved | error`.
- Draft helpers save, list, restore, and remove named snapshots over the same
  adapter. Restoring a draft calls `reset(values)` so restored content becomes
  the clean baseline.
- `useDirtyGuard` provides a beforeunload guard and an app-owned
  `confirmNavigation()` hook for route actions.
- `useOptimisticSubmit` applies an optimistic snapshot, keeps submit state
  active while awaiting the handler, and rolls back to the prior snapshot when
  the handler rejects.
- `useUndoStack` keeps one previous values snapshot and restores it through
  field paths without changing the form's initial baseline.

## Accessibility And Theming

- `DraftResumePrompt` is a non-modal dialog with live announcement, keyboard
  reachable Restore/Discard controls, and Escape dismissal.
- `DirtyGuardDialog` is an alert dialog with Escape cancel.
- Persistence chrome is token-only and does not animate.
