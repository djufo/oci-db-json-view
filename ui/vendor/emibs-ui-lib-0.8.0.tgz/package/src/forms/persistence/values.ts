import type { SetValueOptions, UseFormReturn } from "../../core/orchestration/forms";
import {
  cloneValue,
  getPath,
  hasPath,
  normalizePath,
  valuesEqual,
} from "../../core/orchestration/forms/path";

export { cloneValue, valuesEqual };

function stableNormalize(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(stableNormalize);
  if (value === null || typeof value !== "object") return value;
  if (value instanceof Date) return value.toISOString();
  const out: Record<string, unknown> = {};
  for (const key of Object.keys(value).sort()) {
    out[key] = stableNormalize((value as Record<string, unknown>)[key]);
  }
  return out;
}

export function snapshotFingerprint(value: unknown): string {
  return JSON.stringify(stableNormalize(value));
}

function collectLeafPaths(value: unknown, prefix = "", out = new Set<string>()): Set<string> {
  if (Array.isArray(value)) {
    if (value.length === 0 && prefix) out.add(prefix);
    value.forEach((item, index) => collectLeafPaths(item, prefix ? `${prefix}.${index}` : String(index), out));
    return out;
  }
  if (value !== null && typeof value === "object" && !(value instanceof Date)) {
    const entries = Object.entries(value as Record<string, unknown>);
    if (entries.length === 0 && prefix) out.add(prefix);
    for (const [key, child] of entries) collectLeafPaths(child, prefix ? `${prefix}.${key}` : key, out);
    return out;
  }
  if (prefix) out.add(prefix);
  return out;
}

export function applyFormSnapshot<TValues extends object>(
  form: UseFormReturn<TValues>,
  values: Partial<TValues>,
  options: SetValueOptions = { shouldValidate: false },
): void {
  const names = new Set<string>(form.store.getRegisteredNames().map(normalizePath));
  for (const name of collectLeafPaths(values)) names.add(normalizePath(name));
  for (const name of names) {
    const next = hasPath(values, name) ? cloneValue(getPath(values, name)) : undefined;
    if (!valuesEqual(form.store.getValue(name), next)) {
      form.store.setValue(name, next, options);
    }
  }
}
