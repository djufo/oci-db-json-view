import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";

import type { FieldValues, SubmitHandler, UseFormReturn } from "../../core/orchestration/forms";
import { cloneValue } from "./values";
import { useAutosave, type UseAutosaveReturn } from "./autosave";
import type { StorageAdapter } from "./storage";

export interface DraftRecord<TValues extends object = FieldValues> {
  name: string;
  values: TValues;
  updatedAt: string;
}

interface DraftCollection<TValues extends object> {
  version: 1;
  drafts: DraftRecord<TValues>[];
}

export interface UseDraftsOptions {
  adapter?: StorageAdapter<unknown>;
  key: string;
  activeDraftName?: string;
  prompt?: boolean;
}

export interface DraftPromptState<TValues extends object = FieldValues> {
  draft: DraftRecord<TValues>;
}

export interface UseDraftsReturn<TValues extends object = FieldValues> {
  drafts: DraftRecord<TValues>[];
  loading: boolean;
  error: Error | null;
  prompt: DraftPromptState<TValues> | null;
  refreshDrafts(): Promise<DraftRecord<TValues>[]>;
  listDrafts(): Promise<DraftRecord<TValues>[]>;
  saveDraft(name: string, values?: TValues): Promise<DraftRecord<TValues>>;
  restoreDraft(name: string): Promise<DraftRecord<TValues> | null>;
  removeDraft(name: string): Promise<void>;
  discardDraft(name: string): Promise<void>;
  dismissPrompt(): void;
  clearActiveDraft(): Promise<void>;
  withClearOnSubmit(handler: SubmitHandler<TValues>): SubmitHandler<TValues>;
}

export interface UseDraftAutosaveOptions extends UseDraftsOptions {
  name?: string;
  debounceMs?: number;
}

const DRAFTS_SUFFIX = "::drafts";
export const DEFAULT_ACTIVE_DRAFT_NAME = "Autosaved draft";

function collectionKey(key: string): string {
  return `${key}${DRAFTS_SUFFIX}`;
}

function toError(thrown: unknown): Error {
  return thrown instanceof Error ? thrown : new Error(String(thrown));
}

function normalizeDraftName(name: string): string {
  const normalized = name.trim();
  if (!normalized) throw new Error("Draft name is required.");
  return normalized;
}

function normalizeCollection<TValues extends object>(value: unknown): DraftCollection<TValues> {
  if (!value || typeof value !== "object") return { version: 1, drafts: [] };
  const input = value as Partial<DraftCollection<TValues>>;
  if (!Array.isArray(input.drafts)) return { version: 1, drafts: [] };
  return {
    version: 1,
    drafts: input.drafts.filter(
      (draft): draft is DraftRecord<TValues> =>
        Boolean(
          draft &&
            typeof draft === "object" &&
            typeof draft.name === "string" &&
            typeof draft.updatedAt === "string" &&
            draft.values &&
            typeof draft.values === "object",
        ),
    ),
  };
}

async function readCollection<TValues extends object>(
  adapter: StorageAdapter<unknown>,
  key: string,
): Promise<DraftCollection<TValues>> {
  return normalizeCollection<TValues>(await adapter.get(collectionKey(key)));
}

async function writeCollection<TValues extends object>(
  adapter: StorageAdapter<unknown>,
  key: string,
  collection: DraftCollection<TValues>,
): Promise<void> {
  if (collection.drafts.length === 0) {
    await adapter.remove(collectionKey(key));
    return;
  }
  await adapter.set(collectionKey(key), collection);
}

export async function listDrafts<TValues extends object = FieldValues>(
  adapter: StorageAdapter<unknown>,
  key: string,
): Promise<DraftRecord<TValues>[]> {
  const collection = await readCollection<TValues>(adapter, key);
  return [...collection.drafts].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export async function saveDraft<TValues extends object = FieldValues>(
  adapter: StorageAdapter<unknown>,
  key: string,
  name: string,
  values: TValues,
  now: Date = new Date(),
): Promise<DraftRecord<TValues>> {
  const draftName = normalizeDraftName(name);
  const collection = await readCollection<TValues>(adapter, key);
  const next: DraftRecord<TValues> = {
    name: draftName,
    values: cloneValue(values),
    updatedAt: now.toISOString(),
  };
  const drafts = collection.drafts.filter((draft) => draft.name !== draftName);
  drafts.push(next);
  await writeCollection(adapter, key, { version: 1, drafts });
  return next;
}

export async function restoreDraft<TValues extends object = FieldValues>(
  adapter: StorageAdapter<unknown>,
  key: string,
  name: string,
): Promise<DraftRecord<TValues> | null> {
  const draftName = normalizeDraftName(name);
  const drafts = await listDrafts<TValues>(adapter, key);
  return drafts.find((draft) => draft.name === draftName) ?? null;
}

export async function removeDraft(
  adapter: StorageAdapter<unknown>,
  key: string,
  name: string,
): Promise<void> {
  const draftName = normalizeDraftName(name);
  const collection = await readCollection(adapter, key);
  await writeCollection(adapter, key, {
    version: 1,
    drafts: collection.drafts.filter((draft) => draft.name !== draftName),
  });
}

export function createDraftAutosaveAdapter<TValues extends object>(
  adapter: StorageAdapter<unknown>,
  key: string,
  name: string,
): StorageAdapter<TValues> {
  return {
    async get() {
      const draft = await restoreDraft<TValues>(adapter, key, name);
      return draft?.values ?? null;
    },
    async set(_ignoredKey, value) {
      await saveDraft(adapter, key, name, value);
    },
    async remove() {
      await removeDraft(adapter, key, name);
    },
  };
}

function pickPromptDraft<TValues extends object>(
  drafts: DraftRecord<TValues>[],
  activeDraftName: string,
): DraftRecord<TValues> | null {
  return drafts.find((draft) => draft.name === activeDraftName) ?? drafts[0] ?? null;
}

export function useDrafts<TValues extends object = FieldValues>(
  form: UseFormReturn<TValues>,
  {
    adapter,
    key,
    activeDraftName = DEFAULT_ACTIVE_DRAFT_NAME,
    prompt = true,
  }: UseDraftsOptions,
): UseDraftsReturn<TValues> {
  const [drafts, setDrafts] = useState<DraftRecord<TValues>[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const [promptState, setPromptState] = useState<DraftPromptState<TValues> | null>(null);

  const refreshDrafts = useCallback(async () => {
    if (!adapter) {
      setDrafts([]);
      setPromptState(null);
      return [];
    }
    setLoading(true);
    setError(null);
    try {
      const next = await listDrafts<TValues>(adapter, key);
      setDrafts(next);
      return next;
    } catch (thrown) {
      setError(toError(thrown));
      return [];
    } finally {
      setLoading(false);
    }
  }, [adapter, key]);

  useEffect(() => {
    let cancelled = false;
    if (!adapter) return undefined;
    setLoading(true);
    setError(null);
    void listDrafts<TValues>(adapter, key)
      .then((next) => {
        if (cancelled) return;
        setDrafts(next);
        if (prompt) {
          const draft = pickPromptDraft(next, activeDraftName);
          setPromptState(draft ? { draft } : null);
        }
      })
      .catch((thrown) => {
        if (!cancelled) setError(toError(thrown));
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [activeDraftName, adapter, key, prompt]);

  const save = useCallback(
    async (name: string, values: TValues = form.store.getValues()) => {
      if (!adapter) throw new Error("No draft storage adapter is configured.");
      const next = await saveDraft(adapter, key, name, values);
      const updated = await refreshDrafts();
      if (prompt) {
        const draft = pickPromptDraft(updated, activeDraftName);
        setPromptState(draft ? { draft } : null);
      }
      return next;
    },
    [activeDraftName, adapter, form.store, key, prompt, refreshDrafts],
  );

  const restore = useCallback(
    async (name: string) => {
      if (!adapter) return null;
      const draft = await restoreDraft<TValues>(adapter, key, name);
      if (!draft) return null;
      form.reset(draft.values as Partial<TValues>);
      setPromptState(null);
      return draft;
    },
    [adapter, form, key],
  );

  const remove = useCallback(
    async (name: string) => {
      if (!adapter) return;
      await removeDraft(adapter, key, name);
      const updated = await refreshDrafts();
      setPromptState((current) => {
        if (!current || current.draft.name === name) return null;
        const stillExists = updated.some((draft) => draft.name === current.draft.name);
        return stillExists ? current : null;
      });
    },
    [adapter, key, refreshDrafts],
  );

  const clearActiveDraft = useCallback(() => remove(activeDraftName), [activeDraftName, remove]);
  const dismissPrompt = useCallback(() => setPromptState(null), []);
  const withClearOnSubmit = useCallback(
    (handler: SubmitHandler<TValues>): SubmitHandler<TValues> =>
      async (values) => {
        await handler(values);
        await clearActiveDraft();
      },
    [clearActiveDraft],
  );

  return {
    drafts,
    loading,
    error,
    prompt: promptState,
    refreshDrafts,
    listDrafts: refreshDrafts,
    saveDraft: save,
    restoreDraft: restore,
    removeDraft: remove,
    discardDraft: remove,
    dismissPrompt,
    clearActiveDraft,
    withClearOnSubmit,
  };
}

export function useDraftAutosave<TValues extends object = FieldValues>(
  form: UseFormReturn<TValues>,
  {
    adapter,
    key,
    name = DEFAULT_ACTIVE_DRAFT_NAME,
    debounceMs,
  }: UseDraftAutosaveOptions,
): UseAutosaveReturn {
  const draftAdapter = useMemo(
    () => (adapter ? createDraftAutosaveAdapter<TValues>(adapter, key, name) : undefined),
    [adapter, key, name],
  );
  return useAutosave(form, {
    adapter: draftAdapter,
    key: name,
    debounceMs,
  });
}

export interface DraftResumePromptProps<TValues extends object = FieldValues> {
  draft: DraftRecord<TValues> | null | undefined;
  title?: ReactNode;
  description?: ReactNode;
  restoreLabel?: ReactNode;
  discardLabel?: ReactNode;
  onRestore: (name: string) => void;
  onDiscard: (name: string) => void;
  onDismiss?: () => void;
}

export function DraftResumePrompt<TValues extends object = FieldValues>({
  draft,
  title = "Resume draft",
  description,
  restoreLabel = "Restore",
  discardLabel = "Discard",
  onRestore,
  onDiscard,
  onDismiss,
}: DraftResumePromptProps<TValues>) {
  useEffect(() => {
    if (!draft) return undefined;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onDismiss?.();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [draft, onDismiss]);

  if (!draft) return null;

  const titleId = `draft-resume-${draft.name.replace(/\W+/g, "-")}`;
  return (
    <section
      className="ui-form-draft-prompt"
      role="dialog"
      aria-modal="false"
      aria-labelledby={titleId}
      aria-live="polite"
    >
      <div className="ui-form-draft-prompt__body">
        <h3 id={titleId}>{title}</h3>
        <p>
          {description ??
            `A saved draft named ${draft.name} is available from ${new Date(draft.updatedAt).toLocaleString()}.`}
        </p>
      </div>
      <div className="ui-form-persistence-actions">
        <button className="ui-form-persistence-button" type="button" onClick={() => onRestore(draft.name)}>
          {restoreLabel}
        </button>
        <button className="ui-form-persistence-button ui-form-persistence-button--secondary" type="button" onClick={() => onDiscard(draft.name)}>
          {discardLabel}
        </button>
      </div>
    </section>
  );
}
