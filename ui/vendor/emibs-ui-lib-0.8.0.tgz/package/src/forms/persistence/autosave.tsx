import { useCallback, useEffect, useRef, useState } from "react";

import type { FieldValues, FormStore, UseFormReturn } from "../../core/orchestration/forms";
import { cloneValue, snapshotFingerprint } from "./values";
import type { StorageAdapter } from "./storage";

export type SaveStatus = "idle" | "saving" | "saved" | "error";

export interface SaveStatusSnapshot {
  status: SaveStatus;
  error: Error | null;
  lastSavedAt: Date | null;
}

export interface AutosaveController<TValues extends object = FieldValues> {
  getState(): SaveStatusSnapshot;
  check(): void;
  flush(): Promise<void>;
  cancel(): void;
  dispose(): void;
}

export interface CreateAutosaveControllerOptions<TValues extends object = FieldValues> {
  adapter: StorageAdapter<TValues>;
  key: string;
  debounceMs?: number;
  getSnapshot: () => TValues;
  isDirty: () => boolean;
  subscribe: (listener: () => void) => () => void;
  onStatusChange?: (snapshot: SaveStatusSnapshot) => void;
}

export interface UseAutosaveOptions<TValues extends object = FieldValues> {
  adapter?: StorageAdapter<TValues>;
  key: string;
  debounceMs?: number;
}

export interface UseAutosaveReturn extends SaveStatusSnapshot {
  flush(): Promise<void>;
  cancel(): void;
}

interface PendingSave<TValues extends object> {
  values: TValues;
  fingerprint: string;
}

const DEFAULT_DEBOUNCE_MS = 500;

function toError(thrown: unknown): Error {
  return thrown instanceof Error ? thrown : new Error(String(thrown));
}

export function createAutosaveController<TValues extends object = FieldValues>({
  adapter,
  key,
  debounceMs = DEFAULT_DEBOUNCE_MS,
  getSnapshot,
  isDirty,
  subscribe,
  onStatusChange,
}: CreateAutosaveControllerOptions<TValues>): AutosaveController<TValues> {
  let state: SaveStatusSnapshot = { status: "idle", error: null, lastSavedAt: null };
  let timer: ReturnType<typeof setTimeout> | null = null;
  let pending: PendingSave<TValues> | null = null;
  let disposed = false;
  let runToken = 0;
  let lastSavedFingerprint = snapshotFingerprint(getSnapshot());

  const publish = (next: SaveStatusSnapshot) => {
    state = next;
    onStatusChange?.(state);
  };

  const setStatus = (status: SaveStatus, error: Error | null = null, lastSavedAt = state.lastSavedAt) => {
    if (state.status === status && state.error === error && state.lastSavedAt === lastSavedAt) return;
    publish({ status, error, lastSavedAt });
  };

  const clearTimer = () => {
    if (timer) clearTimeout(timer);
    timer = null;
  };

  const savePending = async () => {
    clearTimer();
    const item = pending;
    if (!item || disposed) return;
    pending = null;
    const token = ++runToken;
    setStatus("saving");
    try {
      await adapter.set(key, item.values);
      if (disposed || token !== runToken) return;
      lastSavedFingerprint = item.fingerprint;
      setStatus("saved", null, new Date());
    } catch (thrown) {
      if (disposed || token !== runToken) return;
      setStatus("error", toError(thrown));
    }
  };

  const check = () => {
    if (disposed) return;
    if (!isDirty()) {
      clearTimer();
      pending = null;
      lastSavedFingerprint = snapshotFingerprint(getSnapshot());
      setStatus("idle");
      return;
    }

    const values = cloneValue(getSnapshot());
    const fingerprint = snapshotFingerprint(values);
    if (fingerprint === lastSavedFingerprint && state.status !== "error") return;
    pending = { values, fingerprint };
    clearTimer();
    timer = setTimeout(() => {
      void savePending();
    }, debounceMs);
  };

  const unsubscribe = subscribe(check);

  return {
    getState() {
      return state;
    },
    check,
    flush() {
      return savePending();
    },
    cancel() {
      clearTimer();
      pending = null;
      setStatus("idle");
    },
    dispose() {
      disposed = true;
      runToken += 1;
      clearTimer();
      pending = null;
      unsubscribe();
    },
  };
}

function storeAutosaveOptions<TValues extends object>(
  store: FormStore<TValues>,
  adapter: StorageAdapter<TValues>,
  key: string,
  debounceMs?: number,
): CreateAutosaveControllerOptions<TValues> {
  return {
    adapter,
    key,
    debounceMs,
    getSnapshot: () => store.getValues(),
    isDirty: () => store.getFormState().isDirty,
    subscribe: store.subscribe,
  };
}

export function useAutosave<TValues extends object = FieldValues>(
  form: UseFormReturn<TValues>,
  { adapter, key, debounceMs }: UseAutosaveOptions<TValues>,
): UseAutosaveReturn {
  const controllerRef = useRef<AutosaveController<TValues> | null>(null);
  const [state, setState] = useState<SaveStatusSnapshot>({
    status: "idle",
    error: null,
    lastSavedAt: null,
  });

  useEffect(() => {
    if (!adapter) return undefined;
    const controller = createAutosaveController({
      ...storeAutosaveOptions(form.store, adapter, key, debounceMs),
      onStatusChange: setState,
    });
    controllerRef.current = controller;
    controller.check();
    return () => {
      controller.dispose();
      if (controllerRef.current === controller) controllerRef.current = null;
    };
  }, [adapter, debounceMs, form.store, key]);

  const flush = useCallback(async () => {
    await controllerRef.current?.flush();
  }, []);

  const cancel = useCallback(() => {
    controllerRef.current?.cancel();
  }, []);

  return { ...state, flush, cancel };
}

const statusLabel: Record<SaveStatus, string> = {
  idle: "Not saved yet",
  saving: "Saving",
  saved: "Saved",
  error: "Save error",
};

export interface SaveStatusIndicatorProps {
  status: SaveStatus;
  error?: Error | null;
  lastSavedAt?: Date | null;
  labels?: Partial<Record<SaveStatus, string>>;
}

export function SaveStatusIndicator({
  status,
  error,
  lastSavedAt,
  labels,
}: SaveStatusIndicatorProps) {
  const label = labels?.[status] ?? statusLabel[status];
  const detail =
    status === "error" && error
      ? error.message
      : status === "saved" && lastSavedAt
        ? lastSavedAt.toLocaleTimeString()
        : null;
  return (
    <span
      className={`ui-form-save-status ui-form-save-status--${status}`}
      aria-live="polite"
      role="status"
    >
      <span className="ui-form-save-status__dot" aria-hidden="true" />
      <span>{detail ? `${label} · ${detail}` : label}</span>
    </span>
  );
}
