import "./persistence.css";

export {
  createMemoryStorageAdapter,
  createLatencyStorageAdapter,
  localStorageAdapter,
  default,
} from "./storage";
export type {
  MemoryStorageAdapter,
  StorageAdapter,
  StorageMaybePromise,
} from "./storage";
export {
  SaveStatusIndicator,
  createAutosaveController,
  useAutosave,
} from "./autosave";
export type {
  AutosaveController,
  CreateAutosaveControllerOptions,
  SaveStatus,
  SaveStatusIndicatorProps,
  SaveStatusSnapshot,
  UseAutosaveOptions,
  UseAutosaveReturn,
} from "./autosave";
export {
  DEFAULT_ACTIVE_DRAFT_NAME,
  DraftResumePrompt,
  createDraftAutosaveAdapter,
  listDrafts,
  removeDraft,
  restoreDraft,
  saveDraft,
  useDraftAutosave,
  useDrafts,
} from "./drafts";
export type {
  DraftPromptState,
  DraftRecord,
  DraftResumePromptProps,
  UseDraftAutosaveOptions,
  UseDraftsOptions,
  UseDraftsReturn,
} from "./drafts";
export {
  DirtyGuardDialog,
  useDirtyGuard,
} from "./guard";
export type {
  DirtyGuardDialogProps,
  DirtyGuardOptions,
  DirtyGuardReturn,
  PendingNavigation,
} from "./guard";
export {
  createOptimisticSubmitHandler,
  useOptimisticSubmit,
} from "./optimistic";
export type { OptimisticSubmitOptions } from "./optimistic";
export { useUndoStack } from "./undo";
export type { UseUndoStackReturn } from "./undo";
export { PersistenceCatalogDemo } from "./catalogDemo";
