import { useCallback } from "react";

import type { FieldValues, SubmitHandler, UseFormReturn } from "../../core/orchestration/forms";

export interface OptimisticSubmitOptions<TValues extends object = FieldValues> {
  onSubmit: SubmitHandler<TValues>;
  optimisticValues?: (values: TValues) => Partial<TValues>;
  onRollback?: (snapshot: TValues, error: unknown) => void;
  onSuccess?: (values: TValues) => void;
}

function applyValues<TValues extends object>(form: UseFormReturn<TValues>, values: Partial<TValues>): void {
  for (const [name, value] of Object.entries(values)) {
    form.setValue(name, value, { shouldValidate: false });
  }
}

export function createOptimisticSubmitHandler<TValues extends object = FieldValues>(
  form: UseFormReturn<TValues>,
  { onSubmit, optimisticValues, onRollback, onSuccess }: OptimisticSubmitOptions<TValues>,
): SubmitHandler<TValues> {
  return async (values) => {
    const previous = form.getValues();
    const optimistic = { ...previous, ...(optimisticValues?.(values) ?? values) };
    applyValues(form, optimistic);
    form.store.setSubmitting(true);
    try {
      await onSubmit(values);
      form.reset(form.getValues());
      onSuccess?.(form.store.getValues());
    } catch (thrown) {
      applyValues(form, previous);
      onRollback?.(previous, thrown);
      throw thrown;
    } finally {
      form.store.setSubmitting(false);
    }
  };
}

export function useOptimisticSubmit<TValues extends object = FieldValues>(
  form: UseFormReturn<TValues>,
  options: OptimisticSubmitOptions<TValues>,
): SubmitHandler<TValues> {
  return useCallback(createOptimisticSubmitHandler(form, options), [form, options]);
}
