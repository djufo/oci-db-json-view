import { afterEach, describe, expect, it, vi } from "vitest";

import {
  createFormStore,
  FormSubmissionError,
  type FormStore,
  type UseFormReturn,
} from "../../core/orchestration/forms";
import {
  createAutosaveController,
  createMemoryStorageAdapter,
  createOptimisticSubmitHandler,
  listDrafts,
  removeDraft,
  restoreDraft,
  saveDraft,
  type SaveStatusSnapshot,
} from ".";

interface Values {
  title: string;
  status: "Draft" | "Queued";
}

function asForm<TValues extends object>(store: FormStore<TValues>): UseFormReturn<TValues> {
  return {
    store,
    setValue: store.setValue,
    getValues: store.getValues,
    reset: store.reset,
  } as UseFormReturn<TValues>;
}

afterEach(() => {
  vi.useRealTimers();
});

describe("createAutosaveController", () => {
  it("debounces dirty value changes into one persisted snapshot", async () => {
    vi.useFakeTimers();
    const store = createFormStore<Values>({
      defaultValues: { title: "", status: "Draft" },
    });
    const adapter = createMemoryStorageAdapter<Values>();
    const statuses: SaveStatusSnapshot[] = [];
    const controller = createAutosaveController({
      adapter,
      key: "request",
      debounceMs: 250,
      getSnapshot: store.getValues,
      isDirty: () => store.getFormState().isDirty,
      subscribe: store.subscribe,
      onStatusChange: (state) => statuses.push(state),
    });

    store.setValue("title", "A");
    store.setValue("title", "AB");

    await vi.advanceTimersByTimeAsync(249);
    expect(await adapter.get("request")).toBeNull();

    await vi.advanceTimersByTimeAsync(1);
    expect(await adapter.get("request")).toEqual({ title: "AB", status: "Draft" });
    expect(statuses.map((state) => state.status)).toEqual(["saving", "saved"]);

    controller.dispose();
  });

  it("does not persist pristine forms", async () => {
    vi.useFakeTimers();
    const store = createFormStore<Values>({
      defaultValues: { title: "", status: "Draft" },
    });
    const adapter = createMemoryStorageAdapter<Values>();
    const controller = createAutosaveController({
      adapter,
      key: "request",
      debounceMs: 100,
      getSnapshot: store.getValues,
      isDirty: () => store.getFormState().isDirty,
      subscribe: store.subscribe,
    });

    controller.check();
    await vi.advanceTimersByTimeAsync(100);

    expect(adapter.keys()).toEqual([]);
    controller.dispose();
  });

  it("surfaces adapter errors without changing form values", async () => {
    vi.useFakeTimers();
    const store = createFormStore<Values>({
      defaultValues: { title: "", status: "Draft" },
    });
    const controller = createAutosaveController({
      adapter: {
        get: () => null,
        set: () => {
          throw new Error("storage denied");
        },
        remove: () => undefined,
      },
      key: "request",
      debounceMs: 20,
      getSnapshot: store.getValues,
      isDirty: () => store.getFormState().isDirty,
      subscribe: store.subscribe,
    });

    store.setValue("title", "Persist me");
    await vi.advanceTimersByTimeAsync(20);

    expect(controller.getState().status).toBe("error");
    expect(controller.getState().error?.message).toBe("storage denied");
    expect(store.getValues()).toEqual({ title: "Persist me", status: "Draft" });
    controller.dispose();
  });
});

describe("draft storage", () => {
  it("saves, lists, restores, and removes named drafts independently", async () => {
    const adapter = createMemoryStorageAdapter<unknown>();

    await saveDraft(adapter, "request", "Morning", { title: "A", status: "Draft" }, new Date("2026-07-04T10:00:00Z"));
    await saveDraft(adapter, "request", "Evening", { title: "B", status: "Queued" }, new Date("2026-07-04T12:00:00Z"));

    expect((await listDrafts<Values>(adapter, "request")).map((draft) => draft.name)).toEqual([
      "Evening",
      "Morning",
    ]);
    expect((await restoreDraft<Values>(adapter, "request", "Morning"))?.values).toEqual({
      title: "A",
      status: "Draft",
    });

    await removeDraft(adapter, "request", "Evening");
    expect((await listDrafts<Values>(adapter, "request")).map((draft) => draft.name)).toEqual([
      "Morning",
    ]);
  });
});

describe("createOptimisticSubmitHandler", () => {
  it("rolls back to the previous values when submit rejects", async () => {
    const store = createFormStore<Values>({
      defaultValues: { title: "Original", status: "Draft" },
    });
    const form = asForm(store);
    const handler = createOptimisticSubmitHandler(form, {
      optimisticValues: (values) => ({ ...values, status: "Queued" as const }),
      onSubmit: async () => {
        throw new FormSubmissionError({ formError: "Rejected" });
      },
    });

    store.setValue("title", "Edited");

    await expect(handler(store.getValues())).rejects.toBeInstanceOf(FormSubmissionError);
    expect(store.getValues()).toEqual({ title: "Edited", status: "Draft" });
    expect(store.getFormState().isDirty).toBe(true);
    expect(store.getFormState().isSubmitting).toBe(false);
  });

  it("keeps the optimistic values after submit resolves", async () => {
    const store = createFormStore<Values>({
      defaultValues: { title: "Original", status: "Draft" },
    });
    const form = asForm(store);
    const handler = createOptimisticSubmitHandler(form, {
      optimisticValues: (values) => ({ ...values, status: "Queued" as const }),
      onSubmit: async () => undefined,
    });

    await handler(store.getValues());
    expect(store.getValues()).toEqual({ title: "Original", status: "Queued" });
    expect(store.getFormState().isDirty).toBe(false);
    expect(store.getFormState().isSubmitting).toBe(false);
  });
});
