export type StorageMaybePromise<T> = T | Promise<T>;

/**
 * Pluggable value storage for form persistence.
 *
 * Adapters own serialization and backend choice. The Forms persistence layer
 * only needs key-based get/set/remove, so localStorage, IndexedDB, server APIs,
 * or tests can be swapped without changing autosave/draft logic.
 */
export interface StorageAdapter<TValue = unknown> {
  get(key: string): StorageMaybePromise<TValue | null | undefined>;
  set(key: string, value: TValue): StorageMaybePromise<void>;
  remove(key: string): StorageMaybePromise<void>;
}

export interface MemoryStorageAdapter<TValue = unknown> extends StorageAdapter<TValue> {
  dump(): Record<string, TValue>;
  clear(): void;
  keys(): string[];
}

function resolveLocalStorage(): Storage {
  const storage = globalThis.localStorage;
  if (!storage) {
    throw new Error("localStorage is not available in this environment.");
  }
  return storage;
}

export const localStorageAdapter: StorageAdapter<unknown> = {
  get(key) {
    const raw = resolveLocalStorage().getItem(key);
    return raw === null ? null : (JSON.parse(raw) as unknown);
  },
  set(key, value) {
    resolveLocalStorage().setItem(key, JSON.stringify(value));
  },
  remove(key) {
    resolveLocalStorage().removeItem(key);
  },
};

export default localStorageAdapter;

export function createMemoryStorageAdapter<TValue = unknown>(
  initial: Record<string, TValue> = {},
): MemoryStorageAdapter<TValue> {
  const values = new Map<string, TValue>(Object.entries(initial));
  return {
    get(key) {
      return values.has(key) ? values.get(key) : null;
    },
    set(key, value) {
      values.set(key, value);
    },
    remove(key) {
      values.delete(key);
    },
    dump() {
      return Object.fromEntries(values);
    },
    clear() {
      values.clear();
    },
    keys() {
      return [...values.keys()];
    },
  };
}

export function createLatencyStorageAdapter<TValue>(
  adapter: StorageAdapter<TValue>,
  delayMs: number | (() => number),
): StorageAdapter<TValue> {
  const delay = () =>
    new Promise<void>((resolve) => {
      setTimeout(resolve, typeof delayMs === "function" ? delayMs() : delayMs);
    });
  return {
    async get(key) {
      await delay();
      return adapter.get(key);
    },
    async set(key, value) {
      await delay();
      await adapter.set(key, value);
    },
    async remove(key) {
      await delay();
      await adapter.remove(key);
    },
  };
}
