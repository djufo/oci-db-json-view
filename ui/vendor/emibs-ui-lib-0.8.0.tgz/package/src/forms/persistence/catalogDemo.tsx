import { useEffect, useMemo, useRef, useState } from "react";

import { FormSubmissionError, useForm, useFormSelector, useFormState } from "../../core/orchestration/forms";
import type { FieldBinding } from "../useField";
import { FormPanel } from "../FormPanel";
import {
  DEFAULT_ACTIVE_DRAFT_NAME,
  DirtyGuardDialog,
  DraftResumePrompt,
  SaveStatusIndicator,
  createLatencyStorageAdapter,
  createMemoryStorageAdapter,
  useDirtyGuard,
  useDraftAutosave,
  useDrafts,
  useOptimisticSubmit,
  useUndoStack,
  type StorageAdapter,
} from ".";
import "./persistence.css";

interface PersistenceValues {
  requestTitle: string;
  ownerEmail: string;
  priority: "normal" | "urgent" | "later";
  notes: string;
  workflowStatus: "Draft" | "Queued";
}

const STORAGE_KEY = "catalog.forms.persistence";

const priorityOptions = [
  { value: "normal", label: "Normal" },
  { value: "urgent", label: "Urgent" },
  { value: "later", label: "Later" },
] as const;

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function BoundSelect({
  binding,
}: {
  binding: FieldBinding<PersistenceValues["priority"]>;
}) {
  return (
    <select
      ref={binding.ref as (element: HTMLSelectElement | null) => void}
      className="ui-input ui-select"
      value={binding.value}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
      onChange={(event) => binding.onChange(event.currentTarget.value)}
    >
      {priorityOptions.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

function BoundTextarea({ binding }: { binding: FieldBinding<string> }) {
  return (
    <textarea
      ref={binding.ref as (element: HTMLTextAreaElement | null) => void}
      className="ui-input ui-textarea"
      rows={4}
      value={binding.value ?? ""}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
      onChange={binding.onChange}
    />
  );
}

function PersistenceDemoInstance({
  adapter,
  onReload,
  idPrefix,
}: {
  adapter: StorageAdapter<unknown>;
  onReload: () => void;
  idPrefix?: string;
}) {
  const form = useForm<PersistenceValues>({
    defaultValues: {
      requestTitle: "",
      ownerEmail: "",
      priority: "normal",
      notes: "",
      workflowStatus: "Draft",
    },
    mode: "onChange",
  });
  const formState = useFormState(form);
  const values = useFormSelector(form, (store) => store.getValues());
  const saveStatus = useDraftAutosave(form, {
    adapter,
    key: STORAGE_KEY,
    name: DEFAULT_ACTIVE_DRAFT_NAME,
    debounceMs: 450,
  });
  const drafts = useDrafts(form, {
    adapter,
    key: STORAGE_KEY,
    activeDraftName: DEFAULT_ACTIVE_DRAFT_NAME,
  });
  const guard = useDirtyGuard(form);
  const undo = useUndoStack(form);
  const [draftName, setDraftName] = useState("Review copy");
  const [failNextSubmit, setFailNextSubmit] = useState(false);
  const [submitTrace, setSubmitTrace] = useState<string | null>(null);
  const [navTrace, setNavTrace] = useState("No navigation attempted.");
  const failNextRef = useRef(false);

  useEffect(() => {
    failNextRef.current = failNextSubmit;
  }, [failNextSubmit]);

  const optimisticSubmit = useOptimisticSubmit(form, {
    optimisticValues: (nextValues) => ({ ...nextValues, workflowStatus: "Queued" as const }),
    async onSubmit(nextValues) {
      setSubmitTrace("Submitting optimistically.");
      await delay(650);
      if (failNextRef.current) {
        failNextRef.current = false;
        setFailNextSubmit(false);
        throw new FormSubmissionError({
          formError: "Mock submit failed. The form rolled back to the previous draft.",
        });
      }
      setSubmitTrace(`Submitted ${nextValues.requestTitle || "untitled request"}.`);
    },
    onRollback() {
      setSubmitTrace("Rolled back after the mock failure.");
    },
  });

  const submit = drafts.withClearOnSubmit(optimisticSubmit);

  const messages = submitTrace
    ? [{ id: "submit-trace", tone: values.workflowStatus === "Queued" ? "success" as const : "info" as const, children: submitTrace }]
    : [];

  return (
    <div className="ui-form-persistence-demo">
      <DraftResumePrompt
        draft={drafts.prompt?.draft}
        onRestore={(name) => {
          void drafts.restoreDraft(name);
        }}
        onDiscard={(name) => {
          void drafts.discardDraft(name);
        }}
        onDismiss={drafts.dismissPrompt}
      />
      <div className="ui-form-persistence-demo__toolbar">
        <SaveStatusIndicator
          status={saveStatus.status}
          error={saveStatus.error}
          lastSavedAt={saveStatus.lastSavedAt}
        />
        <button className="ui-form-persistence-button ui-form-persistence-button--secondary" type="button" onClick={onReload}>
          Reload demo
        </button>
        <button className="ui-form-persistence-button ui-form-persistence-button--secondary" type="button" onClick={() => void saveStatus.flush()}>
          Flush autosave
        </button>
      </div>
      <FormPanel
        form={form}
        idPrefix={idPrefix}
        eyebrow="Forms persistence"
        title="Operations request"
        subtitle="Autosave, draft resume, dirty guard, undo, and optimistic rollback run against a delayed in-memory adapter."
        badges={[
          { id: "dirty", label: formState.isDirty ? "dirty" : "clean", tone: formState.isDirty ? "warning" : "success" },
          { id: "status", label: values.workflowStatus, tone: values.workflowStatus === "Queued" ? "success" : "neutral" },
        ]}
        messages={messages}
        sections={[
          {
            id: "request",
            title: "Request",
            description: "The status field changes optimistically during submit and rolls back on failure.",
            fields: [
              { name: "requestTitle", label: "Title", required: true, placeholder: "Quarterly access review" },
              { name: "ownerEmail", label: "Owner email", type: "email", placeholder: "owner@example.com" },
              {
                name: "priority",
                label: "Priority",
                render: (binding) => <BoundSelect binding={binding as FieldBinding<PersistenceValues["priority"]>} />,
              },
              {
                name: "workflowStatus",
                label: "Workflow status",
                readOnly: true,
              },
              {
                name: "notes",
                label: "Notes",
                wide: true,
                render: (binding) => <BoundTextarea binding={binding as FieldBinding<string>} />,
              },
            ],
          },
        ]}
        onSubmit={submit}
        actions={
          <>
            <button
              className="ui-form-persistence-button ui-form-persistence-button--secondary"
              type="button"
              disabled={!undo.canUndo}
              onClick={undo.undo}
            >
              Undo
            </button>
            <button
              className="ui-form-persistence-button ui-form-persistence-button--secondary"
              type="button"
              onClick={() => {
                form.reset();
                undo.clear();
                setSubmitTrace(null);
              }}
            >
              Reset
            </button>
            <button className="ui-form-persistence-button" type="submit" disabled={formState.isSubmitting}>
              {formState.isSubmitting ? "Submitting" : "Submit"}
            </button>
          </>
        }
        footer={
          <div className="ui-form-persistence-demo__meta">
            <div className="ui-form-persistence-demo__row">
              <input
                className="ui-input"
                value={draftName}
                aria-label="Draft name"
                onChange={(event) => setDraftName(event.currentTarget.value)}
              />
              <button className="ui-form-persistence-button ui-form-persistence-button--secondary" type="button" onClick={() => void drafts.saveDraft(draftName)}>
                Save named draft
              </button>
            </div>
            <div className="ui-form-persistence-demo__drafts" aria-label="Saved drafts">
              {drafts.drafts.length === 0 ? <span>No named drafts.</span> : null}
              {drafts.drafts.map((draft) => (
                <span className="ui-form-persistence-demo__row" key={draft.name}>
                  <strong>{draft.name}</strong>
                  <button className="ui-form-persistence-button ui-form-persistence-button--secondary" type="button" onClick={() => void drafts.restoreDraft(draft.name)}>
                    Restore
                  </button>
                  <button className="ui-form-persistence-button ui-form-persistence-button--secondary" type="button" onClick={() => void drafts.removeDraft(draft.name)}>
                    Remove
                  </button>
                </span>
              ))}
            </div>
            <label className="ui-form-persistence-demo__toggle">
              <input
                type="checkbox"
                checked={failNextSubmit}
                onChange={(event) => setFailNextSubmit(event.currentTarget.checked)}
              />
              Fail next submit
            </label>
            <div className="ui-form-persistence-demo__row">
              <button
                className="ui-form-persistence-button ui-form-persistence-button--secondary"
                type="button"
                onClick={() => {
                  guard.confirmNavigation(() => setNavTrace("Demo navigation completed."), "Demo navigation");
                }}
              >
                Demo navigation
              </button>
              <span>{navTrace}</span>
            </div>
          </div>
        }
      />
      <DirtyGuardDialog
        open={Boolean(guard.pendingNavigation)}
        onConfirm={guard.proceedNavigation}
        onCancel={guard.cancelNavigation}
      />
    </div>
  );
}

export function PersistenceCatalogDemo({ idPrefix }: { idPrefix?: string } = {}) {
  const adapter = useMemo(
    () => createLatencyStorageAdapter(createMemoryStorageAdapter<unknown>(), 180),
    [],
  );
  const [reloadKey, setReloadKey] = useState(0);
  return (
    <PersistenceDemoInstance
      key={reloadKey}
      adapter={adapter}
      idPrefix={idPrefix}
      onReload={() => setReloadKey((value) => value + 1)}
    />
  );
}
