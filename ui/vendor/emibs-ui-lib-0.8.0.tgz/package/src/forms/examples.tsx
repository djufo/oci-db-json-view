// src/forms — worked example of the forms engine (catalog render target).
//
// A typed useForm({ schema }) rendered through <FormPanel> (EditableFormPanel
// layout) with live validation, announced errors, blocked submit, a simulated
// async submit, server-error reconciliation, and reset. This is the component
// the catalog registers as the Forms engine demo entry.

import { useState } from "react";
import { z } from "zod";

import { FormSubmissionError, useForm, useFormState } from "../core/orchestration/forms";
import type { FormSpec } from "../core/config";
import { ArrayField } from "./ArrayField";
import { AutoForm, type AutoFormOverrides } from "./AutoForm";
import { Form } from "./Form";
import { FormField } from "./FormField";
import { FormPanel } from "./FormPanel";
import { Button } from "../lib";

const signupSchema = z
  .object({
    email: z.string().min(1, "Email is required").email("Enter a valid email"),
    password: z.string().min(8, "Use at least 8 characters"),
    confirm: z.string().min(1, "Confirm your password"),
  })
  .refine((values) => values.password === values.confirm, {
    path: ["confirm"],
    message: "Passwords must match",
  });

type SignupValues = z.infer<typeof signupSchema>;

const lineItemsSchema = z.object({
  lineItems: z
    .array(
      z.object({
        description: z.string().min(1, "Description is required"),
        qty: z.coerce.number().min(1, "Qty must be at least 1"),
        price: z.coerce.number().min(0, "Price cannot be negative"),
      }),
    )
    .min(1, "Add at least one line item")
    .max(5, "Use five line items or fewer"),
});

type LineItemsValues = z.infer<typeof lineItemsSchema>;

/** The reserved address that the simulated backend rejects with a 422. */
const TAKEN_EMAIL = "taken@example.com";

export function ValidatedFormPanelDemo() {
  // Value type is INFERRED from the schema; no explicit generic needed.
  const form = useForm({
    schema: signupSchema,
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: { email: "", password: "", confirm: "" },
  });
  const { isSubmitting, isValid, submitCount } = useFormState(form);
  const [createdFor, setCreatedFor] = useState<string | null>(null);

  const onSubmit = async (values: SignupValues) => {
    // Simulate a network round-trip; reconcile a server-side 422 for a taken email.
    await new Promise((resolve) => setTimeout(resolve, 350));
    if (values.email.toLowerCase() === TAKEN_EMAIL) {
      throw new FormSubmissionError({
        formError: "That email is already registered.",
        fieldErrors: { email: "Email already in use" },
      });
    }
    setCreatedFor(values.email);
  };

  return (
    <div style={{ display: "grid", gap: "var(--space-5)", maxWidth: 760 }}>
      <FormPanel
        form={form}
        onSubmit={onSubmit}
        eyebrow="Forms engine"
        title="Create account"
        subtitle={`Schema-validated form on the headless engine. Submit ${TAKEN_EMAIL} to see server-error reconciliation.`}
        badges={[
          { id: "valid", label: isValid ? "valid" : "invalid", tone: isValid ? "success" : "warning" },
          { id: "count", label: `submits: ${submitCount}`, tone: "info" },
        ]}
        messages={
          createdFor
            ? [{ id: "ok", tone: "success", children: `Account created for ${createdFor}.` }]
            : []
        }
        sections={[
          {
            id: "credentials",
            title: "Credentials",
            description: "Live validation follows the onBlur / reValidate-onChange timing.",
            fields: [
              {
                name: "email",
                label: "Email",
                type: "email",
                required: true,
                placeholder: "you@example.com",
                autoComplete: "email",
              },
              {
                name: "password",
                label: "Password",
                type: "password",
                required: true,
                hint: "At least 8 characters.",
                autoComplete: "new-password",
              },
              {
                name: "confirm",
                label: "Confirm password",
                type: "password",
                required: true,
                autoComplete: "new-password",
              },
            ],
          },
        ]}
        actions={
          <>
            <Button
              size="sm"
              type="button"
              variant="secondary"
              onClick={() => {
                form.reset();
                setCreatedFor(null);
              }}
            >
              Reset
            </Button>
            <Button size="sm" type="submit" disabled={isSubmitting}>
              {isSubmitting ? "Creating…" : "Create account"}
            </Button>
          </>
        }
      />
      <LineItemsArrayFieldDemo />
    </div>
  );
}

export function LineItemsArrayFieldDemo() {
  const form = useForm({
    schema: lineItemsSchema,
    mode: "onBlur",
    reValidateMode: "onChange",
    defaultValues: {
      lineItems: [{ description: "Design review", qty: 1, price: 125 }],
    },
  });
  const { isSubmitting } = useFormState(form);
  const [submitted, setSubmitted] = useState<string | null>(null);

  const onSubmit = (values: LineItemsValues) => {
    setSubmitted(JSON.stringify(values, null, 2));
  };

  return (
    <Form form={form} onSubmit={onSubmit} className="ui-editable-form ui-editable-form--comfortable">
      <header className="ui-editable-form__header">
        <div className="ui-editable-form__title-block">
          <span className="ui-editable-form__eyebrow">Field array</span>
          <h2>Line items</h2>
          <p>Repeatable nested rows validate and submit as an array of objects.</p>
        </div>
      </header>
      <ArrayField
        form={form}
        name="lineItems"
        label="Line items"
        description="Add, remove, or reorder rows. Keyboard users can use the buttons or Alt+ArrowUp / Alt+ArrowDown on a focused row."
        createItem={() => ({ description: "", qty: 1, price: 0 })}
        getFocusName={(rowName) => `${rowName}.description`}
        required
      >
        {({ name }) => (
          <div className="ui-editable-form__grid">
            <FormField
              form={form}
              name={`${name}.description`}
              label="Description"
              required
              placeholder="Consulting"
            />
            <FormField
              form={form}
              name={`${name}.qty`}
              label="Qty"
              type="number"
              required
            />
            <FormField
              form={form}
              name={`${name}.price`}
              label="Price"
              type="number"
              required
            />
          </div>
        )}
      </ArrayField>
      <footer className="ui-editable-form__footer">
        <Button type="submit" size="sm" disabled={isSubmitting}>
          Submit line items
        </Button>
        {submitted ? <pre>{submitted}</pre> : null}
      </footer>
    </Form>
  );
}

interface ProjectSetupValues {
  title: string;
  accentColor: string;
  notes: string;
}

const projectSetupSpec: FormSpec<ProjectSetupValues> = {
  fields: [
    {
      name: "title",
      type: "text",
      label: "Project title",
      required: true,
      validation: { required: true },
      section: "main",
      placeholder: "Migration dashboard",
    },
    {
      name: "accentColor",
      type: "text",
      label: "Accent color",
      section: "main",
      default: "#2563eb",
    },
    {
      name: "notes",
      type: "textarea",
      label: "Review notes",
      section: "review",
      width: "full",
    },
  ],
  sections: [
    { id: "main", title: "Main details" },
    { id: "review", title: "Review layout" },
  ],
};

const projectSetupOverrides: AutoFormOverrides = {
  controls: {
    accentColor: ({ field, binding, id }) => (
      <div className="ui-auto-form__control-shell">
        <label className="ui-field__label" htmlFor={id}>
          {field.label}
        </label>
        <input
          id={id}
          name={binding.name}
          type="color"
          value={String(binding.value ?? "#2563eb")}
          onBlur={binding.onBlur}
          onChange={(event) => binding.onChange(event.currentTarget.value)}
          onFocus={binding.onFocus}
        />
      </div>
    ),
  },
  renderSection: ({ section, content }) =>
    section.id === "review" ? (
      <div className="ui-auto-form__section-slot">
        <p>Section-specific layout can insert review guidance without replacing the rest of the form.</p>
        {content}
      </div>
    ) : (
      content
    ),
};

export function AutoFormOverrideDemo() {
  return (
    <div style={{ maxWidth: 640 }}>
      <AutoForm<ProjectSetupValues>
        spec={projectSetupSpec}
        overrides={projectSetupOverrides}
        title="Project setup"
        subtitle="One field uses a bespoke color control while the review section uses a layout slot."
        submitLabel="Save project"
        onSubmit={() => undefined}
      />
    </div>
  );
}
