# Conditional Forms

Catalog demo for conditional visibility, dependent options, and computed values.

- Uses form rules for `visible`, `required`, and `compute`.
- Hidden fields are removed from validation and submitted values by the engine.
- Dynamic show/hide changes are mirrored into a hidden `role="status"` / `aria-live="polite"` region.

