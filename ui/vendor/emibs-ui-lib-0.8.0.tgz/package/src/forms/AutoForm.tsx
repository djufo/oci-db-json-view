// src/forms — <AutoForm>: render a complete, validated, themed, accessible form
// from a FormSpec (issue-601).
//
// AutoForm is the schema-driven renderer at the top of the Forms feature: given
// a presentation-free FormSpec (hand-authored or derived from a Zod schema via
// core/config `zodToSpec`), it instantiates the headless engine (useForm,
// issue-552), registers every field, seeds defaults, and lays the fields into
// the EditableFormPanel shell — each field rendered by the type → control
// registry so swapping a field's `type` in the spec swaps the control with no
// other change. When a Zod `schema` is supplied it becomes the resolver (single
// source of truth) so validation + sanitized submit values come from the schema.
//
// FormSpec is FLAT (issue-600): fields carry an optional `section` id and
// `order`; AutoForm groups them into the spec's declared `sections` (falling
// back to one implicit section) at render time.
//
// Presentation BINDING (issue-569): consumes core (config + engine) plus
// primitives/data shells through the src/lib public surface; it is NOT part of
// core.

import { useMemo, type ReactNode } from "react";

import {
  type FieldType,
  type FormFieldSpec,
  type FormSectionSpec,
  type FormSpec,
} from "../core/config";
import {
  standardSchemaResolver,
  useForm,
  useFormState,
  type FieldValues,
  type Resolver,
  type ReValidateMode,
  type StandardSchemaV1,
  type SubmitErrorHandler,
  type SubmitHandler,
  type UseFormReturn,
  type ValidationMode,
} from "../core/orchestration/forms";
import {
  Button,
  EditableFormPanel,
  cn,
  type EditableFormBadge,
  type EditableFormMessage,
} from "../lib";
import { FormProvider } from "./Form";
import { useField } from "./useField";
import {
  ErrorSummary,
  FormErrorAnnouncer,
  FormSuccessRegion,
  formFieldControlId,
  type FormFieldChrome,
} from "./validationChrome";
import {
  createControlRegistry,
  resolveControlRenderer,
  type ControlRegistry,
  type AutoFormControlRenderer,
} from "./controlRegistry";
import type { FieldBinding } from "./useField";

/** A section resolved from the flat spec: its chrome plus the fields in it. */
export interface AutoFormResolvedSection {
  id: string;
  title?: ReactNode;
  description?: ReactNode;
  fields: FormFieldSpec[];
}

/** Context handed to a per-field layout slot (issue-602). */
export interface AutoFormFieldRenderContext {
  field: FormFieldSpec;
  binding: FieldBinding;
  id: string;
  /** the resolved control element (default or per-field override) */
  control: ReactNode;
  /** the default wrapping cell — return this untouched to keep default layout */
  cell: ReactNode;
}

/** Context handed to a section layout slot (issue-602). */
export interface AutoFormSectionRenderContext {
  section: AutoFormResolvedSection;
  /** the default auto-rendered fields grid for this section */
  content: ReactNode;
}

/**
 * Escape hatches that let AutoForm degrade to hand-authored fields/layout while
 * still owning registration, validation, and submission through one engine
 * (issue-602). Everything here is optional and composes with the auto-render.
 */
export interface AutoFormOverrides {
  /** per-field custom control keyed by field name; still bound to the engine */
  controls?: Record<string, AutoFormControlRenderer>;
  /** wrap or replace a field's layout cell (add chrome, custom layout, …) */
  renderField?: (ctx: AutoFormFieldRenderContext) => ReactNode;
  /** wrap or replace a section's body (insert content around the fields grid) */
  renderSection?: (ctx: AutoFormSectionRenderContext) => ReactNode;
}

export interface AutoFormProps<TValues extends object = FieldValues> {
  /** the form model: flat fields + optional sections + validation + layout */
  spec: FormSpec<TValues>;
  /** valid-submit handler; receives schema-sanitized values when a schema is set */
  onSubmit: SubmitHandler<TValues>;
  onInvalid?: SubmitErrorHandler;
  /**
   * Optional Standard Schema (Zod is the reference vendor). When present it is
   * the resolver — the single source of truth for validation + sanitized values.
   * Pair with `zodToSpec(schema)` to keep layout + validation from one schema.
   */
  schema?: StandardSchemaV1;
  /** explicit resolver (ignored when `schema` is set); advanced escape hatch */
  resolver?: Resolver<TValues>;
  /** seed values merged over the spec-derived defaults */
  defaultValues?: Partial<TValues>;
  mode?: ValidationMode;
  reValidateMode?: ReValidateMode;
  /** override/extend the type → control registry (by field TYPE) */
  registry?: ControlRegistry;
  /** per-field control + layout escape hatches (by field NAME) (issue-602) */
  overrides?: AutoFormOverrides;
  /** stable id prefix for generated control ids (default "auto-form") */
  idPrefix?: string;
  /** panel chrome */
  title?: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  badges?: EditableFormBadge[];
  messages?: EditableFormMessage[];
  /** extra actions rendered beside the submit button */
  actions?: ReactNode;
  /** post-submit success/confirmation content announced through role=status */
  successMessage?: ReactNode;
  /** render the field-linking ErrorSummary after a failed submit (default true) */
  showErrorSummary?: boolean;
  errorSummaryTitle?: ReactNode;
  errorSummaryDescription?: ReactNode;
  showOptionalLabels?: boolean;
  announceErrors?: boolean;
  /** Disable native browser validation so the engine owns submit lifecycle. */
  noValidate?: boolean;
  /** submit button label (defaults to "Submit") */
  submitLabel?: ReactNode;
  footer?: ReactNode;
  variant?: "comfortable" | "compact";
  submitErrorTone?: EditableFormMessage["tone"];
  className?: string;
}

const DEFAULT_SECTION_ID = "__auto-form-default";

function emptyValueForType(type: FieldType): unknown {
  switch (type) {
    case "checkbox":
    case "switch":
      return false;
    case "file":
    case "tags":
      return [];
    default:
      return "";
  }
}

function defaultValuesFromSpec<TValues extends object>(spec: FormSpec<TValues>): Record<string, unknown> {
  const values: Record<string, unknown> = {};
  for (const field of spec.fields) {
    values[field.name] = field.default ?? emptyValueForType(field.type);
  }
  return values;
}

/** Group the spec's flat fields into ordered sections, respecting `field.section`,
 *  `field.order`, and `section.order`. Fields without a matching section join a
 *  trailing implicit (untitled) section. Empty declared sections are dropped. */
function resolveSections<T extends object>(spec: FormSpec<T>): AutoFormResolvedSection[] {
  const declared = new Map<string, FormSectionSpec>();
  for (const s of spec.sections ?? []) declared.set(s.id, s);

  const orderedFields = spec.fields
    .map((field, index) => ({ field, index }))
    .sort((a, b) => (a.field.order ?? a.index) - (b.field.order ?? b.index) || a.index - b.index)
    .map((entry) => entry.field);

  const buckets = new Map<string, FormFieldSpec[]>();
  for (const field of orderedFields) {
    const key = field.section && declared.has(field.section) ? field.section : DEFAULT_SECTION_ID;
    const bucket = buckets.get(key) ?? [];
    bucket.push(field);
    buckets.set(key, bucket);
  }

  const sections: AutoFormResolvedSection[] = [];
  const declaredOrder = [...(spec.sections ?? [])].sort(
    (a, b) => (a.order ?? 0) - (b.order ?? 0),
  );
  for (const s of declaredOrder) {
    const fields = buckets.get(s.id);
    if (fields && fields.length > 0) {
      sections.push({ id: s.id, title: s.title, description: s.description, fields });
    }
  }
  const leftover = buckets.get(DEFAULT_SECTION_ID);
  if (leftover && leftover.length > 0) {
    sections.push({ id: DEFAULT_SECTION_ID, fields: leftover });
  }
  return sections;
}

/** One auto-rendered field: binds to the engine + renders via the registry,
 *  honoring per-field control + layout overrides (issue-602). */
function AutoFormField<TValues extends object>({
  field,
  form,
  registry,
  idPrefix,
  disabled,
  showOptionalLabels,
  overrides,
}: {
  field: FormFieldSpec;
  form: UseFormReturn<TValues>;
  registry: Record<FormFieldSpec["type"], AutoFormControlRenderer>;
  idPrefix: string;
  disabled?: boolean;
  showOptionalLabels?: boolean;
  overrides?: AutoFormOverrides;
}) {
  const id = formFieldControlId(field.name, idPrefix);
  const binding = useField<TValues, keyof TValues & string>(field.name as keyof TValues & string, {
    form,
    defaultValue: field.default as TValues[keyof TValues & string],
    focusId: id,
  });
  // Per-field control override (by name) wins over the type registry, but the
  // engine still owns registration (useField above) + validation (binding.error).
  const render = overrides?.controls?.[field.name] ?? resolveControlRenderer(registry, field.type);
  const control = render({ field, binding: binding as FieldBinding, id, disabled, showOptionalLabel: showOptionalLabels });
  const cell = (
    <div className={cn("ui-auto-form__cell", field.width && `ui-auto-form__cell--${field.width}`)}>
      {control}
    </div>
  );
  if (overrides?.renderField) {
    return <>{overrides.renderField({ field, binding: binding as FieldBinding, id, control, cell })}</>;
  }
  return cell;
}

export function AutoForm<TValues extends object = FieldValues>({
  spec,
  onSubmit,
  onInvalid,
  schema,
  resolver,
  defaultValues,
  mode,
  reValidateMode,
  registry,
  overrides,
  idPrefix = "auto-form",
  title,
  eyebrow,
  subtitle,
  badges,
  messages = [],
  actions,
  successMessage,
  showErrorSummary = true,
  errorSummaryTitle,
  errorSummaryDescription,
  showOptionalLabels = true,
  announceErrors = true,
  noValidate = true,
  submitLabel,
  footer,
  variant,
  submitErrorTone = "danger",
  className,
}: AutoFormProps<TValues>) {
  const controls = useMemo(() => createControlRegistry(registry), [registry]);

  const effectiveResolver = useMemo<Resolver<TValues> | undefined>(() => {
    if (schema) return standardSchemaResolver(schema) as unknown as Resolver<TValues>;
    return resolver;
  }, [schema, resolver]);

  const seededDefaults = useMemo(
    () => ({ ...defaultValuesFromSpec(spec), ...(defaultValues ?? {}) }) as Partial<TValues>,
    [spec, defaultValues],
  );

  const sections = useMemo(() => resolveSections(spec), [spec]);

  const form = useForm<TValues>({
    defaultValues: seededDefaults,
    resolver: effectiveResolver,
    mode,
    reValidateMode,
  });

  const formState = useFormState(form);
  const submit = form.handleSubmit(onSubmit, onInvalid);
  const fieldChrome: FormFieldChrome[] = spec.fields.map((field) => ({
    name: field.name,
    label: field.label,
    controlId: formFieldControlId(field.name, idPrefix),
  }));

  const allMessages: EditableFormMessage[] = [
    ...(showErrorSummary && formState.submitCount > 0 && !formState.isValid
      ? [
          {
            id: "auto-form-error-summary",
            tone: "danger" as const,
            children: (
              <ErrorSummary
                form={form}
                fields={fieldChrome}
                title={errorSummaryTitle}
                description={errorSummaryDescription}
              />
            ),
          },
        ]
      : []),
    ...messages,
    ...(formState.submitError
      ? [{ id: "auto-form-submit-error", tone: submitErrorTone, children: formState.submitError }]
      : []),
    ...(successMessage
      ? [
          {
            id: "auto-form-success-region",
            tone: "success" as const,
            children: <FormSuccessRegion>{successMessage}</FormSuccessRegion>,
          },
        ]
      : []),
  ];

  const submitAction = (
    <Button type="submit" variant="primary" disabled={formState.isSubmitting}>
      {submitLabel ?? "Submit"}
    </Button>
  );

  return (
    <FormProvider form={form}>
      {announceErrors ? <FormErrorAnnouncer form={form} fields={fieldChrome} /> : null}
      <EditableFormPanel
        className={className}
        title={title}
        eyebrow={eyebrow}
        subtitle={subtitle}
        badges={badges}
        messages={allMessages}
        variant={variant}
        noValidate={noValidate}
        actions={
          actions ? (
            <>
              {actions}
              {submitAction}
            </>
          ) : (
            submitAction
          )
        }
        footer={footer}
        onSubmit={(event) => {
          void submit(event);
        }}
        sections={sections.map((section) => {
          const content = (
            <div className="ui-editable-form__grid ui-auto-form__grid">
              {section.fields.map((field) => (
                <AutoFormField
                  key={field.name}
                  field={field}
                  form={form}
                  registry={controls}
                  idPrefix={idPrefix}
                  disabled={formState.isSubmitting}
                  showOptionalLabels={showOptionalLabels}
                  overrides={overrides}
                />
              ))}
            </div>
          );
          return {
            id: section.id,
            title: section.title,
            description: section.description,
            children: overrides?.renderSection ? overrides.renderSection({ section, content }) : content,
          };
        })}
      />
    </FormProvider>
  );
}
