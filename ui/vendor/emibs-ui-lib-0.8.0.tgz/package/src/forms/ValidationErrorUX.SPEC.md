# Validation Error UX

Catalog demo for blocked submits, validation timing, and server-error reconciliation.

- Exercises `onChange`, `onBlur`, and `onSubmit` validation modes.
- Shows engine-owned error summaries and first-error focus requests.
- Demonstrates `FormSubmissionError` mapping form-level and field-level server errors.

