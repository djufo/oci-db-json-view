# AutoForm

Schema-driven form renderer. Given a presentation-free `FormSpec` (hand-authored
or derived from a Zod schema via `zodToSpec`), `AutoForm` instantiates the
headless engine (`useForm`), registers every field, seeds defaults, and lays the
fields into the `EditableFormPanel` shell — each field rendered by a
type→control registry so swapping a field's `type` swaps the control with no
other change. When a Zod `schema` is supplied it becomes the resolver (the single
source of truth) for validation and sanitized submit values.

`FormSpec` is flat: `{ fields, sections? }`. Each field carries an optional
`section` id and `order`; AutoForm groups the fields into the declared sections
(fields with no matching section join one trailing implicit section) at render
time.

Owning epic: issue-553 (schema-driven auto-form renderer). Stories: issue-600
(FormSpec + Zod derivation via `zodToSpec`), issue-601 (registry + renderer),
issue-602 (overrides + layout slots).

## Import

```tsx
import { AutoForm } from "emibs-ui-lib/forms";
import { zodToSpec } from "emibs-ui-lib/core";
```

## Props

| Prop | Type | Description |
| --- | --- | --- |
| `spec` | `FormSpec` | Flat fields + optional sections + validation + layout (required). |
| `onSubmit` | `(values) => void \| Promise<void>` | Valid-submit handler; receives schema-sanitized values (required). |
| `schema` | `StandardSchemaV1` | Optional Zod schema; becomes the resolver (single source of truth). |
| `defaultValues` | `Partial<TValues>` | Seed values merged over the spec-derived defaults. |
| `mode` / `reValidateMode` | validation timing | Passed through to the engine. |
| `registry` | `ControlRegistry` | Override/extend the type→control map (by field type). |
| `overrides` | `AutoFormOverrides` | Per-field control + layout escape hatches (issue-602). |
| `showErrorSummary` / `errorSummaryTitle` / `errorSummaryDescription` | summary chrome | The default submit-failure summary lists current field errors as links that focus generated controls. |
| `successMessage` | `ReactNode` | Optional post-submit confirmation rendered in a `role="status"` live region. |
| `showOptionalLabels` / `announceErrors` | boolean | Toggle the optional field convention and hidden polite error announcer. |
| `title` / `subtitle` / `badges` / `actions` / `submitLabel` / `footer` / `variant` | panel chrome | Supplied by the caller (the flat `FormSpec` carries no form-level chrome). |

## Type → control registry

`text → TextInputControl`, `textarea → TextareaControl`,
`number → NumberInputControl`, `select → SelectControl`,
`combobox → ComboboxField`, `radio → RadioGroup`, `checkbox → CheckboxControl`,
`switch → SwitchControl`, `date → DateField`, `tags → TagInput`,
`file → FileUploadControl`. The registry is a plain record, so
`createControlRegistry(overrides)` registers or replaces a control without
editing `AutoForm`. A field with no explicit `label` falls back to a humanized
name.

## Overrides (issue-602)

- `overrides.controls[name]` — a bespoke control for one named field, still
  engine-bound (registration + validation flow unchanged).
- `overrides.renderField` — wrap or replace a field's layout cell.
- `overrides.renderSection` — wrap or replace a section body around the fields
  grid.

## Accessibility

The registry preserves label association, `aria-invalid`/`aria-describedby` where
the current control supports those native attributes, `role="alert"` on rendered
errors, and the required/optional convention. Generated controls use stable ids
derived from `idPrefix` + field name; the submit-failure `ErrorSummary` uses
those ids for in-page links and focus. Field errors are mirrored into a hidden
polite live region, and `successMessage` renders in a status live region.
Token-only styling renders correctly in light/dark + brand themes.

## Validation Messages

When a Zod/Standard Schema resolver is supplied, the schema's own messages win.
For FormSpec-driven validation, `createFormSpecResolver(spec, { messages,
fieldMessages, formatMessage })` provides the lightweight i18n seam:
field-level rule messages win over the dictionary, which wins over the default
English rule messages.

Server 422-style responses map through the engine contract:

```ts
throw new FormSubmissionError({
  formError: "Could not save.",
  fieldErrors: { email: "Email already exists" },
});
```

## Boundaries

`AutoForm` is presentation binding (issue-569): it consumes core (config +
engine) + primitives + `EditableFormPanel`; it is not part of core. Conditional
fields, field arrays, wizards, and the visual builder are separate epics.
