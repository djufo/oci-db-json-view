export const ENTITY_CRUD_USAGE_NOTE = [
  "Define one EntityModel with identity, labelField, fields, displayColumns, filters, and relations.",
  "Use modelToFormSpec for create/edit forms; ResourceManager composes the generated list, detail, AutoForm editor, and delete flow.",
  "All data access goes through a CrudAdapter, so replacing createMockAdapter with a real adapter does not require ResourceManager or generator changes.",
  "Mutations use a refetch-after-mutate strategy: create, update, and delete call the adapter, then refresh the list and selected detail state.",
].join(" ");
