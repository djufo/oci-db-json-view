export {
  modelToList,
  modelToDetail,
  EntityListView,
  EntityDetailView,
  formatEntityValue,
  type EntityRelatedLabels,
  type EntityListViewProps,
  type EntityDetailViewProps,
} from "./generators";

export {
  createEntityCrudFormOverrides,
  type EntityRelationResource,
  type EntityRelationResourceMap,
  type EntityCrudFormOverrideOptions,
} from "./relationshipControl";

export {
  ResourceManager,
  type ResourceManagerProps,
} from "./ResourceManager";

export { EntityCrudCatalogDemo } from "./demo";
export { ENTITY_CRUD_USAGE_NOTE } from "./docs";
