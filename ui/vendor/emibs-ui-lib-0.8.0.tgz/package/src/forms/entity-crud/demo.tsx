import { useMemo } from "react";

import {
  exampleOwnerModel,
  exampleOwnerRows,
  exampleProjectModel,
  exampleProjectRows,
} from "../../core/config";
import { createMockAdapter } from "../../core/orchestration";
import { ResourceManager } from "./ResourceManager";
import type { EntityRelationResourceMap } from "./relationshipControl";

export function EntityCrudCatalogDemo() {
  const ownerAdapter = useMemo(
    () => createMockAdapter(exampleOwnerRows, { identity: "id", idPrefix: "owner" }),
    [],
  );
  const projectAdapter = useMemo(
    () => createMockAdapter(exampleProjectRows, { identity: "id", idPrefix: "project" }),
    [],
  );
  const relationResources = useMemo<EntityRelationResourceMap>(
    () => ({
      "project-owner": {
        model: exampleOwnerModel,
        adapter: ownerAdapter,
        rows: exampleOwnerRows,
      },
    }),
    [ownerAdapter],
  );

  return (
    <ResourceManager
      model={exampleProjectModel}
      adapter={projectAdapter}
      relationResources={relationResources}
      pageSize={2}
    />
  );
}
