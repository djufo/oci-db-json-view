// src/forms — the type → control registry for AutoForm (issue-601).
//
// Maps each FormSpec FieldType to the Field-contract primitive that renders it,
// bound to the headless engine through a useField `binding`. This is the
// presentation BINDING (issue-569): it consumes core config (FieldType /
// FormFieldSpec) + the engine binding and produces JSX; it lives at the
// forms/components edge, never inside core. The registry is a plain record, so a
// consumer can register a new type → control (or override a built-in) without
// editing AutoForm — see `createControlRegistry`.
//
// Primitives are consumed through src/lib's public surface. The registry applies
// the engine binding and the validation/a11y affordances that current primitives
// expose; no primitive/core changes are required for this presentation binding.

import { useState, type ReactElement } from "react";

import { type FieldOption, type FieldType, type FormFieldSpec } from "../core/config";
import type { FieldBinding } from "./useField";
import { FieldRequirementLabel } from "./validationChrome";
import {
  CheckboxControl,
  ComboboxField,
  DateField,
  FileUploadControl,
  NumberInputControl,
  RadioGroup,
  SelectControl,
  SwitchControl,
  TagInput,
  TextInputControl,
  TextareaControl,
  type TagInputItem,
} from "../lib";

/** Everything a control renderer needs to bind one field to the engine. */
export interface AutoFormControlContext {
  /** the field's declarative config (label, options, validation, …) */
  field: FormFieldSpec;
  /** the engine binding for this field (value/onChange/onBlur/error/…) */
  binding: FieldBinding;
  /** stable dom id for the control (label association + aria) */
  id: string;
  /** form-level disabled (e.g. while submitting) OR field-level disabled */
  disabled?: boolean;
  /** show an "Optional" convention for fields that are not required */
  showOptionalLabel?: boolean;
}

/** Renders one bound control for a field type. */
export type AutoFormControlRenderer = (ctx: AutoFormControlContext) => ReactElement;

/** A (partial) map of field type → control renderer. */
export type ControlRegistry = Partial<Record<FieldType, AutoFormControlRenderer>>;

// --- value + field coercion --------------------------------------------------

function asString(value: unknown): string {
  return value === null || value === undefined ? "" : String(value);
}
function asBoolean(value: unknown): boolean {
  return value === true;
}
function asStringArray(value: unknown): string[] {
  return Array.isArray(value) ? value.map(String) : [];
}

function humanizeName(name: string): string {
  const words = name
    .replace(/[_-]+/g, " ")
    .replace(/([a-z0-9])([A-Z])/g, "$1 $2")
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length === 0) return name;
  return words.map((word, index) => (index === 0 ? word.charAt(0).toUpperCase() + word.slice(1) : word)).join(" ");
}

/** A field's label, falling back to a humanized name (derivation only sets a
 *  label from `.meta`, so most derived fields rely on this). */
function labelOf(field: FormFieldSpec): string {
  return field.label != null ? String(field.label) : humanizeName(field.name);
}
/** Required is mirrored onto both `field.required` and `field.validation.required`. */
function isRequired(field: FormFieldSpec): boolean {
  return field.required === true || field.validation?.required === true;
}
function requirementOf(field: FormFieldSpec, showOptionalLabel = true): ReactElement | null {
  const required = isRequired(field);
  if (!required && !showOptionalLabel) return null;
  return <FieldRequirementLabel required={required} optional={showOptionalLabel && !required} />;
}
function optionalRequirementOf(field: FormFieldSpec, showOptionalLabel = true): ReactElement | null {
  if (!showOptionalLabel) return null;
  return isRequired(field) ? null : <FieldRequirementLabel optional={showOptionalLabel} />;
}
/** Choice options as `{ value: string; label }` (control option value is string). */
function choiceOptions(options: readonly FieldOption[] | undefined) {
  return (options ?? []).map((o) => ({ value: String(o.value), label: o.label, disabled: o.disabled }));
}

function validationIds(id: string, error: string | undefined) {
  const errorId = error ? `${id}-error` : undefined;
  return {
    errorId,
    describedBy: errorId,
    invalid: error ? true : undefined,
  };
}

function FieldError({ id, error }: { id: string; error: string | undefined }) {
  if (!error) return null;
  return (
    <span className="ui-field__error" id={`${id}-error`} role="alert" aria-atomic="true">
      {error}
    </span>
  );
}

// --- tags need a small draft-holding wrapper (engine stores the string[]) -----

function AutoTagsControl({ field, binding, id, disabled, showOptionalLabel }: AutoFormControlContext): ReactElement {
  const [draft, setDraft] = useState("");
  const values = asStringArray(binding.value);
  const tags: TagInputItem[] = values.map((value) => ({ id: value, label: value, value }));
  const { errorId } = validationIds(id, binding.error);
  const optional = optionalRequirementOf(field, showOptionalLabel);
  return (
    <div className="ui-auto-form__control-shell" aria-invalid={binding.error ? true : undefined} aria-describedby={errorId}>
      {optional ? <div className="ui-auto-form__requirement-row">{optional}</div> : null}
      <TagInput
        id={id}
        label={labelOf(field)}
        hint={field.description}
        placeholder={field.placeholder}
        disabled={disabled}
        value={draft}
        tags={tags}
        onValueChange={setDraft}
        onAdd={(value) => {
          const next = value.trim();
          if (next && !values.includes(next)) binding.onChange([...values, next]);
          setDraft("");
        }}
        onRemove={(tag) => binding.onChange(values.filter((v) => v !== tag.value))}
      />
      <FieldError id={id} error={binding.error} />
    </div>
  );
}

// --- the default registry -----------------------------------------------------

export const defaultControlRegistry: Record<FieldType, AutoFormControlRenderer> = {
  text: ({ field, binding, id, disabled, showOptionalLabel }) => (
    <TextInputControl
      id={id}
      label={labelOf(field)}
      hint={field.description}
      error={binding.error}
      status={requirementOf(field, showOptionalLabel)}
      placeholder={field.placeholder}
      required={isRequired(field)}
      aria-required={isRequired(field) || undefined}
      disabled={disabled}
      name={binding.name}
      value={asString(binding.value)}
      onValueChange={(value) => binding.onChange(value)}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
    />
  ),

  textarea: ({ field, binding, id, disabled, showOptionalLabel }) => (
    <TextareaControl
      id={id}
      label={labelOf(field)}
      hint={field.description}
      error={binding.error}
      status={requirementOf(field, showOptionalLabel)}
      placeholder={field.placeholder}
      required={isRequired(field)}
      aria-required={isRequired(field) || undefined}
      disabled={disabled}
      name={binding.name}
      value={asString(binding.value)}
      onValueChange={(value) => binding.onChange(value)}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
    />
  ),

  number: ({ field, binding, id, disabled, showOptionalLabel }) => (
    <NumberInputControl
      id={id}
      label={labelOf(field)}
      hint={field.description}
      error={binding.error}
      status={requirementOf(field, showOptionalLabel)}
      placeholder={field.placeholder}
      required={isRequired(field)}
      aria-required={isRequired(field) || undefined}
      disabled={disabled}
      min={field.validation?.min}
      max={field.validation?.max}
      name={binding.name}
      value={asString(binding.value)}
      onValueChange={(raw, valueAsNumber) => binding.onChange(valueAsNumber ?? raw)}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
    />
  ),

  select: ({ field, binding, id, disabled, showOptionalLabel }) => (
    <SelectControl
      id={id}
      label={labelOf(field)}
      hint={field.description}
      error={binding.error}
      status={requirementOf(field, showOptionalLabel)}
      placeholder={field.placeholder ?? "Select…"}
      required={isRequired(field)}
      aria-required={isRequired(field) || undefined}
      disabled={disabled}
      name={binding.name}
      options={choiceOptions(field.options)}
      value={asString(binding.value)}
      onValueChange={(value) => binding.onChange(value)}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
    />
  ),

  combobox: ({ field, binding, id, disabled, showOptionalLabel }) => (
    <ComboboxField
      id={id}
      label={labelOf(field)}
      hint={field.description}
      error={binding.error}
      meta={optionalRequirementOf(field, showOptionalLabel)}
      placeholder={field.placeholder}
      required={isRequired(field)}
      aria-required={isRequired(field) || undefined}
      disabled={disabled}
      name={binding.name}
      options={choiceOptions(field.options)}
      value={asString(binding.value)}
      onValueChange={(value) => binding.onChange(value)}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
    />
  ),

  radio: ({ field, binding, id, disabled, showOptionalLabel }) => (
    <RadioGroup
      id={id}
      label={labelOf(field)}
      description={field.description}
      error={binding.error}
      meta={optionalRequirementOf(field, showOptionalLabel)}
      required={isRequired(field)}
      disabled={disabled}
      name={binding.name}
      options={choiceOptions(field.options)}
      value={asString(binding.value)}
      onChange={(value) => binding.onChange(value)}
    />
  ),

  checkbox: ({ field, binding, id, disabled, showOptionalLabel }) => {
    const validation = validationIds(id, binding.error);
    return (
      <div className="ui-auto-form__control-shell">
        <CheckboxControl
          id={id}
          name={binding.name}
          label={labelOf(field)}
          description={field.description}
          status={optionalRequirementOf(field, showOptionalLabel)}
          aria-describedby={validation.describedBy}
          aria-invalid={validation.invalid}
          aria-required={isRequired(field) || undefined}
          required={isRequired(field)}
          disabled={disabled}
          checked={asBoolean(binding.value)}
          onChange={(checked) => binding.onChange(checked)}
          onBlur={binding.onBlur}
          onFocus={binding.onFocus}
        />
        <FieldError id={id} error={binding.error} />
      </div>
    );
  },

  switch: ({ field, binding, id, disabled, showOptionalLabel }) => {
    const validation = validationIds(id, binding.error);
    return (
      <div className="ui-auto-form__control-shell">
        <SwitchControl
          id={id}
          name={binding.name}
          label={labelOf(field)}
          description={field.description}
          status={optionalRequirementOf(field, showOptionalLabel)}
          aria-describedby={validation.describedBy}
          aria-invalid={validation.invalid}
          aria-required={isRequired(field) || undefined}
          required={isRequired(field)}
          disabled={disabled}
          checked={asBoolean(binding.value)}
          onChange={(checked) => binding.onChange(checked)}
          onBlur={binding.onBlur}
          onFocus={binding.onFocus}
        />
        <FieldError id={id} error={binding.error} />
      </div>
    );
  },

  date: ({ field, binding, id, disabled, showOptionalLabel }) => (
    <DateField
      id={id}
      label={labelOf(field)}
      description={field.description}
      error={binding.error}
      status={optionalRequirementOf(field, showOptionalLabel)}
      required={isRequired(field)}
      disabled={disabled}
      name={binding.name}
      value={asString(binding.value)}
      onChange={(value) => binding.onChange(value)}
      onBlur={binding.onBlur}
      onFocus={binding.onFocus}
    />
  ),

  tags: (ctx) => <AutoTagsControl {...ctx} />,

  file: ({ field, binding, id, disabled, showOptionalLabel }) => {
    const validation = validationIds(id, binding.error);
    const optional = optionalRequirementOf(field, showOptionalLabel);
    return (
      <div className="ui-auto-form__control-shell">
        {optional ? <div className="ui-auto-form__requirement-row">{optional}</div> : null}
        <FileUploadControl
          id={id}
          name={binding.name}
          label={labelOf(field)}
          description={field.description}
          aria-describedby={validation.describedBy}
          aria-invalid={validation.invalid}
          aria-required={isRequired(field) || undefined}
          required={isRequired(field)}
          disabled={disabled}
          onFilesSelected={(files) => binding.onChange(files)}
        />
        <FieldError id={id} error={binding.error} />
      </div>
    );
  },
};

/**
 * Merge caller overrides onto the built-in registry. Registering (or replacing)
 * a type is a data change — AutoForm reads the resolved renderer, so no AutoForm
 * edit is needed to support a new control.
 */
export function createControlRegistry(overrides?: ControlRegistry): Record<FieldType, AutoFormControlRenderer> {
  if (!overrides) return defaultControlRegistry;
  return { ...defaultControlRegistry, ...overrides };
}

/** Resolve the renderer for a field type, falling back to the text control. */
export function resolveControlRenderer(
  registry: Record<FieldType, AutoFormControlRenderer>,
  type: FieldType,
): AutoFormControlRenderer {
  return registry[type] ?? registry.text;
}
