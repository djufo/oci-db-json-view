import { FormSubmissionError, type FieldErrors } from "../core/orchestration/forms";
import { type FormFieldSpec, type FormSpec, humanizeName } from "../core/config";

export type ValidationRuleKey =
  | "required"
  | "number"
  | "min"
  | "max"
  | "minLength"
  | "maxLength"
  | "email"
  | "url"
  | "server"
  | "form";

export interface ValidationMessageContext {
  rule: ValidationRuleKey;
  name: string;
  label: string;
  value: unknown;
  constraint?: number | string;
}

export type ValidationMessageFormatter = (context: ValidationMessageContext) => string;
export type ValidationMessageValue = string | ValidationMessageFormatter;
export type ValidationMessageMap = Partial<Record<ValidationRuleKey, ValidationMessageValue>>;
export type FieldValidationMessageMap = ValidationMessageMap;

export interface MessageAwareFormFieldSpec extends FormFieldSpec {
  readonly messages?: FieldValidationMessageMap;
  readonly validation?: FormFieldSpec["validation"] & {
    readonly messages?: FieldValidationMessageMap;
  };
}

export interface FormSpecValidationOptions {
  /** Rule-keyed dictionary; swap this to localize all default FormSpec messages. */
  readonly messages?: ValidationMessageMap;
  /** Imperative resolver for products that keep messages outside the spec. */
  readonly formatMessage?: ValidationMessageFormatter;
  /** Per-field overrides. These win over the dictionary/default messages. */
  readonly fieldMessages?: Record<string, FieldValidationMessageMap>;
}

export interface ServerValidationPayload {
  readonly fieldErrors?: FieldErrors;
  readonly formError?: string;
  readonly message?: string;
}

export const defaultValidationMessages: Record<ValidationRuleKey, ValidationMessageFormatter> = {
  required: ({ label }) => `${label} is required.`,
  number: ({ label }) => `${label} must be a number.`,
  min: ({ label, constraint }) => `${label} must be at least ${constraint}.`,
  max: ({ label, constraint }) => `${label} must be at most ${constraint}.`,
  minLength: ({ label, constraint }) => `${label} must be at least ${constraint} characters.`,
  maxLength: ({ label, constraint }) => `${label} must be at most ${constraint} characters.`,
  email: ({ label }) => `${label} must be a valid email.`,
  url: ({ label }) => `${label} must be a valid URL.`,
  server: ({ label }) => `${label} was rejected by the server.`,
  form: () => "Submission failed.",
};

export function labelForField(field: Pick<FormFieldSpec, "label" | "name">): string {
  return field.label || humanizeName(field.name);
}

export function messageOverridesForField(
  field: FormFieldSpec,
  options?: FormSpecValidationOptions,
): FieldValidationMessageMap | undefined {
  const messageAware = field as MessageAwareFormFieldSpec;
  return {
    ...(options?.fieldMessages?.[field.name] ?? {}),
    ...(messageAware.validation?.messages ?? {}),
    ...(messageAware.messages ?? {}),
  };
}

export function resolveValidationMessage(
  rule: ValidationRuleKey,
  context: Omit<ValidationMessageContext, "rule">,
  options: FormSpecValidationOptions | undefined,
  fieldMessages: FieldValidationMessageMap | undefined,
): string {
  const fullContext: ValidationMessageContext = { ...context, rule };
  const specific = fieldMessages?.[rule];
  if (specific !== undefined) return renderMessage(specific, fullContext);

  const dictionary = options?.messages?.[rule];
  if (dictionary !== undefined) return renderMessage(dictionary, fullContext);

  if (options?.formatMessage) return options.formatMessage(fullContext);
  return defaultValidationMessages[rule](fullContext);
}

export function createServerValidationError(payload: ServerValidationPayload): FormSubmissionError {
  return new FormSubmissionError({
    fieldErrors: payload.fieldErrors,
    formError: payload.formError,
    message: payload.message,
  });
}

export function createFormSpecError(
  field: FormFieldSpec,
  rule: ValidationRuleKey,
  value: unknown,
  options?: FormSpecValidationOptions,
  constraint?: number | string,
): string {
  return resolveValidationMessage(
    rule,
    {
      name: field.name,
      label: labelForField(field),
      value,
      constraint,
    },
    options,
    messageOverridesForField(field, options),
  );
}

export function errorCountLabel(count: number): string {
  return count === 1 ? "1 validation issue" : `${count} validation issues`;
}

function renderMessage(message: ValidationMessageValue, context: ValidationMessageContext): string {
  return typeof message === "function" ? message(context) : message;
}

export type { FieldErrors, FormSpec };
