import { describe, expect, it, vi } from "vitest";

import { createFormStore, FormSubmissionError, type Resolver } from "../../core/orchestration/forms";
import {
  buildStepViews,
  goBack,
  goNext,
  goTo,
  initWizard,
  isStepSliceValid,
  resolvePath,
  submitWizard,
  validateStepFields,
} from "./machine";
import type { WizardState, WizardStep } from "./types";

// A 3-field wizard value map. Each field is "required" (non-empty string).
type Values = { a: string; b: string; c: string; plan: string };

/** Required-non-empty resolver over the four fields. */
const requiredResolver: Resolver<Values> = (values) => {
  const errors: Record<string, string> = {};
  for (const key of ["a", "b", "c"] as const) {
    if (!values[key]) errors[key] = `${key} is required`;
  }
  return { values, errors };
};

function makeStore() {
  return createFormStore<Values>({ resolver: requiredResolver, mode: "onChange" });
}

const linearSteps: WizardStep<Values>[] = [
  { id: "s1", label: "Step 1", fields: ["a"] },
  { id: "s2", label: "Step 2", fields: ["b"] },
  { id: "s3", label: "Step 3", fields: ["c"] },
];

describe("initWizard", () => {
  it("starts on the first step and marks it visited", () => {
    const state = initWizard(linearSteps);
    expect(state.currentId).toBe("s1");
    expect(state.visited).toEqual(["s1"]);
  });

  it("returns an empty state for no steps", () => {
    const state = initWizard<Values>([]);
    expect(state.currentId).toBe("");
    expect(state.visited).toEqual([]);
  });
});

describe("goNext — per-step gating", () => {
  it("blocks Next until the active step's slice validates", async () => {
    const store = makeStore();
    let state = initWizard(linearSteps);

    // Step 1 field `a` is empty → Next is blocked and the error surfaces.
    const blocked = await goNext(store, linearSteps, state);
    expect(blocked.advanced).toBe(false);
    expect(blocked.valid).toBe(false);
    expect(blocked.state.currentId).toBe("s1");
    expect(store.getError("a")).toBe("a is required");
    // future steps must NOT have leaked errors from the whole-form resolver
    expect(store.getError("b")).toBeUndefined();
    expect(store.getError("c")).toBeUndefined();

    // Fill `a` → Next now advances and clears the error.
    store.setValue("a", "alpha");
    const ok = await goNext(store, linearSteps, state);
    expect(ok.advanced).toBe(true);
    expect(ok.state.currentId).toBe("s2");
    expect(ok.state.visited).toEqual(["s1", "s2"]);
    expect(store.getError("a")).toBeUndefined();
    state = ok.state;
  });

  it("does not advance past the last step", async () => {
    const store = makeStore();
    store.setValue("a", "x");
    store.setValue("b", "y");
    store.setValue("c", "z");
    let state: WizardState = initWizard(linearSteps);
    state = (await goNext(store, linearSteps, state)).state; // -> s2
    state = (await goNext(store, linearSteps, state)).state; // -> s3
    expect(state.currentId).toBe("s3");
    const last = await goNext(store, linearSteps, state); // no-op, but valid
    expect(last.advanced).toBe(false);
    expect(last.valid).toBe(true);
    expect(last.state.currentId).toBe("s3");
  });
});

describe("goBack — values preserved", () => {
  it("returns to the previous step with entered data intact", async () => {
    const store = makeStore();
    let state = initWizard(linearSteps);
    store.setValue("a", "alpha");
    state = (await goNext(store, linearSteps, state)).state; // -> s2
    store.setValue("b", "bravo");

    const back = goBack(store, linearSteps, state);
    expect(back.moved).toBe(true);
    expect(back.state.currentId).toBe("s1");
    // both values survive the backward navigation
    expect(store.getValue("a")).toBe("alpha");
    expect(store.getValue("b")).toBe("bravo");
  });

  it("is a no-op on the first step", () => {
    const store = makeStore();
    const state = initWizard(linearSteps);
    const back = goBack(store, linearSteps, state);
    expect(back.moved).toBe(false);
    expect(back.state.currentId).toBe("s1");
  });
});

describe("goTo — visited navigation keeps values", () => {
  it("jumps to an already-visited step and preserves values", async () => {
    const store = makeStore();
    let state = initWizard(linearSteps);
    store.setValue("a", "alpha");
    state = (await goNext(store, linearSteps, state)).state; // -> s2 (visits s2)
    store.setValue("b", "bravo");
    state = (await goNext(store, linearSteps, state)).state; // -> s3

    const toS1 = await goTo(store, linearSteps, state, "s1");
    expect(toS1.moved).toBe(true);
    expect(toS1.state.currentId).toBe("s1");
    expect(store.getValue("a")).toBe("alpha");

    const toS3 = await goTo(store, linearSteps, toS1.state, "s3");
    expect(toS3.moved).toBe(true);
    expect(toS3.state.currentId).toBe("s3");
    expect(store.getValue("b")).toBe("bravo");
  });

  it("refuses to jump forward to an unvisited step (no gate bypass)", async () => {
    const store = makeStore();
    const state = initWizard(linearSteps);
    // s3 not visited, and `a` invalid → cannot leap ahead
    const leap = await goTo(store, linearSteps, state, "s3");
    expect(leap.moved).toBe(false);
    expect(leap.state.currentId).toBe("s1");
  });

  it("reaches the immediate next step through the gate when valid", async () => {
    const store = makeStore();
    const state = initWizard(linearSteps);
    store.setValue("a", "alpha");
    const step = await goTo(store, linearSteps, state, "s2");
    expect(step.moved).toBe(true);
    expect(step.state.currentId).toBe("s2");
  });
});

describe("validateStepFields", () => {
  it("is trivially valid for a step with no fields", async () => {
    const store = makeStore();
    expect(await validateStepFields(store, undefined)).toBe(true);
    expect(await validateStepFields(store, [])).toBe(true);
  });

  it("only surfaces errors for the requested slice", async () => {
    const store = makeStore();
    expect(await validateStepFields(store, ["a"])).toBe(false);
    expect(store.getError("a")).toBe("a is required");
    expect(store.getError("b")).toBeUndefined();
  });
});

describe("resolvePath — branching (story B)", () => {
  const branchingSteps: WizardStep<Values>[] = [
    {
      id: "plan",
      fields: ["plan"],
      next: (v) => (v.plan === "pro" ? "pro" : "basic"),
    },
    { id: "basic", fields: ["a"], next: () => "done" },
    { id: "pro", fields: ["b"], next: () => "done" },
    { id: "done", fields: ["c"] },
  ];

  it("follows the basic branch and omits the skipped pro step", () => {
    const store = makeStore();
    store.setValue("plan", "free");
    const path = resolvePath(branchingSteps, store.getValues()).map((s) => s.id);
    expect(path).toEqual(["plan", "basic", "done"]);
    expect(path).not.toContain("pro");
  });

  it("re-routes to the pro branch when the value changes", () => {
    const store = makeStore();
    store.setValue("plan", "pro");
    const path = resolvePath(branchingSteps, store.getValues()).map((s) => s.id);
    expect(path).toEqual(["plan", "pro", "done"]);
    expect(path).not.toContain("basic");
  });

  it("goNext advances along the resolved branch", async () => {
    const store = makeStore();
    store.setValue("plan", "pro");
    store.setValue("b", "bravo");
    const state = initWizard(branchingSteps);
    const stepped = await goNext(store, branchingSteps, state);
    expect(stepped.advanced).toBe(true);
    expect(stepped.state.currentId).toBe("pro"); // skipped `basic`
  });
});

describe("buildStepViews — stepper view models", () => {
  it("marks complete / current / upcoming and error states", async () => {
    const store = makeStore();
    let state = initWizard(linearSteps);
    store.setValue("a", "alpha");
    state = (await goNext(store, linearSteps, state)).state; // now on s2, s1 complete

    const views = buildStepViews(store, linearSteps, state);
    expect(views.map((v) => v.status)).toEqual(["complete", "current", "upcoming"]);
    expect(views[0].disabled).toBe(false); // visited → clickable
    expect(views[1].disabled).toBe(true); // current → not clickable
    expect(views[2].disabled).toBe(true); // upcoming → not clickable
  });

  it("flags a visited step whose slice went invalid as error", async () => {
    const store = makeStore();
    let state = initWizard(linearSteps);
    store.setValue("a", "alpha");
    state = (await goNext(store, linearSteps, state)).state; // s1 complete, on s2
    // invalidate s1's field after leaving it
    store.setValue("a", "");
    await validateStepFields(store, ["a"]);
    expect(isStepSliceValid(store, linearSteps[0])).toBe(false);

    const views = buildStepViews(store, linearSteps, state);
    expect(views[0].status).toBe("error");
    expect(views[0].hasError).toBe(true);
  });
});

describe("submitWizard — review aggregate submit", () => {
  type BranchValues = { plan: string; basic: string; pro: string; done: string };

  const branchResolver: Resolver<BranchValues> = (values) => {
    const errors: Record<string, string> = {};
    for (const key of ["plan", "basic", "pro", "done"] as const) {
      if (!values[key]) errors[key] = `${key} is required`;
    }
    return { values, errors };
  };

  const branchSteps: WizardStep<BranchValues>[] = [
    {
      id: "plan",
      fields: ["plan"],
      next: (values) => (values.plan === "pro" ? "pro" : "basic"),
    },
    { id: "basic", fields: ["basic"], next: () => "done" },
    { id: "pro", fields: ["pro"], next: () => "done" },
    { id: "done", fields: ["done"] },
    { id: "review", label: "Review" },
  ];

  function makeBranchStore(values: Partial<BranchValues>) {
    return createFormStore<BranchValues>({
      resolver: branchResolver,
      defaultValues: { plan: "", basic: "", pro: "", done: "", ...values },
      mode: "onSubmit",
    });
  }

  it("validates non-skipped steps and submits one merged payload", async () => {
    const store = makeBranchStore({ plan: "basic", basic: "ready", pro: "", done: "confirmed" });
    const state: WizardState = { currentId: "review", visited: ["plan", "basic", "done", "review"] };
    const submit = vi.fn();

    const result = await submitWizard(store, branchSteps, state, submit);

    expect(result.submitted).toBe(true);
    expect(result.valid).toBe(true);
    expect(store.getFormState().submitCount).toBe(1);
    expect(submit).toHaveBeenCalledTimes(1);
    expect(submit).toHaveBeenCalledWith({ plan: "basic", basic: "ready", done: "confirmed" });
    expect(store.getError("pro")).toBeUndefined();
  });

  it("routes validation errors to the first owning step and does not submit", async () => {
    const store = makeBranchStore({ plan: "basic", basic: "", pro: "", done: "" });
    const state: WizardState = { currentId: "review", visited: ["plan", "basic", "done", "review"] };
    const submit = vi.fn();
    const invalid = vi.fn();

    const result = await submitWizard(store, branchSteps, state, submit, invalid);

    expect(result.submitted).toBe(false);
    expect(result.valid).toBe(false);
    expect(result.routedTo).toBe("basic");
    expect(result.state.currentId).toBe("basic");
    expect(store.getError("basic")).toBe("basic is required");
    expect(store.getError("done")).toBe("done is required");
    expect(store.getError("pro")).toBeUndefined();
    expect(store.getPendingFocus()).toBe("basic");
    expect(submit).not.toHaveBeenCalled();
    expect(invalid).toHaveBeenCalledWith({ basic: "basic is required", done: "done is required" });
  });

  it("reconciles server field errors and routes back to the owning step", async () => {
    const store = makeBranchStore({ plan: "basic", basic: "ready", pro: "", done: "confirmed" });
    const state: WizardState = { currentId: "review", visited: ["plan", "basic", "done", "review"] };

    const result = await submitWizard(store, branchSteps, state, async () => {
      throw new FormSubmissionError({
        fieldErrors: { done: "Server rejected the confirmation." },
        formError: "Review failed.",
      });
    });

    expect(result.submitted).toBe(false);
    expect(result.valid).toBe(true);
    expect(result.routedTo).toBe("done");
    expect(result.state.currentId).toBe("done");
    expect(store.getError("done")).toBe("Server rejected the confirmation.");
    expect(store.getFormState().submitError).toBe("Review failed.");
    expect(store.getPendingFocus()).toBe("done");
  });
});
