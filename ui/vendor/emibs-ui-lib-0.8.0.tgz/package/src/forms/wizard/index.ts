// src/forms/wizard — public entry for the multi-step form wizard (epic
// issue-555). The pure controller (machine.ts) drives navigation + per-step
// gating over the headless form engine; useFormWizard binds it to React and
// FormWizard/WizardStepper render the flow and its progress.
//
// Presentation-free logic (types, machine) is separated from the React binding
// and the JSX so the controller is unit-testable against a bare form store.

export type {
  WizardStep,
  WizardState,
  WizardStepStatus,
  WizardStepView,
} from "./types";

export {
  initWizard,
  resolvePath,
  indexInPath,
  stepById,
  validateStepFields,
  isStepSliceValid,
  collectStepFields,
  firstErroredFieldForStep,
  firstErroredStepId,
  getWizardSubmitValues,
  validateWizardPathFields,
  submitWizard,
  goNext,
  goBack,
  goTo,
  stepStatus,
  buildStepViews,
} from "./machine";
export type { WizardSubmitResult } from "./machine";

export { useFormWizard } from "./useFormWizard";
export type { UseFormWizardOptions, UseFormWizardReturn } from "./useFormWizard";

export { WizardStepper } from "./WizardStepper";
export type { WizardStepperProps } from "./WizardStepper";

export { WizardReviewStep, buildWizardReviewGroups } from "./WizardReviewStep";
export type {
  WizardReviewGroup,
  WizardReviewItem,
  WizardReviewStepProps,
} from "./WizardReviewStep";

export { wizardStepsFromFormSpec } from "./formSpec";
export type { WizardStepsFromFormSpecOptions } from "./formSpec";

export { FormWizard } from "./FormWizard";
export type { FormWizardProps, WizardStepRenderProps } from "./FormWizard";
