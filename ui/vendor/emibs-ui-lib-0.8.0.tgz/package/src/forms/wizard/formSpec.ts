// src/forms/wizard — derive wizard steps from the flat AutoForm FormSpec.
//
// The helper mirrors AutoForm's section ordering: fields remain the source of
// truth, sections become steps, and the optional review step is appended after
// the editable sections.

import {
  humanizeName,
  type FormFieldSpec,
  type FormSectionSpec,
  type FormSpec,
} from "../../core/config";
import type { WizardStep } from "./types";

const DEFAULT_SECTION_ID = "__wizard-default";

export interface WizardStepsFromFormSpecOptions<TValues extends object> {
  readonly reviewStep?: WizardStep<TValues> | false;
}

function orderedFields(fields: readonly FormFieldSpec[]): FormFieldSpec[] {
  return fields
    .map((field, index) => ({ field, index }))
    .sort((a, b) => (a.field.order ?? a.index) - (b.field.order ?? b.index) || a.index - b.index)
    .map((entry) => entry.field);
}

function orderedSections(sections: readonly FormSectionSpec[] | undefined): FormSectionSpec[] {
  return [...(sections ?? [])].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
}

function uniqueStepId<TValues extends object>(steps: readonly WizardStep<TValues>[], requested: string): string {
  if (!steps.some((step) => step.id === requested)) return requested;
  let index = 2;
  while (steps.some((step) => step.id === `${requested}-${index}`)) index += 1;
  return `${requested}-${index}`;
}

export function wizardStepsFromFormSpec<TValues extends object>(
  spec: FormSpec<TValues>,
  options: WizardStepsFromFormSpecOptions<TValues> = {},
): WizardStep<TValues>[] {
  const declared = new Map<string, FormSectionSpec>();
  for (const section of spec.sections ?? []) declared.set(section.id, section);

  const buckets = new Map<string, FormFieldSpec[]>();
  for (const field of orderedFields(spec.fields)) {
    const sectionId = field.section && declared.has(field.section) ? field.section : DEFAULT_SECTION_ID;
    const bucket = buckets.get(sectionId) ?? [];
    bucket.push(field);
    buckets.set(sectionId, bucket);
  }

  const steps: WizardStep<TValues>[] = [];
  for (const section of orderedSections(spec.sections)) {
    const fields = buckets.get(section.id);
    if (!fields || fields.length === 0) continue;
    steps.push({
      id: section.id,
      label: section.title ?? humanizeName(section.id),
      description: section.description,
      fields: fields.map((field) => field.name as keyof TValues & string),
      fieldLabels: Object.fromEntries(
        fields.map((field) => [field.name, field.label ?? humanizeName(field.name)]),
      ) as Partial<Record<keyof TValues & string, string>>,
    });
  }

  const defaultFields = buckets.get(DEFAULT_SECTION_ID);
  if (defaultFields && defaultFields.length > 0) {
    steps.push({
      id: uniqueStepId(steps, "details"),
      label: "Details",
      fields: defaultFields.map((field) => field.name as keyof TValues & string),
      fieldLabels: Object.fromEntries(
        defaultFields.map((field) => [field.name, field.label ?? humanizeName(field.name)]),
      ) as Partial<Record<keyof TValues & string, string>>,
    });
  }

  const reviewStep =
    options.reviewStep === false
      ? undefined
      : options.reviewStep ?? {
          id: uniqueStepId(steps, "review"),
          label: "Review",
          description: "Confirm",
        };
  if (reviewStep) steps.push(reviewStep);
  return steps;
}
