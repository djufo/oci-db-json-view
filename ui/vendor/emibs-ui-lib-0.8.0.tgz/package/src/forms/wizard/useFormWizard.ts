// src/forms/wizard — React binding for the pure wizard machine.
//
// Hook only, no JSX. Holds the WizardState in component state and drives it via
// the pure transitions in machine.ts. It subscribes to the form store through
// the engine's selector so the resolved path and per-step statuses recompute
// when values or errors change (branching + error display), while navigation
// itself is local component state. Re-renders stay minimal: the store
// subscription bails out unless the path/status signature actually changes.

import { useCallback, useMemo, useRef, useState } from "react";

import { useFormSelector, type UseFormReturn } from "../../core/orchestration/forms";
import {
  buildStepViews,
  goBack,
  goNext,
  goTo,
  indexInPath,
  initWizard,
  isStepSliceValid,
  resolvePath,
  stepById,
  submitWizard,
  validateStepFields,
  type WizardSubmitResult,
} from "./machine";
import type { SubmitErrorHandler, SubmitHandler } from "../../core/orchestration/forms";
import type { WizardState, WizardStep, WizardStepView } from "./types";

export interface UseFormWizardOptions<TValues extends object> {
  /** ordered step definitions; each owns a subset of the form's fields */
  steps: readonly WizardStep<TValues>[];
}

export interface UseFormWizardReturn<TValues extends object> {
  /** the resolved path of steps for the current values (skipped steps absent) */
  readonly steps: readonly WizardStep<TValues>[];
  /** the active step, or undefined for an empty wizard */
  readonly currentStep: WizardStep<TValues> | undefined;
  /** 0-based index of the active step within the resolved path */
  readonly currentIndex: number;
  readonly isFirst: boolean;
  readonly isLast: boolean;
  /** ids reached at least once, in first-visit order */
  readonly visited: readonly string[];
  /** stepper view models for the resolved path */
  readonly stepViews: WizardStepView[];
  /** validate the active step's slice, advancing if valid; resolves to whether
   *  it advanced */
  next(): Promise<boolean>;
  /** move to the previous step (never validates; values preserved) */
  back(): void;
  /** navigate to a step by id (visited/backward free; forward gated) */
  goTo(id: string): Promise<boolean>;
  /** validate the active (or a named) step's slice without navigating */
  validateStep(id?: string): Promise<boolean>;
  /** aggregate final submit for the resolved path, routing back to errored steps */
  submit(onValid: SubmitHandler<TValues>, onInvalid?: SubmitErrorHandler): Promise<WizardSubmitResult>;
  /** synchronous check: does the active step's slice currently hold no errors */
  readonly isCurrentStepValid: boolean;
}

/**
 * Bind a multi-step wizard to a form engine. Pass the engine from useForm() and
 * the step definitions; the returned controller gates Next on the active step's
 * fields, preserves values across Back/goTo, and exposes stepper view models.
 */
export function useFormWizard<TValues extends object>(
  form: UseFormReturn<TValues>,
  options: UseFormWizardOptions<TValues>,
): UseFormWizardReturn<TValues> {
  const { steps } = options;
  const { store } = form;
  const [state, setState] = useState<WizardState>(() => initWizard(steps));

  // A signature that changes when the resolved path or any step's error state
  // changes, so the store subscription re-renders only on a meaningful change.
  const stepsRef = useRef(steps);
  stepsRef.current = steps;
  const signatureSelector = useCallback(() => {
    const path = resolvePath(stepsRef.current, store.getValues());
    return path
      .map((s) => `${s.id}:${isStepSliceValid(store, s) ? "1" : "0"}`)
      .join(">");
  }, [store]);
  const signature = useFormSelector(form, signatureSelector, Object.is);

  const view = useMemo(() => {
    const path = resolvePath(steps, store.getValues());
    const currentIndex = indexInPath(path, state.currentId);
    const currentStep = currentIndex >= 0 ? path[currentIndex] : stepById(steps, state.currentId);
    return {
      path,
      currentIndex,
      currentStep,
      stepViews: buildStepViews(store, steps, state),
      isCurrentStepValid: isStepSliceValid(store, currentStep),
    };
    // `signature` is an intentional recompute trigger for value/error changes.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [steps, store, state, signature]);

  const next = useCallback(async () => {
    const result = await goNext(store, stepsRef.current, state);
    if (result.advanced) setState(result.state);
    return result.advanced;
  }, [store, state]);

  const back = useCallback(() => {
    const result = goBack(store, stepsRef.current, state);
    if (result.moved) setState(result.state);
  }, [store, state]);

  const goToStep = useCallback(
    async (id: string) => {
      const result = await goTo(store, stepsRef.current, state, id);
      if (result.moved) setState(result.state);
      return result.moved;
    },
    [store, state],
  );

  const validateStep = useCallback(
    (id?: string) => {
      const step = id ? stepById(stepsRef.current, id) : view.currentStep;
      return validateStepFields(store, step?.fields);
    },
    [store, view.currentStep],
  );

  const submit = useCallback(
    async (onValid: SubmitHandler<TValues>, onInvalid?: SubmitErrorHandler) => {
      const result = await submitWizard(store, stepsRef.current, state, onValid, onInvalid);
      if (result.state !== state) setState(result.state);
      return result;
    },
    [store, state],
  );

  return {
    steps: view.path,
    currentStep: view.currentStep,
    currentIndex: view.currentIndex,
    isFirst: view.currentIndex <= 0,
    isLast: view.currentIndex === view.path.length - 1,
    visited: state.visited,
    stepViews: view.stepViews,
    next,
    back,
    goTo: goToStep,
    validateStep,
    submit,
    isCurrentStepValid: view.isCurrentStepValid,
  };
}
