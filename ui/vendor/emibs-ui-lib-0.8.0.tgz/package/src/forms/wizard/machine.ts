// src/forms/wizard — the pure wizard state machine.
//
// Framework-agnostic navigation + gating logic over the headless form store.
// No React and no JSX: every function here takes explicit arguments and returns
// plain data, so the whole controller is unit-testable against a bare
// createFormStore() (the React hook in useFormWizard.ts is a thin wrapper).
//
// Gating contract: a step is validated by validating ONLY its own field slice
// through the store's per-field validator, which surfaces errors for those
// fields (and any already-errored field) without leaking NEW errors onto
// still-unvisited future steps. Values are never reset — Back/goTo simply move
// currentId; the entered values persist in the shared store.

import {
  extractServerValidationErrors,
  ROOT_ERROR_KEY,
  type FieldErrors,
  type FormStore,
  type SubmitErrorHandler,
  type SubmitHandler,
} from "../../core/orchestration/forms";
import { getPath, hasPath, normalizePath, setPath } from "../../core/orchestration/forms/path";
import type { WizardState, WizardStep, WizardStepStatus, WizardStepView } from "./types";

export interface WizardSubmitResult {
  /** true when validation passed and the submit handler completed */
  readonly submitted: boolean;
  /** true when current-path validation passed before the submit handler ran */
  readonly valid: boolean;
  /** navigation state after any error-to-step routing */
  readonly state: WizardState;
  /** first resolved-path step that owns a reconciled field error */
  readonly routedTo?: string;
  /** field errors present after validation or server-error reconciliation */
  readonly errors: FieldErrors;
}

/** Find a step by id, or undefined. */
export function stepById<T extends object>(
  steps: readonly WizardStep<T>[],
  id: string,
): WizardStep<T> | undefined {
  return steps.find((s) => s.id === id);
}

/**
 * Resolve the ordered path of steps for the given values. Starting from the
 * first step, each step's `next(values)` (when present and pointing at a real,
 * not-yet-visited step) chooses the successor; otherwise the path falls through
 * to the next declared step. Steps not reached this way are skipped (absent from
 * the path). A `seen` guard makes cycles terminate.
 *
 * Convergence note: a fork step routes to a branch head via `next`; each branch
 * tail must itself route forward (its own `next`) to the shared continuation, or
 * linear fallthrough would land on the sibling branch. Sibling branches are only
 * skipped because the tail's `next` jumps over them.
 */
export function resolvePath<T extends object>(
  steps: readonly WizardStep<T>[],
  values: T,
): WizardStep<T>[] {
  if (steps.length === 0) return [];
  const path: WizardStep<T>[] = [];
  const seen = new Set<string>();
  let current: WizardStep<T> | undefined = steps[0];
  while (current && !seen.has(current.id)) {
    seen.add(current.id);
    path.push(current);
    let nextId: string | undefined;
    if (current.next) nextId = current.next(values);
    const nextStep: WizardStep<T> | undefined =
      nextId !== undefined
        ? stepById(steps, nextId)
        : steps[steps.indexOf(current) + 1];
    current = nextStep;
  }
  return path;
}

/** Index of a step id within a resolved path, or -1. */
export function indexInPath<T extends object>(path: readonly WizardStep<T>[], id: string): number {
  return path.findIndex((s) => s.id === id);
}

/** Initial navigation state: first step active and marked visited. */
export function initWizard<T extends object>(steps: readonly WizardStep<T>[]): WizardState {
  const firstId = steps[0]?.id ?? "";
  return { currentId: firstId, visited: firstId ? [firstId] : [] };
}

/** Append an id to the visited list if not already present (order preserved). */
function withVisited(state: WizardState, id: string): WizardState {
  if (state.visited.includes(id)) {
    return state.currentId === id ? state : { ...state, currentId: id };
  }
  return { currentId: id, visited: [...state.visited, id] };
}

/** Unique field names owned by the resolved path, in step/field order. */
export function collectStepFields<T extends object>(
  steps: readonly WizardStep<T>[],
): (keyof T & string)[] {
  const seen = new Set<string>();
  const fields: (keyof T & string)[] = [];
  for (const step of steps) {
    for (const field of step.fields ?? []) {
      if (seen.has(field)) continue;
      seen.add(field);
      fields.push(field);
    }
  }
  return fields;
}

function fieldOwnsError(field: string, errorName: string): boolean {
  if (errorName === ROOT_ERROR_KEY) return false;
  const normalizedField = normalizePath(field);
  const normalizedError = normalizePath(errorName);
  return normalizedError === normalizedField || normalizedError.startsWith(`${normalizedField}.`);
}

/** First field error owned by a step, respecting the step's declared field order. */
export function firstErroredFieldForStep<T extends object>(
  step: WizardStep<T>,
  errors: FieldErrors,
): string | undefined {
  for (const field of step.fields ?? []) {
    const exact = errors[normalizePath(field)];
    if (exact !== undefined) return normalizePath(field);
    const nested = Object.keys(errors).find((name) => fieldOwnsError(field, name));
    if (nested) return nested;
  }
  return undefined;
}

/** First resolved-path step that owns a field error. Root/form errors do not route. */
export function firstErroredStepId<T extends object>(
  steps: readonly WizardStep<T>[],
  errors: FieldErrors,
): string | undefined {
  for (const step of steps) {
    if (firstErroredFieldForStep(step, errors)) return step.id;
  }
  return undefined;
}

function clearErrorsOutsideFields<T extends object>(
  store: FormStore<T>,
  fields: readonly (keyof T & string)[],
): void {
  const names = Object.keys(store.getErrors());
  if (names.length === 0) return;
  for (const name of names) {
    if (name === ROOT_ERROR_KEY) continue;
    if (!fields.some((field) => fieldOwnsError(field, name))) store.clearErrors(name);
  }
}

/**
 * Values merged from the resolved wizard path. When steps declare field
 * ownership, skipped-step fields are omitted even if they exist in defaults.
 * If no step declares fields, fall back to the engine's full submit payload.
 */
export function getWizardSubmitValues<T extends object>(
  store: FormStore<T>,
  steps: readonly WizardStep<T>[],
): Partial<T> {
  const fields = collectStepFields(steps);
  const submitValues = store.getSubmitValues();
  if (fields.length === 0) return submitValues;
  let out = {} as Partial<T>;
  for (const field of fields) {
    if (!hasPath(submitValues, field)) continue;
    out = setPath(out, field, getPath(submitValues, field));
  }
  return out;
}

/**
 * Validate every field owned by the resolved path, surfacing errors on all
 * non-skipped steps without leaking new errors onto skipped branches.
 */
export async function validateWizardPathFields<T extends object>(
  store: FormStore<T>,
  steps: readonly WizardStep<T>[],
): Promise<boolean> {
  const fields = collectStepFields(steps);
  if (fields.length === 0) return store.validate();
  clearErrorsOutsideFields(store, fields);
  let valid = true;
  for (const step of steps) {
    const stepValid = await validateStepFields(store, step.fields);
    valid = stepValid && valid;
  }
  return valid;
}

/**
 * Aggregate final wizard submit. It validates the current resolved path, submits
 * exactly one merged payload through the form store lifecycle flags, reconciles
 * server field/form errors, and returns a state routed to the first step that
 * owns an error.
 */
export async function submitWizard<T extends object>(
  store: FormStore<T>,
  steps: readonly WizardStep<T>[],
  state: WizardState,
  onValid: SubmitHandler<T>,
  onInvalid?: SubmitErrorHandler,
): Promise<WizardSubmitResult> {
  const path = resolvePath(steps, store.getValues());
  store.countSubmit();
  store.setSubmitError(undefined);
  store.setSubmitting(true);

  const valid = await validateWizardPathFields(store, path);
  if (!valid) {
    store.setSubmitting(false);
    const errors = store.getErrors();
    const routedTo = firstErroredStepId(path, errors);
    const focus = routedTo ? firstErroredFieldForStep(stepById(path, routedTo)!, errors) : undefined;
    if (focus) store.setFocus(focus);
    onInvalid?.(errors);
    return {
      submitted: false,
      valid: false,
      state: routedTo ? withVisited(state, routedTo) : state,
      routedTo,
      errors,
    };
  }

  try {
    await onValid(getWizardSubmitValues(store, path) as T);
    store.clearErrors();
    store.setSubmitting(false);
    return { submitted: true, valid: true, state, errors: {} };
  } catch (thrown) {
    const server = extractServerValidationErrors(thrown);
    store.setSubmitting(false);
    if (server) {
      for (const [name, message] of Object.entries(server.fieldErrors ?? {})) {
        store.setError(name, message);
      }
      store.setSubmitError(
        server.formError ?? (Object.keys(server.fieldErrors ?? {}).length > 0 ? undefined : "Submission failed."),
      );
    } else {
      store.setSubmitError(thrown instanceof Error ? thrown.message : "Submission failed.");
    }
    const errors = store.getErrors();
    const routedTo = firstErroredStepId(path, errors);
    const focus = routedTo ? firstErroredFieldForStep(stepById(path, routedTo)!, errors) : undefined;
    if (focus) store.setFocus(focus);
    return {
      submitted: false,
      valid: true,
      state: routedTo ? withVisited(state, routedTo) : state,
      routedTo,
      errors,
    };
  }
}

/**
 * Validate a step's own field slice and report whether that slice is currently
 * valid. Runs the store's immediate per-field validation sequentially (so the
 * store's monotonic validation token never supersedes an earlier field), then
 * reads back each field's error. A step with no fields is trivially valid.
 */
export async function validateStepFields<T extends object>(
  store: FormStore<T>,
  fields: readonly (keyof T & string)[] | undefined,
): Promise<boolean> {
  if (!fields || fields.length === 0) return true;
  for (const name of fields) {
    await store.validateField(name, { immediate: true });
  }
  return fields.every((name) => store.getError(name) === undefined);
}

/** True when none of a step's gated fields currently holds an error. */
export function isStepSliceValid<T extends object>(
  store: FormStore<T>,
  step: WizardStep<T> | undefined,
): boolean {
  const fields = step?.fields;
  if (!fields || fields.length === 0) return true;
  return fields.every((name) => store.getError(name) === undefined);
}

/**
 * Advance to the next step on the resolved path, gated on the active step's
 * slice validating. Returns the (possibly unchanged) state plus whether it
 * advanced and whether the active step was valid. On the last step nothing
 * advances (submit is a separate concern — story C).
 */
export async function goNext<T extends object>(
  store: FormStore<T>,
  steps: readonly WizardStep<T>[],
  state: WizardState,
): Promise<{ state: WizardState; advanced: boolean; valid: boolean }> {
  const path = resolvePath(steps, store.getValues());
  const idx = indexInPath(path, state.currentId);
  const current = idx >= 0 ? path[idx] : stepById(steps, state.currentId);
  const valid = await validateStepFields(store, current?.fields);
  if (!valid) return { state, advanced: false, valid: false };
  // Recompute the path AFTER validation — sanitized values may re-branch it.
  const nextPath = resolvePath(steps, store.getValues());
  const nextIdx = indexInPath(nextPath, state.currentId);
  const target = nextIdx >= 0 ? nextPath[nextIdx + 1] : undefined;
  if (!target) return { state, advanced: false, valid: true };
  return { state: withVisited(state, target.id), advanced: true, valid: true };
}

/** Move to the previous step on the resolved path. Never validates; values are
 *  preserved. No-op on the first step. */
export function goBack<T extends object>(
  store: FormStore<T>,
  steps: readonly WizardStep<T>[],
  state: WizardState,
): { state: WizardState; moved: boolean } {
  const path = resolvePath(steps, store.getValues());
  const idx = indexInPath(path, state.currentId);
  if (idx <= 0) return { state, moved: false };
  const target = path[idx - 1];
  return { state: { ...state, currentId: target.id }, moved: true };
}

/**
 * Navigate directly to a step by id. Backward or to an already-visited step is
 * free and preserves values. Forward to an as-yet-unvisited step is gated:
 * it only proceeds when it is the immediate next step and the active slice
 * validates (delegating to goNext), so clicking a future step can never bypass
 * gating.
 */
export async function goTo<T extends object>(
  store: FormStore<T>,
  steps: readonly WizardStep<T>[],
  state: WizardState,
  targetId: string,
): Promise<{ state: WizardState; moved: boolean }> {
  if (targetId === state.currentId) return { state, moved: false };
  const target = stepById(steps, targetId);
  if (!target) return { state, moved: false };
  if (state.visited.includes(targetId)) {
    return { state: { ...state, currentId: targetId }, moved: true };
  }
  // Unvisited forward target: only reachable as the gated immediate next step.
  const result = await goNext(store, steps, state);
  if (result.advanced && result.state.currentId === targetId) {
    return { state: result.state, moved: true };
  }
  return { state, moved: false };
}

/** Derive a step's status within the current path. Current wins over error for
 *  the primary status; callers read `hasError` separately when they want to
 *  flag an errored-but-active step. */
export function stepStatus<T extends object>(
  store: FormStore<T>,
  step: WizardStep<T>,
  opts: { isCurrent: boolean; isVisited: boolean },
): WizardStepStatus {
  if (opts.isCurrent) return "current";
  if (opts.isVisited) return isStepSliceValid(store, step) ? "complete" : "error";
  return "upcoming";
}

/**
 * Build the stepper view models for the CURRENT resolved path. Skipped steps
 * are already absent (they are not on the path). Only visited, non-current
 * steps are enabled for click navigation.
 */
export function buildStepViews<T extends object>(
  store: FormStore<T>,
  steps: readonly WizardStep<T>[],
  state: WizardState,
): WizardStepView[] {
  const path = resolvePath(steps, store.getValues());
  return path.map((step, index) => {
    const isCurrent = step.id === state.currentId;
    const isVisited = state.visited.includes(step.id);
    const hasError = !isStepSliceValid(store, step);
    return {
      id: step.id,
      label: step.label ?? step.id,
      description: step.description,
      index,
      status: stepStatus(store, step, { isCurrent, isVisited }),
      isCurrent,
      isVisited,
      hasError: hasError && isVisited,
      disabled: !isVisited || isCurrent,
    };
  });
}
