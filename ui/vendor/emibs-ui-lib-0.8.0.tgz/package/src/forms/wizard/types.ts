// src/forms/wizard — multi-step form wizard (epic issue-555).
//
// Presentation-free type contracts for the wizard controller that sits on top
// of the headless form engine (core/orchestration/forms). A wizard drives a
// multi-step form where each step owns a subset of the form's fields; Next is
// gated on that subset validating and Back preserves every entered value (the
// values live in the shared form store, so navigation never resets them).

import type { FieldValues } from "../../core/orchestration/forms";

/** Visual/derived state of a step within the current path. */
export type WizardStepStatus = "complete" | "current" | "upcoming" | "error";

/**
 * One step of a wizard. A step declares the subset of form fields it gates
 * (`fields`); Next validates only those. `next` is the optional value-driven
 * branching resolver (story B): given the current form values it returns the id
 * of the step to advance to, or `undefined` to fall through to the linear next
 * step. Steps left off the resolved path are treated as skipped — absent from
 * the progress indicator and from final aggregation.
 */
export interface WizardStep<TValues extends object = FieldValues> {
  /** stable id used for navigation, keys, and branch targets */
  id: string;
  /** field names (subset of the form schema) this step owns and gates on Next */
  fields?: readonly (keyof TValues & string)[];
  /** human label for the progress stepper */
  label?: string;
  /** optional supporting copy for the stepper */
  description?: string;
  /** optional human labels for review-summary rows keyed by field name */
  fieldLabels?: Partial<Record<keyof TValues & string, string>>;
  /** value-driven branching: return the next step id, or undefined for linear */
  next?: (values: TValues) => string | undefined;
}

/** Immutable navigation state the controller advances between renders. */
export interface WizardState {
  /** id of the currently active step */
  readonly currentId: string;
  /** ids of every step reached at least once, in first-visit order */
  readonly visited: readonly string[];
}

/** Per-step view model the stepper renders (derived; never authored by hand). */
export interface WizardStepView {
  readonly id: string;
  readonly label: string;
  readonly description?: string;
  /** 0-based position within the CURRENT resolved path */
  readonly index: number;
  readonly status: WizardStepStatus;
  readonly isCurrent: boolean;
  readonly isVisited: boolean;
  /** a gated field of this step currently holds a validation error */
  readonly hasError: boolean;
  /** true when the step cannot be navigated to by clicking (not yet visited) */
  readonly disabled: boolean;
}
