// src/forms — public entry for the Forms feature (epic issue-550).
//
// One-stop surface: the React composition layer (<Form>/<FormProvider>,
// useField, <FormField>, <FormPanel>) plus the headless engine re-exported from
// core/orchestration/forms. Consumers import the Forms API from here; they do
// not reach into core internals.

export { Form, FormProvider, useFormContext, useOptionalFormContext } from "./Form";
export type { FormProps } from "./Form";
export { useField } from "./useField";
export type { FieldBinding, UseFieldOptions } from "./useField";
export { FormField } from "./FormField";
export type { FormFieldProps } from "./FormField";
export { ArrayField } from "./ArrayField";
export type {
  ArrayFieldProps,
  ArrayFieldRowRenderContext,
} from "./ArrayField";
export { FormPanel } from "./FormPanel";
export type {
  FormPanelProps,
  FormPanelFieldSpec,
  FormPanelSectionSpec,
} from "./FormPanel";
export { AutoForm } from "./AutoForm";
export type {
  AutoFormProps,
  AutoFormOverrides,
  AutoFormResolvedSection,
  AutoFormFieldRenderContext,
  AutoFormSectionRenderContext,
} from "./AutoForm";
export {
  defaultControlRegistry,
  createControlRegistry,
  resolveControlRenderer,
} from "./controlRegistry";
export type {
  ControlRegistry,
  AutoFormControlRenderer,
  AutoFormControlContext,
} from "./controlRegistry";
export {
  ErrorSummary,
  FieldRequirementLabel,
  FormErrorAnnouncer,
  FormSuccessRegion,
  errorSummaryItems,
  focusFieldControl,
  formFieldControlId,
} from "./validationChrome";
export type {
  ErrorSummaryItem,
  ErrorSummaryProps,
  FieldRequirementLabelProps,
  FormErrorAnnouncerProps,
  FormFieldChrome,
  FormSuccessRegionProps,
} from "./validationChrome";
export {
  createServerValidationError,
  defaultValidationMessages,
  errorCountLabel,
  labelForField,
  messageOverridesForField,
  resolveValidationMessage,
} from "./validationMessages";
export type {
  FieldValidationMessageMap,
  FormSpecValidationOptions,
  MessageAwareFormFieldSpec,
  ServerValidationPayload,
  ValidationMessageContext,
  ValidationMessageFormatter,
  ValidationMessageMap,
  ValidationMessageValue,
  ValidationRuleKey,
} from "./validationMessages";
export {
  FormBuilder,
  FormBuilderPage,
  FORM_BUILDER_DOCS,
  addFieldToSpec,
  addSectionToSpec,
  autoFormCodeSnippet,
  changeFieldTypeInSpec,
  cloneSeedSpec,
  contactRegistrationSeedSpec,
  createFormSpecResolver,
  fieldTypeLabel,
  getBuilderSections,
  moveFieldByOffset,
  moveFieldInSpec,
  normalizeSpecOrders,
  parseFormSpecJson,
  removeFieldFromSpec,
  removeSectionFromSpec,
  renameFieldInSpec,
  renameSectionInSpec,
  serializeFormSpec,
  updateFieldInSpec,
  validateValuesAgainstSpec,
} from "./builder";
export type { FormBuilderProps } from "./builder";
export { AutoFormOverrideDemo, ValidatedFormPanelDemo } from "./examples";
export {
  ConditionalFormCatalogDemo,
  FieldArrayFormCatalogDemo,
  FormWizardCatalogDemo,
  ValidationErrorUxCatalogDemo,
} from "./catalogDemos";
export * from "./wizard";
export * from "./entity-crud";
export * from "./persistence";
export { PersistenceCatalogDemo } from "./persistence/catalogDemo";

// Re-export the headless engine so the Forms feature is reachable from one path.
export {
  createFormStore,
  useForm,
  useFieldState,
  useFieldArray,
  useFormState,
  useFormSelector,
  standardSchemaResolver,
  FormSubmissionError,
  isFormSubmissionError,
  extractServerValidationErrors,
  ROOT_ERROR_KEY,
} from "../core/orchestration/forms";
export type {
  CreateFormStoreOptions,
  FieldErrors,
  FieldArrayMutationOptions,
  FieldArrayRow,
  FieldArrayState,
  FieldPath,
  FieldRegistration,
  FieldState,
  FieldValues,
  FormState,
  FormStore,
  RegisterFieldOptions,
  RegisterOptions,
  Resolver,
  ResolverResult,
  ReValidateMode,
  ServerValidationErrors,
  SetValueOptions,
  StandardSchemaV1,
  SubmitErrorHandler,
  SubmitHandler,
  UseFieldArrayOptions,
  UseFieldArrayReturn,
  UseFormReturn,
  UseFormWithSchemaOptions,
  ValidationMode,
} from "../core/orchestration/forms";
