// @vitest-environment happy-dom
import { readdirSync, readFileSync } from "node:fs";
import { join, relative, resolve } from "node:path";
import ts from "typescript";
import axe from "axe-core";
import { describe, expect, it } from "vitest";

// uif/issue-4685 follow-up (revision cycle 1): `<article role="listitem">`
// inside a `role="list"` container was ONE documented rule with (at least)
// eight occurrences across the package, fixed piecemeal in two passes before
// this gate existed. This is the package-wide enforcement Finding 3 asked
// for: every JSX host element (`article`, `div`, `span`, `section`, ...)
// carrying a literal `role="..."` string is checked against axe-core's OWN
// `aria-allowed-role` rule, so a sixth (or twentieth) occurrence fails the
// build instead of waiting for the next manual sweep.
//
// Why this is a REAL axe run and not a hand-rolled ARIA-in-HTML table: the
// element/role allow-list is a genuinely large, versioned part of the ARIA
// spec (and axe's own reading of it). Reimplementing that table here would
// duplicate axe's source of truth and silently drift from it — exactly the
// failure mode check-prop-docs.mjs's own header comment warns against for a
// much smaller table. Mounting a synthetic `<TAG role="ROLE">` snippet per
// unique (tag, role) pair actually found in source and asking real axe
// whether IT objects makes axe the oracle, not a copy of axe.
//
// Deliberately conservative, matching check-prop-docs.mjs's own philosophy:
//
//  1. Only a LITERAL host element with a LITERAL string `role` is checked.
//     `<Foo role="listitem">` (a custom component — the rendered host tag is
//     unknown here), `role={computed}` (not a string literal), and spread
//     props (`{...rest}`, which might carry a role) are all SKIPPED, not
//     guessed at. This can produce false negatives (a dynamic role slipping
//     through) but never a false positive, which is the trade this package's
//     other guards make throughout.
//  2. `<input>`'s ALLOWED-ROLES set depends on its `type` (checkbox/radio/
//     range/text/... each have their own implicit role and allow-list —
//     `<input type="checkbox" role="switch">` is the standard APG switch
//     pattern and is valid; a bare `<input role="switch">` defaults to
//     type=text and is NOT). A first version of this gate checked (tag, role)
//     alone and flagged SwitchControl.tsx's real, valid `<input type=
//     "checkbox" role="switch">` as a violation — a false positive from the
//     gate's own synthetic snippet being less specific than the real markup,
//     not a bug in the component. `type` is carried through for `input` so
//     the synthetic snippet matches what axe would actually see.
//  3. Each unique (tag, type, role) triple is checked exactly once via axe,
//     then the verdict is applied to every occurrence that shares it — cheap,
//     and the failure message still lists every offending file:line.
//  4. No baseline: every occurrence flagged today has already been fixed (see
//     the sibling `listRoleAffordance.test.tsx` / `disabledLinkAffordance
//     .test.tsx` coverage, plus CatalogExplorer.tsx's `<ul role="alert">`,
//     found BY writing this gate and fixed the same way), so this gate
//     starts, and must stay, at zero.

// happy-dom rewrites `import.meta.url` to an http URL (see
// tests/overlay/filterDrawerPanelDrawerComposition.test.tsx), so resolve from
// the process working directory the way that test does, rather than from
// this file's own location.
const SRC_ROOT = resolve(process.cwd(), "src");

const VOID_ELEMENTS = new Set([
  "area", "base", "br", "col", "embed", "hr", "img", "input",
  "link", "meta", "param", "source", "track", "wbr",
]);

type RoleOccurrence = { file: string; line: number; tag: string; type: string | null; role: string };

function listSourceFiles(directory: string): string[] {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) return listSourceFiles(path);
    if (!/\.tsx?$/.test(entry.name)) return [];
    if (/\.test\.tsx?$/.test(entry.name) || /\.d\.ts$/.test(entry.name)) return [];
    return [path];
  });
}

/** A plain-text string value off a JSX attribute's initializer, or `null` if it is not a simple string literal. */
function literalAttrValue(attr: ts.JsxAttribute): string | null {
  const init = attr.initializer;
  if (!init) return null;
  if (ts.isStringLiteral(init)) return init.text;
  if (ts.isJsxExpression(init) && init.expression && ts.isStringLiteral(init.expression)) {
    return init.expression.text;
  }
  return null;
}

/** Every literal-host-element + literal-string-role JSX attribute in one file. */
function findRoleOccurrences(file: string, relFile: string, source: string): RoleOccurrence[] {
  const sf = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  const found: RoleOccurrence[] = [];

  const visitOpening = (tagNameNode: ts.JsxTagNameExpression, attrs: ts.JsxAttributes, node: ts.Node) => {
    if (!ts.isIdentifier(tagNameNode)) return; // member expressions (Foo.Bar) are never host elements
    const tag = tagNameNode.text;
    if (!/^[a-z]/.test(tag)) return; // uppercase-leading = custom component, host tag unknown here

    let role: string | null = null;
    let type: string | null = null;
    for (const prop of attrs.properties) {
      if (!ts.isJsxAttribute(prop) || !prop.name) continue;
      const name = prop.name.getText(sf);
      if (name === "role") role = literalAttrValue(prop);
      else if (tag === "input" && name === "type") type = literalAttrValue(prop);
    }
    if (!role) return; // no role, or a dynamic one — skip, do not guess
    const line = sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1;
    found.push({ file: relFile, line, tag, type, role });
  };

  const visit = (node: ts.Node) => {
    if (ts.isJsxOpeningElement(node)) visitOpening(node.tagName, node.attributes, node);
    else if (ts.isJsxSelfClosingElement(node)) visitOpening(node.tagName, node.attributes, node);
    ts.forEachChild(node, visit);
  };
  visit(sf);
  return found;
}

/** Groups an occurrence into the (tag[, type], role) key its axe verdict is shared under. */
function pairKey(occurrence: Pick<RoleOccurrence, "tag" | "type" | "role">): string {
  return occurrence.tag === "input"
    ? `input[type=${occurrence.type ?? "text"}] ${occurrence.role}`
    : `${occurrence.tag} ${occurrence.role}`;
}

/** Mounts the element in isolation and asks real axe whether its role is allowed. */
async function axeAllowsRole(occurrence: Pick<RoleOccurrence, "tag" | "type" | "role">): Promise<boolean> {
  const { tag, role } = occurrence;
  const typeAttr = tag === "input" ? ` type="${occurrence.type ?? "text"}"` : "";
  const container = document.createElement("div");
  const html = VOID_ELEMENTS.has(tag)
    ? `<${tag}${typeAttr} role="${role}" />`
    : `<${tag}${typeAttr} role="${role}">content</${tag}>`;
  container.innerHTML = html;
  document.body.append(container);
  try {
    const results = await axe.run(container, { runOnly: { type: "rule", values: ["aria-allowed-role"] } });
    return results.violations.length === 0;
  } finally {
    container.remove();
  }
}

describe("package-wide aria-allowed-role gate (uif/issue-4685)", () => {
  it("finds no host element carrying a role axe-core disallows for it", async () => {
    const occurrences = listSourceFiles(SRC_ROOT).flatMap((file) =>
      findRoleOccurrences(file, relative(SRC_ROOT, file), readFileSync(file, "utf8")),
    );

    const pairs = new Map<string, RoleOccurrence>();
    for (const occurrence of occurrences) pairs.set(pairKey(occurrence), occurrence);

    const disallowed = new Set<string>();
    for (const [key, occurrence] of pairs) {
      const allowed = await axeAllowsRole(occurrence);
      if (!allowed) disallowed.add(key);
    }

    const violations = occurrences.filter((occurrence) => disallowed.has(pairKey(occurrence)));

    const detail = violations.length
      ? `\naxe-core's aria-allowed-role rule rejects the following <element role="..."> combinations:\n${violations
          .map((v) => `  ${v.file}:${v.line}: <${v.tag}${v.type ? ` type="${v.type}"` : ""} role="${v.role}">`)
          .join("\n")}\n`
      : "";

    expect(violations, detail).toEqual([]);
  });
});
