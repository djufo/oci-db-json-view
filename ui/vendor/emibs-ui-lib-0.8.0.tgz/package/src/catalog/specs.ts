/// <reference types="vite/client" />
// Catalog Explorer — .SPEC.md loader for the inspect-page Spec tab.
//
// Eagerly raw-imports every adjacent spec at build time and resolves them by the
// metadata specPath. Specs live beside their source under src/components/**,
// src/forms/** (the Forms composition slice, issue-668), src/compositions/**
// and src/core/** (uif/issue-4675). Board: task-234.
//
// Why the last two were added (uif/issue-4675): the catalog reported
// "1014/1014 checks (100%)" while these two source directories held ZERO specs
// and — more to the point — a spec written under either of them could not have
// been loaded at all, because no glob reached them. The coverage figure was
// therefore silent about them by construction rather than by measurement. The
// globs below make a spec in either directory resolvable; whether one exists is
// then a question the registration gate (scripts/check-catalog-registration.mjs)
// can actually ask.
//
// `import.meta.glob` patterns must be static string literals — Vite resolves
// them at build time — so each root is spelled out rather than looped over.

const raw = {
  ...(import.meta.glob("../components/**/*.SPEC.md", {
    query: "?raw",
    import: "default",
    eager: true,
  }) as Record<string, string>),
  ...(import.meta.glob("../forms/**/*.SPEC.md", {
    query: "?raw",
    import: "default",
    eager: true,
  }) as Record<string, string>),
  ...(import.meta.glob("../compositions/**/*.SPEC.md", {
    query: "?raw",
    import: "default",
    eager: true,
  }) as Record<string, string>),
  ...(import.meta.glob("../core/**/*.SPEC.md", {
    query: "?raw",
    import: "default",
    eager: true,
  }) as Record<string, string>),
};

// Key every spec by its path relative to src/ (e.g. "components/data/X.SPEC.md",
// "forms/AutoForm.SPEC.md", "compositions/CompositionFrame.SPEC.md") so a
// metadata specPath resolves regardless of the source folder it lives in. This
// is the single keying mechanism — adding a root above adds nothing here.
const bySuffix: Record<string, string> = {};
for (const [key, value] of Object.entries(raw)) {
  const suffix = key.replace(/^(?:\.\.\/)+/, "");
  bySuffix[suffix] = value;
}

/** Resolve a metadata specPath (e.g. "./forms/AutoForm.SPEC.md") to raw markdown. */
export function getSpec(specPath: string | null): string | null {
  if (!specPath) return null;
  const suffix = specPath.replace(/^\.?\/+/, "");
  return bySuffix[suffix] ?? null;
}
