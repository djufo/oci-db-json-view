import { describe, expect, it } from "vitest";
import {
  buildCoverageReport,
  buildCoverageRows,
  coverageFacets,
  coveragePercent,
  findLifecycleViolations,
  formatCoverageSummary,
  type CoverageFacetKey,
} from "./coverage";
import type { ComponentEntry } from "./types";

// Synthetic fixtures only — never live catalog data. A unit test that asserts a
// real entry *lacks* something goes red the moment the catalog improves.
function fixture(overrides: Partial<ComponentEntry> = {}): ComponentEntry {
  return {
    id: "fixture",
    name: "Fixture",
    category: "primitives",
    sourceApp: ["Shared"],
    patterns: ["Test"],
    specPath: "./Fixture.SPEC.md",
    hasSpec: true,
    status: "catalogued",
    hasDemo: true,
    specContent: "# Fixture",
    render: () => null,
    ...overrides,
  };
}

/** A fixture with all six coverage facets satisfied. */
function completeFixture(overrides: Partial<ComponentEntry> = {}): ComponentEntry {
  return fixture({
    variants: [{ label: "Default", render: () => null }],
    usage: { import: "import { Fixture } from 'lib';", snippet: "<Fixture />" },
    propDocs: [{ name: "id", type: "string", description: "Identifier." }],
    states: [{ id: "ready", label: "Ready", render: () => null }],
    ...overrides,
  });
}

/** Strips exactly one facet from an otherwise-complete fixture. */
const facetRemovers: Record<CoverageFacetKey, Partial<ComponentEntry>> = {
  demo: { hasDemo: false },
  variants: { variants: [] },
  usage: { usage: undefined },
  props: { propDocs: [] },
  states: { states: [] },
  spec: { specContent: "  " },
};

describe("catalog coverage", () => {
  it("keeps explicit states as their own coverage facet", () => {
    const rows = buildCoverageRows([
      fixture({ id: "without-states" }),
      fixture({
        id: "with-states",
        states: [{ id: "ready", label: "Ready", render: () => null }],
      }),
    ]);

    expect(coverageFacets.map((facet) => facet.key)).toEqual([
      "demo",
      "variants",
      "usage",
      "props",
      "states",
      "spec",
    ]);
    expect(rows.find((row) => row.entry.id === "with-states")?.completed).toBe(
      (rows.find((row) => row.entry.id === "without-states")?.completed ?? 0) + 1,
    );
  });

  it("requires every coverage facet at active, not a subset", () => {
    const bare = fixture({ status: "active", hasDemo: false, specContent: null });

    expect(findLifecycleViolations([bare])).toEqual([
      {
        entryId: "fixture",
        entryName: "Fixture",
        status: "active",
        missing: ["demo", "variants", "usage", "props", "states", "spec"],
      },
    ]);
  });

  describe.each(coverageFacets.map((facet) => facet.key))(
    "an active entry missing only %s",
    (facetKey) => {
      it("is reported as a violation naming that facet", () => {
        const entry = completeFixture({ status: "active", ...facetRemovers[facetKey] });

        expect(findLifecycleViolations([entry])).toEqual([
          {
            entryId: "fixture",
            entryName: "Fixture",
            status: "active",
            missing: [facetKey],
          },
        ]);
      });

      it("is not a violation while the entry is still catalogued", () => {
        const entry = completeFixture({ status: "catalogued", ...facetRemovers[facetKey] });

        expect(findLifecycleViolations([entry])).toEqual([]);
      });
    },
  );

  it("leaves work in progress alone below active", () => {
    const catalogued = fixture({ id: "catalogued", status: "catalogued", hasDemo: false });
    const demoMigrated = fixture({ id: "demo-migrated", status: "demo-migrated" });

    expect(findLifecycleViolations([catalogued, demoMigrated])).toEqual([]);
  });

  it("reports missing facets in the canonical facet order", () => {
    const entry = completeFixture({
      status: "adopted",
      ...facetRemovers.spec,
      ...facetRemovers.variants,
      ...facetRemovers.demo,
    });

    expect(findLifecycleViolations([entry])[0]?.missing).toEqual(["demo", "variants", "spec"]);
  });

  it("accepts complete active and adopted fixtures and formats a concise report", () => {
    const report = buildCoverageReport([
      completeFixture({ id: "active", status: "active" }),
      completeFixture({ id: "adopted", status: "adopted" }),
    ]);

    expect(report.lifecycleChecked).toBe(2);
    expect(report.lifecycleViolations).toEqual([]);
    expect(formatCoverageSummary(report)).toBe(
      "Catalog coverage: 2 entries, 12/12 checks (100%), 2 active-or-later entries valid. " +
        "Denominator: those 2 registered entries x 6 facets. It measures the registry against itself; " +
        "a component outside componentMeta is not counted as incomplete, it is not counted at all " +
        "(scripts/check-catalog-registration.mjs bounds that gap).",
    );
  });

  it("counts incomplete work in progress without failing the lifecycle rule", () => {
    const report = buildCoverageReport([
      completeFixture({ id: "active", status: "active" }),
      fixture({ id: "wip", status: "catalogued", hasDemo: false, specContent: null }),
    ]);

    expect(report.completed).toBe(6);
    expect(report.total).toBe(12);
    expect(report.percent).toBe(50);
    expect(report.lifecycleChecked).toBe(1);
    expect(report.lifecycleViolations).toEqual([]);
  });

  // Regression: the gate once printed "1013/1014 checks (100%)" because the
  // percentage was rounded. A completeness figure must never overstate
  // completeness — 100% has to mean every check passed.
  it("never reports 100% while a single check is short", () => {
    const entries = Array.from({ length: 169 }, (_, index) =>
      completeFixture({
        id: `entry-${index}`,
        status: "active",
        ...(index === 168 ? facetRemovers.spec : {}),
      }),
    );

    const report = buildCoverageReport(entries);

    expect(report.completed).toBe(1013);
    expect(report.total).toBe(1014);
    expect(report.percent).toBe(99);
    expect(formatCoverageSummary(report)).toBe(
      "Catalog coverage: 169 entries, 1013/1014 checks (99%), 1 lifecycle violation. " +
        "Denominator: those 169 registered entries x 6 facets. It measures the registry against itself; " +
        "a component outside componentMeta is not counted as incomplete, it is not counted at all " +
        "(scripts/check-catalog-registration.mjs bounds that gap).",
    );
  });

  it("reports 100% only when every check passes", () => {
    const entries = Array.from({ length: 169 }, (_, index) =>
      completeFixture({ id: `entry-${index}`, status: "active" }),
    );

    expect(buildCoverageReport(entries).percent).toBe(100);
  });

  it("floors partial percentages rather than rounding them up", () => {
    expect(coveragePercent(1013, 1014)).toBe(99);
    expect(coveragePercent(2, 3)).toBe(66);
    expect(coveragePercent(1014, 1014)).toBe(100);
    expect(coveragePercent(0, 1014)).toBe(0);
    expect(coveragePercent(0, 0)).toBe(0);
  });
});
