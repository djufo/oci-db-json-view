// Catalog Explorer — switchable group indexes derived from the registry.
//
// Every navigation/slice axis is computed here from componentMeta so the sidebar,
// gallery and faceted slice-&-dice all read one source of truth.
// Board: task-223 (derive switchable group indexes).

import type { Category, ComponentMeta, GroupAxis, Group, SourceApp } from "./types";

const CATEGORY_LABEL: Record<Category, string> = {
  primitives: "Primitives & controls",
  layout: "Layout & page shells",
  data: "Data, panels & boards",
  feedback: "Feedback & overlays",
  auth: "Auth & account",
};

const CATEGORY_ORDER: Category[] = ["primitives", "layout", "data", "feedback", "auth"];
const SOURCE_ORDER: SourceApp[] = ["Score", "eLitua", "Shared"];

const byName = (a: ComponentMeta, b: ComponentMeta) => a.name.localeCompare(b.name);

/** Group entries by a single axis, returning ordered groups with counts via items.length. */
export function groupBy(items: ComponentMeta[], axis: GroupAxis): Group[] {
  switch (axis) {
    case "category":
      return CATEGORY_ORDER.map((key) => ({
        key,
        label: CATEGORY_LABEL[key],
        items: items.filter((i) => i.category === key).sort(byName),
      })).filter((g) => g.items.length > 0);

    case "sourceApp":
      return SOURCE_ORDER.map((key) => ({
        key,
        label: key,
        // A component can list multiple source apps; it appears under each.
        items: items.filter((i) => i.sourceApp.includes(key)).sort(byName),
      })).filter((g) => g.items.length > 0);

    case "pattern": {
      const keys = Array.from(new Set(items.flatMap((i) => i.patterns))).sort();
      return keys.map((key) => ({
        key,
        label: key,
        items: items.filter((i) => i.patterns.includes(key)).sort(byName),
      }));
    }

    case "status": {
      const keys = Array.from(new Set(items.map((i) => i.status))).sort();
      return keys.map((key) => ({
        key,
        label: key,
        items: items.filter((i) => i.status === key).sort(byName),
      }));
    }

    case "alpha": {
      const keys = Array.from(new Set(items.map((i) => i.name[0]?.toUpperCase() ?? "#"))).sort();
      return keys.map((key) => ({
        key,
        label: key,
        items: items.filter((i) => (i.name[0]?.toUpperCase() ?? "#") === key).sort(byName),
      }));
    }
  }
}

export const AXES: { axis: GroupAxis; label: string }[] = [
  { axis: "category", label: "Category" },
  { axis: "sourceApp", label: "Source app" },
  { axis: "pattern", label: "Pattern" },
  { axis: "status", label: "Status" },
  { axis: "alpha", label: "A–Z" },
];

function fuzzyIncludes(value: string, query: string): boolean {
  const haystack = value.toLowerCase();
  const needle = query.toLowerCase();
  let cursor = 0;

  for (const char of needle) {
    cursor = haystack.indexOf(char, cursor);
    if (cursor < 0) return false;
    cursor += 1;
  }

  return true;
}

type SearchableMeta = Pick<ComponentMeta, "id" | "name" | "sourceApp" | "patterns"> & {
  category?: string;
};

/** Free-text fuzzy match over registry and mockup metadata (<10s findability). */
export function matches(meta: SearchableMeta, query: string): boolean {
  const tokens = query
    .trim()
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean);
  if (!tokens.length) return true;

  const fields = [meta.name, meta.id, meta.category, ...meta.sourceApp, ...meta.patterns].filter(
    (field): field is string => Boolean(field),
  );
  return tokens.every((token) => fields.some((field) => field.toLowerCase().includes(token) || fuzzyIncludes(field, token)));
}
