import { describe, expect, it } from "vitest";
import { buildCoverageReport, formatCoverageSummary, type LifecycleViolation } from "./coverage";
import { entries } from "./registry";

function describeViolation(violation: LifecycleViolation): string {
  return `  ${violation.entryName} (${violation.entryId}, ${violation.status}) is missing: ${violation.missing.join(", ")}`;
}

describe("catalog build coverage", () => {
  // The package's completeness gate. It is lifecycle-gated on purpose — see the
  // comment on findLifecycleViolations in coverage.ts. A new component may land
  // at `catalogued` with facets still missing; an `active` one may not.
  it("prints the registry report and enforces active lifecycle evidence", () => {
    const report = buildCoverageReport(entries);
    console.info(formatCoverageSummary(report));

    const detail = report.lifecycleViolations.length
      ? `\nActive-or-later entries missing part of their documented surface:\n${report.lifecycleViolations
          .map(describeViolation)
          .join("\n")}\n`
      : "";

    expect(report.lifecycleViolations, detail).toEqual([]);
  });

  // The lifecycle gate exempts anything below `active`, which is the right rule
  // (see findLifecycleViolations) and also a one-field escape hatch: setting a
  // finished component back to `status: "catalogued"` removes it from the check
  // entirely, while formatCoverageSummary keeps printing a comfortable
  // percentage over ALL entries — the gate goes quiet and the report does not.
  //
  // Every entry in the registry is `active` or later today, so asserting that
  // the gate actually covers all of them costs nothing now and closes the hole
  // permanently: a demotion has to be argued for here, in a diff, instead of
  // happening silently in a registry field.
  //
  // This is an ADDITION to the lifecycle rule above, not a replacement for it.
  // A genuinely new component still lands at `catalogued` — it just cannot do
  // so without this line changing too.
  it("checks every entry, so a status demotion cannot silently empty the gate", () => {
    const report = buildCoverageReport(entries);
    const exempt = entries
      .filter((entry) => entry.status !== "active" && entry.status !== "adopted")
      .map((entry) => `${entry.name} (${entry.id}) is ${entry.status}`);

    expect(
      report.lifecycleChecked,
      exempt.length
        ? `\nEntries below 'active' are exempt from the lifecycle gate:\n  ${exempt.join("\n  ")}\n` +
          "If a demotion is intended, say so here; if it is not, restore the status.\n"
        : "",
    ).toBe(report.rows.length);
  });
});
