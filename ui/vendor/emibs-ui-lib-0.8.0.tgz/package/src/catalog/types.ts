// Catalog Explorer — registry types.
//
// The registry is the single source of truth that drives the whole explorer:
// grouped/switchable/searchable navigation, the per-component inspect page,
// faceted slice-&-dice, theming and mockup composition. Group indexes
// (by category / source app / pattern / status) are all derived from this.
//
// Owning board epic: task-219 (Catalog Explorer · Component registry & metadata).

import type { ReactNode } from "react";

/** Folder-level taxonomy — the natural component category. */
export type Category = "primitives" | "layout" | "data" | "feedback" | "auth";

/** Which product the pattern was extracted from. */
export type SourceApp = "Score" | "eLitua" | "Shared";

/** Ordered lifecycle of a catalog entry. */
export type EntryStatus = "catalogued" | "demo-migrated" | "active" | "adopted";

/** Static metadata for one catalogued component (auto-mined; see metadata.ts). */
export type ComponentMeta = {
  /** Stable kebab-case id used in routes (#/c/<id>) and deep links. */
  id: string;
  /** Exported component name as it appears in source. */
  name: string;
  category: Category;
  /** One or more source apps the pattern was pulled from. */
  sourceApp: SourceApp[];
  /** Pattern/theme tags for grouping and the keyword cloud. */
  patterns: string[];
  /** Path to the adjacent .SPEC.md, or null when none exists yet. */
  specPath: string | null;
  hasSpec: boolean;
  status: EntryStatus;
};

/** One row of a component's Props/API reference table. */
export type PropDoc = {
  /** Prop name as written in JSX/TS. */
  name: string;
  /** TypeScript type or union, shown verbatim. */
  type: string;
  /** True when the prop has no default and must be supplied. */
  required?: boolean;
  /** Default value, shown when the prop is optional. */
  default?: string;
  /** One-line description of what the prop does. */
  description: string;
};

export type PlaygroundControlOption = {
  value: string;
  label: string;
};

type PlaygroundControlBase = {
  /** Prop/control name passed to renderWith and toSnippet. */
  name: string;
  label: string;
};

export type PlaygroundControl =
  | (PlaygroundControlBase & {
      kind: "boolean";
      default: boolean;
    })
  | (PlaygroundControlBase & {
      kind: "enum";
      default: string;
      options: readonly PlaygroundControlOption[];
    })
  | (PlaygroundControlBase & {
      kind: "string";
      default: string;
    })
  | (PlaygroundControlBase & {
      kind: "number";
      default: number;
    })
  | (PlaygroundControlBase & {
      kind: "node";
      default: string;
      options: readonly PlaygroundControlOption[];
    });

export type PlaygroundControlValue = boolean | number | string | ReactNode;

export type PlaygroundProps = Record<string, PlaygroundControlValue>;

export type PlaygroundSetControlValue = (name: string, value: PlaygroundControlValue) => void;

export type PlaygroundSchema = {
  controls: readonly PlaygroundControl[];
  renderWith: (props: PlaygroundProps, setControlValue?: PlaygroundSetControlValue) => ReactNode;
  toSnippet: (props: PlaygroundProps) => string;
};

/** One explicit component-state preview. Variants are a separate concept. */
export type StatePreview = {
  /** Stable kebab-case id used by coverage, tests, and future deep links. */
  id: string;
  /** Human-readable state label. */
  label: string;
  /** Optional explanation of the state and when it appears. */
  description?: string;
  /** Renders the state in isolation. */
  render: () => ReactNode;
};

/** A fully registered entry = metadata + an isolated demo renderer. */
export type ComponentEntry = ComponentMeta & {
  /** Canonical demo presence derived from the demo registry during assembly. */
  hasDemo: boolean;
  /** Resolved adjacent SPEC markdown, or null when absent/empty. */
  specContent: string | null;
  /** Renders the component's demo on the isolated inspect canvas. */
  render: () => ReactNode;
  /** Optional labelled variants for the inspect-page variants grid. */
  variants?: { label: string; render: () => ReactNode }[];
  /** Optional explicit interaction/data/lifecycle state previews. */
  states?: readonly StatePreview[];
  /** Optional import and JSX snippets for catalog usage documentation. */
  usage?: {
    import: string;
    snippet: string;
    variants?: { label: string; snippet: string }[];
  };
  /** Optional structured Props/API reference (Storybook ArgsTable equivalent). */
  propDocs?: PropDoc[];
  /** Optional live controls + JSX snippet builder for the inspect Playground tab. */
  playground?: PlaygroundSchema;
};

/** The axes the sidebar can group/slice by. */
export type GroupAxis = "category" | "sourceApp" | "pattern" | "status" | "alpha";

/** A derived, ordered group of entries for one axis value. */
export type Group<T extends ComponentMeta = ComponentMeta> = {
  key: string;
  label: string;
  items: T[];
};
