import { useState } from "react";
import { AddressField, type AddressMapAdapter, type AddressValue, type MapAdapterViewProps } from "../../components/data/AddressField";
import { GeoCoordinatePicker } from "../../components/data/GeoCoordinatePicker";
import { Button } from "../../components/primitives/Button";
import type { StatePreview } from "../types";
import type { Variant } from "./types";

// Synthetic address; the demo adapter never calls a service or loads a map SDK.
const initial: AddressValue = {
  street: "Example avenue", number: "12", city: "Sample town", postcode: "00000",
  countryCode: "LT", latitude: 54.6872, longitude: 25.2797,
};
function DemoMap({ point, readOnly, onPick }: MapAdapterViewProps) {
  return <div className="ui-address-demo-map">
    <p>{point ? `Selected point: ${point.latitude}, ${point.longitude}` : "No point selected"}</p>
    {point && <span className="ui-address-demo-map__pin" aria-hidden="true">＋</span>}
    {!readOnly && <Button type="button" onClick={() => onPick?.({ latitude: 55.7, longitude: 21.1 })}>Pick demo point</Button>}
  </div>;
}
const demoAdapter: AddressMapAdapter = { View: DemoMap, geocode: async () => ({ latitude: 54.6872, longitude: 25.2797 }) };
const searchDemo = async () => [{ ...initial, id: 1, canEdit: false }];
type DemoProps = { readOnly?: boolean; noMap?: boolean; coordinatesOnly?: boolean };
function AddressDemo({ readOnly = false, noMap = false, coordinatesOnly = false }: DemoProps) {
  const [value, setValue] = useState(initial);
  const mapAdapter = noMap ? undefined : demoAdapter;
  return coordinatesOnly
    ? <GeoCoordinatePicker latitude={value.latitude} longitude={value.longitude} readOnly={readOnly} mapAdapter={mapAdapter} onChange={point => setValue({ ...value, ...point })} />
    : <AddressField value={value} onChange={setValue} readOnly={readOnly} mapAdapter={mapAdapter} countryLabel="Lithuania" searchAddresses={searchDemo} />;
}
export const addressDemos = {
  "address-field": () => <AddressDemo />,
  "geo-coordinate-picker": () => <AddressDemo coordinatesOnly />,
};
function variants(coordinatesOnly: boolean): Variant[] {
  return [
    { label: "editable", render: () => <AddressDemo coordinatesOnly={coordinatesOnly} /> },
    { label: "read-only", render: () => <AddressDemo coordinatesOnly={coordinatesOnly} readOnly /> },
    { label: "no-map", render: () => <AddressDemo coordinatesOnly={coordinatesOnly} noMap /> },
  ];
}
export const addressVariants: Record<string, Variant[]> = {
  "address-field": variants(false), "geo-coordinate-picker": variants(true),
};
export const addressStates: Record<string, StatePreview[]> = Object.fromEntries(
  Object.entries(addressVariants).map(([id, rows]) => [id, rows.map(row => ({ ...row, id: row.label }))]),
);
