import { addressDemos } from "./address";
import { demoHeroImage, demoImage } from "../../demos/demoImage";
import type { ReactNode } from "react";
import {
  ArrowRight,
  BedDouble,
  Bell,
  Bot,
  CalendarDays,
  Database,
  Download,
  Flag,
  LayoutDashboard,
  Mail,
  MapPin,
  MapPinned,
  Plus,
  RefreshCw,
  Share2,
  ShieldCheck,
  Trash2,
  UserRound,
} from "lucide-react";
import { ActionGroup } from "../../components/primitives/ActionGroup";
import { Badge } from "../../components/primitives/Badge";
import { Breadcrumb } from "../../components/primitives/Breadcrumb";
import { Button } from "../../components/primitives/Button";
import {
  Card,
  CardAction,
  CardBody,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "../../components/primitives/Card";
import { BandChip, Chip, ClassChip, ModelChip, StatusChip } from "../../components/primitives/Chip";
import { ContactLinkList } from "../../components/primitives/ContactLinkList";
import { DescriptionList } from "../../components/primitives/DescriptionList";
import { EmptyState } from "../../components/primitives/EmptyState";
import { Field, Input, Select, Textarea } from "../../components/primitives/Field";
import { FreshnessBadge } from "../../components/primitives/FreshnessBadge";
import { IconButton } from "../../components/primitives/IconButton";
import { IdentityAvatar } from "../../components/primitives/IdentityAvatar";
import { InfoChipList } from "../../components/primitives/InfoChipList";
import { LoadingSpinner } from "../../components/primitives/LoadingSpinner";
import { Kbd, PlatformInputProvider, ShortcutHint } from "../../components/primitives/PlatformInputProvider";
import { Menu } from "../../components/primitives/Menu";
import { Meter } from "../../components/primitives/Meter";
import { DiscoveryCloudPanel } from "../../components/data/DiscoveryCloudPanel";
import { FilePreviewPanel } from "../../components/data/FilePreviewPanel";
import { MapMarkerPin } from "../../components/data/MapMarkerPin";
import { Pager } from "../../components/data/Pager";
import { AppShell } from "../../components/layout/AppShell";
import { BrandImageLink } from "../../components/layout/BrandImageLink";
import { EditorialArticlePage } from "../../components/layout/EditorialArticlePage";
import { LegalDocumentPage } from "../../components/layout/LegalDocumentPage";
import { MapViewport } from "../../components/layout/MapViewport";
import { NavigationMenu } from "../../components/layout/NavigationMenu";
import { PageHeader } from "../../components/layout/PageHeader";
import { PortalFooter } from "../../components/layout/PortalFooter";
import { PortalInfoPage } from "../../components/layout/PortalInfoPage";
import { PortalLandingPage } from "../../components/layout/PortalLandingPage";
import { PublicProfilePage } from "../../components/layout/PublicProfilePage";
import { StatusStrip } from "../../components/layout/StatusStrip";
import { TableOfContentsNav } from "../../components/layout/TableOfContentsNav";
import { PayloadBlock } from "../../components/primitives/PayloadBlock";
import { SectionCard } from "../../components/layout/SectionCard";
import { SignalDot } from "../../components/primitives/SignalDot";
import { Skeleton } from "../../components/primitives/Skeleton";
import { StatusIndicator } from "../../components/primitives/StatusIndicator";
import { Toolbar, ToolbarItem } from "../../components/primitives/Toolbar";
import { Tooltip } from "../../components/primitives/Tooltip";
import { LoadingState } from "../../components/feedback/LoadingState";
import { AutoFormDemo, FormPanelDemo } from "../formsDemos";
import {
  ConditionalFormCatalogDemo,
  FieldArrayFormCatalogDemo,
  FormBuilderPage,
  FormWizardCatalogDemo,
  PersistenceCatalogDemo,
  ValidationErrorUxCatalogDemo,
} from "../../forms";
import {
  brandImageDesktop,
  brandImageMobile,
  contactLinkListPublicItems,
  editorialArticleAuthor,
  editorialArticleMeta,
  editorialArticleRelated,
  editorialArticleSections,
  editorialArticleShareActions,
  editorialArticleTags,
  editorialArticleToc,
  filePreviewMeta,
  infoChipListRouteItems,
  legalDocumentBlocks,
  legalDocumentMeta,
  mapViewportMarkers,
  mapViewportStats,
  navItems,
  navigationMenuGroups,
  navigationMenuHeaderItems,
  portalFooterLinks,
  portalInfoAuthor,
  portalInfoSections,
  portalInfoStats,
  portalLandingFeatures,
  portalLandingHighlights,
  portalLandingIntents,
  portalLandingPlanner,
  portalLandingStats,
  publicProfileBadges,
  publicProfileContactActions,
  publicProfilePanels,
  publicProfileStats,
  scoreTaskDocumentMarkdown,
  statusItems,
  tableOfContentsNavItems,
} from "../../demos/data";
import {
  AccessibilityAuditDemo,
  AccountMenuRegistryDemo,
  AccountProfileRegistryDemo,
  AccountSessionsRegistryDemo,
  ActivityDashboardDemo,
  ActorAccessMatrixDemo,
  AdminHomePanelDemo,
  AdminRecordEditorPanelDemo,
  AgentManagementPanelDemo,
  AgentProfilePanelDemo,
  AlertDialogFrameDemo,
  AlertLaneDemo,
  AuditTimelineDemo,
  AuthAccessRegistryDemo,
  AuthStatusRegistryDemo,
  BlastRadiusConfirmDemo,
  BookingWidgetPanelDemo,
  CheckboxDemo,
  ChecklistEditorPanelDemo,
  CollapsibleDemo,
  ComboboxDemo,
  CommandBarDemo,
  CommandConsoleDemo,
  CommandPaletteDemo,
  CompareTrayPanelDemo,
  ComponentCatalogDemo,
  ComponentPlaygroundDemo,
  ComponentReviewDemo,
  ConfirmationDialogRegistryDemo,
  ContentTabsDemo,
  CookieConsentRegistryDemo,
  CreationDialogRegistryDemo,
  DataStatePanelRegistryDemo,
  DataTableDemo,
  DateFieldDemo,
  DesignIdeaBoardPanelDemo,
  DialogFrameDemo,
  DialogRegistryDemo,
  DrawerRegistryDemo,
  EditableFormDemo,
  EditorialListingDemo,
  EntityCardDemo,
  EntityCardGridPanelDemo,
  EntityFilterPanelDemo,
  ExplorerWorkspaceDemo,
  FacetFilterPanelDemo,
  FileActionListDemo,
  FilePreviewDialogDemo,
  FileUploadDemo,
  FilterDrawerPanelDemo,
  FloatingLabelFieldDemo,
  GeocodingControlPanelDemo,
  IconInputDemo,
  IdeaBacklogPanelDemo,
  InspectorRailDemo,
  IntegrationSetupPanelDemo,
  KanbanBoardDemo,
  MapControlPanelDemo,
  MapInfoCardDemo,
  MarkdownDocumentPanelDemo,
  MediaAssetPanelDemo,
  MetricGridDemo,
  ModeControlPanelDemo,
  NewsletterSignupPanelDemo,
  NoticeBannerRegistryDemo,
  NotificationToggleRegistryDemo,
  NotificationsRegistryDemo,
  NumberInputDemo,
  OperationalDiagnosticPanelDemo,
  OverlayHarnessRegistryDemo,
  PasswordRevealRegistryDemo,
  PaymentAccountPanelDemo,
  PaymentCheckoutPanelDemo,
  PopoverRegistryDemo,
  PortalHeaderDemo,
  PortalMobileNavigationDemo,
  PortalShellDemo,
  PreviewMatrixPanelDemo,
  ProcessRunHistoryPanelDemo,
  ProjectDirectoryDemo,
  ProjectProfileDemo,
  ProjectSettingsPanelDemo,
  RadioGroupDemo,
  RecordDetailPanelDemo,
  RelationshipPickerPanelDemo,
  ResourceIndexDemo,
  ResourceTransferDemo,
  ScheduleEditorDialogDemo,
  SchedulerControlPanelDemo,
  SearchDemo,
  SegmentedDemo,
  SelectDemo,
  SessionRefreshRegistryDemo,
  SliderRegistryDemo,
  SubscriptionCapacityDemo,
  SwitchDemo,
  TablePrimitiveRegistryDemo,
  TagInputDemo,
  TemporalInputDemo,
  TextInputControlDemo,
  TextareaControlDemo,
  ThemeAuditDemo,
  ThemeExportPanelDemo,
  ThemeLabPanelDemo,
  ThemeModeToggleDemo,
  ThemePreviewCanvasDemo,
  ToastStackRegistryDemo,
  ValidationSummaryRegistryDemo,
  WorkBoardToolbarDemo,
  WorkItemCardGridDemo,
  WorkItemPlanningPanelDemo,
  WorkItemRelationEditorDemo,
  WorkItemTracePanelDemo,
  WorkflowCommandBarDemo,
  WorkflowMapDemo,
  WorkspacePageFrameDemo,
  WorkspaceShellDemo,
  discoveryCloudGroups,
} from "./demoComponents";

// --- Isolated demo renderers, keyed by metadata id ---
export const DEMOS: Record<string, () => ReactNode> = {
  ...addressDemos,
  "auto-form": () => <AutoFormDemo />,
  "form-panel": () => <FormPanelDemo />,
  "account-menu": () => <AccountMenuRegistryDemo />,
  "account-profile-panel": () => <AccountProfileRegistryDemo />,
  "account-sessions-panel": () => <AccountSessionsRegistryDemo />,
  "auth-access-panel": () => <AuthAccessRegistryDemo />,
  "auth-status-panel": () => <AuthStatusRegistryDemo />,
  "password-reveal-button": () => <PasswordRevealRegistryDemo />,
  "session-refresh-dialog": () => <SessionRefreshRegistryDemo />,
  "accessibility-audit-panel": () => <AccessibilityAuditDemo />,
  "activity-dashboard": () => <ActivityDashboardDemo />,
  "actor-access-matrix": () => <ActorAccessMatrixDemo />,
  "admin-home-panel": () => <AdminHomePanelDemo />,
  "admin-record-editor-panel": () => <AdminRecordEditorPanelDemo />,
  "agent-management-panel": () => <AgentManagementPanelDemo />,
  "agent-profile-panel": () => <AgentProfilePanelDemo />,
  "checklist-editor-panel": () => <ChecklistEditorPanelDemo />,
  "command-console": () => <CommandConsoleDemo />,
  "entity-card-grid-panel": () => <EntityCardGridPanelDemo />,
  "entity-filter-panel": () => <EntityFilterPanelDemo />,
  "idea-backlog-panel": () => <IdeaBacklogPanelDemo />,
  "integration-setup-panel": () => <IntegrationSetupPanelDemo />,
  "map-control-panel": () => <MapControlPanelDemo />,
  "map-info-card": () => <MapInfoCardDemo />,
  "markdown-document-panel": () => <MarkdownDocumentPanelDemo />,
  "media-asset-panel": () => <MediaAssetPanelDemo />,
  "metric-grid": () => <MetricGridDemo />,
  "mode-control-panel": () => <ModeControlPanelDemo />,
  "operational-diagnostic-panel": () => <OperationalDiagnosticPanelDemo />,
  "payment-account-panel": () => <PaymentAccountPanelDemo />,
  "process-run-history-panel": () => <ProcessRunHistoryPanelDemo />,
  "project-settings-panel": () => <ProjectSettingsPanelDemo />,
  "record-detail-panel": () => <RecordDetailPanelDemo />,
  "relationship-picker-panel": () => <RelationshipPickerPanelDemo />,
  "schedule-editor-dialog": () => <ScheduleEditorDialogDemo />,
  "scheduler-control-panel": () => <SchedulerControlPanelDemo />,
  "work-board-toolbar": () => <WorkBoardToolbarDemo />,
  "work-item-card": () => <WorkItemCardGridDemo />,
  "work-item-planning-panel": () => <WorkItemPlanningPanelDemo />,
  "work-item-trace-panel": () => <WorkItemTracePanelDemo />,
  "workflow-command-bar": () => <WorkflowCommandBarDemo />,
  "entity-card": () => <EntityCardDemo />,
  "app-shell": () => (
    <div style={{ maxHeight: 520, overflow: "auto" }}>
      <AppShell
        brand={<strong>emibs-ui-lib</strong>}
        nav={navItems.slice(0, 8)}
        actions={<Badge tone="info">catalog shell</Badge>}
      >
        <PageHeader
          eyebrow="Catalog"
          title="Reusable UI framework"
          description="Navigation, page body and top actions stay presentational while routes remain app-owned."
        />
        <StatusStrip items={statusItems} />
      </AppShell>
    </div>
  ),
  "brand-image-link": () => (
    <div className="portal-demo-shell" style={{ maxWidth: 420 }}>
      <BrandImageLink
        href="#/c/brand-image-link"
        label="Open eLitua home"
        desktopImage={brandImageDesktop}
        mobileImage={brandImageMobile}
        title="eLitua"
        subtitle="Lithuanian tourism portal"
      />
    </div>
  ),
  "booking-widget-panel": () => <BookingWidgetPanelDemo />,
  "editorial-article-page": () => (
    <div className="editorial-article-demo-shell">
      <EditorialArticlePage
        backHref="#/c/editorial-article-page"
        backLabel="Blog"
        category="Destination guides"
        title="Things to Do in Lithuania 2026: The Ultimate Guide"
        subtitle="Everything a visitor needs to plan a practical Lithuanian route."
        author={editorialArticleAuthor}
        meta={editorialArticleMeta}
        hero={{ src: demoImage("city", 1200, 520), alt: "Vilnius old town rooftops" }}
        toc={editorialArticleToc}
        activeTocId="why-visit"
        sections={editorialArticleSections}
        tags={editorialArticleTags}
        shareActions={editorialArticleShareActions}
        related={editorialArticleRelated}
      />
    </div>
  ),
  "table-of-contents-nav": () => (
    <div style={{ maxWidth: 340 }}>
      <TableOfContentsNav items={tableOfContentsNavItems} activeItemId="why-visit" />
    </div>
  ),
  "editorial-listing-page": () => <EditorialListingDemo />,
  "explorer-workspace": () => <ExplorerWorkspaceDemo />,
  "legal-document-page": () => (
    <div className="legal-document-demo-shell">
      <LegalDocumentPage
        eyebrow="Legal information"
        title="Privacy policy"
        subtitle="A policy-oriented document surface for terms, privacy notices and provider agreements."
        meta={legalDocumentMeta}
        summary={{
          title: "Service provider",
          tone: "info",
          children: <><strong>eLitua MB, Lithuania.</strong> Product teams supply approved legal copy and version history.</>,
        }}
        blocks={legalDocumentBlocks}
        contact={{
          title: "Questions about this document?",
          description: "Contact, escalation and related policy routes are injected by the consuming product.",
          actions: <a className="ui-legal-document__contact-link" href="mailto:info@example.lt"><Mail size={15} />Contact</a>,
        }}
      />
    </div>
  ),
  "map-viewport": () => (
    <MapViewport
      title="Lithuania discovery map"
      stats={mapViewportStats}
      markers={mapViewportMarkers}
      actions={<Button size="sm" variant="secondary"><MapPinned size={15} />Fit route</Button>}
      infoPanel={<SectionCard density="compact" title="Selected guide"><p>Map SDK, clustering and routing stay product-owned.</p></SectionCard>}
    />
  ),
  "navigation-menu": () => (
    <div className="navigation-menu-demo-grid">
      <NavigationMenu ariaLabel="Grouped eLitua navigation" groups={navigationMenuGroups} />
      <NavigationMenu ariaLabel="Header navigation" density="compact" items={navigationMenuHeaderItems} layout="horizontal" />
    </div>
  ),
  "page-header": () => (
    <PageHeader
      eyebrow="Score operations"
      title="Component catalog"
      description="Review UI Framework components, specs, and adoption state before product teams replace local route chrome."
      leading={<LayoutDashboard size={20} />}
      status="ready for review"
      statusTone="success"
      badges={[
        { id: "source", label: "Score + eLitua", tone: "accent" },
        { id: "contract", label: "presentational" },
      ]}
      meta={[
        { id: "components", label: "Components", value: "129" },
        { id: "owner", label: "Owner", value: "UI Framework" },
      ]}
      actions={(
        <>
          <Button size="sm" variant="secondary"><RefreshCw size={15} />Refresh</Button>
          <Button size="sm"><Plus size={15} />New extraction</Button>
        </>
      )}
    />
  ),
  "portal-footer": () => (
    <PortalFooter
      brand={<a href="#/c/portal-footer" className="portal-footer-demo-brand">eLitua</a>}
      links={portalFooterLinks}
      actions={<Badge tone="success">desktop</Badge>}
      copyright="2026 eLitua - Lithuanian tourism portal"
    />
  ),
  "portal-header": () => <PortalHeaderDemo />,
  "portal-info-page": () => (
    <div className="portal-info-demo-shell">
      <PortalInfoPage
        eyebrow="About the portal"
        title="Lithuania in the palm of your hand"
        lead={<><strong>eLitua connects tourism data, accommodations, guides and AI-assisted planning.</strong></>}
        heroImage={{ src: demoHeroImage, alt: "Lithuanian lake and forest landscape" }}
        stats={portalInfoStats}
        sections={portalInfoSections}
        mission={<><strong>Mission copy stays product-owned.</strong> The shared shell keeps the emphasis band and responsive behavior.</>}
        author={portalInfoAuthor}
      />
    </div>
  ),
  "portal-landing-page": () => (
    <div className="portal-landing-demo-shell">
      <PortalLandingPage
        eyebrow="Lithuania travel"
        title="Plan Lithuania with local context"
        subtitle="Explore places, guides, stays and route ideas through a shared public landing page shell."
        heroImage={{ src: demoHeroImage, alt: "Lithuanian lake and forest landscape" }}
        actions={<><Button><MapPinned size={17} />Explore map</Button><Button variant="secondary">Meet guides<ArrowRight size={17} /></Button></>}
        stats={portalLandingStats}
        heroHighlights={portalLandingHighlights}
        intentTitle="Choose your route"
        intentDescription="Start with an intent, then refine by region, accommodation, guide language or pace."
        intents={portalLandingIntents}
        featuredTitle="Featured places"
        featuredDescription="A fast starting point for discovery through mapped places and guide knowledge."
        features={portalLandingFeatures}
        planner={{ ...portalLandingPlanner, action: <Button size="sm">Plan<CalendarDays size={15} /></Button> }}
      />
    </div>
  ),
  "portal-mobile-navigation": () => <PortalMobileNavigationDemo />,
  "portal-shell": () => <PortalShellDemo />,
  "public-profile-page": () => (
    <PublicProfilePage
      eyebrow="Licensed guide"
      title="Austeja Petrauskaite"
      subtitle="A public profile surface for guides, providers and marketplace participants."
      avatar="AP"
      avatarLabel="Austeja Petrauskaite profile avatar"
      badges={publicProfileBadges}
      contactActions={publicProfileContactActions}
      primaryAction={{ id: "request-route", label: "Request route", href: "#/c/public-profile-page", icon: <CalendarDays size={16} /> }}
      secondaryActions={[{ id: "share", label: "Share", href: "#/c/public-profile-page", icon: <Share2 size={16} />, variant: "secondary" }]}
      stats={publicProfileStats}
      panels={publicProfilePanels}
      aside={<div className="public-profile-demo-aside"><Badge tone="success">available this week</Badge><h2>Build a traveler-ready route</h2><p>Booking checks and calendar state stay product-owned.</p></div>}
    />
  ),
  "status-strip": () => <StatusStrip items={statusItems} />,
  "inspector-rail": () => <InspectorRailDemo />,
  "alert-lane": () => <AlertLaneDemo />,
  "blast-radius-confirm": () => <BlastRadiusConfirmDemo />,
  "audit-timeline": () => <AuditTimelineDemo />,
  "command-bar": () => <CommandBarDemo />,
  "workspace-page-frame": () => <WorkspacePageFrameDemo />,
  "workspace-shell": () => <WorkspaceShellDemo />,
  "action-group": () => (
    <ActionGroup align="end" gap="sm" label="Registry action group demo">
      <Button type="button" variant="secondary" size="sm">
        <RefreshCw size={15} />
        Refresh
      </Button>
      <Button type="button" variant="secondary" size="sm">
        <Download size={15} />
        Export
      </Button>
      <Button type="button" size="sm">
        <Plus size={15} />
        New
      </Button>
    </ActionGroup>
  ),
  button: () => (
    <div className="xpl-row">
      <Button>Primary</Button>
      <Button variant="danger">Danger</Button>
      <Button variant="ghost">Ghost</Button>
      <Button variant="quiet">Quiet</Button>
      <Button loading>Saving</Button>
    </div>
  ),
  breadcrumb: () => (
    <Breadcrumb
      ariaLabel="Catalog path"
      items={[
        { id: "home", label: "Components", href: "#/" },
        { id: "primitives", label: "Primitives", href: "#/coverage" },
        { id: "current", label: "Breadcrumb" },
      ]}
    />
  ),
  chip: () => (
    <div className="xpl-row" aria-label="Chip taxonomy demo">
      <Chip tone="accent">Base chip</Chip>
      <StatusChip status="success" label="ready" />
      <BandChip band="campaign" />
      <ClassChip classification="convergence" />
      <ModelChip model="advanced" label="advanced model" />
    </div>
  ),
  "freshness-badge": () => (
    <div className="xpl-row">
      <FreshnessBadge value="2026-07-18T11:59:00.000Z" now={Date.parse("2026-07-18T12:00:00.000Z")} />
      <FreshnessBadge value="2026-07-18T11:00:00.000Z" now={Date.parse("2026-07-18T12:00:00.000Z")} staleAfterMs={30 * 60_000} />
      <FreshnessBadge value={null} />
    </div>
  ),
  "keyboard-hint": () => (
    <div className="xpl-row">
      <PlatformInputProvider platform="mac" hasHardwareKeyboard><ShortcutHint shortcut="mod+k">Mac</ShortcutHint></PlatformInputProvider>
      <PlatformInputProvider platform="windows" hasHardwareKeyboard><ShortcutHint shortcut="mod+k">Windows</ShortcutHint></PlatformInputProvider>
      <PlatformInputProvider platform="mobile" hasHardwareKeyboard={false}><ShortcutHint shortcut="mod+k">Mobile</ShortcutHint><Kbd shortcut="mod+k" /></PlatformInputProvider>
    </div>
  ),
  meter: () => (
    <div className="xpl-stack">
      <Meter label="Daily capacity" value={72} />
      <Meter label="Weekly capacity" value={28} />
      <Meter label="Unreported capacity" value={null} />
    </div>
  ),
  "signal-dot": () => (
    <div className="xpl-row">
      <SignalDot label="Online" showLabel tone="success" />
      <SignalDot label="Degraded" showLabel tone="warning" />
      <SignalDot label="Offline" showLabel tone="danger" />
      <SignalDot label="Live updates" pulse tone="info" />
    </div>
  ),
  menu: () => (
    <Menu
      triggerLabel="Task actions"
      items={[
        { id: "inspect", label: "Inspect" },
        { id: "duplicate", label: "Duplicate" },
        { id: "archive", label: "Archive", disabled: true },
        { id: "delete", label: "Delete", tone: "danger" },
      ]}
    />
  ),
  skeleton: () => (
    <div className="xpl-stack" aria-label="Loading content preview">
      <Skeleton exposed ariaLabel="Loading title" variant="text" />
      <Skeleton exposed ariaLabel="Loading summary" animation="wave" variant="text" />
      <Skeleton exposed ariaLabel="Loading image" variant="rectangular" />
    </div>
  ),
  slider: () => <SliderRegistryDemo />,
  "table-primitive": () => <TablePrimitiveRegistryDemo />,
  toolbar: () => (
    <Toolbar ariaLabel="Preview commands" rovingFocus>
      <ToolbarItem>Undo</ToolbarItem>
      <ToolbarItem>Redo</ToolbarItem>
      <ToolbarItem disabled>Publish</ToolbarItem>
      <ToolbarItem>Inspect</ToolbarItem>
    </Toolbar>
  ),
  tooltip: () => (
    <Tooltip content="Refreshes the preview without changing saved theme data" side="bottom">
      <Button variant="quiet">Focus or hover for help</Button>
    </Tooltip>
  ),
  badge: () => (
    <div className="xpl-row">
      <Badge tone="neutral">neutral</Badge>
      <Badge tone="info">info</Badge>
      <Badge tone="success">success</Badge>
      <Badge tone="warning">warning</Badge>
      <Badge tone="danger">danger</Badge>
      <Badge tone="accent">accent</Badge>
    </div>
  ),
  card: () => (
    <Card style={{ maxWidth: 360 }}>
      <CardHeader>
        <div>
          <CardTitle>Sodyba Pamiske</CardTitle>
          <CardDescription>Structured card slot parity for shared review surfaces.</CardDescription>
        </div>
        <CardAction>
          <Badge tone="success">Verified</Badge>
        </CardAction>
      </CardHeader>
      <CardBody>
        A presentational surface for grouped content. Product data, media,
        routes, and action behavior stay in the consuming app.
      </CardBody>
      <CardFooter>
        <Button size="sm" variant="secondary">Details</Button>
        <Button size="sm">Review</Button>
      </CardFooter>
    </Card>
  ),
  "icon-button": () => (
    <div className="xpl-row">
      <IconButton label="Refresh" icon={<RefreshCw size={16} />} />
      <IconButton label="New" variant="active" icon={<Plus size={16} />} />
      <IconButton label="Alerts" variant="ghost" icon={<Bell size={16} />} />
      <IconButton label="Delete" variant="danger" icon={<Trash2 size={16} />} />
    </div>
  ),
  "identity-avatar": () => (
    <div className="xpl-row">
      <IdentityAvatar label="Austeja Petrauskaite" initials="AP" size="lg" tone="accent" status="success" statusLabel="Verified" />
      <IdentityAvatar label="Codex Maestro" initials="CM" tone="info" status="info" statusLabel="Active" />
      <IdentityAvatar label="Agent worker" icon={<Bot size={18} />} tone="warning" status="warning" statusLabel="Busy" />
      <IdentityAvatar label="Guest account" icon={<UserRound size={18} />} size="sm" />
    </div>
  ),
  "loading-spinner": () => (
    <div className="xpl-stack" style={{ maxWidth: 520 }}>
      <LoadingSpinner label="Loading session" tone="accent" variant="centered" />
      <div className="xpl-row">
        <LoadingSpinner label="Map tiles" size="sm" tone="info" />
        <LoadingSpinner ariaLabel="Loading without visible label" showLabel={false} tone="neutral" />
        <LoadingSpinner label="Saving" size="lg" tone="success" />
      </div>
    </div>
  ),
  "status-indicator": () => (
    <div className="xpl-stack" style={{ maxWidth: 520 }}>
      <StatusIndicator
        detail="Credentials valid - last sync just now"
        icon={<ShieldCheck size={15} />}
        label="Connected to Bokun"
        tone="success"
        variant="bar"
      />
      <StatusIndicator icon={<Bot size={15} />} label="At capacity" detail="Day 92% - week 78%" tone="warning" />
      <StatusIndicator label="Disabled" tone="neutral" variant="pill" size="sm" />
    </div>
  ),
  "payload-block": () => (
    <div style={{ maxWidth: 620 }}>
      <PayloadBlock
        title="Diagnostic JSON"
        description="Preformatted response payload with host-owned copy, retention, and optional disclosure behavior."
        label="sample response"
        language="json"
        status="connected"
        statusTone="success"
        collapsible
        defaultCollapsed
        meta={[
          { id: "source", label: "Source", value: "TestDbPage" },
          { id: "checked", label: "Checked", value: "02:15 UTC" },
        ]}
        payload={'{\n  "status": "success",\n  "message": "database query executed"\n}'}
      />
    </div>
  ),
  "alert-dialog-frame": () => <AlertDialogFrameDemo />,
  "confirmation-dialog": () => <ConfirmationDialogRegistryDemo />,
  "cookie-consent-banner": () => <CookieConsentRegistryDemo simple />,
  "creation-dialog": () => <CreationDialogRegistryDemo />,
  "data-state-panel": () => <DataStatePanelRegistryDemo />,
  "dialog-frame": () => <DialogFrameDemo />,
  "notice-banner": () => <NoticeBannerRegistryDemo />,
  "notification-toggle": () => <NotificationToggleRegistryDemo />,
  "notification-bell": () => <NotificationsRegistryDemo />,
  "activity-center": () => <NotificationsRegistryDemo />,
  "resource-transfer-dialog": () => <ResourceTransferDemo />,
  "toast-stack": () => <ToastStackRegistryDemo />,
  "validation-summary": () => <ValidationSummaryRegistryDemo />,
  "validation-error-ux-demo": () => <ValidationErrorUxCatalogDemo />,
  "component-catalog-panel": () => <ComponentCatalogDemo />,
  "component-playground-panel": () => <ComponentPlaygroundDemo />,
  "component-review-panel": () => <ComponentReviewDemo />,
  "compare-tray-panel": () => <CompareTrayPanelDemo />,
  "conditional-form-demo": () => <ConditionalFormCatalogDemo />,
  "field-array-form-demo": () => <FieldArrayFormCatalogDemo />,
  "design-idea-board-panel": () => <DesignIdeaBoardPanelDemo />,
  "discovery-cloud-panel": () => (
    <DiscoveryCloudPanel
      description="Pattern and keyword cloud chrome. Consumers own query construction, route URLs, and counts."
      groups={discoveryCloudGroups}
      resultCount="92 components"
    />
  ),
  "editable-form-panel": () => <EditableFormDemo />,
  "form-builder": () => <FormBuilderPage />,
  "form-persistence-demo": () => <PersistenceCatalogDemo />,
  "form-wizard-demo": () => <FormWizardCatalogDemo />,
  "facet-filter-panel": () => <FacetFilterPanelDemo />,
  "filter-drawer-panel": () => <FilterDrawerPanelDemo />,
  "file-action-list-panel": () => <FileActionListDemo />,
  "floating-label-field": () => <FloatingLabelFieldDemo />,
  "geocoding-control-panel": () => <GeocodingControlPanelDemo />,
  "kanban-board": () => <KanbanBoardDemo />,
  pager: () => (
    <Pager
      page={2}
      total={12}
      summary="Showing 11-20 of 118 places"
      compactSummary="11-20 of 118"
      onPageChange={() => undefined}
    />
  ),
  "payment-checkout-panel": () => <PaymentCheckoutPanelDemo />,
  "newsletter-signup-panel": () => <NewsletterSignupPanelDemo />,
  "preview-matrix-panel": () => <PreviewMatrixPanelDemo />,
  "project-directory-panel": () => <ProjectDirectoryDemo />,
  "project-profile-panel": () => <ProjectProfileDemo />,
  "resource-index-panel": () => <ResourceIndexDemo />,
  "subscription-capacity-panel": () => <SubscriptionCapacityDemo />,
  "theme-audit-panel": () => <ThemeAuditDemo />,
  "theme-export-panel": () => <ThemeExportPanelDemo />,
  "theme-lab-panel": () => <ThemeLabPanelDemo />,
  "theme-preview-canvas": () => <ThemePreviewCanvasDemo />,
  "workflow-map-panel": () => <WorkflowMapDemo />,
  "switch-control": () => <SwitchDemo />,
  "checkbox-control": () => <CheckboxDemo />,
  collapsible: () => <CollapsibleDemo />,
  "combobox-field": () => <ComboboxDemo />,
  "select-control": () => <SelectDemo />,
  "radio-group": () => <RadioGroupDemo />,
  "date-field": () => <DateFieldDemo />,
  "data-table": () => <DataTableDemo />,
  dialog: () => <DialogRegistryDemo />,
  drawer: () => <DrawerRegistryDemo />,
  popover: () => <PopoverRegistryDemo />,
  "overlay-harness": () => <OverlayHarnessRegistryDemo />,
  "number-input-control": () => <NumberInputDemo />,
  "temporal-input-control": () => <TemporalInputDemo />,
  "text-input-control": () => <TextInputControlDemo />,
  "textarea-control": () => <TextareaControlDemo />,
  "command-palette": () => <CommandPaletteDemo />,
  "contact-link-list": () => (
    <ContactLinkList
      label="Guide contact links"
      items={contactLinkListPublicItems}
    />
  ),
  "content-tabs": () => <ContentTabsDemo />,
  "segmented-control": () => <SegmentedDemo />,
  "section-card": () => (
    <div style={{ maxWidth: 680 }}>
      <SectionCard
        collapsible
        defaultCollapsed
        actions={<Button size="sm" type="button" variant="secondary"><RefreshCw size={15} /> Refresh</Button>}
        badges={[
          { id: "runtime", label: "runtime", tone: "info" },
          { id: "review", label: "reviewable", tone: "success" },
        ]}
        description="A reusable section wrapper; settings data, route state and persistence stay local."
        icon={<Database size={18} />}
        title="Settings summary"
      >
        <DescriptionList
          columns={2}
          density="compact"
          items={[
            { id: "recipient", label: "Recipient", value: "ops@example.lt" },
            { id: "updated", label: "Updated", value: "Just now", tone: "success" },
          ]}
        />
      </SectionCard>
    </div>
  ),
  "search-field": () => (
    <div style={{ maxWidth: 420 }}>
      <SearchDemo />
    </div>
  ),
  field: () => (
    <div className="xpl-stack" style={{ maxWidth: 420 }}>
      <Field label="Project name" hint="Shown across the board and reports." meta="Score">
        <Input defaultValue="Score" />
      </Field>
      <Field label="Default status" required>
        <Select defaultValue="ready">
          <option value="created">created</option>
          <option value="ready">ready</option>
          <option value="processing">processing</option>
        </Select>
      </Field>
      <Field label="Public profile summary" hint="Used by eLitua account forms for short profile copy.">
        <Textarea defaultValue="Tours, stays, and verified local experiences." rows={3} />
      </Field>
      <Field
        id="field-demo-webhook"
        label="Webhook URL"
        description="Receives issue updates from Score."
        hint="Use https and include a path."
        error="Enter a valid https URL."
        required
      >
        <Input defaultValue="example.lt/hook" />
      </Field>
    </div>
  ),
  "empty-state": () => (
    <div style={{ maxWidth: 380 }}>
      <EmptyState
        icon={<Database size={22} />}
        title="No records yet"
        action={<Button size="sm">Add the first record</Button>}
      >
        Connect a source or create a record to populate this view.
      </EmptyState>
    </div>
  ),
  "loading-state": () => (
    <div style={{ maxWidth: 380 }}>
      <LoadingState title="Loading records" description="Fetching the latest records." />
    </div>
  ),
  "file-preview-panel": () => (
    <div className="xpl-stack" style={{ maxWidth: 760 }}>
      <FilePreviewPanel
        file={{
          filename: "issue-590-extraction-notes.md",
          contentType: "text/markdown",
          downloadHref: "#",
          downloadName: "issue-590-extraction-notes.md",
        }}
        kind="markdown"
        description="Score fetches the authenticated attachment text and passes it into shared preview chrome."
        badges={[
          { id: "kind", label: "Markdown", tone: "info" },
          { id: "owner", label: "app-fetched", tone: "success" },
        ]}
        meta={filePreviewMeta}
        markdown={scoreTaskDocumentMarkdown}
      />
      <FilePreviewPanel
        file={{
          filename: "score-ledger-export.bin",
          contentType: "application/octet-stream",
          sizeLabel: "3.4 MB",
          downloadHref: "#",
        }}
        kind="file"
        badges={[{ id: "policy", label: "download only", tone: "warning" }]}
        fallbackLabel="Preview unavailable for this file type."
      />
    </div>
  ),
  "file-preview-dialog": () => <FilePreviewDialogDemo />,
  "file-upload-control": () => <FileUploadDemo />,
  "icon-input-field": () => <IconInputDemo />,
  "description-list": () => (
    <div style={{ maxWidth: 520 }}>
      <DescriptionList
        ariaLabel="Description list demo"
        columns={2}
        items={[
          { id: "license", label: "License", value: "LT-G-2041", icon: <ShieldCheck size={15} />, tone: "success" },
          { id: "owner", label: "Owner", value: "Maestro", icon: <Bot size={15} />, tone: "info" },
          { id: "branch", label: "Branch", value: "score-299-extract-description-list" },
          { id: "sync", label: "Last sync", value: "Just now" },
        ]}
      />
    </div>
  ),
  "info-chip-list": () => (
    <InfoChipList
      label="Guide routes"
      items={infoChipListRouteItems}
    />
  ),
  "tag-input": () => <TagInputDemo />,
  "work-item-relation-editor-panel": () => <WorkItemRelationEditorDemo />,
  "theme-mode-toggle": () => <ThemeModeToggleDemo />,
  "map-marker-pin": () => (
    <div className="xpl-stack">
      <MapMarkerPin label="Accommodation marker" icon={<BedDouble size={16} />} showLabel />
      <MapMarkerPin label="Selected guide marker" icon={<Flag size={16} />} selected showLabel />
      <MapMarkerPin kind="dot" label="Verified place dot" icon={<MapPin size={13} />} tone="success" showLabel />
      <MapMarkerPin kind="cluster" count="24" ariaLabel="Cluster with 24 records" />
    </div>
  ),
};
