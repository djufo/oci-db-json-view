import type { StatePreview } from "../../types";

import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import { PayloadBlock } from "../../../components/primitives/PayloadBlock";
import { SelectControl } from "../../../components/primitives/SelectControl";
import { TextInputControl } from "../../../components/primitives/TextInputControl";
import { TextareaControl } from "../../../components/primitives/TextareaControl";
import { StatusStrip } from "../../../components/layout/StatusStrip";

import { AccessibilityAuditPanel } from "../../../components/data/AccessibilityAuditPanel";
import { ActivityDashboard } from "../../../components/data/ActivityDashboard";
import { ActorAccessMatrix } from "../../../components/data/ActorAccessMatrix";
import { AdminHomePanel } from "../../../components/data/AdminHomePanel";
import { AdminRecordEditorPanel } from "../../../components/data/AdminRecordEditorPanel";
import { AgentManagementPanel } from "../../../components/data/AgentManagementPanel";
import { AgentProfilePanel } from "../../../components/data/AgentProfilePanel";
import { AuditTimeline, type AuditEntry } from "../../../components/data/AuditTimeline";
import {
  BookingWidgetPanel,
  type BookingWidgetPanelBadge,
  type BookingWidgetPanelDetail,
} from "../../../components/data/BookingWidgetPanel";
import { ChecklistEditorPanel, type ChecklistEditorItem } from "../../../components/data/ChecklistEditorPanel";
import { CommandBar } from "../../../components/data/CommandBar";
import type { CommandVerb } from "../../../components/data/commandBarModel";
import type { CommandPaletteGroup } from "../../../components/primitives/CommandPalette";
import { CommandConsole } from "../../../components/data/CommandConsole";
import {
  CompareTrayPanel,
  type CompareTrayAction,
  type CompareTrayItem,
} from "../../../components/data/CompareTrayPanel";
import {
  ComponentCatalogPanel,
  type ComponentCatalogItem,
} from "../../../components/data/ComponentCatalogPanel";
import {
  ComponentPlaygroundPanel,
  type ComponentPlaygroundControl,
  type ComponentPlaygroundValues,
} from "../../../components/data/ComponentPlaygroundPanel";
import {
  ComponentReviewPanel,
  type ComponentReviewCanvasSize,
  type ComponentReviewTab,
  type ComponentReviewVariant,
} from "../../../components/data/ComponentReviewPanel";
import { DataTable, type DataTableColumn } from "../../../components/data/DataTable";
import { DesignIdeaBoardPanel, type DesignIdeaBoardItem } from "../../../components/data/DesignIdeaBoardPanel";
import { DiscoveryCloudPanel, type DiscoveryCloudGroup } from "../../../components/data/DiscoveryCloudPanel";
import {
  EditableFormPanel,
  type EditableFormSection,
} from "../../../components/data/EditableFormPanel";
import { EntityCard } from "../../../components/data/EntityCard";
import { EntityCardGridPanel } from "../../../components/data/EntityCardGridPanel";
import { EntityFilterPanel, type EntityFilterControl } from "../../../components/data/EntityFilterPanel";
import {
  FacetFilterPanel,
  type FacetFilterChip,
  type FacetFilterGroup,
} from "../../../components/data/FacetFilterPanel";
import { FileActionListPanel } from "../../../components/data/FileActionListPanel";
import { FilePreviewDialog } from "../../../components/data/FilePreviewDialog";
import { FilePreviewPanel, type FilePreviewRecord } from "../../../components/data/FilePreviewPanel";
import { FilterDrawerPanel } from "../../../components/data/FilterDrawerPanel";
import {
  GeocodingControlPanel,
  type GeocodingControlCandidate,
  type GeocodingControlSource,
} from "../../../components/data/GeocodingControlPanel";
import { IdeaBacklogPanel } from "../../../components/data/IdeaBacklogPanel";
import {
  IntegrationSetupPanel,
  type IntegrationSetupSection,
} from "../../../components/data/IntegrationSetupPanel";
import { KanbanBoard, type KanbanColumn } from "../../../components/data/KanbanBoard";
import {
  MapControlPanel,
  type MapControlPanelAction,
  type MapControlPanelStat,
} from "../../../components/data/MapControlPanel";
import { MapInfoCard } from "../../../components/data/MapInfoCard";
import { MapMarkerPin } from "../../../components/data/MapMarkerPin";
import { MarkdownDocumentPanel } from "../../../components/data/MarkdownDocumentPanel";
import { MediaAssetPanel } from "../../../components/data/MediaAssetPanel";
import { MetricGrid, type MetricGridItem } from "../../../components/data/MetricGrid";
import {
  ModeControlPanel,
  type ModeControlOption,
  type ModeControlToggle,
} from "../../../components/data/ModeControlPanel";
import { NewsletterSignupPanel } from "../../../components/data/NewsletterSignupPanel";
import { OperationalDiagnosticPanel } from "../../../components/data/OperationalDiagnosticPanel";
import { Pager } from "../../../components/data/Pager";
import { PaymentAccountPanel } from "../../../components/data/PaymentAccountPanel";
import { PaymentCheckoutPanel } from "../../../components/data/PaymentCheckoutPanel";
import {
  PreviewMatrixPanel,
  type PreviewMatrixColumn,
  type PreviewMatrixRow,
} from "../../../components/data/PreviewMatrixPanel";
import {
  ProcessRunHistoryPanel,
  type ProcessRunHistoryItem,
} from "../../../components/data/ProcessRunHistoryPanel";
import { ProjectDirectoryPanel } from "../../../components/data/ProjectDirectoryPanel";
import {
  ProjectProfilePanel,
  type ProjectProfileChecklistItem,
  type ProjectProfileField,
} from "../../../components/data/ProjectProfilePanel";
import {
  ProjectSettingsPanel,
  type ProjectSettingsConfigDocument,
  type ProjectSettingsNotice,
  type ProjectSettingsSummaryDigest,
} from "../../../components/data/ProjectSettingsPanel";
import {
  RecordDetailPanel,
  type RecordDetailField,
  type RecordDetailSection,
} from "../../../components/data/RecordDetailPanel";
import { RelationshipPickerPanel } from "../../../components/data/RelationshipPickerPanel";
import { ResourceIndexPanel } from "../../../components/data/ResourceIndexPanel";
import {
  ResourceTransferDialog,
  type ResourceTransferDialogResource,
} from "../../../components/data/ResourceTransferDialog";
import {
  ScheduleEditorDialog,
  type ScheduleEditorDialogCheck,
  type ScheduleEditorDialogField,
  type ScheduleEditorDialogMeta,
} from "../../../components/data/ScheduleEditorDialog";
import { SchedulerControlPanel } from "../../../components/data/SchedulerControlPanel";
import { SubscriptionCapacityPanel } from "../../../components/data/SubscriptionCapacityPanel";
import {
  ThemeAuditPanel,
  type ThemeAuditGap,
  type ThemeAuditMetric,
  type ThemeAuditNote,
  type ThemeAuditTokenGroup,
} from "../../../components/data/ThemeAuditPanel";
import {
  ThemeExportPanel,
  type ThemeExportFormat,
} from "../../../components/data/ThemeExportPanel";
import {
  ThemeLabPanel,
  type ThemeLabProposal,
  type ThemeLabTextAreaControl,
} from "../../../components/data/ThemeLabPanel";
import {
  ThemePreviewCanvas,
  type ThemePreviewCanvasSurface,
} from "../../../components/data/ThemePreviewCanvas";
import { WorkBoardToolbar } from "../../../components/data/WorkBoardToolbar";
import { WorkItemCard } from "../../../components/data/WorkItemCard";
import {
  WorkItemPlanningPanel,
  type WorkItemDraft,
  type WorkItemTriageDraft,
} from "../../../components/data/WorkItemPlanningPanel";
import {
  WorkItemRelationEditorPanel,
  type WorkItemRelationEditorField,
} from "../../../components/data/WorkItemRelationEditorPanel";
import { WorkItemTracePanel } from "../../../components/data/WorkItemTracePanel";
import { WorkflowCommandBar } from "../../../components/data/WorkflowCommandBar";
import { WorkflowMapPanel, type WorkflowMapStage } from "../../../components/data/WorkflowMapPanel";

import { AutoForm } from "../../../forms/AutoForm";
import { FormPanel } from "../../../forms/FormPanel";
import { FormBuilder } from "../../../forms/builder/FormBuilder";
import { contactRegistrationSeedSpec } from "../../../forms/builder/seed";
import { DraftResumePrompt, SaveStatusIndicator } from "../../../forms/persistence";
import { useForm } from "../../../core/orchestration/forms";
import type { FieldType, FormSpec } from "../../../core/config";

import {
  accessibilityAuditNotes,
  accessibilityAuditViolations,
  activityDashboardItems,
  activityDashboardMetrics,
  activityDashboardQueues,
  actorAccessRoleOptions,
  actorAccessRows,
  adminHomeActions,
  adminHomeMetrics,
  adminHomeNotices,
  adminRecordEditorMeta,
  adminRecordEditorNotices,
  agentManagementAgents,
  agentManagementMetrics,
  agentManagementRunners,
  agentProfileFields,
  agentProfileGrants,
  agentProfileMetrics,
  commandConsoleMessages,
  commandConsoleSessions,
  designIdeaBoardItems,
  designIdeaBoardLanes,
  entities,
  entityCardGridItems,
  entityFilterStats,
  entityFilterStatusOptions,
  entityFilterTypeOptions,
  fileActionListItems,
  filePreviewMeta,
  ideaBacklogItems,
  integrationSetupMetrics,
  kanbanColumns,
  mapInfoCardBadges,
  mapInfoCardRows,
  markdownDocumentMeta,
  mediaAssetItems,
  mediaAssetStats,
  metricGridItems,
  operationalDiagnosticDetails,
  operationalDiagnosticMetrics,
  paymentAccountStats,
  paymentHistoryRows,
  paymentMethods,
  payoutRows,
  processRunHistoryItems,
  projectDirectoryItems,
  projectSettingsStats,
  relationshipPickerItems,
  resourceIndexItems,
  resourceTransferTargets,
  schedulerControlItems,
  scoreTaskDocumentMarkdown,
  subscriptionCapacityMetrics,
  subscriptionCapacityRows,
  tableRows,
  tagInputItems,
  tagInputSuggestions,
  workBoardEpicOptions,
  workBoardProjectOptions,
  workBoardToolbarBadges,
  workItemCards,
  workItemComplexityOptions,
  workItemEpicOptions,
  workItemProjectOptions,
  workItemRoleOptions,
  workItemTraceNotes,
  workItemTraceRelationGroups,
  workItemTypeOptions,
  workflowCommandBarCommands,
} from "../../../demos/data";

// ---------------------------------------------------------------------------
// Local fixtures.
//
// Everything below covers panels that have no exported fixture in
// `src/demos/data.tsx`. Fixture-backed panels reuse those exports directly so
// the states tab and the demo tab stay on the same data.
// ---------------------------------------------------------------------------

const noop = () => undefined;

/** audit-timeline */
const auditTimelineEntries: AuditEntry[] = [
  {
    id: "claim",
    time: "14:02",
    kind: "lease",
    title: "Task issue-1042 claimed",
    actor: "agent-codex-maestro",
    tone: "info",
    detail: "Lease held for 45m",
  },
  {
    id: "push",
    time: "14:31",
    kind: "delivery",
    title: "Branch pushed and PR opened",
    actor: "agent-codex-maestro",
    tone: "success",
    meta: "PR #1007",
  },
  {
    id: "review",
    time: "15:04",
    kind: "disposition",
    title: "Review returned to engineer",
    actor: "agent-review-2",
    detail: "Missing regression coverage",
  },
];

const auditTimelineSeverityEntries: AuditEntry[] = [
  {
    id: "retry",
    time: "02:11",
    kind: "runner",
    title: "Runner retried after transport timeout",
    actor: "conveyor-worker-3",
    tone: "warning",
    detail: "Attempt 2 of 3",
  },
  {
    id: "fail",
    time: "02:19",
    kind: "runner",
    title: "Attempt abandoned — provider refused the session",
    actor: "conveyor-worker-3",
    tone: "danger",
  },
  {
    id: "halt",
    time: "02:20",
    kind: "fleet",
    title: "Dispatch halted for the project lane",
    actor: "maestro",
    tone: "critical",
    detail: "Manual release required",
  },
];

/** booking-widget-panel */
const bookingWidgetBadges: BookingWidgetPanelBadge[] = [
  { id: "instant", label: "Instant confirmation", tone: "success" },
  { id: "free-cancel", label: "Free cancellation", tone: "info" },
];

const bookingWidgetDetails: BookingWidgetPanelDetail[] = [
  { id: "duration", label: "Duration", value: "3 hours" },
  { id: "languages", label: "Languages", value: "Lithuanian, English" },
  { id: "from", label: "From", value: "EUR 42 per person", tone: "accent" },
];

/** checklist-editor-panel */
const checklistItems: ChecklistEditorItem[] = [
  { id: "spec", text: "SPEC.md written and reviewed", checked: true },
  { id: "tests", text: "Regression test covers the reported failure", checked: true },
  { id: "tokens", text: "No hardcoded colours in the diff", checked: false },
  { id: "docs", text: "Catalog entry updated", checked: false, meta: "blocked" },
];

/** command-bar */
const commandBarNavigation: CommandPaletteGroup = {
  id: "navigation",
  title: "Navigate",
  items: [
    { id: "board", label: "Work board", meta: "#/board" },
    { id: "agents", label: "Agents", meta: "#/agents" },
    { id: "projects", label: "Projects", meta: "#/projects" },
  ],
};

const commandBarVerbs: CommandVerb[] = [
  { id: "park", label: "Park", description: "Move the task out of the active lane" },
  { id: "release", label: "Release", description: "Drop the lease and requeue" },
];

/** compare-tray-panel */
const compareTrayItems: CompareTrayItem[] = [
  {
    id: "status-strip",
    title: "StatusStrip",
    meta: "layout",
    description: "Live signal rail with freshness and capacity tones.",
    preview: <Badge tone="success">healthy</Badge>,
    previewLabel: "StatusStrip preview",
    removeLabel: "Unpin StatusStrip",
    onRemove: noop,
  },
  {
    id: "metric-grid",
    title: "MetricGrid",
    meta: "data",
    description: "Label / value / detail tile grid for operational metrics.",
    preview: <Badge tone="info">4 tiles</Badge>,
    previewLabel: "MetricGrid preview",
    removeLabel: "Unpin MetricGrid",
    onRemove: noop,
  },
];

const compareTrayPinAction: CompareTrayAction = {
  label: "Pin this component",
  activeLabel: "Pinned",
  onClick: noop,
};

/** component-catalog-panel */
const componentCatalogItems: ComponentCatalogItem[] = [
  { id: "button", label: "Button", meta: "primitives", active: true, onSelect: noop },
  { id: "data-table", label: "DataTable", meta: "data", onSelect: noop },
  { id: "kanban-board", label: "KanbanBoard", meta: "data", onSelect: noop },
  { id: "status-strip", label: "StatusStrip", meta: "layout", onSelect: noop },
];

/** component-playground-panel */
const playgroundControls: ComponentPlaygroundControl[] = [
  {
    name: "variant",
    label: "Variant",
    kind: "enum",
    options: [
      { value: "primary", label: "Primary" },
      { value: "ghost", label: "Ghost" },
    ],
  },
  { name: "disabled", label: "Disabled", kind: "boolean" },
  { name: "label", label: "Label", kind: "string", placeholder: "Continue" },
];

const playgroundValues: ComponentPlaygroundValues = {
  variant: "primary",
  disabled: false,
  label: "Continue",
};

/** component-review-panel */
const componentReviewVariants: ComponentReviewVariant[] = [
  {
    id: "enabled",
    title: "Enabled",
    description: "Default affordance.",
    preview: <Button>Continue</Button>,
  },
  {
    id: "disabled",
    title: "Disabled",
    description: "Command unavailable.",
    preview: <Button disabled>Continue</Button>,
  },
];

const componentReviewCanvasSizes: ComponentReviewCanvasSize[] = [
  { id: "sm", label: "Narrow", maxWidth: 360 },
  { id: "lg", label: "Wide", maxWidth: 880 },
];

const componentReviewTabs: ComponentReviewTab[] = [
  {
    id: "notes",
    label: "Review notes",
    items: [
      { id: "tokens", body: "Uses shared tone tokens only." },
      { id: "focus", body: "Focus ring survives the disabled state." },
    ],
  },
  {
    id: "risks",
    label: "Risks",
    emptyLabel: "No open risks recorded for this component.",
  },
];

/** data-table */
type CatalogTableRow = (typeof tableRows)[number];

const dataTableColumns: DataTableColumn<CatalogTableRow>[] = [
  { id: "id", header: "Entity", accessor: (row) => row.id, rowHeader: true },
  { id: "type", header: "Type", accessor: (row) => row.type },
  { id: "status", header: "Status", accessor: (row) => row.status },
  { id: "owner", header: "Owner", accessor: (row) => row.owner },
  { id: "load", header: "Load", accessor: (row) => row.load, align: "right" },
];

/** design-idea-board-panel */
const designIdeaBoardBlockedItems: DesignIdeaBoardItem[] = [
  {
    id: "blocked-density",
    title: "Density scope for nested boards",
    laneId: designIdeaBoardLanes[0]?.id ?? "intake",
    note: "Needs the shared DensityScope before the board can inherit it.",
    priority: "High",
    ownerBoundary: "Owner decides whether boards inherit page density.",
    blockers: ["DensityScope not adopted", "No owner decision recorded"],
  },
];

/** discovery-cloud-panel */
const discoveryCloudGroups: DiscoveryCloudGroup[] = [
  {
    id: "patterns",
    label: "Patterns",
    items: [
      { id: "data", label: "Data, panels & boards", count: 72, size: "lg", onSelect: noop },
      { id: "forms", label: "Forms", count: 18, size: "md", onSelect: noop },
      { id: "auth", label: "Auth & account", count: 9, size: "sm", onSelect: noop },
    ],
  },
  {
    id: "apps",
    label: "Source apps",
    items: [
      { id: "score", label: "Score", count: 94, size: "lg", onSelect: noop },
      { id: "elitua", label: "eLitua", count: 46, size: "md", onSelect: noop },
    ],
  },
];

const discoveryCloudSelectedGroups: DiscoveryCloudGroup[] = [
  {
    id: "patterns",
    label: "Patterns",
    items: [
      { id: "data", label: "Data, panels & boards", count: 72, size: "lg", active: true, onSelect: noop },
      { id: "forms", label: "Forms", count: 18, size: "md", onSelect: noop },
      { id: "auth", label: "Auth & account", count: 0, size: "sm", disabled: true },
    ],
  },
];

const discoveryCloudEmptyGroups: DiscoveryCloudGroup[] = [
  { id: "patterns", label: "Patterns", items: [], emptyLabel: "No pattern matches this query." },
];

/** editable-form-panel */
const editableFormSections: EditableFormSection[] = [
  {
    id: "identity",
    title: "Identity",
    description: "Public-facing guide identity.",
    fields: [
      {
        id: "name",
        label: "Display name",
        required: true,
        control: <TextInputControl hideLabel id="editable-name" label="Display name" value="Raseiniai Magde" />,
      },
      {
        id: "slug",
        label: "Slug",
        hint: "Used in the public URL.",
        control: <TextInputControl hideLabel id="editable-slug" label="Slug" value="raseiniai-magde" />,
      },
    ],
  },
];

const editableFormInvalidSections: EditableFormSection[] = [
  {
    id: "identity",
    title: "Identity",
    fields: [
      {
        id: "name",
        label: "Display name",
        required: true,
        error: "A display name is required.",
        control: <TextInputControl hideLabel id="editable-name-invalid" label="Display name" value="" />,
      },
      {
        id: "slug",
        label: "Slug",
        error: "Slug is already taken.",
        control: <TextInputControl hideLabel id="editable-slug-invalid" label="Slug" value="raseiniai-magde" />,
      },
    ],
  },
];

/** entity-filter-panel */
const entityFilterControls: EntityFilterControl[] = [
  { id: "query", kind: "text", label: "Search", value: "", placeholder: "Name or key", onChange: noop },
  { id: "type", kind: "select", label: "Type", value: "", options: entityFilterTypeOptions, onChange: noop },
  { id: "status", kind: "select", label: "Status", value: "", options: entityFilterStatusOptions, onChange: noop },
];

const entityFilterActiveControls: EntityFilterControl[] = [
  { id: "query", kind: "text", label: "Search", value: "vilnius", placeholder: "Name or key", onChange: noop },
  { id: "type", kind: "select", label: "Type", value: entityFilterTypeOptions[1]?.value ?? "", options: entityFilterTypeOptions, onChange: noop },
  { id: "status", kind: "select", label: "Status", value: "", options: entityFilterStatusOptions, onChange: noop },
];

/** facet-filter-panel */
const facetFilterGroups: FacetFilterGroup[] = [
  {
    id: "category",
    label: "Category",
    options: [
      { id: "data", label: "Data", count: 72, onSelect: noop },
      { id: "layout", label: "Layout", count: 31, onSelect: noop },
      { id: "auth", label: "Auth", count: 9, onSelect: noop },
    ],
  },
  {
    id: "status",
    label: "Status",
    options: [
      { id: "catalogued", label: "Catalogued", count: 140, onSelect: noop },
      { id: "adopted", label: "Adopted", count: 12, onSelect: noop },
    ],
  },
];

const facetFilterSelectedGroups: FacetFilterGroup[] = [
  {
    id: "category",
    label: "Category",
    modeControl: { value: "all", onChange: noop },
    options: [
      { id: "data", label: "Data", count: 72, selected: true, onSelect: noop },
      { id: "layout", label: "Layout", count: 31, onSelect: noop },
      { id: "auth", label: "Auth", count: 0, disabled: true },
    ],
  },
  {
    id: "status",
    label: "Status",
    options: [
      { id: "catalogued", label: "Catalogued", count: 68, selected: true, onSelect: noop },
      { id: "adopted", label: "Adopted", count: 4, onSelect: noop },
    ],
  },
];

const facetFilterChips: FacetFilterChip[] = [
  { id: "category", label: "Category", value: "Data", onRemove: noop },
  { id: "status", label: "Status", value: "Catalogued", onRemove: noop },
];

const facetFilterEmptyGroups: FacetFilterGroup[] = [
  { id: "category", label: "Category", options: [], emptyLabel: "No facet values for this query." },
];

/** file-preview-panel + file-preview-dialog */
const markdownFileRecord: FilePreviewRecord = {
  id: "extraction-review",
  filename: "extraction-review.md",
  contentType: "text/markdown",
  sizeLabel: "18 KB",
  uploadedBy: "agent-codex-maestro",
  createdAtLabel: "2026-08-14",
  downloadHref: "#/files/extraction-review.md",
};

const binaryFileRecord: FilePreviewRecord = {
  id: "capacity-export",
  filename: "capacity-export.xlsx",
  contentType: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  sizeLabel: "1.4 MB",
  uploadedBy: "maestro",
  createdAtLabel: "2026-08-21",
  downloadHref: "#/files/capacity-export.xlsx",
};

/** geocoding-control-panel */
const geocodingSources: GeocodingControlSource[] = [
  { id: "google", label: "Google", selected: true, onSelect: noop },
  { id: "osm", label: "OpenStreetMap", onSelect: noop },
  { id: "manual", label: "Manual", onSelect: noop },
];

const geocodingCandidates: GeocodingControlCandidate[] = [
  {
    id: "vilnius-old-town",
    label: "Vilnius Old Town",
    description: "Vilniaus m. sav., Lithuania",
    coordinates: "54.6805, 25.2871",
    meta: [{ id: "confidence", label: "High confidence", tone: "success" }],
    selected: true,
    onSelect: noop,
  },
  {
    id: "vilnius-airport",
    label: "Vilnius Airport",
    description: "Rodūnios kelias 10A, Vilnius",
    coordinates: "54.6394, 25.2858",
    meta: [{ id: "confidence", label: "Medium confidence", tone: "warning" }],
    onSelect: noop,
  },
];

/** integration-setup-panel */
const integrationSetupSections: IntegrationSetupSection[] = [
  {
    id: "credentials",
    title: "Credentials",
    description: "Stored by the product, never read by the shared component.",
    fields: [
      {
        id: "access-key",
        label: "Access key",
        required: true,
        control: <TextInputControl hideLabel id="integration-access-key" label="Access key" type="password" value="key-live-8f2b" />,
      },
    ],
    toggles: [
      { id: "sync", label: "Nightly product sync", description: "Pull availability every night at 02:00.", checked: true, onChange: noop },
    ],
  },
];

/** kanban-board */
const kanbanEmptyColumns: KanbanColumn[] = kanbanColumns.map((column) => ({
  ...column,
  tasks: [],
  emptyLabel: "No work in this lane.",
}));

/** map-control-panel */
const mapControlActions: MapControlPanelAction[] = [
  { id: "zoom-in", label: "Zoom in", onSelect: noop },
  { id: "zoom-out", label: "Zoom out", onSelect: noop },
  { id: "reset", label: "Reset view", onSelect: noop },
  { id: "cluster", label: "Cluster markers", onSelect: noop },
];

const mapControlActiveActions: MapControlPanelAction[] = [
  { id: "zoom-in", label: "Zoom in", onSelect: noop },
  { id: "zoom-out", label: "Zoom out", onSelect: noop },
  { id: "reset", label: "Reset view", onSelect: noop },
  { id: "cluster", label: "Cluster markers", active: true, onSelect: noop },
];

const mapControlStats: MapControlPanelStat[] = [
  { id: "markers", label: "Markers", value: "128" },
  { id: "zoom", label: "Zoom", value: "12" },
];

/** metric-grid */
const metricGridBreachItems: MetricGridItem[] = [
  { id: "queue", label: "Ready work", value: "0", detail: "Queue drained", tone: "warning" },
  { id: "failures", label: "Failed runs", value: "6", detail: "Last hour", tone: "danger" },
  { id: "capacity", label: "Day capacity", value: "97%", detail: "Resets in 42m", tone: "warning" },
];

/** mode-control-panel */
const modeControlOptions: ModeControlOption[] = [
  { value: "manual", label: "Manual" },
  { value: "assisted", label: "Assisted" },
  { value: "automatic", label: "Automatic" },
];

const modeControlToggles: ModeControlToggle[] = [
  { id: "autosync", label: "Auto-sync coordinates", description: "Re-geocode on every address change.", checked: true, onChange: noop },
  { id: "notify", label: "Notify owner on change", checked: false, onChange: noop },
];

/** preview-matrix-panel */
const previewMatrixColumns: PreviewMatrixColumn[] = [
  { id: "light", label: "Light", description: "Default theme" },
  { id: "dark", label: "Dark", description: "Dark theme" },
];

const previewMatrixRows: PreviewMatrixRow[] = [
  {
    id: "button-enabled",
    itemLabel: "Button",
    variantLabel: "Enabled",
    cells: [
      { columnId: "light", preview: <Button>Continue</Button>, supported: true },
      { columnId: "dark", preview: <Button>Continue</Button>, supported: true },
    ],
  },
  {
    id: "badge-danger",
    itemLabel: "Badge",
    variantLabel: "Danger",
    cells: [
      { columnId: "light", preview: <Badge tone="danger">failed</Badge>, supported: true },
      { columnId: "dark", preview: <Badge tone="danger">failed</Badge>, supported: true },
    ],
  },
];

const previewMatrixPartialRows: PreviewMatrixRow[] = [
  {
    id: "button-enabled",
    itemLabel: "Button",
    variantLabel: "Enabled",
    cells: [{ columnId: "light", preview: <Button>Continue</Button>, supported: true }],
  },
  {
    id: "marker-cluster",
    itemLabel: "MapMarkerPin",
    variantLabel: "Cluster",
    cells: [
      { columnId: "light", preview: <MapMarkerPin kind="cluster" count={12} />, supported: true },
      {
        columnId: "dark",
        preview: null,
        supported: false,
        statusLabel: "Not reviewed in dark",
        tone: "warning",
      },
    ],
  },
];

/** process-run-history-panel */
const processRunInFlight: ProcessRunHistoryItem[] = [
  {
    id: "run-current",
    title: "spec-guard",
    startedAt: "16:02:11",
    exitCode: null,
    command: "npm run spec-guard -- --since origin/main",
    summary: "Scanning 71 changed catalog entries.",
  },
  ...processRunHistoryItems.slice(0, 2),
];

/** project-profile-panel */
const projectProfileFields: ProjectProfileField[] = [
  { id: "key", label: "Key", value: "UI" },
  { id: "repo", label: "Repository", value: "emibs-ui-lib", href: "#/projects/ui" },
  { id: "owner", label: "Delivery owner", value: "Maestro" },
  { id: "updated", label: "Updated", value: "12 minutes ago" },
];

const projectProfileChecklist: ProjectProfileChecklistItem[] = [
  { id: "spec", text: "Every catalogued component has a SPEC", checked: true },
  { id: "states", text: "Every data entry has explicit states", checked: false, meta: "in progress" },
  { id: "tokens", text: "No hardcoded colours remain", checked: true },
];

/** project-settings-panel */
const projectSettingsSummary: ProjectSettingsSummaryDigest = {
  title: "Daily digest",
  description: "Sent to the delivery owner each morning.",
  updatedAt: "Updated 2026-08-28",
  recipientControl: {
    label: "Recipient",
    required: true,
    control: <TextInputControl hideLabel id="digest-recipient-input" label="Recipient" type="email" value="owner@example.com" />,
  },
  titleTemplateControl: {
    label: "Subject template",
    control: <TextInputControl hideLabel id="digest-title-input" label="Subject template" value="[{project}] daily digest" />,
  },
  log: "2026-08-28 06:00 delivered to owner@example.com",
  logEmptyLabel: "No digest has been sent yet.",
};

const projectSettingsConfig: ProjectSettingsConfigDocument = {
  title: "Public config",
  description: "Served to the portal at build time.",
  editor: (
    <TextareaControl
      hideLabel
      id="project-config-editor"
      label="Public config"
      rows={6}
      value={'{\n  "publicName": "UI Framework",\n  "showRoadmap": true\n}'}
    />
  ),
  meta: [{ id: "size", label: "Size", value: "612 bytes" }],
};

const projectSettingsInvalidConfig: ProjectSettingsConfigDocument = {
  ...projectSettingsConfig,
  editor: (
    <TextareaControl
      hideLabel
      id="project-config-editor-invalid"
      label="Public config"
      rows={6}
      value={'{\n  "publicName": "UI Framework",\n  "showRoadmap": tru\n}'}
    />
  ),
  validation: "Unexpected token at line 3 — the document was not saved.",
};

const projectSettingsNotices: ProjectSettingsNotice[] = [
  {
    id: "digest",
    title: "Digest delivery is enabled",
    description: "The next run is scheduled for 06:00 UTC.",
    tone: "info",
  },
];

/** record-detail-panel */
const recordDetailFields: RecordDetailField[] = [
  { id: "id", label: "Task", value: "issue-1042" },
  { id: "state", label: "State", value: "In review" },
  { id: "actor", label: "Actor", value: "agent-codex-maestro" },
  { id: "pr", label: "Pull request", value: "#1007", href: "#/pulls/1007" },
];

const recordDetailSections: RecordDetailSection[] = [
  {
    id: "acceptance",
    title: "Acceptance",
    fields: [
      { id: "criteria", label: "Criteria", value: "All 71 data entries carry states" },
      { id: "evidence", label: "Evidence", value: "tsc and vitest both pass" },
    ],
  },
];

const recordDetailSparseSections: RecordDetailSection[] = [
  {
    id: "acceptance",
    title: "Acceptance",
    emptyLabel: "No acceptance criteria were recorded for this task.",
  },
];

/** resource-transfer-dialog */
const resourceTransferResource: ResourceTransferDialogResource = {
  title: "extraction-review.md",
  subtitle: "Attached to issue-1042",
  meta: [
    { id: "size", label: "18 KB" },
    { id: "kind", label: "Markdown", tone: "info" },
  ],
};

/** schedule-editor-dialog */
const scheduleEditorMeta: ScheduleEditorDialogMeta[] = [
  { id: "last-run", label: "Last run", value: "2026-08-29 02:00" },
  { id: "next-run", label: "Next run", value: "2026-08-30 02:00" },
];

const scheduleEditorChecks: ScheduleEditorDialogCheck[] = [
  { id: "suspended", label: "Suspended", checked: false, hint: "Keeps the job registered without running it.", onChange: noop },
];

const scheduleEditorFields: ScheduleEditorDialogField[] = [
  { id: "runner", label: "Runner", value: "conveyor-worker-3", control: "text" },
  {
    id: "lane",
    label: "Lane",
    value: "nightly",
    control: "select",
    options: [
      { value: "nightly", label: "Nightly" },
      { value: "hourly", label: "Hourly" },
    ],
  },
];

/** theme-audit-panel */
const themeAuditMetrics: ThemeAuditMetric[] = [
  { id: "tokens", label: "Tokens referenced", value: "48", tone: "success" },
  { id: "gaps", label: "Hardcoded values", value: "0", tone: "success" },
  { id: "surfaces", label: "Surfaces audited", value: "12" },
];

const themeAuditGapMetrics: ThemeAuditMetric[] = [
  { id: "tokens", label: "Tokens referenced", value: "44", tone: "info" },
  { id: "gaps", label: "Hardcoded values", value: "3", tone: "danger" },
  { id: "surfaces", label: "Surfaces audited", value: "12" },
];

const themeAuditTokenGroups: ThemeAuditTokenGroup[] = [
  {
    id: "surface",
    label: "Surface",
    tokens: [
      { id: "bg", label: "--surface-1", value: "panel background" },
      { id: "border", label: "--border-subtle", value: "hairline" },
    ],
  },
  {
    id: "status",
    label: "Status",
    tokens: [
      { id: "ok", label: "--status-ok", value: "healthy signal" },
      { id: "warn", label: "--status-warn", value: "degraded signal" },
    ],
  },
];

const themeAuditGaps: ThemeAuditGap[] = [
  { id: "hex-border", label: "Literal border colour on the lane header", detail: "ui-board__lane-head", tone: "danger" },
  { id: "rgba-shadow", label: "Literal shadow colour on the pinned card", detail: "ui-board__card--pinned", tone: "warning" },
];

const themeAuditNotes: ThemeAuditNote[] = [
  { id: "handoff", children: "Adoption is blocked until every gap resolves to a token." },
];

/** theme-export-panel */
const themeExportFormats: ThemeExportFormat[] = [
  { id: "css", label: "CSS custom properties", description: "A :root block for emibs-theme/1." },
  { id: "json", label: "JSON", description: "Portable token map." },
  { id: "figma", label: "Figma tokens", description: "Not generated for this theme yet.", disabled: true },
];

const themeExportPreview = ':root {\n  --surface-1: …;\n  --status-ok: …;\n}';

/** theme-lab-panel */
const themeLabPrompt: ThemeLabTextAreaControl = {
  id: "theme-lab-prompt",
  label: "Prompt",
  value: "A calm operator console theme with a warm neutral surface and a single cool accent.",
  rows: 3,
  onChange: noop,
};

const themeLabProposal: ThemeLabProposal = {
  name: "Warm console",
  rationale: "Neutral warm surfaces with one cool accent keep status colour the only saturated signal.",
  badges: [{ id: "model", label: "claude-opus-4-8", tone: "info" }],
  swatchGroups: [
    {
      id: "surface",
      label: "Surface",
      swatches: [
        { id: "surface-1", label: "--surface-1", value: "warm neutral 98" },
        { id: "surface-2", label: "--surface-2", value: "warm neutral 95" },
      ],
    },
  ],
  guardrails: [
    { id: "body", label: "Body text contrast", value: "12.4:1", tone: "success" },
    { id: "muted", label: "Muted text contrast", value: "4.7:1", tone: "warning", detail: "Passes AA, fails AAA" },
  ],
};

/** theme-preview-canvas */
const themePreviewGeneratedSurfaces: ThemePreviewCanvasSurface[] = [
  { id: "light", label: "Light", badge: "generated", badgeTone: "info" },
  { id: "dark", label: "Dark", badge: "generated", badgeTone: "info" },
];

const themePreviewCompareSurfaces: ThemePreviewCanvasSurface[] = [
  { id: "current", label: "Current theme", badge: "in use", badgeTone: "neutral" },
  { id: "proposed", label: "Proposed theme", badge: "preview", badgeTone: "accent" },
];

const themePreviewFixture = (
  <div>
    <Badge tone="success">healthy</Badge> <Button>Continue</Button>
  </div>
);

/** work-item-planning-panel */
const workItemDraft: WorkItemDraft = {
  title: "Author state previews for the data category",
  type: "task",
  projectKey: "UI",
  points: "5",
  priority: "major",
  deliveryRole: "engineer",
  complexity: "moderate",
  assignee: "agent-codex-maestro",
  parentEpic: "issue-980",
  agentAllowed: true,
  description: "Every catalogued data entry needs an explicit states facet.",
};

const workItemTriage: WorkItemTriageDraft = {
  points: "5",
  suggestedActor: "agent-codex-maestro",
  note: "Split from the catalog-completion epic.",
  makeReady: true,
};

/** work-item-relation-editor-panel */
const relationEditorFields: WorkItemRelationEditorField[] = [
  {
    id: "blocked-by",
    label: "Blocked by",
    value: "",
    tags: tagInputItems,
    suggestions: tagInputSuggestions,
    placeholder: "issue-…",
    hint: "The consuming app prevents self-links and duplicates.",
    onValueChange: noop,
    onAdd: noop,
    onRemove: noop,
  },
  {
    id: "relates-to",
    label: "Relates to",
    value: "issue-",
    tags: [],
    suggestions: tagInputSuggestions,
    emptyLabel: "No related work items yet.",
    onValueChange: noop,
    onAdd: noop,
    onRemove: noop,
  },
];

/** workflow-map-panel */
const workflowMapStages: WorkflowMapStage[] = [
  {
    id: "ready",
    label: "Ready",
    count: 6,
    status: "flowing",
    statusTone: "success",
    items: [
      { id: "issue-1042", title: "Author data-category states", owner: "unassigned", status: "ready", statusTone: "info" },
    ],
  },
  {
    id: "in-progress",
    label: "In progress",
    count: 3,
    status: "flowing",
    statusTone: "success",
    items: [
      { id: "issue-1039", title: "Prop docs for the data category", owner: "agent-mini-worker", status: "claimed", statusTone: "accent" },
    ],
  },
  {
    id: "review",
    label: "Review",
    count: 4,
    status: "backing up",
    statusTone: "warning",
    items: [
      {
        id: "issue-1031",
        title: "Usage snippets for feedback panels",
        owner: "agent-review-2",
        status: "third round",
        statusTone: "warning",
        recovery: "Escalate to architect",
        recoveryTone: "danger",
      },
    ],
  },
  { id: "done", label: "Done", count: 0, items: [], emptyLabel: "Nothing merged in this window." },
];

// ---------------------------------------------------------------------------
// Local helper components.
//
// Only the form entries need hooks; every other state renders the real
// component with plain props.
// ---------------------------------------------------------------------------

type FormPanelStateDemoValues = {
  displayName: string;
  email: string;
};

function FormPanelStateDemo({
  readOnly = false,
  submitError,
}: {
  readOnly?: boolean;
  submitError?: string;
}) {
  const form = useForm<FormPanelStateDemoValues>({
    defaultValues: { displayName: "Raseiniai Magde", email: "guide@example.com" },
  });

  return (
    <FormPanel
      form={form}
      idPrefix={readOnly ? "state-form-readonly" : submitError ? "state-form-error" : "state-form-ready"}
      onSubmit={noop}
      eyebrow="Forms engine"
      title="Guide profile"
      subtitle="A typed useForm store rendered through the EditableFormPanel layout."
      messages={submitError ? [{ id: "submit", tone: "danger", children: submitError }] : undefined}
      sections={[
        {
          id: "identity",
          title: "Identity",
          fields: [
            { name: "displayName", label: "Display name", required: true, readOnly, disabled: readOnly },
            { name: "email", label: "Email", type: "email", required: true, readOnly, disabled: readOnly },
          ],
        },
      ]}
    />
  );
}

const emptyFormBuilderSpec: FormSpec = { sections: [], fields: [] };

// A plausible product narrowing: no file control, because this product has
// nowhere to put an upload, and no free-text tags.
const narrowedFormBuilderTypes: FieldType[] = ["text", "textarea", "select", "checkbox", "date"];

// ---------------------------------------------------------------------------
// States, keyed by catalog entry id (see src/catalog/metadata.ts).
// ---------------------------------------------------------------------------

export const dataStates: Record<string, StatePreview[]> = {
  "accessibility-audit-panel": [
    {
      id: "running",
      label: "Running",
      description: "A running audit keeps the panel footprint while refusing to report a result it does not have yet.",
      render: () => (
        <AccessibilityAuditPanel
          eyebrow="Accessibility"
          title="Axe audit"
          status="running"
          statusLabel="Scanning the current canvas…"
        />
      ),
    },
    {
      id: "pass",
      label: "Complete — pass",
      description: "A clean run reports its pass count so an empty violation list never reads as an audit that never ran.",
      render: () => (
        <AccessibilityAuditPanel
          eyebrow="Accessibility"
          title="Axe audit"
          status="complete"
          passCount={38}
          notes={accessibilityAuditNotes}
          emptyLabel="No violations were returned by this run."
        />
      ),
    },
    {
      id: "violations",
      label: "Complete — issues",
      description: "Each violation carries its own severity, rule id, and target selectors so triage never needs the console.",
      render: () => (
        <AccessibilityAuditPanel
          eyebrow="Accessibility"
          title="Axe audit"
          status="complete"
          passCount={31}
          notes={accessibilityAuditNotes}
          violations={accessibilityAuditViolations}
        />
      ),
    },
    {
      id: "unavailable",
      label: "Unavailable",
      description: "An engine the product could not start stays neutral and never reads as a pass.",
      render: () => (
        <AccessibilityAuditPanel
          eyebrow="Accessibility"
          title="Axe audit"
          status="unavailable"
          statusLabel="The audit engine is not loaded on this host."
        />
      ),
    },
  ],

  "activity-dashboard": [
    {
      id: "live",
      label: "Live",
      description: "Queue counts, metrics, and the recent-work feed read from one poll of caller-supplied data.",
      render: () => (
        <ActivityDashboard
          eyebrow="Operator"
          title="Fleet activity"
          status="Live"
          statusTone="success"
          queues={activityDashboardQueues}
          metrics={activityDashboardMetrics}
          items={activityDashboardItems}
        />
      ),
    },
    {
      id: "degraded",
      label: "Degraded",
      description: "A transient poll failure surfaces beside the last known counts instead of blanking the dashboard.",
      render: () => (
        <ActivityDashboard
          eyebrow="Operator"
          title="Fleet activity"
          status="Stale"
          statusTone="warning"
          queues={activityDashboardQueues}
          metrics={activityDashboardMetrics}
          items={activityDashboardItems}
          error="The activity feed could not be refreshed — showing the last successful poll."
        />
      ),
    },
    {
      id: "quiet",
      label: "Quiet",
      description: "An idle window keeps the queue and metric chrome so an empty feed reads as calm, not broken.",
      render: () => (
        <ActivityDashboard
          eyebrow="Operator"
          title="Fleet activity"
          status="Idle"
          statusTone="neutral"
          queues={activityDashboardQueues}
          metrics={activityDashboardMetrics}
          items={[]}
          emptyLabel="No work has moved in the last hour."
        />
      ),
    },
  ],

  "actor-access-matrix": [
    {
      id: "editable",
      label: "Editable",
      description: "Role selects and grant checkboxes become interactive only once the product supplies both change callbacks.",
      render: () => (
        <ActorAccessMatrix
          eyebrow="Access"
          title="Project actors"
          contextLabel="Project"
          contextValue="UI"
          actors={actorAccessRows}
          onRoleChange={noop}
          onGrantChange={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The header and context stay readable so the route keeps its identity while rows resolve.",
      render: () => (
        <ActorAccessMatrix
          eyebrow="Access"
          title="Project actors"
          contextLabel="Project"
          contextValue="UI"
          actors={[]}
          loading
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed access read refuses to render a partial grant table that could be mistaken for the truth.",
      render: () => (
        <ActorAccessMatrix
          eyebrow="Access"
          title="Project actors"
          contextLabel="Project"
          contextValue="UI"
          actors={[]}
          error="Access could not be read for this project."
        />
      ),
    },
  ],

  "admin-home-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Metrics, notices, and navigation cards share one landing surface without any of them owning routing.",
      render: () => (
        <AdminHomePanel
          eyebrow="Admin"
          title="Operator home"
          subtitle="Everything an operator needs on the first screen."
          status="All systems nominal"
          statusTone="success"
          metrics={adminHomeMetrics}
          notices={adminHomeNotices}
          actionItems={adminHomeActions}
          onActionSelect={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The landing shell holds its footprint so the page does not reflow when the first payload lands.",
      render: () => (
        <AdminHomePanel
          eyebrow="Admin"
          title="Operator home"
          loading
          loadingLabel="Loading the operator summary…"
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed summary read shows the failure instead of stale metric cards from the previous session.",
      render: () => (
        <AdminHomePanel
          eyebrow="Admin"
          title="Operator home"
          status="Degraded"
          statusTone="danger"
          error="The operator summary could not be loaded."
        />
      ),
    },
  ],

  "admin-record-editor-panel": [
    {
      id: "editing",
      label: "Editing",
      description: "The back control, notices, and footer stay pinned around a product-supplied form body.",
      render: () => (
        <AdminRecordEditorPanel
          eyebrow="Admin"
          title="Edit guide"
          subtitle="raseiniai-magde"
          backLabel="Back to guides"
          backHref="#/admin/guides"
          status="Draft"
          statusTone="warning"
          meta={adminRecordEditorMeta}
          notices={adminRecordEditorNotices}
          onSubmit={(event) => event.preventDefault()}
          actions={<Button type="submit">Save</Button>}
        >
          <TextInputControl id="record-editor-name" label="Display name" value="Raseiniai Magde" />
        </AdminRecordEditorPanel>
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The back control stays reachable while the record loads so the route is never a dead end.",
      render: () => (
        <AdminRecordEditorPanel
          eyebrow="Admin"
          title="Edit guide"
          backLabel="Back to guides"
          backHref="#/admin/guides"
          loading
          loadingLabel="Loading the record…"
        />
      ),
    },
    {
      id: "missing",
      label: "Record missing",
      description: "A record the route cannot resolve says so explicitly rather than presenting an empty form to save.",
      render: () => (
        <AdminRecordEditorPanel
          eyebrow="Admin"
          title="Edit guide"
          backLabel="Back to guides"
          backHref="#/admin/guides"
          empty
          emptyLabel="No guide exists for this id — it may have been deleted."
        />
      ),
    },
  ],

  "agent-management-panel": [
    {
      id: "editable",
      label: "Editable",
      description: "Runner selects and enablement checkboxes are live only where the product supplied the matching callback.",
      render: () => (
        <AgentManagementPanel
          eyebrow="Fleet"
          title="Agent administration"
          status="14 agents"
          statusTone="info"
          metrics={agentManagementMetrics}
          agents={agentManagementAgents}
          runners={agentManagementRunners}
          onAgentEnabledChange={noop}
          onAgentRunnerChange={noop}
          onRunnerEnabledChange={noop}
        />
      ),
    },
    {
      id: "read-only",
      label: "Read-only",
      description: "Without change callbacks every control renders disabled, so a viewer can never appear to hold write access.",
      render: () => (
        <AgentManagementPanel
          eyebrow="Fleet"
          title="Agent administration"
          status="Read-only"
          statusTone="neutral"
          metrics={agentManagementMetrics}
          agents={agentManagementAgents}
          runners={agentManagementRunners}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "Capacity and availability cells stay blank rather than showing the previous window's numbers.",
      render: () => (
        <AgentManagementPanel eyebrow="Fleet" title="Agent administration" agents={[]} loading />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed roster read never falls back to a partial agent list that could authorise the wrong dispatch.",
      render: () => (
        <AgentManagementPanel
          eyebrow="Fleet"
          title="Agent administration"
          agents={[]}
          error="The agent roster could not be read from the control plane."
        />
      ),
    },
  ],

  "agent-profile-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Capacity metrics, configuration fields, and release grants read from one agent record.",
      render: () => (
        <AgentProfilePanel
          eyebrow="Fleet"
          title="agent-codex-maestro"
          agentId="agent-codex-maestro"
          status="Running"
          statusTone="success"
          metrics={agentProfileMetrics}
          grants={agentProfileGrants}
          fields={agentProfileFields}
          onFormFieldChange={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "Identity chrome survives the load so the route keeps naming the agent it is about to show.",
      render: () => (
        <AgentProfilePanel
          eyebrow="Fleet"
          title="agent-codex-maestro"
          agentId="agent-codex-maestro"
          loading
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed profile read shows no grants at all rather than a subset that understates real access.",
      render: () => (
        <AgentProfilePanel
          eyebrow="Fleet"
          title="agent-codex-maestro"
          agentId="agent-codex-maestro"
          status="Unreachable"
          statusTone="danger"
          error="The agent profile could not be read."
        />
      ),
    },
  ],

  "audit-timeline": [
    {
      id: "run",
      label: "Delivery run",
      description: "Ticks, mono actors, and the fixed time column keep the sequence readable as a single spine.",
      render: () => <AuditTimeline ariaLabel="Delivery audit" entries={auditTimelineEntries} />,
    },
    {
      id: "severity",
      label: "Escalating severity",
      description: "Warning, danger, and critical ticks stay distinguishable from each other and from an untoned entry.",
      render: () => <AuditTimeline ariaLabel="Runner audit" entries={auditTimelineSeverityEntries} />,
    },
    {
      id: "empty",
      label: "Empty",
      description: "A record with no entries states that plainly instead of collapsing to nothing.",
      render: () => (
        <AuditTimeline
          ariaLabel="Delivery audit"
          entries={[]}
          emptyLabel="No audit entries have been recorded for this task."
        />
      ),
    },
  ],

  "auto-form": [
    {
      id: "ready",
      label: "Ready",
      description: "Sections, controls, and required markers are derived from the spec alone — no per-field JSX.",
      render: () => (
        <AutoForm
          spec={contactRegistrationSeedSpec}
          onSubmit={noop}
          eyebrow="Forms"
          title="Contact registration"
          submitLabel="Register"
        />
      ),
    },
    {
      id: "server-error",
      label: "Server error",
      description: "A rejected submit surfaces the server's message without discarding what the registrant typed.",
      render: () => (
        <AutoForm
          spec={contactRegistrationSeedSpec}
          onSubmit={noop}
          eyebrow="Forms"
          title="Contact registration"
          submitLabel="Register"
          messages={[{ id: "server", tone: "danger", children: "That email is already registered." }]}
        />
      ),
    },
    {
      id: "submitted",
      label: "Submitted",
      description: "Confirmation is announced through a live region rather than replacing the form silently.",
      render: () => (
        <AutoForm
          spec={contactRegistrationSeedSpec}
          onSubmit={noop}
          eyebrow="Forms"
          title="Contact registration"
          submitLabel="Register"
          successMessage="Registration received — a confirmation email is on its way."
        />
      ),
    },
  ],

  "booking-widget-panel": [
    {
      id: "available",
      label: "Available",
      description: "The provider widget occupies its slot while availability copy stays product-owned.",
      render: () => (
        <BookingWidgetPanel
          eyebrow="Book"
          title="Vilnius Old Town walking tour"
          provider="Bókun"
          badges={bookingWidgetBadges}
          details={bookingWidgetDetails}
          status={{ label: "Live availability", detail: "Updated 2 minutes ago", tone: "success" }}
          widgetLabel="Booking widget"
          widget={<div>Provider booking widget renders here.</div>}
        />
      ),
    },
    {
      id: "consent-pending",
      label: "Consent pending",
      description: "The panel keeps its full layout while the provider script is still gated behind cookie consent.",
      render: () => (
        <BookingWidgetPanel
          eyebrow="Book"
          title="Vilnius Old Town walking tour"
          provider="Bókun"
          badges={bookingWidgetBadges}
          details={bookingWidgetDetails}
          status={{ label: "Awaiting consent", tone: "warning" }}
          widgetLabel="Booking widget"
          emptyWidgetLabel="Accept marketing cookies to load the booking widget."
          consentNotice="The booking widget is provided by Bókun and sets its own cookies."
        />
      ),
    },
    {
      id: "unavailable",
      label: "Unavailable",
      description: "A provider outage falls back to a contact route instead of leaving a dead booking frame.",
      render: () => (
        <BookingWidgetPanel
          eyebrow="Book"
          title="Vilnius Old Town walking tour"
          provider="Bókun"
          details={bookingWidgetDetails}
          status={{ label: "Booking unavailable", detail: "Provider did not respond", tone: "danger" }}
          fallback="Email hello@example.com to reserve a place while the provider is unreachable."
        />
      ),
    },
  ],

  "checklist-editor-panel": [
    {
      id: "editing",
      label: "Editing",
      description: "Text, checked state, and removal all emit item ids; the panel never mutates the list itself.",
      render: () => (
        <ChecklistEditorPanel
          eyebrow="Definition of done"
          title="Delivery checklist"
          items={checklistItems}
          status="2 of 4 complete"
          statusTone="info"
          onAddItem={noop}
          onItemTextChange={noop}
          onItemCheckedChange={noop}
          onRemoveItem={noop}
        />
      ),
    },
    {
      id: "read-only",
      label: "Read-only",
      description: "A reviewer sees the same rows with every edit affordance withdrawn, not merely visually muted.",
      render: () => (
        <ChecklistEditorPanel
          eyebrow="Definition of done"
          title="Delivery checklist"
          items={checklistItems}
          status="Locked after approval"
          statusTone="neutral"
          readOnly
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "An empty checklist keeps the add affordance so the first criterion is one click away.",
      render: () => (
        <ChecklistEditorPanel
          eyebrow="Definition of done"
          title="Delivery checklist"
          items={[]}
          emptyLabel="No criteria yet — add the first one."
          onAddItem={noop}
        />
      ),
    },
  ],

  "command-bar": [
    {
      id: "healthy",
      label: "Healthy signals",
      description: "The bar keeps the command field reachable while the live status slot reports a fresh, healthy fleet.",
      render: () => (
        <CommandBar
          navigation={commandBarNavigation}
          navigate={noop}
          onVerb={noop}
          entityHref={(id) => `#/issues/${id}`}
          verbs={commandBarVerbs}
          brand="Score"
          statusStrip={
            <StatusStrip
              ariaLabel="Fleet signals"
              items={[
                { id: "tick", label: "tick", value: "12s", variant: "signal", freshness: "fresh" },
                { id: "capacity", label: "capacity", value: "82%", variant: "signal", signal: "ok" },
              ]}
            />
          }
        />
      ),
    },
    {
      id: "degraded",
      label: "Degraded signals",
      description: "A stale fleet changes the status slot only — the command field never becomes unreachable because telemetry lapsed.",
      render: () => (
        <CommandBar
          navigation={commandBarNavigation}
          navigate={noop}
          onVerb={noop}
          entityHref={(id) => `#/issues/${id}`}
          verbs={commandBarVerbs}
          brand="Score"
          statusStrip={
            <StatusStrip
              ariaLabel="Fleet signals"
              items={[
                { id: "tick", label: "tick", value: "9m", variant: "signal", freshness: "stale" },
                { id: "capacity", label: "capacity", value: "41%", variant: "signal", signal: "warn" },
              ]}
            />
          }
        />
      ),
    },
    // The three query modes of the one palette (uif/issue-4678). Each is
    // reached through props alone — controlled `open` + `query` — because a
    // StatePreview cannot type into a field or press ⌘K. `placement="contained"`
    // and `autoFocus={false}` keep the palette in flow and stop three previews
    // on one page fighting over focus, matching the command-palette states.
    {
      id: "verb-query",
      label: "Verb query",
      description:
        'A `> ` query switches the palette to the verb grammar: the Actions group is offered above navigation, and each item stays disabled until a target id is parsed out of the rest of the query.',
      render: () => (
        <CommandBar
          navigation={commandBarNavigation}
          navigate={noop}
          onVerb={noop}
          entityHref={(id) => `#/issues/${id}`}
          verbs={commandBarVerbs}
          brand="Score"
          open
          query="> park issue-2098"
          onQueryChange={noop}
          placement="contained"
          autoFocus={false}
        />
      ),
    },
    {
      id: "entity-jump-query",
      label: "Entity-jump query",
      description:
        "A query the entity matcher recognises adds a Jump to group wired to entityHref, so an id typed anywhere in the app opens that entity without leaving the bar.",
      render: () => (
        <CommandBar
          navigation={commandBarNavigation}
          navigate={noop}
          onVerb={noop}
          entityHref={(id) => `#/issues/${id}`}
          verbs={commandBarVerbs}
          brand="Score"
          open
          query="issue-2098"
          onQueryChange={noop}
          placement="contained"
          autoFocus={false}
        />
      ),
    },
    {
      id: "navigation-query",
      label: "Navigation query",
      description:
        "Free text matches neither grammar, so only the app's navigation group renders — the group every query keeps last, which is why the bar never dead-ends on an unrecognised query.",
      render: () => (
        <CommandBar
          navigation={commandBarNavigation}
          navigate={noop}
          onVerb={noop}
          entityHref={(id) => `#/issues/${id}`}
          verbs={commandBarVerbs}
          brand="Score"
          open
          query="board"
          onQueryChange={noop}
          placement="contained"
          autoFocus={false}
        />
      ),
    },
  ],

  "command-console": [
    {
      id: "active",
      label: "Active session",
      description: "The session rail and transcript stay side by side so switching sessions never loses the prompt draft.",
      render: () => (
        <CommandConsole
          title="Maestro console"
          sessions={commandConsoleSessions}
          messages={commandConsoleMessages}
          activeSessionId={commandConsoleSessions[0]?.id}
          draft="park issue-1042"
          onDraftChange={noop}
          onSubmit={noop}
          onSessionSelect={noop}
        />
      ),
    },
    {
      id: "submitting",
      label: "Submitting",
      description: "A prompt in flight locks the composer so the same command cannot be queued twice.",
      render: () => (
        <CommandConsole
          title="Maestro console"
          sessions={commandConsoleSessions}
          messages={commandConsoleMessages}
          activeSessionId={commandConsoleSessions[0]?.id}
          draft="park issue-1042"
          submitting
          submittingLabel="Sending…"
          onDraftChange={noop}
          onSubmit={noop}
        />
      ),
    },
    {
      id: "new-session",
      label: "New session",
      description: "A session with no transcript keeps the composer usable rather than waiting for a first message.",
      render: () => (
        <CommandConsole
          title="Maestro console"
          sessions={commandConsoleSessions}
          messages={[]}
          activeSessionId={commandConsoleSessions[0]?.id}
          draft=""
          emptyState="No messages yet — ask Maestro something to start this session."
          onDraftChange={noop}
          onSubmit={noop}
        />
      ),
    },
  ],

  "compare-tray-panel": [
    {
      id: "pinned",
      label: "Pinned",
      description: "Each pinned card carries its own preview and remove control so the tray never owns pinned state.",
      render: () => (
        <CompareTrayPanel
          title="Compare tray"
          description="Pinned components stay side by side across catalog navigation."
          resultCount="2 pinned"
          items={compareTrayItems}
          currentAction={compareTrayPinAction}
        />
      ),
    },
    {
      id: "current-pinned",
      label: "Current item pinned",
      description: "The pin control reports the current item's membership instead of offering an action that would duplicate it.",
      render: () => (
        <CompareTrayPanel
          title="Compare tray"
          resultCount="3 pinned"
          items={compareTrayItems}
          currentAction={{ ...compareTrayPinAction, active: true }}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "An empty tray still offers the pin action so the first comparison can start from here.",
      render: () => (
        <CompareTrayPanel
          title="Compare tray"
          items={[]}
          emptyLabel="Nothing pinned yet — pin a component to start comparing."
          currentAction={compareTrayPinAction}
        />
      ),
    },
  ],

  "component-catalog-panel": [
    {
      id: "browsing",
      label: "Browsing",
      description: "The navigation rail, sidebar, and review region hold a stable three-column footprint as selection moves.",
      render: () => (
        <ComponentCatalogPanel
          eyebrow="Catalog"
          title="Component explorer"
          description="Every catalogued component with its demo, variants, and states."
          items={componentCatalogItems}
          search={{ value: "", placeholder: "Filter components", resultMeta: "162 components", onChange: noop }}
        >
          <div>Selected component review canvas.</div>
        </ComponentCatalogPanel>
      ),
    },
    {
      id: "searching",
      label: "Searching",
      description: "A narrowed rail reports how many entries survived the query so a short list never reads as a broken registry.",
      render: () => (
        <ComponentCatalogPanel
          eyebrow="Catalog"
          title="Component explorer"
          items={componentCatalogItems.slice(0, 2)}
          search={{ value: "ta", placeholder: "Filter components", resultMeta: "2 of 162", onChange: noop }}
        >
          <div>Selected component review canvas.</div>
        </ComponentCatalogPanel>
      ),
    },
    {
      id: "no-matches",
      label: "No matches",
      description: "A query with no hits empties the rail only — the review region and search field stay usable.",
      render: () => (
        <ComponentCatalogPanel
          eyebrow="Catalog"
          title="Component explorer"
          items={[]}
          emptyItemsLabel="No component matches this filter."
          search={{ value: "zzz", placeholder: "Filter components", resultMeta: "0 of 162", onChange: noop }}
        >
          <div>Pick a component to review it here.</div>
        </ComponentCatalogPanel>
      ),
    },
  ],

  "component-playground-panel": [
    {
      id: "ready",
      label: "Ready",
      description: "Controls, stage, and snippet stay in sync from one caller-owned value map.",
      render: () => (
        <ComponentPlaygroundPanel
          eyebrow="Playground"
          title="Button"
          controls={playgroundControls}
          values={playgroundValues}
          onValueChange={noop}
          stage={<Button>Continue</Button>}
          snippet={'<Button variant="primary">Continue</Button>'}
          onCopySnippet={noop}
          onReset={noop}
        />
      ),
    },
    {
      id: "copied",
      label: "Copied",
      description: "Copy confirmation is a controlled prop, so the panel never claims a clipboard write it did not perform.",
      render: () => (
        <ComponentPlaygroundPanel
          eyebrow="Playground"
          title="Button"
          controls={playgroundControls}
          values={playgroundValues}
          onValueChange={noop}
          stage={<Button>Continue</Button>}
          snippet={'<Button variant="primary">Continue</Button>'}
          copied
          onCopySnippet={noop}
        />
      ),
    },
    {
      id: "no-controls",
      label: "No controls",
      description: "A component with no adjustable props keeps its stage and snippet instead of hiding the whole playground.",
      render: () => (
        <ComponentPlaygroundPanel
          eyebrow="Playground"
          title="MapMarkerPin"
          controls={[]}
          values={{}}
          emptyControlsLabel="This component exposes no playground controls."
          stage={<MapMarkerPin label="Vilnius" tone="info" />}
          snippet={'<MapMarkerPin label="Vilnius" tone="info" />'}
        />
      ),
    },
  ],

  "component-review-panel": [
    {
      id: "reviewing",
      label: "Reviewing",
      description: "Variant, canvas size, and tab selection are all controlled, so the review state survives a route change.",
      render: () => (
        <ComponentReviewPanel
          eyebrow="Review"
          title="Button"
          summary="The primary command affordance."
          variants={componentReviewVariants}
          activeVariantId="enabled"
          canvasSizes={componentReviewCanvasSizes}
          activeCanvasSizeId="lg"
          tabs={componentReviewTabs}
          activeTabId="notes"
          onVariantChange={noop}
          onCanvasSizeChange={noop}
          onTabChange={noop}
        />
      ),
    },
    {
      id: "empty-tab",
      label: "Empty tab",
      description: "A tab with nothing recorded says so in place instead of falling back to another tab's content.",
      render: () => (
        <ComponentReviewPanel
          eyebrow="Review"
          title="Button"
          variants={componentReviewVariants}
          activeVariantId="disabled"
          tabs={componentReviewTabs}
          activeTabId="risks"
          onVariantChange={noop}
          onTabChange={noop}
        />
      ),
    },
    {
      id: "no-variants",
      label: "No variants",
      description: "A component with no reviewable variants keeps its metadata header rather than rendering an empty stage.",
      render: () => (
        <ComponentReviewPanel
          eyebrow="Review"
          title="Newly catalogued component"
          summary="Catalogued for review; no preview variants authored yet."
          variants={[]}
          emptyLabel="No preview variants have been authored for this component."
        />
      ),
    },
  ],

  "data-table": [
    {
      id: "populated",
      label: "Populated",
      description: "Sort, pagination, and selection are derived client-side; the caller keeps fetching and serialization.",
      render: () => (
        <DataTable
          ariaLabel="Catalog entities"
          caption="Catalog entities"
          columns={dataTableColumns}
          data={tableRows}
          getRowId={(row) => row.id}
          defaultSort={{ columnId: "owner", direction: "asc" }}
          selectionMode="multi"
          defaultSelection={[tableRows[0]?.id ?? ""]}
          selectedRowActions={<Button variant="ghost">Reassign</Button>}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The loading surface is rendered by the shared DataStatePanel, so it announces like every other non-ready state.",
      render: () => (
        <DataTable
          ariaLabel="Catalog entities"
          columns={dataTableColumns}
          data={[]}
          loading
          loadingState={{ title: "Loading entities…" }}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A genuinely empty result keeps the toolbar so the filter that produced it can be cleared.",
      render: () => (
        <DataTable
          ariaLabel="Catalog entities"
          columns={dataTableColumns}
          data={[]}
          searchSlot={<TextInputControl hideLabel id="data-table-search" label="Search" value="zzz" />}
          emptyState={{ title: "No entities match this filter", description: "Clear the search to see all rows." }}
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed fetch renders the error panel instead of an empty table that would read as zero rows.",
      render: () => (
        <DataTable
          ariaLabel="Catalog entities"
          columns={dataTableColumns}
          data={[]}
          error="The entity list could not be loaded."
          errorState={{ title: "Entities unavailable", description: "Retry once the control plane responds." }}
        />
      ),
    },
  ],

  "design-idea-board-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Lane membership comes from each item's laneId, so the board never infers workflow state of its own.",
      render: () => (
        <DesignIdeaBoardPanel
          eyebrow="Design"
          title="Idea board"
          subtitle="Pre-adoption review queue."
          lanes={designIdeaBoardLanes}
          items={designIdeaBoardItems}
        />
      ),
    },
    {
      id: "blocked",
      label: "Blocked",
      description: "Blocker chips and the owner boundary render as visible text so a stalled idea is never silently parked.",
      render: () => (
        <DesignIdeaBoardPanel
          eyebrow="Design"
          title="Idea board"
          lanes={designIdeaBoardLanes}
          items={designIdeaBoardBlockedItems}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty lanes",
      description: "Every lane keeps its heading when the board is empty so the workflow shape stays legible.",
      render: () => (
        <DesignIdeaBoardPanel
          eyebrow="Design"
          title="Idea board"
          lanes={designIdeaBoardLanes}
          items={[]}
          emptyLaneLabel="Nothing in this lane."
        />
      ),
    },
  ],

  "discovery-cloud-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Item weight comes from the caller's size hint, not from counts the panel would have to derive.",
      render: () => (
        <DiscoveryCloudPanel
          title="Discover"
          description="Jump into the catalog by pattern or source app."
          resultCount="162 components"
          groups={discoveryCloudGroups}
        />
      ),
    },
    {
      id: "filtered",
      label: "Filtered",
      description: "An active item and a zero-count disabled item stay visually distinct from an ordinary unselected one.",
      render: () => (
        <DiscoveryCloudPanel
          title="Discover"
          resultCount="72 components"
          groups={discoveryCloudSelectedGroups}
          actions={<Button variant="ghost">Clear</Button>}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A group that matched nothing keeps its own label so the query's shape stays visible.",
      render: () => (
        <DiscoveryCloudPanel title="Discover" resultCount="0 components" groups={discoveryCloudEmptyGroups} />
      ),
    },
  ],

  "editable-form-panel": [
    {
      id: "editing",
      label: "Editing",
      description: "Section fields are caller-rendered controls; the shell owns only labelling and layout.",
      render: () => (
        <EditableFormPanel
          eyebrow="Admin"
          title="Guide profile"
          subtitle="Public identity for the guide directory."
          sections={editableFormSections}
          actions={<Button type="submit">Save</Button>}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "invalid",
      label: "Invalid",
      description: "Form-level and per-field messages appear together so a blocked save always names what failed.",
      render: () => (
        <EditableFormPanel
          eyebrow="Admin"
          title="Guide profile"
          badges={[{ id: "unsaved", label: "Unsaved changes", tone: "warning" }]}
          messages={[{ id: "blocked", tone: "danger", children: "Fix two fields before saving." }]}
          sections={editableFormInvalidSections}
          actions={<Button type="submit">Save</Button>}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "saved",
      label: "Saved",
      description: "A completed save reports its result in the same message strip rather than through a transient toast alone.",
      render: () => (
        <EditableFormPanel
          eyebrow="Admin"
          title="Guide profile"
          badges={[{ id: "saved", label: "Saved", tone: "success" }]}
          messages={[{ id: "saved", tone: "success", children: "Profile saved and published to the directory." }]}
          sections={editableFormSections}
          actions={<Button type="submit">Save</Button>}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],

  "entity-card": [
    {
      id: "default",
      label: "Default",
      description: "Badges, tags, and metadata sit under a caller-owned action without the card taking a route decision.",
      render: () => (
        <EntityCard
          title={entities[0]?.title}
          subtitle={entities[0]?.subtitle}
          meta={entities[0]?.meta}
          tags={entities[0]?.tags}
          badges={[{ id: "publish-state", label: "Published", tone: "success" }]}
          actionLabel="Open guide"
          onSelect={noop}
        />
      ),
    },
    {
      id: "selected",
      label: "Selected",
      description: "Selection is a caller-owned flag, so the card and its list never disagree about what is active.",
      render: () => (
        <EntityCard
          title={entities[1]?.title}
          subtitle={entities[1]?.subtitle}
          meta={entities[1]?.meta}
          tags={entities[1]?.tags}
          badges={[{ id: "active", label: "Active", tone: "accent" }]}
          selected
          actionLabel="Open roster"
          onSelect={noop}
        />
      ),
    },
    {
      id: "disabled",
      label: "Disabled",
      description: "A disabled card withdraws its action instead of leaving a control that would fail on click.",
      render: () => (
        <EntityCard
          title={entities[2]?.title}
          subtitle={entities[2]?.subtitle}
          meta={entities[2]?.meta}
          tags={entities[2]?.tags}
          badges={[{ id: "access-state", label: "Read-only", tone: "neutral" }]}
          disabled
          actionLabel="Open schema"
          onSelect={noop}
        />
      ),
    },
  ],

  "entity-card-grid-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "The grid renders one pre-paged page; the product keeps paging, filtering, and selection state.",
      render: () => (
        <EntityCardGridPanel
          eyebrow="Directory"
          title="Guides"
          description="Page 1 of 6"
          status="128 records"
          statusTone="info"
          items={entityCardGridItems}
          selectedItemId={entityCardGridItems[0]?.id}
          onItemSelect={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The toolbar and pagination slots stay mounted so the page does not jump when cards arrive.",
      render: () => (
        <EntityCardGridPanel
          eyebrow="Directory"
          title="Guides"
          items={[]}
          loading
          loadingLabel="Loading guides…"
          pagination={<Pager ariaLabel="Guides" page={1} total={6} />}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A filter that matched nothing keeps the toolbar so the filter that caused it can be undone.",
      render: () => (
        <EntityCardGridPanel
          eyebrow="Directory"
          title="Guides"
          status="0 records"
          statusTone="neutral"
          items={[]}
          emptyLabel="No guide matches the current filters."
          toolbar={<Button variant="ghost">Clear filters</Button>}
        />
      ),
    },
  ],

  "entity-filter-panel": [
    {
      id: "idle",
      label: "Idle",
      description: "With no filter applied the clear control stays hidden rather than offering a no-op reset.",
      render: () => (
        <EntityFilterPanel
          title="Filter entities"
          controls={entityFilterControls}
          stats={entityFilterStats}
          resultCount={128}
          totalCount={128}
          onRefresh={noop}
        />
      ),
    },
    {
      id: "filtered",
      label: "Filtered",
      description: "The result-versus-total summary makes a narrowed list distinguishable from an empty dataset.",
      render: () => (
        <EntityFilterPanel
          title="Filter entities"
          controls={entityFilterActiveControls}
          stats={entityFilterStats}
          resultCount={7}
          totalCount={128}
          clearVisible
          onClear={noop}
          onRefresh={noop}
        />
      ),
    },
    {
      id: "refreshing",
      label: "Refreshing",
      description: "A refresh in flight locks its own control while the filter inputs stay editable.",
      render: () => (
        <EntityFilterPanel
          title="Filter entities"
          controls={entityFilterActiveControls}
          resultCount={7}
          totalCount={128}
          refreshing
          refreshingLabel="Refreshing…"
          refreshDisabled
          onRefresh={noop}
        />
      ),
    },
  ],

  "facet-filter-panel": [
    {
      id: "unfiltered",
      label: "Unfiltered",
      description: "Counts show the full facet distribution before any option narrows the result set.",
      render: () => (
        <FacetFilterPanel
          title="Facets"
          description="Counted filters for the catalog registry."
          resultCount="162 components"
          groups={facetFilterGroups}
        />
      ),
    },
    {
      id: "filtered",
      label: "Filtered",
      description: "Every applied facet has a removable chip, so no filter can narrow the list invisibly.",
      render: () => (
        <FacetFilterPanel
          title="Facets"
          resultCount="68 components"
          groups={facetFilterSelectedGroups}
          activeFilters={facetFilterChips}
          onReset={noop}
        />
      ),
    },
    {
      id: "no-facets",
      label: "No facet values",
      description: "A group with no values keeps its heading so the missing axis is visible, not silently dropped.",
      render: () => (
        <FacetFilterPanel title="Facets" resultCount="0 components" groups={facetFilterEmptyGroups} />
      ),
    },
  ],

  "file-action-list-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Every row action is a caller-supplied descriptor; the list executes no command of its own.",
      render: () => (
        <FileActionListPanel
          eyebrow="Attachments"
          title="Project files"
          status="4 files"
          statusTone="info"
          items={fileActionListItems}
          onItemSelect={noop}
          onMenuOpenChange={noop}
        />
      ),
    },
    {
      id: "menu-open",
      label: "Menu open",
      description: "Menu visibility is controlled, so at most one row can be open across a re-render.",
      render: () => (
        <FileActionListPanel
          eyebrow="Attachments"
          title="Project files"
          items={fileActionListItems}
          menuOpenItemId={fileActionListItems[0]?.id ?? null}
          onMenuOpenChange={noop}
          onItemSelect={noop}
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed listing shows no rows at all rather than a partial set that would look like the whole attachment history.",
      render: () => (
        <FileActionListPanel
          eyebrow="Attachments"
          title="Project files"
          items={[]}
          error="The attachment list could not be read."
        />
      ),
    },
  ],

  "file-preview-dialog": [
    {
      id: "rendered",
      label: "Rendered markdown",
      description: "Markdown resolves to the rendered view first, with source kept one control away.",
      render: () => (
        <FilePreviewDialog
          open
          placement="contained"
          file={markdownFileRecord}
          kind="markdown"
          markdown={scoreTaskDocumentMarkdown}
          meta={filePreviewMeta}
          mode="view"
          onModeChange={noop}
          onClose={noop}
        />
      ),
    },
    {
      id: "source",
      label: "Source",
      description: "Raw source renders through a caller-supplied node so the dialog never fetches the file itself.",
      render: () => (
        <FilePreviewDialog
          open
          placement="contained"
          file={markdownFileRecord}
          kind="markdown"
          markdown={scoreTaskDocumentMarkdown}
          mode="src"
          source={<PayloadBlock label="extraction-review.md" payload={scoreTaskDocumentMarkdown} />}
          onModeChange={noop}
          onClose={noop}
        />
      ),
    },
    {
      id: "unavailable",
      label: "No preview",
      description: "A file the product cannot preview keeps its download action instead of showing an empty viewer.",
      render: () => (
        <FilePreviewDialog
          open
          placement="contained"
          file={binaryFileRecord}
          kind="file"
          previewAvailable={false}
          meta={filePreviewMeta}
          fallbackLabel="This file type has no in-browser preview."
          downloadAction={{ href: "#/files/capacity-export.xlsx", label: "Download" }}
          onClose={noop}
        />
      ),
    },
  ],

  "file-preview-panel": [
    {
      id: "markdown",
      label: "Markdown",
      description: "Markdown previews compose MarkdownDocumentPanel, so sanitization stays at one boundary.",
      render: () => (
        <FilePreviewPanel
          file={markdownFileRecord}
          kind="markdown"
          markdown={scoreTaskDocumentMarkdown}
          meta={filePreviewMeta}
        />
      ),
    },
    {
      id: "fallback",
      label: "Unsupported file",
      description: "A non-previewable file falls back to a download-oriented card that still names type and size.",
      render: () => (
        <FilePreviewPanel
          file={binaryFileRecord}
          kind="file"
          meta={filePreviewMeta}
          fallbackLabel="Spreadsheets have no in-browser preview."
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed attachment fetch shows the failure instead of an empty document that would read as a blank file.",
      render: () => (
        <FilePreviewPanel
          file={markdownFileRecord}
          kind="markdown"
          error="The attachment could not be fetched — the signed URL may have expired."
        />
      ),
    },
  ],

  "filter-drawer-panel": [
    {
      id: "inline",
      label: "Inline",
      description: "Inline mode keeps the filters permanently visible for wide layouts with room to spare.",
      render: () => (
        <FilterDrawerPanel
          mode="inline"
          eyebrow="Filters"
          title="Refine results"
          summary="2 active"
          summaryTone="info"
        >
          <FacetFilterPanel groups={facetFilterSelectedGroups} activeFilters={facetFilterChips} onReset={noop} />
        </FilterDrawerPanel>
      ),
    },
    {
      id: "drawer-closed",
      label: "Drawer closed",
      description: "Closed drawer mode collapses to a trigger that still reports how many filters are applied.",
      render: () => (
        <FilterDrawerPanel
          mode="drawer"
          open={false}
          eyebrow="Filters"
          title="Refine results"
          summary="2 active"
          summaryTone="info"
          triggerLabel="Filters"
          onOpenChange={noop}
        >
          <FacetFilterPanel groups={facetFilterSelectedGroups} activeFilters={facetFilterChips} onReset={noop} />
        </FilterDrawerPanel>
      ),
    },
    {
      id: "drawer-open",
      label: "Drawer open",
      description: "The open drawer traps focus and dismisses through onOpenChange so the caller keeps the open flag.",
      render: () => (
        <FilterDrawerPanel
          mode="drawer"
          open
          eyebrow="Filters"
          title="Refine results"
          summary="2 active"
          summaryTone="info"
          triggerLabel="Filters"
          footerActions={<Button variant="ghost">Reset</Button>}
          onOpenChange={noop}
        >
          <FacetFilterPanel groups={facetFilterSelectedGroups} activeFilters={facetFilterChips} onReset={noop} />
        </FilterDrawerPanel>
      ),
    },
  ],

  "form-builder": [
    {
      id: "seeded",
      label: "Seeded spec",
      description: "The preview renders the working spec through AutoForm itself, so the builder never becomes a second renderer.",
      render: () => <FormBuilder initialSpec={contactRegistrationSeedSpec} />,
    },
    {
      id: "empty-canvas",
      label: "Empty canvas",
      description: "An empty spec keeps the palette reachable so the first field can be added without an import.",
      render: () => <FormBuilder initialSpec={emptyFormBuilderSpec} />,
    },
    {
      id: "narrowed-palette",
      label: "Narrowed palette",
      description: "A product whose backend cannot store every control passes its own type list; the palette and the config panel's Type select follow it, in the order given.",
      render: () => <FormBuilder initialSpec={emptyFormBuilderSpec} availableFieldTypes={narrowedFormBuilderTypes} />,
    },
  ],

  "form-panel": [
    {
      id: "ready",
      label: "Ready",
      description: "Sections bind to a typed useForm store; the panel owns labelling and error wiring only.",
      render: () => <FormPanelStateDemo />,
    },
    {
      id: "read-only",
      label: "Read-only",
      description: "Read-only fields keep their values visible while removing every route to an edit the viewer cannot save.",
      render: () => <FormPanelStateDemo readOnly />,
    },
    {
      id: "submit-error",
      label: "Submit error",
      description: "A rejected submit surfaces the form-level failure without clearing the values that produced it.",
      render: () => <FormPanelStateDemo submitError="The directory rejected this profile — the email is already in use." />,
    },
  ],

  "form-persistence-demo": [
    {
      id: "saving",
      label: "Saving",
      description: "A debounced dirty write announces itself so the writer knows an autosave is in flight.",
      render: () => <SaveStatusIndicator status="saving" />,
    },
    {
      id: "saved",
      label: "Saved",
      description: "Confirmation carries the save time so a stale indicator cannot be mistaken for a fresh write.",
      render: () => <SaveStatusIndicator status="saved" lastSavedAt={new Date("2026-08-29T09:14:00Z")} />,
    },
    {
      id: "save-error",
      label: "Save error",
      description: "A rejected write reports the failure instead of silently leaving the draft only in memory.",
      render: () => (
        <SaveStatusIndicator status="error" error={new Error("The storage adapter rejected the write.")} />
      ),
    },
    {
      id: "draft-available",
      label: "Draft available",
      description: "A recovered draft is offered rather than applied, so restoring is always the writer's decision.",
      render: () => (
        <DraftResumePrompt
          draft={{
            name: "Autosaved draft",
            values: { displayName: "Raseiniai Magde" },
            updatedAt: "2026-08-29T09:02:00Z",
          }}
          onRestore={noop}
          onDiscard={noop}
        />
      ),
    },
  ],

  "geocoding-control-panel": [
    {
      id: "candidates",
      label: "Candidates",
      description: "Returned candidates and the selected coordinate pair stay visible together so the choice is reviewable.",
      render: () => (
        <GeocodingControlPanel
          eyebrow="Location"
          title="Geocode address"
          query="Vilnius Old Town"
          sources={geocodingSources}
          candidates={geocodingCandidates}
          coordinates={{ label: "Selected", latitude: "54.6805", longitude: "25.2871", source: "Google" }}
          onQueryChange={noop}
          onSearch={noop}
        />
      ),
    },
    {
      id: "searching",
      label: "Searching",
      description: "A search in flight locks its own control while the coordinate source buttons stay selectable.",
      render: () => (
        <GeocodingControlPanel
          eyebrow="Location"
          title="Geocode address"
          query="Vilnius Old Town"
          sources={geocodingSources}
          loading
          loadingLabel="Searching…"
          searchDisabled
          onQueryChange={noop}
          onSearch={noop}
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A provider failure clears the candidate list so a stale match can never be selected by mistake.",
      render: () => (
        <GeocodingControlPanel
          eyebrow="Location"
          title="Geocode address"
          query="Vilnius Old Town"
          sources={geocodingSources}
          candidates={[]}
          emptyCandidatesLabel="No candidates."
          error="The geocoding provider returned an error — try another source."
          onQueryChange={noop}
          onSearch={noop}
        />
      ),
    },
  ],

  "idea-backlog-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Project context sits in the header so a backlog row is never read against the wrong project.",
      render: () => (
        <IdeaBacklogPanel
          eyebrow="Ideas"
          title="Related ideas"
          contextLabel="Project"
          contextValue="UI"
          items={ideaBacklogItems}
          onItemSelect={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The project context survives the load, so the panel keeps naming the backlog it is fetching.",
      render: () => (
        <IdeaBacklogPanel
          eyebrow="Ideas"
          title="Related ideas"
          contextLabel="Project"
          contextValue="UI"
          items={[]}
          loading
          loadingLabel="Loading ideas…"
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A project with no ideas states that against its own context rather than showing a generic blank list.",
      render: () => (
        <IdeaBacklogPanel
          eyebrow="Ideas"
          title="Related ideas"
          contextLabel="Project"
          contextValue="UI"
          items={[]}
          emptyLabel="No ideas have been filed against this project."
        />
      ),
    },
  ],

  "integration-setup-panel": [
    {
      id: "connected",
      label: "Connected",
      description: "Operational metrics appear beside the connection state so a live integration is evidenced, not asserted.",
      render: () => (
        <IntegrationSetupPanel
          eyebrow="Integration"
          title="Bókun"
          status={{ label: "Connected", detail: "Last sync 12 minutes ago", tone: "connected" }}
          metrics={integrationSetupMetrics}
          sections={integrationSetupSections}
          actions={<Button type="submit">Save</Button>}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "testing",
      label: "Testing",
      description: "A connection test in progress is a distinct state from connected, so a pending result never reads as success.",
      render: () => (
        <IntegrationSetupPanel
          eyebrow="Integration"
          title="Bókun"
          status={{ label: "Testing connection", tone: "testing" }}
          messages={[{ id: "testing", tone: "info", children: "Calling the provider with the saved credentials…" }]}
          sections={integrationSetupSections}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A rejected credential is reported without the component ever reading or echoing the secret itself.",
      render: () => (
        <IntegrationSetupPanel
          eyebrow="Integration"
          title="Bókun"
          status={{ label: "Disconnected", detail: "Credentials rejected", tone: "error" }}
          messages={[{ id: "error", tone: "danger", children: "The provider rejected the access key (HTTP 401)." }]}
          sections={integrationSetupSections}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],

  "kanban-board": [
    {
      id: "populated",
      label: "Populated",
      description: "Lane membership and counts come from the caller; the board never moves a task on its own.",
      render: () => <KanbanBoard ariaLabel="Delivery board" columns={kanbanColumns} />,
    },
    {
      id: "collapsed",
      label: "Collapsed lanes",
      description: "Collapsible lanes become disclosures that still report their counts while closed.",
      render: () => (
        <KanbanBoard ariaLabel="Delivery board" columns={kanbanColumns} collapsible defaultCollapsed />
      ),
    },
    {
      id: "empty",
      label: "Empty lanes",
      description: "An empty board keeps every lane heading so the workflow shape stays readable with no work in it.",
      render: () => (
        <KanbanBoard ariaLabel="Delivery board" columns={kanbanEmptyColumns} emptyLabel="No work in this lane." />
      ),
    },
  ],

  "map-control-panel": [
    {
      id: "default",
      label: "Default",
      description: "Every command is delegated through onSelect, so the panel holds no map engine state.",
      render: () => (
        <MapControlPanel
          title="Map controls"
          actions={mapControlActions}
          stats={mapControlStats}
          status="Ready"
          statusTone="success"
        />
      ),
    },
    {
      id: "active-tool",
      label: "Active tool",
      description: "An active command reports the current map mode rather than only the action a click would take.",
      render: () => (
        <MapControlPanel
          title="Map controls"
          actions={mapControlActiveActions}
          stats={[{ id: "markers", label: "Clusters", value: "18", tone: "info" }, ...mapControlStats.slice(1)]}
          status="Clustered"
          statusTone="info"
        />
      ),
    },
    {
      id: "disabled",
      label: "Disabled",
      description: "While the map engine is unavailable every command is withdrawn together, not one at a time.",
      render: () => (
        <MapControlPanel
          title="Map controls"
          actions={mapControlActions}
          stats={mapControlStats}
          status="Map unavailable"
          statusTone="danger"
          disabled
        />
      ),
    },
  ],

  "map-info-card": [
    {
      id: "selected",
      label: "Selected marker",
      description: "The close control reports selection back to the product; the card never clears the marker itself.",
      render: () => (
        <MapInfoCard
          eyebrow="Marker"
          title="Vilnius Old Town"
          subtitle="Lithuania / city"
          badges={mapInfoCardBadges}
          rows={mapInfoCardRows}
          onClose={noop}
        />
      ),
    },
    {
      id: "sparse",
      label: "Sparse record",
      description: "Rows with no value are omitted while the supplied order is preserved, so gaps never shift the layout.",
      render: () => (
        <MapInfoCard
          eyebrow="Marker"
          title="Unnamed viewpoint"
          rows={[
            { id: "coords", label: "Coordinates", value: "54.6805, 25.2871" },
            { id: "phone", label: "Phone" },
            { id: "site", label: "Website" },
            { id: "region", label: "Region", value: "Vilniaus apskritis" },
          ]}
          onClose={noop}
        />
      ),
    },
    {
      id: "read-only",
      label: "Read-only",
      description: "Without a close handler or actions the card presents as reference detail with no affordance that would fail.",
      render: () => (
        <MapInfoCard
          eyebrow="Marker"
          title="Vilnius Old Town"
          subtitle="Lithuania / city"
          badges={mapInfoCardBadges}
          rows={mapInfoCardRows}
        />
      ),
    },
  ],

  "map-marker-pin": [
    {
      id: "default",
      label: "Default",
      description: "Tone carries the marker's meaning while the glyph keeps one stable footprint across every tone.",
      render: () => <MapMarkerPin label="Vilnius Old Town" tone="info" showLabel />,
    },
    {
      id: "selected",
      label: "Selected",
      description: "Selection overrides the tone so the active marker never has to compete with a status colour.",
      render: () => <MapMarkerPin label="Vilnius Old Town" tone="info" selected showLabel />,
    },
    {
      id: "cluster",
      label: "Cluster",
      description: "A cluster shows its count in place of an icon while keeping the same hit target as a single pin.",
      render: () => <MapMarkerPin ariaLabel="18 markers in this cluster" kind="cluster" count={18} />,
    },
  ],

  "markdown-document-panel": [
    {
      id: "rendered",
      label: "Rendered",
      description: "Markdown is parsed and sanitized before it reaches the DOM, and the pipeline stays swappable.",
      render: () => (
        <MarkdownDocumentPanel
          eyebrow="Document"
          title="Extraction review notes"
          markdown={scoreTaskDocumentMarkdown}
          meta={markdownDocumentMeta}
          badges={[{ id: "trusted", label: "Trusted source", tone: "info" }]}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A document with no body says so instead of rendering an empty page that could read as a fetch failure.",
      render: () => (
        <MarkdownDocumentPanel
          eyebrow="Document"
          title="Extraction review notes"
          meta={markdownDocumentMeta}
          emptyLabel="This document has no content yet."
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed fetch is reported rather than rendering a partial body that would look like the whole document.",
      render: () => (
        <MarkdownDocumentPanel
          eyebrow="Document"
          title="Extraction review notes"
          error="The document could not be fetched from the task store."
        />
      ),
    },
  ],

  "media-asset-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Asset URLs, previews, and actions are product-owned; the panel never fetches or authorises a file.",
      render: () => (
        <MediaAssetPanel
          eyebrow="Media"
          title="Guide assets"
          status="12 assets"
          statusTone="info"
          stats={mediaAssetStats}
          assets={mediaAssetItems}
          showDetail
          onAssetSelect={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The stats row and upload chrome stay mounted so the grid does not reflow when thumbnails resolve.",
      render: () => (
        <MediaAssetPanel
          eyebrow="Media"
          title="Guide assets"
          stats={mediaAssetStats}
          assets={[]}
          loading
          loadingLabel="Loading assets…"
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "An empty library keeps the upload affordance so the first asset can be added from here.",
      render: () => (
        <MediaAssetPanel
          eyebrow="Media"
          title="Guide assets"
          assets={[]}
          emptyLabel="No assets have been uploaded for this guide."
          upload={{
            label: "Add assets",
            description: "Images up to 8 MB, or PDF documents.",
            action: <Button variant="ghost">Choose files</Button>,
          }}
        />
      ),
    },
  ],

  "metric-grid": [
    {
      id: "populated",
      label: "Populated",
      description: "Tiles render as semantic dl/dt/dd so metrics stay readable without becoming interactive.",
      render: () => <MetricGrid ariaLabel="Delivery metrics" items={metricGridItems} />,
    },
    {
      id: "threshold-breach",
      label: "Threshold breach",
      description: "Warning and danger tones come from caller-computed thresholds — the grid never decides what is bad.",
      render: () => <MetricGrid ariaLabel="Delivery metrics" items={metricGridBreachItems} />,
    },
    {
      id: "empty",
      label: "Empty",
      description: "A metric set that resolved to nothing keeps its footprint instead of collapsing the page around it.",
      render: () => (
        <MetricGrid ariaLabel="Delivery metrics" items={[]} emptyLabel="No metrics are available for this window." />
      ),
    },
  ],

  "mode-control-panel": [
    {
      id: "active",
      label: "Active",
      description: "Mode and each toggle report changes separately, so one automation switch never implies another.",
      render: () => (
        <ModeControlPanel
          eyebrow="Workspace"
          title="Entity mode"
          modeValue="assisted"
          modeOptions={modeControlOptions}
          toggles={modeControlToggles}
          status="Saved"
          statusTone="success"
          onModeChange={noop}
          actions={<Button variant="ghost">Refresh</Button>}
        />
      ),
    },
    {
      id: "disabled",
      label: "Disabled",
      description: "A locked workspace withdraws the mode selector rather than accepting a change it cannot persist.",
      render: () => (
        <ModeControlPanel
          eyebrow="Workspace"
          title="Entity mode"
          modeValue="manual"
          modeOptions={modeControlOptions}
          toggles={modeControlToggles}
          status="Locked"
          statusTone="neutral"
          message="Editing is disabled while a bulk import is running."
          disabled
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed mode write keeps the previous selection visible so the workspace state is never ambiguous.",
      render: () => (
        <ModeControlPanel
          eyebrow="Workspace"
          title="Entity mode"
          modeValue="assisted"
          modeOptions={modeControlOptions}
          toggles={modeControlToggles}
          status="Not saved"
          statusTone="danger"
          error="The mode change could not be saved — the workspace is still in Assisted."
          onModeChange={noop}
        />
      ),
    },
  ],

  "newsletter-signup-panel": [
    {
      id: "ready",
      label: "Ready",
      description: "The email value is fully controlled, so the panel holds nothing the product cannot inspect.",
      render: () => (
        <NewsletterSignupPanel
          eyebrow="Stay in touch"
          title="Lithuania travel notes"
          description="One letter a month. No partner mail."
          value=""
          onValueChange={noop}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description: "A subscription in flight locks the submit route so one address cannot be sent twice.",
      render: () => (
        <NewsletterSignupPanel
          eyebrow="Stay in touch"
          title="Lithuania travel notes"
          value="reader@example.com"
          busy
          busyLabel="Subscribing…"
          onValueChange={noop}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "submitted",
      label: "Submitted",
      description: "Success is a controlled prop, so the panel never claims a subscription the product has not confirmed.",
      render: () => (
        <NewsletterSignupPanel
          eyebrow="Stay in touch"
          title="Lithuania travel notes"
          value="reader@example.com"
          submitted
          successMessage="You are on the list — check your inbox to confirm."
          onValueChange={noop}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A rejected address stays in the field so the reader can correct it instead of retyping it.",
      render: () => (
        <NewsletterSignupPanel
          eyebrow="Stay in touch"
          title="Lithuania travel notes"
          value="reader@example"
          error="Enter a complete email address."
          onValueChange={noop}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],

  "operational-diagnostic-panel": [
    {
      id: "result",
      label: "Result",
      description: "Metrics, key/value rows, and the raw payload sit together so a diagnostic can be read without a console.",
      render: () => (
        <OperationalDiagnosticPanel
          eyebrow="Diagnostics"
          title="Oracle connection check"
          status={{ label: "Healthy", tone: "success", detail: "Round trip 41 ms" }}
          metrics={operationalDiagnosticMetrics}
          details={operationalDiagnosticDetails}
          payloadLabel="Raw response"
          payload={'{\n  "status": "ok",\n  "latencyMs": 41\n}'}
        />
      ),
    },
    {
      id: "loading",
      label: "Running",
      description: "A check in progress keeps its header so the panel never presents last run's numbers as current.",
      render: () => (
        <OperationalDiagnosticPanel
          eyebrow="Diagnostics"
          title="Oracle connection check"
          loading
          loadingLabel="Running the connection check…"
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed check reports the failure rather than an empty result set that would read as a clean run.",
      render: () => (
        <OperationalDiagnosticPanel
          eyebrow="Diagnostics"
          title="Oracle connection check"
          status={{ label: "Failed", tone: "danger" }}
          error="The diagnostic endpoint did not respond within 10 seconds."
        />
      ),
    },
  ],

  pager: [
    {
      id: "mid-range",
      label: "Mid range",
      description: "With pages on both sides every movement control is live and the summary states the position.",
      render: () => (
        <Pager
          ariaLabel="Guides"
          page={4}
          total={12}
          summary="Showing 61–80 of 240"
          onPageChange={noop}
        />
      ),
    },
    {
      id: "first-page",
      label: "First page",
      description: "First and previous are disabled at the start rather than silently clamping to the same page.",
      render: () => (
        <Pager ariaLabel="Guides" page={1} total={12} summary="Showing 1–20 of 240" onPageChange={noop} />
      ),
    },
    {
      id: "last-page",
      label: "Last page",
      description: "Next and last are disabled at the end, so the control can never suggest a page that does not exist.",
      render: () => (
        <Pager ariaLabel="Guides" page={12} total={12} summary="Showing 221–240 of 240" onPageChange={noop} />
      ),
    },
  ],

  "payment-account-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Amounts, dates, and statuses arrive preformatted — the panel performs no money formatting.",
      render: () => (
        <PaymentAccountPanel
          eyebrow="Billing"
          title="Payment account"
          summaryLabel="Available balance"
          summaryValue="EUR 1,284.50"
          summaryDetail="Next payout 2026-09-01"
          stats={paymentAccountStats}
          methods={paymentMethods}
          payments={paymentHistoryRows}
          payouts={payoutRows}
        />
      ),
    },
    {
      id: "no-methods",
      label: "No saved method",
      description: "A missing payment method is called out on its own so it never reads as an account with no activity.",
      render: () => (
        <PaymentAccountPanel
          eyebrow="Billing"
          title="Payment account"
          summaryLabel="Available balance"
          summaryValue="EUR 1,284.50"
          stats={paymentAccountStats}
          methods={[]}
          emptyMethodsLabel="No saved payment method — add one before the next charge."
          payments={paymentHistoryRows}
          payouts={payoutRows}
        />
      ),
    },
    {
      id: "no-activity",
      label: "No activity",
      description: "Each ledger keeps its own empty copy so a quiet payout history is distinguishable from a quiet payment history.",
      render: () => (
        <PaymentAccountPanel
          eyebrow="Billing"
          title="Payment account"
          summaryLabel="Available balance"
          summaryValue="EUR 0.00"
          methods={paymentMethods}
          payments={[]}
          emptyPaymentsLabel="No payments in this period."
          payouts={[]}
          emptyPayoutsLabel="No payouts have been issued yet."
        />
      ),
    },
  ],

  "payment-checkout-panel": [
    {
      id: "ready",
      label: "Ready",
      description: "The provider control is an opaque slot — no payment SDK behaviour crosses into the shared component.",
      render: () => (
        <PaymentCheckoutPanel
          eyebrow="Checkout"
          title="Confirm booking"
          amount="EUR 126.00"
          amountLabel="Total"
          amountDetail="3 travellers, taxes included"
          providerLabel="Card details"
          providerSlot={<div>Provider payment element renders here.</div>}
          submitLabel="Pay now"
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "processing",
      label: "Processing",
      description: "An authorisation in flight locks submit so a card cannot be charged twice from one form.",
      render: () => (
        <PaymentCheckoutPanel
          eyebrow="Checkout"
          title="Confirm booking"
          amount="EUR 126.00"
          providerSlot={<div>Provider payment element renders here.</div>}
          processing
          processingLabel="Authorising…"
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "declined",
      label: "Declined",
      description: "A decline keeps the amount and provider slot in place so the traveller can retry without re-entering the booking.",
      render: () => (
        <PaymentCheckoutPanel
          eyebrow="Checkout"
          title="Confirm booking"
          amount="EUR 126.00"
          providerSlot={<div>Provider payment element renders here.</div>}
          error="The card was declined by the issuer. Try another payment method."
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "provider-unavailable",
      label: "Provider unavailable",
      description: "With no provider element the form disables submit instead of collecting details nothing can charge.",
      render: () => (
        <PaymentCheckoutPanel
          eyebrow="Checkout"
          title="Confirm booking"
          amount="EUR 126.00"
          providerFallback="The payment provider could not be loaded. Refresh to try again."
          disabled
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],

  "preview-matrix-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Each cell renders its own caller-supplied canvas, so the matrix compares real output rather than screenshots.",
      render: () => (
        <PreviewMatrixPanel
          title="Theme coverage"
          description="Every reviewed fixture across both themes."
          ariaLabel="Theme coverage matrix"
          columns={previewMatrixColumns}
          rows={previewMatrixRows}
        />
      ),
    },
    {
      id: "gaps",
      label: "Coverage gaps",
      description: "An unsupported or missing cell is labelled in place so a gap can never pass as an untested pass.",
      render: () => (
        <PreviewMatrixPanel
          title="Theme coverage"
          ariaLabel="Theme coverage matrix"
          columns={previewMatrixColumns}
          rows={previewMatrixPartialRows}
          missingCellLabel="Not reviewed"
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A matrix with no rows keeps its column headers so the comparison axes stay visible.",
      render: () => (
        <PreviewMatrixPanel
          title="Theme coverage"
          ariaLabel="Theme coverage matrix"
          columns={previewMatrixColumns}
          rows={[]}
          emptyLabel="No fixtures have been registered for this matrix."
        />
      ),
    },
  ],

  "process-run-history-panel": [
    {
      id: "history",
      label: "History",
      description: "Timestamps, durations, and exit codes arrive preformatted; the panel interprets none of them.",
      render: () => (
        <ProcessRunHistoryPanel
          eyebrow="Runs"
          title="spec-guard history"
          status="Last 24 hours"
          statusTone="neutral"
          runs={processRunHistoryItems}
        />
      ),
    },
    {
      id: "in-flight",
      label: "In flight",
      description: "A null exit code derives a running label, so an unfinished run never reads as a successful one.",
      render: () => (
        <ProcessRunHistoryPanel
          eyebrow="Runs"
          title="spec-guard history"
          status="Running"
          statusTone="info"
          runs={processRunInFlight}
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed history read shows no runs rather than a partial list that would understate the failures.",
      render: () => (
        <ProcessRunHistoryPanel
          eyebrow="Runs"
          title="spec-guard history"
          runs={[]}
          error="The run log could not be read from the host."
        />
      ),
    },
  ],

  "project-directory-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Cards link only where the product supplied an href, so the directory never invents a route.",
      render: () => (
        <ProjectDirectoryPanel
          eyebrow="Projects"
          title="Project directory"
          status="6 projects"
          statusTone="info"
          items={projectDirectoryItems}
          onItemSelect={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The route header holds its place so the page keeps its identity while the grid resolves.",
      render: () => (
        <ProjectDirectoryPanel
          eyebrow="Projects"
          title="Project directory"
          items={[]}
          loading
          loadingLabel="Loading projects…"
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A viewer with access to no projects sees that stated, not an empty grid that could read as a fetch failure.",
      render: () => (
        <ProjectDirectoryPanel
          eyebrow="Projects"
          title="Project directory"
          items={[]}
          emptyLabel="No projects are visible to this account."
        />
      ),
    },
  ],

  "project-profile-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Identity, metadata, and the definition-of-done checklist read from one project record.",
      render: () => (
        <ProjectProfilePanel
          eyebrow="Project"
          title="UI Framework"
          subtitle="Shared component library extraction"
          badges={[{ id: "active", label: "Active", tone: "success" }]}
          fields={projectProfileFields}
          description="The catalogued component library shared by Score and eLitua."
          checklist={projectProfileChecklist}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "Header chrome remains available for route context while the profile body resolves.",
      render: () => (
        <ProjectProfilePanel
          eyebrow="Project"
          title="UI Framework"
          loading
          loadingLabel="Loading the project profile…"
        />
      ),
    },
    {
      id: "empty",
      label: "Not found",
      description: "A project id the route cannot resolve says so instead of rendering an empty but plausible profile.",
      render: () => (
        <ProjectProfilePanel
          eyebrow="Project"
          title="UI Framework"
          empty
          emptyLabel="No project exists for this key."
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed read refuses to show a checklist that might understate what the project still owes.",
      render: () => (
        <ProjectProfilePanel
          eyebrow="Project"
          title="UI Framework"
          error="The project profile could not be loaded."
        />
      ),
    },
  ],

  "project-settings-panel": [
    {
      id: "configured",
      label: "Configured",
      description: "Digest controls and the config editor are caller-supplied nodes; the panel parses nothing.",
      render: () => (
        <ProjectSettingsPanel
          eyebrow="Settings"
          title="UI Framework settings"
          status="Saved"
          statusTone="success"
          stats={projectSettingsStats}
          notices={projectSettingsNotices}
          summary={projectSettingsSummary}
          config={projectSettingsConfig}
        />
      ),
    },
    {
      id: "invalid-config",
      label: "Invalid config",
      description: "Validation copy comes from the product, so a rejected document is never silently saved as valid.",
      render: () => (
        <ProjectSettingsPanel
          eyebrow="Settings"
          title="UI Framework settings"
          status="Not saved"
          statusTone="danger"
          stats={projectSettingsStats}
          notices={[
            { id: "invalid", title: "Config document rejected", description: "Fix the JSON before saving.", tone: "danger" },
          ]}
          summary={projectSettingsSummary}
          config={projectSettingsInvalidConfig}
        />
      ),
    },
    {
      id: "never-sent",
      label: "Digest never sent",
      description: "An empty delivery log states that no digest has gone out rather than leaving the log area blank.",
      render: () => (
        <ProjectSettingsPanel
          eyebrow="Settings"
          title="UI Framework settings"
          status="Draft"
          statusTone="warning"
          summary={{ ...projectSettingsSummary, log: undefined, updatedAt: undefined }}
          config={projectSettingsConfig}
        />
      ),
    },
  ],

  "record-detail-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Fields and sections stay dense and read-only; editing lives entirely in the consuming app.",
      render: () => (
        <RecordDetailPanel
          eyebrow="Task"
          title="Author data-category states"
          subtitle="issue-1042"
          badges={[{ id: "review", label: "In review", tone: "info" }]}
          fields={recordDetailFields}
          sections={recordDetailSections}
          onClose={noop}
        />
      ),
    },
    {
      id: "empty-section",
      label: "Empty section",
      description: "A section with nothing recorded keeps its heading and says so, so a gap is never mistaken for an omission.",
      render: () => (
        <RecordDetailPanel
          eyebrow="Task"
          title="Author data-category states"
          subtitle="issue-1042"
          fields={recordDetailFields}
          sections={recordDetailSparseSections}
          onClose={noop}
        />
      ),
    },
    {
      id: "read-only",
      label: "Read-only",
      description: "With no actions or close handler the panel presents as reference detail with no control that would fail.",
      render: () => (
        <RecordDetailPanel
          eyebrow="Task"
          title="Author data-category states"
          subtitle="issue-1042"
          variant="compact"
          fields={recordDetailFields}
        />
      ),
    },
  ],

  "relationship-picker-panel": [
    {
      id: "selection",
      label: "Selection",
      description: "Selected and total counts are caller-computed so the header can never disagree with the checkboxes.",
      render: () => (
        <RelationshipPickerPanel
          eyebrow="Relationships"
          title="Regions"
          subtitle="Regions attached to this guide."
          items={relationshipPickerItems}
          selectedCount={2}
          totalCount={relationshipPickerItems.length}
          onSelectAll={noop}
          onClearSelection={noop}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "Counts stay blank while rows load, so a partial list never implies a partial selection.",
      render: () => (
        <RelationshipPickerPanel
          eyebrow="Relationships"
          title="Regions"
          items={[]}
          loading
          loadingLabel="Loading regions…"
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "With nothing to attach the select-all control is withdrawn rather than left as a no-op.",
      render: () => (
        <RelationshipPickerPanel
          eyebrow="Relationships"
          title="Regions"
          items={[]}
          emptyLabel="No regions are available to attach."
        />
      ),
    },
  ],

  "resource-index-panel": [
    {
      id: "ordered",
      label: "Ordered",
      description: "Move controls appear only when onItemMove exists, and the end-of-range buttons disable themselves.",
      render: () => (
        <ResourceIndexPanel
          eyebrow="Admin"
          title="Resources"
          status="6 resources"
          statusTone="info"
          items={resourceIndexItems}
          onItemSelect={noop}
          onItemMove={noop}
        />
      ),
    },
    {
      id: "read-only",
      label: "Read-only",
      description: "Without select or move callbacks rows render as inert titles rather than controls that lead nowhere.",
      render: () => (
        <ResourceIndexPanel
          eyebrow="Admin"
          title="Resources"
          status="Read-only"
          statusTone="neutral"
          layout="grid"
          items={resourceIndexItems.map(({ href: _href, actions: _actions, ...item }) => item)}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "An empty collection keeps the header actions so the first resource can be created from here.",
      render: () => (
        <ResourceIndexPanel
          eyebrow="Admin"
          title="Resources"
          items={[]}
          emptyLabel="No resources have been created yet."
          actions={<Button variant="ghost">New resource</Button>}
        />
      ),
    },
  ],

  "resource-transfer-dialog": [
    {
      id: "ready",
      label: "Ready",
      description: "Target and move-versus-copy are controlled, so the dialog never mutates the resource itself.",
      render: () => (
        <ResourceTransferDialog
          open
          placement="contained"
          resource={resourceTransferResource}
          targets={resourceTransferTargets}
          targetId={resourceTransferTargets[0]?.id ?? ""}
          move={false}
          allowMove
          onTargetChange={noop}
          onMoveChange={noop}
          onCancel={noop}
          onConfirm={noop}
        />
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description: "A transfer in flight locks confirmation so the same resource cannot be moved twice.",
      render: () => (
        <ResourceTransferDialog
          open
          placement="contained"
          resource={resourceTransferResource}
          targets={resourceTransferTargets}
          targetId={resourceTransferTargets[0]?.id ?? ""}
          move
          allowMove
          busy
          busyLabel="Transferring…"
          onTargetChange={noop}
          onCancel={noop}
          onConfirm={noop}
        />
      ),
    },
    {
      id: "no-targets",
      label: "No targets",
      description: "With no eligible destination confirmation stays disabled instead of offering a transfer that must fail.",
      render: () => (
        <ResourceTransferDialog
          open
          placement="contained"
          resource={resourceTransferResource}
          targets={[]}
          targetId=""
          move={false}
          emptyLabel="No project accepts this resource type."
          onTargetChange={noop}
          onCancel={noop}
          onConfirm={noop}
        />
      ),
    },
  ],

  "schedule-editor-dialog": [
    {
      id: "enabled",
      label: "Enabled",
      description: "Enabled state, schedule text, and extra fields are all controlled — the dialog parses no cron syntax.",
      render: () => (
        <ScheduleEditorDialog
          open
          placement="contained"
          eyebrow="Scheduler"
          title="Nightly spec guard"
          enabled
          schedule="0 2 * * *"
          firstStartAt="2026-08-30T02:00"
          meta={scheduleEditorMeta}
          checks={scheduleEditorChecks}
          fields={scheduleEditorFields}
          onClose={noop}
          onEnabledChange={noop}
          onScheduleChange={noop}
          onFirstStartAtChange={noop}
          onFieldChange={noop}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "disabled",
      label: "Disabled job",
      description: "A disabled job keeps its schedule visible so re-enabling never has to guess the previous pattern.",
      render: () => (
        <ScheduleEditorDialog
          open
          placement="contained"
          eyebrow="Scheduler"
          title="Nightly spec guard"
          enabled={false}
          schedule="0 2 * * *"
          meta={scheduleEditorMeta}
          checks={scheduleEditorChecks}
          statusTone="neutral"
          onClose={noop}
          onEnabledChange={noop}
          onScheduleChange={noop}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "saving",
      label: "Saving",
      description: "A save in flight locks submit so a half-applied schedule cannot be written twice.",
      render: () => (
        <ScheduleEditorDialog
          open
          placement="contained"
          eyebrow="Scheduler"
          title="Nightly spec guard"
          enabled
          schedule="0 2 * * *"
          fields={scheduleEditorFields}
          saving
          savingLabel="Saving…"
          submitDisabled
          onClose={noop}
          onEnabledChange={noop}
          onScheduleChange={noop}
          onFieldChange={noop}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],

  "scheduler-control-panel": [
    {
      id: "interactive",
      label: "Interactive",
      description: "Enablement renders as a control only where the product supplied a toggle callback.",
      render: () => (
        <SchedulerControlPanel
          eyebrow="Scheduler"
          title="Scheduled jobs"
          status="8 jobs"
          statusTone="info"
          schedulers={schedulerControlItems}
          onToggleScheduler={noop}
        />
      ),
    },
    {
      id: "read-only",
      label: "Read-only",
      description: "Without a toggle callback enablement renders as a badge, so a viewer never sees a control they cannot use.",
      render: () => (
        <SchedulerControlPanel
          eyebrow="Scheduler"
          title="Scheduled jobs"
          status="Read-only"
          statusTone="neutral"
          schedulers={schedulerControlItems}
        />
      ),
    },
    {
      id: "busy-row",
      label: "Row busy",
      description: "Only the job being written is locked; the rest of the list stays operable during the round trip.",
      render: () => (
        <SchedulerControlPanel
          eyebrow="Scheduler"
          title="Scheduled jobs"
          schedulers={schedulerControlItems}
          busySchedulerId={schedulerControlItems[0]?.id ?? null}
          onToggleScheduler={noop}
        />
      ),
    },
  ],

  "subscription-capacity-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Capacity, reset, and agent badges are caller-computed so the panel enforces no capacity policy.",
      render: () => (
        <SubscriptionCapacityPanel
          eyebrow="Fleet"
          title="Subscription capacity"
          ariaLabel="Subscription capacity"
          status="4 subscriptions"
          statusTone="info"
          metrics={subscriptionCapacityMetrics}
          subscriptions={subscriptionCapacityRows}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The panel footprint is preserved so the page does not reflow when capacity numbers arrive.",
      render: () => (
        <SubscriptionCapacityPanel
          eyebrow="Fleet"
          title="Subscription capacity"
          ariaLabel="Subscription capacity"
          subscriptions={[]}
          loading
          loadingLabel="Reading subscription capacity…"
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed capacity read shows nothing rather than stale headroom that could authorise an over-dispatch.",
      render: () => (
        <SubscriptionCapacityPanel
          eyebrow="Fleet"
          title="Subscription capacity"
          ariaLabel="Subscription capacity"
          subscriptions={[]}
          error="Subscription capacity could not be read from the provider."
        />
      ),
    },
  ],

  "theme-audit-panel": [
    {
      id: "clean",
      label: "Clean",
      description: "A component with no hardcoded values says so explicitly instead of leaving the gap list blank.",
      render: () => (
        <ThemeAuditPanel
          title="Theme audit"
          description="Token coverage before adoption."
          metrics={themeAuditMetrics}
          tokenGroups={themeAuditTokenGroups}
          gaps={[]}
          emptyGapsLabel="No hardcoded values were found."
          notes={themeAuditNotes}
        />
      ),
    },
    {
      id: "gaps",
      label: "Gaps",
      description: "Each hardcoded value names the class that owns it, so a gap is actionable without a second search.",
      render: () => (
        <ThemeAuditPanel
          title="Theme audit"
          metrics={themeAuditGapMetrics}
          tokenGroups={themeAuditTokenGroups}
          gaps={themeAuditGaps}
          notes={themeAuditNotes}
        />
      ),
    },
    {
      id: "no-tokens",
      label: "No tokens",
      description: "A surface that references no tokens is reported as unaudited, never as fully covered.",
      render: () => (
        <ThemeAuditPanel
          title="Theme audit"
          metrics={themeAuditGapMetrics}
          tokenGroups={[]}
          emptyTokensLabel="This component references no theme tokens yet."
          gaps={themeAuditGaps}
        />
      ),
    },
  ],

  "theme-export-panel": [
    {
      id: "ready",
      label: "Ready",
      description: "Format choice is controlled and every action is caller-owned — the panel serializes nothing itself.",
      render: () => (
        <ThemeExportPanel
          title="Export theme"
          description="Portable emibs-theme/1 artifact."
          badges={[{ id: "scope", label: "Full token set", tone: "info" }]}
          formats={themeExportFormats}
          activeFormatId="css"
          onFormatChange={noop}
          actions={[
            { id: "copy", label: "Copy", kind: "copy", onClick: noop },
            { id: "download", label: "Download", kind: "download", onClick: noop },
          ]}
          preview={themeExportPreview}
        />
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description: "A running export locks its own action while the format selector stays usable.",
      render: () => (
        <ThemeExportPanel
          title="Export theme"
          formats={themeExportFormats}
          activeFormatId="json"
          onFormatChange={noop}
          actions={[
            { id: "copy", label: "Copy", kind: "copy", disabled: true },
            { id: "download", label: "Download", kind: "download", busy: true, busyLabel: "Preparing…", onClick: noop },
          ]}
          preview={themeExportPreview}
        />
      ),
    },
    {
      id: "no-preview",
      label: "No preview",
      description: "A format with nothing generated yet keeps its controls rather than hiding the export surface.",
      render: () => (
        <ThemeExportPanel
          title="Export theme"
          formats={themeExportFormats}
          activeFormatId="json"
          onFormatChange={noop}
          actions={[{ id: "generate", label: "Generate", kind: "custom", onClick: noop }]}
          emptyPreviewLabel="Generate the artifact to preview it here."
        />
      ),
    },
  ],

  "theme-lab-panel": [
    {
      id: "empty",
      label: "No proposal",
      description: "The review surface is explicit before the first model response, so an empty preview never reads as a failure.",
      render: () => (
        <ThemeLabPanel
          title="Theme lab"
          description="Describe a theme, review the proposal, then apply it."
          prompt={themeLabPrompt}
          proposal={null}
          emptyProposalLabel="No proposal yet — generate one to review it here."
          generateAction={{ label: "Generate", onClick: noop }}
          applyAction={{ label: "Apply", disabled: true }}
        />
      ),
    },
    {
      id: "generating",
      label: "Generating",
      description: "Apply stays disabled while a proposal is in flight, so nothing can be applied before it is reviewed.",
      render: () => (
        <ThemeLabPanel
          title="Theme lab"
          prompt={{ ...themeLabPrompt, disabled: true }}
          proposal={null}
          emptyProposalLabel="Waiting for the model response…"
          generateAction={{ label: "Generate", busy: true, busyLabel: "Generating…", onClick: noop }}
          applyAction={{ label: "Apply", disabled: true }}
        />
      ),
    },
    {
      id: "proposal",
      label: "Proposal",
      description: "Contrast guardrails are shown beside the swatches so a failing pair is visible before apply is offered.",
      render: () => (
        <ThemeLabPanel
          title="Theme lab"
          prompt={themeLabPrompt}
          iteration={{ id: "theme-lab-iteration", label: "Refine", value: "", rows: 2, onChange: noop }}
          proposal={themeLabProposal}
          generateAction={{ label: "Regenerate", onClick: noop }}
          applyAction={{ label: "Apply", onClick: noop }}
        />
      ),
    },
  ],

  "theme-preview-canvas": [
    {
      id: "single",
      label: "Single surface",
      description: "One surface hosts the fixture at the caller's canvas width without imposing a page layout.",
      render: () => (
        <ThemePreviewCanvas
          mode="single"
          ariaLabel="Theme preview"
          singleSurface={{ label: "Current theme" }}
          canvasWidth="360px"
        >
          {themePreviewFixture}
        </ThemePreviewCanvas>
      ),
    },
    {
      id: "compare",
      label: "Compare",
      description: "Compare mode renders the same fixture per surface so a difference can only come from the theme.",
      render: () => (
        <ThemePreviewCanvas
          mode="compare"
          ariaLabel="Theme comparison"
          compareSurfaces={themePreviewCompareSurfaces}
          canvasWidth="320px"
        >
          {themePreviewFixture}
        </ThemePreviewCanvas>
      ),
    },
    {
      id: "empty",
      label: "No surfaces",
      description: "A generated run with no surfaces yet keeps a stable canvas rather than collapsing the review area.",
      render: () => (
        <ThemePreviewCanvas
          mode="generated"
          ariaLabel="Theme preview"
          generatedSurfaces={[]}
          emptyLabel="No generated surfaces to preview yet."
        >
          {themePreviewFixture}
        </ThemePreviewCanvas>
      ),
    },
  ],

  "work-board-toolbar": [
    {
      id: "unfiltered",
      label: "Unfiltered",
      description: "With nothing applied the chip strip stays empty rather than showing a default that was never chosen.",
      render: () => (
        <WorkBoardToolbar
          eyebrow="Board"
          title="Delivery board"
          badges={workBoardToolbarBadges}
          search={{ value: "", placeholder: "Search work items", onChange: noop }}
          project={{ label: "Project", value: "", options: workBoardProjectOptions, onChange: noop }}
          epic={{ label: "Epic", value: "", options: workBoardEpicOptions, onChange: noop }}
          onFiltersOpenChange={noop}
        />
      ),
    },
    {
      id: "filtered",
      label: "Filtered",
      description: "Every active filter has a removable chip, so the board's contents can always be explained from the toolbar.",
      render: () => (
        <WorkBoardToolbar
          eyebrow="Board"
          title="Delivery board"
          badges={workBoardToolbarBadges}
          search={{ value: "states", placeholder: "Search work items", onChange: noop }}
          project={{ label: "Project", value: workBoardProjectOptions[1]?.value ?? "", options: workBoardProjectOptions, onChange: noop }}
          epic={{ label: "Epic", value: workBoardEpicOptions[1]?.value ?? "", options: workBoardEpicOptions, onChange: noop }}
          filtersOpen
          activeFilters={[
            { id: "query", label: 'Search: "states"', onRemove: noop },
            { id: "project", label: "Project: UI", onRemove: noop },
          ]}
          clearFiltersAction={<Button variant="ghost">Clear all</Button>}
          onFiltersOpenChange={noop}
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed filter load reports the failure while leaving the search field usable.",
      render: () => (
        <WorkBoardToolbar
          eyebrow="Board"
          title="Delivery board"
          search={{ value: "", placeholder: "Search work items", onChange: noop }}
          project={{ label: "Project", value: "", options: [], disabled: true }}
          error="Project and epic filters could not be loaded."
        />
      ),
    },
  ],

  "work-item-card": [
    {
      id: "default",
      label: "Default",
      description: "Id, badges, and the parent epic sit under one open affordance that the product routes.",
      render: () => <WorkItemCard {...workItemCards[0]} onOpen={noop} />,
    },
    {
      id: "selected",
      label: "Selected",
      description: "Selection is caller-owned, so a board and its detail pane can never disagree about the active card.",
      render: () => <WorkItemCard {...workItemCards[1]} selected onOpen={noop} />,
    },
    {
      id: "disabled",
      label: "Disabled",
      description: "A card the actor cannot open withdraws the affordance rather than routing to a permission error.",
      render: () => <WorkItemCard {...workItemCards[2]} disabled />,
    },
  ],

  "work-item-planning-panel": [
    {
      id: "drafting",
      label: "Drafting",
      description: "Work-item and triage drafts are separate controlled objects, so triage never edits the item by accident.",
      render: () => (
        <WorkItemPlanningPanel
          eyebrow="Planning"
          title="Plan work item"
          workItem={workItemDraft}
          triage={workItemTriage}
          typeOptions={workItemTypeOptions}
          projectOptions={workItemProjectOptions}
          roleOptions={workItemRoleOptions}
          complexityOptions={workItemComplexityOptions}
          epicOptions={workItemEpicOptions}
          canMoveProject
          onWorkItemChange={noop}
          onTriageChange={noop}
          onSave={noop}
          onTriage={noop}
          onCancel={noop}
        />
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description: "A pending save locks every submit route so one plan cannot be written twice.",
      render: () => (
        <WorkItemPlanningPanel
          eyebrow="Planning"
          title="Plan work item"
          workItem={workItemDraft}
          triage={workItemTriage}
          typeOptions={workItemTypeOptions}
          projectOptions={workItemProjectOptions}
          busy
          onWorkItemChange={noop}
          onTriageChange={noop}
          onSave={noop}
        />
      ),
    },
    {
      id: "blocked",
      label: "Blocked",
      description: "A rejected plan keeps the draft intact so the writer corrects the field instead of retyping the item.",
      render: () => (
        <WorkItemPlanningPanel
          eyebrow="Planning"
          title="Plan work item"
          status="Not saved"
          statusTone="danger"
          messages={[{ id: "epic", tone: "danger", children: "The parent epic does not exist in project UI." }]}
          workItem={workItemDraft}
          triage={workItemTriage}
          typeOptions={workItemTypeOptions}
          projectOptions={workItemProjectOptions}
          onWorkItemChange={noop}
          onTriageChange={noop}
          onSave={noop}
        />
      ),
    },
  ],

  "work-item-relation-editor-panel": [
    {
      id: "editing",
      label: "Editing",
      description: "Each relation field owns its own draft value and tags, so one field's edit never disturbs another.",
      render: () => (
        <WorkItemRelationEditorPanel
          eyebrow="Relations"
          title="Work item relations"
          subtitle="issue-1042"
          fields={relationEditorFields}
          actions={<Button>Save relations</Button>}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "Committed tags stay hidden while relations load so a partial set is never saved back as complete.",
      render: () => (
        <WorkItemRelationEditorPanel
          eyebrow="Relations"
          title="Work item relations"
          fields={[]}
          loading
          loadingLabel="Loading relations…"
        />
      ),
    },
    {
      id: "no-fields",
      label: "No relation types",
      description: "A work-item type with no relation fields says so rather than presenting an empty editor to save.",
      render: () => (
        <WorkItemRelationEditorPanel
          eyebrow="Relations"
          title="Work item relations"
          fields={[]}
          emptyFieldsLabel="This work-item type defines no relations."
        />
      ),
    },
  ],

  "work-item-trace-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Relation groups and review notes render side by side without the panel creating or mutating a review.",
      render: () => (
        <WorkItemTracePanel
          eyebrow="Trace"
          title="Delivery trace"
          subtitle="issue-1042"
          status="In review"
          statusTone="info"
          relationGroups={workItemTraceRelationGroups}
          notes={workItemTraceNotes}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "Relations and notes carry separate empty copy, so an unreviewed item is distinguishable from an unlinked one.",
      render: () => (
        <WorkItemTracePanel
          eyebrow="Trace"
          title="Delivery trace"
          subtitle="issue-1042"
          relationGroups={[]}
          emptyRelationsLabel="No relations have been recorded."
          notes={[]}
          emptyNotesLabel="No review notes yet."
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed trace read shows no notes at all rather than a subset that would misrepresent the review history.",
      render: () => (
        <WorkItemTracePanel
          eyebrow="Trace"
          title="Delivery trace"
          subtitle="issue-1042"
          error="The delivery trace could not be read."
        />
      ),
    },
  ],

  "workflow-command-bar": [
    {
      id: "available",
      label: "Available",
      description: "Each command shows its destination state, so a transition is never taken without its consequence visible.",
      render: () => (
        <WorkflowCommandBar
          eyebrow="Workflow"
          title="Transitions"
          currentState="In review"
          currentStateTone="info"
          commands={workflowCommandBarCommands}
        />
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description: "A transition in flight locks that one command while the rest of the bar stays legible.",
      render: () => (
        <WorkflowCommandBar
          eyebrow="Workflow"
          title="Transitions"
          currentState="In review"
          currentStateTone="info"
          status="Applying…"
          statusTone="warning"
          commands={workflowCommandBarCommands.map((command, index) =>
            index === 0 ? { ...command, busy: true } : { ...command, disabled: true },
          )}
        />
      ),
    },
    {
      id: "terminal",
      label: "No transitions",
      description: "A terminal state offers no command at all rather than a disabled row that implies a route still exists.",
      render: () => (
        <WorkflowCommandBar
          eyebrow="Workflow"
          title="Transitions"
          currentState="Done"
          currentStateTone="success"
          commands={[]}
          emptyLabel="No transitions are legal from this state."
        />
      ),
    },
  ],

  "workflow-map-panel": [
    {
      id: "populated",
      label: "Populated",
      description: "Stage order and counts come from the caller, so the map never infers a workflow the product does not run.",
      render: () => (
        <WorkflowMapPanel
          eyebrow="Workflow"
          title="Delivery map"
          ariaLabel="Delivery workflow map"
          status="13 in flight"
          statusTone="info"
          insights={[
            { id: "throughput", label: "Merged today", value: "9", tone: "success" },
            { id: "stalled", label: "Stalled > 24h", value: "2", tone: "warning" },
          ]}
          stages={workflowMapStages}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The panel footprint is preserved so stage columns do not jump into place as rows resolve.",
      render: () => (
        <WorkflowMapPanel
          eyebrow="Workflow"
          title="Delivery map"
          ariaLabel="Delivery workflow map"
          stages={[]}
          loading
          loadingLabel="Loading the delivery map…"
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A failed board read shows no stages rather than a partial map that would understate what is stalled.",
      render: () => (
        <WorkflowMapPanel
          eyebrow="Workflow"
          title="Delivery map"
          ariaLabel="Delivery workflow map"
          stages={[]}
          error="The delivery map could not be read from the board."
        />
      ),
    },
  ],
};
