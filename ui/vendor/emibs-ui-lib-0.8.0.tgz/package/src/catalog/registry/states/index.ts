import { addressStates } from "../address";
import { templateStates } from "../templates";
import type { StatePreview } from "../../types";
import { primitivesStates } from "./primitives";
import { layoutStates } from "./layout";
import { dataStates } from "./data";
import { feedbackStates } from "./feedback";
import { authStates } from "./auth";

// Explicit component states are deliberately separate from ordinary variants.
// New E2/E4 registry entries enter the States tab and lifecycle gate by adding
// metadata here; no Explorer or coverage code changes are required.
export const STATES: Record<string, StatePreview[]> = {
  ...addressStates,
  ...templateStates,
  ...primitivesStates,
  ...layoutStates,
  ...dataStates,
  ...feedbackStates,
  ...authStates,
};
