import type { ReactNode } from "react";
import type { StatePreview } from "../../types";
import {
  BlastRadiusConfirmDemo,
  ConfirmationDialogRegistryDemo,
} from "../demoComponents";
import { ActivityCenter, type ActivityCenterItem } from "../../../components/feedback/ActivityCenter";
import { AlertDialogFrame } from "../../../components/feedback/AlertDialogFrame";
import { AlertLane } from "../../../components/feedback/AlertLane";
import { CookieConsentBanner } from "../../../components/feedback/CookieConsentBanner";
import { CreationDialog } from "../../../components/feedback/CreationDialog";
import { DataStatePanel } from "../../../components/feedback/DataStatePanel";
import { DialogFrame } from "../../../components/feedback/DialogFrame";
import { LoadingState } from "../../../components/feedback/LoadingState";
import { NoticeBanner } from "../../../components/feedback/NoticeBanner";
import { NotificationBell } from "../../../components/feedback/NotificationBell";
import { NotificationToggle } from "../../../components/feedback/NotificationToggle";
import { ToastStack } from "../../../components/feedback/ToastStack";
import { ValidationSummary } from "../../../components/feedback/ValidationSummary";
import { Button } from "../../../components/primitives/Button";
import { Skeleton } from "../../../components/primitives/Skeleton";
import { ValidationErrorUxCatalogDemo } from "../../../forms";
import {
  toastStackItems,
  validationSummaryProfileItems,
  validationSummarySettingsItems,
} from "../../../demos/data";

const noop = () => undefined;

/**
 * Contained overlay placements are `position: absolute; inset: 0`, so a state
 * preview has to supply the positioned, bounded stage the product page would
 * otherwise be. Geometry only — tone and colour stay with the component.
 */
function ContainedStage({ children, minHeight = 300 }: { children: ReactNode; minHeight?: number }) {
  return <div style={{ position: "relative", minHeight, overflow: "hidden" }}>{children}</div>;
}

/**
 * ActivityCenter is flat by design (it renders no surface); the consuming app
 * owns the dropdown/drawer it is mounted in. This stands in for that surface
 * using theme tokens only.
 */
function PanelSurface({ children }: { children: ReactNode }) {
  return (
    <div
      style={{
        width: "min(100%, 380px)",
        maxHeight: 380,
        display: "flex",
        overflow: "hidden",
        border: "1px solid var(--border)",
        borderRadius: "var(--radius-md)",
        background: "var(--surface)",
      }}
    >
      {children}
    </div>
  );
}

/** Fixed formatter so state previews stay stable instead of drifting with wall time. */
const fixedTimestamps: Record<string, string> = {
  "review-requested": "4m ago",
  "run-finished": "1h ago",
  "digest-ready": "2d ago",
};
const formatActivityTimestamp = (iso: string) => fixedTimestamps[iso] ?? iso;

const activityItems: ActivityCenterItem[] = [
  {
    id: "review-requested",
    title: "Review requested on issue-915",
    body: "The reviewer lane picked up the branch and is waiting on you.",
    read: false,
    createdAt: "review-requested",
    link: "#/c/activity-center",
    type: "review.requested",
  },
  {
    id: "run-finished",
    title: "Nightly extraction run finished",
    body: "42 records imported, 3 skipped.",
    read: false,
    createdAt: "run-finished",
    type: "run.finished",
  },
  {
    id: "digest-ready",
    title: "Weekly digest ready",
    read: true,
    createdAt: "digest-ready",
    link: "#/c/activity-center",
    type: "digest.ready",
  },
];

const consentCategories = [
  {
    id: "essential",
    label: "Essential",
    description: "Session, security, and consent storage. Always on.",
    checked: true,
    locked: true,
  },
  {
    id: "analytics",
    label: "Analytics",
    description: "Aggregated usage measurement the app may enable after consent.",
    checked: false,
  },
  {
    id: "marketing",
    label: "Marketing",
    description: "Campaign attribution supplied by the consuming app's SDKs.",
    checked: true,
  },
];

const creationSections = [
  {
    id: "identity",
    title: "Identity",
    description: "The shared dialog lays out fields it does not own.",
    fields: [
      {
        id: "title",
        label: "Title",
        required: true,
        wide: true,
        control: <input className="ui-input" defaultValue="Extract the creation dialog" />,
      },
      {
        id: "type",
        label: "Type",
        control: <input className="ui-input" defaultValue="story" readOnly />,
      },
    ],
  },
];


export const feedbackStates: Record<string, StatePreview[]> = {
  "confirmation-dialog": [
    {
      id: "busy",
      label: "Busy",
      description: "A pending product mutation locks Escape, backdrop, close, cancel, and confirm while the alertdialog remains labelled.",
      render: () => <ConfirmationDialogRegistryDemo busy />,
    },
  ],
  "blast-radius-confirm": [
    {
      id: "pending",
      label: "Pending write",
      description: "The caller-computed impact remains visible while the shared confirmation frame is locked.",
      render: () => <BlastRadiusConfirmDemo pending />,
    },
  ],
  "validation-error-ux-demo": [
    {
      id: "submit-timing",
      label: "Submit timing",
      description:
        "onSubmit mode: nothing is marked until a blocked submit, which then reveals the summary and requests focus on the first errored field.",
      render: () => <ValidationErrorUxCatalogDemo idPrefix="state-submit" initialMode="onSubmit" />,
    },
    {
      id: "blur-timing",
      label: "Blur timing",
      description: "onBlur mode: each field reports as it loses focus, so errors accumulate before the first submit attempt.",
      render: () => <ValidationErrorUxCatalogDemo idPrefix="state-blur" initialMode="onBlur" />,
    },
    {
      id: "change-timing",
      label: "Change timing",
      description: "onChange mode: validation runs on every keystroke and clears the moment a field becomes valid again.",
      render: () => <ValidationErrorUxCatalogDemo idPrefix="state-change" initialMode="onChange" />,
    },
  ],
  "alert-dialog-frame": [
    {
      id: "blocking",
      label: "Blocking",
      description:
        "Defaults force an explicit choice: no close control, no backdrop dismissal, and the footer actions are the only exit.",
      render: () => (
        <ContainedStage minHeight={320}>
          <AlertDialogFrame
            open
            placement="contained"
            title="Apply workflow transition?"
            description="Transition legality, the write, and the audit event stay with the consuming route."
            footer={
              <>
                <Button type="button" variant="secondary" size="sm" onClick={noop}>
                  Cancel
                </Button>
                <Button type="button" size="sm" onClick={noop}>
                  Apply
                </Button>
              </>
            }
            onClose={noop}
          />
        </ContainedStage>
      ),
    },
    {
      id: "dismissible",
      label: "Dismissible",
      description:
        "A lower-risk informational alert opts into both close affordances: showClose renders the labelled control and closeOnBackdrop re-enables backdrop dismissal.",
      render: () => (
        <ContainedStage minHeight={320}>
          <AlertDialogFrame
            open
            closeOnBackdrop
            placement="contained"
            showClose
            size="sm"
            title="Release notes updated"
            description="Informational alerts can be dismissed without choosing a footer action."
            footer={
              <Button type="button" size="sm" onClick={noop}>
                Got it
              </Button>
            }
            onClose={noop}
          />
        </ContainedStage>
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description:
        "While the product write is in flight the close control is disabled and Escape and backdrop dismissal are both suppressed, so the frame cannot be abandoned mid-mutation.",
      render: () => (
        <ContainedStage minHeight={320}>
          <AlertDialogFrame
            busy
            open
            closeOnBackdrop
            placement="contained"
            showClose
            title="Applying workflow transition"
            description="The frame stays labelled and described while the consuming app completes the write."
            footer={
              <Button type="button" size="sm" disabled>
                Applying…
              </Button>
            }
            onClose={noop}
          />
        </ContainedStage>
      ),
    },
  ],
  "cookie-consent-banner": [
    {
      id: "consent-pending",
      label: "Consent pending",
      description:
        "First visit: the labelled dialog offers manage, reject, and accept-all while the preference panel stays collapsed and aria-expanded reads false.",
      render: () => (
        <CookieConsentBanner
          categories={consentCategories}
          description="Optional categories stay off until the consuming app records a decision."
          dock="contained"
          title="We use cookies"
          onPreferencesOpenChange={noop}
        />
      ),
    },
    {
      id: "preferences-open",
      label: "Preferences open",
      description:
        "The expanded region lists controlled category rows; the essential row is locked and disabled so it can be read but never switched off.",
      render: () => (
        <CookieConsentBanner
          categories={consentCategories}
          description="Optional categories stay off until the consuming app records a decision."
          dock="contained"
          preferencesOpen
          title="We use cookies"
          onPreferencesOpenChange={noop}
          onSavePreferences={noop}
        />
      ),
    },
    {
      id: "essential-only",
      label: "Essential only",
      description:
        "A product with no optional categories hides the manage action; the remaining buttons keep plain button semantics and the dialog title still labels the banner.",
      render: () => (
        <CookieConsentBanner
          description="We use cookies to keep the portal working. No optional categories are set."
          dock="contained"
          rejectLabel="Essential only"
          showManageAction={false}
          title="Cookie notice"
          tone="inverse"
          onAcceptAll={noop}
          onRejectNonEssential={noop}
        />
      ),
    },
  ],
  "creation-dialog": [
    {
      id: "editing",
      label: "Editing",
      description: "The default intake state: fields are live, and cancel, submit, Escape, and backdrop dismissal are all available.",
      render: () => (
        <ContainedStage minHeight={420}>
          <CreationDialog
            open
            eyebrow="Board"
            placement="contained"
            sections={creationSections}
            title="New issue"
            onClose={noop}
            onSubmit={(event) => event.preventDefault()}
          />
        </ContainedStage>
      ),
    },
    {
      id: "submitting",
      label: "Submitting",
      description:
        "submitting swaps in submittingLabel, disables cancel, submit, and the close control, and suppresses Escape and backdrop close until the product write settles.",
      render: () => (
        <ContainedStage minHeight={420}>
          <CreationDialog
            open
            eyebrow="Board"
            placement="contained"
            sections={creationSections}
            submitting
            submittingLabel="Creating…"
            title="New issue"
            onClose={noop}
          />
        </ContainedStage>
      ),
    },
    {
      id: "submit-blocked",
      label: "Submit blocked",
      description:
        "submitDisabled is the consumer's validation gate: only the submit button is disabled, so cancel and dismissal stay reachable.",
      render: () => (
        <ContainedStage minHeight={420}>
          <CreationDialog
            open
            eyebrow="Board"
            placement="contained"
            sections={creationSections}
            submitDisabled
            title="New issue"
            onClose={noop}
            onSubmit={(event) => event.preventDefault()}
          />
        </ContainedStage>
      ),
    },
  ],
  "data-state-panel": [
    {
      id: "loading",
      label: "Loading",
      description: "The loading tone marks the region aria-busy and keeps status semantics, so the wait is announced once rather than per placeholder.",
      render: () => (
        <DataStatePanel
          description="Fetching the latest runtime settings."
          eyebrow="settings"
          title="Loading settings"
          tone="loading"
        >
          <Skeleton variant="text" />
          <Skeleton variant="text" />
        </DataStatePanel>
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A resolved-but-empty result keeps status semantics and offers the product's own next action instead of reading as a failure.",
      render: () => (
        <DataStatePanel
          actions={
            <Button type="button" size="sm" onClick={noop}>
              Create the first record
            </Button>
          }
          description="No records match the current filters."
          title="Nothing here yet"
          tone="empty"
        />
      ),
    },
    {
      id: "success",
      label: "Success",
      description: "A completed outcome stays a polite status region, so it never interrupts the reader mid-task.",
      render: () => (
        <DataStatePanel
          description="42 records imported and 3 skipped."
          eyebrow="import"
          title="Import finished"
          tone="success"
        />
      ),
    },
    {
      id: "danger",
      label: "Error",
      description: "Warning and danger tones escalate to role=alert with an assertive live region; retry policy stays with the consuming app.",
      render: () => (
        <DataStatePanel
          actions={
            <Button type="button" size="sm" variant="secondary" onClick={noop}>
              Try again
            </Button>
          }
          description="The settings service did not respond."
          title="Could not load settings"
          tone="danger"
        />
      ),
    },
  ],
  "dialog-frame": [
    {
      id: "open",
      label: "Open",
      description: "The idle frame: the close control is shown and Escape and backdrop dismissal both reach onClose.",
      render: () => (
        <ContainedStage minHeight={360}>
          <DialogFrame
            open
            eyebrow="Board"
            placement="contained"
            size="md"
            status="processing"
            statusTone="warning"
            subtitle="A controlled frame around product-owned detail content."
            title="Task detail"
            onClose={noop}
          >
            <p>Loading, editing, permissions, and persistence stay outside the frame.</p>
          </DialogFrame>
        </ContainedStage>
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description:
        "busy disables the close control and suppresses Escape and backdrop close, so an in-flight save cannot be abandoned; the title and subtitle stay wired up.",
      render: () => (
        <ContainedStage minHeight={360}>
          <DialogFrame
            busy
            open
            eyebrow="Board"
            placement="contained"
            size="md"
            status="saving"
            statusTone="info"
            subtitle="Close affordances are locked until the product write settles."
            title="Task detail"
            onClose={noop}
          >
            <p>The frame keeps its content mounted while the consuming app finishes the mutation.</p>
          </DialogFrame>
        </ContainedStage>
      ),
    },
    {
      id: "no-dismiss",
      label: "No dismiss affordance",
      description:
        "With showClose and closeOnBackdrop both off, the frame renders no dismissal control at all and the footer owns the only exit.",
      render: () => (
        <ContainedStage minHeight={360}>
          <DialogFrame
            open
            closeOnBackdrop={false}
            footer={
              <Button type="button" size="sm" onClick={noop}>
                Acknowledge
              </Button>
            }
            placement="contained"
            showClose={false}
            size="md"
            subtitle="The product requires an explicit acknowledgement before the frame closes."
            title="Migration notice"
            onClose={noop}
          />
        </ContainedStage>
      ),
    },
  ],
  "notice-banner": [
    {
      id: "info",
      label: "Info",
      description: "Neutral and info tones default to role=status with a polite live region, so an ambient notice never interrupts.",
      render: () => (
        <NoticeBanner title="Scheduled maintenance">
          The board is read-only between 02:00 and 02:30 UTC.
        </NoticeBanner>
      ),
    },
    {
      id: "success",
      label: "Success",
      description: "A confirmation after a product-owned write; still a polite status region rather than an alert.",
      render: () => (
        <NoticeBanner tone="success" title="Settings saved">
          The consuming app owns the request, the retry policy, and this copy.
        </NoticeBanner>
      ),
    },
    {
      id: "warning",
      label: "Warning",
      description: "Warning escalates the default semantics to role=alert with an assertive live region.",
      render: () => (
        <NoticeBanner
          action={
            <Button type="button" size="sm" variant="secondary" onClick={noop}>
              Review
            </Button>
          }
          title="Capacity is close to its ceiling"
          tone="warning"
        >
          Two lanes are queued behind the current subscription band.
        </NoticeBanner>
      ),
    },
    {
      id: "danger-dismissible",
      label: "Danger, dismissible",
      description:
        "Danger is announced assertively, and supplying onDismiss adds the labelled dismiss control; whether the banner returns is the app's data cycle, not a timer here.",
      render: () => (
        <NoticeBanner dismissLabel="Dismiss import error" title="Import rejected" tone="danger" onDismiss={noop}>
          Row 14 has no external id.
        </NoticeBanner>
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The loading tone swaps in the animated icon, which reduced-motion preferences suppress; the banner stays a polite status region.",
      render: () => (
        <NoticeBanner density="compact" tone="loading" title="Reconnecting to the runtime">
          The product owns the retry schedule.
        </NoticeBanner>
      ),
    },
  ],
  "notification-toggle": [
    {
      id: "unsubscribed",
      label: "Unsubscribed",
      description: "aria-pressed is false and the default label states the current outcome before the reverse action.",
      render: () => (
        <NotificationToggle
          subscribed={false}
          unsubscribedDescription="Updates on this task will not reach your inbox."
          onChange={noop}
        />
      ),
    },
    {
      id: "subscribed",
      label: "Subscribed",
      description: "aria-pressed flips to true and the label leads with the current outcome, then the action that reverses it.",
      render: () => (
        <NotificationToggle
          subscribed
          status="4 subscribers"
          subscribedDescription="Updates on this task are emailed to you."
          onChange={noop}
        />
      ),
    },
    {
      id: "busy",
      label: "Busy",
      description:
        "While the consuming app persists the preference the button announces aria-busy and dims, but stays focusable and in the tab order — a keyboard user must not lose the control at the moment they activate it. Re-entry is blocked in the click handler instead, so a click while busy emits nothing.",
      render: () => (
        <NotificationToggle busy status="Saving…" subscribed={false} onChange={noop} />
      ),
    },
    {
      id: "disabled",
      label: "Disabled",
      description: "A permission or capability gate removes interactivity outright, with no aria-busy claim that work is in flight.",
      render: () => (
        <NotificationToggle
          disabled
          subscribed={false}
          unsubscribedDescription="Email delivery is not configured for this workspace."
          onChange={noop}
        />
      ),
    },
  ],
  "notification-bell": [
    {
      id: "no-unread",
      label: "No unread",
      description: "At zero the badge is not rendered and the accessible name still states the count before the open action.",
      render: () => <NotificationBell unreadCount={0} onClick={noop} />,
    },
    {
      id: "unread",
      label: "Unread",
      description: "A positive count renders the decorative badge and is repeated in the accessible name, which is the only announced source.",
      render: () => <NotificationBell controlsId="bell-state-panel" unreadCount={7} onClick={noop} />,
    },
    {
      id: "overflow",
      label: "Overflow",
      description: "Counts above max render as {max}+ in the badge while the accessible name keeps the exact total.",
      render: () => <NotificationBell max={99} unreadCount={248} onClick={noop} />,
    },
    {
      id: "open",
      label: "Open",
      description: "While the panel it controls is shown, aria-expanded is true and the accessible name switches its action half to close.",
      render: () => <NotificationBell controlsId="bell-state-panel" open unreadCount={7} onClick={noop} />,
    },
    {
      id: "disabled",
      label: "Disabled",
      description: "Non-interactive: the badge still reflects the count, but the disclosure cannot be toggled.",
      render: () => <NotificationBell disabled unreadCount={7} onClick={noop} />,
    },
  ],
  "activity-center": [
    {
      id: "ready",
      label: "Ready",
      description:
        "Notifications newest-first with unread rows accented; a row with a link is a real anchor, one without is a button, and both report through onItemSelect.",
      render: () => (
        <PanelSurface>
          <ActivityCenter
            className="ui-activity-center--fill"
            formatTimestamp={formatActivityTimestamp}
            items={activityItems}
            onItemSelect={noop}
            onMarkAllRead={noop}
          />
        </PanelSurface>
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description:
        "The initial load renders three skeleton rows inside one aria-busy, polite region carrying a visually hidden “Loading notifications…” line; the header action is disabled off the ready state.",
      render: () => (
        <PanelSurface>
          <ActivityCenter
            className="ui-activity-center--fill"
            items={[]}
            status="loading"
            onMarkAllRead={noop}
          />
        </PanelSurface>
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A resolved, empty inbox states that everything is caught up instead of leaving the panel ambiguous.",
      render: () => (
        <PanelSurface>
          <ActivityCenter className="ui-activity-center--fill" items={[]} onMarkAllRead={noop} />
        </PanelSurface>
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "A load failure renders a role=alert panel with the caller's detail and an optional retry; fetching and reconnection stay in the hook.",
      render: () => (
        <PanelSurface>
          <ActivityCenter
            className="ui-activity-center--fill"
            error="The notifications service did not respond."
            items={[]}
            status="error"
            onRetry={noop}
          />
        </PanelSurface>
      ),
    },
    {
      id: "paginating",
      label: "Paginating",
      description: "With hasMore set, the cursor control appears; loadingMore disables it and marks it aria-busy while the next page resolves.",
      render: () => (
        <PanelSurface>
          <ActivityCenter
            className="ui-activity-center--fill"
            formatTimestamp={formatActivityTimestamp}
            hasMore
            items={activityItems}
            loadingMore
            onItemSelect={noop}
            onLoadMore={noop}
          />
        </PanelSurface>
      ),
    },
  ],
  "toast-stack": [
    {
      id: "stacked",
      label: "Stacked",
      description: "Several live messages share one polite region; danger items individually take role=alert while the rest stay status.",
      render: () => <ToastStack items={toastStackItems} />,
    },
    {
      id: "dismissible",
      label: "Dismissible",
      description:
        "A per-item onDismiss renders the labelled control and reports the id back; there is no timer here, so a toast is sticky until the app removes it.",
      render: () => (
        <ToastStack
          items={[
            {
              id: "import-failed",
              title: "Import failed",
              description: "Row 14 has no external id.",
              tone: "danger",
              meta: "just now",
              dismissLabel: "Dismiss import failure",
              onDismiss: noop,
            },
          ]}
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description: "The loading tone renders the spinner icon for work the app has started but not yet resolved into a success or error toast.",
      render: () => (
        <ToastStack
          items={[
            {
              id: "export-running",
              title: "Preparing export",
              description: "The consuming app owns the job, its progress, and the follow-up toast.",
              tone: "loading",
              meta: "12s",
            },
          ]}
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "With no items the labelled region still renders its empty line, so a mounted stack is never mistaken for a broken one.",
      render: () => <ToastStack items={[]} />,
    },
  ],
  "validation-summary": [
    {
      id: "errors",
      label: "Errors",
      description:
        "Items present default the tone to danger, which takes role=alert with an assertive live region; each item carries its own message.",
      render: () => (
        <ValidationSummary
          description="Three fields are blocking the save."
          items={validationSummaryProfileItems}
          title="Resolve these fields"
        />
      ),
    },
    {
      id: "focus-routing",
      label: "Focus routing",
      description:
        "Items without an href or controlId render as buttons instead of anchors, so onItemSelect can request focus without the summary owning form state.",
      render: () => (
        <ValidationSummary
          items={validationSummarySettingsItems.map(({ controlId: _controlId, ...item }) => item)}
          title="Resolve these fields"
          onItemSelect={noop}
        />
      ),
    },
    {
      id: "warning",
      label: "Warning",
      description: "A warning tone still uses alert semantics but marks issues the product treats as advisory rather than blocking.",
      render: () => (
        <ValidationSummary
          density="compact"
          description="The form can be saved, but these will be flagged on publish."
          items={validationSummarySettingsItems}
          title="Review before publishing"
          tone="warning"
        />
      ),
    },
    {
      id: "success",
      label: "Success",
      description:
        "An empty item list defaults the tone to success and renders emptyLabel under polite status semantics, so a clean form reads as ready rather than blank.",
      render: () => (
        <ValidationSummary
          emptyLabel="No validation issues."
          title="Ready to submit"
        />
      ),
    },
  ],
  "alert-lane": [
    {
      id: "findings",
      label: "Open findings",
      description: "Live findings render as chips whose severity drives the token colour through data-severity, each with an optional deep link.",
      render: () => (
        <AlertLane
          alerts={[
            { id: "tick", title: "Scheduler tick stale (12m)", severity: "critical", href: "#/runtime", detail: "no tick since 03:14Z" },
            { id: "rotation", title: "Doctor: orphaned rotation endpoint", severity: "warning", href: "#/admin" },
            { id: "queue", title: "Review queue depth 14", severity: "info", href: "#/board" },
          ]}
        />
      ),
    },
    {
      id: "partially-dismissed",
      label: "Partially dismissed",
      description:
        "Controlled dismissal: with dismissedIds and onDismiss the app owns which chips are hidden, and a still-open finding returns on the next snapshot.",
      render: () => (
        <AlertLane
          alerts={[
            { id: "tick", title: "Scheduler tick stale (12m)", severity: "critical", href: "#/runtime" },
            { id: "rotation", title: "Doctor: orphaned rotation endpoint", severity: "warning" },
            { id: "queue", title: "Review queue depth 14", severity: "info" },
          ]}
          dismissedIds={["rotation", "queue"]}
          onDismiss={noop}
        />
      ),
    },
    {
      id: "not-dismissable",
      label: "Not dismissable",
      description: "dismissable=false removes the control entirely, for lanes whose findings must stay on screen until the data says otherwise.",
      render: () => (
        <AlertLane
          alerts={[{ id: "budget", title: "Subscription band exhausted", severity: "error" }]}
          dismissable={false}
        />
      ),
    },
    {
      id: "all-clear",
      label: "All clear",
      description: "An empty or fully dismissed set renders the quiet all-clear chip, so an empty lane is never ambiguous.",
      render: () => <AlertLane alerts={[]} clearLabel="No open sentinel or doctor findings" />,
    },
  ],
  "loading-state": [
    {
      id: "busy",
      label: "Busy",
      description:
        "The preset marks one aria-busy status region and announces the title once; the repeated skeleton rows are decorative and stay hidden from assistive technology.",
      render: () => <LoadingState description="Fetching the latest records." title="Loading records" />,
    },
    {
      id: "busy-compact",
      label: "Busy, compact",
      description: "The same single announcement at compact density, for a panel that already has its own surrounding surface.",
      render: () => (
        <LoadingState align="start" density="compact" description="Fetching the latest records." title="Loading records" />
      ),
    },
    {
      id: "busy-with-escape",
      label: "Busy, with an escape",
      description:
        "The region stays busy while the actions slot offers the product's own way out; the preset itself owns no fetch, timer, or cancellation.",
      render: () => (
        <LoadingState
          actions={
            <Button type="button" size="sm" variant="secondary" onClick={noop}>
              Cancel
            </Button>
          }
          description="This import can take a few minutes."
          skeleton={
            <>
              <Skeleton variant="rectangular" />
              <Skeleton variant="text" />
              <Skeleton variant="text" />
            </>
          }
          title="Importing records"
        />
      ),
    },
  ],
};
