import type { ReactNode } from "react";
import { KeyRound, Mail, ShieldCheck, UserRound } from "lucide-react";
import type { StatePreview } from "../../types";
import { AccountMenu } from "../../../components/auth/AccountMenu";
import { AccountProfilePanel } from "../../../components/auth/AccountProfilePanel";
import { AccountSessionsPanel } from "../../../components/auth/AccountSessionsPanel";
import {
  AuthAccessPanel,
  AuthFieldRow,
  AuthInputField,
  AuthStrengthMeter,
} from "../../../components/auth/AuthAccessPanel";
import { AuthStatusPanel } from "../../../components/auth/AuthStatusPanel";
import { PasswordRevealButton } from "../../../components/auth/PasswordRevealButton";
import { SessionRefreshDialog } from "../../../components/auth/SessionRefreshDialog";
import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import { Input } from "../../../components/primitives/Field";
import {
  accountProfileBadges,
  accountProfileLinks,
  accountProfileStats,
  accountSessions,
  elituaAuthProviders,
  scoreAuthProviders,
} from "../../../demos/data";

const noop = () => undefined;

// Placeholder identity only. Auth previews never carry a real-looking address,
// token, or secret; `.invalid` is reserved by RFC 2606 and can never resolve.
const placeholderEmail = "operator@example.invalid";
const maskedSecret = "••••••••••••";

/**
 * The account menu panel and the contained dialog placement are both absolutely
 * positioned, so a state preview supplies the bounded, positioned stage the
 * product page would otherwise be. Geometry only.
 */
function Stage({ children, minHeight }: { children: ReactNode; minHeight: number }) {
  return <div style={{ position: "relative", minHeight, overflow: "hidden" }}>{children}</div>;
}

const menuIdentity = {
  name: "Operator account",
  secondary: placeholderEmail,
  initials: "OA",
  role: "Reviewer",
  roleTone: "success" as const,
};

const menuSections = [
  {
    id: "account",
    label: "Account",
    items: [
      {
        id: "profile",
        label: "My profile",
        description: "Identity and account details",
        href: "#/c/account-profile-panel",
        icon: <UserRound size={16} />,
        current: true,
      },
      {
        id: "sessions",
        label: "Sessions",
        description: "Review active devices",
        href: "#/c/account-sessions-panel",
        icon: <KeyRound size={16} />,
      },
    ],
  },
];

const guestActions = [
  { id: "login", label: "Log in", href: "#/c/auth-access-panel", icon: <KeyRound size={16} /> },
  { id: "register", label: "Create account", href: "#/c/auth-access-panel", icon: <UserRound size={16} /> },
];

const sessionRows = accountSessions.map((session) => ({
  ...session,
  action: session.current ? (
    <Badge tone="success">Protected</Badge>
  ) : (
    <Button size="sm" type="button" variant="ghost" onClick={noop}>
      Revoke
    </Button>
  ),
}));

export const authStates: Record<string, StatePreview[]> = {
  "account-menu": [
    {
      id: "closed",
      label: "Closed",
      description:
        "The resting header state: only the identity trigger renders, with aria-expanded false and no panel in the tree at all.",
      render: () => (
        <Stage minHeight={80}>
          <AccountMenu identity={menuIdentity} open={false} sections={menuSections} onOpenChange={noop} />
        </Stage>
      ),
    },
    {
      id: "signed-in",
      label: "Signed in",
      description:
        "With an identity the panel leads with the profile summary and role badge, then the role-filtered sections the consuming app supplied.",
      render: () => (
        <Stage minHeight={340}>
          <AccountMenu identity={menuIdentity} open sections={menuSections} onOpenChange={noop} />
        </Stage>
      ),
    },
    {
      id: "guest",
      label: "Guest",
      description:
        "Omitting identity switches the same panel to the guest prompt and the sign-in calls to action; sections are ignored in this state.",
      render: () => (
        <Stage minHeight={260}>
          <AccountMenu
            guestActions={guestActions}
            guestDescription="Sign in to save routes, preferences, and active sessions."
            guestTitle="Account"
            open
            onOpenChange={noop}
          />
        </Stage>
      ),
    },
    {
      id: "restricted-item",
      label: "Restricted item",
      description:
        "A disabled item keeps its place so the capability stays discoverable, but it drops its href and reports aria-disabled instead of navigating.",
      render: () => (
        <Stage minHeight={340}>
          <AccountMenu
            identity={menuIdentity}
            open
            sections={[
              {
                id: "workspace",
                label: "Workspace",
                items: [
                  {
                    id: "settings",
                    label: "Account settings",
                    description: "Preferences and notifications",
                    href: "#/c/account-profile-panel",
                    icon: <ShieldCheck size={16} />,
                  },
                  {
                    id: "billing",
                    label: "Billing",
                    description: "Requires the workspace owner grant",
                    disabled: true,
                    href: "#/c/account-profile-panel",
                    icon: <KeyRound size={16} />,
                  },
                  {
                    id: "sign-out",
                    label: "Sign out",
                    icon: <UserRound size={16} />,
                    tone: "danger" as const,
                  },
                ],
              },
            ]}
            onOpenChange={noop}
          />
        </Stage>
      ),
    },
  ],
  "account-profile-panel": [
    {
      id: "verified",
      label: "Verified",
      description:
        "The settled account: identity chrome, badges, and stats render with no outstanding notice, and the form sections hold the product's own controls.",
      render: () => (
        <AccountProfilePanel
          avatar="OA"
          avatarLabel="Operator account"
          badges={accountProfileBadges}
          eyebrow="authenticated account"
          secondaryLinks={accountProfileLinks}
          sections={[
            {
              id: "identity",
              title: "Account identity",
              description: "The panel owns layout and labels; the controls stay product-owned.",
              fields: [
                {
                  id: "display-name",
                  label: "Display name",
                  icon: <UserRound size={15} />,
                  control: <Input defaultValue="Operator account" />,
                },
                {
                  id: "email",
                  label: "Email",
                  icon: <Mail size={15} />,
                  control: <Input defaultValue={placeholderEmail} type="email" />,
                },
              ],
            },
          ]}
          stats={accountProfileStats}
          subtitle="Identity, verification, and preference sections stay presentational."
          title="Operator account"
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "action-required",
      label: "Action required",
      description:
        "A notice row carries an unresolved account condition and the product's own remedy control; delivery, expiry, and retry limits stay in the consuming app.",
      render: () => (
        <AccountProfilePanel
          avatar="OA"
          avatarLabel="Operator account"
          badges={[{ id: "unverified", label: "email unverified", tone: "warning" }]}
          eyebrow="authenticated account"
          notices={[
            {
              id: "verification",
              tone: "warning",
              icon: <Mail size={18} />,
              title: "Email verification required for marketplace actions",
              description: "Verification delivery, expiration, and retry limits stay in the consuming app.",
              action: (
                <Button size="sm" type="button" variant="secondary" onClick={noop}>
                  Resend
                </Button>
              ),
            },
          ]}
          stats={accountProfileStats.slice(0, 2)}
          subtitle="The panel renders the condition; it never decides or clears it."
          title="Operator account"
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      id: "identity-only",
      label: "Identity only",
      description:
        "With no stats, notices, sections, or links the panel degrades to identity chrome alone, so a thin profile route still renders a complete surface.",
      render: () => (
        <AccountProfilePanel
          avatarLabel="Operator account"
          eyebrow="authenticated account"
          subtitle="No optional slot is supplied, and none is faked."
          title="Operator account"
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],
  "account-sessions-panel": [
    {
      id: "active",
      label: "Active",
      description:
        "The loaded list: the current session is badged and its revoke path is replaced by the product's protected marker, while other devices keep their action slot.",
      render: () => (
        <AccountSessionsPanel
          eyebrow="account security"
          sessions={sessionRows}
          status="3 active"
          statusTone="info"
          subtitle="Device summaries and current-session state render here; revocation APIs stay local."
          title="Active sessions"
        />
      ),
    },
    {
      id: "loading",
      label: "Loading",
      description:
        "The section is marked aria-busy and the list is replaced by loadingLabel, so no stale device row is shown while the fetch is in flight.",
      render: () => (
        <AccountSessionsPanel
          eyebrow="account security"
          loading
          subtitle="The consuming app owns the fetch; the panel only reflects it."
          title="Active sessions"
        />
      ),
    },
    {
      id: "empty",
      label: "Empty",
      description: "A resolved, empty result states why the list is blank instead of leaving an unexplained gap.",
      render: () => (
        <AccountSessionsPanel
          emptyDescription="Sessions will appear here after sign-in."
          emptyTitle="No active sessions"
          eyebrow="account security"
          sessions={[]}
          status="0 active"
          title="Active sessions"
        />
      ),
    },
    {
      id: "error",
      label: "Error",
      description:
        "An error renders as a role=alert block above the list rather than replacing it, so a partially loaded set of devices stays readable.",
      render: () => (
        <AccountSessionsPanel
          error="One tablet session has not refreshed recently; stale-session policy stays product-owned."
          eyebrow="account security"
          sessions={sessionRows}
          status="3 active"
          statusTone="warning"
          title="Active sessions"
        />
      ),
    },
  ],
  "auth-access-panel": [
    {
      id: "providers-only",
      label: "Providers only",
      description:
        "Provider actions with no credential body: the divider is suppressed because it only renders when a provider area and children both exist.",
      render: () => (
        <AuthAccessPanel
          eyebrow="eLitua traveler"
          footer={<span>Provider callbacks, redirects, and token persistence stay in the app.</span>}
          providers={elituaAuthProviders}
          subtitle="Choose a provider to continue."
          title="Sign in"
        />
      ),
    },
    {
      id: "credentials",
      label: "Providers and credentials",
      description:
        "With both a provider area and body content the labelled divider appears between them; the panel owns layout while the form controls come from the product.",
      render: () => (
        <AuthAccessPanel
          dividerLabel="or register with email"
          eyebrow="eLitua traveler"
          providers={elituaAuthProviders}
          subtitle="Fields, validation, and submission are supplied by the consuming app."
          title="Create account"
        >
          <AuthFieldRow>
            <AuthInputField
              icon={<UserRound size={18} />}
              id="state-auth-name"
              label="Display name"
              placeholder="Display name"
              readOnly
              value="Operator account"
            />
            <AuthInputField
              icon={<Mail size={18} />}
              id="state-auth-email"
              label="Email"
              readOnly
              type="email"
              value={placeholderEmail}
            />
          </AuthFieldRow>
          <AuthInputField
            action={<PasswordRevealButton visible={false} onVisibleChange={noop} />}
            after={
              <AuthStrengthMeter
                hint="Meets length and mixed character guidance."
                label="Strong password"
                score={3}
                tone="success"
              />
            }
            icon={<KeyRound size={18} />}
            id="state-auth-password"
            label="Password"
            readOnly
            type="password"
            value={maskedSecret}
          />
        </AuthAccessPanel>
      ),
    },
    {
      id: "rejected",
      label: "Rejected",
      description:
        "A danger-toned message renders the consuming app's verbatim rejection above the form; the panel performs no auth exchange and no validation of its own.",
      render: () => (
        <AuthAccessPanel
          eyebrow="Score operator"
          message={{ tone: "danger", children: "That credential was not accepted. Try again or use a provider." }}
          subtitle="Refusal copy and retry policy stay product-owned."
          title="Sign in to Score"
          variant="operator"
        >
          <AuthInputField
            error="Enter the token issued for this workspace."
            icon={<KeyRound size={18} />}
            id="state-auth-token"
            label="Development token"
            readOnly
            type="password"
            value={maskedSecret}
          />
        </AuthAccessPanel>
      ),
    },
    {
      id: "recovery-sent",
      label: "Recovery sent",
      description:
        "The recovery outcome reuses the same card with no provider or credential content at all — just a status message and the caller's action row.",
      render: () => (
        <AuthAccessPanel
          actions={
            <>
              <Button type="button" onClick={noop}>
                Try again
              </Button>
              <Button type="button" variant="secondary" onClick={noop}>
                Back to login
              </Button>
            </>
          }
          footer={<span>Resend throttling and route links stay in the consuming app.</span>}
          message={{ tone: "success", children: "A reset link was sent if that address has an account." }}
          subtitle="Check your inbox to continue."
          title="Check your email"
        />
      ),
    },
  ],
  "auth-status-panel": [
    {
      id: "loading",
      label: "Loading",
      description:
        "A boot or callback wait: status semantics with the animated tone icon, which reduced-motion preferences suppress. No credential input is ever rendered here.",
      render: () => (
        <AuthStatusPanel
          eyebrow="OAuth callback"
          subtitle="Provider tokens are being exchanged by the product."
          title="Completing login"
          tone="loading"
        />
      ),
    },
    {
      id: "success",
      label: "Success",
      description: "A settled positive outcome, with the redirect and its timing left to the consuming app's action slot.",
      render: () => (
        <AuthStatusPanel
          actions={
            <Button type="button" onClick={noop}>
              Go to home
            </Button>
          }
          eyebrow="Email verification"
          subtitle="Account activation and redirect timing stay product-owned."
          title="Email verified"
          tone="success"
        />
      ),
    },
    {
      id: "no-access",
      label: "No access",
      description:
        "Authenticated but unauthorized: an info tone, because a missing grant is a state to resolve rather than a failure, and the detail body names what is required.",
      render: () => (
        <AuthStatusPanel
          actions={
            <Button type="button" variant="secondary" onClick={noop}>
              Refresh session
            </Button>
          }
          eyebrow="Score operator"
          subtitle="The actor is authenticated, but project membership is still required."
          title="No project access"
          tone="info"
          variant="operator"
        >
          <dl>
            <div>
              <dt>Actor</dt>
              <dd>{placeholderEmail}</dd>
            </div>
            <div>
              <dt>Required grant</dt>
              <dd>Project access</dd>
            </div>
          </dl>
        </AuthStatusPanel>
      ),
    },
    {
      id: "error",
      label: "Error",
      description: "Only the danger tone escalates to role=alert; recovery actions are still supplied by the product.",
      render: () => (
        <AuthStatusPanel
          actions={
            <Button type="button" onClick={noop}>
              Sign in again
            </Button>
          }
          subtitle="Retry and recovery routes are supplied by the product."
          title="Session expired"
          tone="danger"
        />
      ),
    },
  ],
  "password-reveal-button": [
    {
      id: "hidden",
      label: "Hidden",
      description:
        "The resting state: aria-pressed is false and both the accessible name and the tooltip read “Password hidden — show password”, stating the current state and the action the click performs.",
      render: () => (
        <AuthInputField
          action={<PasswordRevealButton visible={false} onVisibleChange={noop} />}
          hint="The button controls visibility only; the input type stays with the form."
          icon={<KeyRound size={18} />}
          id="state-reveal-hidden"
          label="Password"
          readOnly
          type="password"
          value={maskedSecret}
        />
      ),
    },
    {
      id: "visible",
      label: "Visible",
      description:
        "aria-pressed flips to true, the glyph becomes eye-off, and the label becomes “Password shown — hide password”; the form, not the button, changed the input type.",
      render: () => (
        <AuthInputField
          action={<PasswordRevealButton visible onVisibleChange={noop} />}
          hint="The consuming form owns the value and the input type."
          icon={<KeyRound size={18} />}
          id="state-reveal-visible"
          label="Password"
          readOnly
          type="text"
          value={maskedSecret}
        />
      ),
    },
    {
      id: "disabled",
      label: "Disabled",
      description:
        "Non-interactive: the click handler short-circuits before onVisibleChange, so a locked field cannot be revealed while still showing its current pressed state.",
      render: () => (
        <AuthInputField
          action={<PasswordRevealButton disabled visible={false} onVisibleChange={noop} />}
          hint="Revealing is gated by the product while the field is locked."
          icon={<KeyRound size={18} />}
          id="state-reveal-disabled"
          label="Password"
          readOnly
          type="password"
          value={maskedSecret}
        />
      ),
    },
  ],
  "session-refresh-dialog": [
    {
      id: "open",
      label: "Open",
      description:
        "The interrupt state: the page behind stays mounted, and because onClose is supplied the close control, Escape, and backdrop dismissal are all live.",
      render: () => (
        <Stage minHeight={460}>
          <SessionRefreshDialog
            dividerLabel="Development access"
            eyebrow="Score operator"
            message={{ tone: "info", children: "The current page stays open while credentials are collected." }}
            open
            placement="contained"
            providers={scoreAuthProviders}
            subtitle="Refresh your session without losing current page context."
            title="Sign in again"
            onClose={noop}
          >
            <AuthInputField
              autoComplete="off"
              icon={<KeyRound size={18} />}
              id="state-session-refresh-token"
              label="Development token"
              readOnly
              type="password"
              value={maskedSecret}
            />
          </SessionRefreshDialog>
        </Stage>
      ),
    },
    {
      id: "close-locked",
      label: "Close locked",
      description:
        "closeDisabled keeps the close control visible but inert and turns off Escape and backdrop dismissal, so an in-flight exchange cannot be interrupted.",
      render: () => (
        <Stage minHeight={460}>
          <SessionRefreshDialog
            closeDisabled
            eyebrow="Score operator"
            message={{ tone: "warning", children: "Completing the exchange. Dismissal is unavailable until it settles." }}
            open
            placement="contained"
            providers={scoreAuthProviders}
            subtitle="The dialog stays put while the product finishes the refresh."
            title="Signing you in"
            onClose={noop}
          />
        </Stage>
      ),
    },
    {
      id: "no-dismiss",
      label: "No dismiss path",
      description:
        "Omitting onClose renders no close control at all and leaves every dismissal route off — a hard reauth gate the product must resolve.",
      render: () => (
        <Stage minHeight={460}>
          <SessionRefreshDialog
            eyebrow="Score operator"
            message={{ tone: "danger", children: "The session expired. Re-authentication is required to continue." }}
            open
            placement="contained"
            providerSlot={
              <button className="ui-auth-provider ui-auth-provider--featured" type="button">
                <ShieldCheck size={18} />
                <span>Identity provider slot</span>
              </button>
            }
            subtitle="An SDK-rendered provider button is passed through as an inert node."
            title="Session expired"
          />
        </Stage>
      ),
    },
  ],
};
