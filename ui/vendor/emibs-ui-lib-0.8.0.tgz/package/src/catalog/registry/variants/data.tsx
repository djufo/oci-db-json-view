import { BedDouble, FileText, Flag, LayoutDashboard, MapPin, Search } from "lucide-react";
import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import { EmptyState } from "../../../components/primitives/EmptyState";
import { Field, Input, Select, Textarea } from "../../../components/primitives/Field";
import { ActivityDashboard } from "../../../components/data/ActivityDashboard";
import { ActorAccessMatrix } from "../../../components/data/ActorAccessMatrix";
import { AdminHomePanel } from "../../../components/data/AdminHomePanel";
import { AdminRecordEditorPanel } from "../../../components/data/AdminRecordEditorPanel";
import { AgentManagementPanel } from "../../../components/data/AgentManagementPanel";
import { AgentProfilePanel } from "../../../components/data/AgentProfilePanel";
import { AuditTimeline } from "../../../components/data/AuditTimeline";
import { ChecklistEditorPanel } from "../../../components/data/ChecklistEditorPanel";
import { CommandBar } from "../../../components/data/CommandBar";
import { CommandConsole } from "../../../components/data/CommandConsole";
import { CompareTrayPanel } from "../../../components/data/CompareTrayPanel";
import { ComponentCatalogPanel } from "../../../components/data/ComponentCatalogPanel";
import { ComponentPlaygroundPanel } from "../../../components/data/ComponentPlaygroundPanel";
import { ComponentReviewPanel } from "../../../components/data/ComponentReviewPanel";
import { DesignIdeaBoardPanel } from "../../../components/data/DesignIdeaBoardPanel";
import { DiscoveryCloudPanel } from "../../../components/data/DiscoveryCloudPanel";
import { EditableFormPanel } from "../../../components/data/EditableFormPanel";
import { EntityCardGridPanel } from "../../../components/data/EntityCardGridPanel";
import { EntityFilterPanel } from "../../../components/data/EntityFilterPanel";
import { FacetFilterPanel } from "../../../components/data/FacetFilterPanel";
import { FileActionListPanel } from "../../../components/data/FileActionListPanel";
import { FilePreviewPanel } from "../../../components/data/FilePreviewPanel";
import { FilterDrawerPanel } from "../../../components/data/FilterDrawerPanel";
import { IdeaBacklogPanel } from "../../../components/data/IdeaBacklogPanel";
import { IntegrationSetupPanel } from "../../../components/data/IntegrationSetupPanel";
import { KanbanBoard } from "../../../components/data/KanbanBoard";
import { MapControlPanel } from "../../../components/data/MapControlPanel";
import { MapInfoCard } from "../../../components/data/MapInfoCard";
import { MapMarkerPin } from "../../../components/data/MapMarkerPin";
import { MarkdownDocumentPanel } from "../../../components/data/MarkdownDocumentPanel";
import { MediaAssetPanel } from "../../../components/data/MediaAssetPanel";
import { MetricGrid } from "../../../components/data/MetricGrid";
import { ModeControlPanel } from "../../../components/data/ModeControlPanel";
import { OperationalDiagnosticPanel } from "../../../components/data/OperationalDiagnosticPanel";
import { Pager } from "../../../components/data/Pager";
import { PaymentAccountPanel } from "../../../components/data/PaymentAccountPanel";
import { PreviewMatrixPanel } from "../../../components/data/PreviewMatrixPanel";
import { ProcessRunHistoryPanel } from "../../../components/data/ProcessRunHistoryPanel";
import { ProjectProfilePanel } from "../../../components/data/ProjectProfilePanel";
import { ProjectSettingsPanel } from "../../../components/data/ProjectSettingsPanel";
import { RecordDetailPanel } from "../../../components/data/RecordDetailPanel";
import { RelationshipPickerPanel } from "../../../components/data/RelationshipPickerPanel";
import { ScheduleEditorDialog } from "../../../components/data/ScheduleEditorDialog";
import { SchedulerControlPanel } from "../../../components/data/SchedulerControlPanel";
import { SubscriptionCapacityPanel } from "../../../components/data/SubscriptionCapacityPanel";
import { ThemeAuditPanel } from "../../../components/data/ThemeAuditPanel";
import { ThemeExportPanel } from "../../../components/data/ThemeExportPanel";
import { ThemeLabPanel } from "../../../components/data/ThemeLabPanel";
import { ThemePreviewCanvas } from "../../../components/data/ThemePreviewCanvas";
import { WorkBoardToolbar } from "../../../components/data/WorkBoardToolbar";
import { WorkItemCard } from "../../../components/data/WorkItemCard";
import { WorkItemPlanningPanel } from "../../../components/data/WorkItemPlanningPanel";
import { WorkItemRelationEditorPanel } from "../../../components/data/WorkItemRelationEditorPanel";
import { WorkItemTracePanel } from "../../../components/data/WorkItemTracePanel";
import { WorkflowCommandBar } from "../../../components/data/WorkflowCommandBar";
import { WorkflowMapPanel } from "../../../components/data/WorkflowMapPanel";
import { AutoFormDemo, AutoFormMultiSectionDemo, AutoFormValidationDemo, FormPanelDemo } from "../../formsDemos";
import { FormBuilderPage, PersistenceCatalogDemo } from "../../../forms";
import {
  activityDashboardItems,
  activityDashboardMetrics,
  activityDashboardQueues,
  actorAccessRows,
  adminHomeActions,
  adminHomeMetrics,
  adminHomeNotices,
  adminHomeSections,
  adminRecordEditorMeta,
  adminRecordEditorNotices,
  agentManagementAgents,
  agentManagementMetrics,
  agentManagementRunners,
  agentProfileFields,
  agentProfileGrants,
  agentProfileMetrics,
  agentProfileProviderOptions,
  agentProfileRoleOptions,
  commandConsoleMessages,
  commandConsoleSessions,
  designIdeaBoardItems,
  designIdeaBoardLanes,
  entityCardGridItems,
  entityFilterRegionOptions,
  entityFilterStats,
  entityFilterStatusOptions,
  entityFilterTypeOptions,
  entityFilterVerificationOptions,
  filePreviewMeta,
  ideaBacklogItems,
  integrationSetupMetrics,
  kanbanColumns,
  mapInfoCardBadges,
  mapInfoCardRows,
  markdownDocumentMeta,
  mediaAssetItems,
  mediaAssetStats,
  metricGridCompactItems,
  metricGridItems,
  operationalDiagnosticDetails,
  operationalDiagnosticMetrics,
  paymentAccountStats,
  paymentHistoryRows,
  paymentMethods,
  payoutRows,
  processRunHistoryItems,
  projectSettingsStats,
  relationshipPickerItems,
  schedulerControlItems,
  scoreTaskDocumentMarkdown,
  subscriptionCapacityMetrics,
  subscriptionCapacityRows,
  workBoardEpicOptions,
  workBoardProjectOptions,
  workBoardToolbarBadges,
  workItemActorOptions,
  workItemCards,
  workItemComplexityOptions,
  workItemEpicOptions,
  workItemProjectOptions,
  workItemRoleOptions,
  workItemTraceNotes,
  workItemTraceRelationGroups,
  workItemTypeOptions,
  workflowCommandBarCommands,
  workflowReleaseCommands,
} from "../../../demos/data";
import {
  AccessibilityAuditDemo,
  AuditTimelineDemo,
  BookingWidgetPanelDemo,
  ComponentCatalogDemo,
  ComponentPlaygroundDemo,
  DataTableDemo,
  DesignIdeaBoardPanelDemo,
  EntityCardDemo,
  FileActionListDemo,
  FilePreviewDialogDemo,
  GeocodingControlPanelDemo,
  NewsletterSignupPanelDemo,
  PaymentCheckoutPanelDemo,
  ProjectDirectoryDemo,
  ProjectProfileDemo,
  RegistryKanbanTaskCard,
  ResourceIndexDemo,
  ResourceTransferDemo,
  SubscriptionCapacityDemo,
  ThemePreviewFixture,
  WorkflowMapDemo,
  compareTrayItems,
  componentReviewTabs,
  componentReviewVariants,
  previewMatrixColumns,
  previewMatrixRows,
  projectProfileFields,
  scoreKanbanColumns,
  themeAuditTokenGroups,
  themeExportFormats,
  themeLabProposal,
  themePreviewCompareSurfaces,
  workflowMapInsights,
  workflowMapStages,
} from "../demoComponents";
import type { Variant } from "../types";

/** Local fixtures for entries whose shared demo fixtures do not exist yet. */
const registryChecklistItems = [
  { id: "build", text: "npm run build passes on the extraction branch", checked: true },
  { id: "spec", text: "Component SPEC.md records the contract and the non-goals", checked: true },
  { id: "catalog", text: "Catalog entry carries demo, variants, usage and prop docs", checked: false },
  { id: "deploy", text: "Deployed catalog verified at ui-lib.ayc.io", checked: false },
];

const registryCommandNavigation = {
  id: "navigation",
  title: "Navigation",
  items: [
    { id: "board", label: "Board", meta: "g b", href: "#/c/command-bar" },
    { id: "fleet", label: "Fleet", meta: "g f", href: "#/c/command-bar" },
    { id: "audit", label: "Audit log", meta: "g a", href: "#/c/command-bar" },
  ],
};

const registryCommandVerbs = [
  { id: "park", label: "park", description: "Pause an issue and release its lease." },
  { id: "requeue", label: "requeue", description: "Return an issue to the ready queue." },
];

const registryAgentRunnerOptions = agentManagementRunners.map((runner) => ({
  value: runner.id,
  label: runner.displayName ?? runner.id,
}));

const registryWorkItemDraft = {
  title: "Adopt WorkItemPlanningPanel in the Score task editor",
  type: "story",
  projectKey: "score",
  points: "3",
  priority: "900",
  deliveryRole: "engineer",
  complexity: "medium",
  assignee: "agent-codex-maestro",
  parentEpic: "task-206 - UI Framework",
  agentAllowed: true,
  description: "Replace the bespoke planning form with the shared panel while keeping workflow rules in Score.",
};

const registryWorkItemTriage = {
  points: "3",
  suggestedActor: "agent-codex-worker",
  note: "Estimate confirmed against the extraction checklist.",
  makeReady: true,
};

export const dataVariants: Record<string, Variant[]> = {
  "accessibility-audit-panel": [
    { label: "pass", render: () => <AccessibilityAuditDemo state="pass" /> },
    { label: "running", render: () => <AccessibilityAuditDemo state="running" /> },
    { label: "idle", render: () => <AccessibilityAuditDemo state="idle" /> },
    { label: "unavailable", render: () => <AccessibilityAuditDemo state="unavailable" /> },
  ],
  "activity-dashboard": [
    {
      label: "queue and metric rails",
      render: () => (
        <ActivityDashboard
          eyebrow="score"
          title="Worker activity"
          subtitle="Queue depth, scheduler counters and the delivery feed in one operator surface."
          status="live"
          statusTone="success"
          queues={activityDashboardQueues}
          metrics={activityDashboardMetrics}
          items={activityDashboardItems.slice(0, 3)}
        />
      ),
    },
    {
      label: "feed only",
      render: () => (
        <ActivityDashboard
          eyebrow="score"
          title="Delivery feed"
          subtitle="Both rails are optional; products that already render counters elsewhere pass items only."
          items={activityDashboardItems.slice(0, 4)}
        />
      ),
    },
    {
      label: "localized section labels",
      render: () => (
        <ActivityDashboard
          eyebrow="score"
          title="Darbo eiga"
          queueLabel="Eilės"
          metricLabel="Rodikliai"
          feedTitle="Paskutiniai įvykiai"
          queues={activityDashboardQueues.slice(0, 3)}
          metrics={activityDashboardMetrics.slice(0, 2)}
          items={activityDashboardItems.slice(0, 2)}
        />
      ),
    },
  ],
  "actor-access-matrix": [
    {
      label: "editable roles and grants",
      render: () => (
        <ActorAccessMatrix
          eyebrow="score"
          title="Actor access"
          subtitle="Role selects and grant checkboxes stay interactive while change handlers are supplied."
          contextLabel="Project"
          contextValue="score"
          actors={actorAccessRows}
          onGrantChange={() => undefined}
          onRoleChange={() => undefined}
        />
      ),
    },
    {
      label: "read-only audit view",
      render: () => (
        <ActorAccessMatrix
          eyebrow="score"
          title="Access audit"
          subtitle="Without change handlers the same rows render as a non-interactive access record."
          status="read-only"
          statusTone="info"
          actors={actorAccessRows}
        />
      ),
    },
    {
      label: "localized column labels",
      render: () => (
        <ActorAccessMatrix
          title="Prieigos matrica"
          actorColumnLabel="Aktorius"
          interfaceColumnLabel="Sąsaja"
          statusColumnLabel="Būsena"
          roleColumnLabel="Rolė"
          grantsColumnLabel="Leidimai"
          actionsColumnLabel="Veiksmai"
          actors={actorAccessRows.slice(0, 2)}
          onRoleChange={() => undefined}
        />
      ),
    },
  ],
  "admin-home-panel": [
    {
      label: "linked action tiles",
      render: () => (
        <AdminHomePanel
          eyebrow="admin"
          title="Administration"
          subtitle="Action cards render as links whenever the consuming route registry supplies an href."
          metrics={adminHomeMetrics}
          notices={adminHomeNotices}
          actionItems={adminHomeActions}
        />
      ),
    },
    {
      label: "controlled action tiles",
      render: () => (
        <AdminHomePanel
          eyebrow="admin"
          title="Administration"
          subtitle="Dropping href and supplying onActionSelect turns the same tiles into controlled buttons."
          actionLabel="Open"
          actionItems={adminHomeActions.map((item) => ({ ...item, href: undefined }))}
          onActionSelect={() => undefined}
        />
      ),
    },
    {
      label: "with sections and footer",
      render: () => (
        <AdminHomePanel
          eyebrow="admin"
          title="Administration"
          status="4 sessions"
          statusTone="info"
          actionItems={adminHomeActions.slice(0, 2)}
          sections={adminHomeSections}
          footer="Route registries, RBAC and localization stay in the consuming admin app."
        />
      ),
    },
  ],
  "admin-record-editor-panel": [
    {
      label: "with meta and notices",
      render: () => (
        <AdminRecordEditorPanel
          eyebrow="admin"
          title="Edit user #42"
          subtitle="Metadata badges and notice rows are optional header regions."
          backLabel="Back to users"
          backHref="#/c/admin-record-editor-panel"
          status="active"
          statusTone="success"
          meta={adminRecordEditorMeta}
          notices={adminRecordEditorNotices}
        >
          <Field label="Email">
            <Input type="email" value="ruta@example.lt" onChange={() => undefined} />
          </Field>
        </AdminRecordEditorPanel>
      ),
    },
    {
      label: "with footer actions",
      render: () => (
        <AdminRecordEditorPanel
          eyebrow="admin"
          title="Edit project"
          backLabel="Back to projects"
          onBack={() => undefined}
          actions={<Button size="sm" variant="ghost" type="button">Delete</Button>}
          footer={
            <>
              <Button size="sm" variant="ghost" type="button">Cancel</Button>
              <Button size="sm" type="submit">Save changes</Button>
            </>
          }
          onSubmit={(event) => event.preventDefault()}
        >
          <Field label="Project key">
            <Input value="score" onChange={() => undefined} />
          </Field>
        </AdminRecordEditorPanel>
      ),
    },
    {
      label: "plain shell",
      render: () => (
        <AdminRecordEditorPanel title="New record" backLabel="Back">
          <Field label="Display name">
            <Input value="" placeholder="Untitled record" onChange={() => undefined} />
          </Field>
        </AdminRecordEditorPanel>
      ),
    },
  ],
  "agent-management-panel": [
    {
      label: "read-only roster",
      render: () => (
        <AgentManagementPanel
          eyebrow="score"
          title="Agent roster"
          subtitle="Without change callbacks the runner select and enablement checkboxes render read-only."
          agents={agentManagementAgents}
        />
      ),
    },
    {
      label: "with metrics and runner registry",
      render: () => (
        <AgentManagementPanel
          eyebrow="score"
          title="Agent management"
          subtitle="Metrics, the runner registry and the editable controls are all opt-in regions."
          status="4 agents"
          statusTone="info"
          metrics={agentManagementMetrics}
          agents={agentManagementAgents}
          runners={agentManagementRunners}
          runnerOptions={registryAgentRunnerOptions}
          onAgentEnabledChange={() => undefined}
          onAgentRunnerChange={() => undefined}
          onRunnerEnabledChange={() => undefined}
          onRunnerNameChange={() => undefined}
          onRunnerResponsibilitiesChange={() => undefined}
        />
      ),
    },
  ],
  "agent-profile-panel": [
    {
      label: "editable identity form",
      render: () => (
        <AgentProfilePanel
          eyebrow="score"
          title="Codex Maestro"
          agentId="agent-codex-maestro"
          subtitle="Controlled text, select and checkbox fields report through onFormFieldChange."
          status="active"
          statusTone="success"
          metrics={agentProfileMetrics}
          formTitle="Identity"
          formDescription="Persistence, debouncing and validation stay in the consuming app."
          formFields={[
            { id: "displayName", label: "Display name", value: "Codex Maestro", control: "text" },
            { id: "role", label: "Role", value: "admin", control: "select", options: agentProfileRoleOptions },
            { id: "provider", label: "Provider", value: "codex", control: "select", options: agentProfileProviderOptions },
            { id: "enabled", label: "Enabled", value: true, control: "checkbox", hint: "Disabled agents keep their capacity record." },
          ]}
          onFormFieldChange={() => undefined}
        />
      ),
    },
    {
      label: "read-only field summary",
      render: () => (
        <AgentProfilePanel
          eyebrow="score"
          title="Codex Maestro"
          agentId="agent-codex-maestro"
          subtitle="The same panel without form fields becomes a read-only profile summary."
          metrics={agentProfileMetrics.slice(0, 2)}
          fieldsTitle="Configuration"
          fields={agentProfileFields}
        />
      ),
    },
    {
      label: "with release grants",
      render: () => (
        <AgentProfilePanel
          eyebrow="score"
          title="Codex Maestro"
          agentId="agent-codex-maestro"
          grantsTitle="Release grants"
          grantsDescription="Grant rows are read-only visibility; mutations and RBAC stay product-owned."
          grants={agentProfileGrants}
          fields={agentProfileFields.slice(0, 3)}
        />
      ),
    },
  ],
  "audit-timeline": [
    { label: "compact", render: () => <AuditTimelineDemo density="compact" /> },
    { label: "empty", render: () => <AuditTimeline entries={[]} emptyLabel="No delivery record yet." /> },
  ],
  "auto-form": [
    { label: "profile settings", render: () => <AutoFormDemo /> },
    { label: "with validation (zod)", render: () => <AutoFormValidationDemo /> },
    { label: "multi-section", render: () => <AutoFormMultiSectionDemo /> },
  ],
  "booking-widget-panel": [
    { label: "with widget", render: () => <BookingWidgetPanelDemo /> },
    { label: "consent pending", render: () => <BookingWidgetPanelDemo blocked /> },
  ],
  "checklist-editor-panel": [
    {
      label: "compact density",
      render: () => (
        <ChecklistEditorPanel
          eyebrow="score"
          title="Definition of done"
          subtitle="Compact rows fit inside a task detail sidebar."
          density="compact"
          items={registryChecklistItems}
          onAddItem={() => undefined}
          onItemCheckedChange={() => undefined}
          onItemTextChange={() => undefined}
          onRemoveItem={() => undefined}
        />
      ),
    },
    {
      label: "read-only",
      render: () => (
        <ChecklistEditorPanel
          eyebrow="score"
          title="Definition of done"
          subtitle="Read-only mode keeps the checklist reviewable without edit affordances."
          status="locked"
          statusTone="info"
          readOnly
          items={registryChecklistItems}
        />
      ),
    },
    {
      label: "with footer and add disabled",
      render: () => (
        <ChecklistEditorPanel
          title="Release checklist"
          addLabel="Add step"
          addDisabled
          items={registryChecklistItems.slice(0, 2)}
          footer="The template owns the maximum item count; the panel only renders the disabled add control."
          onItemCheckedChange={() => undefined}
        />
      ),
    },
  ],
  "command-bar": [
    {
      label: "field only",
      render: () => (
        <CommandBar
          navigation={registryCommandNavigation}
          navigate={() => undefined}
          onVerb={() => undefined}
          entityHref={(id) => `#/c/command-bar/${id}`}
          verbs={registryCommandVerbs}
        />
      ),
    },
    {
      label: "with brand and status strip",
      render: () => (
        <CommandBar
          brand={<strong>Score</strong>}
          navigation={registryCommandNavigation}
          navigate={() => undefined}
          onVerb={() => undefined}
          entityHref={(id) => `#/c/command-bar/${id}`}
          statusStrip={<Badge tone="success">fleet healthy</Badge>}
          verbs={registryCommandVerbs}
        />
      ),
    },
    {
      label: "localized trigger copy",
      render: () => (
        <CommandBar
          ariaLabel="Komandų juosta"
          navigation={registryCommandNavigation}
          navigate={() => undefined}
          onVerb={() => undefined}
          entityHref={(id) => `#/c/command-bar/${id}`}
          hint="Ieškoti, pereiti arba vykdyti…"
          placeholder="Įveskite objekto numerį arba komandą (> …)"
        />
      ),
    },
  ],
  "command-console": [
    {
      label: "session rail",
      render: () => (
        <CommandConsole
          title="Maestro console"
          sessions={commandConsoleSessions}
          activeSessionId="framework"
          messages={commandConsoleMessages}
          draft="Extract the next reviewable panel."
          onCloseSession={() => undefined}
          onDraftChange={() => undefined}
          onNewSession={() => undefined}
          onSessionSelect={() => undefined}
          onSubmit={() => undefined}
        />
      ),
    },
    {
      label: "single session",
      render: () => (
        <CommandConsole
          title="Release gate console"
          sessions={commandConsoleSessions.slice(1, 2)}
          activeSessionId="release"
          messages={commandConsoleMessages.slice(0, 2)}
          draft=""
          draftPlaceholder="Ask the release gate a question"
          onDraftChange={() => undefined}
          onSubmit={() => undefined}
        />
      ),
    },
    {
      label: "localized labels",
      render: () => (
        <CommandConsole
          title="Komandų konsolė"
          sessions={commandConsoleSessions}
          activeSessionId="framework"
          messages={commandConsoleMessages}
          draft=""
          sessionLabel="Sesijos"
          transcriptLabel="Pokalbis"
          draftLabel="Užklausa"
          draftPlaceholder="Rašykite komandą"
          sendLabel="Siųsti"
          newSessionLabel="Nauja sesija"
          closeSessionLabel="Uždaryti sesiją"
          onCloseSession={() => undefined}
          onDraftChange={() => undefined}
          onNewSession={() => undefined}
          onSessionSelect={() => undefined}
          onSubmit={() => undefined}
        />
      ),
    },
  ],
  "compare-tray-panel": [
    {
      label: "compact",
      render: () => (
        <CompareTrayPanel
          currentAction={{
            active: false,
            label: "Pin current",
          }}
          density="compact"
          description="Fits near other catalog review controls."
          items={compareTrayItems().slice(0, 1)}
          resultCount="1 pinned"
        />
      ),
    },
    {
      label: "empty",
      render: () => <CompareTrayPanel title="No pinned components" items={[]} emptyLabel="Pin components to compare their first fixture side by side." />,
    },
  ],
  "component-catalog-panel": [
    { label: "compact density", render: () => <ComponentCatalogDemo compact /> },
    {
      label: "empty results",
      render: () => (
        <ComponentCatalogPanel
          badges={[{ id: "empty", label: "empty", tone: "warning" }]}
          description="Empty navigation remains visible while product search state stays outside the shared component."
          items={[]}
          search={{ value: "no-match", resultMeta: "0/4" }}
          sidebar={<EmptyState icon={<Search size={22} />} title="No facets">Filter state remains product-owned.</EmptyState>}
          title="Catalog search"
        >
          <EmptyState icon={<LayoutDashboard size={22} />} title="No component selected">
            Select a catalog entry to render the review content slot.
          </EmptyState>
        </ComponentCatalogPanel>
      ),
    },
  ],
  "component-playground-panel": [
    { label: "compact density", render: () => <ComponentPlaygroundDemo compact /> },
    {
      label: "empty controls",
      render: () => (
        <ComponentPlaygroundPanel
          controls={[]}
          emptyControlsLabel="This component has no configurable props yet."
          snippet={"<EmptyState title=\"Preview pending\" />"}
          stage={<EmptyState icon={<FileText size={22} />} title="Preview pending">Fixture rendering stays catalog-owned.</EmptyState>}
          title="Empty playground"
          values={{}}
        />
      ),
    },
  ],
  "component-review-panel": [
    {
      label: "compact canvas",
      render: () => (
        <ComponentReviewPanel
          activeCanvasSizeId="narrow"
          activeTabId="usage"
          activeVariantId="narrow"
          badges={[{ id: "compact", label: "compact", tone: "info" }]}
          canvasSizes={[
            { id: "narrow", label: "Narrow", maxWidth: 360 },
            { id: "full", label: "Full" },
          ]}
          eyebrow="review"
          meta={[{ id: "source", label: "Source", value: "Score catalog" }]}
          reviewNotes={["Narrow previews keep controls and content stacked."]}
          summary="Compact review state for small catalog panels."
          tabs={componentReviewTabs.slice(0, 1)}
          title="Compact review"
          variants={componentReviewVariants.slice(1, 2)}
        />
      ),
    },
    {
      label: "empty variants",
      render: () => (
        <ComponentReviewPanel
          badges={[{ id: "pending", label: "pending", tone: "warning" }]}
          emptyLabel="Preview migration is not ready yet."
          eyebrow="review"
          summary="The panel still carries metadata when a preview cannot render."
          title="Pending component"
          variants={[]}
        />
      ),
    },
  ],
  "data-table": [
    { label: "loading", render: () => <DataTableDemo state="loading" /> },
    { label: "empty", render: () => <DataTableDemo state="empty" /> },
    { label: "error", render: () => <DataTableDemo state="error" /> },
  ],
  "design-idea-board-panel": [
    {
      label: "Score only",
      render: () => <DesignIdeaBoardPanelDemo target="Score" />,
    },
    {
      label: "eLitua only",
      render: () => <DesignIdeaBoardPanelDemo target="eLitua" />,
    },
    {
      label: "empty lane",
      render: () => (
        <DesignIdeaBoardPanel
          eyebrow="mockup porting"
          title="Design ideas without later queue"
          subtitle="Empty lanes stay visible so review boards do not jump between extraction cycles."
          badges={[
            { id: "state", label: "empty state", tone: "warning" },
            { id: "lanes", label: `${designIdeaBoardLanes.length} lanes`, tone: "info" },
          ]}
          lanes={designIdeaBoardLanes}
          items={designIdeaBoardItems.filter((item) => item.laneId !== "later")}
        />
      ),
    },
  ],
  "discovery-cloud-panel": [
    {
      label: "compact",
      render: () => (
        <DiscoveryCloudPanel
          density="compact"
          title="Compact discovery"
          description="Fits beside filters in a review sidebar."
          groups={[
            {
              id: "compact-patterns",
              label: "Patterns",
              items: [
                { id: "data", label: "Data", href: "#/c/discovery-cloud-panel", count: 34, active: true, tone: "accent" },
                { id: "layout", label: "Layout", href: "#/c/discovery-cloud-panel", count: 21 },
                { id: "theme", label: "Theme", href: "#/c/discovery-cloud-panel", count: 9, size: "sm" },
              ],
            },
          ]}
          resultCount="42 matches"
        />
      ),
    },
    {
      label: "empty",
      render: () => <DiscoveryCloudPanel title="No discovery data" groups={[]} emptyLabel="No cloud groups are available yet." />,
    },
  ],
  "editable-form-panel": [
    {
      label: "comfortable sections",
      render: () => (
        <EditableFormPanel
          eyebrow="admin"
          title="Guide profile"
          subtitle="The default comfortable form shell for full-page admin editors."
          sections={[
            {
              id: "identity",
              title: "Identity",
              description: "Field state, validation and submission stay in the consuming app.",
              fields: [
                {
                  id: "name",
                  label: "Display name",
                  required: true,
                  control: <Input value="Rūta Kazlauskienė" onChange={() => undefined} />,
                },
                {
                  id: "email",
                  label: "Email",
                  control: <Input type="email" value="ruta@example.lt" onChange={() => undefined} />,
                  hint: "Used for booking notifications only.",
                },
              ],
            },
            {
              id: "coverage",
              title: "Coverage",
              fields: [
                {
                  id: "region",
                  label: "Primary region",
                  control: (
                    <Select value="vilnius" onChange={() => undefined}>
                      {entityFilterRegionOptions.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  ),
                },
                {
                  id: "summary",
                  label: "Summary",
                  wide: true,
                  control: <Textarea rows={3} value="Cultural guide covering Vilnius old town and Trakai." onChange={() => undefined} />,
                },
              ],
            },
          ]}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      label: "compact variant",
      render: () => (
        <EditableFormPanel
          eyebrow="admin"
          title="Quick edit"
          subtitle="Compact spacing for drawer and inline record editors."
          variant="compact"
          sections={[
            {
              id: "quick",
              title: "Record",
              fields: [
                { id: "title", label: "Title", control: <Input value="Trakai castle route" onChange={() => undefined} /> },
                {
                  id: "status",
                  label: "Status",
                  control: (
                    <Select value="1" onChange={() => undefined}>
                      {entityFilterStatusOptions.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </Select>
                  ),
                },
              ],
            },
          ]}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      label: "with badges, messages and footer",
      render: () => (
        <EditableFormPanel
          eyebrow="admin"
          title="Accommodation record"
          badges={[
            { id: "source", label: "eLitua", tone: "accent" },
            { id: "draft", label: "draft", tone: "warning" },
          ]}
          messages={[
            { id: "autosave", tone: "info", children: "Autosave, validation and toast delivery remain product-owned." },
          ]}
          actions={<Button size="sm" variant="ghost" type="button">Discard</Button>}
          sections={[
            {
              id: "listing",
              title: "Listing",
              fields: [
                { id: "name", label: "Name", control: <Input value="Aukštaitija Lakehouse Retreat" onChange={() => undefined} /> },
                { id: "capacity", label: "Capacity", control: <Input type="number" value="8" onChange={() => undefined} /> },
              ],
            },
          ]}
          footer={<Button size="sm" type="submit">Save record</Button>}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],
  "entity-card": [
    { label: "fallback media", render: () => <EntityCardDemo media="fallback" /> },
    { label: "linked compact", render: () => <EntityCardDemo density="compact" linked /> },
    { label: "no media", render: () => <EntityCardDemo media="none" /> },
  ],
  "entity-card-grid-panel": [
    {
      label: "compact density",
      render: () => (
        <EntityCardGridPanel
          eyebrow="eLitua"
          title="Admin entity list"
          description="Compact density trades card padding for row count in admin lists."
          density="compact"
          items={entityCardGridItems.slice(0, 4)}
        />
      ),
    },
    {
      label: "with toolbar and pagination",
      render: () => (
        <EntityCardGridPanel
          eyebrow="eLitua"
          title="Browse entities"
          description="Toolbar and pagination are slots; paging maths stays in the consuming app."
          status="42 records"
          statusTone="info"
          toolbar={
            <Field label="Search">
              <Input type="search" value="vilnius" onChange={() => undefined} />
            </Field>
          }
          pagination={
            <Pager
              page={1}
              total={4}
              summary="Showing 1-6 of 42 records"
              compactSummary="1-6 of 42"
              onPageChange={() => undefined}
            />
          }
          items={entityCardGridItems.slice(0, 3)}
        />
      ),
    },
    {
      label: "controlled selection",
      render: () => (
        <EntityCardGridPanel
          eyebrow="eLitua"
          title="Pick an entity"
          description="Selection is controlled: the panel reports the id and never stores it."
          itemActionLabel="Select"
          items={entityCardGridItems.slice(0, 4).map((item) => ({ ...item, href: undefined }))}
          selectedItemId="guide-ruta"
          onItemSelect={() => undefined}
        />
      ),
    },
  ],
  "entity-filter-panel": [
    {
      label: "full control set with stats",
      render: () => (
        <EntityFilterPanel
          title="Entity filters"
          subtitle="Every control is controlled; the panel never derives results itself."
          controls={[
            { id: "search", kind: "text", label: "Search", value: "vilnius", placeholder: "Name or slug", onChange: () => undefined },
            { id: "type", kind: "select", label: "Type", value: "guide", options: entityFilterTypeOptions, onChange: () => undefined },
            { id: "verified", kind: "select", label: "Verification", value: "1", options: entityFilterVerificationOptions, onChange: () => undefined },
            { id: "region", kind: "select", label: "Region", value: "vilnius", options: entityFilterRegionOptions, onChange: () => undefined },
          ]}
          resultCount="42"
          totalCount="87"
          stats={entityFilterStats}
          clearVisible
          clearLabel="Clear filters"
          onClear={() => undefined}
        />
      ),
    },
    {
      label: "search only",
      render: () => (
        <EntityFilterPanel
          title="Quick search"
          controls={[
            { id: "search", kind: "text", label: "Search", value: "", placeholder: "Search entities", onChange: () => undefined },
          ]}
          resultCount="87"
          resultLabel="records"
        />
      ),
    },
    {
      label: "with refresh and footer note",
      render: () => (
        <EntityFilterPanel
          title="Entity filters"
          controls={[
            { id: "status", kind: "select", label: "Status", value: "1", options: entityFilterStatusOptions, onChange: () => undefined },
            { id: "region", kind: "select", label: "Region", value: "", options: entityFilterRegionOptions, onChange: () => undefined },
          ]}
          refreshLabel="Refresh"
          refreshingLabel="Refreshing"
          onRefresh={() => undefined}
          footer="Query synchronization and persistence stay in the consuming route."
        />
      ),
    },
  ],
  "facet-filter-panel": [
    {
      label: "compact",
      render: () => (
        <FacetFilterPanel
          density="compact"
          title="Compact facets"
          description="Useful inside catalog sidebars and dense admin filters."
          resultCount="18 matches"
          activeFilters={[
            { id: "source-score", label: "Source", value: "Score", tone: "accent" },
            { id: "status-demo", label: "Status", value: "Demo migrated", tone: "success" },
          ]}
          groups={[
            {
              id: "source",
              label: "Source app",
              allOption: { id: "all", label: "All", count: 94 },
              options: [
                { id: "score", label: "Score", count: 42, selected: true },
                { id: "elitua", label: "eLitua", count: 36 },
              ],
            },
          ]}
        />
      ),
    },
    {
      label: "empty",
      render: () => <FacetFilterPanel title="No facets" groups={[]} emptyLabel="No filter dimensions are available yet." />,
    },
  ],
  "file-action-list-panel": [
    { label: "comfortable", render: () => <FileActionListDemo /> },
    { label: "compact", render: () => <FileActionListDemo compact /> },
    {
      label: "empty",
      render: () => <FileActionListPanel title="Project files" items={[]} emptyLabel="No project files yet." />,
    },
  ],
  "file-preview-dialog": [
    { label: "markdown view", render: () => <FilePreviewDialogDemo /> },
    { label: "long filename", render: () => <FilePreviewDialogDemo longFilename /> },
    { label: "source fallback", render: () => <FilePreviewDialogDemo fallback /> },
  ],
  "file-preview-panel": [
    {
      label: "markdown",
      render: () => (
        <FilePreviewPanel
          file={{ filename: "acceptance-notes.md", contentType: "text/markdown" }}
          kind="markdown"
          markdown={scoreTaskDocumentMarkdown}
          meta={filePreviewMeta}
        />
      ),
    },
    {
      label: "fallback",
      render: () => (
        <FilePreviewPanel
          file={{ filename: "runtime-output.log", contentType: "text/plain", sizeLabel: "42 KB" }}
          kind="document"
          fallbackLabel="Preview unavailable."
        />
      ),
    },
    {
      label: "loading",
      render: () => (
        <FilePreviewPanel
          file={{ filename: "pending-preview.md", contentType: "text/markdown" }}
          kind="markdown"
          loading
        />
      ),
    },
  ],
  "filter-drawer-panel": [
    {
      label: "inline compact",
      render: () => (
        <FilterDrawerPanel
          mode="inline"
          density="compact"
          title="Explorer filters"
          summary="18 matches"
          badges={[{ id: "region", label: "Vilnius", tone: "info" }]}
        >
          <Field label="Search">
            <Input type="search" value="guide" onChange={() => undefined} />
          </Field>
        </FilterDrawerPanel>
      ),
    },
    {
      label: "closed drawer",
      render: () => (
        <FilterDrawerPanel mode="drawer" open={false} title="Board filters" summary="2 active">
          <Field label="Query">
            <Input type="search" value="type:story" onChange={() => undefined} />
          </Field>
        </FilterDrawerPanel>
      ),
    },
  ],
  "form-builder": [{ label: "designer", render: () => <FormBuilderPage /> }],
  "form-panel": [{ label: "validated", render: () => <FormPanelDemo /> }],
  "form-persistence-demo": [{ label: "draft autosave", render: () => <PersistenceCatalogDemo /> }],
  "geocoding-control-panel": [
    { label: "ready", render: () => <GeocodingControlPanelDemo /> },
    { label: "compact", render: () => <GeocodingControlPanelDemo compact /> },
    { label: "loading", render: () => <GeocodingControlPanelDemo loading /> },
    { label: "error", render: () => <GeocodingControlPanelDemo error="Google Maps returned ZERO_RESULTS for the current search." /> },
  ],
  "idea-backlog-panel": [
    {
      label: "linked rows with project context",
      render: () => (
        <IdeaBacklogPanel
          eyebrow="score"
          title="Idea backlog"
          subtitle="Rows render as links whenever the consuming route supplies an href."
          contextLabel="Project"
          contextValue="score"
          items={ideaBacklogItems.map((item) => ({ ...item, href: "#/c/idea-backlog-panel" }))}
        />
      ),
    },
    {
      label: "controlled selection",
      render: () => (
        <IdeaBacklogPanel
          eyebrow="score"
          title="Idea backlog"
          subtitle="Without href but with onItemSelect the same rows become controlled buttons."
          itemActionLabel="Open idea"
          items={ideaBacklogItems.map((item) => ({ ...item, href: undefined }))}
          onItemSelect={() => undefined}
        />
      ),
    },
    {
      label: "read-only rows",
      render: () => (
        <IdeaBacklogPanel
          title="Archived ideas"
          status="read-only"
          statusTone="info"
          items={ideaBacklogItems.map((item) => ({ ...item, href: undefined }))}
        />
      ),
    },
  ],
  "integration-setup-panel": [
    {
      label: "connected with metrics",
      render: () => (
        <IntegrationSetupPanel
          eyebrow="eLitua"
          title="Bókun integration"
          subtitle="Status, badges and metrics are optional header regions above the credential form."
          badges={[{ id: "provider", label: "Bókun", tone: "accent" }]}
          status={{ label: "Connected", detail: "Credentials accepted 12m ago", tone: "connected" }}
          metrics={integrationSetupMetrics}
          sections={[
            {
              id: "credentials",
              title: "Credentials",
              description: "The shared component never reads or masks the secret value itself.",
              fields: [
                { id: "access", label: "Access key", required: true, control: <Input value="bk_live_1f2c" onChange={() => undefined} /> },
                { id: "secret", label: "Secret key", required: true, control: <Input type="password" value="hidden-value" onChange={() => undefined} /> },
              ],
            },
          ]}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      label: "credentials only",
      render: () => (
        <IntegrationSetupPanel
          eyebrow="eLitua"
          title="Connect a provider"
          subtitle="A first-time setup form drops the status, metric and message regions."
          sections={[
            {
              id: "credentials",
              title: "Credentials",
              fields: [
                { id: "access", label: "Access key", required: true, control: <Input value="" placeholder="bk_live_…" onChange={() => undefined} /> },
                { id: "secret", label: "Secret key", required: true, control: <Input type="password" value="" onChange={() => undefined} /> },
              ],
            },
          ]}
          footer={<Button size="sm" type="submit">Connect</Button>}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      label: "with toggle rows",
      render: () => (
        <IntegrationSetupPanel
          eyebrow="eLitua"
          title="Sync options"
          messages={[
            { id: "scope", tone: "info", children: "Provider SDK calls, disconnect flows and analytics stay product-owned." },
          ]}
          sections={[
            {
              id: "sync",
              title: "Synchronization",
              toggles: [
                {
                  id: "availability",
                  label: "Availability sync",
                  description: "Refresh availability windows every 15 minutes.",
                  checked: true,
                  onChange: () => undefined,
                },
                {
                  id: "pricing",
                  label: "Pricing sync",
                  description: "Mirror provider pricing into the local catalog.",
                  checked: false,
                  onChange: () => undefined,
                },
              ],
            },
          ]}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],
  "kanban-board": [
    {
      label: "default cards",
      render: () => <KanbanBoard columns={kanbanColumns} emptyLabel="No tasks" />,
    },
    {
      label: "wrapped lanes",
      render: () => (
        <KanbanBoard
          columns={scoreKanbanColumns}
          emptyLabel="No tasks in this lane"
          layout="wrap"
          renderTask={(task) => <RegistryKanbanTaskCard task={task} />}
        />
      ),
    },
    {
      label: "single lane",
      render: () => (
        <KanbanBoard
          columns={scoreKanbanColumns.slice(1, 2)}
          emptyLabel="No tasks in this lane"
          layout="single"
          renderTask={(task) => <RegistryKanbanTaskCard task={task} />}
        />
      ),
    },
  ],
  "map-control-panel": [
    {
      label: "compact wrap",
      render: () => (
        <MapControlPanel
          title="Map controls"
          density="compact"
          layout="wrap"
          actions={[
            { id: "reset", label: "Reset view", onSelect: () => undefined },
            { id: "cluster", label: "Cluster", active: true, onSelect: () => undefined },
            { id: "heat", label: "Heatmap", onSelect: () => undefined },
            { id: "draw", label: "Draw area", disabled: true, onSelect: () => undefined },
          ]}
        />
      ),
    },
    {
      label: "stacked layout",
      render: () => (
        <MapControlPanel
          eyebrow="eLitua"
          title="Layers"
          subtitle="A stacked layout suits a narrow rail beside the map."
          layout="stack"
          actions={[
            { id: "guides", label: "Guides", description: "Show guide coverage pins.", active: true, onSelect: () => undefined },
            { id: "stays", label: "Stays", description: "Show accommodation records.", onSelect: () => undefined },
            { id: "routes", label: "Routes", description: "Show curated route lines.", tone: "ghost", onSelect: () => undefined },
          ]}
        />
      ),
    },
    {
      label: "with stats and footer",
      render: () => (
        <MapControlPanel
          title="Viewport"
          status="live"
          statusTone="success"
          actions={[
            { id: "fit", label: "Fit to results", onSelect: () => undefined },
            { id: "locate", label: "Locate me", onSelect: () => undefined },
          ]}
          stats={[
            { id: "visible", label: "Visible", value: "412", tone: "info" },
            { id: "missing", label: "No coords", value: "13", tone: "warning" },
          ]}
          footer="Visibility policy and map engine bindings stay in the consuming page."
        />
      ),
    },
  ],
  "map-info-card": [
    {
      label: "inline placement",
      render: () => (
        <MapInfoCard
          eyebrow="geo record"
          title="Vilnius old town"
          subtitle="Inline placement suits a side panel or a catalog review surface."
          badges={mapInfoCardBadges}
          rows={mapInfoCardRows}
        />
      ),
    },
    {
      label: "overlay placement",
      render: () => (
        <div style={{ position: "relative", minHeight: 260 }}>
          <MapInfoCard
            eyebrow="geo record"
            title="Trakai castle"
            placement="overlay"
            badges={mapInfoCardBadges.slice(0, 1)}
            rows={mapInfoCardRows.slice(0, 3)}
            closeLabel="Close record"
            onClose={() => undefined}
          />
        </div>
      ),
    },
    {
      label: "with actions and footer",
      render: () => (
        <MapInfoCard
          title="Curonian Spit"
          rows={mapInfoCardRows.slice(0, 2)}
          actions={
            <>
              <Button size="sm" variant="ghost" type="button">Open record</Button>
              <Button size="sm" type="button">Add to route</Button>
            </>
          }
          footer="Selection dispatch, clustering and routing stay with the map engine."
        />
      ),
    },
  ],
  "map-marker-pin": [
    { label: "pin", render: () => <MapMarkerPin label="Stay" icon={<BedDouble size={16} />} showLabel /> },
    { label: "selected", render: () => <MapMarkerPin label="Guide" icon={<Flag size={16} />} selected showLabel /> },
    { label: "dot", render: () => <MapMarkerPin kind="dot" label="Place" icon={<MapPin size={13} />} tone="success" showLabel /> },
    { label: "cluster", render: () => <MapMarkerPin kind="cluster" count="24" ariaLabel="Cluster with 24 records" /> },
  ],
  "markdown-document-panel": [
    {
      label: "with meta and badges",
      render: () => (
        <MarkdownDocumentPanel
          eyebrow="score"
          title="Extraction review notes"
          description="Metadata rows and badges frame the rendered document."
          badges={[
            { id: "format", label: "GFM", tone: "info" },
            { id: "source", label: "task document", tone: "accent" },
          ]}
          markdown={scoreTaskDocumentMarkdown}
          meta={markdownDocumentMeta}
        />
      ),
    },
    {
      label: "document only",
      render: () => (
        <MarkdownDocumentPanel
          title="Acceptance notes"
          markdown={scoreTaskDocumentMarkdown}
        />
      ),
    },
    {
      label: "with actions and footer",
      render: () => (
        <MarkdownDocumentPanel
          eyebrow="score"
          title="Extraction review notes"
          markdown={scoreTaskDocumentMarkdown}
          meta={markdownDocumentMeta.slice(0, 2)}
          actions={
            <>
              <Button size="sm" variant="ghost" type="button">Copy</Button>
              <Button size="sm" type="button">Download</Button>
            </>
          }
          footer="Task fetch, permissions and upload behavior remain in the consuming app."
        />
      ),
    },
  ],
  "media-asset-panel": [
    {
      label: "with upload region and stats",
      render: () => (
        <MediaAssetPanel
          eyebrow="score"
          title="Media library"
          subtitle="Stats and the upload prompt are optional regions above the asset grid."
          stats={mediaAssetStats}
          upload={{
            label: "Add an attachment",
            description: "Authenticated upload URLs and progress stay product-owned.",
            acceptLabel: "PNG, JPG or Markdown",
            action: <Button size="sm" type="button">Choose file</Button>,
          }}
          assets={mediaAssetItems}
          onAssetSelect={() => undefined}
        />
      ),
    },
    {
      label: "detail column hidden",
      render: () => (
        <MediaAssetPanel
          eyebrow="score"
          title="Attachments"
          subtitle="showDetail=false gives the grid the full width when the product renders detail elsewhere."
          assets={mediaAssetItems}
          showDetail={false}
          onAssetSelect={() => undefined}
        />
      ),
    },
    {
      label: "documents only",
      render: () => (
        <MediaAssetPanel
          title="Task documents"
          status="4 files"
          statusTone="info"
          selectedAssetLabel="Selected document"
          assets={mediaAssetItems.filter((asset) => asset.kind !== "image")}
        />
      ),
    },
  ],
  "metric-grid": [
    {
      label: "compact density",
      render: () => <MetricGrid ariaLabel="Integration summary" density="compact" items={metricGridCompactItems} />,
    },
    {
      label: "two columns",
      render: () => <MetricGrid ariaLabel="Queue summary" columns={2} items={metricGridItems} />,
    },
    {
      label: "four columns",
      render: () => <MetricGrid ariaLabel="Queue summary" columns={4} items={metricGridItems} />,
    },
  ],
  "mode-control-panel": [
    {
      label: "with feature toggles",
      render: () => (
        <ModeControlPanel
          eyebrow="eLitua"
          title="Map mode"
          subtitle="Toggles are controlled rows beneath the mode selector."
          modeLabel="Display mode"
          modeValue="clusters"
          modeOptions={[
            { value: "clusters", label: "Clusters" },
            { value: "pins", label: "Individual pins" },
            { value: "heat", label: "Heatmap" },
          ]}
          onModeChange={() => undefined}
          toggles={[
            { id: "labels", label: "Show labels", description: "Render the record name beside each marker.", checked: true, onChange: () => undefined },
            { id: "missing", label: "Include records without coordinates", checked: false, onChange: () => undefined },
          ]}
        />
      ),
    },
    {
      label: "selector only",
      render: () => (
        <ModeControlPanel
          title="Result mode"
          modeValue="list"
          modeOptions={[
            { value: "list", label: "List" },
            { value: "grid", label: "Grid" },
            { value: "map", label: "Map" },
          ]}
          onModeChange={() => undefined}
        />
      ),
    },
    {
      label: "with message and footer",
      render: () => (
        <ModeControlPanel
          eyebrow="eLitua"
          title="Map mode"
          status="degraded"
          statusTone="warning"
          modeValue="pins"
          modeOptions={[
            { value: "clusters", label: "Clusters", disabled: true },
            { value: "pins", label: "Individual pins" },
          ]}
          onModeChange={() => undefined}
          message="Clustering is unavailable while the tile provider is rate limited."
          actions={<Button size="sm" variant="ghost" type="button">Retry</Button>}
          footer="Persistence and entity behavior stay in the consuming page."
        />
      ),
    },
  ],
  "newsletter-signup-panel": [
    { label: "accent", render: () => <NewsletterSignupPanelDemo /> },
    { label: "submitted", render: () => <NewsletterSignupPanelDemo submitted /> },
    { label: "neutral error", render: () => <NewsletterSignupPanelDemo tone="neutral" error="Use a valid email address before subscribing." /> },
    { label: "busy inverse", render: () => <NewsletterSignupPanelDemo tone="tone-inverse" busy /> },
  ],
  "operational-diagnostic-panel": [
    {
      label: "metrics and details",
      render: () => (
        <OperationalDiagnosticPanel
          eyebrow="ops"
          title="Database diagnostics"
          description="Metric tiles and a detail list without an embed or payload region."
          status={{ label: "Healthy", tone: "success", detail: "Last check 184 ms" }}
          metrics={operationalDiagnosticMetrics}
          details={operationalDiagnosticDetails}
        />
      ),
    },
    {
      label: "with payload output",
      render: () => (
        <OperationalDiagnosticPanel
          eyebrow="ops"
          title="Database diagnostics"
          status={{ label: "Completed", tone: "info" }}
          metrics={operationalDiagnosticMetrics.slice(0, 2)}
          resultTitle="Last diagnostic run"
          resultDescription="Fetching, parsing, redaction and retries remain in the consuming app."
          payloadLabel="Response"
          payload={'{\n  "status": "ok",\n  "tables": 42,\n  "latencyMs": 184\n}'}
        />
      ),
    },
    {
      label: "with embedded tool",
      render: () => (
        <OperationalDiagnosticPanel
          eyebrow="ops"
          title="Database browser"
          description="The embed slot hosts a product-owned tool without owning its auth or routing."
          embed={{
            title: "Product-owned database browser",
            srcDoc: "<p>Product-owned database browser renders here.</p>",
            description: "The shared panel supplies the frame only.",
          }}
          footer="Proxying, query parameters and resize behavior stay outside the shared component."
        />
      ),
    },
  ],
  pager: [
    {
      label: "first page",
      render: () => (
        <Pager
          page={1}
          total={8}
          summary="Showing 1-10 of 74 records"
          compactSummary="1-10 of 74"
          onPageChange={() => undefined}
        />
      ),
    },
    {
      label: "middle page",
      render: () => (
        <Pager
          page={4}
          total={8}
          summary="Showing 31-40 of 74 records"
          compactSummary="31-40 of 74"
          onPageChange={() => undefined}
        />
      ),
    },
    {
      label: "detail footer",
      render: () => (
        <Pager
          page={2}
          total={3}
          summary="Showing detail section 2 of 3"
          compactSummary="Section 2 of 3"
          onPageChange={() => undefined}
          showFirstLast={false}
        />
      ),
    },
  ],
  "payment-account-panel": [
    {
      label: "methods and payment history",
      render: () => (
        <PaymentAccountPanel
          eyebrow="eLitua"
          title="Payment account"
          subtitle="A traveller-facing account renders saved methods and the payment ledger."
          summaryLabel="Balance"
          summaryValue="342.50 EUR"
          summaryDetail="Processing this week"
          stats={paymentAccountStats}
          methods={paymentMethods}
          payments={paymentHistoryRows}
        />
      ),
    },
    {
      label: "with payouts ledger",
      render: () => (
        <PaymentAccountPanel
          eyebrow="eLitua"
          title="Provider payouts"
          subtitle="A provider-facing account adds the payout ledger beside payments."
          stats={paymentAccountStats.slice(0, 2)}
          methods={paymentMethods.slice(0, 1)}
          payments={paymentHistoryRows.slice(0, 2)}
          payouts={payoutRows}
        />
      ),
    },
    {
      label: "with checkout slot",
      render: () => (
        <PaymentAccountPanel
          title="Checkout"
          summaryLabel="Due now"
          summaryValue="84.00 EUR"
          methods={paymentMethods}
          checkout={
            <>
              <p>The checkout slot hosts the product-owned provider widget.</p>
              <Button size="sm" type="button">Pay 84.00 EUR</Button>
            </>
          }
          emptyPaymentsLabel="No payments recorded for this booking yet."
        />
      ),
    },
  ],
  "payment-checkout-panel": [
    { label: "ready", render: () => <PaymentCheckoutPanelDemo /> },
    { label: "provider error", render: () => <PaymentCheckoutPanelDemo error="Payment failed. Choose another card or retry." /> },
    { label: "processing", render: () => <PaymentCheckoutPanelDemo processing /> },
  ],
  "preview-matrix-panel": [
    {
      label: "compact",
      render: () => (
        <PreviewMatrixPanel
          columns={previewMatrixColumns}
          density="compact"
          rows={previewMatrixRows().slice(0, 1)}
        />
      ),
    },
    {
      label: "empty",
      render: () => <PreviewMatrixPanel columns={previewMatrixColumns} rows={[]} emptyLabel="No matrix rows match the active filters." />,
    },
  ],
  "process-run-history-panel": [
    {
      label: "compact density",
      render: () => (
        <ProcessRunHistoryPanel
          eyebrow="score"
          title="Scheduler runs"
          subtitle="Compact density fits the run log into a scheduler detail sidebar."
          density="compact"
          runs={processRunHistoryItems}
        />
      ),
    },
    {
      label: "with header actions and footer",
      render: () => (
        <ProcessRunHistoryPanel
          eyebrow="score"
          title="Scheduler runs"
          status="3 runs"
          statusTone="info"
          runs={processRunHistoryItems.slice(0, 2)}
          actions={<Button size="sm" variant="ghost" type="button">Refresh</Button>}
          footer="Exit-code semantics are derived only when the consuming app omits a status label."
        />
      ),
    },
  ],
  "project-directory-panel": [
    { label: "loading", render: () => <ProjectDirectoryDemo state="loading" /> },
    { label: "empty", render: () => <ProjectDirectoryDemo state="empty" /> },
    { label: "error", render: () => <ProjectDirectoryDemo state="error" /> },
  ],
  "project-profile-panel": [
    { label: "loading", render: () => <ProjectProfileDemo state="loading" /> },
    { label: "empty", render: () => <ProjectProfileDemo state="empty" /> },
    { label: "error", render: () => <ProjectProfileDemo state="error" /> },
    {
      label: "no checklist",
      render: () => (
        <ProjectProfilePanel
          eyebrow="score"
          title="New project"
          subtitle="A shell for profiles that are initialized before operational checklists exist."
          badges={[{ id: "draft", label: "draft", tone: "warning" }]}
          fields={projectProfileFields.slice(0, 3)}
          checklist={[]}
        />
      ),
    },
  ],
  "project-settings-panel": [
    {
      label: "with stats and notices",
      render: () => (
        <ProjectSettingsPanel
          eyebrow="score"
          title="Project settings"
          subtitle="Stat tiles and notice rows frame the digest and config regions."
          status="admin only"
          statusTone="warning"
          stats={projectSettingsStats}
          notices={[
            {
              id: "secrets",
              title: "Secrets are referenced by name",
              description: "Values stay in the vault; the panel only renders the reference.",
              tone: "info",
            },
          ]}
          summary={{
            title: "Summary digest",
            description: "Recipient and title template are controlled input slots.",
            updatedAt: "Jun 28, 2026 04:15 UTC",
            recipientControl: {
              label: "Recipient",
              control: <Input type="email" value="owner@example.lt" onChange={() => undefined} />,
            },
            titleTemplateControl: {
              label: "Title template",
              control: <Input value="Score digest — {{date}}" onChange={() => undefined} />,
            },
            log: "Jun 28 04:15 UTC — digest delivered to owner@example.lt",
          }}
          config={{
            title: "Runtime config",
            description: "The editor is a slot; the panel never parses or validates JSON.",
            editor: <Textarea rows={5} value={'{\n  "publicConfig": true\n}'} onChange={() => undefined} />,
            meta: [{ id: "updated", label: "Updated", value: "Jun 28, 2026 04:10 UTC" }],
          }}
        />
      ),
    },
    {
      label: "digest and config only",
      render: () => (
        <ProjectSettingsPanel
          title="Project settings"
          summary={{
            recipientControl: {
              label: "Recipient",
              control: <Input type="email" value="" placeholder="owner@example.lt" onChange={() => undefined} />,
            },
            titleTemplateControl: {
              label: "Title template",
              control: <Input value="" placeholder="Digest — {{date}}" onChange={() => undefined} />,
            },
            logEmptyLabel: "No digest has been sent yet.",
          }}
          config={{
            editor: <Textarea rows={4} value="{}" onChange={() => undefined} />,
          }}
        />
      ),
    },
  ],
  "record-detail-panel": [
    {
      label: "comfortable with sections",
      render: () => (
        <RecordDetailPanel
          eyebrow="geo record"
          title="Vilnius old town"
          subtitle="The comfortable variant suits a full page or a dialog detail view."
          badges={[
            { id: "verified", label: "verified", tone: "success" },
            { id: "region", label: "Vilnius", tone: "info" },
          ]}
          fields={[
            { id: "id", label: "Record", value: "geo-1842" },
            { id: "coords", label: "Coordinates", value: "54.6872, 25.2797" },
          ]}
          sections={[
            {
              id: "coverage",
              title: "Coverage",
              fields: [
                { id: "guides", label: "Guides", value: "18 nearby" },
                { id: "routes", label: "Routes", value: "7 curated" },
              ],
            },
            {
              id: "audit",
              title: "Audit",
              emptyLabel: "No audit entries recorded for this record.",
            },
          ]}
        />
      ),
    },
    {
      label: "compact variant",
      render: () => (
        <RecordDetailPanel
          eyebrow="selected record"
          title="Trakai castle route"
          variant="compact"
          badges={[{ id: "active", label: "active", tone: "success" }]}
          fields={[
            { id: "id", label: "Record", value: "geo-1907" },
            { id: "type", label: "Type", value: "Route" },
            { id: "length", label: "Length", value: "14 km" },
          ]}
        />
      ),
    },
    {
      label: "with close and footer",
      render: () => (
        <RecordDetailPanel
          title="Curonian Spit national park"
          closeLabel="Close record"
          onClose={() => undefined}
          actions={<Button size="sm" variant="ghost" type="button">Edit</Button>}
          fields={[
            { id: "id", label: "Record", value: "geo-2044" },
            { id: "permit", label: "Permit", value: "pending" },
          ]}
          footer="Route adapters, permissions and API behavior stay in the consuming app."
        />
      ),
    },
  ],
  "relationship-picker-panel": [
    {
      label: "with select-all controls",
      render: () => (
        <RelationshipPickerPanel
          eyebrow="eLitua"
          title="Guide coverage"
          subtitle="Select-all and clear are optional controls above the checkbox rows."
          items={relationshipPickerItems.map((item) => ({ ...item, onToggle: () => undefined }))}
          selectedLabel="selected"
          selectedCount={2}
          totalLabel="areas"
          totalCount={relationshipPickerItems.length}
          selectAllLabel="Select all"
          clearLabel="Clear"
          onClearSelection={() => undefined}
          onSelectAll={() => undefined}
        />
      ),
    },
    {
      label: "read-only list",
      render: () => (
        <RelationshipPickerPanel
          eyebrow="eLitua"
          title="Assigned coverage"
          subtitle="Without toggle callbacks the rows read as a coverage record."
          status="read-only"
          statusTone="info"
          items={relationshipPickerItems.map((item) => ({ ...item, disabled: true }))}
        />
      ),
    },
    {
      label: "with footer actions",
      render: () => (
        <RelationshipPickerPanel
          title="Link routes"
          items={relationshipPickerItems.slice(0, 3).map((item) => ({ ...item, onToggle: () => undefined }))}
          footer={
            <>
              <Button size="sm" variant="ghost" type="button">Cancel</Button>
              <Button size="sm" type="button">Save links</Button>
            </>
          }
        />
      ),
    },
  ],
  "resource-index-panel": [
    { label: "list", render: () => <ResourceIndexDemo /> },
    { label: "grid", render: () => <ResourceIndexDemo layout="grid" /> },
  ],
  "resource-transfer-dialog": [
    { label: "copy", render: () => <ResourceTransferDemo /> },
    { label: "move", render: () => <ResourceTransferDemo initialMove /> },
    { label: "empty", render: () => <ResourceTransferDemo empty /> },
  ],
  "schedule-editor-dialog": [
    {
      label: "contained placement",
      render: () => (
        <ScheduleEditorDialog
          open
          placement="contained"
          eyebrow="score"
          title="Edit scheduler"
          subtitle="Contained placement renders the dialog inline instead of as a fixed overlay."
          enabled
          schedule="*/3 * * * *"
          scheduleHint="Standard five-field cron; the panel never parses the expression."
          meta={[
            { id: "runner", label: "Runner", value: "maestro-runner" },
            { id: "workflow", label: "Workflow", value: "ui-framework" },
          ]}
          onClose={() => undefined}
          onEnabledChange={() => undefined}
          onScheduleChange={() => undefined}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      label: "with checks and custom fields",
      render: () => (
        <ScheduleEditorDialog
          open
          placement="contained"
          eyebrow="score"
          title="Edit scheduler"
          enabled={false}
          schedule="17 * * * *"
          firstStartAt="2026-08-30T06:00"
          firstStartAtHint="Supply a valid datetime-local value; the panel does not format dates."
          checks={[
            { id: "single-flight", label: "Single flight", checked: true, hint: "Skip a tick while the previous run holds the lock.", onChange: () => undefined },
            { id: "notify", label: "Notify on failure", checked: false, onChange: () => undefined },
          ]}
          fields={[
            {
              id: "runner",
              label: "Runner",
              value: "ops-runner",
              control: "select",
              options: [
                { value: "maestro-runner", label: "Maestro runner" },
                { value: "board-runner", label: "Board runner" },
                { value: "ops-runner", label: "Ops runner" },
              ],
            },
            { id: "notes", label: "Notes", value: "Audits merged task branches.", control: "textarea", rows: 3 },
          ]}
          footer="Command execution policy and audit events stay in the consuming app."
          onClose={() => undefined}
          onEnabledChange={() => undefined}
          onFieldChange={() => undefined}
          onFirstStartAtChange={() => undefined}
          onScheduleChange={() => undefined}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
    {
      label: "localized labels",
      render: () => (
        <ScheduleEditorDialog
          open
          placement="contained"
          title="Redaguoti planuoklę"
          enabled
          schedule="* * * * *"
          enabledLabel="Įjungta"
          disabledLabel="Išjungta"
          enabledFieldLabel="Būsena"
          scheduleLabel="Tvarkaraštis"
          firstStartAtLabel="Pirmas paleidimas"
          cancelLabel="Atšaukti"
          saveLabel="Išsaugoti"
          savingLabel="Saugoma"
          onClose={() => undefined}
          onEnabledChange={() => undefined}
          onScheduleChange={() => undefined}
          onSubmit={(event) => event.preventDefault()}
        />
      ),
    },
  ],
  "scheduler-control-panel": [
    {
      label: "with toggle controls",
      render: () => (
        <SchedulerControlPanel
          eyebrow="score"
          title="Schedulers"
          subtitle="Supplying onToggleScheduler turns the enablement badge into a control."
          status="3 registered"
          statusTone="info"
          schedulers={schedulerControlItems}
          onToggleScheduler={() => undefined}
        />
      ),
    },
    {
      label: "read-only badges",
      render: () => (
        <SchedulerControlPanel
          eyebrow="score"
          title="Scheduler catalog"
          subtitle="Without a toggle callback enablement renders as a badge instead."
          schedulers={schedulerControlItems}
        />
      ),
    },
    {
      label: "localized enablement labels",
      render: () => (
        <SchedulerControlPanel
          title="Planuoklės"
          enabledLabel="Įjungta"
          disabledLabel="Išjungta"
          schedulers={schedulerControlItems.slice(0, 2)}
          onToggleScheduler={() => undefined}
        />
      ),
    },
  ],
  "subscription-capacity-panel": [
    { label: "loading", render: () => <SubscriptionCapacityDemo state="loading" /> },
    { label: "empty", render: () => <SubscriptionCapacityDemo state="empty" /> },
    { label: "error", render: () => <SubscriptionCapacityDemo state="error" /> },
    {
      label: "compact",
      render: () => (
        <SubscriptionCapacityPanel
          density="compact"
          eyebrow="Compact capacity"
          title="Subscription check"
          metrics={subscriptionCapacityMetrics.slice(0, 2)}
          subscriptions={subscriptionCapacityRows.slice(0, 2)}
          status="2 accounts"
          statusTone="warning"
        />
      ),
    },
  ],
  "theme-audit-panel": [
    {
      label: "no gaps",
      render: () => (
        <ThemeAuditPanel
          description="A component with complete token coverage and no recorded hardcoded values."
          metrics={[
            { id: "coverage", label: "Coverage", value: "100%", tone: "success" },
            { id: "tokens", label: "Tokens", value: "12", tone: "info" },
          ]}
          tokenGroups={themeAuditTokenGroups.slice(0, 2)}
          gaps={[]}
        />
      ),
    },
    {
      label: "minimal",
      render: () => (
        <ThemeAuditPanel
          title="Audit pending"
          description="Empty token and gap states preserve the review panel footprint."
          metrics={[{ id: "status", label: "Status", value: "pending", tone: "warning" }]}
          tokenGroups={[]}
          gaps={[]}
        />
      ),
    },
  ],
  "theme-export-panel": [
    {
      label: "actions only",
      render: () => (
        <ThemeExportPanel
          badges={[{ id: "scope", label: "Score local themes", tone: "info" }]}
          description="No preview is required when the consuming app already renders export output elsewhere."
          actions={[
            { id: "copy-json", label: "Copy JSON", kind: "copy" },
            { id: "copy-css", label: "Copy CSS", kind: "copy" },
            { id: "download", label: "Download", kind: "download" },
          ]}
        />
      ),
    },
    {
      label: "compact busy",
      render: () => (
        <ThemeExportPanel
          activeFormatId="css"
          density="compact"
          formats={themeExportFormats}
          actions={[{ id: "download-css", label: "CSS", kind: "download", busy: true, busyLabel: "Preparing" }]}
          preview=".score-theme-calm-light {\n  --background: oklch(0.98 0.01 240);\n}"
        />
      ),
    },
  ],
  "theme-lab-panel": [
    {
      label: "empty proposal",
      render: () => (
        <ThemeLabPanel
          description="Stable before the first API response."
          prompt={{
            id: "registry-theme-lab-empty-prompt",
            label: "Vibe or brand",
            value: "High contrast field operations",
            onChange: () => undefined,
          }}
          generateAction={{ label: "Generate" }}
          applyAction={{ label: "Apply to preview", disabled: true }}
          proposal={null}
        />
      ),
    },
    {
      label: "generating",
      render: () => (
        <ThemeLabPanel
          badges={[{ id: "model", label: "waiting for model", tone: "warning" }]}
          prompt={{
            id: "registry-theme-lab-busy-prompt",
            label: "Vibe or brand",
            value: "Quiet review cockpit",
            onChange: () => undefined,
            disabled: true,
          }}
          iteration={{
            id: "registry-theme-lab-busy-iteration",
            label: "Iteration note",
            value: "Reduce saturation",
            onChange: () => undefined,
            disabled: true,
          }}
          generateAction={{ label: "Generate", busyLabel: "Generating", busy: true }}
          applyAction={{ label: "Apply to preview", disabled: true }}
          proposal={themeLabProposal}
        />
      ),
    },
  ],
  "theme-preview-canvas": [
    {
      label: "single",
      render: () => (
        <ThemePreviewCanvas mode="single" canvasWidth="38rem">
          {(surface) => <ThemePreviewFixture surface={surface} />}
        </ThemePreviewCanvas>
      ),
    },
    {
      label: "compare",
      render: () => (
        <ThemePreviewCanvas
          canvasWidth="26rem"
          compareSurfaces={themePreviewCompareSurfaces}
          mode="compare"
        >
          {(surface) => <ThemePreviewFixture surface={surface} />}
        </ThemePreviewCanvas>
      ),
    },
  ],
  "work-board-toolbar": [
    {
      label: "search with project and epic selects",
      render: () => (
        <WorkBoardToolbar
          eyebrow="score"
          title="Work board"
          subtitle="Search plus both route selects is the full board header configuration."
          badges={workBoardToolbarBadges}
          search={{ value: "type:story", label: "Search", placeholder: "Lucene query", onChange: () => undefined }}
          project={{ label: "Project", value: "score", options: workBoardProjectOptions, onChange: () => undefined }}
          epic={{ label: "Epic", value: "task-206", options: workBoardEpicOptions, onChange: () => undefined }}
        />
      ),
    },
    {
      label: "with active filter chips",
      render: () => (
        <WorkBoardToolbar
          eyebrow="score"
          title="Work board"
          filtersOpen
          filtersLabel="Filters"
          onFiltersOpenChange={() => undefined}
          project={{ label: "Project", value: "score", options: workBoardProjectOptions, onChange: () => undefined }}
          activeFilters={[
            { id: "project", label: "Project: score", tone: "success", removeLabel: "Remove project filter", onRemove: () => undefined },
            { id: "epic", label: "Epic: UI Framework", tone: "accent", removeLabel: "Remove epic filter", onRemove: () => undefined },
            { id: "query", label: "type:story", tone: "info", removeLabel: "Remove query", onRemove: () => undefined },
          ]}
          activeFiltersLabel="Active filters"
          clearFiltersAction={<Button size="sm" variant="ghost" type="button">Clear all</Button>}
        />
      ),
    },
    {
      label: "search only",
      render: () => (
        <WorkBoardToolbar
          title="Board search"
          search={{ value: "", placeholder: "Search the board", onChange: () => undefined }}
          headerActions={<Button size="sm" type="button">New task</Button>}
        />
      ),
    },
  ],
  "work-item-card": [
    {
      label: "comfortable with epic link",
      render: () => <WorkItemCard {...workItemCards[0]} />,
    },
    {
      label: "compact density",
      render: () => <WorkItemCard {...workItemCards[0]} density="compact" />,
    },
    {
      label: "with footer slot",
      render: () => <WorkItemCard {...workItemCards[1]} density="comfortable" selected={false} />,
    },
  ],
  "work-item-planning-panel": [
    {
      label: "full option vocabulary",
      render: () => (
        <WorkItemPlanningPanel
          eyebrow="score"
          title="Plan work item"
          subtitle="Project, role, complexity, actor and epic vocabularies are all injected."
          workItem={registryWorkItemDraft}
          triage={registryWorkItemTriage}
          typeOptions={workItemTypeOptions}
          projectOptions={workItemProjectOptions}
          roleOptions={workItemRoleOptions}
          complexityOptions={workItemComplexityOptions}
          actorOptions={workItemActorOptions}
          epicOptions={workItemEpicOptions}
          canMoveProject
          onTriage={() => undefined}
          onTriageChange={() => undefined}
          onWorkItemChange={() => undefined}
          onSave={() => undefined}
        />
      ),
    },
    {
      label: "project locked",
      render: () => (
        <WorkItemPlanningPanel
          eyebrow="score"
          title="Edit work item"
          subtitle="Without the move-project grant the project select renders disabled."
          badges={[{ id: "locked", label: "project locked", tone: "warning" }]}
          workItem={registryWorkItemDraft}
          triage={registryWorkItemTriage}
          typeOptions={workItemTypeOptions}
          projectOptions={workItemProjectOptions}
          actorOptions={workItemActorOptions}
          onTriage={() => undefined}
          onTriageChange={() => undefined}
          onWorkItemChange={() => undefined}
          onSave={() => undefined}
        />
      ),
    },
    {
      label: "localized action labels",
      render: () => (
        <WorkItemPlanningPanel
          title="Planuoti darbą"
          workItem={registryWorkItemDraft}
          triage={registryWorkItemTriage}
          typeOptions={workItemTypeOptions}
          saveLabel="Išsaugoti"
          triageLabel="Pritaikyti triažą"
          cancelLabel="Atšaukti"
          onCancel={() => undefined}
          onTriage={() => undefined}
          onTriageChange={() => undefined}
          onWorkItemChange={() => undefined}
          onSave={() => undefined}
        />
      ),
    },
  ],
  "work-item-relation-editor-panel": [
    {
      label: "empty fields",
      render: () => <WorkItemRelationEditorPanel density="compact" title="No relation fields" fields={[]} />,
    },
    {
      label: "loading",
      render: () => (
        <WorkItemRelationEditorPanel
          density="compact"
          title="Loading relations"
          fields={[]}
          loading
          loadingLabel="Resolving relation options..."
        />
      ),
    },
  ],
  "work-item-trace-panel": [
    {
      label: "relations and notes",
      render: () => (
        <WorkItemTracePanel
          eyebrow="score"
          title="task-293 trace"
          subtitle="Both regions render when the consuming app supplies relations and review notes."
          badges={[{ id: "epic", label: "UI Framework", tone: "accent" }]}
          relationGroups={workItemTraceRelationGroups}
          notes={workItemTraceNotes}
        />
      ),
    },
    {
      label: "relations only",
      render: () => (
        <WorkItemTracePanel
          eyebrow="score"
          title="Dependency map"
          relationTitle="Dependencies"
          relationGroups={workItemTraceRelationGroups}
          emptyNotesLabel="Review notes are rendered on the review tab."
        />
      ),
    },
    {
      label: "notes only",
      render: () => (
        <WorkItemTracePanel
          eyebrow="score"
          title="Review history"
          notesTitle="Review notes"
          notes={workItemTraceNotes}
          emptyRelationsLabel="Relations are shown on the planning tab."
          footer="Review creation, subscriptions and audit behavior stay in Score."
        />
      ),
    },
  ],
  "workflow-command-bar": [
    {
      label: "compact wrap",
      render: () => (
        <WorkflowCommandBar
          eyebrow="score"
          title="Transitions"
          density="compact"
          layout="wrap"
          commands={workflowCommandBarCommands}
        />
      ),
    },
    {
      label: "stacked layout",
      render: () => (
        <WorkflowCommandBar
          eyebrow="score"
          title="Release transitions"
          subtitle="A stacked layout gives each command room for its consequence copy."
          layout="stack"
          commands={workflowReleaseCommands}
        />
      ),
    },
    {
      label: "with current state and footer",
      render: () => (
        <WorkflowCommandBar
          eyebrow="score"
          title="Transitions"
          currentState="review"
          currentStateTone="warning"
          status="reviewer decision pending"
          statusTone="info"
          commands={workflowReleaseCommands.slice(0, 2)}
          actions={<Button size="sm" variant="ghost" type="button">History</Button>}
          footer="Workflow legality, release grants and audit events stay in the consuming app."
        />
      ),
    },
  ],
  "workflow-map-panel": [
    { label: "loading", render: () => <WorkflowMapDemo state="loading" /> },
    { label: "empty", render: () => <WorkflowMapDemo state="empty" /> },
    { label: "error", render: () => <WorkflowMapDemo state="error" /> },
    {
      label: "compact",
      render: () => (
        <WorkflowMapPanel
          density="compact"
          eyebrow="Compact workflow"
          title="Release handoff"
          status="review"
          statusTone="warning"
          insights={workflowMapInsights.slice(1, 3)}
          stages={workflowMapStages.slice(2, 5)}
        />
      ),
    },
  ],
};
