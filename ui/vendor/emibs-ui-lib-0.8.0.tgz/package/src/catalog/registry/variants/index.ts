import { addressVariants } from "../address";
import type { Variant } from "../types";
import { primitivesVariants } from "./primitives";
import { layoutVariants } from "./layout";
import { dataVariants } from "./data";
import { feedbackVariants } from "./feedback";
import { authVariants } from "./auth";

export const VARIANTS: Record<string, Variant[]> = {
  ...addressVariants,
  ...primitivesVariants,
  ...layoutVariants,
  ...dataVariants,
  ...feedbackVariants,
  ...authVariants,
};
