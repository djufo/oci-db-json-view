import {
  AccountMenuRegistryDemo,
  AccountProfileRegistryDemo,
  AccountSessionsRegistryDemo,
  AuthAccessRegistryDemo,
  AuthStatusRegistryDemo,
  PasswordRevealRegistryDemo,
  SessionRefreshRegistryDemo,
} from "../demoComponents";
import type { Variant } from "../types";

export const authVariants: Record<string, Variant[]> = {
  "account-menu": [
    { label: "authenticated", render: () => <AccountMenuRegistryDemo /> },
    { label: "guest", render: () => <AccountMenuRegistryDemo guest /> },
  ],
  "account-profile-panel": [
    { label: "full profile", render: () => <AccountProfileRegistryDemo /> },
    { label: "compact identity", render: () => <AccountProfileRegistryDemo compact /> },
  ],
  "account-sessions-panel": [
    { label: "active sessions", render: () => <AccountSessionsRegistryDemo /> },
    { label: "loading", render: () => <AccountSessionsRegistryDemo state="loading" /> },
    { label: "empty", render: () => <AccountSessionsRegistryDemo state="empty" /> },
    { label: "error", render: () => <AccountSessionsRegistryDemo state="error" /> },
  ],
  "auth-access-panel": [
    { label: "operator token", render: () => <AuthAccessRegistryDemo /> },
    { label: "traveler signup", render: () => <AuthAccessRegistryDemo mode="portal" /> },
    { label: "password recovery", render: () => <AuthAccessRegistryDemo mode="recovery" /> },
  ],
  "auth-status-panel": [
    { label: "loading", render: () => <AuthStatusRegistryDemo state="loading" /> },
    { label: "success", render: () => <AuthStatusRegistryDemo state="success" /> },
    { label: "no access", render: () => <AuthStatusRegistryDemo state="no-access" /> },
    { label: "error", render: () => <AuthStatusRegistryDemo state="error" /> },
  ],
  "password-reveal-button": [
    { label: "hidden", render: () => <PasswordRevealRegistryDemo /> },
    { label: "visible", render: () => <PasswordRevealRegistryDemo initialVisible /> },
  ],
  "session-refresh-dialog": [
    { label: "open", render: () => <SessionRefreshRegistryDemo /> },
    { label: "dismissed", render: () => <SessionRefreshRegistryDemo initiallyOpen={false} /> },
  ],
};
