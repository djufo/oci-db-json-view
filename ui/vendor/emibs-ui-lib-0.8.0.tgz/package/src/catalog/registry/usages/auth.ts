import type { UsageSnippet } from "../types";

export const authUsages: Record<string, UsageSnippet> = {
  "account-menu": {
    import: `import { AccountMenu } from "emibs-ui-lib/components/auth/AccountMenu";`,
    snippet: `<AccountMenu open={menuOpen} identity={{ name: actor.name, secondary: actor.email, initials: actor.initials, role: actor.role, roleTone: "success" }} sections={visibleSections} onOpenChange={setMenuOpen} />`,
    variants: [
      { label: "guest header", snippet: '<AccountMenu open={menuOpen} guestTitle="Account" guestDescription="Sign in to save routes and preferences." guestActions={[{ id: "login", label: "Log in", href: "/login" }]} onOpenChange={setMenuOpen} />' },
      { label: "keep open on select", snippet: '<AccountMenu open={menuOpen} closeOnSelect={false} align="start" identity={identity} sections={sections} onOpenChange={setMenuOpen} />' },
    ],
  },
  "account-profile-panel": {
    import: `import { AccountProfilePanel } from "emibs-ui-lib/components/auth/AccountProfilePanel";`,
    snippet: `<AccountProfilePanel title={profile.displayName} eyebrow="authenticated account" avatarLabel={\`\${profile.displayName} account\`} badges={badges} stats={stats} sections={sections} secondaryLinks={links} actions={<Button type="submit">Save profile</Button>} onSubmit={saveProfile} />`,
    variants: [
      { label: "verification prompt", snippet: '<AccountProfilePanel title={profile.displayName} notices={[{ id: "verify", tone: "warning", title: "Email verification required", action: <Button onClick={resend}>Resend</Button> }]} sections={sections} onSubmit={saveProfile} />' },
      { label: "identity only", snippet: '<AccountProfilePanel title={profile.displayName} subtitle="Account identity" avatarLabel="Account" onSubmit={saveProfile} />' },
    ],
  },
  "account-sessions-panel": {
    import: `import { AccountSessionsPanel } from "emibs-ui-lib/components/auth/AccountSessionsPanel";`,
    snippet: `<AccountSessionsPanel title="Active sessions" eyebrow="account security" sessions={sessions} loading={loading} error={error} status={\`\${sessions.length} active\`} statusTone="info" actions={<Button variant="danger" onClick={revokeOthers}>Revoke others</Button>} />`,
    variants: [
      { label: "per-row revoke", snippet: '<AccountSessionsPanel title="Active sessions" sessions={sessions.map((s) => ({ ...s, revokeLabel: "Revoke session", actionDisabled: s.current, onRevoke: () => revoke(s.id) }))} />' },
      { label: "empty copy", snippet: '<AccountSessionsPanel title="Active sessions" sessions={[]} emptyTitle="No active sessions" emptyDescription="Sessions will appear here after sign-in." />' },
    ],
  },
  "auth-access-panel": {
    import: `import { AuthAccessPanel, AuthFieldRow, AuthInputField, AuthStrengthMeter } from "emibs-ui-lib/components/auth/AuthAccessPanel";`,
    snippet: `<AuthAccessPanel title="Create account" eyebrow="eLitua traveler" providers={providers} dividerLabel="or register with email" message={error ? { tone: "danger", children: error } : undefined} footer={<a href="/login">Log in</a>}>{form}</AuthAccessPanel>`,
    variants: [
      { label: "SDK provider slot", snippet: '<AuthAccessPanel variant="operator" title="Sign in to Score" providerSlot={<div ref={googleButtonRef} />} dividerLabel="or use development access">{tokenForm}</AuthAccessPanel>' },
      { label: "recovery outcome", snippet: '<AuthAccessPanel title="Check your email" message={{ tone: "success", children: "A reset link was sent if that address has an account." }} actions={<Button onClick={retry}>Try again</Button>} />' },
    ],
  },
  "auth-status-panel": {
    import: `import { AuthStatusPanel } from "emibs-ui-lib/components/auth/AuthStatusPanel";`,
    snippet: `<AuthStatusPanel tone={status.tone} eyebrow="OAuth callback" title={status.title} subtitle={status.detail} actions={<Button onClick={goHome}>Go to home</Button>} />`,
    variants: [
      { label: "operator boot", snippet: '<AuthStatusPanel variant="operator" fullHeight tone="loading" title="Checking your session" subtitle="Provider tokens are being exchanged." />' },
      { label: "no access", snippet: '<AuthStatusPanel tone="info" title="No project access" subtitle="Project membership is still required." actions={<Button variant="secondary" onClick={refresh}>Refresh session</Button>} />' },
    ],
  },
  "password-reveal-button": {
    import: `import { PasswordRevealButton } from "emibs-ui-lib/components/auth/PasswordRevealButton";`,
    snippet: `<AuthInputField id="password" label="Password" type={visible ? "text" : "password"} value={password} onChange={handleChange} action={<PasswordRevealButton visible={visible} onVisibleChange={setVisible} />} />`,
    variants: [
      { label: "localized labels", snippet: '<PasswordRevealButton visible={visible} showLabel={t("password.hiddenShow")} hideLabel={t("password.shownHide")} onVisibleChange={setVisible} />' },
      { label: "locked field", snippet: '<PasswordRevealButton disabled visible={false} onVisibleChange={setVisible} />' },
    ],
  },
  "session-refresh-dialog": {
    import: `import { SessionRefreshDialog } from "emibs-ui-lib/components/auth/SessionRefreshDialog";`,
    snippet: `<SessionRefreshDialog open={sessionExpired} title="Sign in again" eyebrow="Score operator" subtitle="Refresh your session without losing current page context." providers={providers} closeDisabled={exchanging} onClose={dismiss}>{credentialForm}</SessionRefreshDialog>`,
    variants: [
      { label: "hard reauth gate", snippet: '<SessionRefreshDialog open title="Session expired" message={{ tone: "danger", children: "Re-authentication is required to continue." }} providers={providers} />' },
      { label: "SDK provider slot", snippet: '<SessionRefreshDialog open title="Sign in again" providerSlot={<div ref={googleButtonRef} />} dividerLabel="Development access" onClose={dismiss}>{tokenForm}</SessionRefreshDialog>' },
    ],
  },
};
