import type { UsageSnippet } from "../types";

export const primitivesUsages: Record<string, UsageSnippet> = {
  "file-upload-control": {
    import: `import { FileUploadControl } from "emibs-ui-lib/components/primitives/FileUploadControl";`,
    snippet: `<FileUploadControl accept="image/*,.md" label="Add evidence" multiple variant="dropzone" onFilesAdded={(files, selection) => validateAndUpload(files, selection.source)} />`,
    variants: [
      {
        label: "picker compatibility",
        snippet: '<FileUploadControl label="Choose file" onFilesSelected={handleNativePickerFiles} />',
      },
      {
        label: "localized announcement",
        snippet: '<FileUploadControl label="Pridėti failus" onFilesAdded={handleFiles} formatSelectionAnnouncement={(files) => `${files.length} failai pasirinkti.`} />',
      },
    ],
  },
  button: {
    import: `import { Button } from "emibs-ui-lib/components/primitives/Button";`,
    snippet: "<Button>Primary</Button>",
    variants: [
      { label: "primary", snippet: '<Button>Primary</Button>' },
      { label: "danger", snippet: '<Button variant="danger">Danger</Button>' },
      { label: "ghost", snippet: '<Button variant="ghost">Ghost</Button>' },
      { label: "quiet", snippet: '<Button variant="quiet">Quiet</Button>' },
      { label: "secondary compatibility", snippet: '<Button variant="secondary">Secondary</Button>' },
      { label: "sm", snippet: '<Button size="sm">Small</Button>' },
      { label: "md", snippet: '<Button size="md">Medium</Button>' },
      { label: "lg", snippet: '<Button size="lg">Large</Button>' },
      { label: "disabled", snippet: '<Button disabled>Disabled</Button>' },
      { label: "loading", snippet: '<Button loading loadingLabel="Saving changes">Save changes</Button>' },
    ],
  },
  breadcrumb: {
    import: `import { Breadcrumb } from "emibs-ui-lib/components/primitives/Breadcrumb";`,
    snippet: `<Breadcrumb ariaLabel="Project path" items={breadcrumbItems} />`,
    variants: [
      { label: "custom separator", snippet: '<Breadcrumb items={items} separator="›" />' },
      { label: "explicit current", snippet: '<Breadcrumb items={[...items, { id: "task", label: "Task", current: true }]} />' },
    ],
  },
  chip: {
    import: `import { Chip, StatusChip, BandChip, ClassChip, ModelChip } from "emibs-ui-lib/components/primitives/Chip";`,
    snippet: `<Chip tone="accent">Base chip</Chip>`,
    variants: [
      { label: "status", snippet: '<StatusChip status="success" label="ready" />' },
      { label: "band", snippet: '<BandChip band="campaign" />' },
      { label: "class", snippet: '<ClassChip classification="convergence" />' },
      { label: "model", snippet: '<ModelChip model="advanced" label="advanced model" />' },
    ],
  },
  "freshness-badge": {
    import: `import { FreshnessBadge } from "emibs-ui-lib/components/primitives/FreshnessBadge";`,
    snippet: `<FreshnessBadge value={lastHeartbeat} staleAfterMs={5 * 60_000} />`,
    variants: [
      { label: "Score display buckets only", snippet: '<FreshnessBadge value={lastHeartbeat} />' },
      { label: "explicit stale policy", snippet: '<FreshnessBadge value={lastHeartbeat} staleAfterMs={300_000} />' },
      { label: "unknown", snippet: '<FreshnessBadge value={null} />' },
    ],
  },
  "keyboard-hint": {
    import: `import { KeyboardHint } from "emibs-ui-lib/components/primitives/KeyboardHint";`,
    snippet: `<KeyboardHint keys={["⌘", "K"]} />`,
    variants: [
      { label: "single key", snippet: '<KeyboardHint keys={["Esc"]} />' },
      { label: "custom label", snippet: '<KeyboardHint keys={["Ctrl", "Enter"]} label="Submit with Control plus Enter" />' },
    ],
  },
  meter: {
    import: `import { Meter } from "emibs-ui-lib/components/primitives/Meter";`,
    snippet: `<Meter label="Daily capacity" value={remainingPercent} />`,
    variants: [
      { label: "explicit unknown (B31)", snippet: '<Meter label="Daily capacity" value={null} />' },
      { label: "critical", snippet: '<Meter label="Daily capacity" value={8} />' },
      { label: "without visible value", snippet: '<Meter label="Daily capacity" value={72} showValue={false} />' },
    ],
  },
  "signal-dot": {
    import: `import { SignalDot } from "emibs-ui-lib/components/primitives/SignalDot";`,
    snippet: `<SignalDot label="Online" tone="success" showLabel />`,
    variants: [
      { label: "icon only", snippet: '<SignalDot label="Live updates" tone="info" pulse />' },
      { label: "warning", snippet: '<SignalDot label="Degraded" tone="warning" showLabel />' },
    ],
  },
  menu: {
    import: `import { Menu } from "emibs-ui-lib/components/primitives/Menu";`,
    snippet: `<Menu triggerLabel="Task actions" items={menuItems} />`,
    variants: [
      { label: "controlled", snippet: '<Menu open={open} onOpenChange={setOpen} triggerLabel="Actions" items={items} />' },
      { label: "aligned end", snippet: '<Menu align="end" triggerLabel="Actions" items={items} />' },
    ],
  },
  skeleton: {
    import: `import { Skeleton } from "emibs-ui-lib/components/primitives/Skeleton";`,
    snippet: `<Skeleton variant="text" />`,
    variants: [
      { label: "rectangular wave", snippet: '<Skeleton variant="rectangular" animation="wave" />' },
      { label: "circular status", snippet: '<Skeleton variant="circular" exposed ariaLabel="Loading avatar" />' },
    ],
  },
  slider: {
    import: `import { Slider } from "emibs-ui-lib/components/primitives/Slider";`,
    snippet: `<Slider label="Preview width" value={width} onValueChange={setWidth} />`,
    variants: [
      { label: "formatted", snippet: '<Slider label="Capacity" value={value} formatValue={(next) => `${next}%`} onValueChange={setValue} />' },
      { label: "read only", snippet: '<Slider label="Fixed limit" value={25} readOnly />' },
    ],
  },
  "table-primitive": {
    import: `import { TablePrimitive } from "emibs-ui-lib/components/primitives/TablePrimitive";`,
    snippet: `<TablePrimitive ariaLabel="Tasks" columns={columns} rows={rows} getRowId={(row) => row.id} selection={selection} />`,
    variants: [
      { label: "compact striped", snippet: '<TablePrimitive ariaLabel="Tasks" columns={columns} rows={rows} getRowId={getRowId} density="compact" striped />' },
      { label: "empty", snippet: '<TablePrimitive ariaLabel="Tasks" columns={columns} rows={[]} getRowId={getRowId} emptyMessage="No tasks" />' },
    ],
  },
  toolbar: {
    import: `import { Toolbar, ToolbarItem } from "emibs-ui-lib/components/primitives/Toolbar";`,
    snippet: `<Toolbar ariaLabel="Formatting commands" rovingFocus><ToolbarItem>Bold</ToolbarItem><ToolbarItem>Italic</ToolbarItem></Toolbar>`,
    variants: [
      { label: "vertical", snippet: '<Toolbar ariaLabel="Object commands" orientation="vertical" rovingFocus>{items}</Toolbar>' },
      { label: "native tab order", snippet: '<Toolbar ariaLabel="Page commands">{buttons}</Toolbar>' },
    ],
  },
  tooltip: {
    import: `import { Tooltip } from "emibs-ui-lib/components/primitives/Tooltip";`,
    snippet: `<Tooltip content="Refreshes the preview"><Button>Refresh</Button></Tooltip>`,
    variants: [
      { label: "bottom", snippet: '<Tooltip content="More detail" side="bottom"><button>Info</button></Tooltip>' },
      { label: "left", snippet: '<Tooltip content="More detail" side="left"><button>Info</button></Tooltip>' },
    ],
  },
  badge: {
    import: `import { Badge } from "emibs-ui-lib/components/primitives/Badge";`,
    snippet: "<Badge tone=\"info\">Info</Badge>",
    variants: [
      { label: "neutral", snippet: '<Badge tone="neutral">Neutral</Badge>' },
      { label: "info", snippet: '<Badge tone="info">Info</Badge>' },
      { label: "success", snippet: '<Badge tone="success">Success</Badge>' },
      { label: "warning", snippet: '<Badge tone="warning">Warning</Badge>' },
      { label: "danger", snippet: '<Badge tone="danger">Danger</Badge>' },
      { label: "accent", snippet: '<Badge tone="accent">Accent</Badge>' },
    ],
  },
  "command-palette": {
    import: `import { CommandPalette } from "emibs-ui-lib/components/primitives/CommandPalette";`,
    snippet: `<CommandPalette open query={query} onQueryChange={setQuery} groups={groups} onOpenChange={setOpen} />`,
    variants: [
      { label: "fixed modal", snippet: '<CommandPalette open={open} query={query} onQueryChange={setQuery} groups={groups} onOpenChange={setOpen} />' },
      { label: "contained demo", snippet: '<CommandPalette open query={query} onQueryChange={setQuery} groups={groups} placement="contained" />' },
    ],
  },
  "icon-button": {
    import: `import { Bell, Plus, RefreshCw, Trash2 } from "lucide-react";\nimport { IconButton } from "emibs-ui-lib/components/primitives/IconButton";`,
    snippet: '<IconButton label="Alerts" icon={<Bell size={16} />} />',
    variants: [
      { label: "neutral", snippet: '<IconButton label="Refresh" icon={<RefreshCw size={16} />} />' },
      { label: "active", snippet: '<IconButton label="New" variant="active" icon={<Plus size={16} />} />' },
      { label: "ghost", snippet: '<IconButton label="Alerts" variant="ghost" icon={<Bell size={16} />} />' },
      { label: "danger", snippet: '<IconButton label="Delete" variant="danger" icon={<Trash2 size={16} />} />' },
    ],
  },
  "identity-avatar": {
    import: `import { Bot } from "lucide-react";\nimport { IdentityAvatar } from "emibs-ui-lib/components/primitives/IdentityAvatar";`,
    snippet: `<IdentityAvatar label="Austeja Petrauskaite" initials="AP" size="lg" />`,
    variants: [
      { label: "icon", snippet: '<IdentityAvatar label="Agent worker" icon={<Bot size={18} />} tone="warning" />' },
      { label: "initials", snippet: '<IdentityAvatar label="Ruta Travels" initials="RT" tone="success" />' },
      { label: "large status", snippet: '<IdentityAvatar label="Guide profile" initials="GP" size="xl" tone="accent" status="success" statusLabel="Verified" />' },
      { label: "rounded small", snippet: '<IdentityAvatar label="Editorial author" initials="MK" shape="rounded" size="sm" tone="info" />' },
    ],
  },
  "loading-spinner": {
    import: `import { LoadingSpinner } from "emibs-ui-lib/components/primitives/LoadingSpinner";`,
    snippet: `<LoadingSpinner label="Loading map" />`,
    variants: [
      { label: "inline", snippet: '<LoadingSpinner label="Loading records" />' },
      { label: "hidden label", snippet: '<LoadingSpinner ariaLabel="Loading records" showLabel={false} size="sm" />' },
      { label: "centered", snippet: '<LoadingSpinner label="Restoring session" tone="accent" variant="centered" />' },
    ],
  },
  "switch-control": {
    import: `import { SwitchControl } from "emibs-ui-lib/components/primitives/SwitchControl";`,
    snippet: '<SwitchControl checked={true} label="Email notifications" onChange={() => undefined} />',
  },
  "checkbox-control": {
    import: `import { CheckboxControl } from "emibs-ui-lib/components/primitives/CheckboxControl";`,
    snippet: '<CheckboxControl checked={true} label="Require review before release" onChange={() => undefined} />',
  },
  collapsible: {
    import: `import { Collapsible } from "emibs-ui-lib/components/primitives/Collapsible";`,
    snippet: '<Collapsible title="Preference group" count="4 categories">Preference rows</Collapsible>',
    variants: [
      { label: "controlled", snippet: '<Collapsible title="Filters" collapsed={collapsed} onCollapsedChange={setCollapsed}>Filter controls</Collapsible>' },
      { label: "compact", snippet: '<Collapsible title="Queue metrics" density="compact" defaultCollapsed>Metric rows</Collapsible>' },
    ],
  },
  "segmented-control": {
    import: `import { SegmentedControl } from "emibs-ui-lib/components/primitives/SegmentedControl";`,
    snippet: `<SegmentedControl ariaLabel="Workspace view" value="board" options={[{ id: "board", label: "Board" }, { id: "table", label: "Table" }]} onValueChange={() => undefined} />`,
  },
  "search-field": {
    import: `import { SearchField } from "emibs-ui-lib/components/primitives/SearchField";`,
    snippet: '<SearchField id="search-sample" label="Search records" value="Route" onValueChange={() => undefined} />',
  },
  "select-control": {
    import: `import { SelectControl } from "emibs-ui-lib/components/primitives/SelectControl";`,
    snippet: '<SelectControl id="project-select" label="Project" value="score" options={[{ value: "score", label: "Score" }]} onValueChange={() => undefined} />',
    variants: [
      { label: "placeholder", snippet: '<SelectControl id="role-select" label="Role" value="" placeholder="Choose a role" options={roleOptions} onValueChange={setRole} />' },
      { label: "compact", snippet: '<SelectControl id="region-select" label="Region" value={region} density="compact" options={regionOptions} onValueChange={setRegion} />' },
    ],
  },
  dialog: {
    import: `import { Dialog } from "emibs-ui-lib/components/primitives/overlay";`,
    snippet: '<Dialog open={open} onClose={() => setOpen(false)} title="Edit task" description="Task fields stay product-owned." footer={footerActions}>{body}</Dialog>',
    variants: [
      { label: "alertdialog", snippet: '<Dialog open={open} onClose={() => setOpen(false)} role="alertdialog" size="sm" title="Delete this project?" footer={confirmActions} />' },
    ],
  },
  drawer: {
    import: `import { Drawer } from "emibs-ui-lib/components/primitives/overlay";`,
    snippet: '<Drawer open={open} onClose={() => setOpen(false)} title="Board filters">{filterControls}</Drawer>',
    variants: [
      { label: "left", snippet: '<Drawer open={open} onClose={() => setOpen(false)} side="left" size="min(90vw, 320px)" title="Navigation">{nav}</Drawer>' },
      { label: "bottom", snippet: '<Drawer open={open} onClose={() => setOpen(false)} side="bottom" title="Quick actions">{actions}</Drawer>' },
      { label: "bare chrome", snippet: '<Drawer open={open} onClose={close} chrome="bare" layerClassName="ui-filter-drawer__mount" backdropClassName="ui-filter-drawer__overlay" className="ui-filter-drawer__panel" surfaceProps={{ id: panelId, "aria-labelledby": titleId }}>{panelContents}</Drawer>' },
    ],
  },
  popover: {
    import: `import { Popover, getPopoverTriggerProps } from "emibs-ui-lib/components/primitives/overlay";`,
    snippet: '<Popover open={open} onClose={() => setOpen(false)} anchorRef={triggerRef} aria-label="Column options" id="columns-popover">{options}</Popover>',
    variants: [
      { label: "trigger wiring", snippet: '<button ref={triggerRef} {...getPopoverTriggerProps({ open, id: "columns-popover" })} onClick={() => setOpen((value) => !value)}>Columns</button>' },
      { label: "anchored menu", snippet: '<Popover open={open} onClose={() => setOpen(false)} anchorRef={triggerRef} side="top" align="start" matchAnchorWidth role="menu" aria-label="Row actions">{menuItems}</Popover>' },
    ],
  },
  "overlay-harness": {
    // The barrel, not the overlay subpath: `components/primitives/overlay`
    // exports the engine (useOverlay, OverlayPortal, Dialog, Drawer, Popover)
    // and the harness is not part of that engine surface — src/lib/index.ts is
    // where it is actually exported from.
    import: `import { OverlayHarness } from "emibs-ui-lib";`,
    snippet: "<OverlayHarness />",
    variants: [
      { label: "contained preview", snippet: '<OverlayHarness container={host} modal={false} scrollProbe={false} />' },
      { label: "controlled + stacked", snippet: '<OverlayHarness open={open} onOpenChange={setOpen} nestedOpen={nested} onNestedOpenChange={setNested} />' },
    ],
  },
  "radio-group": {
    import: `import { RadioGroup } from "emibs-ui-lib/components/primitives/RadioGroup";`,
    snippet: '<RadioGroup id="cadence" label="Summary cadence" value={cadence} options={[{ value: "daily", label: "Daily" }, { value: "weekly", label: "Weekly" }]} onChange={setCadence} />',
    variants: [
      { label: "horizontal compact", snippet: '<RadioGroup id="view" label="Board view" defaultValue="board" density="compact" orientation="horizontal" options={viewOptions} onChange={setView} />' },
      { label: "validation", snippet: '<RadioGroup id="role" label="Account role" required options={roleOptions} error={roleError} onChange={setRole} />' },
    ],
  },
  "date-field": {
    import: `import { DateField } from "emibs-ui-lib/components/primitives/DateField";`,
    snippet: '<DateField id="due-date" label="Due date" value={dueDate} onChange={setDueDate} />',
    variants: [
      { label: "bounded", snippet: '<DateField id="cutoff" label="Cutoff date" value={cutoff} min="2026-07-01" max="2026-12-31" onChange={setCutoff} />' },
      { label: "validation", snippet: '<DateField id="start" label="Start date" value={start} required error={startError} onChange={setStart} />' },
    ],
  },
  "number-input-control": {
    import: `import { NumberInputControl } from "emibs-ui-lib/components/primitives/NumberInputControl";`,
    snippet: '<NumberInputControl id="issue-points" label="Points" value={points} min={0} step={1} suffix="pts" onValueChange={setPoints} />',
    variants: [
      { label: "coordinate", snippet: '<NumberInputControl id="latitude" label="Latitude" value={latitude} min={-90} max={90} step={0.000001} suffix="lat" onValueChange={setLatitude} />' },
      { label: "validation", snippet: '<NumberInputControl id="image-width" label="Image width" value={width} min={1} step={1} suffix="px" error={widthError} onValueChange={setWidth} />' },
    ],
  },
  "temporal-input-control": {
    import: `import { TemporalInputControl } from "emibs-ui-lib/components/primitives/TemporalInputControl";`,
    snippet: '<TemporalInputControl id="first-start" label="First start" type="datetime-local" value={firstStart} onValueChange={setFirstStart} />',
    variants: [
      { label: "date", snippet: '<TemporalInputControl id="license-date" label="License date" type="date" value={licenseDate} onValueChange={setLicenseDate} />' },
      { label: "time", snippet: '<TemporalInputControl id="check-in" label="Check-in time" type="time" value={checkInTime} step={900} density="compact" onValueChange={setCheckInTime} />' },
    ],
  },
  "text-input-control": {
    import: `import { TextInputControl } from "emibs-ui-lib/components/primitives/TextInputControl";`,
    snippet: '<TextInputControl id="summary-email" label="Summary email" type="email" value={email} onValueChange={setEmail} />',
    variants: [
      { label: "credential", snippet: '<TextInputControl id="access-key" label="Access key" value={accessKey} prefix="key" counter={`${accessKey.length}/64`} onValueChange={setAccessKey} />' },
      { label: "validation", snippet: '<TextInputControl id="website" label="Website" type="url" value={website} error={websiteError} onValueChange={setWebsite} />' },
    ],
  },
  "textarea-control": {
    import: `import { TextareaControl } from "emibs-ui-lib/components/primitives/TextareaControl";`,
    snippet: '<TextareaControl id="issue-description" label="Description" value={description} rows={5} onValueChange={setDescription} />',
    variants: [
      { label: "counter", snippet: '<TextareaControl id="public-bio" label="Public bio" value={bio} maxLength={280} counter={`${bio.length}/280`} onValueChange={setBio} />' },
      { label: "validation", snippet: '<TextareaControl id="prompt" label="Prompt" value={prompt} error={promptError} onValueChange={setPrompt} />' },
    ],
  },
  "description-list": {
    import: `import { DescriptionList } from "emibs-ui-lib/components/primitives/DescriptionList";`,
    snippet: `<DescriptionList items={[{ id: "license", label: "License", value: "LT-G-2041" }, { id: "country", label: "Country", value: "Lithuania" }]} />`,
    variants: [
      {
        label: "two columns",
        snippet: '<DescriptionList columns={2} items={[{ id: "license", label: "License", value: "LT-G-2041", tone: "success" }, { id: "country", label: "Country", value: "Lithuania" }]} />',
      },
      {
        label: "compact",
        snippet: '<DescriptionList density="compact" items={[{ id: "provider", label: "Provider", value: "Bokun" }, { id: "sync", label: "Last sync", value: "Just now", tone: "success" }]} />',
      },
    ],
  },
  "conditional-form-demo": {
    import: `import { FormPanel, useForm } from "emibs-ui-lib/forms";`,
    snippet: `<FormPanel form={form} sections={conditionalSections} onSubmit={saveTripRequest} />`,
    variants: [
      { label: "rules", snippet: 'useForm({ schema, rules: { guideLanguage: { visible: condition, required: true }, totalEstimate: { compute } } })' },
      { label: "dependent select", snippet: '<FormField name="activity">{(field) => <select value={field.value} onChange={field.onChange}>{options}</select>}</FormField>' },
    ],
  },
  "field-array-form-demo": {
    import: `import { ArrayField, Form, FormField, useForm } from "emibs-ui-lib/forms";`,
    snippet: `const form = useForm({ schema: lineItemsSchema, defaultValues: { lineItems: [{ description: "Design review", qty: 1, price: 125 }] } });\n<Form form={form} onSubmit={saveEstimate}>\n  <ArrayField form={form} name="lineItems" label="Line items" createItem={() => ({ description: "", qty: 1, price: 0 })}>\n    {({ name }) => (\n      <>\n        <FormField form={form} name={\`\${name}.description\`} label="Description" required />\n        <FormField form={form} name={\`\${name}.qty\`} label="Qty" type="number" required />\n        <FormField form={form} name={\`\${name}.price\`} label="Price" type="number" required />\n      </>\n    )}\n  </ArrayField>\n</Form>`,
    variants: [
      { label: "row defaults", snippet: '<ArrayField createItem={() => ({ description: "", qty: 1, price: 0 })} />' },
      { label: "keyboard reorder", snippet: '<ArrayField getFocusName={(rowName) => `${rowName}.description`} />' },
    ],
  },
  "form-wizard-demo": {
    import: `import { FormField, FormWizard, useForm, type WizardStep } from "emibs-ui-lib/forms";`,
    snippet: `<FormWizard form={form} steps={steps} onComplete={submitReview}>{({ step }) => renderStep(step)}</FormWizard>`,
    variants: [
      { label: "branching", snippet: 'const steps: WizardStep<FormValues>[] = [{ id: "traveller", fields: ["email"], next: (values) => values.business ? "company" : "review" }];' },
      { label: "review submit", snippet: '<FormWizard form={form} steps={steps} labels={{ finish: "Submit review" }} onComplete={submitReview} />' },
    ],
  },
  "action-group": {
    import: `import { ActionGroup } from "emibs-ui-lib/components/primitives/ActionGroup";`,
    snippet: `<ActionGroup align="between" label="Task actions"><Button variant="danger" onClick={deleteTask}>Delete task</Button><Button onClick={saveTask}>Save changes</Button></ActionGroup>`,
    variants: [
      { label: "stacked full width", snippet: '<ActionGroup fullWidth gap="md" label="Confirmation actions" orientation="column">{actions}</ActionGroup>' },
      { label: "card footer", snippet: '<ActionGroup align="end" orientation="row" label="Card actions">{actions}</ActionGroup>' },
    ],
  },
  card: {
    import: `import { Card, CardAction, CardBody, CardDescription, CardFooter, CardHeader, CardTitle } from "emibs-ui-lib/components/primitives/Card";`,
    snippet: `<Card>\n  <CardHeader>\n    <CardTitle>Delivery snapshot</CardTitle>\n    <CardDescription>Counts refresh from the product's own query.</CardDescription>\n    <CardAction><IconButton label="Refresh snapshot" icon={<RefreshCw size={16} />} onClick={refresh} /></CardAction>\n  </CardHeader>\n  <CardBody>{summary}</CardBody>\n  <CardFooter><Button size="sm" onClick={openTask}>Open task</Button></CardFooter>\n</Card>`,
    variants: [
      { label: "header and body", snippet: '<Card><CardHeader><CardTitle>Delivery snapshot</CardTitle></CardHeader><CardBody>{summary}</CardBody></Card>' },
      { label: "body only", snippet: '<Card><CardBody>{content}</CardBody></Card>' },
    ],
  },
  "combobox-field": {
    import: `import { ComboboxField } from "emibs-ui-lib/components/primitives/ComboboxField";`,
    snippet: `<ComboboxField id="assigned-agent" label="Assigned agent" value={agent} options={agentOptions} onValueChange={setAgent} onClear={() => setAgent("")} />`,
    variants: [
      { label: "compact", snippet: '<ComboboxField id="parent-epic" label="Parent epic" value={epic} density="compact" options={epicOptions} onValueChange={setEpic} />' },
      { label: "validation", snippet: '<ComboboxField id="language" label="Language" value={language} required options={languageOptions} error={languageError} onValueChange={setLanguage} />' },
    ],
  },
  "contact-link-list": {
    import: `import { ContactLinkList } from "emibs-ui-lib/components/primitives/ContactLinkList";`,
    snippet: `<ContactLinkList label="Accommodation contact links" items={contactItems} />`,
    variants: [
      { label: "plain compact", snippet: '<ContactLinkList label="Contact links" items={contactItems} variant="plain" density="compact" />' },
      { label: "empty", snippet: '<ContactLinkList label="Contact links" items={[]} emptyLabel="Contact details are available after booking." />' },
    ],
  },
  "content-tabs": {
    import: `import { ContentTabs } from "emibs-ui-lib/components/primitives/ContentTabs";`,
    snippet: `<ContentTabs ariaLabel="Article categories" activeId={category} tabs={categoryTabs} panelId="category-panel" onTabChange={(tab) => setCategory(tab.id)}>{panel}</ContentTabs>`,
    variants: [
      { label: "contained compact", snippet: '<ContentTabs ariaLabel="Component sections" activeId={section} tabs={sectionTabs} variant="contained" density="compact" onTabChange={(tab) => setSection(tab.id)} />' },
      { label: "routed links", snippet: '<ContentTabs ariaLabel="Component sections" activeId="overview" tabs={[{ id: "overview", label: "Overview", href: "#/c/content-tabs" }]} />' },
    ],
  },
  field: {
    import: `import { Field, Input } from "emibs-ui-lib/components/primitives/Field";`,
    snippet: `<Field id="display-name" label="Display name" required hint="Shown on the public profile."><Input name="displayName" value={name} onChange={handleNameChange} /></Field>`,
    variants: [
      { label: "validation", snippet: '<Field id="website" label="Website" error={websiteError}><Input name="website" type="url" value={website} onChange={handleWebsiteChange} /></Field>' },
      { label: "optional select", snippet: '<Field id="provider" label="Provider" optional wide><Select name="provider" value={provider} onChange={handleProviderChange}>{providerOptions}</Select></Field>' },
    ],
  },
  "floating-label-field": {
    import: `import { FloatingLabelField } from "emibs-ui-lib/components/primitives/FloatingLabelField";`,
    snippet: `<FloatingLabelField id="project-name" label="Project name" value={name} required meta="Controlled" onChange={setName} />`,
    variants: [
      { label: "search with leading icon", snippet: '<FloatingLabelField id="score-search" label="Score search" type="search" value={query} leading={<Search size={16} aria-hidden="true" />} onChange={setQuery} />' },
      { label: "validation", snippet: '<FloatingLabelField id="billing-email" label="Billing email" type="email" value={email} error={emailError} density="compact" onChange={setEmail} />' },
    ],
  },
  "icon-input-field": {
    import: `import { IconInputField } from "emibs-ui-lib/components/primitives/IconInputField";`,
    snippet: `<IconInputField id="secret-key" label="Secret key" type="password" icon={<KeyRound size={16} />} action={<Button size="sm" variant="ghost" onClick={toggleReveal}>Reveal</Button>} value={secret} onChange={handleSecretChange} />`,
    variants: [
      { label: "compact validation", snippet: '<IconInputField id="website" label="Website" icon={<Globe2 size={16} />} density="compact" error="Use an https URL for public links." value={website} onChange={handleWebsiteChange} />' },
      { label: "hidden label", snippet: '<IconInputField id="filter" label="Filter rows" hideLabel icon={<Search size={16} />} placeholder="Filter rows" value={filter} onChange={handleFilterChange} />' },
    ],
  },
  "info-chip-list": {
    import: `import { InfoChipList } from "emibs-ui-lib/components/primitives/InfoChipList";`,
    snippet: `<InfoChipList label="Guide languages" items={languageChips} />`,
    variants: [
      { label: "linked chips", snippet: '<InfoChipList label="Route regions" items={[{ id: "vilnius", label: "Vilnius", href: "/regions/vilnius", tone: "accent" }]} />' },
      { label: "empty", snippet: '<InfoChipList label="Routes" items={[]} emptyLabel="Routes are available on request." density="compact" />' },
    ],
  },
  "payload-block": {
    import: `import { PayloadBlock } from "emibs-ui-lib/components/primitives/PayloadBlock";`,
    snippet: `<PayloadBlock label="last run" language="bash" payload={runLog} status="exit 0" statusTone="success" copied={copied} onCopy={copyRunLog} />`,
    variants: [
      { label: "collapsible json", snippet: '<PayloadBlock collapsible defaultCollapsed title="Subscription payload" language="json" payload={payloadJson} wrap density="compact" />' },
      { label: "bare payload", snippet: '<PayloadBlock payload="npm run build" variant="plain" />' },
    ],
  },
  "status-indicator": {
    import: `import { StatusIndicator } from "emibs-ui-lib/components/primitives/StatusIndicator";`,
    snippet: `<StatusIndicator label="Provider reachable" detail="Last checked a moment ago." tone="success" />`,
    variants: [
      { label: "bar with action", snippet: '<StatusIndicator label="Sync failed" detail="The last three syncs failed." tone="danger" variant="bar" action={<Button size="sm" variant="ghost" onClick={retry}>Retry</Button>} />' },
      { label: "compact pill", snippet: '<StatusIndicator label="Pending review" tone="warning" variant="pill" size="sm" />' },
    ],
  },
  "tag-input": {
    import: `import { TagInput } from "emibs-ui-lib/components/primitives/TagInput";`,
    snippet: `<TagInput label="Blocked by" value={draft} tags={references} suggestions={issueSuggestions} onValueChange={setDraft} onAdd={addReference} onRemove={removeReference} />`,
    variants: [
      { label: "validation", snippet: '<TagInput label="Blocked by" value={draft} tags={references} required error={referenceError} onValueChange={setDraft} onAdd={addReference} onRemove={removeReference} />' },
      { label: "locked list", snippet: '<TagInput label="Blocked by" value="" tags={references} disabled emptyLabel="No references." />' },
    ],
  },
  "theme-mode-toggle": {
    import: `import { ThemeModeToggle, type ThemeModeToggleMode } from "emibs-ui-lib/components/primitives/ThemeModeToggle";`,
    snippet: `<ThemeModeToggle mode={mode} nextMode={nextMode} showLabel onModeChange={setMode} />`,
    variants: [
      { label: "three-way cycle", snippet: 'const nextMode = mode === "system" ? "light" : mode === "light" ? "dark" : "system";' },
      { label: "compact ghost", snippet: '<ThemeModeToggle mode={mode} density="compact" variant="ghost" onModeChange={setMode} />' },
    ],
  },
  "empty-state": {
    import: `import { EmptyState } from "emibs-ui-lib/components/primitives/EmptyState";`,
    snippet: '<EmptyState title="Preview pending">No content is available yet.</EmptyState>',
    variants: [
      { label: "with action", snippet: '<EmptyState icon={<Database size={22} />} title="No records" action={<Button size="sm">Create record</Button>}>Connect a source to populate the view.</EmptyState>' },
      { label: "compact", snippet: '<EmptyState density="compact" icon={<Database size={22} />} title="No records">Compact density keeps the empty hint inside an existing surface.</EmptyState>' },
    ],
  },
};
