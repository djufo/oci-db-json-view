import type { UsageSnippet } from "../types";

export const layoutUsages: Record<string, UsageSnippet> = {
  "app-shell": {
    import: `import { AppShell, type NavItem } from "emibs-ui-lib/components/layout/AppShell";`,
    snippet: `<AppShell brand={<BrandImageLink href="/" label="Open home" desktopImage={logo} />} nav={sections.map((section) => ({ label: section.label, href: section.href, icon: section.icon, active: section.href === currentHref }))} actions={<Button size="sm" onClick={refresh}>Refresh</Button>}>
  <RouteContent />
</AppShell>`,
    variants: [
      { label: "hash-router active", snippet: '<AppShell brand={brand} nav={navItems.map((item) => ({ ...item, active: item.href === hash }))}>{route}</AppShell>' },
      { label: "no action bar content", snippet: '<AppShell brand={<strong>emibs-ui-lib</strong>} nav={navItems}>{route}</AppShell>' },
    ],
  },
  "brand-image-link": {
    import: `import { BrandImageLink, type BrandImageSource } from "emibs-ui-lib/components/layout/BrandImageLink";`,
    snippet: `<BrandImageLink href="/" label="Open eLitua home" desktopImage={brandImageDesktop} mobileImage={brandImageMobile} title="eLitua" subtitle="Lithuanian tourism portal" />`,
    variants: [
      { label: "mark only", snippet: '<BrandImageLink href="/" label="Open eLitua home" desktopImage={brandImageDesktop} />' },
      { label: "external site", snippet: '<BrandImageLink href="https://elitua.lt" label="Open elitua.lt" desktopImage={brandImageDesktop} external onClick={trackBrandClick} />' },
    ],
  },
  "editorial-article-page": {
    import: `import { EditorialArticlePage } from "emibs-ui-lib/components/layout/EditorialArticlePage";`,
    snippet: `<EditorialArticlePage backHref="/blog" backLabel="Blog" category={article.category} title={article.title} subtitle={article.standfirst} author={author} meta={meta} hero={{ src: article.heroSrc, alt: article.heroAlt }} toc={toc} activeTocId={activeHeadingId} sections={sections} tags={article.tags} shareActions={shareActions} related={related} />`,
    variants: [
      { label: "observer-driven TOC", snippet: '<EditorialArticlePage title={article.title} toc={toc} activeTocId={activeHeadingId} sections={sections} />' },
      { label: "gated preview", snippet: '<EditorialArticlePage title={article.title} sections={preview} paywall={{ title: "Continue reading", description: "Subscriber access is checked by the app.", action: <Button onClick={subscribe}>Subscribe</Button> }} />' },
    ],
  },
  "editorial-listing-page": {
    import: `import { EditorialListingPage } from "emibs-ui-lib/components/layout/EditorialListingPage";`,
    snippet: `<EditorialListingPage eyebrow="Lithuania travel journal" title="Discover Lithuania" subtitle={hub.lead} categories={categories.map((category) => ({ ...category, active: category.id === categoryId, onClick: () => setCategoryId(category.id) }))} featured={featured} articles={articles} articlesTitle="Latest articles" />`,
    variants: [
      { label: "callback categories", snippet: '<EditorialListingPage title="Discover Lithuania" categories={categories.map((category) => ({ ...category, active: category.id === categoryId, onClick: () => setCategoryId(category.id) }))} articles={articles} />' },
      { label: "URL-owned categories", snippet: '<EditorialListingPage title="Discover Lithuania" categories={categories.map((category) => ({ ...category, href: `/blog/${category.id}`, active: category.id === params.category }))} articles={articles} />' },
    ],
  },
  "explorer-workspace": {
    import: `import { ExplorerWorkspace, type ExplorerView } from "emibs-ui-lib/components/layout/ExplorerWorkspace";`,
    snippet: `<ExplorerWorkspace views={views} activeView={view} onViewChange={setView} controls={<SearchField id="explorer-search" label="Search" value={query} onValueChange={setQuery} />} filters={<EntityFilterPanel {...filterProps} />} detail={selected ? <RecordDetailPanel record={selected} /> : undefined} loading={isLoading} error={error} onDismissError={() => setError(null)}>
  <ResultsView records={records} />
</ExplorerWorkspace>`,
    variants: [
      { label: "local state", snippet: '<ExplorerWorkspace views={views} activeView={view} onViewChange={setView}>{content}</ExplorerWorkspace>' },
      { label: "URL-owned view", snippet: '<ExplorerWorkspace views={views} activeView={viewFromQuery} onViewChange={(next) => navigate(hrefWithView(next))}>{content}</ExplorerWorkspace>' },
    ],
  },
  "legal-document-page": {
    import: `import { LegalDocumentPage } from "emibs-ui-lib/components/layout/LegalDocumentPage";`,
    snippet: `<LegalDocumentPage eyebrow="Legal information" title={t("privacy.title")} subtitle={t("privacy.scope")} meta={documentMeta} summary={{ title: "Service provider", tone: "info", children: controllerCopy }} blocks={blocks} contact={{ title: "Questions about this document?", actions: <a href="mailto:info@example.lt">Contact</a> }} />`,
    variants: [
      { label: "short notice", snippet: '<LegalDocumentPage title="Cookie notice" blocks={cookieBlocks} />' },
      { label: "with consent controls", snippet: '<LegalDocumentPage title="Cookie notice" blocks={cookieBlocks} contact={contact}><CookiePreferenceForm value={consent} onChange={setConsent} /></LegalDocumentPage>' },
    ],
  },
  "map-viewport": {
    import: `import { MapViewport } from "emibs-ui-lib/components/layout/MapViewport";`,
    snippet: `<MapViewport title="Lithuania discovery map" stats={mapStats} actions={<Button size="sm" variant="secondary" onClick={fitRoute}>Fit route</Button>} infoPanel={selected ? <MapInfoCard record={selected} /> : undefined} loading={isLoading} error={error} onDismissError={() => setError(null)}>
  <Map defaultZoom={7} defaultCenter={center} />
</MapViewport>`,
    variants: [
      { label: "real map engine", snippet: '<MapViewport title="Places" stats={mapStats}><Map defaultZoom={7} defaultCenter={center} /></MapViewport>' },
      { label: "static preview", snippet: '<MapViewport title="Lithuania discovery map" titleMode="transient" stats={mapViewportStats} markers={mapViewportMarkers} />' },
    ],
  },
  "navigation-menu": {
    import: `import { NavigationMenu, type NavigationMenuGroup } from "emibs-ui-lib/components/layout/NavigationMenu";`,
    snippet: `<NavigationMenu ariaLabel="Portal menu" groups={visibleGroups} onItemSelect={() => setMenuOpen(false)} />`,
    variants: [
      { label: "grouped sidebar", snippet: '<NavigationMenu ariaLabel="Portal menu" groups={navigationMenuGroups} onItemSelect={closeMenu} />' },
      { label: "horizontal header row", snippet: '<NavigationMenu ariaLabel="Header navigation" items={headerItems} layout="horizontal" density="compact" showDividers={false} />' },
    ],
  },
  "portal-footer": {
    import: `import { PortalFooter } from "emibs-ui-lib/components/layout/PortalFooter";`,
    snippet: `<PortalFooter brand={<a href="/">eLitua</a>} links={footerLinks} actions={<ThemeModeToggle mode={mode} onModeChange={setMode} />} copyright={\`\${year} eLitua\`} />`,
    variants: [
      { label: "paired with mobile nav", snippet: '<PortalFooter brand={brand} links={footerLinks} copyright={copyright} />' },
      { label: "always visible", snippet: '<PortalFooter brand={brand} links={footerLinks} visibility="always" copyright={copyright} />' },
    ],
  },
  "portal-header": {
    import: `import { PortalHeader } from "emibs-ui-lib/components/layout/PortalHeader";`,
    snippet: `<PortalHeader brand={<BrandImageLink href="/" label="Open home" desktopImage={logo} />} nav={navItems.map((item) => ({ ...item, active: item.href === pathname }))} search={{ value: query, placeholder: "Search stays, guides, regions", label: "Search tourism records", onChange: setQuery, onSubmit: runSearch }} utilityActions={utilityActions} identity={<AccountMenu {...accountProps} />} menuOpen={menuOpen} onMenuToggle={() => setMenuOpen((open) => !open)} />`,
    variants: [
      { label: "with menu toggle", snippet: '<PortalHeader brand={brand} nav={navItems} menuOpen={menuOpen} onMenuToggle={() => setMenuOpen((open) => !open)} />' },
      { label: "read-only search", snippet: '<PortalHeader brand={brand} nav={navItems} search={{ value: query, placeholder: "Search", label: "Search tourism records" }} />' },
    ],
  },
  "portal-info-page": {
    import: `import { PortalInfoPage } from "emibs-ui-lib/components/layout/PortalInfoPage";`,
    snippet: `<PortalInfoPage eyebrow={t("about.eyebrow")} title={t("about.title")} lead={t("about.lead")} heroImage={{ src: about.bannerSrc, alt: about.bannerAlt }} stats={portalInfoStats} sections={portalInfoSections} mission={t("about.mission")} author={portalInfoAuthor} />`,
    variants: [
      { label: "identity-led about page", snippet: '<PortalInfoPage title={t("about.title")} heroImage={banner} stats={portalInfoStats} sections={portalInfoSections} author={portalInfoAuthor} />' },
      { label: "text-only trust page", snippet: '<PortalInfoPage eyebrow="Trust" title="How we handle tourism data" lead={lead} sections={trustSections} footer={<a href="/privacy">Privacy policy</a>} />' },
    ],
  },
  "portal-landing-page": {
    import: `import { PortalLandingPage } from "emibs-ui-lib/components/layout/PortalLandingPage";`,
    snippet: `<PortalLandingPage eyebrow="Lithuania travel" title={t("home.title")} subtitle={t("home.subtitle")} heroImage={{ src: hero.src, alt: hero.alt }} actions={<Button onClick={openMap}>Explore map</Button>} stats={portalLandingStats} heroHighlights={portalLandingHighlights} intentTitle="Choose your route" intents={portalLandingIntents} featuredTitle="Featured places" features={portalLandingFeatures} planner={{ ...portalLandingPlanner, action: <Button size="sm" onClick={plan}>Plan</Button> }} />`,
    variants: [
      { label: "hero + intents", snippet: '<PortalLandingPage title={t("home.title")} heroImage={hero} stats={portalLandingStats} intentTitle="Choose your route" intents={portalLandingIntents} />' },
      { label: "featured + planner rail", snippet: '<PortalLandingPage title={t("home.title")} heroImage={hero} featuredTitle="Featured places" features={portalLandingFeatures} planner={{ ...portalLandingPlanner, action: plannerAction }} quote={{ text: quote, attribution: "eLitua editorial desk" }} />' },
    ],
  },
  "portal-mobile-navigation": {
    import: `import { PortalMobileNavigation } from "emibs-ui-lib/components/layout/PortalMobileNavigation";`,
    snippet: `<PortalMobileNavigation items={mobileItems.map((item) => ({ ...item, active: item.href === pathname }))} sheetGroups={sheetGroups} sheetFooter={<Button variant="secondary" size="sm" onClick={() => setSheetOpen(false)}>Done</Button>} sheetOpen={sheetOpen} onSheetOpenChange={setSheetOpen} />`,
    variants: [
      { label: "dock only", snippet: '<PortalMobileNavigation items={mobileItems.map((item) => ({ ...item, active: item.href === pathname }))} />' },
      { label: "contained review dock", snippet: '<PortalMobileNavigation dock="contained" items={portalMobileItems} sheetGroups={portalMobileGroups} sheetOpen={sheetOpen} onSheetOpenChange={setSheetOpen} />' },
    ],
  },
  "portal-shell": {
    import: `import { PortalShell } from "emibs-ui-lib/components/layout/PortalShell";`,
    snippet: `<PortalShell header={<PortalHeader {...headerProps} menuOpen={menuOpen} onMenuToggle={() => setMenuOpen((open) => !open)} />} sidebar={<NavigationMenu ariaLabel="Portal menu" groups={menuGroups} onItemSelect={() => setMenuOpen(false)} />} sidebarOpen={menuOpen} onSidebarOpenChange={setMenuOpen} footer={<PortalFooter {...footerProps} />} mobileNavigation={<PortalMobileNavigation {...mobileProps} />}>
  <Outlet />
</PortalShell>`,
    variants: [
      { label: "centered content route", snippet: '<PortalShell header={header} footer={footer} sidebar={menu} sidebarOpen={menuOpen} onSidebarOpenChange={setMenuOpen}>{route}</PortalShell>' },
      { label: "full-width map route", snippet: '<PortalShell layout="full" header={header} mobileNavigation={mobileNav}>{explorer}</PortalShell>' },
    ],
  },
  "public-profile-page": {
    import: `import { PublicProfilePage } from "emibs-ui-lib/components/layout/PublicProfilePage";`,
    snippet: `<PublicProfilePage eyebrow="Licensed guide" title={guide.name} subtitle={guide.summary} avatar={initials} avatarLabel={\`\${guide.name} profile avatar\`} badges={badges} contactActions={contactActions} primaryAction={{ id: "request-route", label: "Request route", href: \`/guides/\${guide.slug}/request\` }} stats={stats} panels={panels} />`,
    variants: [
      { label: "URL-owned actions", snippet: '<PublicProfilePage title={guide.name} primaryAction={{ id: "request-route", label: "Request route", href: requestHref }} panels={panels} />' },
      { label: "callback actions", snippet: '<PublicProfilePage title={guide.name} primaryAction={{ id: "request-route", label: "Request route", onClick: openBookingDialog }} panels={panels} aside={<AvailabilityCard {...availability} />} />' },
    ],
  },
  "section-card": {
    import: `import { SectionCard } from "emibs-ui-lib/components/layout/SectionCard";`,
    snippet: `<SectionCard title="Credentials" eyebrow="Guide profile" description="Verification state is product-owned." badges={[{ id: "verified", label: "verified", tone: "success" }]} actions={<Button size="sm" variant="secondary" onClick={edit}>Edit</Button>}>
  <DescriptionList items={credentialRows} />
</SectionCard>`,
    variants: [
      { label: "uncontrolled disclosure", snippet: '<SectionCard collapsible defaultCollapsed title="Runtime settings">{settings}</SectionCard>' },
      { label: "controlled disclosure", snippet: '<SectionCard collapsible collapsed={collapsed} onCollapsedChange={setCollapsed} title="Runtime settings">{settings}</SectionCard>' },
    ],
  },
  "workspace-page-frame": {
    import: `import { WorkspacePageFrame } from "emibs-ui-lib/components/layout/WorkspacePageFrame";`,
    snippet: `<WorkspacePageFrame layout={layoutForRoute(route)} ariaLabel={route.label}>
  <RouteContent route={route} />
</WorkspacePageFrame>`,
    variants: [
      { label: "route-mapped layout", snippet: '<WorkspacePageFrame layout={layoutForRoute(route)}>{routeContent}</WorkspacePageFrame>' },
      { label: "bounded object route", snippet: '<WorkspacePageFrame layout="object" objectMaxHeight="calc(100vh - 12rem)" ariaLabel="Task detail">{objectRoute}</WorkspacePageFrame>' },
    ],
  },
  "workspace-shell": {
    import: `import { WorkspaceShell, WorkspaceShellPanel } from "emibs-ui-lib/components/layout/WorkspaceShell";`,
    snippet: `<WorkspaceShell brand="Score" subtitle="Authenticated operator shell" status={<StatusStrip items={liveSignals} />} identity={<AccountMenu {...accountProps} />} actions={<Button size="sm" onClick={refresh}>Refresh</Button>} tabs={tabs.map((tab) => ({ ...tab, active: tab.href === hash }))}>
  <WorkspacePageFrame layout="board">{routeContent}</WorkspacePageFrame>
</WorkspaceShell>`,
    variants: [
      { label: "URL-owned tabs", snippet: '<WorkspaceShell brand="Score" tabs={tabs.map((tab) => ({ ...tab, active: tab.href === hash }))}>{routeContent}</WorkspaceShell>' },
      { label: "tabless embed", snippet: '<WorkspaceShell brand="Score" subtitle="Read-only mirror" status={<StatusIndicator label="Live" tone="success" size="sm" />}>{routeContent}</WorkspaceShell>' },
    ],
  },
  "inspector-rail": {
    import: `import { InspectorRail } from "emibs-ui-lib/components/layout/InspectorRail";`,
    snippet: `<InspectorRail targetId="issue-2098" eyebrow="issue" title="Wire chat board bridge" tabs={tabs} activeTab={tab} tabHref={(id) => hashWithInspectTab(hash, id)} closeHref={hashWithInspect(hash, null)} />`,
    variants: [
      { label: "callback-driven", snippet: '<InspectorRail targetId={id} title={title} tabs={tabs} activeTab={tab} onTabChange={setTab} onClose={close} />' },
      { label: "URL-owned", snippet: '<InspectorRail targetId={id} title={title} tabs={tabs} activeTab={tab} tabHref={(t) => hashWithInspectTab(hash, t)} closeHref={hashWithInspect(hash, null)} />' },
    ],
  },
  "page-header": {
    import: `import { PageHeader } from "emibs-ui-lib/components/layout/PageHeader";`,
    snippet: `<PageHeader title="UI Framework" description="Review shared route chrome." status="ready" statusTone="success" actions={actions} />`,
    variants: [
      { label: "score route", snippet: '<PageHeader title="UI Framework" status="processing" meta={meta} actions={actions} />' },
      { label: "elitua account", snippet: '<PageHeader title="Guide profile" back={{ label: "Account", href: accountHref }} badges={badges} />' },
      { label: "compact admin", snippet: '<PageHeader density="compact" level={2} title="Payments" status="requires review" />' },
    ],
  },
  "status-strip": {
    import: `import { StatusStrip } from "emibs-ui-lib/components/layout/StatusStrip";`,
    snippet: `<StatusStrip ariaLabel="Live activity status" items={[{ id: "refresh", label: "Manual refresh", value: "ready", tone: "info", variant: "badge" }, { id: "ready", label: "Ready", value: readyCount, detail: "queued", tone: "success" }]} />`,
    variants: [
      { label: "badge", snippet: '<StatusStrip items={[{ id: "refresh", label: "Manual refresh", value: "ready", tone: "info", variant: "badge" }]} />' },
      { label: "metric", snippet: '<StatusStrip items={[{ id: "errors", label: "Errors", value: 0, detail: "last hour", tone: "danger" }]} />' },
    ],
  },
  "table-of-contents-nav": {
    import: `import { TableOfContentsNav } from "emibs-ui-lib/components/layout/TableOfContentsNav";`,
    snippet: `<TableOfContentsNav items={tocItems} activeItemId={activeHeadingId} />`,
    variants: [
      { label: "plain compact", snippet: '<TableOfContentsNav items={tocItems} activeItemId={activeHeadingId} density="compact" title="On this page" />' },
      { label: "with meta", snippet: '<TableOfContentsNav items={tocItemsWithMeta} activeItemId="overview" />' },
    ],
  },
};
