import type { UsageSnippet } from "../types";

export const templateUsages: Record<string, UsageSnippet> = {
  "app-frame": {
    import: 'import { AppFrame } from "emibs-ui-lib/components/layout/AppFrame";',
    snippet: `<AppFrame storageKey="my-app" defaultDensity="compact">
  <WorkspaceShell brand="My app" tabs={tabs} actions={<AppearanceControls />}>
    {page}
  </WorkspaceShell>
</AppFrame>`,
    variants: [
      { label: "fixed brand", snippet: '<AppFrame storageKey="my-app" families={[brandFamily]}>{app}</AppFrame>' },
      { label: "follow the OS", snippet: '<AppFrame storageKey="my-app" defaultMode="system">{app}</AppFrame>' },
    ],
  },
  "appearance-controls": {
    import: 'import { AppearanceControls } from "emibs-ui-lib/components/layout/AppearanceControls";',
    snippet: "<AppearanceControls />",
    variants: [
      { label: "with density", snippet: "<AppearanceControls showDensity />" },
      { label: "own state", snippet: "<AppearanceControls appearance={appearance} />" },
    ],
  },
  "sign-in-page": {
    import: 'import { SignInPage } from "emibs-ui-lib/components/layout/SignInPage";',
    snippet: `<SignInPage
  eyebrow="My app"
  title="Sign in"
  description="Use your workspace account."
  notice={error ? <NoticeBanner tone="danger">{error}</NoticeBanner> : undefined}
  corner={<AppearanceControls />}
>
  <form onSubmit={signIn}>{fields}</form>
</SignInPage>`,
    variants: [{ label: "provider button", snippet: '<SignInPage title="Sign in">{googleButton}</SignInPage>' }],
  },
  "page-scaffold": {
    import: 'import { PageColumns, PageScaffold } from "emibs-ui-lib/components/layout/PageScaffold";',
    snippet: `<PageScaffold
  header={<PageHeader title="Jobs" actions={newJob} />}
  toolbar={filters}
  state={loading ? { kind: "loading", title: "Loading jobs" } : error ? { kind: "error", title: "Jobs could not be loaded", action: retry } : null}
  footer={<Pager page={page} total={pages} onPageChange={setPage} />}
>
  <DataTable data={jobs} columns={columns} />
</PageScaffold>`,
    variants: [
      { label: "form page", snippet: '<PageScaffold width="narrow" header={<PageHeader title="New job" />}>{form}</PageScaffold>' },
      { label: "detail with columns", snippet: '<PageScaffold header={header}><PageColumns layout="aside-main">{facts}{body}</PageColumns></PageScaffold>' },
    ],
  },
};
