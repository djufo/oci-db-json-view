import type { UsageSnippet } from "../types";

export const feedbackUsages: Record<string, UsageSnippet> = {
  "alert-lane": {
    import: `import { AlertLane } from "emibs-ui-lib/components/feedback/AlertLane";`,
    snippet: `<AlertLane alerts={findings} onDismiss={dismiss} dismissedIds={dismissed} />`,
    variants: [
      { label: "per-session (uncontrolled)", snippet: '<AlertLane alerts={findings} />' },
      { label: "custom deep link", snippet: '<AlertLane alerts={findings} renderLink={(a) => <Link to={a.route}>Resolve</Link>} />' },
    ],
  },
  "confirmation-dialog": {
    import: `import { ConfirmationDialog } from "emibs-ui-lib/components/feedback/ConfirmationDialog";`,
    snippet: `<ConfirmationDialog open={confirming} title="Delete attachment?" tone="danger" busy={deleting} confirmLabel="Delete" onConfirm={commitDelete} onCancel={close}>This cannot be undone.</ConfirmationDialog>`,
    variants: [
      { label: "contained review", snippet: '<ConfirmationDialog open placement="contained" title="Apply release setting?" confirmLabel="Apply" onConfirm={commit} onCancel={close} />' },
      { label: "pending write", snippet: '<ConfirmationDialog open busy busyLabel="Deleting…" title="Delete attachment?" confirmLabel="Delete" onConfirm={commit} onCancel={close} />' },
    ],
  },
  "blast-radius-confirm": {
    import: `import { BlastRadiusConfirm, blastRadius } from "emibs-ui-lib/components/feedback/BlastRadiusConfirm";`,
    snippet: `const impact = poolDisableBlastRadius(pool, lanes);\n<BlastRadiusConfirm open={confirming} impact={impact} confirmLabel="Disable pool" pending={saving} error={serverError} onConfirm={commit} onCancel={close} />`,
    variants: [
      { label: "server error", snippet: '<BlastRadiusConfirm open impact={impact} confirmLabel="Disable pool" error="403: subscription owner mismatch" onConfirm={commit} onCancel={close} />' },
      { label: "contained review", snippet: '<BlastRadiusConfirm open placement="contained" impact={impact} confirmLabel="Re-band" onConfirm={commit} onCancel={close} />' },
    ],
  },
  "alert-dialog-frame": {
    import: `import { AlertDialogFrame } from "emibs-ui-lib/components/feedback/AlertDialogFrame";`,
    snippet: `<AlertDialogFrame open={open} title="Apply workflow transition?" description="Confirm this route-owned action." footer={actions} onClose={close} />`,
    variants: [
      { label: "contained review", snippet: '<AlertDialogFrame open placement="contained" title="Review action" footer={actions} onClose={close} />' },
      { label: "compact", snippet: '<AlertDialogFrame open size="sm" media={icon} title="Discard changes?" footer={actions} onClose={close} />' },
    ],
  },
  "cookie-consent-banner": {
    import: `import { CookieConsentBanner } from "emibs-ui-lib/components/feedback/CookieConsentBanner";`,
    snippet: `<CookieConsentBanner title="Cookie notice" description="We use cookies to improve the portal." rejectLabel="Essential only" showManageAction={false} tone="inverse" />`,
    variants: [
      {
        label: "managed preferences",
        snippet: `<CookieConsentBanner title="We use cookies" description="Optional categories can be controlled by the app." categories={categories} preferencesOpen={open} onPreferencesOpenChange={setOpen} />`,
      },
      {
        label: "simple essential-only",
        snippet: `<CookieConsentBanner title="Cookie notice" description="We use cookies to improve the portal." rejectLabel="Essential only" showManageAction={false} tone="inverse" />`,
      },
    ],
  },
  "dialog-frame": {
    import: `import { DialogFrame } from "emibs-ui-lib/components/feedback/DialogFrame";`,
    snippet: `<DialogFrame open={open} title="Task detail" subtitle="Product-owned task content." status="processing" statusTone="warning" onClose={close}>{taskContent}</DialogFrame>`,
    variants: [
      { label: "contained review", snippet: '<DialogFrame open placement="contained" title="Preview frame" onClose={() => undefined}>{content}</DialogFrame>' },
      { label: "wide detail", snippet: '<DialogFrame open size="xl" title="Task detail" actions={actions} footer={footer} onClose={close}>{content}</DialogFrame>' },
    ],
  },
  "validation-error-ux-demo": {
    import: `import { FormPanel, FormSubmissionError, useForm } from "emibs-ui-lib/forms";\nimport { ValidationSummary } from "emibs-ui-lib/components/feedback/ValidationSummary";`,
    snippet: `<FormPanel form={form} onInvalid={showSummary} onSubmit={submit}>{summary ? <ValidationSummary items={errors} /> : null}</FormPanel>`,
    variants: [
      { label: "timing", snippet: 'useForm({ schema, mode: "onSubmit", reValidateMode: "onChange" })' },
      { label: "server 422", snippet: 'throw new FormSubmissionError({ formError: "Rejected", fieldErrors: { email: "Already used" } })' },
    ],
  },
  "creation-dialog": {
    import: `import { CreationDialog } from "emibs-ui-lib/components/feedback/CreationDialog";`,
    snippet: `<CreationDialog open={creating} title="New issue" eyebrow="Board" sections={sections} submitting={saving} submittingLabel="Creating…" submitDisabled={!draft.title} onClose={close} onSubmit={handleSubmit} />`,
    variants: [
      { label: "pending write", snippet: '<CreationDialog open submitting submittingLabel="Creating…" title="New issue" sections={sections} onClose={close} onSubmit={handleSubmit} />' },
      { label: "contained review", snippet: '<CreationDialog open placement="contained" title="New issue" sections={sections} onClose={close} onSubmit={handleSubmit} />' },
    ],
  },
  "data-state-panel": {
    import: `import { DataStatePanel } from "emibs-ui-lib/components/feedback/DataStatePanel";`,
    snippet: `<DataStatePanel tone={error ? "danger" : "loading"} title={error ? "Could not load settings" : "Loading settings"} description={error ?? "Fetching the latest runtime settings."} actions={error ? <Button onClick={retry}>Try again</Button> : undefined} />`,
    variants: [
      { label: "empty result", snippet: '<DataStatePanel tone="empty" title="Nothing here yet" description="No records match the current filters." actions={<Button onClick={create}>Create the first record</Button>} />' },
      { label: "compact inline", snippet: '<DataStatePanel tone="warning" density="compact" align="start" title="Partial import" description="3 rows were skipped." />' },
    ],
  },
  "notice-banner": {
    import: `import { NoticeBanner } from "emibs-ui-lib/components/feedback/NoticeBanner";`,
    snippet: `<NoticeBanner tone="warning" title="Capacity is close to its ceiling" action={<Button variant="secondary" onClick={review}>Review</Button>} onDismiss={dismiss}>Two lanes are queued behind the current subscription band.</NoticeBanner>`,
    variants: [
      { label: "compact info", snippet: '<NoticeBanner tone="info" density="compact" title="Scheduled maintenance">Read-only between 02:00 and 02:30 UTC.</NoticeBanner>' },
      { label: "forced live region", snippet: '<NoticeBanner tone="success" role="alert" live="assertive" title="Settings saved" />' },
    ],
  },
  "notification-toggle": {
    import: `import { NotificationToggle } from "emibs-ui-lib/components/feedback/NotificationToggle";`,
    snippet: `<NotificationToggle subscribed={subscribed} busy={saving} status={\`\${subscriberCount} subscribers\`} onChange={persistSubscription} />`,
    variants: [
      { label: "compact header action", snippet: '<NotificationToggle density="compact" subscribed={subscribed} onChange={persistSubscription} />' },
      { label: "gated by permission", snippet: '<NotificationToggle disabled subscribed={false} unsubscribedDescription="Email delivery is not configured for this workspace." />' },
    ],
  },
  "notification-bell": {
    import: `import { NotificationBell } from "emibs-ui-lib/components/feedback/NotificationBell";`,
    snippet: `<NotificationBell unreadCount={unreadCount} open={panelOpen} controlsId="activity-center" onClick={() => setPanelOpen((value) => !value)} />`,
    variants: [
      { label: "modal panel", snippet: '<NotificationBell haspopup="dialog" unreadCount={unreadCount} open={panelOpen} controlsId="activity-center" onClick={toggle} />' },
      { label: "localized label", snippet: '<NotificationBell size="sm" unreadCount={unreadCount} label={(count, open) => t("bell", { count, open })} onClick={toggle} />' },
    ],
  },
  "activity-center": {
    import: `import { ActivityCenter } from "emibs-ui-lib/components/feedback/ActivityCenter";\nimport { useNotifications } from "emibs-ui-lib";`,
    snippet: `const inbox = useNotifications({ baseUrl, appKey, recipientId, token });\n<ActivityCenter id="activity-center" items={inbox.notifications} status={inbox.status === "idle" ? "loading" : inbox.status} unreadCount={inbox.unreadCount} error={inbox.error} onItemSelect={(item) => inbox.markRead(item.id)} onMarkAllRead={inbox.markAllRead} onRetry={inbox.refresh} />`,
    variants: [
      { label: "cursor pagination", snippet: '<ActivityCenter items={inbox.notifications} hasMore={inbox.hasMore} loadingMore={inbox.loadingMore} onLoadMore={inbox.loadMore} onItemSelect={(item) => inbox.markRead(item.id)} />' },
      { label: "localized timestamps", snippet: '<ActivityCenter items={inbox.notifications} labelledBy="inbox-heading" formatTimestamp={(iso) => relativeTime(iso, locale)} onItemSelect={(item) => inbox.markRead(item.id)} />' },
    ],
  },
  "toast-stack": {
    import: `import { ToastStack } from "emibs-ui-lib/components/feedback/ToastStack";`,
    snippet: `<ToastStack items={queue.map((toast) => ({ ...toast, onDismiss: dismissToast }))} placement="top-right" />`,
    variants: [
      { label: "embedded review", snippet: '<ToastStack items={items} placement="contained" emptyLabel="No notifications." />' },
      { label: "single in-flight notice", snippet: '<ToastStack items={[{ id: "export", title: "Preparing export", tone: "loading", meta: "12s" }]} />' },
    ],
  },
  "validation-summary": {
    import: `import { ValidationSummary } from "emibs-ui-lib/components/feedback/ValidationSummary";`,
    snippet: `<ValidationSummary title={items.length > 0 ? "Resolve these fields" : "Ready to submit"} description={submitError} items={items} onItemSelect={(item) => form.setFocus(item.id)} />`,
    variants: [
      { label: "anchored to controls", snippet: '<ValidationSummary title="Resolve these fields" items={[{ id: "email", label: "Email", message: "Use a valid address.", controlId: "profile-email" }]} />' },
      { label: "advisory, compact", snippet: '<ValidationSummary tone="warning" density="compact" title="Review before publishing" items={advisories} />' },
    ],
  },
  "loading-state": {
    import: `import { LoadingState } from "emibs-ui-lib/components/feedback/LoadingState";`,
    snippet: '<LoadingState title="Loading records" description="Fetching the latest records." />',
    variants: [
      { label: "compact", snippet: '<LoadingState density="compact" title="Loading records" description="Fetching the latest records." />' },
      { label: "stacked skeleton", snippet: '<LoadingState title="Loading records" description="Fetching the latest records." skeleton={<div className="xpl-stack"><Skeleton variant="rectangular" /><Skeleton variant="text" /><Skeleton variant="text" /></div>} />' },
    ],
  },
};
