import type { UsageSnippet } from "../types";

export const dataUsages: Record<string, UsageSnippet> = {
  "audit-timeline": {
    import: `import { AuditTimeline } from "emibs-ui-lib/components/data/AuditTimeline";`,
    snippet: `<AuditTimeline entries={entries} />`,
    variants: [
      { label: "compact", snippet: '<AuditTimeline density="compact" entries={entries} />' },
      { label: "empty", snippet: '<AuditTimeline entries={[]} emptyLabel="No delivery record yet." />' },
    ],
  },
  "command-bar": {
    import: `import { CommandBar } from "emibs-ui-lib/components/data/CommandBar";`,
    snippet: `<CommandBar brand="SCORE" navigation={nav} verbs={verbs} navigate={navigate} onVerb={openInspector} entityHref={taskHref} statusStrip={<StatusStrip items={signals} />} />`,
    variants: [
      { label: "nav + jump only", snippet: '<CommandBar navigation={nav} navigate={navigate} onVerb={noop} entityHref={taskHref} />' },
      { label: "custom entity matcher", snippet: '<CommandBar navigation={nav} verbs={verbs} navigate={navigate} onVerb={onVerb} entityHref={href} matchEntity={matchGuideId} />' },
      { label: "controlled open + query", snippet: '<CommandBar navigation={nav} verbs={verbs} navigate={navigate} onVerb={onVerb} entityHref={taskHref} open={open} onOpenChange={setOpen} query={query} onQueryChange={setQuery} />' },
    ],
  },
  "auto-form": {
    import: `import { AutoForm } from "emibs-ui-lib/forms";\nimport { zodToSpec } from "emibs-ui-lib/core";`,
    snippet: `const spec = zodToSpec(schema, { sections, overrides: fieldOverrides });\n<AutoForm spec={spec} schema={schema} overrides={layoutOverrides} title="Profile settings" submitLabel="Save settings" onSubmit={handleSubmit} />`,
    variants: [
      { label: "derived spec", snippet: `<AutoForm spec={zodToSpec(schema)} title="Create account" onSubmit={handleSubmit} />` },
      { label: "with validation (zod)", snippet: `<AutoForm spec={spec} schema={schema} mode="onBlur" onSubmit={handleSubmit} />` },
      { label: "multi-section", snippet: `<AutoForm spec={{ fields, sections }} onSubmit={handleSubmit} />` },
      { label: "with overrides", snippet: `<AutoForm spec={spec} schema={schema} overrides={{ renderSection }} onSubmit={handleSubmit} />` },
    ],
  },
  "form-panel": {
    import: `import { FormPanel, useForm } from "emibs-ui-lib/forms";`,
    snippet: `const form = useForm({ schema });\n<FormPanel form={form} onSubmit={handleSubmit} title="Contact us" sections={sections} />`,
  },
  "accessibility-audit-panel": {
    import: `import { AccessibilityAuditPanel } from "emibs-ui-lib/components/data/AccessibilityAuditPanel";`,
    snippet: `<AccessibilityAuditPanel title="Preview accessibility audit" status="complete" notes={notes} violations={violations} passCount={37} />`,
    variants: [
      { label: "pass", snippet: '<AccessibilityAuditPanel title="A11y audit" status="complete" violations={[]} passCount={42} />' },
      { label: "running", snippet: '<AccessibilityAuditPanel title="A11y audit" status="running" />' },
      { label: "unavailable", snippet: '<AccessibilityAuditPanel title="A11y audit" status="unavailable" />' },
    ],
  },
  "entity-card": {
    import: `import { EntityCard } from "emibs-ui-lib/components/data/EntityCard";`,
    snippet: `<EntityCard title="Vilnius Old Town Guest Stay" subtitle="Vilnius district" image={image} badges={badges} metaItems={metaItems} action={actions} />`,
    variants: [
      { label: "image", snippet: '<EntityCard title="Retreat" image={{ src, alt }} badges={badges} metaItems={metaItems} />' },
      { label: "fallback", snippet: '<EntityCard title="Retreat" showMedia icon={<BedDouble size={24} />} />' },
      { label: "link", snippet: '<EntityCard title="Retreat" href={profileHref} density="compact" />' },
    ],
  },
  "booking-widget-panel": {
    import: `import { BookingWidgetPanel } from "emibs-ui-lib/components/data/BookingWidgetPanel";`,
    snippet: `<BookingWidgetPanel title="Guided tour" provider="Bokun" details={bookingDetails} widget={bokunWidget} />`,
    variants: [
      { label: "with widget", snippet: '<BookingWidgetPanel title="Guided tour" provider="Bokun" widget={bokunWidget} />' },
      { label: "consent pending", snippet: '<BookingWidgetPanel title="Guided tour" provider="Bokun" consentNotice={notice} />' },
    ],
  },
  "resource-transfer-dialog": {
    import: `import { ResourceTransferDialog } from "emibs-ui-lib/components/data/ResourceTransferDialog";`,
    snippet: `<ResourceTransferDialog open resource={fileSummary} targets={targets} targetId={targetId} move={move} onMoveChange={setMove} onTargetChange={setTargetId} onCancel={close} onConfirm={transfer} />`,
    variants: [
      { label: "copy", snippet: '<ResourceTransferDialog open resource={fileSummary} targets={targets} targetId={targetId} move={false} onCancel={close} onConfirm={copyFile} onTargetChange={setTargetId} />' },
      { label: "move", snippet: '<ResourceTransferDialog open resource={fileSummary} targets={targets} targetId={targetId} move onCancel={close} onConfirm={moveFile} onTargetChange={setTargetId} />' },
      { label: "empty", snippet: '<ResourceTransferDialog open resource={fileSummary} targets={[]} targetId="" move={false} onCancel={close} onConfirm={transfer} onTargetChange={setTargetId} />' },
    ],
  },
  "component-catalog-panel": {
    import: `import { ComponentCatalogPanel } from "emibs-ui-lib/components/data/ComponentCatalogPanel";`,
    snippet: `<ComponentCatalogPanel title="Catalog" items={items} search={search} sidebar={filters}>{reviewContent}</ComponentCatalogPanel>`,
    variants: [
      { label: "with actions", snippet: '<ComponentCatalogPanel title="Catalog" items={items} actions={actions} sidebar={filters}>{reviewContent}</ComponentCatalogPanel>' },
      { label: "empty results", snippet: '<ComponentCatalogPanel title="Catalog" items={[]} search={{ value: "none" }}>{emptyState}</ComponentCatalogPanel>' },
    ],
  },
  "component-playground-panel": {
    import: `import { ComponentPlaygroundPanel } from "emibs-ui-lib/components/data/ComponentPlaygroundPanel";`,
    snippet: `<ComponentPlaygroundPanel title="Playground" controls={controls} values={values} stage={preview} snippet={snippet} onValueChange={setValue} />`,
    variants: [
      { label: "with actions", snippet: '<ComponentPlaygroundPanel title="Playground" controls={controls} values={values} stage={preview} snippet={snippet} onReset={reset} onCopySnippet={copySnippet} />' },
      { label: "empty controls", snippet: '<ComponentPlaygroundPanel title="Playground" controls={[]} values={{}} stage={preview} emptyControlsLabel="No controls." />' },
    ],
  },
  "map-marker-pin": {
    import: `import { MapMarkerPin } from "emibs-ui-lib/components/data/MapMarkerPin";`,
    snippet: `<MapMarkerPin label="Accommodation" showLabel />`,
    variants: [
      { label: "pin", snippet: `<MapMarkerPin label="Accommodation" showLabel />` },
      { label: "selected", snippet: `<MapMarkerPin label="Guide" showLabel selected />` },
      { label: "dot", snippet: `<MapMarkerPin kind="dot" tone="success" />` },
      { label: "cluster", snippet: `<MapMarkerPin kind="cluster" count="24" ariaLabel="Cluster with 24 records" />` },
    ],
  },
  pager: {
    import: `import { Pager } from "emibs-ui-lib/components/data/Pager";`,
    snippet: `<Pager page={page} total={pageCount} summary={summary} compactSummary={compactSummary} onPageChange={setPage} />`,
    variants: [
      { label: "full controls", snippet: '<Pager page={2} total={12} summary="Showing 11-20 of 118 places" compactSummary="11-20 of 118" onPageChange={setPage} />' },
      { label: "footer controls", snippet: '<Pager page={2} total={3} summary="Showing detail section 2 of 3" compactSummary="Section 2 of 3" showFirstLast={false} onPageChange={setPage} />' },
    ],
  },
  "payment-checkout-panel": {
    import: `import { PaymentCheckoutPanel } from "emibs-ui-lib/components/data/PaymentCheckoutPanel";`,
    snippet: `<PaymentCheckoutPanel amount="324.00 EUR" providerSlot={<PaymentElement />} submitLabel="Pay 324.00 EUR" onSubmit={confirmPayment} />`,
    variants: [
      { label: "ready", snippet: '<PaymentCheckoutPanel amount="324.00 EUR" providerSlot={<PaymentElement />} submitLabel="Pay 324.00 EUR" />' },
      { label: "error", snippet: '<PaymentCheckoutPanel amount={amountLabel} providerSlot={paymentElement} error={paymentError} />' },
      { label: "processing", snippet: '<PaymentCheckoutPanel amount={amountLabel} providerSlot={paymentElement} processing processingLabel="Confirming payment" />' },
    ],
  },
  "newsletter-signup-panel": {
    import: `import { NewsletterSignupPanel } from "emibs-ui-lib/components/data/NewsletterSignupPanel";`,
    snippet: `<NewsletterSignupPanel title="Get travel inspiration" value={email} onValueChange={setEmail} onSubmit={subscribe} />`,
    variants: [
      { label: "submitted", snippet: '<NewsletterSignupPanel title="Get travel inspiration" value={email} submitted successMessage="Thanks. You are on the list." />' },
      { label: "busy", snippet: '<NewsletterSignupPanel title="Get travel inspiration" value={email} busy busyLabel="Subscribing..." />' },
      { label: "error", snippet: '<NewsletterSignupPanel title="Get travel inspiration" value={email} error={validationError} />' },
    ],
  },
  "form-builder": {
    import: `import { FormBuilder, autoFormCodeSnippet, serializeFormSpec } from "emibs-ui-lib/forms";`,
    snippet: `<FormBuilder initialSpec={contactRegistrationSeedSpec} onSpecChange={setSpec} />`,
    variants: [
      { label: "catalog page", snippet: `<FormBuilderPage />` },
      { label: "narrowed palette", snippet: `<FormBuilder availableFieldTypes={["text", "textarea", "select", "date"]} onSpecChange={setSpec} />` },
      { label: "product-owned export", snippet: `<FormBuilder onSpecChange={setSpec} />\n// no export callback: derive both artefacts from the spec you already hold\nawait save(serializeFormSpec(spec), autoFormCodeSnippet(spec));` },
      { label: "copy as code", snippet: `<AutoForm spec={exportedSpec} onSubmit={handleSubmit} />` },
    ],
  },
  "form-persistence-demo": {
    import: `import { FormPanel, SaveStatusIndicator, createLatencyStorageAdapter, createMemoryStorageAdapter, useForm, useDraftAutosave, useDrafts, useDirtyGuard, useOptimisticSubmit, useUndoStack } from "emibs-ui-lib/forms";`,
    snippet: `const form = useForm({ defaultValues });\nconst autosave = useDraftAutosave(form, { adapter, key: "request", debounceMs: 500 });\nconst drafts = useDrafts(form, { adapter, key: "request" });\nconst submit = drafts.withClearOnSubmit(useOptimisticSubmit(form, { onSubmit, optimisticValues }));\n<FormPanel form={form} onSubmit={submit} sections={sections} actions={<SaveStatusIndicator status={autosave.status} />} />`,
    variants: [
      { label: "adapter seam", snippet: 'const adapter = createLatencyStorageAdapter(createMemoryStorageAdapter(), 180);' },
      { label: "guarded navigation", snippet: 'const guard = useDirtyGuard(form);\nguard.confirmNavigation(() => navigate(nextHref));' },
      { label: "rollback", snippet: 'useOptimisticSubmit(form, { optimisticValues, onSubmit: submitToServer })' },
    ],
  },
  "data-table": {
    import: `import { DataTable } from "emibs-ui-lib/components/data/DataTable";`,
    snippet: '<DataTable caption="Work items" data={rows} columns={columns} getRowId={(row) => row.id} showPagination pageSize={10} />',
    variants: [
      { label: "toolbar slots", snippet: '<DataTable caption="Work items" data={rows} columns={columns} getRowId={(row) => row.id} searchSlot={<SearchField label="Search work items" value={query} onValueChange={setQuery} />} filterSlot={filterControls} exportAction={<Button onClick={exportRows}>Export</Button>} selectionMode="multi" selectedRowActions={({ selectedRows }) => <Button onClick={() => archive(selectedRows)}>Archive selected</Button>} />' },
      { label: "sortable selection", snippet: '<DataTable caption="Work items" data={rows} columns={columns} getRowId={(row) => row.id} defaultSort={{ columnId: "points", direction: "desc" }} selectionMode="multi" onSelectionChange={setSelected} />' },
      { label: "async states", snippet: '<DataTable caption="Work items" data={rows} columns={columns} getRowId={(row) => row.id} loading={isLoading} error={loadError} />' },
    ],
  },
  "theme-audit-panel": {
    import: `import { ThemeAuditPanel } from "emibs-ui-lib/components/data/ThemeAuditPanel";`,
    snippet: `<ThemeAuditPanel metrics={metrics} tokenGroups={tokenGroups} gaps={gaps} />`,
    variants: [
      { label: "no gaps", snippet: '<ThemeAuditPanel metrics={metrics} tokenGroups={tokenGroups} gaps={[]} />' },
      { label: "with notes", snippet: '<ThemeAuditPanel metrics={metrics} tokenGroups={tokenGroups} gaps={gaps} notes={notes} />' },
    ],
  },
  "theme-export-panel": {
    import: `import { ThemeExportPanel } from "emibs-ui-lib/components/data/ThemeExportPanel";`,
    snippet: `<ThemeExportPanel formats={formats} activeFormatId={format} actions={exportActions} preview={serializedTokens} onFormatChange={setFormat} />`,
    variants: [
      { label: "actions only", snippet: '<ThemeExportPanel actions={exportActions} badges={badges} />' },
      { label: "compact", snippet: '<ThemeExportPanel density="compact" formats={formats} activeFormatId="css" preview={cssOutput} />' },
    ],
  },
  "theme-lab-panel": {
    import: `import { ThemeLabPanel } from "emibs-ui-lib/components/data/ThemeLabPanel";`,
    snippet: `<ThemeLabPanel prompt={promptControl} iteration={iterationControl} generateAction={generateAction} applyAction={applyAction} proposal={proposal} />`,
    variants: [
      { label: "empty", snippet: '<ThemeLabPanel prompt={promptControl} generateAction={generateAction} proposal={null} />' },
      { label: "busy", snippet: '<ThemeLabPanel prompt={promptControl} generateAction={{ label: "Generate", busy: true }} proposal={proposal} />' },
    ],
  },
  "theme-preview-canvas": {
    import: `import { ThemePreviewCanvas } from "emibs-ui-lib/components/data/ThemePreviewCanvas";`,
    snippet: `<ThemePreviewCanvas mode="generated" generatedSurfaces={generatedSurfaces}>{(surface) => renderFixture(surface)}</ThemePreviewCanvas>`,
    variants: [
      { label: "single", snippet: '<ThemePreviewCanvas mode="single">{fixture}</ThemePreviewCanvas>' },
      { label: "compare", snippet: '<ThemePreviewCanvas mode="compare" compareSurfaces={themeSurfaces}>{(surface) => renderFixture(surface)}</ThemePreviewCanvas>' },
    ],
  },
  "discovery-cloud-panel": {
    import: `import { DiscoveryCloudPanel } from "emibs-ui-lib/components/data/DiscoveryCloudPanel";`,
    snippet: `<DiscoveryCloudPanel groups={cloudGroups} resultCount="92 components" />`,
    variants: [
      { label: "compact", snippet: '<DiscoveryCloudPanel density="compact" groups={cloudGroups} resultCount="42 matches" />' },
      { label: "empty", snippet: '<DiscoveryCloudPanel title="No discovery data" groups={[]} emptyLabel="No cloud groups are available yet." />' },
    ],
  },
  "design-idea-board-panel": {
    import: `import { DesignIdeaBoardPanel } from "emibs-ui-lib/components/data/DesignIdeaBoardPanel";`,
    snippet: `<DesignIdeaBoardPanel title="Design ideas" lanes={lanes} items={items} />`,
    variants: [
      { label: "filtered", snippet: '<DesignIdeaBoardPanel title="Score ideas" lanes={lanes} items={scoreItems} />' },
      { label: "with metrics", snippet: '<DesignIdeaBoardPanel title="Design ideas" lanes={lanes} items={items} metrics={metrics} />' },
    ],
  },
  "compare-tray-panel": {
    import: `import { CompareTrayPanel } from "emibs-ui-lib/components/data/CompareTrayPanel";`,
    snippet: `<CompareTrayPanel items={pinnedItems} currentAction={pinCurrentAction} resultCount="2 pinned" />`,
    variants: [
      { label: "compact", snippet: '<CompareTrayPanel density="compact" items={pinnedItems} resultCount="1 pinned" />' },
      { label: "empty", snippet: '<CompareTrayPanel items={[]} emptyLabel="Pin items to compare them side by side." />' },
    ],
  },
  "facet-filter-panel": {
    import: `import { FacetFilterPanel } from "emibs-ui-lib/components/data/FacetFilterPanel";`,
    snippet: `<FacetFilterPanel groups={groups} activeFilters={activeFilters} onReset={clearFilters} />`,
    variants: [
      { label: "compact", snippet: '<FacetFilterPanel density="compact" groups={groups} resultCount="18 matches" />' },
      { label: "empty", snippet: '<FacetFilterPanel title="No facets" groups={[]} emptyLabel="No filter dimensions are available yet." />' },
    ],
  },
  "filter-drawer-panel": {
    import: `import { FilterDrawerPanel } from "emibs-ui-lib/components/data/FilterDrawerPanel";`,
    snippet: `<FilterDrawerPanel mode="drawer" open={filtersOpen} onOpenChange={setFiltersOpen} title="Board filters">{controls}</FilterDrawerPanel>`,
    variants: [
      { label: "inline", snippet: '<FilterDrawerPanel mode="inline" title="Entity filters" summary="42 / 87">{controls}</FilterDrawerPanel>' },
      { label: "compact", snippet: '<FilterDrawerPanel density="compact" title="Explorer filters" badges={badges}>{controls}</FilterDrawerPanel>' },
    ],
  },
  "file-action-list-panel": {
    import: `import { FileActionListPanel } from "emibs-ui-lib/components/data/FileActionListPanel";`,
    snippet: `<FileActionListPanel title="Project files" items={files} menuOpenItemId={openId} onMenuOpenChange={setOpenId} />`,
    variants: [
      { label: "with actions", snippet: '<FileActionListPanel title="Project files" items={filesWithActions} menuOpenItemId={openId} onMenuOpenChange={setOpenId} />' },
      { label: "compact", snippet: '<FileActionListPanel density="compact" title="Files" items={files} />' },
      { label: "empty", snippet: '<FileActionListPanel title="Files" items={[]} emptyLabel="No files." />' },
    ],
  },
  "geocoding-control-panel": {
    import: `import { GeocodingControlPanel } from "emibs-ui-lib/components/data/GeocodingControlPanel";`,
    snippet: `<GeocodingControlPanel query={query} onQueryChange={setQuery} sources={sources} candidates={candidates} coordinates={selectedCoordinates} onSearch={runGeocode} />`,
    variants: [
      { label: "ready", snippet: '<GeocodingControlPanel query={query} sources={sources} candidates={geocodeResults} coordinates={selectedCoordinates} />' },
      { label: "loading", snippet: '<GeocodingControlPanel query={query} sources={sources} candidates={[]} loading loadingLabel="Searching map provider." />' },
      { label: "error", snippet: '<GeocodingControlPanel query={query} sources={sources} candidates={[]} error={geocodeError} />' },
    ],
  },
  "file-preview-panel": {
    import: `import { FilePreviewPanel } from "emibs-ui-lib/components/data/FilePreviewPanel";`,
    snippet: `<FilePreviewPanel file={file} kind="markdown" markdown={markdown} meta={meta} />`,
    variants: [
      { label: "markdown", snippet: '<FilePreviewPanel file={file} kind="markdown" markdown={markdown} loading={loading} error={error} />' },
      { label: "download fallback", snippet: '<FilePreviewPanel file={file} kind="file" fallbackLabel="Preview unavailable." />' },
    ],
  },
  "file-preview-dialog": {
    import: `import { FilePreviewDialog } from "emibs-ui-lib/components/data/FilePreviewDialog";`,
    snippet: `<FilePreviewDialog open={open} file={file} kind="markdown" markdown={markdown} sourceHref={signedUrl} onClose={close} />`,
    variants: [
      { label: "controlled mode", snippet: '<FilePreviewDialog open mode={mode} onModeChange={setMode} file={file} kind="markdown" markdown={markdown} sourceHref={signedUrl} onClose={close} />' },
      { label: "source only", snippet: '<FilePreviewDialog open file={file} kind="document" previewAvailable={false} sourceHref={signedUrl} onClose={close} />' },
    ],
  },
  "preview-matrix-panel": {
    import: `import { PreviewMatrixPanel } from "emibs-ui-lib/components/data/PreviewMatrixPanel";`,
    snippet: `<PreviewMatrixPanel columns={columns} rows={rows} />`,
    variants: [
      { label: "compact", snippet: '<PreviewMatrixPanel density="compact" columns={columns} rows={rows} />' },
      { label: "empty", snippet: '<PreviewMatrixPanel columns={columns} rows={[]} emptyLabel="No previews match the active filters." />' },
    ],
  },
  "project-directory-panel": {
    import: `import { ProjectDirectoryPanel } from "emibs-ui-lib/components/data/ProjectDirectoryPanel";`,
    snippet: `<ProjectDirectoryPanel title="Projects" items={projects} status="3 accessible" />`,
    variants: [
      { label: "loading", snippet: '<ProjectDirectoryPanel title="Projects" items={[]} loading />' },
      { label: "empty", snippet: '<ProjectDirectoryPanel title="Projects" items={[]} emptyLabel="No accessible projects." />' },
      { label: "error", snippet: '<ProjectDirectoryPanel title="Projects" items={[]} error="Projects failed to load." />' },
    ],
  },
  "resource-index-panel": {
    import: `import { ResourceIndexPanel } from "emibs-ui-lib/components/data/ResourceIndexPanel";`,
    snippet: `<ResourceIndexPanel title="Resources" items={resources} layout="grid" status="4 resources" />`,
    variants: [
      { label: "list", snippet: '<ResourceIndexPanel title="Projects" items={projects} onItemMove={moveProject} />' },
      { label: "grid", snippet: '<ResourceIndexPanel title="Users" items={users} layout="grid" />' },
    ],
  },
  "project-profile-panel": {
    import: `import { ProjectProfilePanel } from "emibs-ui-lib/components/data/ProjectProfilePanel";`,
    snippet: `<ProjectProfilePanel title="Score" eyebrow="score" fields={fields} checklist={definitionOfDone} attachments={mediaSlot} />`,
    variants: [
      { label: "with attachments", snippet: '<ProjectProfilePanel title="Score" fields={fields} checklist={definitionOfDone} attachments={mediaSlot} />' },
      { label: "loading", snippet: '<ProjectProfilePanel title="Score" loading loadingLabel="Loading project..." />' },
      { label: "empty checklist", snippet: '<ProjectProfilePanel title="Score" checklist={[]} />' },
    ],
  },
  "subscription-capacity-panel": {
    import: `import { SubscriptionCapacityPanel } from "emibs-ui-lib/components/data/SubscriptionCapacityPanel";`,
    snippet: `<SubscriptionCapacityPanel title="Subscriptions" metrics={metrics} subscriptions={subscriptions} status="3 subscriptions" />`,
    variants: [
      { label: "compact", snippet: '<SubscriptionCapacityPanel density="compact" title="Subscription check" subscriptions={subscriptions} />' },
      { label: "loading", snippet: '<SubscriptionCapacityPanel title="Subscriptions" subscriptions={[]} loading />' },
      { label: "empty", snippet: '<SubscriptionCapacityPanel title="Subscriptions" subscriptions={[]} emptyLabel="No subscriptions returned." />' },
    ],
  },
  "workflow-map-panel": {
    import: `import { WorkflowMapPanel } from "emibs-ui-lib/components/data/WorkflowMapPanel";`,
    snippet: `<WorkflowMapPanel title="Lifecycle map" insights={insights} stages={stages} status="API authoritative" />`,
    variants: [
      { label: "compact", snippet: '<WorkflowMapPanel density="compact" title="Release handoff" stages={stages} />' },
      { label: "loading", snippet: '<WorkflowMapPanel title="Lifecycle map" stages={[]} loading />' },
      { label: "empty", snippet: '<WorkflowMapPanel title="Lifecycle map" stages={[]} emptyLabel="No workflow data." />' },
    ],
  },
  "work-item-relation-editor-panel": {
    import: `import { WorkItemRelationEditorPanel } from "emibs-ui-lib/components/data/WorkItemRelationEditorPanel";`,
    snippet: `<WorkItemRelationEditorPanel title="Relation editor" fields={relationFields} actions={relationActions} />`,
    variants: [
      { label: "compact", snippet: '<WorkItemRelationEditorPanel density="compact" title="Relations" fields={relationFields} />' },
      { label: "loading", snippet: '<WorkItemRelationEditorPanel title="Relations" fields={[]} loading />' },
    ],
  },
  "activity-dashboard": {
    import: `import { ActivityDashboard } from "emibs-ui-lib/components/data/ActivityDashboard";`,
    snippet: `<ActivityDashboard title="Delivery activity" subtitle="Score fleet" status="Live" queues={activityDashboardQueues} metrics={activityDashboardMetrics} items={activityDashboardItems} />`,
    variants: [
      { label: "feed only", snippet: '<ActivityDashboard title="Delivery activity" items={activityDashboardItems} feedTitle="Latest handoffs" />' },
      { label: "empty", snippet: '<ActivityDashboard title="Delivery activity" items={[]} emptyLabel="No activity in this window." />' },
      { label: "error", snippet: '<ActivityDashboard title="Delivery activity" error="Activity feed unavailable." statusTone="danger" />' },
    ],
  },
  "actor-access-matrix": {
    import: `import { ActorAccessMatrix } from "emibs-ui-lib/components/data/ActorAccessMatrix";`,
    snippet: `<ActorAccessMatrix title="Actor access" contextLabel="Project" contextValue="SCORE" actors={actorAccessRows} onRoleChange={saveRole} onGrantChange={saveGrant} />`,
    variants: [
      { label: "loading", snippet: '<ActorAccessMatrix title="Actor access" actors={[]} loading />' },
      { label: "empty", snippet: '<ActorAccessMatrix title="Actor access" actors={[]} emptyLabel="No actors are mapped to this project." />' },
      { label: "localized columns", snippet: '<ActorAccessMatrix title="Prieiga" actors={actorAccessRows} actorColumnLabel="Vykdytojas" roleColumnLabel="Rolė" grantsColumnLabel="Leidimai" />' },
    ],
  },
  "admin-home-panel": {
    import: `import { AdminHomePanel } from "emibs-ui-lib/components/data/AdminHomePanel";`,
    snippet: `<AdminHomePanel title="Admin" subtitle="Operational entry points" metrics={adminHomeMetrics} notices={adminHomeNotices} actionItems={adminHomeActions} sections={adminHomeSections} onActionSelect={openAdminArea} />`,
    variants: [
      { label: "loading", snippet: '<AdminHomePanel title="Admin" loading loadingLabel="Loading admin dashboard..." />' },
      { label: "empty", snippet: '<AdminHomePanel title="Admin" actionItems={[]} emptyLabel="No admin actions for this role." />' },
      { label: "error", snippet: '<AdminHomePanel title="Admin" error="Admin summary could not be loaded." statusTone="danger" />' },
    ],
  },
  "admin-record-editor-panel": {
    import: `import { AdminRecordEditorPanel } from "emibs-ui-lib/components/data/AdminRecordEditorPanel";`,
    snippet: `<AdminRecordEditorPanel title="Edit guide" backLabel="Back to guides" backHref="/admin/guides" meta={adminRecordEditorMeta} notices={adminRecordEditorNotices} onSubmit={handleSubmit} actions={<Button type="submit">Save record</Button>}>\n  {recordFields}\n</AdminRecordEditorPanel>`,
    variants: [
      { label: "loading", snippet: '<AdminRecordEditorPanel title="Edit guide" backLabel="Back" loading loadingLabel="Loading record..." />' },
      { label: "not found", snippet: '<AdminRecordEditorPanel title="Edit guide" backLabel="Back" empty emptyLabel="Record not found." />' },
      { label: "callback back", snippet: '<AdminRecordEditorPanel title="Edit guide" backLabel="Back" onBack={() => navigate(-1)}>{recordFields}</AdminRecordEditorPanel>' },
    ],
  },
  "agent-management-panel": {
    import: `import { AgentManagementPanel } from "emibs-ui-lib/components/data/AgentManagementPanel";`,
    snippet: `<AgentManagementPanel title="Agents" status="12 agents" metrics={agentManagementMetrics} agents={agentManagementAgents} runners={agentManagementRunners} runnerOptions={runnerOptions} onAgentEnabledChange={saveAgentEnabled} onAgentRunnerChange={saveAgentRunner} />`,
    variants: [
      { label: "agents only", snippet: '<AgentManagementPanel title="Agents" agents={agentManagementAgents} onAgentOpen={openAgentProfile} />' },
      { label: "loading", snippet: '<AgentManagementPanel title="Agents" agents={[]} loading />' },
      { label: "empty", snippet: '<AgentManagementPanel title="Agents" agents={[]} emptyAgentsLabel="No agents registered." />' },
    ],
  },
  "agent-profile-panel": {
    import: `import { AgentProfilePanel } from "emibs-ui-lib/components/data/AgentProfilePanel";`,
    snippet: `<AgentProfilePanel title="Maestro" agentId="agent-maestro" metrics={agentProfileMetrics} formFields={agentProfileFormFields} onFormFieldChange={updateDraftField} grants={agentProfileGrants} fields={agentProfileFields} />`,
    variants: [
      { label: "read-only", snippet: '<AgentProfilePanel title="Maestro" agentId="agent-maestro" fields={agentProfileFields} grants={agentProfileGrants} />' },
      { label: "loading", snippet: '<AgentProfilePanel title="Maestro" agentId="agent-maestro" loading />' },
      { label: "busy", snippet: '<AgentProfilePanel title="Maestro" agentId="agent-maestro" busyState="Saving profile..." formFields={agentProfileFormFields} />' },
    ],
  },
  "checklist-editor-panel": {
    import: `import { ChecklistEditorPanel } from "emibs-ui-lib/components/data/ChecklistEditorPanel";`,
    snippet: `<ChecklistEditorPanel title="Definition of done" items={checklistItems} onAddItem={appendItem} onItemTextChange={setItemText} onItemCheckedChange={setItemChecked} onRemoveItem={removeItem} />`,
    variants: [
      { label: "read-only compact", snippet: '<ChecklistEditorPanel title="Definition of done" density="compact" readOnly items={checklistItems} />' },
      { label: "empty", snippet: '<ChecklistEditorPanel title="Definition of done" items={[]} emptyLabel="No checklist items yet." onAddItem={appendItem} />' },
      { label: "localized labels", snippet: '<ChecklistEditorPanel title="Užduotys" items={checklistItems} addLabel="Pridėti punktą" removeLabel={(_item, index) => `Šalinti punktą ${index + 1}`} />' },
    ],
  },
  "command-console": {
    import: `import { CommandConsole } from "emibs-ui-lib/components/data/CommandConsole";`,
    snippet: `<CommandConsole title="Command console" sessions={commandConsoleSessions} activeSessionId={activeSessionId} messages={commandConsoleMessages} draft={draft} onDraftChange={setDraft} onSubmit={queueCommand} onSessionSelect={setActiveSessionId} onNewSession={openSession} onCloseSession={closeSession} />`,
    variants: [
      { label: "submitting", snippet: '<CommandConsole title="Command console" sessions={commandConsoleSessions} messages={commandConsoleMessages} draft={draft} submitting submittingLabel="Queueing command..." />' },
      { label: "empty transcript", snippet: '<CommandConsole title="Command console" sessions={commandConsoleSessions} messages={[]} draft="" emptyState="Send a prompt to start this session." />' },
    ],
  },
  "component-review-panel": {
    import: `import { ComponentReviewPanel } from "emibs-ui-lib/components/data/ComponentReviewPanel";`,
    snippet: `<ComponentReviewPanel title="EntityCard" eyebrow="Data" summary="Card surface for guide and retreat records." badges={reviewBadges} meta={reviewMeta} variants={previewVariants} activeVariantId={variantId} onVariantChange={setVariantId} tabs={reviewTabs} activeTabId={tabId} onTabChange={setTabId} />`,
    variants: [
      { label: "canvas sizing", snippet: '<ComponentReviewPanel title="EntityCard" variants={previewVariants} activeCanvasSizeId="narrow" onCanvasSizeChange={setCanvasSizeId} />' },
      { label: "with review notes", snippet: '<ComponentReviewPanel title="EntityCard" variants={previewVariants} reviewNotes={["Compact density still clears 44px targets."]} />' },
      { label: "empty", snippet: '<ComponentReviewPanel title="EntityCard" variants={[]} emptyLabel="No preview variants are registered." />' },
    ],
  },
  "editable-form-panel": {
    import: `import { EditableFormPanel } from "emibs-ui-lib/components/data/EditableFormPanel";`,
    snippet: `<EditableFormPanel title="Guide details" subtitle="Public listing copy" badges={formBadges} sections={formSections} onSubmit={handleSubmit} actions={<Button type="submit">Save changes</Button>} />`,
    variants: [
      { label: "compact", snippet: '<EditableFormPanel variant="compact" title="Guide details" sections={formSections} onSubmit={handleSubmit} />' },
      { label: "with messages", snippet: '<EditableFormPanel title="Guide details" messages={[{ id: "conflict", tone: "danger", children: "This record changed since you opened it." }]} sections={formSections} onSubmit={handleSubmit} />' },
    ],
  },
  "entity-card-grid-panel": {
    import: `import { EntityCardGridPanel } from "emibs-ui-lib/components/data/EntityCardGridPanel";`,
    snippet: `<EntityCardGridPanel title="Guides" status="24 records" items={entityCardGridItems} toolbar={<EntityFilterPanel controls={filterControls} onClear={resetFilters} />} pagination={<Pager page={page} pageCount={pageCount} onPageChange={setPage} />} selectedItemId={selectedId} onItemSelect={setSelectedId} />`,
    variants: [
      { label: "compact", snippet: '<EntityCardGridPanel density="compact" title="Guides" items={entityCardGridItems} onItemSelect={setSelectedId} />' },
      { label: "loading", snippet: '<EntityCardGridPanel title="Guides" items={[]} loading loadingLabel="Loading records..." />' },
      { label: "empty", snippet: '<EntityCardGridPanel title="Guides" items={[]} emptyLabel="No guides match these filters." />' },
    ],
  },
  "entity-filter-panel": {
    import: `import { EntityFilterPanel } from "emibs-ui-lib/components/data/EntityFilterPanel";`,
    snippet: `<EntityFilterPanel title="Search filters" controls={filterControls} stats={entityFilterStats} resultCount={24} totalCount={128} clearVisible onClear={resetFilters} onRefresh={refetch} />`,
    variants: [
      { label: "refreshing", snippet: '<EntityFilterPanel controls={filterControls} refreshing refreshingLabel="Refreshing" onRefresh={refetch} />' },
      { label: "loading counts", snippet: '<EntityFilterPanel controls={filterControls} loading loadingLabel="Loading" resultLabel="guides" />' },
      { label: "select control", snippet: '<EntityFilterPanel controls={[{ id: "type", kind: "select", label: "Type", value: type, options: entityFilterTypeOptions, onChange: setType }]} />' },
    ],
  },
  "idea-backlog-panel": {
    import: `import { IdeaBacklogPanel } from "emibs-ui-lib/components/data/IdeaBacklogPanel";`,
    snippet: `<IdeaBacklogPanel title="Idea backlog" contextLabel="Project" contextValue="SCORE" status="9 open" items={ideaBacklogItems} onItemSelect={openIdea} />`,
    variants: [
      { label: "loading", snippet: '<IdeaBacklogPanel title="Idea backlog" items={[]} loading loadingLabel="Loading ideas..." />' },
      { label: "no context", snippet: '<IdeaBacklogPanel title="Idea backlog" items={[]} noContextLabel="Select a project to view ideas." />' },
      { label: "empty", snippet: '<IdeaBacklogPanel title="Idea backlog" contextValue="SCORE" items={[]} emptyLabel="No ideas captured yet." />' },
    ],
  },
  "integration-setup-panel": {
    import: `import { IntegrationSetupPanel } from "emibs-ui-lib/components/data/IntegrationSetupPanel";`,
    snippet: `<IntegrationSetupPanel title="Bokun" subtitle="Booking provider" status={{ label: "Connected", tone: "connected", detail: "Last sync 4m ago" }} metrics={integrationSetupMetrics} sections={integrationSections} onSubmit={saveIntegration} actions={<Button type="submit">Save connection</Button>} />`,
    variants: [
      { label: "disconnected", snippet: '<IntegrationSetupPanel title="Bokun" status={{ label: "Disconnected", tone: "disconnected", action: <Button onClick={connect}>Connect</Button> }} sections={integrationSections} />' },
      { label: "testing", snippet: '<IntegrationSetupPanel title="Bokun" status={{ label: "Testing credentials", tone: "testing" }} sections={integrationSections} />' },
      { label: "error", snippet: '<IntegrationSetupPanel title="Bokun" status={{ label: "Error", tone: "error" }} messages={[{ id: "auth", tone: "danger", children: "HMAC signature rejected." }]} sections={integrationSections} />' },
    ],
  },
  "kanban-board": {
    import: `import { KanbanBoard } from "emibs-ui-lib/components/data/KanbanBoard";`,
    snippet: `<KanbanBoard columns={kanbanColumns} ariaLabel="Task workflow board" />`,
    variants: [
      { label: "collapsible lanes", snippet: '<KanbanBoard columns={kanbanColumns} collapsible defaultCollapsed />' },
      { label: "wrap layout", snippet: '<KanbanBoard columns={kanbanColumns} layout="wrap" density="comfortable" columnMinWidth={260} />' },
      { label: "custom card", snippet: '<KanbanBoard columns={kanbanColumns} renderTask={(task) => <WorkItemCard itemId={task.id} title={task.title} density="compact" />} />' },
    ],
  },
  "map-control-panel": {
    import: `import { MapControlPanel } from "emibs-ui-lib/components/data/MapControlPanel";`,
    snippet: `<MapControlPanel title="Map tools" actions={mapControlActions} stats={mapViewportStats} status="12 markers" />`,
    variants: [
      { label: "compact stack", snippet: '<MapControlPanel density="compact" layout="stack" actions={mapControlActions} />' },
      { label: "hidden", snippet: '<MapControlPanel actions={mapControlActions} visible={false} />' },
      { label: "disabled while loading", snippet: '<MapControlPanel title="Map tools" actions={mapControlActions} disabled />' },
    ],
  },
  "map-info-card": {
    import: `import { MapInfoCard } from "emibs-ui-lib/components/data/MapInfoCard";`,
    snippet: `<MapInfoCard title="Vilnius Old Town Guest Stay" subtitle="Vilnius district" badges={mapInfoCardBadges} rows={mapInfoCardRows} placement="overlay" onClose={clearSelectedMarker} actions={<Button href={profileHref}>Open profile</Button>} />`,
    variants: [
      { label: "inline", snippet: '<MapInfoCard placement="inline" title="Vilnius Old Town Guest Stay" rows={mapInfoCardRows} />' },
      { label: "no close affordance", snippet: '<MapInfoCard title="Trakai Castle" badges={mapInfoCardBadges} rows={mapInfoCardRows} />' },
    ],
  },
  "markdown-document-panel": {
    import: `import { MarkdownDocumentPanel } from "emibs-ui-lib/components/data/MarkdownDocumentPanel";`,
    snippet: `<MarkdownDocumentPanel title="Extraction review notes" markdown={scoreTaskDocumentMarkdown} meta={markdownDocumentMeta} actions={<Button onClick={copyMarkdown}>Copy source</Button>} />`,
    variants: [
      { label: "loading", snippet: '<MarkdownDocumentPanel title="Extraction review notes" loading loadingLabel="Loading document..." />' },
      { label: "empty", snippet: '<MarkdownDocumentPanel title="Extraction review notes" markdown="" emptyLabel="This document has no body yet." />' },
      { label: "custom renderer (still DOMPurify-sanitized)", snippet: '<MarkdownDocumentPanel title="Release notes" markdown={notes} renderMarkdown={renderWithMdast} />' },
      { label: "extra narrowing pass", snippet: '<MarkdownDocumentPanel title="Release notes" markdown={notes} sanitizeHtml={stripAllLinks} />' },
    ],
  },
  "media-asset-panel": {
    import: `import { MediaAssetPanel } from "emibs-ui-lib/components/data/MediaAssetPanel";`,
    snippet: `<MediaAssetPanel title="Media library" status="42 assets" stats={mediaAssetStats} assets={mediaAssetItems} upload={{ label: "Upload media", description: "PNG, JPG or PDF up to 10 MB", action: <FileUploadControl onFilesChange={stageFiles} /> }} onAssetSelect={setSelectedAssetId} />`,
    variants: [
      { label: "list only", snippet: '<MediaAssetPanel title="Media library" assets={mediaAssetItems} showDetail={false} />' },
      { label: "loading", snippet: '<MediaAssetPanel title="Media library" assets={[]} loading loadingLabel="Loading media assets..." />' },
      { label: "empty", snippet: '<MediaAssetPanel title="Media library" assets={[]} emptyLabel="No media uploaded for this guide." />' },
    ],
  },
  "metric-grid": {
    import: `import { MetricGrid } from "emibs-ui-lib/components/data/MetricGrid";`,
    snippet: `<MetricGrid items={metricGridItems} columns={4} ariaLabel="Delivery metrics" />`,
    variants: [
      { label: "compact", snippet: '<MetricGrid density="compact" columns={3} items={metricGridCompactItems} />' },
      { label: "empty", snippet: '<MetricGrid items={[]} emptyLabel="No metrics for this window." />' },
    ],
  },
  "mode-control-panel": {
    import: `import { ModeControlPanel } from "emibs-ui-lib/components/data/ModeControlPanel";`,
    snippet: `<ModeControlPanel title="Map mode" modeLabel="Display" modeValue={mode} modeOptions={mapModeOptions} onModeChange={setMode} toggles={mapModeToggles} />`,
    variants: [
      { label: "disabled", snippet: '<ModeControlPanel title="Map mode" modeValue={mode} modeOptions={mapModeOptions} disabled status="Read-only" />' },
      { label: "error", snippet: '<ModeControlPanel title="Map mode" modeValue={mode} modeOptions={mapModeOptions} error="Mode change was rejected." statusTone="danger" />' },
    ],
  },
  "operational-diagnostic-panel": {
    import: `import { OperationalDiagnosticPanel } from "emibs-ui-lib/components/data/OperationalDiagnosticPanel";`,
    snippet: `<OperationalDiagnosticPanel title="Route diagnostics" status={{ label: "Healthy", tone: "success", detail: "Checked 2m ago" }} metrics={operationalDiagnosticMetrics} details={operationalDiagnosticDetails} payload={<PayloadBlock value={diagnosticResponse} />} />`,
    variants: [
      { label: "loading", snippet: '<OperationalDiagnosticPanel title="Route diagnostics" loading loadingLabel="Loading diagnostics." />' },
      { label: "error", snippet: '<OperationalDiagnosticPanel title="Route diagnostics" status={{ label: "Failing", tone: "danger" }} error="Diagnostic endpoint returned 503." />' },
      { label: "embedded report (fully sandboxed)", snippet: '<OperationalDiagnosticPanel title="Route diagnostics" embed={{ title: "Latency report", src: reportUrl }} />' },
      { label: "interactive tool embed", snippet: '<OperationalDiagnosticPanel title="Database browser" embed={{ title: "DB view", src: dbViewUrl, sandbox: ["allow-scripts", "allow-forms"] }} />' },
      { label: "inline markup (inert, unsanitized)", snippet: '<OperationalDiagnosticPanel title="Route diagnostics" embed={{ title: "Last report", srcDoc: reportHtml }} />' },
    ],
  },
  "payment-account-panel": {
    import: `import { PaymentAccountPanel } from "emibs-ui-lib/components/data/PaymentAccountPanel";`,
    snippet: `<PaymentAccountPanel title="Billing" summaryLabel="Balance" summaryValue="EUR 1,240.00" summaryDetail="Next payout 3 Sep" stats={paymentAccountStats} methods={paymentMethods} payments={paymentHistoryRows} payouts={payoutRows} />`,
    variants: [
      { label: "with checkout", snippet: '<PaymentAccountPanel title="Billing" methods={paymentMethods} checkout={<PaymentCheckoutPanel title="Add funds" />} />' },
      { label: "empty", snippet: '<PaymentAccountPanel title="Billing" methods={[]} payments={[]} payouts={[]} emptyMethodsLabel="No saved cards." />' },
    ],
  },
  "process-run-history-panel": {
    import: `import { ProcessRunHistoryPanel } from "emibs-ui-lib/components/data/ProcessRunHistoryPanel";`,
    snippet: `<ProcessRunHistoryPanel title="Run history" subtitle="score-worker" status="Last 20 runs" runs={processRunHistoryItems} />`,
    variants: [
      { label: "compact", snippet: '<ProcessRunHistoryPanel density="compact" title="Run history" runs={processRunHistoryItems} />' },
      { label: "loading", snippet: '<ProcessRunHistoryPanel title="Run history" runs={[]} loading loadingLabel="Loading run history." />' },
      { label: "empty", snippet: '<ProcessRunHistoryPanel title="Run history" runs={[]} emptyLabel="This process has not run yet." />' },
    ],
  },
  "project-settings-panel": {
    import: `import { ProjectSettingsPanel } from "emibs-ui-lib/components/data/ProjectSettingsPanel";`,
    snippet: `<ProjectSettingsPanel title="Project settings" subtitle="SCORE" stats={projectSettingsStats} summary={summaryDigest} config={configDocument} actions={<Button onClick={save}>Save settings</Button>} />`,
    variants: [
      { label: "with notices", snippet: '<ProjectSettingsPanel title="Project settings" notices={[{ id: "digest", title: "Digest recipient missing", tone: "warning" }]} summary={summaryDigest} config={configDocument} />' },
      { label: "config validation", snippet: '<ProjectSettingsPanel title="Project settings" summary={summaryDigest} config={{ ...configDocument, validation: "Line 12: unknown key `runner`." }} statusTone="danger" />' },
    ],
  },
  "record-detail-panel": {
    import: `import { RecordDetailPanel } from "emibs-ui-lib/components/data/RecordDetailPanel";`,
    snippet: `<RecordDetailPanel eyebrow="Guide" title="Vilnius Old Town Guest Stay" subtitle="Published 12 Aug" badges={recordBadges} fields={recordFields} sections={recordSections} onClose={closeInspector} />`,
    variants: [
      { label: "compact", snippet: '<RecordDetailPanel variant="compact" title="Vilnius Old Town Guest Stay" fields={recordFields} />' },
      { label: "sections only", snippet: '<RecordDetailPanel title="Vilnius Old Town Guest Stay" sections={recordSections} footer={<Button href={editHref}>Edit record</Button>} />' },
    ],
  },
  "relationship-picker-panel": {
    import: `import { RelationshipPickerPanel } from "emibs-ui-lib/components/data/RelationshipPickerPanel";`,
    snippet: `<RelationshipPickerPanel title="Linked guides" subtitle="Attach guides to this itinerary" items={relationshipPickerItems} selectedCount={3} totalCount={12} onSelectAll={selectAll} onClearSelection={clearSelection} />`,
    variants: [
      { label: "loading", snippet: '<RelationshipPickerPanel title="Linked guides" items={[]} loading loadingLabel="Loading relationships." />' },
      { label: "empty", snippet: '<RelationshipPickerPanel title="Linked guides" items={[]} emptyLabel="No candidate records returned." />' },
    ],
  },
  "schedule-editor-dialog": {
    import: `import { ScheduleEditorDialog } from "emibs-ui-lib/components/data/ScheduleEditorDialog";`,
    snippet: `<ScheduleEditorDialog open={open} title="Edit scheduler" subtitle="board-watch" enabled={enabled} schedule={schedule} firstStartAt={firstStartAt} meta={schedulerMeta} checks={schedulerChecks} fields={schedulerFields} onEnabledChange={setEnabled} onScheduleChange={setSchedule} onFirstStartAtChange={setFirstStartAt} onFieldChange={setField} onClose={close} onSubmit={saveScheduler} />`,
    variants: [
      { label: "contained", snippet: '<ScheduleEditorDialog placement="contained" open title="Edit scheduler" enabled={enabled} schedule={schedule} onEnabledChange={setEnabled} onScheduleChange={setSchedule} onClose={close} onSubmit={saveScheduler} />' },
      { label: "saving", snippet: '<ScheduleEditorDialog open title="Edit scheduler" enabled={enabled} schedule={schedule} saving savingLabel="Saving" submitDisabled onEnabledChange={setEnabled} onScheduleChange={setSchedule} onClose={close} onSubmit={saveScheduler} />' },
      { label: "error", snippet: '<ScheduleEditorDialog open title="Edit scheduler" enabled={enabled} schedule={schedule} error="Cron pattern is not valid." onEnabledChange={setEnabled} onScheduleChange={setSchedule} onClose={close} onSubmit={saveScheduler} />' },
    ],
  },
  "scheduler-control-panel": {
    import: `import { SchedulerControlPanel } from "emibs-ui-lib/components/data/SchedulerControlPanel";`,
    snippet: `<SchedulerControlPanel title="Schedulers" status="6 mapped" schedulers={schedulerControlItems} busySchedulerId={busySchedulerId} onToggleScheduler={saveSchedulerEnabled} />`,
    variants: [
      { label: "loading", snippet: '<SchedulerControlPanel title="Schedulers" schedulers={[]} loading loadingLabel="Loading schedulers." />' },
      { label: "empty", snippet: '<SchedulerControlPanel title="Schedulers" schedulers={[]} emptyLabel="No schedulers are mapped." />' },
      { label: "read-only", snippet: '<SchedulerControlPanel title="Schedulers" schedulers={schedulerControlItems} enabledLabel="Active" disabledLabel="Paused" />' },
    ],
  },
  "work-board-toolbar": {
    import: `import { WorkBoardToolbar } from "emibs-ui-lib/components/data/WorkBoardToolbar";`,
    snippet: `<WorkBoardToolbar title="Work board" status="42 items" badges={workBoardToolbarBadges} search={{ value: query, onChange: setQuery }} project={{ label: "Project", value: projectKey, options: workBoardProjectOptions, onChange: setProjectKey }} epic={{ label: "Epic", value: epicId, options: workBoardEpicOptions, onChange: setEpicId }} />`,
    variants: [
      { label: "filters open", snippet: '<WorkBoardToolbar title="Work board" filtersOpen onFiltersOpenChange={setFiltersOpen} activeFilters={activeFilters} clearFiltersAction={<Button onClick={clearFilters}>Clear all</Button>} />' },
      { label: "error", snippet: '<WorkBoardToolbar title="Work board" error="Board query failed." statusTone="danger" />' },
    ],
  },
  "work-item-card": {
    import: `import { WorkItemCard } from "emibs-ui-lib/components/data/WorkItemCard";`,
    snippet: `<WorkItemCard itemId="SCORE-412" title="Extract EntityCard variants" badges={workItemBadges} meta={workItemMeta} epic={{ label: "Catalog completion", href: epicHref }} href={taskHref} onOpen={openTask} />`,
    variants: [
      { label: "compact selected", snippet: '<WorkItemCard {...workItemCards[0]} density="compact" selected />' },
      { label: "external link", snippet: '<WorkItemCard itemId="SCORE-412" title="Extract EntityCard variants" externalLink={{ href: prUrl, label: "Open pull request" }} />' },
      { label: "disabled", snippet: '<WorkItemCard itemId="SCORE-412" title="Extract EntityCard variants" disabled openLabel="Open task" />' },
    ],
  },
  "work-item-planning-panel": {
    import: `import { WorkItemPlanningPanel } from "emibs-ui-lib/components/data/WorkItemPlanningPanel";`,
    snippet: `<WorkItemPlanningPanel title="Planning" subtitle="SCORE-412" workItem={workItemDraft} triage={triageDraft} typeOptions={workItemTypeOptions} projectOptions={workItemProjectOptions} roleOptions={workItemRoleOptions} complexityOptions={workItemComplexityOptions} actorOptions={workItemActorOptions} epicOptions={workItemEpicOptions} onWorkItemChange={updateWorkItemDraft} onTriageChange={updateTriageDraft} onSave={savePlanning} onTriage={applyTriage} onCancel={cancel} />`,
    variants: [
      { label: "busy", snippet: '<WorkItemPlanningPanel title="Planning" workItem={workItemDraft} triage={triageDraft} typeOptions={workItemTypeOptions} busy saveLabel="Save planning" />' },
      { label: "project move allowed", snippet: '<WorkItemPlanningPanel title="Planning" workItem={workItemDraft} triage={triageDraft} typeOptions={workItemTypeOptions} projectOptions={workItemProjectOptions} canMoveProject />' },
      { label: "blocked", snippet: '<WorkItemPlanningPanel title="Planning" workItem={workItemDraft} triage={triageDraft} typeOptions={workItemTypeOptions} messages={[{ id: "blocked", tone: "danger", children: "Blocked by SCORE-410." }]} />' },
    ],
  },
  "work-item-trace-panel": {
    import: `import { WorkItemTracePanel } from "emibs-ui-lib/components/data/WorkItemTracePanel";`,
    snippet: `<WorkItemTracePanel eyebrow="SCORE-412" title="Trace" status="3 relations" relationGroups={workItemTraceRelationGroups} notes={workItemTraceNotes} />`,
    variants: [
      { label: "loading", snippet: '<WorkItemTracePanel title="Trace" loading />' },
      { label: "empty", snippet: '<WorkItemTracePanel title="Trace" relationGroups={[]} notes={[]} emptyRelationsLabel="No linked work." emptyNotesLabel="No review notes yet." />' },
      { label: "error", snippet: '<WorkItemTracePanel title="Trace" error="Trace query failed." statusTone="danger" />' },
    ],
  },
  "workflow-command-bar": {
    import: `import { WorkflowCommandBar } from "emibs-ui-lib/components/data/WorkflowCommandBar";`,
    snippet: `<WorkflowCommandBar title="Workflow" currentState="In review" commands={workflowCommandBarCommands} status="Reviewer lane" />`,
    variants: [
      { label: "compact stack", snippet: '<WorkflowCommandBar density="compact" layout="stack" currentState="Ready" commands={workflowReleaseCommands} />' },
      { label: "empty", snippet: '<WorkflowCommandBar title="Workflow" commands={[]} emptyLabel="No transitions available from this state." />' },
    ],
  },
};
