import type { UsageSnippet } from "../types";

export const addressUsages: Record<string, UsageSnippet> = {
  "address-field": {
    import: 'import { AddressField } from "emibs-ui-lib/components/data/AddressField";',
    snippet: '<AddressField value={address} onChange={setAddress} mapAdapter={mapAdapter} countryLabel="Lithuania" searchAddresses={searchAddresses} />',
    variants: [{ label: "read-only", snippet: '<AddressField value={address} onChange={setAddress} readOnly />' }],
  },
  "geo-coordinate-picker": {
    import: 'import { GeoCoordinatePicker } from "emibs-ui-lib/components/data/GeoCoordinatePicker";',
    snippet: '<GeoCoordinatePicker latitude={point.latitude} longitude={point.longitude} onChange={setPoint} mapAdapter={mapAdapter} />',
    variants: [{ label: "no-map", snippet: '<GeoCoordinatePicker latitude={point.latitude} longitude={point.longitude} onChange={setPoint} />' }],
  },
};
