import { addressUsages } from "./address";
import type { UsageSnippet } from "../types";
import { primitivesUsages } from "./primitives";
import { layoutUsages } from "./layout";
import { dataUsages } from "./data";
import { feedbackUsages } from "./feedback";
import { authUsages } from "./auth";

export const USAGES: Record<string, UsageSnippet> = {
  ...addressUsages,
  ...primitivesUsages,
  ...layoutUsages,
  ...dataUsages,
  ...feedbackUsages,
  ...authUsages,
};
