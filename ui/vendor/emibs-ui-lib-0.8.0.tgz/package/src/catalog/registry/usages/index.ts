import { addressUsages } from "./address";
import { templateUsages } from "./templates";
import type { UsageSnippet } from "../types";
import { primitivesUsages } from "./primitives";
import { layoutUsages } from "./layout";
import { dataUsages } from "./data";
import { feedbackUsages } from "./feedback";
import { authUsages } from "./auth";

export const USAGES: Record<string, UsageSnippet> = {
  ...addressUsages,
  ...templateUsages,
  ...primitivesUsages,
  ...layoutUsages,
  ...dataUsages,
  ...feedbackUsages,
  ...authUsages,
};
