import { addressPropDocs } from "./address";
import { templatePropDocs } from "./templates";
import type { PropDocRow } from "../types";
import { primitivesPropDocs } from "./primitives";
import { layoutPropDocs } from "./layout";
import { dataPropDocs } from "./data";
import { feedbackPropDocs } from "./feedback";
import { authPropDocs } from "./auth";

// Props/API reference rows, authored from each component's TypeScript Props type
// (+ adjacent .SPEC.md). Reference pattern on the core controlled/presentational
// primitives; extended to the rest via issue-368/369. Board: issue-359/367.
export const PROPDOCS: Record<string, PropDocRow[]> = {
  ...addressPropDocs,
  ...templatePropDocs,
  ...primitivesPropDocs,
  ...layoutPropDocs,
  ...dataPropDocs,
  ...feedbackPropDocs,
  ...authPropDocs,
};
