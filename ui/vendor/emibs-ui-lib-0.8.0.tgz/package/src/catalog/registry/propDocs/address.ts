import type { PropDocRow } from "../types";

export const addressPropDocs: Record<string, PropDocRow[]> = {
  "address-field": [
    { name: "value", type: "AddressValue", required: true, description: "Controlled fields, country code, nullable coordinates and opaque metadata." },
    { name: "onChange", type: "(value: AddressValue) => void", required: true, description: "Emits the full selected or edited value; never saves." },
    { name: "canEdit", type: "boolean", default: "value.canEdit ?? true", description: "Locks field editing while retaining existing-address selection." },
    { name: "readOnly", type: "boolean", default: "false", description: "Locks edits, geocoding and address selection. Map viewing remains available." },
    { name: "searchAddresses", type: "(query, signal) => Promise<AddressValue[]>", description: "Consumer-owned cancellable search. At most 50 results are rendered." },
    { name: "mapAdapter", type: "AddressMapAdapter", description: "Stable map View and optional cancellable geocode callback." },
    { name: "countryLabel", type: "string", default: "value.countryCode", description: "Read-only country display name." },
  ],
  "geo-coordinate-picker": [
    { name: "latitude", type: "number | null", required: true, description: "Controlled latitude, -90 through 90." },
    { name: "longitude", type: "number | null", required: true, description: "Controlled longitude, -180 through 180." },
    { name: "onChange", type: "(point) => void", required: true, description: "Emits both nullable coordinates." },
    { name: "readOnly", type: "boolean", default: "false", description: "Locks inputs and removes map picking." },
    { name: "mapAdapter", type: "AddressMapAdapter", description: "Consumer-owned View receives point, readOnly and optional onPick." },
  ],
};
