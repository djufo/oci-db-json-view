import type { PropDocRow } from "../types";

export const templatePropDocs: Record<string, PropDocRow[]> = {
  "app-frame": [
    { name: "storageKey", type: "string", description: "Prefix for the persisted choice (`<key>:theme-family`, `<key>:theme-mode`, `<key>:density`). Omit to keep the choice in memory only." },
    { name: "families", type: "readonly AppearanceFamily[]", default: "houseAppearanceFamilies", description: "Theme families offered to the user. A fixed-brand app passes its single family." },
    { name: "defaultFamilyId", type: "string", default: "first family", description: "Family used until the user picks one." },
    { name: "defaultMode", type: '"light" | "dark" | "system"', default: '"light"', description: "Mode used until the user picks one." },
    { name: "defaultDensity", type: '"comfortable" | "compact"', default: '"comfortable"', description: "Density used until the user picks one. Operator consoles pass compact." },
    { name: "children", type: "ReactNode", required: true, description: "The app. Everything inside reads the theme and density of this frame." },
  ],
  "appearance-controls": [
    { name: "appearance", type: "Appearance", default: "enclosing AppFrame", description: "The appearance to edit, when it is not the enclosing frame's." },
    { name: "allowSystem", type: "boolean", default: "true", description: "Offer system as a third mode after light and dark." },
    { name: "showDensity", type: "boolean", default: "false", description: "Show the comfortable/compact switch." },
    { name: "label", type: "string", default: '"Appearance"', description: "Accessible name of the control group." },
    { name: "className", type: "string", description: "Extra class on the group." },
  ],
  "sign-in-page": [
    { name: "title", type: "ReactNode", required: true, description: "The page heading; it also names the card for assistive technology." },
    { name: "children", type: "ReactNode", required: true, description: "The sign-in form or provider button. The page performs no sign-in itself." },
    { name: "brand", type: "ReactNode", description: "Product mark above the title: a logo or an icon." },
    { name: "eyebrow", type: "ReactNode", description: "Small label above the title, usually the product name." },
    { name: "description", type: "ReactNode", description: "One or two sentences under the title." },
    { name: "notice", type: "ReactNode", description: "A sign-in failure or other message, between the copy and the form." },
    { name: "footer", type: "ReactNode", description: "Secondary content under the form." },
    { name: "corner", type: "ReactNode", description: "Top-right slot, typically AppearanceControls. Joins the flow above the card on a phone." },
    { name: "level", type: "1 | 2", default: "1", description: "Heading level of the title." },
    { name: "className", type: "string", description: "Extra class on the page." },
  ],
  "page-scaffold": [
    { name: "width", type: '"default" | "narrow" | "wide" | "full"', default: '"default"', description: "Maximum content width. Narrow suits forms; full suits boards." },
    { name: "header", type: "ReactNode", description: "The page heading, normally a PageHeader." },
    { name: "notice", type: "ReactNode", description: "A page-level message under the header. The content stays in place." },
    { name: "toolbar", type: "ReactNode", description: "Filters and page actions between the header and the content." },
    { name: "state", type: "PageScaffoldState | null", description: "Replaces the content with a loading, empty or error panel." },
    { name: "children", type: "ReactNode", description: "The page content. Not rendered while state is set." },
    { name: "footer", type: "ReactNode", description: "Pagination or totals under the content. Rendered whenever passed; omit it when meaningless." },
  ],
};
