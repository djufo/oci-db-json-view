// Catalog Explorer — the registry: metadata + isolated demo renderers.
//
// Every catalogued component appears here (so the whole set is navigable,
// searchable and inspectable). Components in the migrated slice also carry a
// render() and optional variants[] for the inspect canvas + variants grid.
// Board: task-220 (registry module) + task-238 (primitives migration).

import { componentMeta } from "../metadata";
import { getSpec } from "../specs";
import type { ComponentEntry } from "../types";
import { DEMOS } from "./demos";
import { PLAYGROUNDS } from "./playgrounds";
import { PROPDOCS } from "./propDocs";
import { STATES } from "./states";
import { USAGES } from "./usages";
import { VARIANTS } from "./variants";

/** All catalogued components assembled once from the canonical registries. */
export const entries: ComponentEntry[] = componentMeta.map((meta) => {
  const demo = DEMOS[meta.id];
  const hasDemo = Boolean(demo);
  const resolvedSpec = getSpec(meta.specPath);
  const specContent = resolvedSpec?.trim() ? resolvedSpec : null;
  return {
    ...meta,
    // Demo wiring advances only the initial status. Explicit advanced lifecycle
    // declarations are policy and must survive assembly unchanged.
    status: meta.status === "catalogued" && hasDemo ? "demo-migrated" : meta.status,
    hasDemo,
    specContent,
    render: demo ?? (() => null),
    variants: VARIANTS[meta.id],
    states: STATES[meta.id],
    usage: USAGES[meta.id],
    propDocs: PROPDOCS[meta.id],
    playground: PLAYGROUNDS[meta.id],
  };
});

export const entryById: Record<string, ComponentEntry> = Object.fromEntries(
  entries.map((e) => [e.id, e]),
);

export function getEntry(id: string): ComponentEntry | undefined {
  return entryById[id];
}

/** Has a real isolated demo been wired (vs. metadata-only, migration pending)? */
export function isMigrated(entry: ComponentEntry): boolean {
  return entry.hasDemo;
}
