import type { ReactNode } from "react";
import type { ComponentEntry } from "../types";

export type Variant = { label: string; render: () => ReactNode };
export type UsageSnippet = NonNullable<ComponentEntry["usage"]>;
export type PlaygroundSchema = NonNullable<ComponentEntry["playground"]>;
export type PropDocRow = NonNullable<ComponentEntry["propDocs"]>[number];
