// Catalog Explorer — demo helpers for entity browsing, record detail and map
// control surfaces (mostly eLitua extractions).
import { type CSSProperties, useState } from "react";
import {
  CalendarDays,
  Clock3,
  ExternalLink,
  FileText,
  Mail,
  MapPinned,
  Minus,
  Phone,
  Plus,
  RefreshCw,
  SlidersHorizontal,
  ZoomOut,
} from "lucide-react";
import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import { EmptyState } from "../../../components/primitives/EmptyState";
import { EntityCardGridPanel } from "../../../components/data/EntityCardGridPanel";
import { EntityFilterPanel } from "../../../components/data/EntityFilterPanel";
import { MapControlPanel } from "../../../components/data/MapControlPanel";
import { MapInfoCard } from "../../../components/data/MapInfoCard";
import { MapViewport } from "../../../components/layout/MapViewport";
import { MetricGrid } from "../../../components/data/MetricGrid";
import { ModeControlPanel } from "../../../components/data/ModeControlPanel";
import { Pager } from "../../../components/data/Pager";
import { RecordDetailPanel } from "../../../components/data/RecordDetailPanel";
import { RelationshipPickerPanel } from "../../../components/data/RelationshipPickerPanel";
import {
  entityCardGridItems,
  entityFilterRegionOptions,
  entityFilterStats,
  entityFilterStatusOptions,
  entityFilterTypeOptions,
  entityFilterVerificationOptions,
  mapInfoCardBadges,
  mapInfoCardRows,
  mapViewportMarkers,
  metricGridCompactItems,
  metricGridItems,
  relationshipPickerItems,
} from "../../../demos/data";

export function MetricGridDemo() {
  return (
    <div className="metric-grid-demo-stack">
      <article className="metric-grid-demo-card">
        <div className="metric-grid-demo-copy">
          <Badge tone="info">dashboard metrics</Badge>
          <h3>Comfortable summary tiles</h3>
          <p>Score and eLitua can pass preformatted labels, values, details and tones without moving polling or formatting into the shared layer.</p>
        </div>
        <MetricGrid items={metricGridItems} columns={4} ariaLabel="Cross-project metric examples" />
      </article>

      <article className="metric-grid-demo-card">
        <div className="metric-grid-demo-copy">
          <Badge tone="success">compact detail</Badge>
          <h3>Dense integration row</h3>
          <p>Compact density fits status panels and side sections where the surrounding page already owns rhythm.</p>
        </div>
        <MetricGrid
          items={metricGridCompactItems}
          columns={3}
          density="compact"
          ariaLabel="Compact integration metrics"
        />
      </article>

      <article className="metric-grid-demo-card">
        <div className="metric-grid-demo-copy">
          <Badge>empty state</Badge>
          <h3>No metrics returned</h3>
          <p>Empty state copy is supplied by the consuming product and stays layout-stable.</p>
        </div>
        <MetricGrid items={[]} emptyLabel="Metrics will appear after the next refresh." />
      </article>
    </div>
  );
}

export function ModeControlPanelDemo() {
  const [mode, setMode] = useState("geo");
  const [autoNavigate, setAutoNavigate] = useState(true);
  const [autoNext, setAutoNext] = useState(false);
  return (
    <div className="mode-control-demo-grid">
      <ModeControlPanel
        eyebrow="entity admin"
        title="Accommodation controls"
        subtitle="The consuming app owns state selectors, dispatch, translations and map/geocoding side effects."
        modeLabel="Workspace mode"
        modeValue={mode}
        modeOptions={[
          { value: "preview", label: "Preview" },
          { value: "edit", label: "Edit" },
          { value: "geo", label: "Geo Form" },
        ]}
        onModeChange={setMode}
        status={mode === "geo" ? "geocoding tools" : "browse mode"}
        statusTone={mode === "geo" ? "accent" : "info"}
        actions={
          <Button type="button" variant="secondary" size="sm">
            <RefreshCw size={15} />
            Refresh
          </Button>
        }
        toggles={[
          {
            id: "auto-navigate",
            label: "Auto-navigate",
            description: "Pan the map when a selected record changes.",
            checked: autoNavigate,
            onChange: setAutoNavigate,
            disabled: mode !== "geo",
          },
          {
            id: "auto-next",
            label: "Auto-next",
            description: "Advance after save and verify in geo review mode.",
            checked: autoNext,
            onChange: setAutoNext,
            disabled: mode !== "geo",
          },
        ]}
        footer={
          <>
            <Badge tone="info">presentational</Badge>
            <span>Entity refresh, view-mode dispatch, geocoding progress and local labels stay product-owned.</span>
          </>
        }
      />
      <ModeControlPanel
        disabled
        eyebrow="busy state"
        title="Guide controls"
        subtitle="Disabled mode shows how loading and refresh work can freeze controls without changing layout."
        modeLabel="Guide mode"
        modeValue="view"
        modeOptions={[
          { value: "view", label: "View" },
          { value: "edit", label: "Edit" },
        ]}
        status="refreshing"
        statusTone="warning"
        message="Controls are disabled while entity data refreshes."
        actions={
          <Button disabled type="button" variant="secondary" size="sm">
            <RefreshCw size={15} />
            Refresh
          </Button>
        }
      />
    </div>
  );
}

export function EntityFilterPanelDemo() {
  const [search, setSearch] = useState("Vilnius");
  const [type, setType] = useState("geo");
  const [verified, setVerified] = useState("1");
  const [enabled, setEnabled] = useState("");
  const [region, setRegion] = useState("vilnius");
  const [refreshing, setRefreshing] = useState(false);
  const filtersActive = Boolean(search || type || verified || enabled || region);
  const clearFilters = () => {
    setSearch("");
    setType("");
    setVerified("");
    setEnabled("");
    setRegion("");
  };
  const refreshFilters = () => {
    setRefreshing(true);
    window.setTimeout(() => setRefreshing(false), 550);
  };
  return (
    <div className="entity-filter-demo-grid">
      <EntityFilterPanel
        title="Search filters"
        subtitle="Fits inside ExplorerWorkspace sidebar slots while app state owns query and result derivation."
        controls={[
          {
            id: "text",
            kind: "text",
            label: "Search",
            value: search,
            placeholder: "Search guides, stays or places",
            onChange: setSearch,
          },
          {
            id: "type",
            kind: "select",
            label: "Entity type",
            value: type,
            options: entityFilterTypeOptions,
            onChange: setType,
          },
          {
            id: "verified",
            kind: "select",
            label: "Verification",
            value: verified,
            options: entityFilterVerificationOptions,
            onChange: setVerified,
          },
          {
            id: "enabled",
            kind: "select",
            label: "Status",
            value: enabled,
            options: entityFilterStatusOptions,
            onChange: setEnabled,
          },
          {
            id: "region",
            kind: "select",
            label: "Region",
            value: region,
            options: entityFilterRegionOptions,
            onChange: setRegion,
          },
        ]}
        clearVisible={filtersActive}
        onClear={clearFilters}
        refreshing={refreshing}
        onRefresh={refreshFilters}
        resultCount={filtersActive ? 42 : 87}
        totalCount={87}
        resultLabel="records"
        stats={entityFilterStats}
        footer={
          <>
            Product-owned pieces: translations, RxJS dispatch, URL query state, map sync, and backend filter behavior.
          </>
        }
      />
      <EntityFilterPanel
        title="Loading filters"
        subtitle="Disabled controls preserve layout while eLitua refreshes entity options."
        loading
        loadingLabel="Loading records"
        controls={[
          {
            id: "text-loading",
            kind: "text",
            label: "Search",
            value: "",
            placeholder: "Unavailable during refresh",
            disabled: true,
          },
          {
            id: "type-loading",
            kind: "select",
            label: "Entity type",
            value: "",
            options: entityFilterTypeOptions,
            disabled: true,
          },
          {
            id: "region-loading",
            kind: "select",
            label: "Region",
            value: "",
            options: entityFilterRegionOptions,
            disabled: true,
          },
        ]}
        clearVisible
        clearDisabled
        onClear={() => undefined}
        refreshDisabled
        onRefresh={() => undefined}
      />
    </div>
  );
}

export function EntityCardGridPanelDemo() {
  const [selectedItemId, setSelectedItemId] = useState("guide-ruta");
  return (
    <EntityCardGridPanel
      title="Tourism card browser"
      eyebrow="entity views"
      description="eLitua card views repeat this shell while entity state, filters, pagination math, map sync and routes stay local."
      status="6 current records"
      statusTone="info"
      toolbar={
        <>
          <Badge tone="success">Pre-paged rows</Badge>
          <span>Card content is mapped by the consuming feature.</span>
        </>
      }
      pagination={
        <Pager
          page={1}
          total={3}
          summary="Showing 1-6 of 18 entities"
          compactSummary="1-6 of 18"
          onPageChange={() => undefined}
        />
      }
      items={entityCardGridItems}
      selectedItemId={selectedItemId}
      onItemSelect={setSelectedItemId}
    />
  );
}

export function RelationshipPickerPanelDemo() {
  const [selected, setSelected] = useState(
    () => new Set(relationshipPickerItems.filter((item) => item.checked).map((item) => item.id)),
  );
  const toggleItem = (itemId: string, checked: boolean) => {
    setSelected((current) => {
      const next = new Set(current);
      if (checked) {
        next.add(itemId);
      } else {
        next.delete(itemId);
      }
      return next;
    });
  };
  const items = relationshipPickerItems.map((item) => ({
    ...item,
    checked: selected.has(item.id),
    onToggle: (checked: boolean) => toggleItem(item.id, checked),
  }));
  return (
    <RelationshipPickerPanel
      eyebrow="guide admin"
      title="Guide region coverage"
      subtitle="Based on eLitua's guide-to-geo editor: the shared panel keeps selection chrome while eLitua keeps DataProxy, guide state and save behavior local."
      status="controlled state"
      statusTone="accent"
      items={items}
      selectedCount={selected.size}
      totalCount={relationshipPickerItems.length}
      actions={<Badge tone="info">many-to-many</Badge>}
      onSelectAll={() =>
        setSelected(new Set(relationshipPickerItems.filter((item) => !item.disabled).map((item) => item.id)))
      }
      onClearSelection={() => setSelected(new Set())}
      footer={
        <>
          <Badge tone="success">{selected.size} saved on submit</Badge>
          <span>Save/cancel actions, stale-data handling, translations and toasts stay in the consuming product.</span>
        </>
      }
    />
  );
}

export function RecordDetailPanelDemo() {
  const [compactOpen, setCompactOpen] = useState(true);
  return (
    <div className="record-detail-demo-grid">
      <RecordDetailPanel
        eyebrow="Score task"
        title="Extract shared detail surface"
        subtitle="task-228 - UI Framework"
        badges={[
          { id: "status", label: "processing", tone: "warning" },
          { id: "project", label: "score" },
          { id: "type", label: "story", tone: "info" },
          { id: "version", label: "v2", tone: "accent" },
        ]}
        actions={
          <>
            <Button variant="secondary" size="sm">
              <RefreshCw size={15} />
              Refresh
            </Button>
            <Button size="sm">
              <FileText size={15} />
              Open
            </Button>
          </>
        }
        fields={[
          { id: "author", label: "Author", value: "codex-maestro" },
          { id: "assignee", label: "Assignee", value: "ui-framework-runner" },
          { id: "branch", label: "Branch", value: "score-work" },
          { id: "pr", label: "Pull request", value: "Review link", href: "#/c/record-detail-panel" },
          { id: "updated", label: "Updated", value: "2026-06-27 20:52", icon: <Clock3 size={15} /> },
        ]}
        sections={[
          {
            id: "summary",
            title: "Summary",
            children:
              "Detail shells keep metadata, field grids and review sections aligned while workflow actions stay product-owned.",
          },
          {
            id: "relations",
            title: "Relations",
            fields: [
              { id: "epic", label: "Parent epic", value: "UI Framework" },
              { id: "blocked", label: "Blocked by", value: "None" },
            ],
          },
        ]}
        footer={
          <Pager
            page={1}
            total={3}
            summary="Showing detail section 1 of 3"
            compactSummary="Section 1 of 3"
            onPageChange={() => undefined}
            showFirstLast={false}
          />
        }
      />

      {compactOpen ? (
        <RecordDetailPanel
          variant="compact"
          eyebrow="eLitua selected record"
          title="Vilnius Old Town apartment"
          subtitle="Accommodation detail"
          badges={[
            { id: "type", label: "apartment", tone: "accent" },
            { id: "verified", label: "verified", tone: "success" },
            { id: "enabled", label: "enabled", tone: "info" },
          ]}
          onClose={() => setCompactOpen(false)}
          fields={[
            { id: "region", label: "Region", value: "Vilnius", icon: <MapPinned size={15} /> },
            { id: "phone", label: "Phone", value: "+370 600 00000", href: "tel:+37060000000", icon: <Phone size={15} /> },
            { id: "email", label: "Email", value: "host@example.lt", href: "mailto:host@example.lt", icon: <Mail size={15} /> },
            { id: "capacity", label: "Capacity", value: "4 beds" },
            { id: "license", label: "License", value: "LT-1024" },
            { id: "license-date", label: "License date", value: "2026-04-18", icon: <CalendarDays size={15} /> },
          ]}
          sections={[
            {
              id: "status",
              title: "Map status",
              fields: [
                { id: "geocode", label: "Geocode", value: "confirmed" },
                { id: "coordinates", label: "Coordinates", value: "54.6872, 25.2797" },
              ],
            },
          ]}
        />
      ) : (
        <EmptyState
          title="No selected record"
          action={
            <Button variant="secondary" onClick={() => setCompactOpen(true)}>
              Select record
            </Button>
          }
        />
      )}
    </div>
  );
}

export function MapInfoCardDemo() {
  return (
    <div className="map-info-card-demo-grid">
      <MapViewport title="Selected marker overlay" markers={mapViewportMarkers}>
        <div className="ui-map-viewport__fallback">
          <div className="ui-map-viewport__route" />
          {mapViewportMarkers.map((marker) => (
            <div
              className={`ui-map-viewport__marker ${marker.selected ? "is-selected" : ""}`}
              key={marker.id}
              style={
                {
                  "--ui-map-marker-x": `${marker.x}%`,
                  "--ui-map-marker-y": `${marker.y}%`,
                } as CSSProperties
              }
            >
              <MapPinned size={15} aria-hidden="true" />
              <span>{marker.label}</span>
            </div>
          ))}
          <MapInfoCard
            placement="overlay"
            eyebrow="Selected place"
            title="Vilnius Old Town"
            subtitle="UNESCO district marker"
            badges={mapInfoCardBadges}
            rows={mapInfoCardRows}
            onClose={() => undefined}
            actions={
              <Button size="sm" variant="secondary">
                <ExternalLink size={14} />
                Open record
              </Button>
            }
          />
        </div>
      </MapViewport>
      <MapInfoCard
        eyebrow="Inline detail"
        title="Trakai Castle route"
        subtitle="Use inline placement inside a side panel or MapViewport info slot."
        badges={[
          { id: "route", label: "route", tone: "info" },
          { id: "draft", label: "needs review", tone: "warning" },
        ]}
        rows={[
          { id: "record", label: "Record", value: "geo-2094" },
          { id: "coordinates", label: "Coordinates", value: "54.6526, 24.9347" },
          { id: "linked", label: "Linked stays", value: "7" },
          { id: "status", label: "Geo status", value: "pending" },
        ]}
        footer="Product apps keep map selection, navigation and localization local."
      />
    </div>
  );
}

export function MapControlPanelDemo() {
  const [zoom, setZoom] = useState(12);
  const [traffic, setTraffic] = useState(false);
  return (
    <div className="map-control-demo-grid">
      <MapControlPanel
        eyebrow="Workspace map"
        title="Map controls"
        subtitle="Actions stay product-owned; the shared component renders the reviewable command chrome."
        status={`Zoom ${zoom}`}
        statusTone="info"
        stats={[
          { id: "markers", label: "Markers", value: "48", tone: "accent" },
          { id: "missing", label: "No coords", value: "7", tone: "warning" },
          { id: "layer", label: "Layer", value: traffic ? "Traffic" : "Default" },
        ]}
        actions={[
          {
            id: "zoom-in",
            label: "Zoom in",
            icon: <Plus size={15} />,
            onSelect: () => setZoom((value) => Math.min(18, value + 1)),
          },
          {
            id: "zoom-out",
            label: "Zoom out",
            icon: <Minus size={15} />,
            onSelect: () => setZoom((value) => Math.max(4, value - 1)),
          },
          {
            id: "reset",
            label: "Initial view",
            icon: <ZoomOut size={15} />,
            onSelect: () => setZoom(12),
          },
          {
            id: "traffic",
            label: "Traffic layer",
            icon: <SlidersHorizontal size={15} />,
            active: traffic,
            onSelect: () => setTraffic((value) => !value),
          },
        ]}
        footer="Consumers map these actions to Google Maps dispatch, route state, telemetry and translations."
      />
      <MapControlPanel
        density="compact"
        layout="stack"
        title="Sidebar density"
        subtitle="Compact stacked layout mirrors eLitua's entity explorer sidebar."
        actions={[
          {
            id: "compact-plus",
            label: "Zoom in",
            icon: <Plus size={14} />,
            onSelect: () => setZoom((value) => Math.min(18, value + 1)),
          },
          {
            id: "compact-minus",
            label: "Zoom out",
            icon: <Minus size={14} />,
            onSelect: () => setZoom((value) => Math.max(4, value - 1)),
          },
          {
            id: "compact-reset",
            label: "Reset view",
            icon: <RefreshCw size={14} />,
            onSelect: () => setZoom(12),
          },
        ]}
      />
    </div>
  );
}
