// Catalog Explorer — demo helpers for admin, agent and configuration panels.
import { useState } from "react";
import {
  Bot,
  CheckCircle2,
  Database,
  Download,
  ExternalLink,
  Eye,
  FileText,
  KeyRound,
  Link2,
  Lock,
  Mail,
  PlugZap,
  Plus,
  ReceiptText,
  RefreshCw,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  Upload,
} from "lucide-react";
import { ActorAccessMatrix } from "../../../components/data/ActorAccessMatrix";
import { AdminHomePanel } from "../../../components/data/AdminHomePanel";
import { AdminRecordEditorPanel } from "../../../components/data/AdminRecordEditorPanel";
import { AgentManagementPanel } from "../../../components/data/AgentManagementPanel";
import { AgentProfilePanel } from "../../../components/data/AgentProfilePanel";
import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import { FileUploadControl } from "../../../components/primitives/FileUploadControl";
import { Input, Select } from "../../../components/primitives/Field";
import { IdeaBacklogPanel } from "../../../components/data/IdeaBacklogPanel";
import { IntegrationSetupPanel } from "../../../components/data/IntegrationSetupPanel";
import { MarkdownDocumentPanel, downloadMarkdown } from "../../../components/data/MarkdownDocumentPanel";
import { MediaAssetPanel } from "../../../components/data/MediaAssetPanel";
import { PaymentAccountPanel } from "../../../components/data/PaymentAccountPanel";
import { PaymentCheckoutPanel } from "../../../components/data/PaymentCheckoutPanel";
import { ProjectSettingsPanel } from "../../../components/data/ProjectSettingsPanel";
import {
  actorAccessRows,
  adminHomeActions,
  adminHomeMetrics,
  adminHomeNotices,
  adminHomeSections,
  adminRecordEditorMeta,
  adminRecordEditorNotices,
  agentManagementAgents,
  agentManagementMetrics,
  agentManagementRunners,
  agentProfileFields,
  agentProfileGrants,
  agentProfileMetrics,
  agentProfileProviderOptions,
  agentProfileRoleOptions,
  ideaBacklogItems,
  integrationSetupMetrics,
  markdownDocumentMeta,
  mediaAssetItems,
  mediaAssetStats,
  paymentAccountStats,
  paymentHistoryRows,
  paymentMethods,
  payoutRows,
  projectSettingsStats,
  scoreTaskDocumentMarkdown,
} from "../../../demos/data";

export function AdminHomePanelDemo() {
  return (
    <AdminHomePanel
      eyebrow="admin hub"
      title="Admin dashboard"
      subtitle="A starting surface for routing into access, resource, session, and profile tools while app code keeps auth and route policy local."
      icon={<ShieldCheck size={22} />}
      status="4 areas"
      statusTone="info"
      metrics={adminHomeMetrics}
      notices={adminHomeNotices}
      actionItems={adminHomeActions}
      sections={adminHomeSections}
      actions={
        <Button variant="secondary" size="sm" type="button">
          <RefreshCw size={15} />
          Refresh
        </Button>
      }
      footer="Counts, project grants, session summaries, route registries, RBAC, persistence and toasts remain product-owned."
    />
  );
}

export function IdeaBacklogPanelDemo() {
  return (
    <IdeaBacklogPanel
      eyebrow="project ideas"
      title="Ideas"
      subtitle="Score's admin project tab shows a context-bound idea collection while Score keeps project selection, idea loading, routes and permissions local."
      contextLabel="Selected project"
      contextValue="score / UI Framework"
      status={`${ideaBacklogItems.length} ideas`}
      statusTone="info"
      items={ideaBacklogItems.map((idea) => ({
        ...idea,
        actions: (
          <Button variant="ghost" size="sm" type="button">
            <ExternalLink size={15} />
            Open
          </Button>
        ),
      }))}
      actions={
        <>
          <Badge tone="success">related collection</Badge>
          <Button variant="secondary" size="sm" type="button">
            <Plus size={15} />
            New idea
          </Button>
        </>
      }
      onItemSelect={() => undefined}
    />
  );
}

export function ActorAccessMatrixDemo() {
  return (
    <ActorAccessMatrix
      eyebrow="admin access"
      title="Actor roles and direct grants"
      subtitle="Score admin screens repeat this matrix for actor roles and project release grants; eLitua admin users can later map account roles into the same structure."
      contextLabel="Selected project"
      contextValue="score / UI Framework"
      status="3 actors"
      statusTone="info"
      actors={actorAccessRows.map((actor) => ({
        ...actor,
        actions: (
          <Button variant="ghost" size="sm" type="button">
            <ExternalLink size={15} />
            Open
          </Button>
        ),
      }))}
      error="One runner is capacity-gated; the consuming app owns dispatch policy and persistence."
      actions={
        <>
          <Badge tone="success">autosave ready</Badge>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
        </>
      }
      onRoleChange={() => undefined}
      onGrantChange={() => undefined}
    />
  );
}

export function AgentManagementPanelDemo() {
  const [agentRows, setAgentRows] = useState(agentManagementAgents);
  const [runnerRows, setRunnerRows] = useState(agentManagementRunners);
  const runnerOptions = runnerRows.map((runner) => ({
    value: runner.id,
    label: runner.displayName || runner.id,
  }));
  return (
    <AgentManagementPanel
      eyebrow="agent operations"
      title="Agent management"
      subtitle="A presentational admin panel for owner-managed agents, runner lanes and capacity gates without binding the shared component to Score APIs."
      status={`${agentRows.length} agents`}
      statusTone="info"
      metrics={agentManagementMetrics}
      agents={agentRows.map((agent) => ({
        ...agent,
        actions: (
          <Button variant="ghost" size="sm" type="button">
            <ExternalLink size={15} />
            Open
          </Button>
        ),
      }))}
      runners={runnerRows}
      runnerOptions={runnerOptions}
      error="The Codex reviewer is capacity-gated; the consuming app owns scheduling policy and persistence."
      actions={
        <>
          <Badge tone="success">autosave-ready</Badge>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
        </>
      }
      onAgentEnabledChange={(agentId, enabled) =>
        setAgentRows((rows) =>
          rows.map((agent) =>
            agent.id === agentId
              ? {
                  ...agent,
                  enabled,
                  state: enabled ? (agent.state === "disabled" ? "idle" : agent.state) : "disabled",
                  stateTone: enabled ? (agent.stateTone === "neutral" ? "info" : agent.stateTone) : "neutral",
                  healthTone: enabled ? (agent.healthTone === "disabled" ? "idle" : agent.healthTone) : "disabled",
                }
              : agent,
          ),
        )
      }
      onAgentRunnerChange={(agentId, runnerId) =>
        setAgentRows((rows) => rows.map((agent) => (agent.id === agentId ? { ...agent, runnerId } : agent)))
      }
      onRunnerEnabledChange={(runnerId, enabled) =>
        setRunnerRows((rows) => rows.map((runner) => (runner.id === runnerId ? { ...runner, enabled } : runner)))
      }
      onRunnerNameChange={(runnerId, displayName) =>
        setRunnerRows((rows) => rows.map((runner) => (runner.id === runnerId ? { ...runner, displayName } : runner)))
      }
      onRunnerResponsibilitiesChange={(runnerId, responsibilities) =>
        setRunnerRows((rows) =>
          rows.map((runner) => (runner.id === runnerId ? { ...runner, responsibilities } : runner)),
        )
      }
    />
  );
}

export function AgentProfilePanelDemo() {
  const [draft, setDraft] = useState({
    displayName: "Codex Maestro",
    role: "admin",
    provider: "codex",
    enabled: true,
  });
  return (
    <AgentProfilePanel
      agentId="agent-codex-maestro"
      avatar={<Bot size={24} />}
      eyebrow="agent profile"
      title={draft.displayName}
      subtitle="Single-agent Maestro flow for scheduled board and UI Framework work."
      status={draft.enabled ? "enabled" : "disabled"}
      statusTone={draft.enabled ? "success" : "neutral"}
      busyState="Changes save automatically"
      metrics={agentProfileMetrics}
      formDescription="The consuming app owns debounced persistence, validation, provider login and toast behavior."
      formFields={[
        {
          id: "displayName",
          label: "Display name",
          value: draft.displayName,
          placeholder: "Agent display name",
        },
        {
          id: "tokenSecret",
          label: "Token secret",
          value: "score/agents/agent-codex-maestro",
          readOnly: true,
          hint: "Runtime tokens are never returned by the shared component.",
        },
        {
          id: "role",
          label: "Role",
          value: draft.role,
          control: "select",
          options: agentProfileRoleOptions,
        },
        {
          id: "provider",
          label: "Provider",
          value: draft.provider || "unassigned",
          control: "select",
          options: agentProfileProviderOptions,
        },
        {
          id: "enabled",
          label: "Enabled",
          value: draft.enabled,
          control: "checkbox",
          hint: "Capacity and runner policy stay in Score.",
        },
      ]}
      grants={agentProfileGrants.map((grant) => ({
        ...grant,
        action: (
          <Button variant="ghost" size="sm" type="button">
            <ExternalLink size={15} />
            Access
          </Button>
        ),
      }))}
      fields={agentProfileFields}
      actions={
        <>
          <Button variant="danger" size="sm" type="button">
            <Trash2 size={15} />
            Delete
          </Button>
          <Button variant="secondary" size="sm" type="button">
            Close
          </Button>
        </>
      }
      onFormFieldChange={(fieldId, value) => {
        setDraft((current) => {
          if (fieldId === "enabled") {
            return { ...current, enabled: Boolean(value) };
          }
          if (fieldId === "provider") {
            return { ...current, provider: value === "unassigned" ? "" : String(value) };
          }
          if (fieldId === "role") {
            return { ...current, role: String(value) };
          }
          if (fieldId === "displayName") {
            return { ...current, displayName: String(value) };
          }
          return current;
        });
      }}
    />
  );
}

export function AdminRecordEditorPanelDemo() {
  const [draft, setDraft] = useState({
    username: "ruta.travels",
    email: "ruta@example.lt",
    displayName: "Ruta Travels",
    role: "guide",
    active: true,
    mustChangePassword: false,
    uploadLabel: "No replacement selected",
  });
  return (
    <div className="admin-record-editor-demo-grid">
      <AdminRecordEditorPanel
        eyebrow="eLitua admin"
        title="Edit User #42"
        subtitle="The consuming app owns route params, DataProxy calls, validation, persistence and redirects."
        backHref="#/c/admin-record-editor-panel"
        backLabel="Users"
        status="Unsaved local draft"
        statusTone="warning"
        meta={adminRecordEditorMeta}
        notices={adminRecordEditorNotices}
        actions={
          <Button size="sm" type="button" variant="secondary">
            <ExternalLink size={15} />
            Open audit
          </Button>
        }
        footer={
          <>
            <Button type="submit">
              <CheckCircle2 size={16} />
              Save
            </Button>
            <Button type="button" variant="danger">
              <Trash2 size={16} />
              Delete
            </Button>
          </>
        }
        onSubmit={(event) => event.preventDefault()}
      >
        <div className="admin-record-editor-demo-fields">
          <label className="admin-record-editor-demo-field">
            <span>Username</span>
            <Input value={draft.username} onChange={(event) => setDraft({ ...draft, username: event.target.value })} />
          </label>
          <label className="admin-record-editor-demo-field">
            <span>Email</span>
            <Input
              type="email"
              value={draft.email}
              onChange={(event) => setDraft({ ...draft, email: event.target.value })}
            />
          </label>
          <label className="admin-record-editor-demo-field">
            <span>Display name</span>
            <Input
              value={draft.displayName}
              onChange={(event) => setDraft({ ...draft, displayName: event.target.value })}
            />
          </label>
          <label className="admin-record-editor-demo-field">
            <span>Role</span>
            <Select value={draft.role} onChange={(event) => setDraft({ ...draft, role: event.target.value })}>
              <option value="user">User</option>
              <option value="admin">Admin</option>
              <option value="guide">Guide</option>
              <option value="accommodation">Accommodation</option>
            </Select>
          </label>
          <label className="admin-record-editor-demo-check">
            <input
              checked={draft.active}
              type="checkbox"
              onChange={(event) => setDraft({ ...draft, active: event.target.checked })}
            />
            <span>Active account</span>
          </label>
          <label className="admin-record-editor-demo-check">
            <input
              checked={draft.mustChangePassword}
              type="checkbox"
              onChange={(event) => setDraft({ ...draft, mustChangePassword: event.target.checked })}
            />
            <span>Must change password on next login</span>
          </label>
          <label className="admin-record-editor-demo-upload">
            <input
              accept="image/*"
              type="file"
              onChange={(event) =>
                setDraft({
                  ...draft,
                  uploadLabel: event.target.files?.[0]?.name ?? "No replacement selected",
                })
              }
            />
            <Upload aria-hidden="true" size={22} />
            <span>{draft.uploadLabel}</span>
          </label>
        </div>
      </AdminRecordEditorPanel>
      <AdminRecordEditorPanel
        eyebrow="Score project admin"
        title="Edit Project"
        subtitle="Loading and not-found route states stay visible without requiring a product API."
        backHref="#/c/admin-record-editor-panel"
        backLabel="Projects"
        status="Loading"
        statusTone="info"
        loading
        loadingLabel="Loading project metadata..."
      />
    </div>
  );
}

export function IntegrationSetupPanelDemo() {
  const [secretVisible, setSecretVisible] = useState(false);
  const [accessKey, setAccessKey] = useState("ak_live_baltic_routes");
  const [secretKey, setSecretKey] = useState("bokun-secret-value");
  const [channel, setChannel] = useState("Baltic tours");
  const [vendor, setVendor] = useState("vendor-4286");
  const [syncProducts, setSyncProducts] = useState(true);
  const [syncAvailability, setSyncAvailability] = useState(true);
  const [syncPricing, setSyncPricing] = useState(false);
  const [autoConfirm, setAutoConfirm] = useState(false);
  return (
    <IntegrationSetupPanel
      eyebrow="provider integration"
      title="Bokun integration"
      subtitle="A setup workspace for external provider credentials and sync controls without sharing secret storage or provider API behavior."
      logo="B"
      badges={[
        { id: "provider", label: "provider setup", tone: "info" },
        { id: "sync", label: "sync controls", tone: "accent" },
        { id: "review", label: "review surface", tone: "success" },
      ]}
      status={{
        label: "Connected to Bokun",
        detail: "Credentials were accepted and availability sync is enabled.",
        tone: "connected",
        action: (
          <Button variant="ghost" size="sm" type="button">
            Disconnect
          </Button>
        ),
      }}
      messages={[
        {
          id: "saved",
          tone: "success",
          icon: <CheckCircle2 size={16} />,
          children: "Credentials saved. Consuming apps own persistence, validation and connection tests.",
        },
      ]}
      metrics={integrationSetupMetrics}
      actions={
        <>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
          <Button variant="ghost" size="sm" type="button">
            <ExternalLink size={15} />
            Provider docs
          </Button>
        </>
      }
      onSubmit={(event) => event.preventDefault()}
      sections={[
        {
          id: "credentials",
          title: "API credentials",
          description: "Credential controls are supplied by the product so secret handling stays local.",
          icon: <KeyRound size={16} />,
          actions: (
            <Button variant="ghost" size="sm" type="button" onClick={() => setSecretVisible((visible) => !visible)}>
              {secretVisible ? "Hide secret" : "Show secret"}
            </Button>
          ),
          fields: [
            {
              id: "access-key",
              label: "Access key",
              required: true,
              control: (
                <div className="ui-input-icon">
                  <KeyRound size={16} aria-hidden="true" />
                  <Input
                    value={accessKey}
                    onChange={(event) => setAccessKey(event.target.value)}
                    autoComplete="off"
                  />
                </div>
              ),
              hint: "Found in the provider account API settings.",
            },
            {
              id: "secret-key",
              label: "Secret key",
              required: true,
              control: (
                <div className="ui-input-icon">
                  <Lock size={16} aria-hidden="true" />
                  <Input
                    type={secretVisible ? "text" : "password"}
                    value={secretKey}
                    onChange={(event) => setSecretKey(event.target.value)}
                    autoComplete="new-password"
                  />
                </div>
              ),
              hint: "Masking, vault storage and rotation policies belong to the consuming app.",
            },
            {
              id: "channel",
              label: "Channel ID",
              meta: "optional",
              control: (
                <div className="ui-input-icon">
                  <Link2 size={16} aria-hidden="true" />
                  <Input value={channel} onChange={(event) => setChannel(event.target.value)} />
                </div>
              ),
            },
            {
              id: "vendor",
              label: "Vendor ID",
              meta: "optional",
              control: (
                <div className="ui-input-icon">
                  <Link2 size={16} aria-hidden="true" />
                  <Input value={vendor} onChange={(event) => setVendor(event.target.value)} />
                </div>
              ),
            },
          ],
        },
        {
          id: "sync",
          title: "Sync settings",
          description: "Each toggle is controlled by product state and can map to provider-specific permissions.",
          icon: <RefreshCw size={16} />,
          toggles: [
            {
              id: "products",
              label: "Sync products and tours",
              description: "Import and keep the provider tour catalog aligned with the local marketplace.",
              checked: syncProducts,
              onChange: setSyncProducts,
            },
            {
              id: "availability",
              label: "Sync availability",
              description: "Refresh calendar availability from the provider system.",
              checked: syncAvailability,
              onChange: setSyncAvailability,
            },
            {
              id: "pricing",
              label: "Sync pricing",
              description: "Allow provider prices to override manually configured marketplace pricing.",
              checked: syncPricing,
              onChange: setSyncPricing,
            },
            {
              id: "confirm",
              label: "Auto-confirm bookings",
              description: "Confirm marketplace bookings in the provider system after local checks pass.",
              checked: autoConfirm,
              onChange: setAutoConfirm,
            },
          ],
        },
      ]}
      footer={
        <>
          <Button variant="danger" type="button">
            <PlugZap size={16} />
            Test connection
          </Button>
          <Button type="submit">
            <CheckCircle2 size={16} />
            Save integration
          </Button>
        </>
      }
    />
  );
}

export function ProjectSettingsPanelDemo() {
  const [summaryEmail, setSummaryEmail] = useState("owner@example.lt");
  const [titleTemplate, setTitleTemplate] = useState("[SCORE-WORK] {title}");
  const [sendTitle, setSendTitle] = useState("UI Framework extraction");
  const [configJson, setConfigJson] = useState(
    '{\n  "auth": {\n    "providers": {\n      "google": {\n        "GOOGLE_CLIENT_ID": "public-client-id.apps.googleusercontent.com"\n      }\n    }\n  },\n  "summary": {\n    "enabled": true\n  }\n}',
  );
  return (
    <ProjectSettingsPanel
      eyebrow="runtime settings"
      title="Project settings"
      subtitle="Non-source changeable values are edited in the project store while secrets stay in the vault and public config is fetched at runtime."
      icon={<SlidersHorizontal size={22} />}
      status="admin gated"
      statusTone="success"
      badges={[
        { id: "source", label: "settings pattern", tone: "info" },
        { id: "digest", label: "summary digest", tone: "accent" },
        { id: "secrets", label: "no secrets", tone: "warning" },
      ]}
      stats={projectSettingsStats}
      notices={[
        {
          id: "ownership",
          title: "Product code owns persistence and validation",
          description:
            "The shared panel only renders the settings surface; APIs, JSON parsing, seeding, public endpoints, email delivery and toasts stay local.",
          tone: "info",
          icon: <Database size={17} />,
        },
      ]}
      actions={
        <>
          <Button type="button" variant="secondary" size="sm">
            <RefreshCw size={15} />
            Reload
          </Button>
          <Button type="button" size="sm">
            <CheckCircle2 size={15} />
            Save settings
          </Button>
        </>
      }
      summary={{
        title: "Status summary digest",
        description: "Recipient, subject template and message buffer controls for agent-to-owner summaries.",
        updatedAt: "Updated 2026-06-28 03:30 UTC",
        recipientControl: {
          label: "Summary email",
          required: true,
          control: (
            <Input type="email" value={summaryEmail} onChange={(event) => setSummaryEmail(event.target.value)} />
          ),
        },
        titleTemplateControl: {
          label: "Title template",
          hint: "Supports {title} and {date}; rendering stays product-owned.",
          control: <Input value={titleTemplate} onChange={(event) => setTitleTemplate(event.target.value)} />,
        },
        sendTitleControl: {
          label: "Send title",
          wide: true,
          control: <Input value={sendTitle} onChange={(event) => setSendTitle(event.target.value)} />,
        },
        log: "2026-06-28 03:12 ToastStack extracted and deployed.\n2026-06-28 03:30 ProjectSettingsPanel extracted for review.",
        actions: (
          <>
            <Button type="button" variant="secondary" size="sm">
              <Mail size={15} />
              Send now
            </Button>
            <Button type="button" variant="ghost" size="sm">
              Clear log
            </Button>
          </>
        ),
      }}
      config={{
        title: "Config JSON",
        description: "A free-form object for public client IDs, templates and other non-secret settings.",
        meta: [
          { id: "scope", label: "Storage", value: "project data store" },
          { id: "public-config", label: "Public config", value: "served from a runtime endpoint" },
          { id: "secret-policy", label: "Secret policy", value: "reference vault names only" },
        ],
        editor: (
          <textarea
            spellCheck={false}
            value={configJson}
            onChange={(event) => setConfigJson(event.target.value)}
            aria-label="Project settings config JSON"
          />
        ),
        validation:
          "Consuming apps parse and validate JSON before save. Build-time VITE values remain fallback-only.",
        actions: (
          <Button type="button" variant="secondary" size="sm">
            <Eye size={15} />
            Preview public config
          </Button>
        ),
      }}
      footer={
        <>
          <Badge tone="info">presentational</Badge>
          <span>Routing, RBAC, seed-from-env behavior, audit logging, SMTP delivery and notifications stay product-owned.</span>
        </>
      }
    />
  );
}

export function PaymentAccountPanelDemo() {
  return (
    <PaymentAccountPanel
      eyebrow="payment workspace"
      title="Traveler and provider payments"
      subtitle="eLitua payment components share a larger account surface without sharing Stripe runtime, proxy calls or currency rules."
      summaryLabel="Checkout total"
      summaryValue="324.00 EUR"
      summaryDetail="Accommodation deposit plus guide booking"
      stats={paymentAccountStats}
      methods={paymentMethods.map((method) => ({
        ...method,
        actions: (
          <>
            {!method.isDefault ? (
              <Button variant="secondary" size="sm" type="button">
                Set default
              </Button>
            ) : null}
            <Button variant="ghost" size="sm" type="button">
              Remove
            </Button>
          </>
        ),
      }))}
      payments={paymentHistoryRows}
      payouts={payoutRows}
      actions={
        <>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
          <Button size="sm" type="button">
            <ReceiptText size={15} />
            Invoice
          </Button>
        </>
      }
      checkout={
        <PaymentCheckoutPanel
          amount="324.00 EUR"
          amountDetail="Accommodation deposit plus guide booking"
          onSubmit={(event) => event.preventDefault()}
          providerSlot={
            <div className="payment-checkout-provider-demo payment-checkout-provider-demo--compact">
              <div>
                <span>Card number</span>
                <strong>4242 4242 4242 4242</strong>
              </div>
              <div>
                <span>Security</span>
                <strong>3DS ready</strong>
              </div>
            </div>
          }
          submitLabel="Pay securely"
        />
      }
    />
  );
}

export function MarkdownDocumentPanelDemo() {
  return (
    <MarkdownDocumentPanel
      eyebrow="task document"
      title="UI Framework extraction notes"
      description="Score task documents can share a neutral markdown preview while task loading, generated content, permissions and workflow actions remain product-owned."
      icon={<FileText size={24} />}
      badges={[
        { id: "status", label: "review-ready", tone: "success" },
        { id: "format", label: "markdown", tone: "info" },
      ]}
      meta={markdownDocumentMeta}
      markdown={scoreTaskDocumentMarkdown}
      actions={
        <>
          <Button variant="secondary" size="sm" type="button">
            <Eye size={15} />
            Preview
          </Button>
          <Button
            variant="ghost"
            size="sm"
            type="button"
            onClick={() => downloadMarkdown("ui-framework-extraction-notes", scoreTaskDocumentMarkdown)}
          >
            <Download size={15} />
            Download
          </Button>
        </>
      }
      footer={
        <>
          <Badge tone="info">sanitized</Badge>
          <span>Parser, sanitizer, filenames, routes, permissions, generated content and toast behavior stay replaceable by consumers.</span>
        </>
      }
    />
  );
}

export function MediaAssetPanelDemo() {
  const [selectedAssetId, setSelectedAssetId] = useState("score-task-markdown");
  const [uploadLabel, setUploadLabel] = useState("No task file selected");
  return (
    <MediaAssetPanel
      eyebrow="media management"
      title="Task and profile media"
      subtitle="Score task attachments and eLitua picture/profile uploads share the same asset review structure while transport and persistence stay product-owned."
      status="review-ready"
      statusTone="success"
      stats={mediaAssetStats}
      assets={mediaAssetItems.map((asset) => ({
        ...asset,
        selected: asset.id === selectedAssetId,
        actions: (
          <>
            <Button variant="ghost" size="sm" type="button">
              <ExternalLink size={15} />
              Open
            </Button>
            <Button variant="ghost" size="sm" type="button">
              <Trash2 size={15} />
              Delete
            </Button>
          </>
        ),
      }))}
      upload={{
        label: "Upload asset",
        description: "File selection can compose FileUploadControl while upload transport stays product-owned.",
        acceptLabel: "PNG, JPG, MD",
        action: (
          <FileUploadControl
            accept="image/*,.md"
            acceptLabel="image/*, .md"
            density="compact"
            label="Choose file"
            selectedLabel={uploadLabel}
            resetOnSelect
            onFilesAdded={(files, selection) =>
              setUploadLabel(`${selection.source}: ${files[0]?.name ?? "No task file selected"}`)
            }
          />
        ),
      }}
      actions={
        <Button variant="secondary" size="sm" type="button">
          <RefreshCw size={15} />
          Refresh
        </Button>
      }
      error="One uploaded profile image is waiting for moderation; policy checks remain product-owned."
      onAssetSelect={setSelectedAssetId}
    />
  );
}
