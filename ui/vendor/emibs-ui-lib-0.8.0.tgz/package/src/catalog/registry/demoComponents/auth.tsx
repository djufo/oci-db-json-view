import { useState } from "react";
import {
  ArrowLeft,
  Bell,
  CheckCircle2,
  ExternalLink,
  KeyRound,
  Mail,
  RefreshCw,
  ShieldCheck,
  Trash2,
  UserRound,
} from "lucide-react";
import { AccountMenu } from "../../../components/auth/AccountMenu";
import { AccountProfilePanel } from "../../../components/auth/AccountProfilePanel";
import { AccountSessionsPanel } from "../../../components/auth/AccountSessionsPanel";
import {
  AuthAccessPanel,
  AuthFieldRow,
  AuthInputField,
  AuthStrengthMeter,
} from "../../../components/auth/AuthAccessPanel";
import { AuthStatusPanel } from "../../../components/auth/AuthStatusPanel";
import { PasswordRevealButton } from "../../../components/auth/PasswordRevealButton";
import { SessionRefreshDialog } from "../../../components/auth/SessionRefreshDialog";
import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import { Input, Select, Textarea } from "../../../components/primitives/Field";
import {
  accountProfileBadges,
  accountProfileLinks,
  accountProfileStats,
  accountSessions,
  elituaAuthProviders,
  scoreAuthProviders,
} from "../../../demos/data";

export function AccountMenuRegistryDemo({ guest = false }: { guest?: boolean }) {
  const [open, setOpen] = useState(true);
  const sections = [
    {
      id: "account",
      label: "Account",
      items: [
        {
          id: "profile",
          label: "My profile",
          description: "Identity and account details",
          href: "#/c/account-profile-panel",
          icon: <UserRound size={16} />,
          current: true,
        },
        {
          id: "sessions",
          label: "Sessions",
          description: "Review active devices",
          href: "#/c/account-sessions-panel",
          icon: <KeyRound size={16} />,
        },
      ],
    },
    {
      id: "workspace",
      label: "Workspace",
      items: [
        {
          id: "settings",
          label: "Account settings",
          description: "Preferences and notifications",
          href: "#/c/account-profile-panel",
          icon: <ShieldCheck size={16} />,
        },
        {
          id: "sign-out",
          label: "Sign out",
          icon: <ExternalLink size={16} />,
          tone: "danger" as const,
          onSelect: () => setOpen(false),
        },
      ],
    },
  ];

  return (
    <div className="account-menu-demo-grid">
      <article className="account-menu-demo-card">
        <p>
          The shared menu owns trigger, identity, section, current-link, and
          guest action chrome while auth state and route handling stay local.
        </p>
        <div className="account-menu-demo-topbar">
          <div className="account-menu-demo-title">
            <strong>{guest ? "Guest account" : "Authenticated account"}</strong>
            <span>{guest ? "Sign-in actions are supplied by the product." : "Role-filtered account links stay product-owned."}</span>
          </div>
          <AccountMenu
            open={open}
            onOpenChange={setOpen}
            identity={
              guest
                ? undefined
                : {
                    name: "Ruta Travels",
                    secondary: "ruta@example.lt",
                    initials: "RT",
                    role: "Guide",
                    roleTone: "success",
                  }
            }
            sections={guest ? [] : sections}
            guestTitle="Account"
            guestDescription="Sign in to save routes, preferences, and active sessions."
            guestActions={[
              { id: "login", label: "Log in", href: "#/c/auth-access-panel", icon: <KeyRound size={16} /> },
              { id: "register", label: "Create account", href: "#/c/auth-access-panel", icon: <UserRound size={16} /> },
            ]}
          />
        </div>
      </article>
    </div>
  );
}

export function AuthAccessRegistryDemo({ mode = "operator" }: { mode?: "operator" | "portal" | "recovery" }) {
  const [passwordVisible, setPasswordVisible] = useState(false);

  if (mode === "recovery") {
    return (
      <div className="auth-demo-grid">
        <AuthAccessPanel
          eyebrow={<CheckCircle2 size={42} aria-hidden="true" />}
          title="Check your email"
          subtitle={
            <>
              A password reset link was sent to <strong>ruta@example.lt</strong>.
            </>
          }
          actions={
            <>
              <Button type="button">Try again</Button>
              <Button type="button" variant="secondary">
                <ArrowLeft size={15} />
                Back to login
              </Button>
            </>
          }
          footer={<span>Request timing, resend throttling, route links, and copy stay in the consuming app.</span>}
        />
      </div>
    );
  }

  if (mode === "operator") {
    return (
      <div className="auth-demo-grid">
        <AuthAccessPanel
          variant="operator"
          eyebrow="Score operator"
          title="Sign in to Score"
          subtitle="Use a provider session or development token without moving token exchange into the shared panel."
          message={{ tone: "info", children: "Session refresh, validation, and storage stay product-owned." }}
          providerSlot={
            <button className="ui-auth-provider ui-auth-provider--featured" type="button">
              <ShieldCheck size={18} />
              <span>Google Identity Services slot</span>
            </button>
          }
          dividerLabel="or use development access"
          footer={<span>Auth redirect, token persistence, and toast behavior stay in the app.</span>}
        >
          <div className="auth-demo-form">
            <AuthInputField
              id="registry-score-token"
              label="Development token"
              type="password"
              value="dev-admin-token"
              readOnly
              icon={<KeyRound size={18} />}
              hint="The consuming app supplies validation and submit handling."
            />
            <Button type="button">Continue</Button>
          </div>
        </AuthAccessPanel>
      </div>
    );
  }

  return (
    <div className="auth-demo-grid">
      <AuthAccessPanel
        eyebrow="eLitua traveler"
        title="Create account"
        subtitle="Review provider actions, email fields, password reveal, and strength feedback."
        providers={elituaAuthProviders}
        dividerLabel="or register with email"
        footer={<span>Already have an account? <a href="#/c/auth-access-panel">Log in</a></span>}
      >
        <div className="auth-demo-form">
          <AuthFieldRow>
            <AuthInputField id="registry-auth-name" label="Display name" value="Ruta Travels" readOnly icon={<UserRound size={18} />} />
            <AuthInputField id="registry-auth-email" label="Email" value="ruta@example.lt" readOnly icon={<Mail size={18} />} />
          </AuthFieldRow>
          <AuthInputField
            id="registry-auth-password"
            label="Password"
            type={passwordVisible ? "text" : "password"}
            value="BalticRoute26!"
            readOnly
            icon={<KeyRound size={18} />}
            action={<PasswordRevealButton visible={passwordVisible} onVisibleChange={setPasswordVisible} />}
            after={<AuthStrengthMeter score={3} tone="success" label="Strong password" hint="Meets length and mixed character guidance." />}
          />
          <p className="auth-demo-terms">Terms, privacy copy, validation, and submission remain product-owned.</p>
          <Button type="button">Create account</Button>
        </div>
      </AuthAccessPanel>
    </div>
  );
}

export function PasswordRevealRegistryDemo({ initialVisible = false }: { initialVisible?: boolean }) {
  const [visible, setVisible] = useState(initialVisible);
  return (
    <div className="auth-demo-form" style={{ maxWidth: 420 }}>
      <AuthInputField
        id="registry-password-reveal"
        label="Password"
        type={visible ? "text" : "password"}
        value="BalticRoute26!"
        readOnly
        icon={<KeyRound size={18} />}
        action={<PasswordRevealButton visible={visible} onVisibleChange={setVisible} />}
        hint="The button only controls visibility; auth policy stays in the product."
      />
    </div>
  );
}

export function SessionRefreshRegistryDemo({ initiallyOpen = true }: { initiallyOpen?: boolean }) {
  const [open, setOpen] = useState(initiallyOpen);
  const [token, setToken] = useState("dev-admin-token");

  return (
    <div className="session-refresh-dialog-demo-shell">
      <div className="session-refresh-dialog-demo-page">
        <div>
          <h3>Protected workspace</h3>
          <p>Unsaved edits and route context remain visible while the product obtains a fresh session.</p>
        </div>
        <Badge tone={open ? "warning" : "success"}>{open ? "Refresh required" : "Session valid"}</Badge>
        <Button type="button" variant="secondary" onClick={() => setOpen(true)}>
          <KeyRound size={16} />
          Refresh session
        </Button>
      </div>
      <SessionRefreshDialog
        open={open}
        placement="contained"
        eyebrow="Score operator"
        title="Sign in again"
        subtitle="Refresh your session without losing current page context."
        message={{ tone: "info", children: "The current page stays open while credentials are collected." }}
        providers={scoreAuthProviders}
        dividerLabel="Development access"
        footer={<Button type="button" variant="ghost" onClick={() => setOpen(false)}>Dismiss</Button>}
        onClose={() => setOpen(false)}
      >
        <form className="session-refresh-dialog-demo-form" onSubmit={(event) => event.preventDefault()}>
          <AuthInputField
            autoComplete="off"
            icon={<KeyRound size={18} />}
            id="registry-session-refresh-token"
            label="Development token"
            onChange={(event) => setToken(event.target.value)}
            type="password"
            value={token}
          />
          <Button disabled={token.trim() === ""} type="submit">Continue</Button>
        </form>
      </SessionRefreshDialog>
    </div>
  );
}

export function AuthStatusRegistryDemo({ state = "all" }: { state?: "all" | "loading" | "success" | "no-access" | "error" }) {
  if (state === "loading") {
    return <AuthStatusPanel eyebrow="OAuth callback" title="Completing login" subtitle="Provider tokens are being exchanged by the product." tone="loading" />;
  }
  if (state === "success") {
    return (
      <AuthStatusPanel
        eyebrow="Email verification"
        title="Email verified"
        subtitle="The consuming app owns account activation and redirect timing."
        tone="success"
        actions={<Button type="button">Go to home</Button>}
      />
    );
  }
  if (state === "no-access") {
    return (
      <AuthStatusPanel
        eyebrow="Score operator"
        title="No project access"
        subtitle="The actor is authenticated, but project membership is still required."
        tone="info"
        variant="operator"
        actions={<Button type="button" variant="secondary">Refresh session</Button>}
      >
        <dl className="auth-status-demo-details">
          <div><dt>Actor</dt><dd>guest@example.test</dd></div>
          <div><dt>Required grant</dt><dd>Project access</dd></div>
        </dl>
      </AuthStatusPanel>
    );
  }
  if (state === "error") {
    return <AuthStatusPanel title="Session expired" subtitle="Retry and recovery actions are supplied by the product." tone="danger" />;
  }
  return (
    <div className="auth-status-demo-grid">
      <AuthStatusRegistryDemo state="loading" />
      <AuthStatusRegistryDemo state="success" />
      <AuthStatusRegistryDemo state="no-access" />
    </div>
  );
}

export function AccountSessionsRegistryDemo({ state = "default" }: { state?: "default" | "loading" | "empty" | "error" }) {
  const sessions = state === "empty" ? [] : accountSessions.map((session) => ({
    ...session,
    action: session.current ? (
      <Badge tone="success">Protected</Badge>
    ) : (
      <Button variant="ghost" size="sm" type="button">
        <Trash2 size={15} />
        Revoke
      </Button>
    ),
  }));

  return (
    <AccountSessionsPanel
      eyebrow="account security"
      title="Active sessions"
      subtitle="Device summaries, current-session state, and actions render here while revocation APIs stay local."
      status={state === "empty" ? "0 active" : "3 active"}
      statusTone={state === "empty" ? "neutral" : "info"}
      loading={state === "loading"}
      error={state === "error" ? "One tablet session has not refreshed recently; stale-session policy stays product-owned." : undefined}
      sessions={sessions}
      actions={
        <>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
          <Button variant="danger" size="sm" type="button">
            <Trash2 size={15} />
            Revoke others
          </Button>
        </>
      }
    />
  );
}

export function AccountProfileRegistryDemo({ compact = false }: { compact?: boolean }) {
  const [displayName, setDisplayName] = useState("Ruta Travels");
  const [email, setEmail] = useState("ruta@example.lt");
  const [notifyFrequency, setNotifyFrequency] = useState("daily");
  const [bio, setBio] = useState("Licensed Vilnius guide focused on families, food routes, and slow cultural walks.");

  return (
    <AccountProfilePanel
      avatar="RT"
      avatarLabel="Ruta Travels account"
      eyebrow="authenticated account"
      title={displayName}
      subtitle={compact ? "Compact account identity review." : "Identity, verification, preferences, and provider profile sections stay presentational."}
      badges={accountProfileBadges}
      stats={compact ? accountProfileStats.slice(0, 2) : accountProfileStats}
      notices={compact ? [] : [
        {
          id: "verification",
          tone: "warning",
          icon: <Mail size={18} />,
          title: "Email verification required for marketplace actions",
          description: "Verification delivery, expiration, and retry limits stay in the consuming app.",
          action: <Button type="button" variant="secondary" size="sm">Resend</Button>,
        },
      ]}
      actions={
        <>
          <Button type="button" variant="secondary" size="sm"><RefreshCw size={15} />Refresh</Button>
          <Button type="submit" size="sm"><CheckCircle2 size={15} />Save profile</Button>
        </>
      }
      sections={[
        {
          id: "identity",
          title: "Account identity",
          description: "Products own profile loading, validation, localization, and persistence.",
          badge: { id: "score", label: "shared chrome", tone: "info" },
          fields: [
            {
              id: "display-name",
              label: "Display name",
              icon: <UserRound size={15} />,
              control: <Input value={displayName} onChange={(event) => setDisplayName(event.target.value)} />,
            },
            {
              id: "email",
              label: "Email",
              icon: <Mail size={15} />,
              control: <Input type="email" value={email} onChange={(event) => setEmail(event.target.value)} />,
            },
            {
              id: "notify",
              label: "Email frequency",
              icon: <Bell size={15} />,
              control: (
                <Select value={notifyFrequency} onChange={(event) => setNotifyFrequency(event.target.value)}>
                  <option value="immediate">Immediate</option>
                  <option value="hourly">Hourly</option>
                  <option value="daily">Daily</option>
                </Select>
              ),
            },
            ...(compact ? [] : [
              {
                id: "bio",
                label: "Profile bio",
                control: (
                  <Textarea
                    rows={4}
                    value={bio}
                    onChange={(event) => setBio(event.target.value)}
                  />
                ),
                wide: true,
              },
            ]),
          ],
        },
      ]}
      secondaryLinks={accountProfileLinks}
      footer="Auth context, verification email, password routes, session revocation, and profile mutations remain product-owned."
      onSubmit={(event) => event.preventDefault()}
    />
  );
}
