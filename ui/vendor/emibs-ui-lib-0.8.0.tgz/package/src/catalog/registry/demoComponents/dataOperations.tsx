// Catalog Explorer — demo helpers for Score operations panels (queues,
// schedulers, process runs, work items and command surfaces).
import { useState } from "react";
import {
  ArrowRight,
  Bot,
  Database,
  ExternalLink,
  Link2,
  PanelRightOpen,
  Pencil,
  Plus,
  RefreshCw,
  SlidersHorizontal,
  X,
} from "lucide-react";
import { ActivityDashboard } from "../../../components/data/ActivityDashboard";
import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import {
  ChecklistEditorPanel,
  type ChecklistEditorItem,
} from "../../../components/data/ChecklistEditorPanel";
import { CommandConsole } from "../../../components/data/CommandConsole";
import { OperationalDiagnosticPanel } from "../../../components/data/OperationalDiagnosticPanel";
import { ProcessRunHistoryPanel } from "../../../components/data/ProcessRunHistoryPanel";
import { ScheduleEditorDialog } from "../../../components/data/ScheduleEditorDialog";
import { SchedulerControlPanel } from "../../../components/data/SchedulerControlPanel";
import { WorkBoardToolbar, type WorkBoardToolbarActiveFilter } from "../../../components/data/WorkBoardToolbar";
import { WorkItemCard } from "../../../components/data/WorkItemCard";
import { WorkItemPlanningPanel } from "../../../components/data/WorkItemPlanningPanel";
import { WorkItemTracePanel } from "../../../components/data/WorkItemTracePanel";
import { WorkflowCommandBar } from "../../../components/data/WorkflowCommandBar";
import {
  activityDashboardItems,
  activityDashboardMetrics,
  activityDashboardQueues,
  commandConsoleMessages,
  commandConsoleSessions,
  operationalDiagnosticDetails,
  operationalDiagnosticMetrics,
  processRunHistoryItems,
  schedulerControlItems,
  workBoardEpicOptions,
  workBoardProjectOptions,
  workBoardToolbarBadges,
  workItemActorOptions,
  workItemCards,
  workItemComplexityOptions,
  workItemEpicOptions,
  workItemProjectOptions,
  workItemRoleOptions,
  workItemTraceNotes,
  workItemTraceRelationGroups,
  workItemTypeOptions,
  workflowCommandBarCommands,
  workflowReleaseCommands,
} from "../../../demos/data";

export function ActivityDashboardDemo() {
  return (
    <ActivityDashboard
      eyebrow="live orchestration"
      title="Score activity"
      subtitle="A focused operator surface for board pressure, worker health and recently updated work items."
      status="refresh ready"
      statusTone="success"
      queues={activityDashboardQueues}
      metrics={activityDashboardMetrics}
      items={activityDashboardItems}
      error="2 stalled tasks need reviewer attention."
      actions={
        <>
          <Badge tone="info">manual refresh</Badge>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
        </>
      }
    />
  );
}

export function SchedulerControlPanelDemo() {
  const [schedulerRows, setSchedulerRows] = useState(schedulerControlItems);
  const [busySchedulerId, setBusySchedulerId] = useState<string | null>(null);
  const toggleScheduler = (schedulerId: string, enabled: boolean) => {
    setBusySchedulerId(schedulerId);
    setSchedulerRows((rows) =>
      rows.map((scheduler) => (scheduler.id === schedulerId ? { ...scheduler, enabled } : scheduler)),
    );
    window.setTimeout(() => setBusySchedulerId(null), 450);
  };
  return (
    <SchedulerControlPanel
      eyebrow="host automation"
      title="Scheduled jobs"
      subtitle="Score exposes reviewed cron-backed jobs while command execution, API persistence and local guard checks stay product-owned."
      status={`${schedulerRows.filter((scheduler) => scheduler.enabled).length} of ${schedulerRows.length} enabled`}
      statusTone="info"
      schedulers={schedulerRows}
      busySchedulerId={busySchedulerId}
      error="One disabled job is held for manual review; the consuming app owns audit and confirmation behavior."
      actions={
        <Button variant="secondary" size="sm" type="button">
          <RefreshCw size={15} />
          Refresh
        </Button>
      }
      onToggleScheduler={(scheduler, enabled) => toggleScheduler(scheduler.id, enabled)}
    />
  );
}

export function ProcessRunHistoryPanelDemo() {
  return (
    <ProcessRunHistoryPanel
      eyebrow="scheduler logs"
      title="Recent runs"
      subtitle="Score owns log retention, command authorization, date formatting, output redaction, persistence, audit events and toasts."
      status={`${processRunHistoryItems.length} runs`}
      statusTone="info"
      runs={processRunHistoryItems}
      error="Demo state: failed runs are visible here, while Score owns escalation policy and retry actions."
      actions={
        <>
          <Badge tone="success">exit-code aware</Badge>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
        </>
      }
      footer="Use compact density inside scheduler cards and comfortable density for dedicated process/job detail pages."
    />
  );
}

export function ScheduleEditorDialogDemo() {
  const [open, setOpen] = useState(true);
  const [enabled, setEnabled] = useState(true);
  const [suspended, setSuspended] = useState(false);
  const [pattern, setPattern] = useState("*/3 * * * *");
  const [firstStart, setFirstStart] = useState("2026-06-28T08:15");
  const [fields, setFields] = useState<Record<string, string>>({
    nudgerId: "maestro-ui-framework-extract",
    displayName: "UI Framework extraction nudge",
    description: "Extract exactly one reusable UI pattern into emibs-ui-lib.",
    assignedAgent: "agent-codex-maestro",
    projectKey: "score",
    workflow: "ui-framework",
    prompt: "Inspect Score and eLitua, then extract the next review-ready scheduler or UI framework surface.",
  });
  const updateField = (fieldId: string, value: string) => {
    setFields((current) => ({ ...current, [fieldId]: value }));
  };
  return (
    <div className="schedule-editor-dialog-demo-shell">
      <div className="schedule-editor-dialog-demo-page">
        <div>
          <Badge tone="info">settings modal</Badge>
          <h3>UI Framework extraction nudge</h3>
          <p>
            Score's scheduler page can share this edit surface while Score keeps catalog validation,
            date conversion, persistence, audit events, host execution policy and toasts local.
          </p>
        </div>
        <div className="schedule-editor-dialog-demo-actions">
          <Button type="button" onClick={() => setOpen(true)}>
            <Pencil size={16} />
            Edit schedule
          </Button>
          <Button type="button" variant="secondary" onClick={() => setOpen(true)}>
            Preview dialog
          </Button>
        </div>
      </div>
      <ScheduleEditorDialog
        open={open}
        placement="contained"
        eyebrow="host automation"
        title={fields.displayName}
        subtitle="Mutable scheduler and nudger settings remain controlled by the consuming app."
        enabled={enabled}
        schedule={pattern}
        firstStartAt={firstStart}
        meta={[
          { id: "scheduler-id", label: "Scheduler", value: "maestro-ui-framework-extract" },
          { id: "runner", label: "Runner", value: "maestro-runner" },
          { id: "workflow", label: "Workflow", value: "ui-framework" },
        ]}
        checks={[
          {
            id: "suspended",
            label: "Suspended",
            checked: suspended,
            hint: "Score decides whether suspended jobs can be requested.",
            onChange: setSuspended,
          },
        ]}
        fields={[
          {
            id: "nudgerId",
            label: "ID",
            value: fields.nudgerId,
            placeholder: "generated when blank",
            hint: "Optional stable id for database-backed nudgers.",
          },
          {
            id: "displayName",
            label: "Name",
            value: fields.displayName,
            required: true,
          },
          {
            id: "description",
            label: "Description",
            value: fields.description,
          },
          {
            id: "assignedAgent",
            label: "Agent",
            value: fields.assignedAgent,
            control: "select",
            options: [
              { value: "agent-codex-maestro", label: "Codex Maestro" },
              { value: "agent-codex-agent", label: "Codex Engineer" },
              { value: "agent-claude-architect", label: "Claude Architect" },
            ],
            required: true,
          },
          {
            id: "projectKey",
            label: "Product",
            value: fields.projectKey,
            control: "select",
            options: [
              { value: "score", label: "Score" },
              { value: "elitua", label: "eLitua" },
              { value: "emibs", label: "EMIBS" },
            ],
            required: true,
          },
          {
            id: "workflow",
            label: "Workflow",
            value: fields.workflow,
          },
          {
            id: "prompt",
            label: "Prompt",
            value: fields.prompt,
            control: "textarea",
            rows: 5,
            required: true,
          },
        ]}
        error="Catalog demo only: Score owns validation and save error mapping."
        footer="Cron validation, next-run calculation, API persistence, audit logging and command execution are product-owned."
        scheduleHint="Five fields: minute hour day-of-month month day-of-week."
        firstStartAtHint="Optional local datetime value prepared by the consuming app."
        onClose={() => setOpen(false)}
        onEnabledChange={setEnabled}
        onScheduleChange={setPattern}
        onFirstStartAtChange={setFirstStart}
        onFieldChange={updateField}
        onSubmit={(event) => {
          event.preventDefault();
          setOpen(false);
        }}
      />
    </div>
  );
}

export function CommandConsoleDemo() {
  const [draft, setDraft] = useState("Create the Score refactor follow-up under UI Framework.");
  return (
    <CommandConsole
      title="Maestro"
      sessions={commandConsoleSessions}
      activeSessionId="framework"
      messages={commandConsoleMessages}
      draft={draft}
      onDraftChange={setDraft}
      onSubmit={() => setDraft("")}
      onSessionSelect={() => undefined}
      onNewSession={() => undefined}
      onCloseSession={() => undefined}
      actions={<Badge tone="success">ready</Badge>}
      draftPlaceholder="Prompt Maestro"
      sendLabel="Queue prompt"
    />
  );
}

export function OperationalDiagnosticPanelDemo() {
  return (
    <OperationalDiagnosticPanel
      eyebrow="operations"
      title="Database diagnostics"
      description="Score embeds an Oracle browser while eLitua renders a database health check; the shared component keeps that diagnostic shell presentational."
      icon={<Database size={24} />}
      status={{
        label: "connected",
        tone: "success",
        detail: "Last checked 2026-06-28 02:15 UTC",
      }}
      metrics={operationalDiagnosticMetrics}
      details={operationalDiagnosticDetails}
      embed={{
        title: "Embedded database browser",
        description: "The consuming app owns iframe source, proxy, auth and table selection.",
        srcDoc:
          "<!doctype html><html><body style='margin:0;font-family:system-ui;background:#f8fafc;color:#1f2937'><main style='padding:18px'><h1 style='font-size:18px;margin:0 0 12px'>APP_STATE</h1><table style='width:100%;border-collapse:collapse;font-size:13px'><tr><th style='text-align:left;border-bottom:1px solid #cbd5e1;padding:8px'>KEY</th><th style='text-align:left;border-bottom:1px solid #cbd5e1;padding:8px'>VALUE</th></tr><tr><td style='padding:8px;border-bottom:1px solid #e2e8f0'>score.tasks</td><td style='padding:8px;border-bottom:1px solid #e2e8f0'>{...}</td></tr><tr><td style='padding:8px'>settings.config</td><td style='padding:8px'>{...}</td></tr></table></main></body></html>",
      }}
      resultTitle="Diagnostic result"
      resultDescription="Status copy and result interpretation stay in the product."
      payloadLabel="Sample response"
      payload={'{\n  "status": "success",\n  "message": "database query executed",\n  "checkedAt": "2026-06-28T02:15:00Z"\n}'}
      error="A stale result warning can be rendered without the shared component owning retry policy."
      actions={
        <>
          <Button variant="secondary" size="sm" type="button">
            <RefreshCw size={15} />
            Refresh
          </Button>
          <Button variant="ghost" size="sm" type="button">
            <ExternalLink size={15} />
            Open tool
          </Button>
        </>
      }
      footer={
        <>
          <Badge tone="info">presentational</Badge>
          <span>Fetch, query execution, redaction, iframe routing, localization and audit behavior remain local.</span>
        </>
      }
    />
  );
}

const checklistEditorSeedItems: ChecklistEditorItem[] = [
  {
    id: "build-test",
    text: "Build and test the affected package after updating the shared component.",
    checked: true,
    meta: "Verified before adoption work starts.",
  },
  {
    id: "deploy-verify",
    text: "Deploy the review surface and verify the catalog route.",
    checked: true,
    meta: "Product deploy remains separate.",
  },
  {
    id: "score-update",
    text: "Record the extraction and low-priority adoption task in Score.",
    checked: false,
    meta: "Parented to UI Framework.",
  },
];

export function ChecklistEditorPanelDemo() {
  const [items, setItems] = useState<ChecklistEditorItem[]>(checklistEditorSeedItems);
  return (
    <ChecklistEditorPanel
      eyebrow="project administration"
      title="Definition of done"
      subtitle="Score owns project checklist persistence, autosave, task generation, validation, permissions and routing."
      status={`${items.length} items`}
      statusTone="info"
      items={items}
      footer={
        <>
          <Badge tone="info">controlled rows</Badge>
          <span>Item ids, ordering, save state, duplicate checks and follow-up task creation stay product-owned.</span>
        </>
      }
      onAddItem={() =>
        setItems((current) => [
          ...current,
          {
            id: `custom-${current.length + 1}-${Date.now()}`,
            text: "",
            checked: false,
            placeholder: "Describe the completion criterion",
          },
        ])
      }
      onItemCheckedChange={(itemId, checked) =>
        setItems((current) => current.map((item) => (item.id === itemId ? { ...item, checked } : item)))
      }
      onItemTextChange={(itemId, text) =>
        setItems((current) => current.map((item) => (item.id === itemId ? { ...item, text } : item)))
      }
      onRemoveItem={(itemId) => setItems((current) => current.filter((item) => item.id !== itemId))}
    />
  );
}

export function WorkBoardToolbarDemo() {
  const [search, setSearch] = useState("type:story assignee:codex");
  const [project, setProject] = useState("score");
  const [epic, setEpic] = useState("task-206");
  const [filtersOpen, setFiltersOpen] = useState(true);

  const activeFilters: WorkBoardToolbarActiveFilter[] = [];
  if (project !== "__all_projects__") {
    activeFilters.push({
      id: "project",
      label: `Project: ${workBoardProjectOptions.find((option) => option.value === project)?.label ?? project}`,
      tone: "info",
      removeLabel: "Remove project filter",
      onRemove: () => {
        setProject("__all_projects__");
        setEpic("__all_epics__");
      },
    });
  }
  if (epic !== "__all_epics__") {
    activeFilters.push({
      id: "epic",
      label: `Epic: ${workBoardEpicOptions.find((option) => option.value === epic)?.label ?? epic}`,
      tone: "accent",
      removeLabel: "Remove epic filter",
      onRemove: () => setEpic("__all_epics__"),
    });
  }
  if (search.trim()) {
    activeFilters.push({
      id: "search",
      label: `Search: ${search.trim()}`,
      tone: "success",
      removeLabel: "Remove search filter",
      onRemove: () => setSearch(""),
    });
  }

  return (
    <WorkBoardToolbar
      eyebrow="Score board"
      title="All work"
      subtitle="Route-backed search, project and epic filters stay controlled by the consuming app."
      status="ready"
      statusTone="success"
      badges={workBoardToolbarBadges}
      search={{
        value: search,
        placeholder: "type:bug assignee:codex",
        onChange: setSearch,
      }}
      project={{
        label: "Project",
        value: project,
        options: workBoardProjectOptions,
        onChange: setProject,
      }}
      epic={{
        label: "Epic",
        value: epic,
        options: workBoardEpicOptions,
        onChange: setEpic,
      }}
      filtersOpen={filtersOpen}
      onFiltersOpenChange={setFiltersOpen}
      activeFilters={activeFilters}
      clearFiltersAction={
        <Button
          type="button"
          variant="ghost"
          size="sm"
          disabled={activeFilters.length === 0}
          onClick={() => {
            setProject("__all_projects__");
            setEpic("__all_epics__");
            setSearch("");
          }}
        >
          <X size={15} />
          Reset
        </Button>
      }
      actions={
        <>
          <Button type="button" variant="secondary" size="sm">
            <RefreshCw size={15} />
            Refresh
          </Button>
          <Button type="button" size="sm">
            <Plus size={15} />
            New issue
          </Button>
          <Button type="button" size="sm">
            <Bot size={15} />
            Claim
          </Button>
        </>
      }
      error={search.includes("error") ? "Search parser reported an invalid query." : undefined}
    />
  );
}

export function WorkItemCardGridDemo() {
  return (
    <div className="work-item-card-demo-grid">
      {workItemCards.map((card, index) => (
        <WorkItemCard
          key={String(card.itemId)}
          {...card}
          actions={
            index === 0 ? (
              <>
                <Button type="button" size="sm">
                  <ArrowRight size={15} />
                  Review
                </Button>
                <Button type="button" variant="secondary" size="sm">
                  <PanelRightOpen size={15} />
                  Detail
                </Button>
              </>
            ) : (
              card.actions
            )
          }
        />
      ))}
    </div>
  );
}

export function WorkflowCommandBarDemo() {
  return (
    <div className="workflow-command-demo-grid">
      <WorkflowCommandBar
        eyebrow="Score task"
        title="Processing commands"
        subtitle="Workflow legality, release gates and task transition dispatch remain in Score."
        currentState="processing"
        currentStateTone="warning"
        status="3 commands"
        statusTone="info"
        commands={workflowCommandBarCommands}
        footer={
          <>
            <Badge tone="info">presentational</Badge>
            <span>Use the command descriptors after Score filters moves through actor and project access.</span>
          </>
        }
      />
      <WorkflowCommandBar
        density="compact"
        layout="stack"
        title="Release gate density"
        subtitle="Compact state fits task cards while retaining disabled release-policy copy."
        currentState="review"
        currentStateTone="accent"
        status="release aware"
        statusTone="warning"
        commands={workflowReleaseCommands}
        actions={<Badge tone="warning">direct grant checked locally</Badge>}
      />
    </div>
  );
}

export function WorkItemPlanningPanelDemo() {
  const [workItem, setWorkItem] = useState({
    title: "Refactor Score task detail planning controls",
    type: "story",
    projectKey: "score",
    points: "3",
    priority: "900",
    deliveryRole: "engineer",
    complexity: "medium",
    assignee: "agent-codex-maestro",
    parentEpic: "task-206 - UI Framework",
    agentAllowed: true,
    description:
      "Compose the shared planning panel for edit and triage sections while Score keeps workflow validation local.",
  });
  const [triage, setTriage] = useState({
    points: "3",
    suggestedActor: "agent-codex-maestro",
    note: "Low-risk refactor after the shared component is reviewed in emibs-ui-lib.",
    makeReady: true,
  });
  return (
    <WorkItemPlanningPanel
      eyebrow="Score task detail"
      title="Planning and triage"
      subtitle="A controlled component for the edit and triage sections of Score work items."
      status="review candidate"
      statusTone="accent"
      badges={[
        { id: "metadata", label: "metadata", tone: "info" },
        { id: "triage", label: "triage", tone: "success" },
        { id: "routing", label: "project/epic routes", tone: "warning" },
      ]}
      messages={[
        {
          id: "scope",
          tone: "info",
          children:
            "Score keeps task DTO mapping, workflow validation, project movement confirmation, persistence and toasts local.",
        },
      ]}
      actions={
        <Button type="button" variant="secondary" size="sm">
          <SlidersHorizontal size={15} />
          Controlled
        </Button>
      }
      workItem={workItem}
      triage={triage}
      typeOptions={workItemTypeOptions}
      projectOptions={workItemProjectOptions}
      roleOptions={workItemRoleOptions}
      complexityOptions={workItemComplexityOptions}
      actorOptions={workItemActorOptions}
      epicOptions={workItemEpicOptions}
      canMoveProject
      saveLabel="Save draft"
      triageLabel="Apply triage"
      onWorkItemChange={(field, value) => setWorkItem((current) => ({ ...current, [field]: value }))}
      onTriageChange={(field, value) => setTriage((current) => ({ ...current, [field]: value }))}
      onCancel={() =>
        setWorkItem((current) => ({
          ...current,
          title: "Refactor Score task detail planning controls",
          projectKey: "score",
        }))
      }
      onSave={() => undefined}
      onTriage={() => undefined}
      footer={
        <>
          <Badge tone="info">presentational</Badge>
          <span>Actor lookup, epic validation, legal transitions, review gates and audit events stay product-owned.</span>
        </>
      }
    />
  );
}

export function WorkItemTracePanelDemo() {
  return (
    <WorkItemTracePanel
      eyebrow="Score task detail"
      title="Relations and review trail"
      subtitle="A controlled component for the relation and review-note sections that remain after planning, document and attachment surfaces are extracted."
      status="review candidate"
      statusTone="accent"
      badges={[
        { id: "relations", label: "relations", tone: "info" },
        { id: "reviews", label: "review notes", tone: "success" },
        { id: "routes", label: "route-owned", tone: "warning" },
      ]}
      actions={
        <Button type="button" variant="secondary" size="sm">
          <Link2 size={15} />
          Route slots
        </Button>
      }
      relationGroups={workItemTraceRelationGroups}
      notes={workItemTraceNotes}
      footer={
        <>
          <Badge tone="info">presentational</Badge>
          <span>Review creation, workflow semantics, task routing, permissions, subscriptions and audit events stay product-owned.</span>
        </>
      }
    />
  );
}
