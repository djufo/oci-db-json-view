import { useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowRight,
  Bell,
  Cookie,
  Database,
  ExternalLink,
  GitBranch,
  Mail,
  PanelRightOpen,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  Trash2,
} from "lucide-react";
import { Badge } from "../../../components/primitives/Badge";
import { Button } from "../../../components/primitives/Button";
import { DescriptionList } from "../../../components/primitives/DescriptionList";
import { Input, Select } from "../../../components/primitives/Field";
import { AlertLane, type AlertLaneItem } from "../../../components/feedback/AlertLane";
import { BlastRadiusConfirm } from "../../../components/feedback/BlastRadiusConfirm";
import { blastRadius } from "../../../components/feedback/blastRadius";
import { SectionCard } from "../../../components/layout/SectionCard";
import { StatusIndicator } from "../../../components/primitives/StatusIndicator";
import { AlertDialogFrame, type AlertDialogFrameSize } from "../../../components/feedback/AlertDialogFrame";
import { ConfirmationDialog } from "../../../components/feedback/ConfirmationDialog";
import { CookieConsentBanner } from "../../../components/feedback/CookieConsentBanner";
import { CreationDialog } from "../../../components/feedback/CreationDialog";
import { DataStatePanel } from "../../../components/feedback/DataStatePanel";
import { DialogFrame, type DialogFrameSize } from "../../../components/feedback/DialogFrame";
import { NotificationToggle } from "../../../components/feedback/NotificationToggle";
import { NotificationBell } from "../../../components/feedback/NotificationBell";
import { ActivityCenter, type ActivityCenterItem } from "../../../components/feedback/ActivityCenter";
import { NoticeBanner } from "../../../components/feedback/NoticeBanner";
import { ToastStack } from "../../../components/feedback/ToastStack";
import { ValidationSummary } from "../../../components/feedback/ValidationSummary";
import { toastStackItems, validationSummaryProfileItems, validationSummarySettingsItems } from "../../../demos/data";

export function CookieConsentRegistryDemo({ simple = false }: { simple?: boolean }) {
  const [open, setOpen] = useState(!simple);
  const [preferences, setPreferences] = useState({
    functional: true,
    analytics: false,
    marketing: false,
  });

  const setPreference = (key: keyof typeof preferences, checked: boolean) => {
    setPreferences((current) => ({ ...current, [key]: checked }));
  };

  return (
    <div className={simple ? "cookie-consent-demo-shell cookie-consent-demo-shell--compact" : "cookie-consent-demo-shell"}>
      <div className="cookie-consent-demo-page" aria-hidden="true">
        <h3>{simple ? "Simple consent preview" : "Managed preference preview"}</h3>
        <p>
          {simple
            ? "Accept-all and essential-only actions mirror eLitua's older banner while persistence stays product-owned."
            : "Preference toggles are controlled by the product while the shared component owns the banner and panel chrome."}
        </p>
      </div>
      <CookieConsentBanner
        acceptAllLabel="Accept all"
        description={
          simple
            ? "We use cookies to enhance your experience on eLitua. Some are essential; optional cookies help us improve the portal."
            : "Some cookies are essential for this review surface. Optional categories can be controlled by the consuming app."
        }
        dock="contained"
        icon={<Cookie size={22} />}
        learnMore={<a href="#/c/legal-document-page">Privacy policy</a>}
        onAcceptAll={() => undefined}
        onPreferencesOpenChange={setOpen}
        onRejectNonEssential={() => undefined}
        onSavePreferences={() => setOpen(false)}
        preferencesOpen={open}
        rejectLabel={simple ? "Essential only" : "Reject non-essential"}
        showManageAction={!simple}
        title={simple ? "Cookie notice" : "We use cookies"}
        tone={simple ? "inverse" : "surface"}
        categories={
          simple
            ? []
            : [
                {
                  id: "essential",
                  label: "Essential cookies",
                  description: "Required for authentication, security and basic navigation. Always enabled.",
                  checked: true,
                  locked: true,
                },
                {
                  id: "functional",
                  label: "Functional cookies",
                  description: "Remember locale, theme and route preferences across visits.",
                  checked: preferences.functional,
                  onChange: (checked) => setPreference("functional", checked),
                },
                {
                  id: "analytics",
                  label: "Analytics cookies",
                  description: "Measure usage patterns after consent without owning analytics activation here.",
                  checked: preferences.analytics,
                  onChange: (checked) => setPreference("analytics", checked),
                },
                {
                  id: "marketing",
                  label: "Marketing cookies",
                  description: "Support campaign attribution or advertising tools supplied by the product.",
                  checked: preferences.marketing,
                  onChange: (checked) => setPreference("marketing", checked),
                },
              ]
        }
      />
    </div>
  );
}

export function ToastStackRegistryDemo({ empty = false }: { empty?: boolean }) {
  const [rows, setRows] = useState(empty ? [] : toastStackItems);
  return (
    <div className="toast-stack-demo-shell">
      <div className="toast-stack-demo-page">
        <Badge tone="info">operator feedback</Badge>
        <h3>Notifications stay near the current workflow</h3>
        <p>
          Product code owns queues, dedupe, timers, route links, and delivery while
          the shared stack renders transient status chrome.
        </p>
        <div className="toast-stack-demo-actions">
          <Button type="button" variant="secondary" onClick={() => setRows(toastStackItems)}>
            <Bell size={15} />
            Restore toasts
          </Button>
          <Button type="button" variant="ghost" onClick={() => setRows([])}>
            <Trash2 size={15} />
            Clear
          </Button>
        </div>
      </div>
      <ToastStack
        placement="contained"
        items={rows.map((toast, index) => ({
          ...toast,
          action:
            index === 2 ? (
              <Button type="button" size="sm" variant="ghost">
                <ExternalLink size={14} />
                Open task
              </Button>
            ) : undefined,
          dismissLabel: `Dismiss ${toast.id}`,
          onDismiss: (toastId) => setRows((currentRows) => currentRows.filter((row) => row.id !== toastId)),
        }))}
      />
    </div>
  );
}

export function NoticeBannerRegistryDemo() {
  return (
    <div className="notice-banner-demo-stack">
      <NoticeBanner
        tone="success"
        title="Profile saved successfully"
        action={
          <Button type="button" size="sm" variant="ghost">
            View public profile
            <ExternalLink size={14} />
          </Button>
        }
      >
        Guide and accommodation profile forms can render save confirmation while
        persistence and routing stay product-owned.
      </NoticeBanner>
      <div className="notice-banner-demo-grid">
        <NoticeBanner
          tone="warning"
          icon={<AlertTriangle size={18} />}
          title="Email not verified"
          action={
            <Button type="button" size="sm" variant="secondary">
              <Mail size={14} />
              Resend
            </Button>
          }
        >
          Delivery throttles, account state, and localized copy stay in the
          consuming app.
        </NoticeBanner>
        <NoticeBanner
          tone="danger"
          title="Board data failed to refresh"
          dismissLabel="Dismiss board refresh error"
          onDismiss={() => undefined}
        >
          Score can render the shared alert chrome while retaining API error
          mapping, retry behavior, and toasts.
        </NoticeBanner>
        <NoticeBanner
          density="compact"
          tone="loading"
          title="Refreshing scheduler catalog"
          action={
            <Button type="button" size="sm" variant="ghost">
              <RefreshCw size={14} />
              Retry
            </Button>
          }
        >
          Compact density fits inside dense operator panels and admin toolbars.
        </NoticeBanner>
        <NoticeBanner density="compact" tone="info" title="Project-owned behavior">
          Auth redirects, validation, timers, analytics, and toast queues remain
          outside the presentational banner.
        </NoticeBanner>
      </div>
    </div>
  );
}

export function ValidationSummaryRegistryDemo({ state = "all" }: { state?: "all" | "profile" | "settings" | "success" }) {
  if (state === "profile") {
    return <ValidationSummaryProfileDemo />;
  }

  if (state === "settings") {
    return (
      <div className="validation-summary-demo-card">
        <div className="validation-summary-demo-copy">
          <Badge tone="warning">Score settings</Badge>
          <h3>Configuration validation</h3>
          <p>Score can pass preformatted JSON and relationship issues while its API remains authoritative.</p>
        </div>
        <ValidationSummary
          density="compact"
          tone="warning"
          title="Settings cannot be saved"
          description="Fix the highlighted controls, then submit again."
          items={validationSummarySettingsItems}
          footer="Field focus, hash routing and toast messages are supplied by the consuming app."
        />
      </div>
    );
  }

  if (state === "success") {
    return (
      <div className="validation-summary-demo-card">
        <div className="validation-summary-demo-copy">
          <Badge tone="success">ready</Badge>
          <h3>Submit-ready state</h3>
          <p>The same surface can confirm local checks while product code owns the final save.</p>
        </div>
        <ValidationSummary
          density="compact"
          tone="success"
          title="Ready to submit"
          description="All visible fields pass local checks."
          emptyLabel="No validation issues remain."
        />
      </div>
    );
  }

  return (
    <div className="validation-summary-demo-grid">
      <ValidationSummaryRegistryDemo state="profile" />
      <ValidationSummaryRegistryDemo state="settings" />
      <ValidationSummaryRegistryDemo state="success" />
    </div>
  );
}

export function ValidationSummaryProfileDemo() {
  return (
    <div className="validation-summary-demo-card">
      <div className="validation-summary-demo-copy">
        <Badge tone="danger">eLitua forms</Badge>
        <h3>Profile and integration validation</h3>
        <p>Account, provider, and integration forms can list blocking fields without moving service calls into the library.</p>
      </div>
      <ValidationSummary
        title="Review required fields"
        description="Three fields need attention before this provider profile can be saved."
        items={validationSummaryProfileItems}
        action={
          <Button type="button" size="sm" variant="secondary">
            Save draft
          </Button>
        }
      />
    </div>
  );
}

export function DataStatePanelRegistryDemo({ state = "all" }: { state?: "all" | "empty" | "danger" }) {
  if (state === "empty") {
    return (
      <DataStatePanel
        tone="empty"
        icon={<Search size={26} />}
        title="Guide profile not found"
        description="eLitua keeps route params, profile visibility checks, and translated not-found copy outside the shared component."
        actions={
          <Button type="button" size="sm" variant="secondary">
            Browse guides
            <ArrowRight size={14} />
          </Button>
        }
      />
    );
  }
  if (state === "danger") {
    return (
      <DataStatePanel
        align="start"
        density="compact"
        tone="danger"
        title="Task detail failed to load"
        description="Score can render the panel while keeping API error mapping, permissions, and retry dispatch local."
        actions={
          <Button type="button" size="sm" variant="ghost">
            <RefreshCw size={14} />
            Retry
          </Button>
        }
      />
    );
  }
  return (
    <div className="data-state-demo-stack">
      <DataStatePanel
        tone="loading"
        eyebrow="Score settings"
        title="Loading runtime settings"
        description="The consuming app keeps the Settings API call, JSON validation, and toast mapping local."
        footer="Use comfortable density for route-level or full-panel loading states."
      />
      <div className="data-state-demo-grid">
        <DataStatePanelRegistryDemo state="empty" />
        <DataStatePanelRegistryDemo state="danger" />
      </div>
    </div>
  );
}

export function ConfirmationDialogRegistryDemo({
  busy = false,
  tone = "danger",
}: {
  busy?: boolean;
  tone?: "danger" | "warning" | "info";
}) {
  const [open, setOpen] = useState(true);
  return (
    <div className="confirmation-dialog-demo-shell">
      <div className="confirmation-dialog-demo-page">
        <div>
          <Badge tone={tone === "danger" ? "danger" : "warning"}>controlled dialog</Badge>
          <h3>{tone === "danger" ? "Task attachment controls" : "High-impact confirmation"}</h3>
          <p>
            Product code owns mutations, permissions, translations, and toasts
            while the shared dialog renders the confirmation shell.
          </p>
        </div>
        <div className="confirmation-dialog-demo-actions">
          <Button type="button" variant={tone === "danger" ? "danger" : "secondary"} onClick={() => setOpen(true)}>
            <Trash2 size={16} />
            Preview dialog
          </Button>
        </div>
      </div>
      <ConfirmationDialog
        open={open}
        placement="contained"
        title={tone === "danger" ? "Delete task attachment?" : "Apply release setting?"}
        tone={tone}
        confirmLabel={tone === "danger" ? "Delete" : "Apply"}
        busy={busy}
        busyLabel={tone === "danger" ? "Deleting…" : "Applying…"}
        onCancel={() => setOpen(false)}
        onConfirm={() => setOpen(false)}
      >
        <p>
          {tone === "danger" ? (
            <>
              Delete <strong>ui-framework-notes.md</strong> from this task.
            </>
          ) : (
            "The consuming app owns the write request, audit event, and follow-up toast."
          )}
        </p>
      </ConfirmationDialog>
    </div>
  );
}

export function CreationDialogRegistryDemo({ minimal = false }: { minimal?: boolean }) {
  const [open, setOpen] = useState(true);
  const [draft, setDraft] = useState({
    title: "Extract Score creation dialog",
    type: "story",
    project: "score",
    priority: "900",
    role: "engineer",
    description:
      "Create a review-ready shared modal creation surface while Score keeps task payload mapping, routes, and persistence local.",
  });

  return (
    <div className="creation-dialog-demo-shell">
      <div className="creation-dialog-demo-page">
        <div>
          <Badge tone="info">modal create flow</Badge>
          <h3>{minimal ? "Compact intake surface" : "Board quick-create surface"}</h3>
          <p>
            Score can share the modal structure while routes, option catalogs,
            payload mapping, validation, and submission stay local.
          </p>
        </div>
        <div className="creation-dialog-demo-actions">
          <Button type="button" onClick={() => setOpen(true)}>
            <Plus size={16} />
            New issue
          </Button>
        </div>
      </div>
      <CreationDialog
        open={open}
        placement="contained"
        eyebrow="Score board"
        title="New issue"
        description="A modal create pattern for task, issue, and record intake."
        badges={[
          { id: "route", label: "route-owned", tone: "info" },
          { id: "ready", label: "ready by default", tone: "success" },
        ]}
        sections={[
          {
            id: "identity",
            title: "Identity",
            description: "The shared dialog lays out fields without knowing how a work item is created.",
            fields: [
              {
                id: "title",
                label: "Title",
                required: true,
                wide: true,
                control: (
                  <Input
                    required
                    value={draft.title}
                    onChange={(event) => setDraft({ ...draft, title: event.target.value })}
                  />
                ),
              },
              {
                id: "type",
                label: "Type",
                control: (
                  <Select
                    value={draft.type}
                    onChange={(event) => setDraft({ ...draft, type: event.target.value })}
                  >
                    <option value="story">story</option>
                    <option value="issue">issue</option>
                    <option value="task">task</option>
                  </Select>
                ),
              },
              {
                id: "project",
                label: "Project",
                required: true,
                control: (
                  <Select
                    required
                    value={draft.project}
                    onChange={(event) => setDraft({ ...draft, project: event.target.value })}
                  >
                    <option value="score">score</option>
                    <option value="elitua">elitua</option>
                    <option value="emibs">emibs</option>
                  </Select>
                ),
              },
              ...(minimal
                ? []
                : [
                    {
                      id: "priority",
                      label: "Priority",
                      control: (
                        <Input
                          min={0}
                          type="number"
                          value={draft.priority}
                          onChange={(event) => setDraft({ ...draft, priority: event.target.value })}
                        />
                      ),
                    },
                    {
                      id: "role",
                      label: "Role",
                      control: (
                        <Select
                          value={draft.role}
                          onChange={(event) => setDraft({ ...draft, role: event.target.value })}
                        >
                          <option value="">Unspecified</option>
                          <option value="engineer">engineer</option>
                          <option value="worker">worker</option>
                          <option value="maestro">maestro</option>
                        </Select>
                      ),
                    },
                    {
                      id: "description",
                      label: "Description",
                      wide: true,
                      control: (
                        <textarea
                          className="ui-input creation-dialog-demo-textarea"
                          value={draft.description}
                          onChange={(event) => setDraft({ ...draft, description: event.target.value })}
                        />
                      ),
                    },
                  ]),
            ],
          },
        ]}
        footer="Product state owns option catalogs, payload conversion, API calls, route focus restoration, and toast delivery."
        submitDisabled={!draft.title.trim() || !draft.project.trim()}
        onClose={() => setOpen(false)}
        onSubmit={(event) => {
          event.preventDefault();
          setOpen(false);
        }}
      />
    </div>
  );
}

export function NotificationToggleRegistryDemo({ compact = false }: { compact?: boolean }) {
  const [subscribed, setSubscribed] = useState(!compact);
  return (
    <div className="notification-toggle-demo-grid">
      <NotificationToggle
        density={compact ? "compact" : "comfortable"}
        subscribed={subscribed}
        onChange={setSubscribed}
        status={compact ? "task-83" : subscribed ? "Subscribed as Codex Maestro" : "2 current subscribers"}
        subscribedDescription={compact ? undefined : "Score will email this actor on task updates; delivery policy stays local."}
        unsubscribedDescription={compact ? undefined : "Opt in without moving subscription APIs into the UI library."}
      />
    </div>
  );
}

export const notificationDemoSeed: ActivityCenterItem[] = [
  {
    id: "n-3",
    title: "Reviewer approved PR #298",
    body: "Add real-time SSE delivery to emibs-svc-notifications is ready to merge.",
    read: false,
    createdAt: new Date(Date.now() - 90 * 1000).toISOString(),
    link: "#/pr/298",
    type: "review.approved",
  },
  {
    id: "n-2",
    title: "New task assigned to you",
    body: "S3 · Build the reusable notifications UI component.",
    read: false,
    createdAt: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
    link: "#/task/3752",
    type: "task.assigned",
  },
  {
    id: "n-1",
    title: "Deploy succeeded",
    body: "ui-lib.ayc.io is serving the latest catalog bundle.",
    read: true,
    createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    type: "deploy.succeeded",
  },
];

export function NotificationsRegistryDemo({
  status = "ready",
  empty = false,
}: {
  status?: "loading" | "ready" | "error";
  empty?: boolean;
}) {
  const [open, setOpen] = useState(true);
  const [items, setItems] = useState<ActivityCenterItem[]>(empty ? [] : notificationDemoSeed);
  const liveSeq = useRef(0);
  const panelId = "activity-center-demo";

  const unread = items.filter((item) => !item.read).length;

  const markRead = (id: string) =>
    setItems((current) => current.map((item) => (item.id === id ? { ...item, read: true } : item)));

  const markAllRead = () => setItems((current) => current.map((item) => ({ ...item, read: true })));

  // Simulate a live SSE `notification` event prepending a fresh unread row.
  const pushLive = () => {
    liveSeq.current += 1;
    const id = `live-${liveSeq.current}`;
    setItems((current) => [
      {
        id,
        title: `Live update #${liveSeq.current}`,
        body: "Arrived over the SSE stream and prepended newest-first.",
        read: false,
        createdAt: new Date().toISOString(),
        link: "#/live",
        type: "demo.live",
      },
      ...current,
    ]);
  };

  return (
    <div className="notifications-demo-shell" style={{ display: "grid", gap: 14, justifyItems: "start" }}>
      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <NotificationBell
          unreadCount={unread}
          open={open}
          controlsId={panelId}
          onClick={() => setOpen((value) => !value)}
        />
        <Button type="button" size="sm" variant="secondary" onClick={pushLive}>
          <Bell size={14} />
          Simulate live event
        </Button>
      </div>
      {open ? (
        // The panel is flat by design (ui-density); the consumer owns the
        // dropdown/drawer surface. This wrapper stands in for that surface.
        <div
          style={{
            width: "min(100%, 380px)",
            maxHeight: 420,
            display: "flex",
            overflow: "hidden",
            border: "1px solid var(--border)",
            borderRadius: "var(--radius-md)",
            background: "var(--surface)",
            boxShadow: "0 16px 40px rgb(15 23 42 / 0.16)",
          }}
        >
          <ActivityCenter
            id={panelId}
            className="ui-activity-center--fill"
            items={items}
            status={status}
            unreadCount={unread}
            error={status === "error" ? "The notifications service did not respond." : undefined}
            onItemSelect={(item) => markRead(item.id)}
            onMarkAllRead={markAllRead}
            onRetry={() => undefined}
          />
        </div>
      ) : null}
    </div>
  );
}

export function DialogFrameDemo({ size = "lg", compact = false }: { size?: DialogFrameSize; compact?: boolean }) {
  const [open, setOpen] = useState(true);

  return (
    <div className={compact ? "dialog-frame-demo-shell dialog-frame-demo-shell--compact" : "dialog-frame-demo-shell"}>
      <div className="dialog-frame-demo-page" aria-hidden="true">
        <div>
          <Badge tone="info">Score task detail</Badge>
          <h3>{compact ? "Compact review modal" : "Generic detail modal"}</h3>
          <p>
            Product-owned task routes, fetches, form state, permissions, and toasts can sit inside a shared dialog
            frame without becoming shared behavior.
          </p>
        </div>
        <div className="dialog-frame-demo-actions">
          <Button type="button" size="sm" onClick={() => setOpen(true)}>
            <PanelRightOpen size={15} />
            Preview frame
          </Button>
        </div>
      </div>
      <DialogFrame
        open={open}
        placement="contained"
        size={size}
        eyebrow="Score board"
        title={compact ? "Review task scope" : "Extract DialogFrame into emibs-ui-lib"}
        subtitle="A controlled modal frame for arbitrary product-owned task detail content."
        status={compact ? "review" : "processing"}
        statusTone={compact ? "info" : "warning"}
        actions={
          compact ? undefined : (
            <Button type="button" variant="secondary" size="sm">
              <ExternalLink size={15} />
              Open task
            </Button>
          )
        }
        footer={
          <div className="dialog-frame-demo-footer">
            <span>Focus policy, routing, editing and persistence stay in Score.</span>
            <Button type="button" size="sm" onClick={() => setOpen(false)}>
              Done
            </Button>
          </div>
        }
        onClose={() => setOpen(false)}
      >
        <div className="dialog-frame-demo-grid">
          <SectionCard
            variant="subtle"
            eyebrow="Detail content"
            title="Task summary"
            description="The library only supplies the frame; rows, forms, relations and markdown are passed in by the product."
          >
            <DescriptionList
              columns={2}
              density="compact"
              items={[
                { id: "status", label: "Status", value: "Processing", tone: "warning" },
                { id: "project", label: "Project", value: "score", tone: "info" },
                { id: "priority", label: "Priority", value: "500" },
                { id: "owner", label: "Owner", value: "agent-codex-maestro" },
              ]}
            />
          </SectionCard>
          <SectionCard variant="card" title="Local behavior">
            <div className="dialog-frame-demo-copy">
              <StatusIndicator label="API data stays app-owned" tone="success" size="sm" icon={<Database size={15} />} />
              <StatusIndicator label="Route close/back stays app-owned" tone="info" size="sm" icon={<GitBranch size={15} />} />
              <StatusIndicator label="Validation and toasts stay app-owned" tone="warning" size="sm" icon={<AlertTriangle size={15} />} />
            </div>
          </SectionCard>
        </div>
      </DialogFrame>
    </div>
  );
}

export function AlertDialogFrameDemo({ size = "default", compact = false }: { size?: AlertDialogFrameSize; compact?: boolean }) {
  const [open, setOpen] = useState(true);

  return (
    <div className={compact ? "alert-dialog-frame-demo-shell alert-dialog-frame-demo-shell--compact" : "alert-dialog-frame-demo-shell"}>
      <div className="alert-dialog-frame-demo-page" aria-hidden="true">
        <div>
          <Badge tone={compact ? "warning" : "info"}>{compact ? "compact alert" : "Score design-system alert"}</Badge>
          <h3>{compact ? "Unsaved workflow change" : "Custom alert-dialog frame"}</h3>
          <p>
            Score can keep Radix trigger, focus policy, workflow checks, and action semantics local while sharing the
            alert-dialog frame, media slot, and footer layout.
          </p>
        </div>
        <div className="alert-dialog-frame-demo-actions">
          <Button type="button" size="sm" onClick={() => setOpen(true)}>
            <AlertTriangle size={15} />
            Preview alert
          </Button>
        </div>
      </div>
      <AlertDialogFrame
        open={open}
        placement="contained"
        size={size}
        media={compact ? <AlertTriangle size={30} /> : <ShieldCheck size={30} />}
        title={compact ? "Discard unsaved edits?" : "Apply workflow transition?"}
        description={
          compact
            ? "The consuming route owns dirty-state detection, restoration, and copy."
            : "The shared frame supplies alert-dialog structure while Score owns transition legality, API calls, audit trail, and notifications."
        }
        footer={
          <>
            <Button type="button" variant="secondary" size="sm" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="button" variant={compact ? "danger" : "primary"} size="sm" onClick={() => setOpen(false)}>
              {compact ? "Discard" : "Apply"}
            </Button>
          </>
        }
        onClose={() => setOpen(false)}
      >
        {!compact ? (
          <div className="alert-dialog-frame-demo-detail">
            <StatusIndicator label="Focus and Radix trigger stay in Score" tone="info" size="sm" />
            <StatusIndicator label="Workflow mutation stays in Score" tone="success" size="sm" />
          </div>
        ) : null}
      </AlertDialogFrame>
    </div>
  );
}

export const alertLaneItems: AlertLaneItem[] = [
  { id: "tick", title: "Scheduler tick stale (12m)", severity: "critical", href: "#/runtime", detail: "no tick since 03:14Z" },
  { id: "rotation", title: "Doctor: orphaned rotation endpoint", severity: "warning", href: "#/admin" },
  { id: "review", title: "Review queue depth 14", severity: "info", href: "#/board" },
];

export function AlertLaneDemo({ dismissable = true }: { dismissable?: boolean }) {
  return (
    <div style={{ maxWidth: 640 }}>
      <AlertLane alerts={alertLaneItems} dismissable={dismissable} />
    </div>
  );
}

export function BlastRadiusConfirmDemo({ error = false, pending = false }: { error?: boolean; pending?: boolean }) {
  const impact = blastRadius("Disable pool score", [
    { label: "Lanes stopped", detail: "Disabling 3 of 4 lanes in pool score.", severity: "danger" },
    { label: "Affected lanes", detail: "agent-claude-dev-1, agent-claude-dev-2, agent-codex-dev-1", severity: "warn" },
    { label: "In-flight work", detail: "2 tasks return to READY.", severity: "info" },
  ]);
  return (
    <div style={{ position: "relative", minHeight: 360 }}>
      <BlastRadiusConfirm
        confirmLabel="Disable pool"
        error={error ? "403: subscription owner mismatch — write rejected by server" : undefined}
        impact={impact}
        onCancel={() => undefined}
        onConfirm={() => undefined}
        open
        pending={pending}
        placement="contained"
      />
    </div>
  );
}
