import { type ReactNode, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BedDouble,
  Bot,
  CalendarDays,
  CheckCircle2,
  Cookie,
  Copy,
  CreditCard,
  Database,
  Download,
  ExternalLink,
  Eye,
  Flag,
  FolderDown,
  GitBranch,
  GitCompare,
  Globe2,
  LayoutDashboard,
  List,
  MapPin,
  MapPinned,
  Plus,
  RefreshCw,
  Search,
  ShieldCheck,
  TimerReset,
  Trash2,
  Upload,
  UserRound,
} from "lucide-react";
import { AccessibilityAuditPanel } from "../../../components/data/AccessibilityAuditPanel";
import { Badge } from "../../../components/primitives/Badge";
import { BookingWidgetPanel } from "../../../components/data/BookingWidgetPanel";
import { Button } from "../../../components/primitives/Button";
import type { CommandPaletteGroup } from "../../../components/primitives/CommandPalette";
import { DataTable, type DataTableColumn } from "../../../components/data/DataTable";
import { Field, Input, Select } from "../../../components/primitives/Field";
import type { DiscoveryCloudGroup } from "../../../components/data/DiscoveryCloudPanel";
import {
  EditableFormActionStrip,
  EditableFormPanel,
  EditableFormResultList,
} from "../../../components/data/EditableFormPanel";
import { EntityCard } from "../../../components/data/EntityCard";
import {
  type FacetFilterGroup,
  type FacetFilterMode,
  FacetFilterPanel,
} from "../../../components/data/FacetFilterPanel";
import { FilterDrawerPanel } from "../../../components/data/FilterDrawerPanel";
import { FileActionListPanel } from "../../../components/data/FileActionListPanel";
import { FilePreviewDialog } from "../../../components/data/FilePreviewDialog";
import {
  type GeocodingControlCandidate,
  GeocodingControlPanel,
  type GeocodingControlSource,
} from "../../../components/data/GeocodingControlPanel";
import { KanbanBoard, type KanbanColumn, type KanbanTask } from "../../../components/data/KanbanBoard";
import { NewsletterSignupPanel } from "../../../components/data/NewsletterSignupPanel";
import { PaymentCheckoutPanel } from "../../../components/data/PaymentCheckoutPanel";
import { ProjectDirectoryPanel } from "../../../components/data/ProjectDirectoryPanel";
import {
  type ProjectProfileChecklistItem,
  type ProjectProfileField,
  ProjectProfilePanel,
} from "../../../components/data/ProjectProfilePanel";
import { ResourceIndexPanel } from "../../../components/data/ResourceIndexPanel";
import { ResourceTransferDialog } from "../../../components/data/ResourceTransferDialog";
import { SubscriptionCapacityPanel } from "../../../components/data/SubscriptionCapacityPanel";
import { WorkItemCard } from "../../../components/data/WorkItemCard";
import {
  type WorkflowMapInsight,
  WorkflowMapPanel,
  type WorkflowMapStage,
} from "../../../components/data/WorkflowMapPanel";
import { type StatusItem, StatusStrip } from "../../../components/layout/StatusStrip";
import { type AuditEntry, AuditTimeline } from "../../../components/data/AuditTimeline";
import { CommandBar } from "../../../components/data/CommandBar";
import type { CommandVerb } from "../../../components/data/commandBarModel";
import { SearchField } from "../../../components/primitives/SearchField";
import { WorkItemRelationEditorPanel } from "../../../components/data/WorkItemRelationEditorPanel";
import {
  accessibilityAuditNotes,
  accessibilityAuditViolations,
  fileActionListItems,
  filePreviewMeta,
  projectDirectoryItems,
  resourceIndexItems,
  resourceTransferTargets,
  scoreTaskDocumentMarkdown,
  subscriptionCapacityMetrics,
  subscriptionCapacityRows,
} from "../../../demos/data";

export type DataTableDemoRow = {
  id: string;
  name: string;
  owner: string;
  status: string;
  points: number;
};

export const dataTableDemoRows: DataTableDemoRow[] = [
  { id: "task-901", name: "Provider auth mock", owner: "Codex", status: "in progress", points: 5 },
  { id: "task-902", name: "Board doctor run", owner: "Llama", status: "ready", points: 2 },
  { id: "task-903", name: "Theme export polish", owner: "Maestro", status: "review", points: 3 },
  { id: "task-904", name: "Palette pages group", owner: "Architect", status: "ready", points: 8 },
  { id: "task-905", name: "Radio group styling", owner: "Codex", status: "done", points: 1 },
  { id: "task-906", name: "Overlay engine docs", owner: "Llama", status: "in progress", points: 3 },
  { id: "task-907", name: "Drawer side variants", owner: "Maestro", status: "ready", points: 2 },
];

export const dataTableDemoColumns: DataTableColumn<DataTableDemoRow>[] = [
  { id: "name", header: "Work item", accessor: (row) => row.name },
  { id: "owner", header: "Owner", accessor: (row) => row.owner },
  { id: "status", header: "Status", accessor: (row) => row.status },
  { id: "points", header: "Points", accessor: (row) => row.points, align: "right" },
];

export function DataTableDemo({ state }: { state?: "loading" | "empty" | "error" }) {
  if (state) {
    return (
      <DataTable
        caption="Work items"
        columns={dataTableDemoColumns}
        data={[]}
        error={state === "error" ? "Work items failed to load." : undefined}
        getRowId={(row) => row.id}
        loading={state === "loading"}
      />
    );
  }
  return (
    <DataTable
      caption="Work items"
      columns={dataTableDemoColumns}
      data={dataTableDemoRows}
      defaultSort={{ columnId: "points", direction: "desc" }}
      getRowId={(row) => row.id}
      pageSize={5}
      selectionMode="multi"
      defaultSelection={["task-901"]}
      searchSlot={<SearchField id="data-table-search" label="Search work items" value="" onValueChange={() => undefined} />}
      filterSlot={<Button size="sm" type="button" variant="secondary">Filter status</Button>}
      exportAction={<Button size="sm" type="button" variant="secondary"><Download aria-hidden="true" size={15} />Export</Button>}
      selectedRowActions={<Button size="sm" type="button" variant="secondary">Archive selected</Button>}
      showCaption
      showPagination
      striped
    />
  );
}

export function BookingWidgetPanelDemo({ blocked = false }: { blocked?: boolean }) {
  return (
    <BookingWidgetPanel
      provider="Bokun"
      providerLogo={<CalendarDays size={22} />}
      eyebrow="eLitua booking"
      title="Vilnius Old Town walking tour"
      subtitle="A public booking widget panel for guide and product pages while provider runtime stays in the consuming app."
      badges={[
        { id: "instant", label: "instant confirmation", tone: "success" },
        { id: "public", label: "public profile", tone: "info" },
      ]}
      status={{
        label: blocked ? "Widget waits for consent" : "Next departure available",
        detail: blocked ? "Third-party scripts stay disabled until eLitua consent policy allows them." : "Tomorrow at 10:00, 6 places left.",
        tone: blocked ? "warning" : "success",
        icon: blocked ? <Cookie size={16} /> : <ShieldCheck size={16} />,
      }}
      details={[
        { id: "duration", label: "Duration", value: "2.5 hours", description: "Local guide route", icon: <TimerReset size={15} /> },
        { id: "price", label: "From", value: "45 EUR", description: "Traveler checkout is app-owned", icon: <CreditCard size={15} />, tone: "success" },
        { id: "language", label: "Languages", value: "LT / EN", description: "Derived from guide profile", icon: <Globe2 size={15} /> },
        { id: "meeting", label: "Meeting point", value: "Cathedral Square", description: "Route link supplied by eLitua", icon: <MapPin size={15} /> },
      ]}
      summary={<p>Use this shell where eLitua wants a reviewable booking call-to-action around an embedded provider widget.</p>}
      consentNotice={
        <span>
          Cookie consent, Bókun script loading, widget ids, analytics events, and checkout handoff remain product-owned.
        </span>
      }
      fallback={
        <span>
          Render a contact link, disabled booking state, or alternate request flow when the provider widget cannot load.
        </span>
      }
      actions={
        <>
          <Button type="button" variant="secondary" size="sm">
            <ExternalLink size={15} />
            Provider page
          </Button>
          <Button type="button" size="sm">
            <CalendarDays size={15} />
            Check dates
          </Button>
        </>
      }
      widget={
        blocked ? undefined : (
          <div className="booking-widget-demo-slot">
            <div>
              <span>Selected date</span>
              <strong>July 1</strong>
            </div>
            <div>
              <span>Travelers</span>
              <strong>2 adults</strong>
            </div>
            <Button type="button">
              Continue in widget
              <ArrowRight size={15} />
            </Button>
          </div>
        )
      }
    />
  );
}

export function PaymentCheckoutProviderDemo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={compact ? "payment-checkout-provider-demo payment-checkout-provider-demo--compact" : "payment-checkout-provider-demo"}>
      <div>
        <span>Card number</span>
        <strong>4242 4242 4242 4242</strong>
      </div>
      {!compact ? (
        <div>
          <span>Expiry</span>
          <strong>04 / 28</strong>
        </div>
      ) : null}
      <div>
        <span>Security</span>
        <strong>3DS ready</strong>
      </div>
    </div>
  );
}

export function PaymentCheckoutPanelDemo({
  error,
  processing = false,
}: {
  error?: ReactNode;
  processing?: boolean;
}) {
  return (
    <div style={{ maxWidth: 520 }}>
      <PaymentCheckoutPanel
        amount="324.00 EUR"
        amountDetail="Accommodation deposit plus guide booking"
        description="Checkout form chrome for provider-owned payment elements and confirmation handlers."
        error={error}
        footer="Stripe hooks, confirmPayment, redirects, analytics, and persistence stay in eLitua."
        icon={<CreditCard size={20} />}
        onSubmit={(event) => event.preventDefault()}
        processing={processing}
        processingLabel="Confirming payment"
        providerSlot={<PaymentCheckoutProviderDemo compact={processing} />}
        submitLabel="Pay 324.00 EUR"
        title="Traveler checkout"
      />
    </div>
  );
}

export function NewsletterSignupPanelDemo({
  tone = "accent",
  submitted = false,
  error,
  busy = false,
}: {
  tone?: "accent" | "neutral" | "tone-inverse";
  submitted?: boolean;
  error?: ReactNode;
  busy?: boolean;
}) {
  const [email, setEmail] = useState("traveler@example.com");
  return (
    <div style={{ maxWidth: 680 }}>
      <NewsletterSignupPanel
        busy={busy}
        description="Weekly destination guides, seasonal itineraries, and local travel notes without sharing the subscription backend."
        emailLabel="Travel newsletter email"
        error={error}
        footer="eLitua keeps provider calls, consent, localization, analytics, and persistence local."
        onSubmit={(event) => event.preventDefault()}
        onValueChange={setEmail}
        submitted={submitted}
        submitLabel="Subscribe"
        successMessage="Thanks. Your travel updates are queued."
        title="Get Lithuania travel inspiration in your inbox"
        tone={tone}
        value={email}
      />
    </div>
  );
}

export function GeocodingControlPanelDemo({
  compact = false,
  error,
  loading = false,
  empty = false,
}: {
  compact?: boolean;
  error?: ReactNode;
  loading?: boolean;
  empty?: boolean;
}) {
  const [query, setQuery] = useState("Trakai Island Castle, Lithuania");
  const [source, setSource] = useState("address");
  const [selectedCandidate, setSelectedCandidate] = useState("trakai-castle");
  const sourceItems: GeocodingControlSource[] = [
    {
      id: "address",
      label: "Address",
      description: "Use the selected record address",
      icon: <Search size={15} />,
      selected: source === "address",
      onSelect: () => setSource("address"),
    },
    {
      id: "name",
      label: "Name",
      description: "Search from place name",
      icon: <MapPin size={15} />,
      selected: source === "name",
      onSelect: () => setSource("name"),
    },
    {
      id: "existing",
      label: "Existing coords",
      description: "Load saved coordinates",
      icon: <MapPinned size={15} />,
      selected: source === "existing",
      onSelect: () => setSource("existing"),
    },
    {
      id: "map",
      label: "Map selection",
      description: "Use the current map pin",
      icon: <MapPinned size={15} />,
      selected: source === "map",
      onSelect: () => setSource("map"),
    },
  ];
  const candidates: GeocodingControlCandidate[] = empty
    ? []
    : [
        {
          id: "trakai-castle",
          label: "Trakai Island Castle",
          description: "Karaimu g. 43C, Trakai, Lithuania",
          coordinates: "54.6529, 24.9347",
          selected: selectedCandidate === "trakai-castle",
          meta: [{ id: "match", label: "formatted address", tone: "success" }],
          selectLabel: "Use Trakai Island Castle geocode result",
          onSelect: () => setSelectedCandidate("trakai-castle"),
        },
        {
          id: "trakai-town",
          label: "Trakai, Vilnius County",
          description: "City-level result for broader destination records",
          coordinates: "54.6378, 24.9343",
          selected: selectedCandidate === "trakai-town",
          meta: [{ id: "scope", label: "locality", tone: "info" }],
          selectLabel: "Use Trakai city geocode result",
          onSelect: () => setSelectedCandidate("trakai-town"),
        },
      ];

  return (
    <div style={{ maxWidth: 760 }}>
      <GeocodingControlPanel
        candidates={candidates}
        coordinates={{
          label: "Selected coordinates",
          latitude: "54.6529",
          longitude: "24.9347",
          source: source === "map" ? "Map selection" : "Geocode result",
        }}
        density={compact ? "compact" : "comfortable"}
        description="Review source actions, address search, selected coordinates, and returned candidates without owning map state."
        emptyCandidatesLabel="No map provider candidates returned."
        error={error}
        footer="eLitua keeps Google Maps calls, debounce timing, coordinate parsing, map pin dispatch, translations, persistence, and toasts local."
        inputPlaceholder="Address, place name, or 54.6529, 24.9347"
        loading={loading}
        onQueryChange={setQuery}
        onSearch={() => undefined}
        query={query}
        searchDisabled={!query.trim()}
        sourceLabel="Coordinate source"
        sources={sourceItems}
        status={loading ? "Searching" : `${candidates.length} candidates`}
        statusTone={error ? "danger" : loading ? "info" : "success"}
        title="GeoForm geocoding"
      />
    </div>
  );
}

export type RegistryKanbanTask = KanbanTask & {
  actor: string;
  area: string;
  epic?: string;
  kind: string;
};

export const scoreKanbanColumns: KanbanColumn<RegistryKanbanTask>[] = [
  {
    id: "ready",
    title: "Ready",
    description: "Prioritized work waiting for an owner.",
    actions: <Badge tone="info">WIP 3</Badge>,
    tasks: [
      {
        id: "issue-385",
        title: "Extract Kanban lane shell",
        owner: "Maestro",
        actor: "agent-codex-maestro",
        area: "UI Framework",
        epic: "UI Framework",
        kind: "story",
        priority: "major",
        tone: "warning",
        age: "12m",
      },
    ],
  },
  {
    id: "processing",
    title: "Processing",
    description: "One active owner with workflow commands still product-owned.",
    tasks: [
      {
        id: "issue-386",
        title: "Adopt shared board lanes in Score",
        owner: "Score UI",
        actor: "agent-luna-ui",
        area: "Board",
        epic: "UI Framework",
        kind: "refactor",
        priority: "low",
        tone: "info",
        age: "fresh",
      },
    ],
  },
  {
    id: "review",
    title: "Review",
    description: "Cards are caller-rendered inside a shared lane shell.",
    tasks: [
      {
        id: "issue-312",
        title: "Confirm board toolbar filters",
        owner: "Maestro",
        actor: "agent-codex-maestro",
        area: "Board",
        epic: "UI Framework",
        kind: "task",
        priority: "minor",
        tone: "accent",
        age: "1h",
      },
    ],
  },
  {
    id: "done",
    title: "Done",
    description: "Empty states stay consistent across every lane.",
    footer: "Done lane keeps historical cards product-owned.",
    tasks: [],
  },
];

export function KanbanBoardDemo() {
  const [selected, setSelected] = useState("issue-385");
  return (
    <KanbanBoard
      ariaLabel="Score workflow board"
      columns={scoreKanbanColumns}
      emptyLabel="No tasks in this lane"
      renderTask={(task) => (
        <RegistryKanbanTaskCard
          selected={task.id === selected}
          task={task}
          onSelect={() => setSelected(task.id)}
        />
      )}
    />
  );
}

export function RegistryKanbanTaskCard({
  task,
  selected = false,
  onSelect,
}: {
  task: RegistryKanbanTask;
  selected?: boolean;
  onSelect?: () => void;
}) {
  return (
    <WorkItemCard
      badges={[
        { id: "priority", label: task.priority ?? "normal", tone: task.tone },
        { id: "kind", label: task.kind, tone: "info" },
      ]}
      density="compact"
      epic={task.epic ? { label: task.epic } : undefined}
      eyebrow={task.area}
      footer={
        onSelect ? (
          <Button size="sm" type="button" variant={selected ? "secondary" : "ghost"} onClick={onSelect}>
            <Eye size={15} />
            Inspect
          </Button>
        ) : null
      }
      itemId={task.id}
      meta={[
        { id: "actor", label: task.actor, icon: <Bot size={14} /> },
        { id: "age", label: task.age ?? "fresh", icon: <CalendarDays size={14} /> },
      ]}
      onOpen={onSelect}
      selected={selected}
      subtitle={task.owner}
      title={task.title}
    />
  );
}

export const facetFilterDemoConfig = [
  {
    id: "source",
    label: "Source app",
    description: "Component origin recorded by the consuming registry.",
    options: [
      { id: "score", label: "Score", count: 42, detail: "operator surfaces", tone: "accent" as const },
      { id: "elitua", label: "eLitua", count: 36, detail: "portal and travel flows", tone: "success" as const },
      { id: "shared", label: "Shared", count: 17, detail: "library-native primitives", tone: "info" as const },
    ],
  },
  {
    id: "pattern",
    label: "Pattern",
    description: "Facet counts respond to every other active axis.",
    options: [
      { id: "layout", label: "Layout and page shells", count: 21 },
      { id: "data", label: "Data, panels and boards", count: 34 },
      { id: "primitives", label: "Primitives and controls", count: 26 },
      { id: "feedback", label: "Feedback and overlays", count: 11 },
    ],
  },
  {
    id: "status",
    label: "Lifecycle",
    options: [
      { id: "catalogued", label: "Catalogued", count: 11 },
      { id: "demo-migrated", label: "Demo migrated", count: 81 },
      { id: "adopted", label: "Adopted", count: 14 },
    ],
  },
];

export const discoveryCloudGroups: DiscoveryCloudGroup[] = [
  {
    id: "patterns",
    label: "Patterns",
    description: "Registry pattern links, active state, and counts are caller-supplied.",
    icon: <List size={15} />,
    items: [
      { id: "data", label: "Data, panels and boards", href: "#/c/discovery-cloud-panel", count: 34, size: "lg", active: true, tone: "accent" },
      { id: "layout", label: "Layout and page shells", href: "#/c/discovery-cloud-panel", count: 21, tone: "info" },
      { id: "theming", label: "Theming", href: "#/c/discovery-cloud-panel", count: 9, tone: "warning" },
      { id: "auth", label: "Auth and account", href: "#/c/discovery-cloud-panel", count: 7, tone: "success" },
    ],
  },
  {
    id: "keywords",
    label: "Keywords",
    description: "Search terms can be weighted, linked, or rendered as inert labels.",
    icon: <Search size={15} />,
    items: [
      { id: "score", label: "Score", href: "#/c/discovery-cloud-panel", count: 41, size: "lg", tone: "accent" },
      { id: "catalog", label: "catalog", href: "#/c/discovery-cloud-panel", count: 18, size: "md", tone: "info" },
      { id: "review", label: "review", href: "#/c/discovery-cloud-panel", count: 16 },
      { id: "theme", label: "theme", href: "#/c/discovery-cloud-panel", count: 12, tone: "warning" },
      { id: "route", label: "route", href: "#/c/discovery-cloud-panel", count: 8, size: "sm" },
    ],
  },
];

export function FacetFilterPanelDemo() {
  const [selected, setSelected] = useState<Record<string, string[]>>({
    source: ["score"],
    pattern: ["data"],
    status: [],
  });
  const [patternMode, setPatternMode] = useState<FacetFilterMode>("any");

  function toggle(groupId: string, optionId: string) {
    setSelected((current) => {
      const currentGroup = current[groupId] ?? [];
      const exists = currentGroup.includes(optionId);
      return {
        ...current,
        [groupId]: exists ? currentGroup.filter((id) => id !== optionId) : [...currentGroup, optionId],
      };
    });
  }

  function clearGroup(groupId: string) {
    setSelected((current) => ({ ...current, [groupId]: [] }));
  }

  const groups: FacetFilterGroup[] = facetFilterDemoConfig.map((group) => ({
    id: group.id,
    label: group.label,
    description: group.description,
    allOption: {
      id: "all",
      label: "All",
      count: group.options.reduce((total, option) => total + option.count, 0),
      selected: (selected[group.id] ?? []).length === 0,
      onSelect: () => clearGroup(group.id),
    },
    modeControl:
      group.id === "pattern"
        ? {
            value: patternMode,
            onChange: setPatternMode,
          }
        : undefined,
    options: group.options.map((option) => ({
      ...option,
      selected: (selected[group.id] ?? []).includes(option.id),
      onSelect: () => toggle(group.id, option.id),
    })),
  }));

  const activeFilters = groups.flatMap((group) =>
    group.options
      .filter((option) => option.selected)
      .map((option) => ({
        id: `${group.id}-${option.id}`,
        label: group.label,
        value: option.label,
        tone: option.tone,
        onRemove: () => toggle(group.id, option.id),
      })),
  );

  const activeCount = activeFilters.length;
  const resultCount = activeCount === 0 ? "92 components" : `${Math.max(8, 42 - activeCount * 9)} matches`;

  return (
    <FacetFilterPanel
      activeFilters={activeFilters}
      description="Controlled filter groups, counted options, active chips, and reset chrome."
      groups={groups}
      resultCount={resultCount}
      onReset={() => setSelected({ source: [], pattern: [], status: [] })}
    />
  );
}

export type RegistryRelationKey = "dependsOn" | "blockedBy" | "related";

export const registryRelationInitial: Record<RegistryRelationKey, string[]> = {
  dependsOn: ["issue-385"],
  blockedBy: ["issue-491"],
  related: ["issue-498"],
};

export const registryRelationLabels = new Map([
  ["issue-183", "UI Framework"],
  ["issue-385", "KanbanBoard lane shell"],
  ["issue-491", "Theme Lab adoption"],
  ["issue-498", "ThemePreviewCanvas extraction"],
  ["issue-502", "Relation editor extraction"],
]);

export const registryRelationFields = [
  { key: "dependsOn" as const, label: "Depends on", tone: "info" as const, emptyLabel: "No dependencies." },
  { key: "blockedBy" as const, label: "Blocked by", tone: "warning" as const, emptyLabel: "No blockers." },
  { key: "related" as const, label: "Related", tone: "accent" as const, emptyLabel: "No related links." },
];

export function WorkItemRelationEditorDemo() {
  const [relations, setRelations] = useState(registryRelationInitial);
  const [drafts, setDrafts] = useState<Record<RegistryRelationKey, string>>({
    dependsOn: "",
    blockedBy: "",
    related: "",
  });
  const suggestions = Array.from(registryRelationLabels.entries()).map(([value, label]) => ({ value, label: `${value} - ${label}` }));

  function addRelation(key: RegistryRelationKey, value: string) {
    const id = value.trim();
    if (!id || id === "issue-502" || relations[key].includes(id)) {
      setDrafts((current) => ({ ...current, [key]: "" }));
      return;
    }
    setRelations((current) => ({ ...current, [key]: [...current[key], id] }));
    setDrafts((current) => ({ ...current, [key]: "" }));
  }

  return (
    <WorkItemRelationEditorPanel
      density="compact"
      eyebrow="Score task detail"
      title="Relation editor"
      subtitle="Dependency, blocker, and related-work lists stay controlled by the consuming app."
      status="draft"
      statusTone="warning"
      fields={registryRelationFields.map((field) => ({
        id: `registry-relation-${field.key}`,
        label: field.label,
        value: drafts[field.key],
        placeholder: "issue-123",
        emptyLabel: field.emptyLabel,
        suggestions,
        tags: relations[field.key].map((id) => ({
          id,
          value: id,
          label: registryRelationLabels.has(id) ? `${id} - ${registryRelationLabels.get(id)}` : id,
          tone: field.tone,
        })),
        onValueChange: (value) => setDrafts((current) => ({ ...current, [field.key]: value })),
        onAdd: (value) => addRelation(field.key, value),
        onRemove: (tag) =>
          setRelations((current) => ({
            ...current,
            [field.key]: current[field.key].filter((id) => id !== (tag.value ?? tag.id)),
          })),
      }))}
      actions={
        <>
          <Button type="button" variant="ghost" size="sm" onClick={() => setDrafts({ dependsOn: "", blockedBy: "", related: "" })}>
            Cancel
          </Button>
          <Button type="button" variant="secondary" size="sm" onClick={() => setRelations(registryRelationInitial)}>
            Reset
          </Button>
          <Button type="button" size="sm">
            Save
          </Button>
        </>
      }
      footer={<span>Score owns normalization, dirty checks, route parsing, persistence, and toasts.</span>}
    />
  );
}

export function ResourceIndexDemo({
  layout = "list",
}: {
  layout?: "list" | "grid";
}) {
  return (
    <ResourceIndexPanel
      eyebrow="admin index"
      title={layout === "grid" ? "eLitua admin resources" : "Project and account resources"}
      subtitle={
        layout === "grid"
          ? "User, profile and picture index pages can use the same metadata card grammar without inheriting Score project ordering."
          : "Score project administration and eLitua resource indexes share title, metadata, link and action chrome."
      }
      status={`${resourceIndexItems.length} resources`}
      statusTone="info"
      layout={layout}
      items={resourceIndexItems}
      actions={
        <Button variant="secondary" size="sm" type="button">
          <Plus size={15} />
          New resource
        </Button>
      }
      onItemMove={layout === "list" ? () => undefined : undefined}
      onItemSelect={() => undefined}
    />
  );
}

export function EntityCardDemo({
  density = "comfortable",
  linked = false,
  media = "fallback",
}: {
  density?: "comfortable" | "compact";
  linked?: boolean;
  media?: "fallback" | "none";
}) {
  return (
    <div style={{ maxWidth: density === "compact" ? 340 : 390 }}>
      <EntityCard
        title="Vilnius Old Town Guest Stay"
        eyebrow="Accommodation"
        subtitle="Vilnius district"
        description="A media-aware tourism record card with badges, compact facts, and caller-owned route actions."
        icon={media === "fallback" ? <BedDouble size={24} /> : undefined}
        showMedia={media !== "none"}
        accentColor="#0f766e"
        badges={[
          { id: "verified", label: "Verified", tone: "success" },
          { id: "family", label: "Family stay", tone: "info" },
        ]}
        metaItems={[
          { id: "region", label: "Vilnius", icon: <MapPin size={13} /> },
          { id: "capacity", label: "Sleeps 6", icon: <UserRound size={13} /> },
          { id: "status", label: "License checked", icon: <ShieldCheck size={13} /> },
        ]}
        footer="eLitua keeps filtering, paging, map sync, analytics, and profile routes product-owned."
        href={linked ? "#/c/entity-card" : undefined}
        selected={!linked && media !== "none"}
        density={density}
        action={
          linked ? undefined : (
            <Button type="button" size="sm" variant="secondary">
              <ExternalLink size={15} />
              Inspect
            </Button>
          )
        }
      />
    </div>
  );
}

export const projectProfileFields: ProjectProfileField[] = [
  { id: "key", label: "Project key", value: "score", icon: <Database size={15} /> },
  { id: "priority", label: "Priority", value: "p1", icon: <Flag size={15} /> },
  { id: "order", label: "Board order", value: "#3" },
  { id: "created", label: "Created", value: "2026-06-27", icon: <CalendarDays size={15} /> },
  {
    id: "repo",
    label: "Repository",
    value: "github.com/ayc/score",
    href: "https://github.com/",
    external: true,
    icon: <GitCompare size={15} />,
  },
];

export const projectProfileChecklist: ProjectProfileChecklistItem[] = [
  { id: "build", text: "Build and type checks pass locally.", checked: true, meta: "Verified before deployment" },
  { id: "deploy", text: "Affected surfaces are deployed and reachable.", checked: true },
  { id: "score", text: "Score task is updated with adoption follow-up.", checked: false },
];

export function ProjectDirectoryDemo({
  state,
}: {
  state?: "loading" | "empty" | "error";
}) {
  return (
    <ProjectDirectoryPanel
      eyebrow="Projects"
      title="Projects"
      description="Score owns project loading, access filtering, route generation, sorting, toasts, and hash synchronization."
      status={state ? undefined : `${projectDirectoryItems.length} accessible`}
      statusTone="info"
      items={state === "empty" ? [] : projectDirectoryItems}
      loading={state === "loading"}
      emptyLabel="No accessible projects."
      error={state === "error" ? "Projects failed to load. Retry policy and error reporting stay product-owned." : undefined}
      actions={
        <Button type="button" size="sm" variant="secondary">
          <RefreshCw size={15} />
          Refresh
        </Button>
      }
    />
  );
}

export function ProjectProfileDemo({
  state,
}: {
  state?: "loading" | "empty" | "error";
}) {
  return (
    <ProjectProfilePanel
      eyebrow="score"
      title="Score"
      subtitle="Agentic project control plane for epics, stories, executable tasks, and runtime evidence."
      badges={[
        { id: "enabled", label: "enabled", tone: "success" },
        { id: "priority", label: "p1", tone: "info" },
        { id: "source", label: "project profile", tone: "accent" },
      ]}
      actions={
        <>
          <a className="ui-button ui-button--ghost ui-button--sm" href="#/c/project-profile-panel">
            <ArrowLeft size={15} />
            Projects
          </a>
          <a className="ui-button ui-button--secondary ui-button--sm" href="#/c/kanban-board">
            Board
            <ArrowRight size={15} />
          </a>
          <a className="ui-button ui-button--secondary ui-button--sm" href="https://github.com/" rel="noreferrer" target="_blank">
            Repo
            <ExternalLink size={15} />
          </a>
        </>
      }
      fields={projectProfileFields}
      description="Score keeps the runtime board, project registry, attachment APIs, route parsing, and permission checks. The shared panel only renders the project profile shell for review."
      checklist={projectProfileChecklist}
      attachments={
        <div className="xpl-row">
          <Badge tone="info">score-project-note.md</Badge>
          <Badge tone="neutral">profile-screenshot.png</Badge>
          <Badge tone="success">2 attachments</Badge>
        </div>
      }
      attachmentsDescription="Attachment upload, preview, deletion, confirmation, and storage stay in the product."
      empty={state === "empty"}
      error={state === "error" ? "Project profile failed to load. Retry policy and alerting stay product-owned." : undefined}
      loading={state === "loading"}
    />
  );
}

export function SubscriptionCapacityDemo({
  state,
}: {
  state?: "loading" | "empty" | "error";
}) {
  return (
    <SubscriptionCapacityPanel
      eyebrow="Provider capacity"
      title="Subscriptions"
      subtitle="A presentational route surface for subscription status, capacity gates, bound agents, and reporter diagnostics."
      status={state ? undefined : `${subscriptionCapacityRows.length} subscriptions`}
      statusTone="info"
      metrics={subscriptionCapacityMetrics}
      subscriptions={state === "empty" ? [] : subscriptionCapacityRows}
      loading={state === "loading"}
      emptyLabel="No subscriptions returned."
      error={state === "error" ? "Subscription capacity failed to load. Retry policy stays product-owned." : undefined}
      actions={
        <Button type="button" size="sm" variant="secondary">
          <RefreshCw size={15} />
          Refresh
        </Button>
      }
      footer="Score keeps capacity parsing, thresholds, suspension policy, API refresh, routing, RBAC and toasts local."
    />
  );
}

export function AccessibilityAuditDemo({
  state = "issues",
}: {
  state?: "idle" | "running" | "pass" | "issues" | "unavailable";
}) {
  const isComplete = state === "pass" || state === "issues";
  return (
    <AccessibilityAuditPanel
      eyebrow="Catalog accessibility"
      title="Preview accessibility audit"
      subtitle="A presentational panel for browser-local audit evidence, manual notes, and affected selectors."
      status={
        state === "running"
          ? "running"
          : state === "unavailable"
            ? "unavailable"
            : isComplete
              ? "complete"
              : "idle"
      }
      passCount={state === "pass" ? 42 : state === "issues" ? 37 : undefined}
      notes={accessibilityAuditNotes}
      violations={state === "issues" ? accessibilityAuditViolations : []}
      actions={
        <Button type="button" size="sm" variant="secondary">
          <RefreshCw size={15} />
          Re-run
        </Button>
      }
      canvas={
        <div className="xpl-stack">
          <Badge tone={state === "issues" ? "warning" : "success"}>
            {state === "issues" ? "generated theme" : "score light"}
          </Badge>
          <Button type="button" size="sm">
            Inspect preview
          </Button>
          <p style={{ margin: 0, color: "var(--text-muted)", fontSize: "0.86rem" }}>
            The consuming app owns axe execution, selected preview, route state, and persistence.
          </p>
        </div>
      }
    />
  );
}

export const workflowMapInsights: WorkflowMapInsight[] = [
  {
    id: "claimable",
    label: "Claimable",
    value: "12",
    detail: "ready or review work",
    tone: "info",
    icon: <GitBranch size={16} />,
  },
  {
    id: "blocked",
    label: "Blocked",
    value: "3",
    detail: "waiting on dependency",
    tone: "warning",
    icon: <AlertTriangle size={16} />,
  },
  {
    id: "recoverable",
    label: "Recoverable",
    value: "2",
    detail: "lease or hard-stop",
    tone: "accent",
    icon: <TimerReset size={16} />,
  },
  {
    id: "released",
    label: "Released",
    value: "8",
    detail: "ready for close",
    tone: "success",
    icon: <CheckCircle2 size={16} />,
  },
];

export const workflowMapStages: WorkflowMapStage[] = [
  {
    id: "created",
    label: "Created",
    description: "Intake, grooming, and triage context.",
    count: "2",
    status: "triage",
    statusTone: "info",
    items: [
      {
        id: "issue-520",
        title: "issue-520 Payment settings copy cleanup",
        href: "#/c/workflow-map-panel",
        status: "needs triage",
        statusTone: "info",
        owner: "Author: owner",
        meta: "priority 640",
        summary: "Metadata is present but the task has not entered ready work yet.",
      },
    ],
  },
  {
    id: "ready",
    label: "Ready",
    description: "Claimable work after blockers and routing gates clear.",
    count: "9",
    status: "claimable",
    statusTone: "success",
    items: [
      {
        id: "issue-521",
        title: "issue-521 Extract workflow map panel",
        href: "#/c/workflow-map-panel",
        status: "ready",
        statusTone: "success",
        owner: "Suggested: codex",
        meta: "project score",
        summary: "Caller supplies project priority, assignee hints, and detail links.",
      },
      {
        id: "issue-498",
        title: "issue-498 Review blockers in task graph",
        status: "blocked",
        statusTone: "warning",
        owner: "Assigned: maestro",
        recovery: "blocked by issue-473",
        recoveryTone: "warning",
      },
    ],
  },
  {
    id: "processing",
    label: "Processing",
    description: "Leased work with owner, heartbeat, and takeover signals.",
    count: "5",
    status: "active",
    statusTone: "info",
    items: [
      {
        id: "issue-506",
        title: "issue-506 Catalog deploy verification",
        href: "#/c/workflow-map-panel",
        status: "leased",
        statusTone: "info",
        owner: "Locked by agent-codex-worker",
        meta: "heartbeat 4m ago",
        summary: "Lease age and takeover rules stay in Score selectors.",
      },
      {
        id: "issue-477",
        title: "issue-477 Stale branch cleanup",
        status: "stalled",
        statusTone: "danger",
        owner: "Locked by disabled agent",
        recovery: "takeover eligible",
        recoveryTone: "danger",
      },
    ],
  },
  {
    id: "review",
    label: "Review",
    description: "Reviewer ownership, changes requested, and hard-stop loops.",
    count: "4",
    status: "handoff",
    statusTone: "warning",
    items: [
      {
        id: "issue-412",
        title: "issue-412 Audit relation editor adoption",
        href: "#/c/workflow-map-panel",
        status: "changes requested",
        statusTone: "warning",
        owner: "Reviewer: agent-reviewer",
        meta: "rotation 2",
        recovery: "hard-stop next",
        recoveryTone: "danger",
      },
    ],
  },
  {
    id: "prod",
    label: "QA / Prod / Done",
    description: "Release gates, deployment evidence, and closure records.",
    count: "8",
    status: "release",
    statusTone: "success",
    items: [
      {
        id: "issue-390",
        title: "issue-390 Activity dashboard adoption",
        href: "#/c/workflow-map-panel",
        status: "done",
        statusTone: "success",
        owner: "Released by maestro",
        meta: "verified score.ayc.io",
        summary: "Deployment and close-record evidence remain product-owned.",
      },
    ],
  },
];

export function WorkflowMapDemo({ state }: { state?: "loading" | "empty" | "error" }) {
  return (
    <WorkflowMapPanel
      eyebrow="Score workflow"
      title="Lifecycle and recovery map"
      subtitle="A presentational inspection surface for stage health, ownership, routing, and recovery cues."
      status="API authoritative"
      statusTone="info"
      insights={workflowMapInsights}
      stages={state === "empty" ? [] : workflowMapStages}
      actions={<Button size="sm" variant="secondary"><RefreshCw size={15} />Refresh</Button>}
      footer="Score keeps lifecycle ordering, allowed transitions, release gates, leases, audit events, and route updates local."
      loading={state === "loading"}
      error={state === "error" ? "Workflow map failed to load. Retry and alert policy stay product-owned." : undefined}
    />
  );
}

export function EditableFormDemo() {
  const [selectedResult, setSelectedResult] = useState("vilnius-old-town");

  return (
    <div style={{ maxWidth: 760 }}>
      <EditableFormPanel
        eyebrow="eLitua admin"
        title="Geo review form"
        subtitle="Selectable geocoding result rows are presentational; map mutation and persistence stay product-owned."
        badges={[
          { id: "geo", label: "geocoding", tone: "info" },
          { id: "selectable", label: "selectable rows", tone: "success" },
        ]}
        messages={[
          {
            id: "result",
            tone: "info",
            children: "Select a candidate row to mirror the current eLitua GeoForm review flow.",
          },
        ]}
        actions={
          <>
            <Button size="sm" type="button" variant="secondary">
              <RefreshCw size={15} />
              Refresh
            </Button>
            <Button size="sm" type="button">
              <CheckCircle2 size={15} />
              Save
            </Button>
          </>
        }
        sections={[
          {
            id: "geocode",
            title: "Geocode candidates",
            description: "The consuming app supplies search debounce, candidate data, and selected-row callbacks.",
            children: (
              <>
                <EditableFormActionStrip>
                  <Button size="sm" type="button" variant="secondary">
                    <MapPinned size={15} />
                    Address
                  </Button>
                  <Button size="sm" type="button" variant="secondary">
                    Existing coords
                  </Button>
                </EditableFormActionStrip>
                <EditableFormResultList
                  items={[
                    {
                      id: "vilnius-old-town",
                      label: "Vilnius Old Town",
                      description: "54.6872, 25.2797 - high confidence",
                      selected: selectedResult === "vilnius-old-town",
                      onSelect: () => setSelectedResult("vilnius-old-town"),
                      action: (
                        <Badge tone={selectedResult === "vilnius-old-town" ? "success" : "neutral"}>
                          {selectedResult === "vilnius-old-town" ? "selected" : "candidate"}
                        </Badge>
                      ),
                    },
                    {
                      id: "trakai",
                      label: "Trakai Island Castle",
                      description: "54.6527, 24.9347 - fallback candidate",
                      selected: selectedResult === "trakai",
                      onSelect: () => setSelectedResult("trakai"),
                      action: (
                        <Badge tone={selectedResult === "trakai" ? "success" : "neutral"}>
                          {selectedResult === "trakai" ? "selected" : "candidate"}
                        </Badge>
                      ),
                    },
                  ]}
                />
              </>
            ),
          },
        ]}
      />
    </div>
  );
}

export function FilterDrawerPanelDemo() {
  // Starts closed: the drawer is a modal portal, so an open default escaped the
  // demo's card and covered whichever catalog page mounted it. The trigger in
  // the demo opens it.
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("type:story status:ready");
  const [project, setProject] = useState("score");
  const [region, setRegion] = useState("vilnius");

  return (
    <div className="filter-drawer-demo-grid">
      <FilterDrawerPanel
        mode="inline"
        density="compact"
        eyebrow="eLitua explorer"
        title="Entity filters"
        summary="42 / 87"
        badges={[{ id: "mode", label: "sidebar", tone: "accent" }]}
        footer="Filter schemas, translated labels, map synchronization and counts stay product-owned."
      >
        <Field label="Search">
          <Input type="search" value={query} onChange={(event) => setQuery(event.target.value)} />
        </Field>
        <Field label="Region">
          <Select value={region} onChange={(event) => setRegion(event.target.value)}>
            <option value="vilnius">Vilnius</option>
            <option value="kaunas">Kaunas</option>
            <option value="trakai">Trakai</option>
          </Select>
        </Field>
      </FilterDrawerPanel>

      <div className="filter-drawer-demo-stage">
        <div className="filter-drawer-demo-page" aria-hidden="true">
          <Badge tone="info">Score board</Badge>
          <h3>Board surface</h3>
          <p>Drawer state, route synchronization and query semantics stay with the consuming feature.</p>
        </div>
        <FilterDrawerPanel
          mode="drawer"
          open={open}
          onOpenChange={setOpen}
          eyebrow="Score board"
          title="Board filters"
          description="Controlled filter controls supplied by the app."
          summary="2 active"
          summaryTone="accent"
          triggerLabel="Filters"
          footerActions={
            <Button type="button" size="sm" onClick={() => setOpen(false)}>
              Done
            </Button>
          }
        >
          <Field label="Project">
            <Select value={project} onChange={(event) => setProject(event.target.value)}>
              <option value="score">Score</option>
              <option value="elitua">eLitua</option>
              <option value="emibs">EMIBS</option>
            </Select>
          </Field>
          <Field label="Query">
            <Input type="search" value={query} onChange={(event) => setQuery(event.target.value)} />
          </Field>
        </FilterDrawerPanel>
      </div>
    </div>
  );
}

export function FileActionListDemo({ compact = false }: { compact?: boolean }) {
  const [menuOpenItemId, setMenuOpenItemId] = useState<string | null>("project-brief");
  return (
    <FileActionListPanel
      actions={
        <Button type="button" variant="primary" size="sm">
          <Upload size={15} />
          Upload
        </Button>
      }
      density={compact ? "compact" : "comfortable"}
      description="Row-based project evidence files. Score owns signed URLs, copy/move APIs, confirmations, browser picker calls, and toasts."
      eyebrow="project profile"
      items={fileActionListItems.map((item) => ({
        ...item,
        actions: [
          { id: "open", label: "Open", href: "#/c/file-action-list-panel", icon: <ExternalLink size={15} /> },
          {
            id: "download",
            label: "Download",
            href: "#/c/file-action-list-panel",
            downloadName: typeof item.filename === "string" ? item.filename : undefined,
            icon: <Download size={15} />,
          },
          { id: "download-to", label: "Download to folder", icon: <FolderDown size={15} /> },
          { id: "copy", label: "Copy / move to", icon: <Copy size={15} /> },
          { id: "delete", label: "Delete", icon: <Trash2 size={15} />, tone: "danger" },
        ],
      }))}
      menuOpenItemId={menuOpenItemId}
      onMenuOpenChange={setMenuOpenItemId}
      status={`${fileActionListItems.length} files`}
      statusTone="info"
      title="Project files"
    />
  );
}

export function FilePreviewDialogDemo({
  longFilename = false,
  fallback = false,
}: {
  longFilename?: boolean;
  fallback?: boolean;
}) {
  const [open, setOpen] = useState(true);
  const markdownHref = `data:text/markdown;charset=utf-8,${encodeURIComponent(scoreTaskDocumentMarkdown)}`;
  const filename = longFilename
    ? "issue-689-file-preview-dialog-extraction-notes-with-a-long-reviewable-filename.md"
    : "issue-689-file-preview-dialog-extraction-notes.md";

  return (
    <div className="dialog-frame-demo-shell">
      <div className="dialog-frame-demo-page" aria-hidden="true">
        <div>
          <Badge tone={fallback ? "warning" : "info"}>{fallback ? "source only" : "Markdown file"}</Badge>
          <h3>{fallback ? "Open raw source" : "Preview project file"}</h3>
          <p>
            Score owns attachment URLs, fetching, permissions, and toast behavior. The shared dialog owns the mode
            switch, frame sizing, and file preview chrome.
          </p>
        </div>
        <div className="dialog-frame-demo-actions">
          <Button type="button" size="sm" onClick={() => setOpen(true)}>
            <Eye size={15} />
            Preview file
          </Button>
        </div>
      </div>
      <FilePreviewDialog
        open={open}
        placement="contained"
        file={{
          id: fallback ? "runtime-log" : "acceptance-notes",
          filename: fallback ? "runtime-output.log" : filename,
          contentType: fallback ? "text/plain" : "text/markdown",
          sizeLabel: fallback ? "42 KB" : "18 KB",
          uploadedBy: "agent-codex-agent",
          createdAtLabel: "2026-07-01",
          downloadHref: fallback ? "#/c/file-preview-dialog" : markdownHref,
          downloadName: fallback ? "runtime-output.log" : filename,
        }}
        kind={fallback ? "document" : "markdown"}
        previewAvailable={!fallback}
        markdown={fallback ? undefined : scoreTaskDocumentMarkdown}
        meta={filePreviewMeta}
        sourceHref={fallback ? "#/c/file-preview-dialog" : markdownHref}
        onClose={() => setOpen(false)}
      />
    </div>
  );
}

export function ResourceTransferDemo({
  initialMove = false,
  empty = false,
}: {
  initialMove?: boolean;
  empty?: boolean;
}) {
  const [open, setOpen] = useState(true);
  const [move, setMove] = useState(initialMove);
  const [targetId, setTargetId] = useState(empty ? "" : "score-qa");
  const targets = empty ? [] : resourceTransferTargets;

  return (
    <div className="dialog-frame-demo-shell dialog-frame-demo-shell--compact">
      <div className="dialog-frame-demo-page" aria-hidden="true">
        <div>
          <Badge tone="info">Score project files</Badge>
          <h3>{empty ? "No destination projects" : "Copy or move attachment"}</h3>
          <p>
            Score owns permission filtering, attachment mutation APIs, signed URLs, and toast handling while the shared
            dialog renders the transfer choice.
          </p>
        </div>
        <div className="dialog-frame-demo-actions">
          <Button type="button" size="sm" onClick={() => setOpen(true)}>
            <Copy size={15} />
            Preview transfer
          </Button>
        </div>
      </div>
      <ResourceTransferDialog
        open={open}
        placement="contained"
        size="md"
        eyebrow="Project attachment"
        title={move ? "Move file" : "Copy file"}
        subtitle="Choose the destination project and whether this file should remain on the source project."
        resource={{
          title: "project-brief.md",
          subtitle: "text/markdown",
          meta: [
            { id: "size", label: "18 KB", tone: "neutral" },
            { id: "source", label: "Score", tone: "info" },
          ],
        }}
        targets={targets}
        targetId={targetId}
        onTargetChange={setTargetId}
        move={move}
        onMoveChange={setMove}
        confirmLabel={move ? "Move file" : "Copy file"}
        emptyLabel="No projects are available for this transfer."
        busy={false}
        onCancel={() => setOpen(false)}
        onConfirm={() => setOpen(false)}
      />
    </div>
  );
}

export // --- UIF-E3 operator component demos (v4 canon, issue-2183) ---

const auditTimelineEntries: AuditEntry[] = [
  { id: "a1", time: "09:02", kind: "created", title: "Task created by maestro", actor: "agent-codex-maestro", tone: "neutral" },
  { id: "a2", time: "10:14", kind: "lease", title: "Lease taken", actor: "agent-claude-dev", tone: "info" },
  { id: "a3", time: "11:47", kind: "disposition", title: "Approved — CLEAN", actor: "agent-codex-reviewer", tone: "success", href: "#/c/audit-timeline" },
  { id: "a4", time: "11:52", kind: "action", title: "Merged --no-ff to score-work", actor: "agent-codex-maestro", tone: "accent", meta: "PR #104" },
  { id: "a5", time: "12:03", kind: "incident", title: "Sentinel: deploy verify failed", actor: "sentinel", tone: "danger", detail: "rolled back to slot 41" },
];

export function AuditTimelineDemo({ density }: { density?: "comfortable" | "compact" }) {
  return (
    <div style={{ maxWidth: 460 }}>
      <AuditTimeline density={density} entries={auditTimelineEntries} />
    </div>
  );
}

export const commandBarVerbs: CommandVerb[] = [
  { id: "park", label: "Park", description: "Move a task to the parked band" },
  { id: "hold", label: "Hold", description: "Hold a task from dispatch" },
  { id: "reband", label: "Re-band", description: "Change a task's priority band" },
];

export const commandBarNav: CommandPaletteGroup = {
  id: "nav",
  title: "Go to",
  items: [
    { id: "board", label: "Board", meta: "#/board", href: "#/board", icon: <LayoutDashboard size={15} /> },
    { id: "fleet", label: "Fleet", meta: "#/fleet", href: "#/fleet" },
    { id: "runtime", label: "Runtime", meta: "#/runtime", href: "#/runtime" },
  ],
};

export const commandBarStatusItems: StatusItem[] = [
  { id: "tick", label: "tick", value: "51s", variant: "signal", freshness: "fresh" },
  { id: "score", label: "score", value: "62%", variant: "signal", signal: "warn" },
  { id: "chat", label: "chat", value: "?", variant: "signal", signal: "unknown" },
];

export function CommandBarDemo() {
  return (
    <CommandBar
      brand="SCORE"
      entityHref={(id) => `#/issue/${id}`}
      navigate={() => undefined}
      navigation={commandBarNav}
      onVerb={() => undefined}
      statusStrip={<StatusStrip items={commandBarStatusItems} />}
      verbs={commandBarVerbs}
    />
  );
}
