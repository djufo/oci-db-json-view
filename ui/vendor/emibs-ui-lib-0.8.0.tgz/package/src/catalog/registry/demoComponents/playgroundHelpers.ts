import type { PlaygroundControl, PlaygroundProps } from "../../types";
import type { TagInputItem } from "../../../components/primitives/TagInput";
import type { ThemeModeToggleMode } from "../../../components/primitives/ThemeModeToggle";

export function playgroundString(props: PlaygroundProps, name: string, fallback: string): string {
  const value = props[name];
  return typeof value === "string" ? value : fallback;
}

export function playgroundBoolean(props: PlaygroundProps, name: string, fallback: boolean): boolean {
  const value = props[name];
  return typeof value === "boolean" ? value : fallback;
}

export function jsxStringProp(name: string, value: string): string {
  return `${name}=${JSON.stringify(value)}`;
}

export function jsxBooleanProp(name: string, value: boolean): string {
  return value ? name : `${name}={false}`;
}

export function jsxElement(name: string, props: string[]): string {
  return `<${name}\n${props.map((prop) => `  ${prop}`).join("\n")}\n/>`;
}

export const switchPlaygroundDefaults = {
  checked: true,
  label: "Email notifications",
  density: "comfortable",
  variant: "framed",
  busy: false,
};

export const segmentedPlaygroundDefaults = {
  value: "board",
  ariaLabel: "Workspace view",
  density: "comfortable",
  showLabels: true,
  disabled: false,
};

export const segmentedPlaygroundOptions = [
  { id: "board", label: "Board" },
  { id: "table", label: "Table" },
  { id: "cards", label: "Cards" },
];

export const dialogSizePlaygroundOptions = [
  { value: "sm", label: "Small" },
  { value: "md", label: "Medium" },
  { value: "lg", label: "Large" },
  { value: "xl", label: "Extra large" },
] as const;

export const dialogRolePlaygroundOptions = [
  { value: "dialog", label: "Dialog" },
  { value: "alertdialog", label: "Alert dialog" },
] as const;

export const drawerSidePlaygroundOptions = [
  { value: "right", label: "Right" },
  { value: "left", label: "Left" },
  { value: "bottom", label: "Bottom" },
  { value: "top", label: "Top" },
] as const;

export const drawerSizePlaygroundOptions = [
  { value: "default", label: "Default" },
  { value: "narrow", label: "Narrow" },
  { value: "wide", label: "Wide" },
] as const;

export const popoverSidePlaygroundOptions = [
  { value: "bottom", label: "Bottom" },
  { value: "top", label: "Top" },
  { value: "right", label: "Right" },
  { value: "left", label: "Left" },
] as const;

export const popoverAlignPlaygroundOptions = [
  { value: "start", label: "Start" },
  { value: "center", label: "Center" },
  { value: "end", label: "End" },
] as const;

export function drawerPlaygroundSize(value: string): string | undefined {
  switch (value) {
    case "narrow":
      return "min(90vw, 320px)";
    case "wide":
      return "min(92vw, 520px)";
    default:
      return undefined;
  }
}

export // --- Forms field-primitive Playground knobs (issue-669) --------------------
// Shared control shape for the Field-contract input primitives: label /
// required / error / disabled / density ("size"). Each schema below reuses
// these helpers so a reviewer flips the same knobs across every form field.

const densityControlOptions = [
  { value: "comfortable", label: "Comfortable" },
  { value: "compact", label: "Compact" },
] as const;

export function fieldKnobControls(labelDefault: string): PlaygroundControl[] {
  return [
    { name: "label", kind: "string", label: "Label", default: labelDefault },
    { name: "required", kind: "boolean", label: "Required", default: false },
    { name: "error", kind: "string", label: "Error", default: "" },
    { name: "disabled", kind: "boolean", label: "Disabled", default: false },
    { name: "density", kind: "enum", label: "Density", default: "comfortable", options: densityControlOptions },
  ];
}

export /** Common JSX prop lines for a field knob set; only non-default props are emitted. */
function fieldKnobSnippetProps(props: PlaygroundProps): string[] {
  const required = playgroundBoolean(props, "required", false);
  const disabled = playgroundBoolean(props, "disabled", false);
  const error = playgroundString(props, "error", "");
  const density = playgroundString(props, "density", "comfortable");
  return [
    jsxStringProp("label", playgroundString(props, "label", "")),
    required ? jsxBooleanProp("required", true) : null,
    error ? jsxStringProp("error", error) : null,
    disabled ? jsxBooleanProp("disabled", true) : null,
    density !== "comfortable" ? jsxStringProp("density", density) : null,
  ].filter(Boolean) as string[];
}

export const selectPlaygroundOptions = [
  { value: "board", label: "Board" },
  { value: "table", label: "Table" },
  { value: "timeline", label: "Timeline" },
];

export const radioGroupPlaygroundOptions = [
  { value: "hourly", label: "Hourly" },
  { value: "daily", label: "Daily" },
  { value: "weekly", label: "Weekly" },
];

export // --- issue-343 controlled/interactive primitive Playground data (issue-454) --
// Fixed demo scaffolding reused by the schemas below so default control values
// reproduce each primitive's current entry.render() output exactly. Snippets
// omit a prop only when its value equals the component's own default.

const comboboxPlaygroundOptions = [
  { value: "agent-codex-maestro", label: "Maestro" },
  { value: "agent-codex-luna", label: "Luna worker" },
  { value: "agent-llama-worker", label: "Local worker" },
];

export const tagInputPlaygroundTags: TagInputItem[] = [
  { id: "lt", label: "Lithuanian", value: "Lithuanian", tone: "success" },
  { id: "en", label: "English", value: "English", tone: "info" },
];

export const tagInputPlaygroundSuggestions = [{ value: "German" }, { value: "Polish" }, { value: "Spanish" }];

export const contentTabsPlaygroundTabMeta = [
  { id: "transactions", label: "Transactions" },
  { id: "payouts", label: "Payouts" },
];

export const themeModePlaygroundOptions = [
  { value: "light", label: "Light" },
  { value: "dark", label: "Dark" },
  { value: "system", label: "System" },
];

export function themeModeNext(mode: ThemeModeToggleMode): ThemeModeToggleMode {
  return mode === "system" ? "light" : mode === "light" ? "dark" : "system";
}
