import { useState } from "react";
import { Database, ExternalLink, Eye, FileText, LayoutDashboard, ShieldCheck, SlidersHorizontal } from "lucide-react";
import { ActionGroup } from "../../../components/primitives/ActionGroup";
import { Button } from "../../../components/primitives/Button";
import { DescriptionList } from "../../../components/primitives/DescriptionList";
import { EmptyState } from "../../../components/primitives/EmptyState";
import {
  type ComponentPlaygroundControl,
  ComponentPlaygroundPanel,
  type ComponentPlaygroundValue,
  type ComponentPlaygroundValues,
} from "../../../components/data/ComponentPlaygroundPanel";
import { buildComponentPlaygroundSnippet } from "../../../lib/componentPlaygroundSnippet";
import { type ComponentCatalogItem, ComponentCatalogPanel } from "../../../components/data/ComponentCatalogPanel";
import {
  ComponentReviewPanel,
  type ComponentReviewTab,
  type ComponentReviewVariant,
} from "../../../components/data/ComponentReviewPanel";
import { DesignIdeaBoardPanel } from "../../../components/data/DesignIdeaBoardPanel";
import { DiscoveryCloudPanel } from "../../../components/data/DiscoveryCloudPanel";
import { SectionCard } from "../../../components/layout/SectionCard";
import { StatusIndicator } from "../../../components/primitives/StatusIndicator";
import { designIdeaBoardItems, designIdeaBoardLanes } from "../../../demos/data";

export const componentPlaygroundControls: ComponentPlaygroundControl[] = [
  {
    name: "label",
    kind: "string",
    label: "Label",
    defaultValue: "Email notifications",
    description: "The primary control label rendered inside the live stage.",
  },
  {
    name: "tone",
    kind: "enum",
    label: "Status tone",
    defaultValue: "info",
    options: [
      { value: "info", label: "Info" },
      { value: "success", label: "Success" },
      { value: "warning", label: "Warning" },
    ],
  },
  {
    name: "count",
    kind: "number",
    label: "Visible checks",
    defaultValue: 3,
    min: 0,
    max: 8,
    step: 1,
  },
  {
    name: "enabled",
    kind: "boolean",
    label: "Enabled",
    defaultValue: true,
    description: "Boolean controls are native checkboxes.",
  },
];

export const componentPlaygroundDefaults: ComponentPlaygroundValues = Object.fromEntries(
  componentPlaygroundControls.map((control) => [control.name, control.defaultValue ?? ""]),
) as ComponentPlaygroundValues;

export function componentPlaygroundString(values: ComponentPlaygroundValues, name: string, fallback: string) {
  const value = values[name];
  return typeof value === "string" ? value : fallback;
}

export function componentPlaygroundNumber(values: ComponentPlaygroundValues, name: string, fallback: number) {
  const value = values[name];
  return typeof value === "number" ? value : fallback;
}

export function componentPlaygroundBoolean(values: ComponentPlaygroundValues, name: string, fallback: boolean) {
  const value = values[name];
  return typeof value === "boolean" ? value : fallback;
}

export const componentCatalogDemoItems: ComponentCatalogItem[] = [
  {
    id: "component-catalog-panel",
    label: "ComponentCatalogPanel",
    meta: "data / Score",
    description: "Catalog shell",
    href: "#/c/component-catalog-panel",
    active: true,
    badges: [{ id: "new", label: "new", tone: "success" }],
  },
  {
    id: "component-review-panel",
    label: "ComponentReviewPanel",
    meta: "data / Score",
    description: "Inspect surface",
    href: "#/c/component-review-panel",
  },
  {
    id: "component-playground-panel",
    label: "ComponentPlaygroundPanel",
    meta: "data / Score",
    description: "Playground controls",
    href: "#/c/component-playground-panel",
  },
  {
    id: "theme-audit-panel",
    label: "ThemeAuditPanel",
    meta: "data / Score",
    description: "Token audit",
    href: "#/c/theme-audit-panel",
  },
];

export function ComponentCatalogDemo({ compact = false }: { compact?: boolean }) {
  const [query, setQuery] = useState("panel");
  const normalizedQuery = query.trim().toLowerCase();
  const items = componentCatalogDemoItems.filter((item) => {
    const label = typeof item.label === "string" ? item.label : "";
    return `${item.id} ${label} ${item.meta ?? ""} ${item.description ?? ""}`.toLowerCase().includes(normalizedQuery);
  });

  return (
    <ComponentCatalogPanel
      badges={[
        { id: "score", label: "Score", tone: "accent" },
        { id: "shell", label: "catalog shell", tone: "success" },
        { id: "visible", label: `${items.length} visible`, tone: "info" },
      ]}
      density={compact ? "compact" : "comfortable"}
      description="A reusable catalog browsing shell that keeps registry loading, routes, previews and adoption workflow in the consuming app."
      eyebrow="Score extraction"
      items={items}
      navigationDescription="Search is controlled by the product."
      navigationTitle="Catalog entries"
      search={{
        value: query,
        placeholder: "Search component panels",
        resultMeta: `${items.length}/${componentCatalogDemoItems.length}`,
        onChange: setQuery,
      }}
      sidebar={
        <div className="xpl-stack">
          <DiscoveryCloudPanel
            density="compact"
            groups={[
              {
                id: "patterns",
                label: "Patterns",
                items: [
                  { id: "catalog", label: "catalog", count: 4, tone: "accent", active: true },
                  { id: "review", label: "review", count: 8 },
                  { id: "theme", label: "theme", count: 5, tone: "warning" },
                ],
              },
            ]}
            title="Discovery"
          />
          <SectionCard
            density="compact"
            description="Facet counts, saved filters, analytics and hash routing stay product-owned."
            icon={<SlidersHorizontal size={16} />}
            title="Sidebar slot"
          >
            <StatusIndicator label="URL owned outside" detail="No registry side effects" tone="success" variant="bar" />
          </SectionCard>
        </div>
      }
      title="Component catalog panel"
    >
      <SectionCard
        badges={[
          { id: "presentational", label: "presentational", tone: "success" },
          { id: "slots", label: "slot based", tone: "info" },
        ]}
        description="Main review content can compose other catalog panels without the shell knowing about registry schemas."
        icon={<LayoutDashboard size={18} />}
        title="Review content"
      >
        <DescriptionList
          columns={2}
          density="compact"
          items={[
            { id: "source", label: "Source", value: "Score Catalog Explorer" },
            { id: "shared", label: "Shared", value: "header, nav rail, slots", tone: "success" },
            { id: "local", label: "Local", value: "registry and routes" },
            { id: "adoption", label: "Adoption", value: "Score follow-up", tone: "info" },
          ]}
        />
      </SectionCard>
    </ComponentCatalogPanel>
  );
}

export function DesignIdeaBoardPanelDemo({ target }: { target?: "Score" | "eLitua" }) {
  const items = target ? designIdeaBoardItems.filter((item) => item.target === target) : designIdeaBoardItems;

  return (
    <DesignIdeaBoardPanel
      eyebrow="mockup porting"
      title={target ? `${target} design ideas` : "Design ideas to port"}
      subtitle={
        target
          ? `Static notes for ${target} mockup ideas before product adoption.`
          : "Cross-product lane board for mockup ideas worth turning into delivery tasks later."
      }
      badges={[
        { id: "ideas", label: `${items.length} ideas`, tone: "info" },
        { id: "scope", label: target ?? "Score + eLitua", tone: "accent" },
      ]}
      actions={
        <Button size="sm" variant="secondary" type="button">
          <ExternalLink size={15} />
          Source mockups
        </Button>
      }
      lanes={designIdeaBoardLanes}
      items={items}
    />
  );
}

export function ComponentPlaygroundDemo({ compact = false }: { compact?: boolean }) {
  const [values, setValues] = useState<ComponentPlaygroundValues>(componentPlaygroundDefaults);
  const [copied, setCopied] = useState(false);
  const label = componentPlaygroundString(values, "label", "Email notifications");
  const tone = componentPlaygroundString(values, "tone", "info") as "info" | "success" | "warning";
  const count = componentPlaygroundNumber(values, "count", 3);
  const enabled = componentPlaygroundBoolean(values, "enabled", true);
  const snippet = buildComponentPlaygroundSnippet(values);

  function updateValue(name: string, value: ComponentPlaygroundValue) {
    setValues((current) => ({ ...current, [name]: value }));
  }

  return (
    <ComponentPlaygroundPanel
      badges={[
        { id: "score", label: "Score", tone: "accent" },
        { id: "playground", label: "playground", tone: "success" },
      ]}
      controls={componentPlaygroundControls}
      copied={copied}
      density={compact ? "compact" : "comfortable"}
      eyebrow="Score extraction"
      footer="Registry loading, theme scopes, route state, clipboard writes, and toasts stay in the consuming catalog."
      snippet={snippet}
      stage={
        <SectionCard
          badges={[{ id: "state", label: enabled ? "enabled" : "disabled", tone: enabled ? "success" : "warning" }]}
          description="The live stage is caller-rendered from normalized playground values."
          icon={<SlidersHorizontal size={17} />}
          title="Playground stage"
        >
          <StatusIndicator
            detail={enabled ? `${count} checks visible` : "Controls disabled"}
            label={label}
            tone={enabled ? tone : "warning"}
            variant="bar"
          />
        </SectionCard>
      }
      stageBadge={compact ? "Compact" : "Default width"}
      subtitle="A controlled control rail, live preview stage, and JSX snippet surface for catalog playgrounds."
      title="Component playground panel"
      values={values}
      onCopySnippet={() => {
        setCopied(true);
        window.setTimeout(() => setCopied(false), 1200);
      }}
      onReset={() => setValues(componentPlaygroundDefaults)}
      onValueChange={updateValue}
    />
  );
}

export const componentReviewVariants: ComponentReviewVariant[] = [
  {
    id: "default",
    title: "Default preview",
    description: "A full-width canvas with component metadata and review notes.",
    preview: (
      <SectionCard
        badges={[{ id: "adoptable", label: "adoptable", tone: "success" }]}
        description="Score keeps route synchronization, task creation, claim dispatch and toasts local."
        icon={<ShieldCheck size={18} />}
        title="Work board toolbar"
      >
        <DescriptionList
          columns={2}
          density="compact"
          items={[
            { id: "source", label: "Source", value: "Score board" },
            { id: "status", label: "Status", value: "Catalog review", tone: "info" },
          ]}
        />
      </SectionCard>
    ),
  },
  {
    id: "narrow",
    title: "Narrow state",
    description: "Preview content can be inspected at constrained widths before app adoption.",
    preview: (
      <div className="xpl-stack">
        <StatusIndicator label="Responsive check" detail="Controls wrap before adoption" tone="info" variant="bar" />
        <ActionGroup fullWidth label="Review commands">
          <Button size="sm" type="button" variant="secondary">Open spec</Button>
          <Button size="sm" type="button">Approve</Button>
        </ActionGroup>
      </div>
    ),
  },
  {
    id: "error",
    title: "Missing preview",
    description: "Catalog owners can still show metadata and next steps while a preview is unavailable.",
    preview: (
      <EmptyState icon={<FileText size={22} />} title="Preview pending">
        The consuming product owns registry loading and can provide an empty-state explanation.
      </EmptyState>
    ),
  },
];

export const componentReviewTabs: ComponentReviewTab[] = [
  {
    id: "usage",
    label: "Usage",
    icon: <FileText size={15} />,
    items: [
      { id: "controlled", body: "Use controlled ids for selected variant, selected tab, and canvas width." },
      { id: "presentational", body: "Keep search, routes, registry loading, and adoption workflow in the consuming app." },
    ],
  },
  {
    id: "code",
    label: "Code",
    icon: <Database size={15} />,
    body: (
      <pre>
        {`<ComponentReviewPanel
  title="WorkBoardToolbar"
  variants={variants}
  activeVariantId={variant}
  onVariantChange={setVariant}
/>`}
      </pre>
    ),
  },
  {
    id: "a11y",
    label: "A11y",
    icon: <ShieldCheck size={15} />,
    items: [
      { id: "tabs", body: "Review tabs expose tablist/tab/tabpanel semantics." },
      { id: "canvas", body: "Canvas controls use native selects with visible labels." },
    ],
  },
];

export function ComponentReviewDemo() {
  const [variantId, setVariantId] = useState("default");
  const [tabId, setTabId] = useState("usage");
  const [canvasSizeId, setCanvasSizeId] = useState("default");
  return (
    <ComponentReviewPanel
      activeCanvasSizeId={canvasSizeId}
      activeTabId={tabId}
      activeVariantId={variantId}
      actions={<Button type="button" size="sm" variant="secondary"><Eye size={15} /> Copy link</Button>}
      badges={[
        { id: "score", label: "Score", tone: "accent" },
        { id: "catalogued", label: "demo-migrated", tone: "success" },
        { id: "layout", label: "review surface", tone: "info" },
      ]}
      eyebrow="Score extraction"
      meta={[
        { id: "package", label: "Package", value: "emibs-ui-lib" },
        { id: "source", label: "Source", value: "ui/src/features/catalog/containers/CatalogExplorerContainer.tsx" },
        { id: "owner", label: "Owner", value: "Score UI" },
      ]}
      reviewNotes={[
        "Fixtures and preview content are caller-supplied.",
        "Catalog search, route synchronization, and registry persistence stay product-owned.",
        "Variant cards are inert except for the controlled inspect action.",
      ]}
      summary="A one-component review surface with metadata, a width-controlled preview canvas, review tabs, and variants."
      tabs={componentReviewTabs}
      title="Component review panel"
      variants={componentReviewVariants}
      onCanvasSizeChange={setCanvasSizeId}
      onTabChange={setTabId}
      onVariantChange={setVariantId}
    />
  );
}
