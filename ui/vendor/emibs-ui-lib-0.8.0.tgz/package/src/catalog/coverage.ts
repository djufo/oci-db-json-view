import type { ComponentEntry, EntryStatus } from "./types";

export type CoverageFacetKey = "demo" | "variants" | "usage" | "props" | "states" | "spec";

export type CoverageFacet = {
  key: CoverageFacetKey;
  label: string;
  complete: (entry: ComponentEntry) => boolean;
};

export type CoverageRow = {
  entry: ComponentEntry;
  completed: number;
  total: number;
};

/**
 * An entry at `active` (or later) must carry its *complete* documented surface:
 * every coverage facet, not a subset. So the lifecycle requirement set is the
 * facet set.
 */
export type LifecycleRequirement = CoverageFacetKey;

export type LifecycleViolation = {
  entryId: string;
  entryName: string;
  status: EntryStatus;
  missing: readonly LifecycleRequirement[];
};

export type CoverageReport = {
  rows: CoverageRow[];
  completed: number;
  total: number;
  percent: number;
  lifecycleChecked: number;
  lifecycleViolations: LifecycleViolation[];
};

export const lifecycleStatusOrder: Record<EntryStatus, number> = {
  catalogued: 0,
  "demo-migrated": 1,
  active: 2,
  adopted: 3,
};

export const coverageFacets: readonly CoverageFacet[] = [
  { key: "demo", label: "Demo migrated", complete: (entry) => entry.hasDemo },
  { key: "variants", label: "Variants", complete: (entry) => Boolean(entry.variants?.length) },
  { key: "usage", label: "Usage snippet", complete: (entry) => Boolean(entry.usage) },
  { key: "props", label: "Prop docs", complete: (entry) => Boolean(entry.propDocs?.length) },
  { key: "states", label: "States", complete: (entry) => Boolean(entry.states?.length) },
  { key: "spec", label: "Spec", complete: (entry) => Boolean(entry.specContent?.trim()) },
];

/**
 * Floor, never round. A completeness gate must not overstate completeness:
 * `Math.round` printed "100%" for 1013/1014 checks, which is exactly the quiet
 * inaccuracy that let the documented surface rot unnoticed. Flooring means the
 * figure reaches 100 only when every single check genuinely passes, and every
 * other reading is a lower bound rather than a flattering one.
 */
export function coveragePercent(completed: number, total: number): number {
  return total === 0 ? 0 : Math.floor((completed / total) * 100);
}

export function buildCoverageRows(items: readonly ComponentEntry[]): CoverageRow[] {
  return items
    .map((entry) => {
      const completed = coverageFacets.filter((facet) => facet.complete(entry)).length;
      return { entry, completed, total: coverageFacets.length };
    })
    .sort((a, b) => {
      if (a.completed !== b.completed) return a.completed - b.completed;
      if (lifecycleStatusOrder[a.entry.status] !== lifecycleStatusOrder[b.entry.status]) {
        return lifecycleStatusOrder[a.entry.status] - lifecycleStatusOrder[b.entry.status];
      }
      return a.entry.name.localeCompare(b.entry.name);
    });
}

/**
 * The completeness gate, deliberately lifecycle-gated rather than absolute.
 *
 * Rule: **nothing reaches or stays at `active` without its full surface** — all
 * six coverage facets (demo, variants, usage, props, states, spec).
 *
 * Why not simply assert "catalog coverage must be 100%"? Because the lifecycle
 * exists precisely so a new component can land at `catalogued` and be iterated
 * on — demo first, then variants, usage, props, states, spec — without blocking
 * everyone else's build. An absolute rule would make the first commit of any new
 * component red, and the pressure would be to weaken the gate again.
 *
 * Gating on status instead keeps the gate real where it matters: the moment an
 * entry is declared `active` (or `adopted`), its documented surface must be
 * complete, and it cannot silently rot afterwards, because any facet removed
 * from an active entry fails the build by name. Work in progress stays welcome;
 * finished work stays finished.
 */
export function findLifecycleViolations(items: readonly ComponentEntry[]): LifecycleViolation[] {
  return items.flatMap((entry) => {
    if (lifecycleStatusOrder[entry.status] < lifecycleStatusOrder.active) return [];
    const missing = coverageFacets
      .filter((facet) => !facet.complete(entry))
      .map((facet) => facet.key);
    return missing.length
      ? [{ entryId: entry.id, entryName: entry.name, status: entry.status, missing }]
      : [];
  });
}

export function buildCoverageReport(items: readonly ComponentEntry[]): CoverageReport {
  const rows = buildCoverageRows(items);
  const completed = rows.reduce((sum, row) => sum + row.completed, 0);
  const total = rows.length * coverageFacets.length;
  return {
    rows,
    completed,
    total,
    percent: coveragePercent(completed, total),
    lifecycleChecked: items.filter(
      (entry) => lifecycleStatusOrder[entry.status] >= lifecycleStatusOrder.active,
    ).length,
    lifecycleViolations: findLifecycleViolations(items),
  };
}

/**
 * What the percentage is a percentage OF — printed with it, always.
 *
 * The figure is computed over `componentMeta` and nothing else, so "100%" is a
 * statement about the completeness of a hand-maintained list, not about the
 * library. A component that is exported and never catalogued is not counted as
 * incomplete; it is not counted at all, and the number goes UP when such a
 * component is left out. Printing the number without that sentence is what made
 * it read as a coverage claim it was never able to make (uif/issue-4675).
 *
 * Every value here is derived from the report, so the qualification cannot go
 * stale the way a written-down count would. The bound on what sits outside the
 * denominator is `scripts/check-catalog-registration.mjs`, which fails the build
 * when the set of uncatalogued public components grows.
 */
export function formatCoverageDenominator(report: CoverageReport): string {
  return (
    `Denominator: those ${report.rows.length} registered entries x ${coverageFacets.length} facets. ` +
    "It measures the registry against itself; a component outside componentMeta is not counted as " +
    "incomplete, it is not counted at all (scripts/check-catalog-registration.mjs bounds that gap)."
  );
}

export function formatCoverageSummary(report: CoverageReport): string {
  const lifecycle = report.lifecycleViolations.length
    ? `${report.lifecycleViolations.length} lifecycle violation${report.lifecycleViolations.length === 1 ? "" : "s"}`
    : `${report.lifecycleChecked} active-or-later entries valid`;
  return (
    `Catalog coverage: ${report.rows.length} entries, ${report.completed}/${report.total} checks ` +
    `(${report.percent}%), ${lifecycle}. ${formatCoverageDenominator(report)}`
  );
}
