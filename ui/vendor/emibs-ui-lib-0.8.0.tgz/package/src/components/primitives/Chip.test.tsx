import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import {
  BandChip,
  Chip,
  ClassChip,
  ModelChip,
  StatusChip,
  modelChipTone,
  statusChipTone,
} from "./Chip";

describe("Chip taxonomy", () => {
  it("routes every taxonomy adapter through the canonical Chip markup", () => {
    const markup = renderToStaticMarkup(
      <>
        <Chip>base</Chip>
        <StatusChip status="success" />
        <BandChip band="campaign" />
        <ClassChip classification="orchestration" />
        <ModelChip model="advanced" />
      </>,
    );

    expect(markup.match(/class="ui-chip /g)).toHaveLength(5);
    expect(markup).toContain('data-taxonomy="status"');
    expect(markup).toContain('data-taxonomy="band"');
    expect(markup).toContain('ui-chip--band-campaign');
    expect(markup).toContain('ui-chip--class-orchestration');
    expect(markup).toContain('data-taxonomy="model"');
  });

  it("keeps mappings explicit and unknown models neutral", () => {
    expect(statusChipTone("warning")).toBe("warning");
    expect(modelChipTone("advanced")).toBe("accent");
    expect(modelChipTone("unknown")).toBe("neutral");
  });
});
