# FileUploadControl

## Purpose

`FileUploadControl` is a presentational file-input affordance for upload buttons
and modern dashed dropzones. It standardizes picker, drag/drop, and focused
clipboard-image selection while products keep file validation, transport,
persistence, progress state, and toast behavior.

## Source Evidence

- Score `ui/src/features/board/components/TaskDetail.tsx` uses a hidden file
  input inside task attachment upload chrome.
- eLitua `ui/src/pages/admin/profiles/ProfileEditPage.tsx` uses a dashed image
  upload area for profile pictures.

## Contract

- Renders a keyboard-accessible native `input type="file"` with button or
  dropzone presentation.
- Accepts controlled copy, icon slot, accept/selected labels, busy and disabled
  states, `accept`, `multiple`, and other safe input attributes.
- Keeps the original picker-only `onFilesSelected(files, event)` callback for
  backward compatibility.
- Calls `onFilesAdded(files, details)` for picker, drop, and paste selections.
  `details.source` is `picker`, `drop`, or `paste`, and `details.event` is the
  corresponding React change, drag, or clipboard event.
- Keeps one persistent polite `role="status"` region and writes a sequenced
  completion message after every picker, drop, or paste selection. The sequence
  makes repeat selection of the same filename announce reliably.
  `formatSelectionAnnouncement(files, details)` can localize the message; UIF
  prepends the monotonic selection number.
- `enableDrop` defaults to `true`. Drag/drop activates only when the modern
  `onFilesAdded` callback is present; file drags expose a visual active state,
  use copy semantics, and emit on drop.
- `capturePaste` defaults to `true`. Paste handling is attached only to this
  component, so it runs when the component or its native input owns focus and
  never installs a page/window listener. It consumes a paste only when the
  clipboard contains at least one image and `onFilesAdded` is present; ordinary
  text paste remains untouched.
- Clipboard images are re-wrapped with deterministic per-mounted-control names:
  `<pastedFileName>-1.<extension>`, `<pastedFileName>-2.<extension>`, and so on.
  `pastedFileName` defaults to `pasted-screenshot`; the extension is derived
  from the MIME type. Before `File` construction the base is Unicode-normalized,
  path separators, dot runs, control/format characters, and unsafe filename
  punctuation are replaced, repeated separators collapse, and the result is
  bounded to 64 Unicode code points. An empty result falls back to
  `pasted-screenshot`.
- Native picker `accept`/`multiple` attributes are forwarded. Drop and paste
  selection honor `multiple=false` by emitting only the first file. `accept`
  remains a selection hint, not a validation boundary: dropped/pasted files are
  emitted without type rejection so the consumer retains one validation path.
- Can reset the native input after selection through `resetOnSelect`.
- `dropLabel` and `pasteLabel` control the drag-active and clipboard helper
  copy. Busy/disabled controls cannot select, drop, or capture paste; error
  remains announced and visibly tokenized.
- Nested drag-enter/leave events use a depth counter: leaving a child does not
  clear the drag state, and the state clears exactly when depth returns to zero
  or the component becomes disabled.

## Boundaries

- No upload request, image processing, MIME/extension/file-size validation, signed URL
  generation, moderation policy, localization, or toast handling lives here.
- Consumers own where selected files are stored and how upload progress is
  represented.

## Field contract (issue-564)

Brought under the shared FieldControl contract, **additively and back-compat**
(no existing prop removed):

- `error` — validation message; sets `aria-invalid` on the control and renders a
  `role="alert"` message wired via `aria-describedby`.
- `required` — renders a Required affordance and sets `aria-required` + the native
  `required` attribute.
- `hint` — supplementary help text below the row (in addition to `description`).
