import { type MouseEventHandler, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import "./materialControls.css";

export type BreadcrumbItem = {
  id: string;
  label: ReactNode;
  href?: string;
  current?: boolean;
  onClick?: MouseEventHandler<HTMLAnchorElement>;
};

export type BreadcrumbProps = {
  items: readonly BreadcrumbItem[];
  ariaLabel?: string;
  separator?: ReactNode;
  className?: string;
};

/** Landmark/list breadcrumb that exposes one canonical current page. */
export function Breadcrumb({
  ariaLabel = "Breadcrumb",
  className,
  items,
  separator = "/",
}: BreadcrumbProps) {
  const explicitCurrent = items.findIndex((item) => item.current);
  const currentIndex = explicitCurrent >= 0 ? explicitCurrent : items.length - 1;

  return (
    <nav aria-label={ariaLabel} className={cn("ui-breadcrumb", className)}>
      <ol className="ui-breadcrumb__list">
        {items.map((item, index) => {
          const current = index === currentIndex;
          return (
            <li className="ui-breadcrumb__item" key={item.id}>
              {index > 0 ? (
                <span aria-hidden="true" className="ui-breadcrumb__separator">
                  {separator}
                </span>
              ) : null}
              {current ? (
                <span aria-current="page" className="ui-breadcrumb__current">
                  {item.label}
                </span>
              ) : item.href ? (
                <a className="ui-breadcrumb__link" href={item.href} onClick={item.onClick}>
                  {item.label}
                </a>
              ) : (
                <span className="ui-breadcrumb__label">{item.label}</span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}
