# TemporalInputControl

## Purpose

`TemporalInputControl` is a controlled native date, time, and datetime-local
input wrapper for scheduler, profile, and admin forms. It keeps temporal field
chrome, label/status layout, hint/error/meta text, icon placement, and density
consistent without owning formatting, timezone conversion, validation, or
persistence.

## Source Evidence

- Score `ui/src/features/schedulers/containers/SchedulersContainer.tsx` repeats
  a labelled native `datetime-local` first-start field inside scheduler edit
  rows.
- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` repeats a
  labelled native `date` field for guide license dates.
- eLitua `ui/src/pages/account/accommodation-profile/AccommodationProfilePage.tsx`
  repeats labelled native `time` fields for accommodation check-in/check-out
  profile rows.
- Existing catalog coverage was checked first: larger shells and page layouts
  are already represented, `ScheduleEditorDialog` owns a scheduler-specific
  dialog surface, and `Field.Input` is a low-level native input helper rather
  than a temporal control primitive.

## Contract

- Requires an `id`, `label`, native temporal `type`, controlled `value`, and
  optional `onValueChange`.
- Supports `date`, `time`, and `datetime-local` native input types.
- Supports leading icon, status, hint, error, metadata text, hidden-label mode,
  compact and comfortable density, disabled and read-only states, and normal
  native input attributes such as `min`, `max`, `step`, `required`, and
  `autoComplete`.
- Links hint, error, and metadata text through `aria-describedby` and sets the
  invalid state when an error is present.

## Non-Goals

- No timezone conversion, locale formatting, relative date logic, validation
  schema, date picker popover, recurrence rules, range selection, async loading,
  route state, persistence, or product-specific copy.
- No replacement for scheduler-specific dialog composition; products can use
  this control inside their own forms after review.

## Review Checks

- Hidden labels still provide an accessible input name.
- Hint, error, and metadata text are linked through `aria-describedby`.
- Disabled and read-only states keep stable sizing and do not imply product
  persistence behavior.
- Long labels, hints, errors, metadata, and status text wrap without overlapping
  the native picker affordance in compact and comfortable densities.
