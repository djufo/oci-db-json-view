# EmptyState

`EmptyState` is the typed empty preset for `DataStatePanel`. It has no
standalone structure, CSS, semantics, or outer surface: title, description,
optional icon, action, and density (comfortable and compact, inherited from
`DataStatePanelProps`) are passed directly to the shared state owner through the
exported `EmptyStateProps` preset contract.
