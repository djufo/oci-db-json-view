# Collapsible

## Purpose

`Collapsible` is a small disclosure primitive for preference panels, filter
groups, dense review sections, and composition mockups that need an explicit
expand/collapse control without owning product state.

## Source Evidence

- Score `ui/src/features/board/containers/BoardContainer.tsx` composes a
  controlled filter reveal through `WorkBoardToolbar`, including `aria-expanded`
  and a linked controls region.
- eLitua `ui/src/features/cookieConsent/CookieConsentBanner.tsx` uses a managed
  preferences disclosure with a button, `aria-expanded`, and preference rows.
- emibs-ui-lib composition mockups already use `Collapsible` internally for
  grouped board controls and queue metrics.

## Contract

- Renders a heading-like toggle row with title, optional count, optional action
  slot, and body content.
- Supports uncontrolled `defaultCollapsed` state or controlled `collapsed` plus
  `onCollapsedChange`.
- Links the toggle to the body with `aria-controls` and reflects state with
  `aria-expanded`.
- Keeps preference persistence, filter derivation, route synchronization,
  validation, analytics, and row semantics in the consuming app.
- Uses `ui-collapsible*` CSS classes and shared catalog tokens only.

## Non-Goals

- No accordion grouping, focus trapping, animation lifecycle, URL state,
  product-specific filter behavior, or cookie consent policy.
- No replacement for `WorkBoardToolbar`, `CookieConsentBanner`, `ContentTabs`,
  or `SectionCard`; this primitive is only the reusable disclosure control.

## Review Expectations

- Compact and comfortable densities must fit inside cards, sidebars, and
  composition slots.
- Long titles, counts, action rows, and body content must wrap without
  overlapping at narrow catalog widths.
