# Field

## Purpose

`Field` is a neutral labeled field wrapper for compact operator and account
forms. It renders accessible label, description, hint, error, required, disabled,
read-only, and native input/select/textarea chrome around caller-owned controls
without owning form state.

## Source Evidence

- Score project settings, board creation, task detail, scheduler, and catalog
  forms repeat dense labeled wrappers around native inputs, selects, and text
  areas.
- eLitua account/profile and admin edit forms repeat the same label, hint,
  validation, and multi-line control structure across accommodation, guide,
  integration, and resource-edit pages.
- Existing catalog coverage was checked first: `SearchField` owns query fields,
  `IconInputField` owns icon-adorned single inputs, and `ComboboxField` owns
  datalist-backed suggestions, but none documents the generic native field
  wrapper.

## Contract

- Exports the shared `FieldControl<TValue>` contract for future field controls:
  `value`, `defaultValue`, `onChange(value)`, `name`, `id`, `label`,
  `description`, `hint`, `error`, `required`, `disabled`, and `readOnly`.
- Wraps caller-supplied controls with a visible `<label htmlFor>` by default and
  auto-generates a stable React `useId` control id when neither `Field.id` nor
  the control id is supplied.
- Accepts either the existing children composition or an `EditableFormPanel`-
  shaped `control` prop with `label`, `description`, `hint`, `error`,
  `required`, and `wide` chrome.
- Wires `aria-describedby` to description, hint, and error ids while preserving
  any caller-supplied description ids.
- Sets `aria-invalid` when `error` is present and renders the error with
  `role="alert"` for announcement.
- Marks required fields consistently with a visible "Required" marker plus
  `required` and `aria-required` on the rendered control. Optional fields are
  not marked and do not emit `aria-required="false"`.
- Supports optional hidden labels, meta text, disabled/read-only styling, and
  custom class names.
- Exports native `Input`, `Select`, and `Textarea` helpers using the shared
  field control styling.
- Preserves composition: consuming apps provide values, handlers, ids,
  validation, options, localization, routing, persistence, analytics, and submit
  behavior.

## Non-Goals

- No validation schema, form library integration, layout grid, option loading,
  formatting, masking, async behavior, route synchronization, persistence, or
  submit orchestration.
- No icon/trailing-action chrome; those remain in `IconInputField`,
  `SearchField`, and `ComboboxField`.

## Review Checks

- Existing `<Field label><Input /></Field>` and select usages remain valid.
- Long labels, hints, errors, and meta text do not overlap controls.
- Hidden labels still expose readable label text to screen readers.
- A field with label, description, hint, error, and required renders a matching
  label `htmlFor`, described-by ids for support text, `aria-invalid`, and
  required/`aria-required` on the control.
- Error state is visible through the wrapper class while caller-supplied
  `aria-describedby` ids remain preserved.
