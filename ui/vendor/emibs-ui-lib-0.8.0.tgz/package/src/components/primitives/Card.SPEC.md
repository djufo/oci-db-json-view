# Card Spec

## Purpose

`Card` is a neutral surface primitive for grouped content where consumers need
consistent header, body, action, and footer slots without adopting a
product-owned card system.

## Sources

- Score `ui/src/components/ui/card.tsx` exposes structured card slots:
  `CardHeader`, `CardTitle`, `CardDescription`, `CardAction`, `CardContent`,
  and `CardFooter`.
- Score `ui/src/design-system/Card.tsx` wraps the local primitive for feature
  surfaces.
- eLitua `ui/src/components/ui/Card.tsx` repeats surface, content, title,
  description, media, meta, and badge primitives for entity browsing.

## Contract

- `Card` renders the outer neutral surface and passes native div attributes
  through to the element.
- `CardHeader` renders a two-column header area where leading title copy and a
  trailing `CardAction` can align without layout shifts.
- `CardTitle` and `CardDescription` provide stable heading/subtitle text styles
  while leaving heading level selection to the caller.
- `CardBody` renders the main content slot with grid spacing.
- `CardFooter` renders a wrapping action/status row.

## Boundaries

- No product routing, entity data mapping, image loading policy, menu behavior,
  or action execution lives in the primitive.
- Use `EntityCard`, `WorkItemCard`, or product-specific components for domain
  cards that own media, badges, metadata, or workflow semantics.

## Review Checks

- Header action controls stay aligned at desktop widths and wrap-safe at narrow
  widths.
- Long titles and descriptions wrap inside the surface.
- Footer actions wrap without overflowing or resizing the card unexpectedly.
