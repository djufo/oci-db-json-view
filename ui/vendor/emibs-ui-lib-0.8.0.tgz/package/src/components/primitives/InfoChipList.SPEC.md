# InfoChipList

## Purpose

`InfoChipList` is a presentational read-only chip list for public profile tags,
route coverage, credentials, filters, and compact metadata groups.

## Source Evidence

- eLitua `ui/src/pages/client/guides/GuidePublicProfilePage/GuideTagList/GuideTagList.tsx`
  renders language tags with an empty fallback.
- eLitua `ui/src/pages/client/guides/GuidePublicProfilePage/GuideRouteList/GuideRouteList.tsx`
  renders route chips with a leading map icon and an empty fallback.
- Existing catalog coverage was checked first: `TagInput` owns editable chips,
  `Badge` owns one-off status labels, and `PublicProfilePage` owns a full
  profile shell, but no standalone presentational list owns reusable read-only
  chip groups.

## Contract

- Renders a tokenized wrapping list of chip items with optional icons, tones,
  titles, links, and click callbacks.
- Provides compact and comfortable density variants plus an empty state label
  that preserves chip-list spacing.
- Leaves item derivation, routing, profile loading, localization, analytics,
  and persistence to the consuming product.

## Non-Goals

- No editable chip creation, duplicate handling, autocomplete, validation,
  route lookup, filtering, or profile business rules.
