import { type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../../lib/cn";

export type ActionGroupAlign = "start" | "center" | "end" | "between";
export type ActionGroupGap = "sm" | "md" | "lg";
export type ActionGroupOrientation = "row" | "column" | "responsive";

export type ActionGroupProps = HTMLAttributes<HTMLDivElement> & {
  children: ReactNode;
  align?: ActionGroupAlign;
  gap?: ActionGroupGap;
  orientation?: ActionGroupOrientation;
  fullWidth?: boolean;
  label?: string;
};

export function ActionGroup({
  align = "start",
  children,
  className,
  fullWidth = false,
  gap = "sm",
  label,
  orientation = "responsive",
  role,
  ...props
}: ActionGroupProps) {
  const ariaLabel = label ?? props["aria-label"];
  return (
    <div
      {...props}
      aria-label={ariaLabel}
      className={cn(
        "ui-action-group",
        `ui-action-group--${align}`,
        `ui-action-group--gap-${gap}`,
        `ui-action-group--${orientation}`,
        fullWidth && "ui-action-group--full",
        className
      )}
      role={role ?? (ariaLabel ? "group" : undefined)}
    >
      {children}
    </div>
  );
}
