import { type ChangeEvent, type InputHTMLAttributes, type ReactNode, useEffect, useId, useRef } from "react";
import { cn } from "../../lib/cn";

export type CheckboxControlDensity = "compact" | "comfortable";
export type CheckboxControlVariant = "framed" | "plain";

export type CheckboxControlProps = Omit<InputHTMLAttributes<HTMLInputElement>, "type" | "checked" | "onChange"> & {
  checked: boolean;
  indeterminate?: boolean;
  label: ReactNode;
  description?: ReactNode;
  /** supplementary help text below the row (Field-contract, issue-564) */
  hint?: ReactNode;
  /** validation message; sets aria-invalid + role="alert" (Field-contract) */
  error?: ReactNode;
  /** renders a Required affordance + aria-required (Field-contract) */
  required?: boolean;
  status?: ReactNode;
  density?: CheckboxControlDensity;
  variant?: CheckboxControlVariant;
  onChange?: (checked: boolean, event: ChangeEvent<HTMLInputElement>) => void;
};

export function CheckboxControl({
  checked,
  indeterminate = false,
  label,
  description,
  hint,
  error,
  required = false,
  status,
  density = "comfortable",
  variant = "framed",
  className,
  disabled,
  readOnly,
  id,
  "aria-describedby": ariaDescribedBy,
  onChange,
  ...props
}: CheckboxControlProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const generatedId = useId();
  const controlId = id ?? `checkbox-${generatedId}`;
  const descriptionId = description ? `${controlId}-description` : undefined;
  const hintId = hint ? `${controlId}-hint` : undefined;
  const errorId = error ? `${controlId}-error` : undefined;
  const describedBy = [ariaDescribedBy, descriptionId, hintId, errorId].filter(Boolean).join(" ") || undefined;

  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.indeterminate = indeterminate && !checked;
    }
  }, [checked, indeterminate]);

  return (
    <div className={cn("ui-checkbox-control-field", error && "has-error")}>
      <label
        className={cn(
          "ui-checkbox-control",
          `ui-checkbox-control--${density}`,
          `ui-checkbox-control--${variant}`,
          checked && "is-checked",
          indeterminate && !checked && "is-indeterminate",
          disabled && "is-disabled",
          readOnly && "is-readonly",
          className,
        )}
        data-id="checkbox-control"
      >
        <span className="ui-checkbox-control__box">
          <input
            aria-checked={indeterminate && !checked ? "mixed" : checked}
            aria-describedby={describedBy}
            aria-invalid={error ? true : props["aria-invalid"]}
            aria-readonly={readOnly || undefined}
            aria-required={required || undefined}
            checked={checked}
            disabled={disabled}
            id={controlId}
            readOnly={readOnly}
            ref={inputRef}
            required={required || undefined}
            type="checkbox"
            onChange={(event) => {
              if (!readOnly) {
                onChange?.(event.target.checked, event);
              }
            }}
            {...props}
          />
          <span className="ui-checkbox-control__indicator" aria-hidden="true" />
        </span>
        <span className="ui-checkbox-control__copy">
          <strong>
            {label}
            {required ? (
              <span aria-hidden="true" className="ui-checkbox-control__required">
                {" "}
                Required
              </span>
            ) : null}
          </strong>
          {description ? <small id={descriptionId}>{description}</small> : null}
        </span>
        {status ? <span className="ui-checkbox-control__status">{status}</span> : null}
      </label>
      {hint ? (
        <span className="ui-checkbox-control__hint" id={hintId}>
          {hint}
        </span>
      ) : null}
      {error ? (
        <span className="ui-checkbox-control__error" id={errorId} role="alert" aria-atomic="true">
          {error}
        </span>
      ) : null}
    </div>
  );
}
