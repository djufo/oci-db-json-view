# ComboboxField

## Purpose

`ComboboxField` is a controlled single-value datalist selector for dense task,
profile, and entity forms. It keeps label, input, suggestions, clear action,
hint, error, and metadata chrome consistent without owning option catalogs or
validation.

## Source Evidence

- Score `ui/src/features/board/containers/BoardContainer.tsx` repeats
  datalist-backed assignee and parent-epic fields in the new issue dialog.
- Score `ui/src/features/board/components/TaskDetail.tsx` passes actor and epic
  options into planning controls that need the same single-value suggestion
  behavior.
- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` uses a
  datalist language field in the guide profile form.
- Existing catalog coverage was checked first: `TagInput` owns multi-chip entry,
  `SearchField` is query-specific, and `IconInputField` has no suggestion list
  contract.

## Contract

- Requires an `id`, `label`, controlled `value`, and optional
  `onValueChange`.
- Renders a native input with a generated `datalist` when options are supplied.
- Supports compact and comfortable density, optional leading icon, trailing
  action slot, clear action, hint, error, metadata text, disabled state, and
  hidden-label mode.
- Forwards normal input props so consuming apps keep option loading,
  normalization, validation, routing, localization, persistence, and analytics.

## Non-Goals

- No async autocomplete, fuzzy search, keyboard roving listbox, option fetching,
  validation schema, route synchronization, or persistence.
- No chip management; multi-value entry belongs to `TagInput`.

## Review Checks

- Hidden labels still provide an accessible input name.
- Hint, error, and metadata text are linked through `aria-describedby`.
- Long option values, labels, placeholders, and errors wrap without overlapping
  icon, clear, or action controls.
- Compact density remains usable inside dialogs and sidebar/filter rails.

## Field contract (issue-564)

Already exposed `error` + `aria-invalid` + `aria-describedby`. Added the
`required` affordance (Required marker + `aria-required` + native `required`),
completing the FieldControl contract. Back-compat: no existing prop changed.
