# SearchField

## Purpose

`SearchField` is a controlled search-input primitive for portal headers,
operator toolbars, and dense entity filters. It keeps icon placement, clear
actions, trailing utility slots, labels, and result metadata consistent without
owning query parsing or data fetching.

## Source Evidence

- eLitua `ui/src/components/layout/header/Header/Header.tsx` renders a
  leading-icon search input with an image-search trailing action.
- eLitua accommodation, guide, and geo filter panels repeat search fields inside
  entity browsing rails.
- Score board toolbar search repeats the same controlled input contract for
  route-backed work-item filtering.
- Existing catalog components include search fields inside larger surfaces
  (`PortalHeader`, `WorkBoardToolbar`, and `EntityFilterPanel`), but no
  standalone primitive owns the search-control chrome for future smaller
  compositions.

## Contract

- Requires an `id`, visible or hidden `label`, controlled `value`, and optional
  `onValueChange`.
- Supports compact and comfortable density plus default or toolbar variants.
- Supports optional description text, result metadata, leading icon override,
  clear action, and trailing action slot.
- Emits only input and clear events; consuming apps own debouncing, routing,
  query parsing, image-search behavior, filtering, validation, localization,
  analytics, and persistence.

## Non-Goals

- No async autocomplete, command palette behavior, saved search state, route
  synchronization, network requests, fuzzy matching, or product-owned result
  formatting.

## Review Checks

- Hidden labels still give the input an accessible name.
- Clear and trailing actions remain reachable without overlapping the input text.
- Long placeholders and result metadata wrap without resizing fixed toolbars.

## Field contract (issue-564)

Brought under the shared FieldControl contract, **additively and back-compat**
(no existing prop removed):

- `error` — validation message; sets `aria-invalid` on the control and renders a
  `role="alert"` message wired via `aria-describedby`.
- `required` — renders a Required affordance and sets `aria-required` + the native
  `required` attribute.
- `hint` — supplementary help text; joins `description`/error/meta in `aria-describedby`.
