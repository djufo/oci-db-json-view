import { type ReactNode } from "react";
import { DataStatePanel, type DataStatePanelProps } from "../feedback/DataStatePanel";

export type EmptyStateProps = Omit<DataStatePanelProps, "tone" | "description" | "actions"> & {
  icon?: ReactNode;
  title: string;
  children?: ReactNode;
  action?: ReactNode;
};

export function EmptyState({ icon, title, children, action, density }: EmptyStateProps) {
  return (
    <DataStatePanel
      actions={action}
      density={density}
      description={children}
      icon={icon}
      title={title}
      tone="empty"
    />
  );
}
