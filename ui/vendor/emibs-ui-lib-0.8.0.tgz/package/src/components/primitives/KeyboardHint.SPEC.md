# KeyboardHint

## Purpose

`KeyboardHint` renders a compact, semantic `<kbd>` chord for visible shortcuts.
Consumers own shortcut registration, platform detection, and command execution.

`PlatformInputProvider`, `Kbd`, and `ShortcutHint` add the platform-aware
contract. They resolve abstract shortcuts (such as `mod+k`) from one map for
both event matching and visible display. The provider detects macOS, Windows,
Linux, and touch-only mobile; mobile suppresses shortcut chrome and hint copy
until a trusted hardware keydown is observed.

## Public contract

- Required `keys` is an ordered string array.
- `separator` defaults to `+` and is visual only.
- `label` may override the generated accessible chord name.
- `keyboardHintLabel()` expands common symbols/names such as Command, Control,
  Option, Shift, Escape, Enter, and Space.
- Native `<kbd>` attributes and `className` remain available.

## States matrix

| Input | Visible | Accessible name |
| --- | --- | --- |
| one key | one key cap | expanded key name |
| chord | separated key caps | “Key plus Key” |
| symbolic modifiers | symbols | human-readable modifier names |
| custom label | unchanged keys | caller-provided command/chord label |

## Accessibility

The semantic root is `<kbd>`. Visual separators and key-cap spans are hidden
from assistive technology so the generated or explicit label is announced once.
The hint is not itself interactive and must sit beside the command it documents.

## Density and composition

KeyboardHint has no outer margin or surface wrapper. Its key-cap chrome uses
theme tokens, and a parent owns spacing between the hint and command label.
`Kbd` uses `--score-kbd-bg`, `--score-kbd-fg`, and `--score-kbd-border` for a
distinct light/dark chip treatment without introducing an outer surface.
