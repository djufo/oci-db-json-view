# CheckboxControl

## Purpose

`CheckboxControl` is a controlled checkbox row for selection, consent,
automation gates, direct grants, and form flags where switch semantics would be
too strong or visually misleading.

## Contract

- Renders a native checkbox input with controlled `checked` state.
- Supports optional indeterminate presentation for select-all or partially
  selected groups.
- Accepts label, description, and status slots while keeping copy, persistence,
  permission policy, validation, routing, and analytics in the consuming app.
- Provides compact and comfortable density plus framed and plain variants.
- Does not replace `SwitchControl`; switches remain for persistent binary
  settings, while checkboxes remain for selections, gates, and checklist-like
  decisions.

## Source Evidence

- Score `ui/src/components/ui/checkbox.tsx` provides local checkbox chrome for
  board creation, project enabled state, project checklists, and access grants.
- Score `ui/src/features/board/containers/BoardContainer.tsx` renders the new
  issue automation gate as a checkbox row.
- eLitua `ui/src/pages/admin/users/UserEditPage.tsx` and
  `ui/src/admin/geos/components/GeosTableView/GeosTableView.tsx` repeat active,
  must-change-password, and verified record checkboxes.

## Non-Goals

- No app-owned mutation behavior, grant policy, select-all math, validation,
  route synchronization, localization, or toast handling.
- No switch styling or scheduler/integration setting semantics; use
  `SwitchControl` for those cases.

## Field contract (issue-564)

Brought under the shared FieldControl contract, **additively and back-compat**
(no existing prop removed):

- `error` — validation message; sets `aria-invalid` on the control and renders a
  `role="alert"` message wired via `aria-describedby`.
- `required` — renders a Required affordance and sets `aria-required` + the native
  `required` attribute.
- `hint` — supplementary help text below the row (in addition to `description`).
