# RadioGroup

## Purpose

`RadioGroup` is a single-select control for compact operator and account forms
where a small, mutually exclusive option set should be visible at once. It
implements the shared `FieldControl` contract and owns option chrome, group
labelling, and keyboard navigation without owning form state, option loading, or
validation.

## Source Evidence

- Score board, scheduler, and project settings forms repeat mutually exclusive
  choices (view mode, priority, cadence) that render as button rows or bare
  radios lacking a consistent labelled group wrapper.
- eLitua admin edit forms repeat single-choice status/role/workflow selections
  where a segmented button set is too visually heavy for descriptive options.
- Existing catalog coverage was checked first: `SegmentedControl` owns compact
  toggle rows, `SelectControl` owns collapsed native dropdowns, and
  `CheckboxControl` owns multi-select flags — none provides a labelled,
  keyboard-navigable single-select radiogroup with per-option descriptions.

## Contract

- Implements the shared `FieldControl<string>` contract:
  `value`/`defaultValue`, `onChange(value)`, `name`, `id`, `label`,
  `description`, `hint`, `error`, `required`, `disabled`, and `readOnly`.
- Renders `role="radiogroup"` wired to a group label via `aria-labelledby`, with
  `aria-describedby` covering description, hint, and error text, plus
  `aria-invalid` and `aria-required` reflecting contract state.
- Accepts `options` as `{ value, label, description?, disabled? }` and emits the
  selected value through `onChange`; supports controlled and uncontrolled use.
- Implements roving tabindex: the selected option (or the first enabled option
  when none is selected) is the single Tab stop; Arrow keys move and select,
  Home/End jump to the first/last enabled option, and Space/Enter select the
  focused option, all skipping disabled options and wrapping at the ends.
- Marks required groups with a visible "Required" marker plus `aria-required`;
  optional groups are not marked and do not emit `aria-required="false"`.
- Emits a hidden input carrying `name`/value when `name` is supplied so the
  group is form-engine ready.
- Supports hidden labels, meta text, disabled/read-only state, compact and
  comfortable density, and vertical or horizontal orientation.

## Non-Goals

- No validation schema, form library integration, option loading, async
  behavior, localization, persistence, route synchronization, or submit
  orchestration; consumers own values, handlers, options, and copy.
- No multi-select (see `CheckboxControl`) and no collapsed dropdown (see
  `SelectControl`).

## Review Checks

- Group label is announced via `aria-labelledby`; per-option descriptions are
  linked through each radio's `aria-describedby`.
- Only one option is tab-reachable; Arrow/Home/End navigation skips disabled
  options and wraps, and selection follows focus.
- Required renders a visible marker plus `aria-required`; error renders with
  `role="alert"` and sets `aria-invalid`.
- Options, descriptions, hints, and errors wrap without overlapping the marker
  in compact and comfortable densities and in both orientations.
- Targets meet a 44px minimum and render correctly in light and dark themes.
