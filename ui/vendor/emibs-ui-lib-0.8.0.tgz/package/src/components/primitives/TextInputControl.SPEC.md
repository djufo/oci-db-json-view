# TextInputControl

## Purpose

`TextInputControl` is a controlled native single-line input wrapper for plain
text, email, URL, telephone, password, and search-style fields that need shared
label, status, adornment, support text, validation, and density chrome.

## Source Evidence

- Score `ui/src/features/settings/containers/SettingsContainer.tsx` repeats
  single-line summary email, title template, and send title inputs.
- Score `ui/src/features/schedulers/containers/SchedulersContainer.tsx` repeats
  single-line nudger id, name, pattern, agent, product, and workflow inputs.
- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` repeats
  first name, last name, license, phone, email, website, and country fields.
- eLitua `ui/src/pages/account/bokun/BokunPage.tsx` repeats access key, secret
  key, channel title, and vendor id credential fields.
- eLitua `ui/src/pages/account/accommodation-profile/AccommodationProfilePage.tsx`
  and admin user/profile editors repeat business, contact, and account fields.

## Existing Coverage Check

- Broad layouts and route shells are already represented by the workspace,
  portal, editorial, public profile, map, catalog, dialog, admin, and project
  panel components.
- `Field` remains the low-level wrapper for caller-supplied controls; it does
  not provide a complete native input row with icon, prefix/suffix, status,
  counter, and compact/comfortable density.
- `IconInputField` covers account-oriented icon-led inputs with a trailing
  action, but it does not match the newer Select/Number/Temporal/Textarea
  sibling contract or support prefix/suffix/counter slots.
- `SearchField` and `ComboboxField` stay specialized for query/result metadata
  and datalist suggestions. This component is the generic native single-line
  input row.

## Contract

- Renders a native `input` with a visible label by default.
- Supports `text`, `email`, `url`, `tel`, `password`, and `search` input types.
- Supports optional hidden labels for dense layouts that still need an
  accessible input name.
- Supports decorative leading icon, prefix/suffix adornments, trailing action
  slot, label-row status, hint/error/meta text, optional counter text,
  compact/comfortable density, read-only and disabled states.
- Forwards normal input props such as `placeholder`, `required`, `maxLength`,
  `autoComplete`, `inputMode`, `pattern`, `disabled`, and `readOnly`.
- Emits `onValueChange` with the next raw input value. Consuming apps own
  validation, masking, reveal controls, trimming, persistence, routing,
  analytics, localization, and credential policy.

## Non-Goals

- No password reveal behavior, masking, validation schema, URL normalization,
  search results, datalist suggestions, route ownership, autosave, persistence,
  API calls, localization, or secret redaction.
- No replacement for larger panels that already compose product-specific form
  rows or for specialized search/combobox controls.

## Review Checks

- Long labels, placeholders, hints, counters, prefixes, suffixes, actions, and
  errors wrap or shrink without overlapping adjacent controls.
- Compact density remains usable inside dialogs, side panels, and dense admin
  form grids.
- Error text is exposed through `aria-describedby` and `aria-invalid`.
