import { type KeyboardEvent, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import { useDensity, type Density } from "../../theme/DensityScope";
import { Badge, type BadgeTone } from "./Badge";

export type ContentTabItem = {
  id: string;
  label: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
  meta?: ReactNode;
  badge?: ReactNode;
  badgeTone?: BadgeTone;
  href?: string;
  external?: boolean;
  disabled?: boolean;
  onSelect?: (tab: ContentTabItem) => void;
};

export type ContentTabsProps = {
  tabs: ContentTabItem[];
  activeId: string;
  onTabChange?: (tab: ContentTabItem) => void;
  title?: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  ariaLabel?: string;
  panelId?: string;
  panelLabel?: string;
  variant?: "underline" | "contained";
  density?: Density;
  className?: string;
  children?: ReactNode;
};

export function ContentTabs({
  tabs,
  activeId,
  onTabChange,
  title,
  description,
  actions,
  ariaLabel = "Content sections",
  panelId,
  panelLabel,
  variant = "underline",
  density,
  className,
  children,
}: ContentTabsProps) {
  const resolvedDensity = useDensity(density);
  return (
    <section className={cn("ui-content-tabs", `ui-content-tabs--${variant}`, `ui-content-tabs--${resolvedDensity}`, className)}>
      {title || description || actions ? (
        <header className="ui-content-tabs__header">
          <div className="ui-content-tabs__title-block">
            {title ? <h2>{title}</h2> : null}
            {description ? <p>{description}</p> : null}
          </div>
          {actions ? <div className="ui-content-tabs__actions">{actions}</div> : null}
        </header>
      ) : null}

      <div className="ui-content-tabs__list" role="tablist" aria-label={ariaLabel} onKeyDown={handleTabListKeyDown}>
        {tabs.map((tab) => (
          <ContentTabControl
            active={tab.id === activeId}
            key={tab.id}
            panelId={panelId}
            tab={tab}
            onSelect={(selected) => {
              selected.onSelect?.(selected);
              onTabChange?.(selected);
            }}
          />
        ))}
      </div>

      {children ? (
        <div className="ui-content-tabs__panel" id={panelId} role="tabpanel" aria-label={panelLabel}>
          {children}
        </div>
      ) : null}
    </section>
  );
}

function handleTabListKeyDown(event: KeyboardEvent<HTMLDivElement>) {
  if (!["ArrowLeft", "ArrowRight", "Home", "End"].includes(event.key)) {
    return;
  }
  const controls = Array.from(event.currentTarget.querySelectorAll<HTMLElement>('[role="tab"]:not([disabled])'));
  if (controls.length === 0) {
    return;
  }
  const current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
  const currentIndex = current ? controls.indexOf(current) : -1;
  const safeIndex = currentIndex >= 0 ? currentIndex : 0;
  const nextIndex =
    event.key === "Home"
      ? 0
      : event.key === "End"
        ? controls.length - 1
        : event.key === "ArrowLeft"
          ? (safeIndex - 1 + controls.length) % controls.length
          : (safeIndex + 1) % controls.length;
  event.preventDefault();
  controls[nextIndex]?.focus();
}

function ContentTabControl({
  active,
  panelId,
  tab,
  onSelect,
}: {
  active: boolean;
  panelId?: string;
  tab: ContentTabItem;
  onSelect: (tab: ContentTabItem) => void;
}) {
  const className = cn("ui-content-tabs__tab", active && "is-active");
  const content = (
    <>
      {tab.icon ? <span className="ui-content-tabs__tab-icon">{tab.icon}</span> : null}
      <span className="ui-content-tabs__tab-copy">
        <span className="ui-content-tabs__tab-label">{tab.label}</span>
        {tab.description ? <span className="ui-content-tabs__tab-description">{tab.description}</span> : null}
      </span>
      {tab.meta ? <span className="ui-content-tabs__tab-meta">{tab.meta}</span> : null}
      {tab.badge ? <Badge tone={tab.badgeTone ?? "neutral"}>{tab.badge}</Badge> : null}
    </>
  );

  if (tab.href && !tab.disabled) {
    return (
      <a
        className={className}
        href={tab.href}
        role="tab"
        aria-selected={active}
        aria-current={active ? "page" : undefined}
        aria-controls={panelId}
        target={tab.external ? "_blank" : undefined}
        rel={tab.external ? "noreferrer" : undefined}
        onClick={() => onSelect(tab)}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      className={className}
      type="button"
      role="tab"
      aria-selected={active}
      aria-controls={panelId}
      disabled={tab.disabled}
      onClick={() => onSelect(tab)}
    >
      {content}
    </button>
  );
}
