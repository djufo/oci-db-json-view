# Meter

## Purpose

`Meter` presents a bounded known value or an explicitly unknown capacity/budget
signal. It implements B31: unknown is a neutral striped state and can never be
rendered as full, OK, or successful.

## Public contract

- Required `label` supplies the accessible subject.
- `value` accepts a finite number. `null`, `undefined`, and non-finite values
  are unknown.
- `max` defaults to `100`; invalid/non-positive maxima also produce unknown.
- Known values are clamped to `0..max`; `tone="auto"` maps `<=15%` to critical,
  `<=40%` to warning, and higher values to OK. Callers may choose an explicit
  known-value tone.
- `showValue` controls only visible numeric/unknown copy, never semantics.
- `normalizeMeter()` is exported as the canonical normalization policy.

## States matrix

| State | Markup / ARIA | Track | Visible value |
| --- | --- | --- | --- |
| known OK | `role="meter"`, min/max/now | determinate OK fill | rounded percent |
| known warning | `role="meter"` | warning fill | rounded percent |
| known critical | `role="meter"` | critical fill | rounded percent |
| below/above bounds | `role="meter"`, clamped now | 0% / 100% fill | clamped percent |
| unknown / invalid | `role="status"`, no `aria-valuenow` | neutral stripes, no fill element | `unknown` when enabled |

## Accessibility

- Known meters expose an accessible label and the native ARIA meter range.
- Unknown has the label `<subject>: unknown`, omits determinate range
  attributes, and retains text when visible.
- Tone and track length are supplementary to the numeric or unknown label.

## Density and composition

Meter is flat and edge-to-edge. It brings no outer margin, padding, border,
Card/Panel, or shadow; parents own placement and gaps.
