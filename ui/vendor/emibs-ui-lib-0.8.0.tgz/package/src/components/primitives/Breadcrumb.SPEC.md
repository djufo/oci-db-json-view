# Breadcrumb

## Purpose

`Breadcrumb` presents a compact navigation path with landmark, ordered-list,
link, separator, and current-page semantics.

## Public API

- `items: readonly BreadcrumbItem[]`: `{ id, label, href?, current?, onClick? }`.
- `ariaLabel`: landmark name, default `Breadcrumb`.
- `separator`: decorative separator content, default `/`.
- `className`: optional integration class on the navigation landmark.

Exactly one item is current: the first item marked `current`, or the final item
when none is marked. The current page renders as text rather than a redundant
link. Non-current items with `href` render native anchors.

## Variants

| Variant | Contract |
| --- | --- |
| Explicit current | First `current=true` item owns current-page semantics |
| Implicit current | Final item is current |
| Custom separator | Decorative content changes without changing semantics |
| Non-link ancestor | Plain path label; callers should prefer `href` for navigable ancestors |

## States matrix

| Item state | Rendering | Accessible contract |
| --- | --- | --- |
| Ancestor with `href` | Anchor | Keyboard-navigable destination |
| Ancestor without `href` | Plain text | Non-interactive label |
| Current | Emphasized text | `aria-current="page"` |
| Empty path | Empty ordered list | Landmark remains named; no false current page |

## Accessibility contract

- A named `<nav>` contains an `<ol>` of `<li>` items, preserving path order.
- Separators are `aria-hidden` so screen readers do not announce punctuation.
- Only the canonical current item receives `aria-current="page"` and it is not
  exposed as a redundant destination.
- Anchor focus uses the shared visible focus token.
- This primitive does not collapse or hide overflow; therefore it never places
  undisclosed destinations behind an inaccessible ellipsis control.

## UI density

The navigation is flat and has no outer margin, padding, border, background, or
shadow. The ordered-list and item parents own tokenized sibling gaps; consumers
own the surrounding surface and layout spacing.

## Boundaries

Route construction, responsive overflow policy, localization, analytics, and
product navigation state remain consumer-owned.
