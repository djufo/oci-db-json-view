# ContactLinkList

## Purpose

`ContactLinkList` is a presentational contact-action list for public profiles,
detail side panels, contact cards, and legal or support surfaces.

## Source Evidence

- eLitua `ui/src/pages/client/guides/GuidePublicProfilePage/GuideContactLinks/GuideContactLinks.tsx`
  renders phone, email, and website actions in the public guide profile hero.
- eLitua guide and accommodation detail cards repeat tel/mail contact rows for
  selected records.
- Existing catalog coverage was checked first: `PublicProfilePage` embeds contact
  actions inside the full profile shell, `RecordDetailPanel` can render contact
  fields, and `InfoChipList` owns read-only metadata chips. No standalone
  component owned reusable contact link chrome.

## Contract

- Renders controlled contact items with label, href or click handler, icon,
  optional meta text, tone, disabled state, external-link behavior, and title.
- Supports pill and plain variants, compact and comfortable density, start/end
  alignment, optional empty fallback, and null rendering when no empty fallback
  is supplied.
- Leaves phone/email/website derivation, URL normalization, routing adapters,
  localization, analytics, and record loading to the consuming product.

## Non-Goals

- No contact validation, `tel:`/`mailto:` construction, copy-to-clipboard,
  provider-specific tracking, moderation, permission checks, or profile fetches.

## Review Expectations

- Long phone numbers, email addresses, and website labels wrap or truncate
  without overflowing compact cards.
- Empty state and disabled links preserve accessible semantics without creating
  fake navigation targets.
