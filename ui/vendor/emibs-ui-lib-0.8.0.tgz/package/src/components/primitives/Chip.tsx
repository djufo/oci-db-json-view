import { type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import "./materialStatusPrimitives.css";

export type ChipTone = "neutral" | "info" | "success" | "warning" | "danger" | "accent";
export type ChipVariant = "filled" | "outlined";
export type ChipSize = "sm" | "md";

export type ChipProps = HTMLAttributes<HTMLSpanElement> & {
  tone?: ChipTone;
  variant?: ChipVariant;
  size?: ChipSize;
  leading?: ReactNode;
  trailing?: ReactNode;
};

/** Canonical visual chip. Taxonomy components below only map domain values into this renderer. */
export function Chip({
  children,
  className,
  leading,
  size = "md",
  tone = "neutral",
  trailing,
  variant = "filled",
  ...props
}: ChipProps) {
  return (
    <span
      className={cn(
        "ui-chip",
        `ui-chip--${tone}`,
        `ui-chip--${variant}`,
        `ui-chip--${size}`,
        className,
      )}
      {...props}
    >
      {leading ? <span className="ui-chip__adornment" aria-hidden="true">{leading}</span> : null}
      <span className="ui-chip__label">{children}</span>
      {trailing ? <span className="ui-chip__adornment" aria-hidden="true">{trailing}</span> : null}
    </span>
  );
}

export type StatusChipStatus = "neutral" | "info" | "success" | "warning" | "danger";
export type BandChipBand = "shelved" | "deep-park" | "parked" | "normal" | "infra" | "campaign";
export type ClassChipClass = "convergence" | "build" | "orchestration";
export type ModelChipModel = "standard" | "advanced" | "unknown";

type TaxonomyChipProps = Omit<ChipProps, "children" | "tone"> & {
  label?: ReactNode;
};

const STATUS_TONES: Record<StatusChipStatus, ChipTone> = {
  neutral: "neutral",
  info: "info",
  success: "success",
  warning: "warning",
  danger: "danger",
};

const MODEL_TONES: Record<ModelChipModel, ChipTone> = {
  standard: "info",
  advanced: "accent",
  unknown: "neutral",
};

export function statusChipTone(status: StatusChipStatus): ChipTone {
  return STATUS_TONES[status];
}

export function modelChipTone(model: ModelChipModel): ChipTone {
  return MODEL_TONES[model];
}

export type StatusChipProps = TaxonomyChipProps & {
  status: StatusChipStatus;
};

export function StatusChip({ status, label, className, ...props }: StatusChipProps) {
  return (
    <Chip
      className={cn("ui-chip--taxonomy", className)}
      data-taxonomy="status"
      data-value={status}
      tone={statusChipTone(status)}
      {...props}
    >
      {label ?? status}
    </Chip>
  );
}

export type BandChipProps = TaxonomyChipProps & {
  band: BandChipBand;
};

export function BandChip({ band, label, className, ...props }: BandChipProps) {
  return (
    <Chip
      className={cn("ui-chip--taxonomy", `ui-chip--band-${band}`, className)}
      data-taxonomy="band"
      data-value={band}
      {...props}
    >
      {label ?? band}
    </Chip>
  );
}

export type ClassChipProps = TaxonomyChipProps & {
  classification: ClassChipClass;
};

export function ClassChip({ classification, label, className, ...props }: ClassChipProps) {
  return (
    <Chip
      className={cn("ui-chip--taxonomy", `ui-chip--class-${classification}`, className)}
      data-taxonomy="class"
      data-value={classification}
      {...props}
    >
      {label ?? classification}
    </Chip>
  );
}

export type ModelChipProps = TaxonomyChipProps & {
  model: ModelChipModel;
};

export function ModelChip({ model, label, className, ...props }: ModelChipProps) {
  return (
    <Chip
      className={cn("ui-chip--taxonomy", className)}
      data-taxonomy="model"
      data-value={model}
      tone={modelChipTone(model)}
      {...props}
    >
      {label ?? model}
    </Chip>
  );
}
