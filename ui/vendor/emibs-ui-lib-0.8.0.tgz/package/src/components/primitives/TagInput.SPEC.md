# TagInput

## Purpose

`TagInput` is a controlled tag-entry field for compact editable lists such as
languages, task references, capabilities, and route keywords.

## Contract

- Renders a labeled text input, optional datalist suggestions, an add action,
  selected tag chips, empty state, and per-tag remove actions.
- Input text and selected tags are controlled by the consuming app through
  `value`, `tags`, `onValueChange`, `onAdd`, and `onRemove`.
- Enter and comma can commit the current input value; consumers still own
  deduplication, validation, sorting, persistence, localization, and route
  behavior.
- Tags support neutral, info, success, warning, danger, and accent tones without
  embedding product-specific taxonomies.
- Uses only `ui-tag-input*` CSS classes and shared token variables.

## Source Evidence

- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` uses a
  language entry field with datalist suggestions, Enter/comma commit behavior,
  selected chips, and remove buttons.
- Score task details expose relationship arrays (`dependsOn`, `blockedBy`,
  `related`); `WorkItemRelationEditorPanel` composes this controlled chip-entry
  pattern for them without binding it to Score task services.

## Non-Goals

- No item creation policy, duplicate detection, validation, API calls, route
  updates, i18n, autocomplete service, keyboard shortcut registry, or relation
  semantics.

## Field contract (issue-564)

Brought under the shared FieldControl contract, **additively and back-compat**
(no existing prop removed):

- `error` — validation message; sets `aria-invalid` on the control and renders a
  `role="alert"` message wired via `aria-describedby`.
- `required` — renders a Required affordance and sets `aria-required` + the native
  `required` attribute.
- Error/required join the existing `hint` in `aria-describedby`.
