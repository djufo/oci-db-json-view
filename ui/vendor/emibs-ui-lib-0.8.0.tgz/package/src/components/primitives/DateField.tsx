import { type InputHTMLAttributes, type ReactNode, useId } from "react";
import { X } from "lucide-react";
import { cn } from "../../lib/cn";
import type { FieldControl } from "./Field";

export type DateFieldDensity = "compact" | "comfortable";

export type DateFieldProps = Omit<
  InputHTMLAttributes<HTMLInputElement>,
  "children" | "className" | "defaultValue" | "onChange" | "size" | "type" | "value"
> &
  Omit<FieldControl<string>, "value" | "defaultValue" | "onChange"> & {
    /** ISO calendar date (`YYYY-MM-DD`) or an empty string when unset. */
    value: string;
    onChange?: (value: string) => void;
    min?: string;
    max?: string;
    clearable?: boolean;
    clearLabel?: string;
    meta?: ReactNode;
    status?: ReactNode;
    hideLabel?: boolean;
    density?: DateFieldDensity;
    rootClassName?: string;
    inputClassName?: string;
  };

const ISO_DATE = /^\d{4}-\d{2}-\d{2}$/;

/** True when `value` is a real ISO calendar date (`YYYY-MM-DD`), rejecting impossible days. */
export function isIsoDateString(value: string): boolean {
  if (!ISO_DATE.test(value)) return false;
  const [year, month, day] = value.split("-").map(Number);
  if (month < 1 || month > 12 || day < 1 || day > 31) return false;
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
}

/** True when an ISO date sits within the inclusive `[min, max]` bounds; empty bounds are open. */
export function isDateWithinRange(value: string, min?: string, max?: string): boolean {
  if (!isIsoDateString(value)) return false;
  if (min && isIsoDateString(min) && value < min) return false;
  if (max && isIsoDateString(max) && value > max) return false;
  return true;
}

export function DateField({
  id,
  label,
  value,
  onChange,
  name,
  description,
  hint,
  error,
  meta,
  status,
  min,
  max,
  required = false,
  disabled = false,
  readOnly = false,
  clearable = true,
  clearLabel = "Clear date",
  hideLabel = false,
  density = "comfortable",
  rootClassName,
  inputClassName,
  "aria-describedby": ariaDescribedBy,
  ...props
}: DateFieldProps) {
  const generatedId = useId();
  const fieldId = id ?? `date-field-${generatedId}`;
  const descriptionId = description ? `${fieldId}-description` : undefined;
  const hintId = hint ? `${fieldId}-hint` : undefined;
  const errorId = error ? `${fieldId}-error` : undefined;
  const metaId = meta ? `${fieldId}-meta` : undefined;
  const describedBy =
    [ariaDescribedBy, descriptionId, hintId, errorId, metaId].filter(Boolean).join(" ") || undefined;
  const showClear = clearable && Boolean(value) && !disabled && !readOnly;

  return (
    <div
      className={cn(
        "ui-date-field",
        `ui-date-field--${density}`,
        disabled && "is-disabled",
        readOnly && "is-readonly",
        error && "has-error",
        rootClassName,
      )}
    >
      <div className="ui-date-field__top">
        <label
          className={cn("ui-date-field__label", hideLabel && "ui-date-field__label--hidden")}
          htmlFor={fieldId}
        >
          {label}
          {required ? (
            <span aria-hidden="true" className="ui-date-field__required">
              Required
            </span>
          ) : null}
        </label>
        {status ? (
          <span className="ui-date-field__status" aria-live="polite">
            {status}
          </span>
        ) : null}
      </div>
      {description ? (
        <span className="ui-date-field__description" id={descriptionId}>
          {description}
        </span>
      ) : null}
      <span className="ui-date-field__control">
        <input
          {...props}
          aria-describedby={describedBy}
          aria-invalid={error ? true : props["aria-invalid"]}
          aria-required={required || undefined}
          className={cn("ui-date-field__input", inputClassName)}
          disabled={disabled}
          id={fieldId}
          max={max}
          min={min}
          name={name}
          onChange={(event) => onChange?.(event.currentTarget.value)}
          readOnly={readOnly}
          required={required}
          type="date"
          value={value}
        />
        {showClear ? (
          <button
            aria-label={clearLabel}
            className="ui-date-field__clear"
            onClick={() => onChange?.("")}
            type="button"
          >
            <X aria-hidden="true" size={16} />
          </button>
        ) : null}
      </span>
      {hint ? (
        <span className="ui-date-field__hint" id={hintId}>
          {hint}
        </span>
      ) : null}
      {error ? (
        <span className="ui-date-field__error" id={errorId} role="alert">
          {error}
        </span>
      ) : null}
      {meta ? (
        <span className="ui-date-field__meta" id={metaId}>
          {meta}
        </span>
      ) : null}
    </div>
  );
}
