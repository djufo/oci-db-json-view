# Chip taxonomy

## Purpose

`Chip` is the one flat visual renderer for compact labels. `StatusChip`,
`BandChip`, `ClassChip`, and `ModelChip` are semantic adapters that map a domain
value into `Chip`; they do not own duplicate markup or styling. Dynamic product
policy, localization, and data mapping remain in consumers.

## Public contract

- `Chip`: `tone`, `variant="filled" | "outlined"`, `size="sm" | "md"`,
  `leading`, `trailing`, native span attributes, and children.
- `StatusChip`: required `status` plus optional `label`; status maps through the
  exported `statusChipTone()` policy.
- `BandChip`: required `band` (`shelved`, `deep-park`, `parked`, `normal`,
  `infra`, `campaign`) and optional `label`; colors use the canonical E1
  `--band-*` tokens.
- `ClassChip`: required `classification` (`convergence`, `build`,
  `orchestration`) and optional `label`; colors use `--delivery-*`.
- `ModelChip`: required `model` (`standard`, `advanced`, `unknown`)
  and optional `label`; mapping is exposed by `modelChipTone()`.
- Every taxonomy adapter accepts the remaining `Chip` presentation props and
  stamps `data-taxonomy` / `data-value` for inspection and testing.

## States matrix

| Primitive | Variants / values | Visual state | Required behavior |
| --- | --- | --- | --- |
| `Chip` | six tones × filled/outlined × sm/md | default | Token-derived compact label |
| `StatusChip` | neutral/info/success/warning/danger | semantic | Status text remains visible; color is supplementary |
| `BandChip` | shelved → campaign | semantic | One E1 band-token map, dormant-to-active |
| `ClassChip` | convergence/build/orchestration | semantic | One E1 delivery-class map |
| `ModelChip` | standard/advanced/unknown | semantic | Unknown stays neutral |
| all | long label | overflow | Ellipsis may clip visually; the DOM text remains complete |

## Accessibility

- Chips are non-interactive spans. Interactive filters/actions must use an
  actual button or link and may compose a Chip only as visible content.
- The semantic value is always rendered as text by default. Tone is never the
  only status signal.
- Decorative leading/trailing icons are hidden from assistive technology;
  consumers put the complete meaning in the label.

## Density and composition

The primitive owns only its control chrome. It has no outer margin, Card/Panel,
surface wrapper, or shadow; parents own sibling spacing with tokenized `gap`.
