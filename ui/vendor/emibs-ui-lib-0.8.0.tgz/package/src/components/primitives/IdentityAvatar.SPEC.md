# IdentityAvatar

## Purpose

Standalone identity/avatar primitive for account triggers, profile heroes,
editorial bylines, agent identity chrome, and compact user rows.

## Contract

- Renders a caller-supplied image, icon, or derived initials inside a stable
  square avatar footprint.
- Supports `xs`, `sm`, `md`, `lg`, and `xl` sizes plus circle, rounded, and
  square shapes.
- Supports neutral, info, success, warning, danger, and accent tones through
  shared catalog tokens.
- Optional status dot is presentational; consuming apps provide the status
  meaning through `statusLabel`.
- Uses a required accessible `label`; product code owns profile names, image
  URLs, verification state, role labels, and route behavior.

## Source Evidence

- Score `AccountMenu`, `AccountProfilePanel`, and `AgentProfilePanel` repeat
  inline avatar/initials rendering inside larger identity surfaces.
- eLitua `AuthDropdown`, public guide profile hero, and editorial bylines repeat
  account and author avatar glyphs.
- Existing larger catalog components expose avatar slots, but no standalone
  primitive owns the shared footprint, fallback, size, tone, and status-dot
  contract.

## Non-Goals

- No account menu, profile card, role badge, verification copy, upload control,
  image fallback network handling, routing, or auth state.
- No product-specific initials derivation beyond a simple display-label fallback.
