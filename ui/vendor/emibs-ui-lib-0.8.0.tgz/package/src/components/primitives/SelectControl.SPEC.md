# SelectControl

## Purpose

`SelectControl` is a controlled native select wrapper for dense task, admin,
filter, and profile forms. It keeps option-selector chrome, label layout,
placeholder, status, hint, error, metadata, and selected-option detail
consistent without owning catalogs or persistence.

## Source Evidence

- Score `ui/src/components/ui/select.tsx` wraps Radix select primitives for
  board, scheduler, admin, and planning controls that repeat the same
  dropdown field chrome.
- eLitua `client/guides/components/GuidesFilters.tsx` and
  `client/places/components/PlacesFilters.tsx` use native select controls for
  entity filtering.
- eLitua admin forms such as `pages/admin/users/UserEditPage.tsx` repeat
  labelled select rows for status, role, and workflow fields.
- Existing catalog coverage was checked first: `Field.Select` is a low-level
  child control, `ComboboxField` owns editable datalist entry, and
  `EntityFilterPanel` owns a full filter shell rather than a reusable select
  primitive.

## Contract

- Requires an `id`, `label`, controlled `value`, and optional `onValueChange`.
- Accepts string-valued options with optional disabled state, description, and
  metadata for a selected-option detail row.
- Supports placeholder, leading icon, status or loading label, hint, error,
  metadata text, hidden-label mode, compact and comfortable density, disabled
  state, and native select props.
- Forwards normal select attributes so consuming apps keep option loading,
  route synchronization, validation, localization, permission gating,
  persistence, and analytics.

## Non-Goals

- No custom popover, virtualized list, async search, fuzzy matching, grouped
  menu, multi-select, option fetching, validation schema, or route state.
- No dependency on Score's Radix/shadcn select implementation; apps can adapt
  progressively from native selects or custom wrappers.

## Review Checks

- Hidden labels still provide an accessible select name.
- Hint, selected detail, error, and metadata text are linked through
  `aria-describedby`.
- Loading disables interaction and announces status without dropping the
  controlled value.
- Long labels, hints, errors, and selected descriptions wrap without overlapping
  icons or the chevron in compact and comfortable densities.
