import {
  type ChangeEvent,
  type KeyboardEvent,
  type MouseEvent,
  type ReactNode,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
} from "react";
import { Search, X } from "lucide-react";
import { cn } from "../../lib/cn";

export type CommandPalettePlacement = "fixed" | "contained";

export type CommandPaletteItem = {
  id: string;
  label: ReactNode;
  description?: ReactNode;
  meta?: ReactNode;
  icon?: ReactNode;
  href?: string;
  active?: boolean;
  disabled?: boolean;
  onSelect?: (item: CommandPaletteItem) => void;
};

export type CommandPaletteGroup = {
  id: string;
  title: ReactNode;
  items: CommandPaletteItem[];
  emptyLabel?: ReactNode;
};

export type CommandPaletteProps = {
  open: boolean;
  query: string;
  onQueryChange: (query: string) => void;
  groups: CommandPaletteGroup[];
  ariaLabel?: string;
  inputLabel?: string;
  placeholder?: string;
  closeLabel?: string;
  closeText?: ReactNode;
  shortcutHint?: ReactNode;
  noMatchesLabel?: ReactNode;
  placement?: CommandPalettePlacement;
  autoFocus?: boolean;
  trapFocus?: boolean;
  closeOnSelect?: boolean;
  onOpenChange?: (open: boolean) => void;
  onItemSelect?: (item: CommandPaletteItem) => void;
  className?: string;
};

type SelectableCommandPaletteItem = {
  key: string;
  item: CommandPaletteItem;
  elementId: string;
};

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button:not([disabled])",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "[tabindex]:not([tabindex='-1'])",
].join(",");

function commandItemKey(groupId: string, item: CommandPaletteItem, index: number): string {
  return `${groupId}:${item.id}:${index}`;
}

function commandItemElementId(key: string): string {
  return `ui-command-palette-item-${key.replace(/[^a-zA-Z0-9_-]/g, "-")}`;
}

function getFocusableElements(container: HTMLElement | null): HTMLElement[] {
  if (!container) return [];
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter((element) => {
    if (element.hasAttribute("disabled")) return false;
    if (element.getAttribute("aria-hidden") === "true") return false;
    return element.tabIndex !== -1;
  });
}

export function CommandPalette({
  open,
  query,
  onQueryChange,
  groups,
  ariaLabel = "Command palette",
  inputLabel = "Command palette search",
  placeholder = "Search commands",
  closeLabel = "Close command palette",
  closeText = <X size={16} aria-hidden="true" />,
  shortcutHint,
  noMatchesLabel,
  placement = "fixed",
  autoFocus = true,
  trapFocus = placement === "fixed",
  closeOnSelect = true,
  onOpenChange,
  onItemSelect,
  className,
}: CommandPaletteProps) {
  const dialogRef = useRef<HTMLElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const previousFocusRef = useRef<HTMLElement | null>(null);
  const itemRefs = useRef<Record<string, HTMLElement | null>>({});
  const instanceId = useId();
  const resultsId = `${instanceId}-results`;
  const selectableItems = useMemo<SelectableCommandPaletteItem[]>(
    () =>
      groups.flatMap((group) =>
        group.items
          .map((item, index) => {
            const key = commandItemKey(group.id, item, index);
            return {
              key,
              item,
              elementId: commandItemElementId(key),
            };
          })
          .filter(({ item }) => !item.disabled),
      ),
    [groups],
  );
  const [highlightedKey, setHighlightedKey] = useState<string | null>(null);
  const highlightedItem = selectableItems.find((candidate) => candidate.key === highlightedKey) ?? null;

  useEffect(() => {
    if (!open) {
      setHighlightedKey(null);
      return;
    }
    setHighlightedKey((current) =>
      selectableItems.some((candidate) => candidate.key === current)
        ? current
        : selectableItems[0]?.key ?? null,
    );
  }, [open, selectableItems]);

  useEffect(() => {
    if (!open || placement !== "fixed") return;
    previousFocusRef.current = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    return () => {
      const previousFocus = previousFocusRef.current;
      previousFocusRef.current = null;
      if (previousFocus && document.contains(previousFocus)) {
        previousFocus.focus({ preventScroll: true });
      }
    };
  }, [open, placement]);

  useEffect(() => {
    if (!open || !autoFocus) return;
    inputRef.current?.focus();
  }, [autoFocus, open]);

  useEffect(() => {
    if (!open || !highlightedItem) return;
    itemRefs.current[highlightedItem.key]?.scrollIntoView({ block: "nearest" });
  }, [highlightedItem, open]);

  if (!open) {
    return null;
  }

  const allGroupsEmpty = groups.every((group) => group.items.length === 0);
  const shouldShowNoMatches = Boolean(noMatchesLabel && allGroupsEmpty);

  const close = () => onOpenChange?.(false);
  const selectItem = (item: CommandPaletteItem) => {
    if (item.disabled) return;
    const handled = Boolean(item.onSelect || onItemSelect);
    item.onSelect?.(item);
    onItemSelect?.(item);
    if (!handled && item.href) {
      window.location.href = item.href;
    }
    if (closeOnSelect) {
      onOpenChange?.(false);
    }
  };
  const moveHighlight = (direction: 1 | -1) => {
    if (selectableItems.length === 0) return;
    const currentIndex = selectableItems.findIndex((candidate) => candidate.key === highlightedKey);
    const nextIndex = currentIndex === -1
      ? direction > 0 ? 0 : selectableItems.length - 1
      : (currentIndex + direction + selectableItems.length) % selectableItems.length;
    setHighlightedKey(selectableItems[nextIndex].key);
  };
  const trapTabKey = (event: KeyboardEvent<HTMLElement>) => {
    const focusable = getFocusableElements(dialogRef.current);
    if (focusable.length === 0) {
      event.preventDefault();
      return;
    }
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    const active = document.activeElement;
    if (event.shiftKey && (active === first || active === dialogRef.current)) {
      event.preventDefault();
      last.focus();
      return;
    }
    if (!event.shiftKey && active === last) {
      event.preventDefault();
      first.focus();
    }
  };
  const handleKeyDown = (event: KeyboardEvent<HTMLElement>) => {
    if (event.key === "Escape") {
      event.preventDefault();
      event.stopPropagation();
      close();
      return;
    }
    if (event.key === "ArrowDown" || event.key === "ArrowUp") {
      event.preventDefault();
      event.stopPropagation();
      moveHighlight(event.key === "ArrowDown" ? 1 : -1);
      return;
    }
    if (event.key === "Enter") {
      const target = event.target as HTMLElement | null;
      if (target?.closest("[data-command-palette-close]")) return;
      if (!highlightedItem) return;
      event.preventDefault();
      event.stopPropagation();
      selectItem(highlightedItem.item);
      return;
    }
    if (trapFocus && event.key === "Tab") {
      trapTabKey(event);
    }
  };

  const dialog = (
    <section
      aria-label={ariaLabel}
      aria-modal={placement === "fixed" ? true : undefined}
      className={cn("ui-command-palette", `ui-command-palette--${placement}`, className)}
      onKeyDown={handleKeyDown}
      ref={dialogRef}
      role={placement === "fixed" ? "dialog" : "search"}
    >
      <header className="ui-command-palette__header">
        <Search size={15} aria-hidden="true" />
        <input
          ref={inputRef}
          aria-activedescendant={highlightedItem?.elementId}
          aria-autocomplete="list"
          aria-controls={resultsId}
          aria-expanded={open}
          aria-haspopup="listbox"
          aria-label={inputLabel}
          className="ui-command-palette__input"
          onChange={(event: ChangeEvent<HTMLInputElement>) => onQueryChange(event.target.value)}
          placeholder={placeholder}
          role="combobox"
          type="search"
          value={query}
        />
        {shortcutHint ? <span className="ui-command-palette__shortcut">{shortcutHint}</span> : null}
        <button
          aria-label={closeLabel}
          className="ui-command-palette__close"
          data-command-palette-close=""
          onClick={close}
          type="button"
        >
          {closeText}
        </button>
      </header>

      <div className="ui-command-palette__body" id={resultsId}>
        {groups.map((group) => (
          <section className="ui-command-palette__group" key={group.id}>
            <h3>{group.title}</h3>
            <div className="ui-command-palette__group-list" role="listbox">
              {group.items.length > 0 ? (
                group.items.map((item, index) => {
                  const itemKey = commandItemKey(group.id, item, index);
                  return (
                    <CommandPaletteItemControl
                      highlightedKey={highlightedKey}
                      item={item}
                      itemKey={itemKey}
                      itemRef={(element) => {
                        itemRefs.current[itemKey] = element;
                      }}
                      key={itemKey}
                      onHighlight={setHighlightedKey}
                      onItemSelect={onItemSelect}
                      onSelectItem={selectItem}
                      rowId={commandItemElementId(itemKey)}
                    />
                  );
                })
              ) : (
                <p className="ui-command-palette__empty">{group.emptyLabel ?? "No commands available."}</p>
              )}
            </div>
          </section>
        ))}
        {shouldShowNoMatches ? (
          <p className="ui-command-palette__empty ui-command-palette__empty--global">{noMatchesLabel}</p>
        ) : null}
      </div>
    </section>
  );

  if (placement === "contained") {
    return <div className="ui-command-palette-layer ui-command-palette-layer--contained">{dialog}</div>;
  }

  return (
    <div className="ui-command-palette-layer ui-command-palette-layer--fixed">
      <button
        aria-label={closeLabel}
        className="ui-command-palette__overlay"
        onClick={close}
        type="button"
      />
      {dialog}
    </div>
  );
}

function CommandPaletteItemControl({
  highlightedKey,
  item,
  itemKey,
  itemRef,
  onHighlight,
  onItemSelect,
  onSelectItem,
  rowId,
}: {
  highlightedKey: string | null;
  item: CommandPaletteItem;
  itemKey: string;
  itemRef: (element: HTMLElement | null) => void;
  onHighlight: (key: string) => void;
  onItemSelect?: (item: CommandPaletteItem) => void;
  onSelectItem: (item: CommandPaletteItem) => void;
  rowId: string;
}) {
  const handleSelect = (event: MouseEvent<HTMLElement>) => {
    if (item.disabled) {
      event.preventDefault();
      return;
    }
    if (item.onSelect || onItemSelect) {
      event.preventDefault();
    }
    onSelectItem(item);
  };
  const handleHighlight = () => {
    if (!item.disabled) onHighlight(itemKey);
  };

  const content = (
    <>
      {item.icon ? <span className="ui-command-palette__item-icon">{item.icon}</span> : null}
      <span className="ui-command-palette__item-copy">
        <span className="ui-command-palette__item-label">{item.label}</span>
        {item.description ? <span className="ui-command-palette__item-description">{item.description}</span> : null}
      </span>
      {item.meta ? <span className="ui-command-palette__item-meta">{item.meta}</span> : null}
    </>
  );
  const className = cn(
    "ui-command-palette__item",
    item.active && "is-active",
    highlightedKey === itemKey && "is-highlighted",
    item.disabled && "is-disabled",
  );

  if (item.href && !item.disabled) {
    return (
      <a
        aria-current={item.active ? "page" : undefined}
        aria-disabled={item.disabled || undefined}
        aria-selected={highlightedKey === itemKey}
        className={className}
        href={item.href}
        id={rowId}
        onClick={handleSelect}
        onFocus={handleHighlight}
        onMouseEnter={handleHighlight}
        ref={itemRef}
        role="option"
      >
        {content}
      </a>
    );
  }

  return (
    <button
      aria-disabled={item.disabled || undefined}
      aria-selected={highlightedKey === itemKey}
      className={className}
      disabled={item.disabled}
      id={rowId}
      onClick={handleSelect}
      onFocus={handleHighlight}
      onMouseEnter={handleHighlight}
      ref={itemRef}
      role="option"
      type="button"
    >
      {content}
    </button>
  );
}
