# ContentTabs

## Purpose

`ContentTabs` is a controlled tab strip for switching visible content sections
inside product pages without owning routing, filtering, persistence, or the
panel body.

## Source Evidence

- eLitua `ui/src/pages/admin/payments/PaymentsPage.tsx` renders a page header
  with Transactions/Payouts content tabs.
- eLitua `ui/src/pages/blog/BlogListingPage/BlogListingPage.tsx` renders
  category tabs that filter the article listing.
- Score was inspected during this extraction; its broad route tabs are already
  represented by `WorkspaceShell`, so this component stays focused on
  content-local tab controls.

## Contract

- Tabs are controlled by `activeId`; consumers update product state or routes
  through `onTabChange`, item-level `onSelect`, or concrete `href` values.
- Renders optional title, description, actions, tab icons, descriptions, badges,
  meta text, and a body panel slot.
- Supports contained and underline variants plus compact/comfortable density.
- Uses button tabs for local state and anchor tabs for route-backed navigation.
- Supports Left/Right/Home/End keyboard focus movement inside the tab list.

## Non-Goals

- No data fetching, filtering, route synchronization, analytics, payment
  behavior, article category rules, localization, or panel content ownership.
