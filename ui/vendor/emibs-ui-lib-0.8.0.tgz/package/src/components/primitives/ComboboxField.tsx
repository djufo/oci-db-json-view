import { type InputHTMLAttributes, type ReactNode, useId } from "react";
import { X } from "lucide-react";
import { cn } from "../../lib/cn";
import { useDensity, type Density } from "../../theme/DensityScope";

export type ComboboxFieldDensity = Density;

export type ComboboxFieldOption = {
  value: string;
  label?: string;
  disabled?: boolean;
};

export type ComboboxFieldProps = Omit<
  InputHTMLAttributes<HTMLInputElement>,
  "children" | "className" | "list" | "onChange" | "size" | "value"
> & {
  id: string;
  label: ReactNode;
  value: string;
  options?: ComboboxFieldOption[];
  onValueChange?: (value: string) => void;
  icon?: ReactNode;
  action?: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  meta?: ReactNode;
  clearLabel?: string;
  hideLabel?: boolean;
  density?: ComboboxFieldDensity;
  inputClassName?: string;
  rootClassName?: string;
  onClear?: () => void;
};

export function ComboboxField({
  id,
  label,
  value,
  options = [],
  onValueChange,
  icon,
  action,
  hint,
  error,
  meta,
  clearLabel = "Clear selection",
  hideLabel = false,
  density,
  inputClassName,
  rootClassName,
  onClear,
  disabled,
  required = false,
  "aria-describedby": ariaDescribedBy,
  ...props
}: ComboboxFieldProps) {
  const resolvedDensity = useDensity(density);
  const generatedListId = useId();
  const listId = options.length > 0 ? `${id}-${generatedListId}-options` : undefined;
  const hintId = hint ? `${id}-hint` : undefined;
  const errorId = error ? `${id}-error` : undefined;
  const metaId = meta ? `${id}-meta` : undefined;
  const describedBy = [ariaDescribedBy, hintId, errorId, metaId].filter(Boolean).join(" ");
  const showClear = Boolean(onClear && value.length > 0 && !disabled);

  return (
    <div className={cn("ui-combobox-field", `ui-combobox-field--${resolvedDensity}`, disabled && "is-disabled", rootClassName)}>
      <label className={cn("ui-combobox-field__label", hideLabel && "ui-combobox-field__label--hidden")} htmlFor={id}>
        {label}
        {required ? (
          <span aria-hidden="true" className="ui-combobox-field__required">
            {" "}
            Required
          </span>
        ) : null}
      </label>
      <div className={cn("ui-combobox-field__control", error && "has-error")}>
        {icon ? <span className="ui-combobox-field__icon">{icon}</span> : null}
        <input
          {...props}
          aria-describedby={describedBy || undefined}
          aria-invalid={error ? true : props["aria-invalid"]}
          aria-required={required || undefined}
          autoComplete={props.autoComplete ?? "off"}
          className={cn("ui-combobox-field__input", inputClassName)}
          disabled={disabled}
          id={id}
          list={listId}
          required={required || undefined}
          onChange={(event) => onValueChange?.(event.currentTarget.value)}
          value={value}
        />
        {showClear ? (
          <button className="ui-combobox-field__clear" type="button" aria-label={clearLabel} onClick={() => onClear?.()}>
            <X size={14} aria-hidden="true" />
          </button>
        ) : null}
        {action ? <span className="ui-combobox-field__action">{action}</span> : null}
      </div>
      {hint ? (
        <span className="ui-combobox-field__hint" id={hintId}>
          {hint}
        </span>
      ) : null}
      {error ? (
        <span className="ui-combobox-field__error" id={errorId}>
          {error}
        </span>
      ) : null}
      {meta ? (
        <span className="ui-combobox-field__meta" id={metaId} aria-live="polite">
          {meta}
        </span>
      ) : null}
      {listId ? (
        <datalist id={listId}>
          {options.map((option) => (
            <option disabled={option.disabled} key={option.value} label={option.label} value={option.value} />
          ))}
        </datalist>
      ) : null}
    </div>
  );
}
