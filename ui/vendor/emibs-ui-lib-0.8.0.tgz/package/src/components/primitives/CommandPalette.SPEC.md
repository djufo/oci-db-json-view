# CommandPalette

## Purpose

`CommandPalette` is a controlled quick-jump overlay for dense workspaces and
catalog-style tools. It renders a search input, grouped command results,
active/disabled states, empty states, keyboard Escape close, and anchor/button
rows without owning the shortcut registry, routing, filtering, or command
execution.

## Source Evidence

- Score catalog and app-shell surfaces repeat searchable navigation, route
  switching, theme/page jumps, and component lookup in
  `/engineering/projects/score/ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  and `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`.
- eLitua keeps route/menu/search state in
  `/engineering/projects/elitua/ui/src/features/menu/service/menuTypes/menuTypes.ts`
  and `/engineering/projects/elitua/ui/src/components/layout/header/Header/Header.tsx`.
- Existing coverage was checked first: `SearchField` explicitly excludes command
  palette behavior, `NavigationMenu` owns static menu rows, and
  `CommandConsole` owns chat/terminal transcript workflows.

## Contract

- Controlled by `open`, `query`, `onQueryChange`, `groups`, and optional
  `onOpenChange`.
- Supports fixed modal placement for products and contained placement for demos.
- Renders anchors when `href` is supplied and buttons otherwise.
- Calls item-local and top-level selection callbacks, then optionally closes.
- Supports optional autofocus and focus trapping for fixed modal usage.
- Supports item icons, descriptions, metadata, active states, disabled states,
  group empty labels, a global no-match label, shortcut hint, and custom close
  content.

## Non-Goals

- No global keyboard shortcut binding, filtering algorithm, fuzzy matching,
  routing adapter, registry lookup, command execution, persistence, analytics,
  or localization.
- It does not replace normal navigation menus or search fields; it composes
  filtered command descriptors supplied by the consuming app.

## Review Checks

- Fixed placement must close on Escape, overlay click, and close button.
- Fixed placement must keep tab focus inside the dialog while open and restore
  focus when it closes.
- ArrowUp/ArrowDown must move the highlighted enabled result with wrapping;
  Enter must activate the highlighted result.
- Contained placement must fit catalog review surfaces without viewport-fixed
  behavior.
- Long labels, descriptions, and metadata wrap or truncate without overlapping
  adjacent controls on mobile.
