# DescriptionList

## Purpose

`DescriptionList` renders compact label/value facts for profile credentials,
record metadata, diagnostics, and task details without owning data mapping,
formatting, routing, or persistence.

## Contract

- Accepts controlled `items` with `id`, `label`, optional `value`, icon, link,
  external-link marker, tone, and metadata.
- Omits items with `null`, `undefined`, empty-string, or `hidden` values.
- Renders an accessible `dl`; callers may provide `ariaLabel` when surrounding
  headings do not name the list.
- Supports `compact` and `comfortable` density.
- Every visible item renders through the one flat `FieldRow`; the list parent
  owns grid columns and sibling gap. `FieldRow` owns no card, padding, margin,
  border, or shadow.
- `FieldRow` is read-only fact presentation only. Editable controls keep using
  `Field`; a fact row must never become an input-row wrapper.
- Supports one, two, three, or automatic responsive columns.
- Shows a caller-supplied empty label when no visible item remains.

## Boundaries

- No product DTO mapping, date formatting, route generation, permission checks,
  localization, analytics, or API calls.
- No full record shell, section chrome, title/action header, or edit behavior;
  those remain in `RecordDetailPanel`, `PublicProfilePage`, and consuming apps.
- Links are passed in already normalized; product apps own route safety and
  external URL policy.

## Source Evidence

- eLitua public guide credentials render a standalone `dl` for license,
  licensed-since, and country facts.
- Score and eLitua record-detail panels repeat compact field grids for task,
  project, profile, accommodation, guide, and diagnostic facts.
- Existing catalog coverage was checked first: `RecordDetailPanel` and
  `PublicProfilePage` cover full shells, while `MetricGrid` covers numeric
  summaries. No standalone primitive represented reusable label/value details.
