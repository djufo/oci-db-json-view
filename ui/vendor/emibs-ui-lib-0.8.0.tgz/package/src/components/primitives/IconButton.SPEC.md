# IconButton

## Purpose

`IconButton` is a compact, labeled icon-only button for dense action slots,
close controls, destructive affordances, social/header utilities, and toolbar
actions.

## Source Evidence

- Score `ui/src/design-system/DeleteIconButton.tsx` and task/project detail
  action slots use icon-only destructive buttons with explicit labels.
- Score board, agent, task document, and attachment rows use compact external
  open/download icon actions.
- eLitua portal header, sidebars, bottom sheets, record detail panels, map
  errors, and entity cards use repeated icon-only close/menu/social controls.

## Contract

- Requires `label` and applies it as `aria-label`; the icon is decorative.
- Renders a `<button>` by default or an `<a>` when `href` is supplied.
- Anchor props are spread through to the `<a>`. A spread `target="_blank"` that
  carries no `rel` is rendered with `rel="noopener noreferrer"`, since the
  `href` is consumer-supplied and therefore untrusted; an explicit caller `rel`
  is always preserved.
- `showTooltip` defaults to true and mirrors the label into `title` unless a
  custom title is supplied.
- Supports neutral, ghost, danger, and active variants plus sm/md/lg fixed
  square sizes.
- The component is presentational only; routing, analytics, confirmation,
  mutation, menu state, and toast behavior stay in consuming apps.

## Non-Goals

- No routing, keyboard shortcut handling, confirmation flow, icon selection,
  telemetry, or permission logic.
- Does not replace full text buttons; use it only when adjacent copy or a
  familiar icon makes the action clear.
