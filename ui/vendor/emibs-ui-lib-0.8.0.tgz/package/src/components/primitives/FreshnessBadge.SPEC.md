# FreshnessBadge

## Purpose

`FreshnessBadge` presents Score-compatible heartbeat age text without importing
Score. The canonical source inspected for parity is
`/engineering/projects/score/ui/src/ui/timing.ts` (`formatHeartbeat`). That
helper defines age-display buckets, not a stale/fresh threshold.

## Public contract

- `value` accepts an ISO/date string, epoch milliseconds, `Date`, or nullish
  value. Missing and invalid values render `unknown`.
- `now` defaults to `Date.now()` and is injectable for deterministic display and
  tests.
- `formatFreshnessAge()` mirrors Score exactly: clamp future ages to zero;
  round seconds; `<60s` seconds, `<60m` floored minutes, `<24h` floored hours,
  then floored days.
- `staleAfterMs` is optional explicit consumer policy. With no threshold the
  state is `known`; with one it is `fresh` below the threshold and `stale` at or
  above it. No hidden Score threshold is invented.
- `getFreshness()` exposes the canonical parsing/format/state result.

## States matrix

| Input / policy | State | Example |
| --- | --- | --- |
| missing or invalid | unknown | `Updated · unknown` |
| future or now | known/fresh | `Updated · 0s ago` |
| age < 60s | known/fresh | `Updated · 59s ago` |
| 60s <= age < 60m | known/fresh | `Updated · 1m ago` |
| 60m <= age < 24h | known/fresh | `Updated · 1h ago` |
| age >= 24h | known/fresh | `Updated · 1d ago` |
| age >= explicit `staleAfterMs` | stale | stale token tone |

## Accessibility

- The visible label and age text are the status meaning; color is
  supplementary.
- Valid values render semantic `<time dateTime="…">`; unknown does not claim a
  timestamp.
- Consumers should choose a stable `now` update cadence to avoid excessive live
  announcements in rapidly changing regions.

## Density and composition

The badge owns only its compact label chrome. It has no outer margin, Card/Panel
wrapper, nested surface, or shadow; parents own sibling gaps.
