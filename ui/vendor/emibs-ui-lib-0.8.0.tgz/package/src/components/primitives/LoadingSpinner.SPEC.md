# LoadingSpinner

## Purpose

`LoadingSpinner` is a small presentational primitive for indeterminate loading
states. It standardizes the repeated route, map, panel, and inline loading
affordances without owning async state, retries, data fetching, or localization.

## Source Evidence

- eLitua `ui/src/App.tsx` renders a centered route-guard loading spinner while
  restoring the authenticated session.
- eLitua `ui/src/components/ui/MapViewport/MapViewport.tsx` renders an inline
  map-loading spinner beside the loading label.
- `emibs-ui-lib` panels already repeat local spinner markup inside map, explorer,
  entity-grid, admin, idea, relationship, notice, toast, and diagnostic loading
  states, which confirms a shared visual primitive is useful below full
  `DataStatePanel` surfaces.

## Contract

- Renders a `role="status"` wrapper with an animated ring and optional visible
  label.
- Supports `sm`, `md`, and `lg` sizes; `inline` and `centered` variants; and the
  shared tone vocabulary.
- Accepts `ariaLabel` when the visible label is omitted or when the visible node
  is not plain text.

## Non-Goals

- No polling, timeout, retry, route guarding, map SDK state, data fetching,
  skeleton layout, progress percentage, or toast behavior.
- No replacement for full-state panels such as `DataStatePanel`, `AuthStatusPanel`,
  or feature-specific loading/error/empty surfaces.

## Review Checks

- Hidden-label and visible-label variants both expose an accessible loading
  status.
- Reduced-motion users see a stable ring without animation.
- The centered variant does not resize its parent unexpectedly.
