# Toolbar

## Purpose

`Toolbar` groups a compact set of related actions under native toolbar
semantics. `ToolbarItem` is the matching native button for the optional roving
focus mechanism.

## Public API

- `ariaLabel` is required and names the action group.
- `orientation` is `horizontal` (default) or `vertical` and is reflected in
  both layout and `aria-orientation`.
- `rovingFocus=false` leaves each child's native tab behavior untouched.
- `rovingFocus=true` gives enabled `ToolbarItem` children one tab stop and
  supports orientation-aware arrows plus Home/End with wraparound.
- `ToolbarItem` accepts native button attributes and defaults `type` to
  `button` so it does not accidentally submit a containing form.

## Variants and states matrix

| State | Layout | Keyboard behavior |
| --- | --- | --- |
| Horizontal/native | Row | Native child tab order |
| Vertical/native | Column | Native child tab order |
| Horizontal/roving | Row | Left/Right, Home/End; wraps |
| Vertical/roving | Column | Up/Down, Home/End; wraps |
| Disabled item | Either | Skipped by roving focus and native activation |
| `aria-disabled` item | Either | Removed from the roving sequence; consumer still owns activation suppression |

## Accessibility contract

- The root exposes `role="toolbar"`, a required accessible name, and the
  synchronized orientation.
- Roving focus operates only on explicit `ToolbarItem` descendants, never on a
  heuristic list of every nested control. This is the canonical opt-in
  mechanism and prevents unrelated nested controls from being mutated.
- Roving navigation prevents page scrolling only for keys it handles. Tab and
  Shift+Tab continue to enter or leave the toolbar normally.
- Stateful controls placed in the toolbar remain responsible for the
  ui-affordance contract: their accessible label must state current state first
  and the next action second. `ToolbarItem` itself is a stateless action button.

## UI density

The toolbar is flat and has no outer padding, margin, border, background, or
shadow. It owns the tokenized gap between its own child controls. The page owns
the surrounding surface and separation from sibling regions.

## Non-goals

No command registry, overflow menu, product permissions, shortcut binding,
selection state, or icon-only labelling policy.
