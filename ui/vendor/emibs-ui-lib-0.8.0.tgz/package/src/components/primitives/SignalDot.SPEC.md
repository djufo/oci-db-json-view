# SignalDot

## Purpose

`SignalDot` is the smallest presentational status signal: a semantic dot with a
required text label. Consumers own health thresholds, polling, and status
derivation.

## Public contract

- Required `label` is either visibly rendered (`showLabel`) or becomes the
  accessible name.
- `tone`: neutral, info, success, warning, or danger.
- `pulse` adds optional motion for a live signal; reduced-motion preferences
  disable it.
- Native span attributes and `className` remain available.

## States matrix

| State | Visual | Accessible result |
| --- | --- | --- |
| neutral/info/success/warning/danger | semantic token color | required status label |
| icon-only | dot | root `aria-label` |
| labelled | dot + visible label | visible text names status |
| pulsing | animated halo | same non-motion meaning |
| reduced motion | static dot | same label and tone |

## Accessibility

The root uses `role="status"`; the dot itself is decorative. Meaning is never
encoded by color or animation alone.

## Density and composition

SignalDot has no surface wrapper, outer padding/margin/border, or shadow.
Parents own sibling spacing; the label gap uses the theme spacing scale.
