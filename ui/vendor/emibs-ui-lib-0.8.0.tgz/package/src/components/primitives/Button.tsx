import { forwardRef, type AnchorHTMLAttributes, type ButtonHTMLAttributes, type ReactNode } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "../../lib/cn";
import "./materialControls.css";

const buttonVariants = cva("ui-button", {
  variants: {
    variant: {
      primary: "ui-button--primary",
      secondary: "ui-button--secondary",
      ghost: "ui-button--ghost",
      quiet: "ui-button--quiet",
      danger: "ui-button--danger",
    },
    size: {
      sm: "ui-button--sm",
      md: "ui-button--md",
      lg: "ui-button--lg",
      icon: "ui-button--icon",
    },
  },
  defaultVariants: {
    variant: "primary",
    size: "md",
  },
});

export type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> &
  VariantProps<typeof buttonVariants> & {
    /** Prevents activation and exposes the in-progress state to assistive technology. */
    loading?: boolean;
    /** Accessible name while loading. Defaults to a contextual "Loading: …" label. */
    loadingLabel?: string;
  };

function resolveLoadingLabel(children: ReactNode, ariaLabel?: string, loadingLabel?: string): string {
  if (loadingLabel) return loadingLabel;
  if (ariaLabel) return `Loading: ${ariaLabel}`;
  if (typeof children === "string" || typeof children === "number") return `Loading: ${children}`;
  return "Loading";
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    "aria-label": ariaLabel,
    children,
    className,
    disabled,
    loading = false,
    loadingLabel,
    onClick,
    size,
    variant,
    ...props
  },
  ref,
) {
  return (
    <button
      {...props}
      ref={ref}
      aria-busy={loading || undefined}
      aria-disabled={loading || undefined}
      aria-label={loading ? resolveLoadingLabel(children, ariaLabel, loadingLabel) : ariaLabel}
      className={cn(buttonVariants({ variant, size }), loading && "is-loading", className)}
      disabled={disabled}
      onClick={(event) => {
        if (loading) {
          event.preventDefault();
          event.stopPropagation();
          return;
        }
        onClick?.(event);
      }}
    >
      {loading ? <span className="ui-button__spinner" aria-hidden="true" /> : null}
      {children}
    </button>
  );
});

export type ButtonLinkProps = AnchorHTMLAttributes<HTMLAnchorElement> &
  VariantProps<typeof buttonVariants> & {
    /** Where the link goes. A ButtonLink is navigation; use Button for an action. */
    href: string;
  };

/**
 * A link that looks like a button, for navigation that deserves a button's
 * weight ("New job", "Open report"). It is a real anchor, so it can be opened
 * in a new tab and is announced as a link — which a `<button>` that calls
 * `navigate()` is not. It takes Button's `variant` and `size`.
 */
export const ButtonLink = forwardRef<HTMLAnchorElement, ButtonLinkProps>(function ButtonLink(
  { className, size, variant, children, ...props },
  ref,
) {
  return (
    <a {...props} ref={ref} className={cn(buttonVariants({ variant, size }), "ui-button--link", className)}>
      {children}
    </a>
  );
});
