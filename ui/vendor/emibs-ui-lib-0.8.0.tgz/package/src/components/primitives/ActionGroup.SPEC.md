# ActionGroup

## Purpose

`ActionGroup` is a small layout primitive for button and link rows in toolbars,
form footers, dialogs, and compact cards. It keeps wrapping, alignment, spacing,
and mobile stacking consistent without owning any command behavior.

## Source Evidence

- Score repeats action-row layout in scheduler bulk controls, scheduler edit
  dialog actions, task detail header actions, board card actions, project editor
  footer actions, and agent/admin toolbars.
- eLitua repeats the same responsive save/delete/cancel action rows in admin
  edit pages, account/Bókun forms, cookie consent actions, and guide profile
  forms.
- Existing catalog components own action slots inside larger surfaces, and
  `IconButton` owns icon-only controls. No standalone primitive represented the
  neutral row layout for mixed action children.

## Contract

- Accepts arbitrary React children and renders only layout chrome.
- Supports `align`, `gap`, `orientation`, and `fullWidth` props for compact
  toolbar rows, responsive footer rows, and stacked mobile forms.
- Adds `role="group"` only when a `label` or `aria-label` is supplied.
- Consuming apps own click handlers, routing, mutation state, permissions,
  labels, icons, validation, and localization.

## Non-Goals

- No button styling, command ordering, confirmation flow, focus trapping,
  overflow menu behavior, or product-specific disabled/busy policy.

## Review Checks

- Multiple buttons wrap without overlap in narrow catalog widths.
- `fullWidth` gives form-footer actions stable touch targets on mobile.
- Alignment variants do not change child button semantics.
