# FloatingLabelField

## Purpose

`FloatingLabelField` is a controlled single-line field control using the
Material outlined text-field pattern: the label sits on the top-left border of
the control, with the outline remaining visible around the label notch.

## Source Evidence

- Material UI and Angular Material outlined text fields keep the label anchored
  on the outline, use a surface-colored label background to interrupt the
  border, and recolor the outline/label for focus and error states.
- Score search and filter bars need the same compact, high-recognition field
  treatment without taking ownership of query parsing, routing, persistence, or
  result loading.
- Existing `TextInputControl`, `SearchField`, and `IconInputField` cover stacked
  labels, pill search, and icon-adorned inputs, but none place the label on the
  top-left outline.

## Contract

- Implements the shared `FieldControl<string>` shape: `id`, `name`, `label`,
  controlled `value` or uncontrolled `defaultValue`, `onChange` (with
  `onValueChange` retained as a compatibility alias), `hint`, `error`,
  `required`, `disabled`, and `readOnly`. When both values are supplied,
  `value` wins and no `defaultValue` is passed to the native input.
- Supports text, email, URL, telephone, password, and search input types.
- Renders optional leading and trailing slots while keeping the native `<input>`
  as the only editable control.
- Wires `aria-describedby` to description, hint, error, and meta text while
  preserving caller-supplied ids.
- Sets `aria-invalid`, `aria-required`, native `required`, disabled, and
  read-only attributes from props.
- Uses an always-outlined control with the label visually seated on the
  top-left border; focus and error states recolor the outline and label.
- Keeps product-owned behavior out of the primitive: consumers own validation,
  formatting, async suggestions, search execution, persistence, analytics,
  localization, and routing.

## Non-Goals

- No floating animation, filled variant, textarea/select behavior, masking,
  formatting, clear button, debounce, suggestions, or form-store integration.
- No search-result fetching or query parsing.
- Catalog Explorer registers the component with a live demo so the pattern is
  visible in the shared library before product adoption.

## Review Checks

- The label remains readable on the outline in default, compact, disabled,
  read-only, focused, and error states.
- Long labels truncate instead of overlapping trailing content.
- Description, hint, meta, and error text wrap without changing the outlined
  label placement.
- Search-style usage with a leading icon preserves native `type="search"` and
  does not show duplicate visible labels.
