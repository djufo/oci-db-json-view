# TextareaControl

## Purpose

`TextareaControl` is a controlled native multiline text input wrapper for long
form descriptions, prompts, profile bios, notes, and JSON-like form fields.

## Source Evidence

- Score `ui/src/features/board/containers/BoardContainer.tsx` uses labelled
  multiline issue description fields in the creation flow.
- Score `ui/src/features/projects/containers/ProjectPage.tsx` uses a
  multiline project description field.
- Score `ui/src/features/schedulers/containers/SchedulersContainer.tsx` uses a
  multiline nudger prompt editor.
- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` and
  `ui/src/pages/account/accommodation-profile/AccommodationProfilePage.tsx`
  use multiline profile bio/description fields.
- eLitua `ui/src/admin/geos/components/GeoForm/GeoForm.tsx` and
  `ui/src/admin/accms/components/GeoForm/GeoForm.tsx` repeat dense multiline
  address and diagnostic fields in admin editors.

## Existing Coverage Check

- Broad layouts and route shells are already represented by the workspace,
  portal, editorial, public profile, map, catalog, dialog, admin, and project
  panel components.
- `EditableFormPanel`, `AdminRecordEditorPanel`, `ScheduleEditorDialog`,
  `WorkItemPlanningPanel`, and `ThemeLabPanel` already own larger panel-specific
  textarea placements.
- `Field.Textarea` is a low-level helper. This control standardizes a standalone
  labelled multiline field with density, status, icon, hint, error, metadata,
  counter, read-only, disabled, and resize chrome.

## Contract

- Renders a native `textarea` with a visible label by default.
- Supports optional hidden labels for dense layouts that still need an
  accessible textarea name.
- Supports decorative leading icon, label-row status, hint/error/meta text,
  optional counter text, compact/comfortable density, read-only and disabled
  states, and controlled resize mode.
- Forwards normal textarea props such as `rows`, `maxLength`, `placeholder`,
  `required`, `disabled`, and `readOnly`.
- Emits `onValueChange` with the next raw textarea value. Consuming apps own
  validation, trimming, persistence, routing, analytics, localization, and
  content policy.

## Non-Goals

- No markdown parser, JSON parser, autosave behavior, prompt validation, route
  ownership, line counting, secret redaction, CMS integration, or API calls.
- No replacement for larger panels that already compose product-specific
  multiline fields.

## Review Checks

- Long labels, placeholders, hints, counters, and errors wrap without
  overlapping or shifting adjacent controls.
- Compact density remains usable inside dialogs, side panels, and dense admin
  form grids.
- Error text is exposed through `aria-describedby` and `aria-invalid`.
