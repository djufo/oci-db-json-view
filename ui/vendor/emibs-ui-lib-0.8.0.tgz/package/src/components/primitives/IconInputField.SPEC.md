# IconInputField

## Purpose

`IconInputField` is a neutral labeled input control with optional leading icon,
trailing action, hint text, error text, and compact density.

## Source Evidence

- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` repeats
  labeled input wrappers with leading profile/contact/license icons and hint
  copy.
- eLitua `ui/src/pages/account/bokun/BókunPage.tsx` repeats the same
  icon-adorned credential and integration id fields.
- Score `ui/src/design-system/AuthAccessPanel.tsx` has the same field shape for
  operator sign-in, but it is currently auth-scoped.

## Contract

- Renders a native `input` with a visible label by default.
- Supports optional hidden labels for dense layouts that still need an
  accessible input name.
- Supports a decorative leading icon, trailing action slot, hint/error
  descriptions, disabled state, and compact/comfortable density.
- Forwards normal input props and events so consuming apps keep control of
  value, validation, submit behavior, localization, routing, analytics, secret
  reveal state, and persistence.

## Non-Goals

- No validation schema, formatting, autocomplete, masking, password reveal
  state, save behavior, route behavior, or API calls.
- No auth-specific provider handling; auth flows can compose this primitive or
  keep using auth-specific wrappers when the larger auth shell is more suitable.

## Review Checks

- Long labels, placeholders, hints, and error text wrap without overlapping the
  icon or trailing action.
- The input remains keyboard focusable and exposes hint/error text through
  `aria-describedby`.
- Compact density remains usable inside form grids and side panels.

## Field contract (issue-564)

Already exposed `error` + `aria-invalid` + `aria-describedby`. Added the
`required` affordance (Required marker + `aria-required` + native `required`),
completing the FieldControl contract. Back-compat: no existing prop changed.
