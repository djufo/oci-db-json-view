# StatusIndicator

## Purpose

`StatusIndicator` is a small presentational primitive for status-dot, label,
detail, icon, and action chrome. It standardizes the repeated status rows and
badges used in provider setup, agent health, scheduler/runtime state, and
profile publication surfaces without owning the state machine behind them.

## Source Evidence

- Score `ui/src/features/agent-admin/containers/AgentAdminContainer.tsx` maps
  agent runtime health into a dot plus label inside agent management rows.
- Score `ui/src/features/schedulers/containers/SchedulersContainer.tsx` repeats
  runtime status/action rows around scheduler controls.
- eLitua `ui/src/pages/account/bokun/BókunPage.tsx` renders a provider
  connection status bar with colored dot, status text, and disconnect action.
- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` renders
  published/verified profile status badges with compact dots.

## Contract

- Accepts controlled `label`, optional `detail`, tone, icon, action slot,
  compact/default size, and `inline`, `bar`, or `pill` variants.
- Supports the shared tone vocabulary: neutral, info, success, warning, danger,
  and accent.
- Keeps provider connection logic, runtime-health thresholds, verification
  semantics, persistence, routing, polling, and localization in consuming apps.

## Non-Goals

- No live polling, status reducer, provider SDK, health scoring, retry behavior,
  toast handling, or route ownership.
- No replacement for larger panels such as `IntegrationSetupPanel`,
  `AgentManagementPanel`, `DataStatePanel`, or `StatusStrip`.

## Review Checks

- Long labels and details wrap without pushing action controls out of the
  container.
- Inline, bar, and pill variants remain stable in narrow catalog previews.
