// @vitest-environment happy-dom

import { StrictMode, act, createElement, useState } from "react";
import { createRoot, type Root } from "react-dom/client";
import { describe, expect, it, vi } from "vitest";
import { switchTransitionDirection } from "./SwitchControl";
import { SwitchControl, type SwitchControlProps } from "./SwitchControl";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

function renderSwitch(root: Root, checked: boolean) {
  act(() => {
    root.render(
      createElement(
        StrictMode,
        null,
        createElement(SwitchControl, {
          checked,
          id: "strict-switch",
          label: "Strict switch",
          onChange: () => undefined,
        }),
      ),
    );
  });
}

function track(container: HTMLElement) {
  const element = container.querySelector(".ui-switch-control__track");
  expect(element).toBeInstanceOf(HTMLElement);
  return element as HTMLElement;
}

function renderProps(root: Root, props: Partial<SwitchControlProps>) {
  act(() => {
    root.render(
      createElement(
        StrictMode,
        null,
        createElement(SwitchControl, {
          checked: false,
          id: "busy-switch",
          label: "Busy switch",
          ...props,
        } as SwitchControlProps),
      ),
    );
  });
}

function input(container: HTMLElement) {
  const element = container.querySelector<HTMLInputElement>("input[type='checkbox']");
  expect(element).toBeInstanceOf(HTMLInputElement);
  return element as HTMLInputElement;
}

function label(container: HTMLElement) {
  const element = container.querySelector<HTMLElement>(".ui-switch-control");
  expect(element).toBeInstanceOf(HTMLElement);
  return element as HTMLElement;
}

describe("switchTransitionDirection", () => {
  it("names the direction when a controlled switch turns on", () => {
    expect(switchTransitionDirection(false, true)).toBe("turning-on");
  });

  it("names the direction when a controlled switch turns off", () => {
    expect(switchTransitionDirection(true, false)).toBe("turning-off");
  });

  it("does not animate an unchanged controlled value", () => {
    expect(switchTransitionDirection(true, true)).toBeUndefined();
  });
});

describe("SwitchControl transition pulse", () => {
  it("keeps the turning-on pulse through a StrictMode rerender", () => {
    const container = document.createElement("div");
    const root = createRoot(container);

    try {
      renderSwitch(root, false);
      expect(track(container).dataset.transition).toBeUndefined();

      renderSwitch(root, true);
      expect(track(container).dataset.transition).toBe("turning-on");
    } finally {
      act(() => root.unmount());
    }
  });

  it("keeps the turning-off pulse through a StrictMode rerender", () => {
    const container = document.createElement("div");
    const root = createRoot(container);

    try {
      renderSwitch(root, true);
      expect(track(container).dataset.transition).toBeUndefined();

      renderSwitch(root, false);
      expect(track(container).dataset.transition).toBe("turning-off");
    } finally {
      act(() => root.unmount());
    }
  });
});

describe("SwitchControl busy state", () => {
  it("announces aria-busy while a write is in flight and drops it otherwise", () => {
    const container = document.createElement("div");
    const root = createRoot(container);

    try {
      renderProps(root, { busy: false });
      expect(input(container).getAttribute("aria-busy")).toBeNull();

      renderProps(root, { busy: true });
      expect(input(container).getAttribute("aria-busy")).toBe("true");
    } finally {
      act(() => root.unmount());
    }
  });

  it("marks the label and the track so the midpoint thumb has a hook", () => {
    const container = document.createElement("div");
    const root = createRoot(container);

    try {
      renderProps(root, { busy: false });
      expect(label(container).classList.contains("is-busy")).toBe(false);
      expect(track(container).dataset.busy).toBeUndefined();

      renderProps(root, { busy: true });
      expect(label(container).classList.contains("is-busy")).toBe(true);
      expect(track(container).dataset.busy).toBe("true");
    } finally {
      act(() => root.unmount());
    }
  });

  // The regression this guards: collapsing busy into `disabled` takes the control
  // out of the tab order, so a keyboard user loses it the instant they activate
  // it (src/theme/STATES.md rule 5).
  it("keeps the busy control enabled and focusable", () => {
    const container = document.createElement("div");
    document.body.appendChild(container);
    const root = createRoot(container);

    try {
      renderProps(root, { busy: true });
      const control = input(container);

      expect(control.disabled).toBe(false);
      expect(control.hasAttribute("disabled")).toBe(false);
      expect(control.tabIndex).not.toBe(-1);

      control.focus();
      expect(document.activeElement).toBe(control);
    } finally {
      act(() => root.unmount());
      container.remove();
    }
  });

  it("emits nothing through onChange while busy", () => {
    const container = document.createElement("div");
    const root = createRoot(container);
    const onChange = vi.fn();

    try {
      renderProps(root, { busy: true, checked: false, onChange });

      act(() => {
        input(container).click();
      });

      expect(onChange).not.toHaveBeenCalled();
    } finally {
      act(() => root.unmount());
    }
  });

  it("emits through onChange when it is not busy", () => {
    const container = document.createElement("div");
    const root = createRoot(container);
    const onChange = vi.fn();

    try {
      renderProps(root, { busy: false, checked: false, onChange });

      act(() => {
        input(container).click();
      });

      expect(onChange).toHaveBeenCalledTimes(1);
      expect(onChange.mock.calls[0]?.[0]).toBe(true);
    } finally {
      act(() => root.unmount());
    }
  });

  // STATES.md rule 4: `disabled` > `readonly` > `busy`.
  it("lets disabled outrank busy", () => {
    const container = document.createElement("div");
    const root = createRoot(container);

    try {
      renderProps(root, { busy: true, disabled: true });

      expect(label(container).classList.contains("is-busy")).toBe(false);
      expect(track(container).dataset.busy).toBeUndefined();
      expect(label(container).classList.contains("is-disabled")).toBe(true);
      expect(input(container).disabled).toBe(true);
    } finally {
      act(() => root.unmount());
    }
  });

  it("lets readonly outrank busy", () => {
    const container = document.createElement("div");
    const root = createRoot(container);

    try {
      renderProps(root, { busy: true, readOnly: true });

      expect(label(container).classList.contains("is-busy")).toBe(false);
      expect(track(container).dataset.busy).toBeUndefined();
      expect(label(container).classList.contains("is-readonly")).toBe(true);
    } finally {
      act(() => root.unmount());
    }
  });
});

// Failure-revert needs no component code: SwitchControl is fully controlled and
// holds no internal checked state, so a consumer whose async write fails simply
// keeps the value it had and drops `busy`. This proves that end to end rather
// than asserting the absence of internal state.
function FailureRevertHarness({ write }: { write: () => Promise<void> }) {
  const [checked, setChecked] = useState(false);
  const [busy, setBusy] = useState(false);

  return createElement(SwitchControl, {
    busy,
    checked,
    id: "revert-switch",
    label: "Revert switch",
    onChange: (next: boolean) => {
      const previous = checked;
      setChecked(next);
      setBusy(true);
      void write().then(
        () => setBusy(false),
        () => {
          setChecked(previous);
          setBusy(false);
        },
      );
    },
  });
}

describe("SwitchControl failure revert", () => {
  it("returns to the previous value when the consumer's write rejects", async () => {
    const container = document.createElement("div");
    const root = createRoot(container);
    let rejectWrite: (reason?: unknown) => void = () => undefined;
    const pending = new Promise<void>((_resolve, reject) => {
      rejectWrite = reject;
    });

    try {
      act(() => {
        root.render(
          createElement(
            StrictMode,
            null,
            createElement(FailureRevertHarness, { write: () => pending }),
          ),
        );
      });

      expect(input(container).checked).toBe(false);
      expect(input(container).getAttribute("aria-busy")).toBeNull();

      act(() => {
        input(container).click();
      });

      // Optimistic flip, write in flight: busy is announced and further change
      // events are swallowed until it settles.
      expect(input(container).checked).toBe(true);
      expect(input(container).getAttribute("aria-busy")).toBe("true");
      expect(track(container).dataset.busy).toBe("true");

      await act(async () => {
        rejectWrite(new Error("write failed"));
        await pending.catch(() => undefined);
      });

      expect(input(container).checked).toBe(false);
      expect(input(container).getAttribute("aria-busy")).toBeNull();
      expect(track(container).dataset.busy).toBeUndefined();
      expect(label(container).classList.contains("is-busy")).toBe(false);
    } finally {
      act(() => root.unmount());
    }
  });
});
