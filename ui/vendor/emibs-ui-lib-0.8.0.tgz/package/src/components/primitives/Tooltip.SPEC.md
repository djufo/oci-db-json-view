# Tooltip

## Purpose

`Tooltip` is a non-interactive, short-text disclosure for a single focusable or
hoverable trigger. It supplements the trigger's accessible description; it does
not replace the trigger's accessible name.

## Public API

- `content: string`: plain, non-interactive descriptive copy.
- `children: ReactElement`: one trigger element; its handlers and existing
  `aria-describedby` value are preserved.
- `side: top | right | bottom | left`, default `top`.
- `className`: optional integration class on the flat positioning wrapper.

## Variants

| Variant | Contract |
| --- | --- |
| `top` | Centers above the trigger |
| `right` | Centers after the trigger |
| `bottom` | Centers below the trigger |
| `left` | Centers before the trigger |

## States matrix

| Pointer state | Focus state | Disclosure |
| --- | --- | --- |
| Outside | Blurred | Hidden |
| Hovered | Blurred | Visible |
| Outside | Focused | Visible |
| Hovered | Focused | Visible until both states end |
| Any | Escape pressed | Hidden until a new hover/focus entry |

## Accessibility contract

- The trigger references the tooltip id through `aria-describedby`; an existing
  description id is retained and joined rather than replaced.
- The disclosure uses `role="tooltip"`, never takes focus, and ignores pointer
  events. Interactive links, buttons, and form controls are not valid content.
- Keyboard focus and pointer hover have equivalent disclosure behavior. Escape
  dismisses without moving focus or firing the trigger.
- The trigger must retain its own accessible name; tooltip copy is descriptive.

## UI density

The inline wrapper has no outer margin, padding, border, or shadow. The tooltip
owns only its intrinsic compact disclosure surface, using spacing and radius
tokens. Parent layout owns all sibling spacing.

## Boundaries

No rich popover content, delay policy, analytics, persistence, or product help
workflow belongs in this primitive.
