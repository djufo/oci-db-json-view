# TablePrimitive

## Purpose

`TablePrimitive` is a small semantic table renderer for already-available rows.
It is intentionally distinct from the app-oriented `DataTable`: there is no
sorting engine, pagination, fetching, async state panel, virtualization, or
domain policy. It supplies native table markup, an internally scrolling sticky
header, and optional controlled row selection.

## Public API

- `rows`, `columns`, and `getRowId` define the rendered table. A column supplies
  `id`, `header`, `cell`, optional alignment, and optional `rowHeader` semantics.
- One accessible name is required through `caption` or `ariaLabel`.
  `showCaption` reveals the semantic caption visually.
- `stickyHeader` defaults to true; `maxHeight` sets the scroll viewport through
  a component-local CSS custom property.
- `density` is `comfortable` or `compact`; `striped` is opt-in.
- Controlled selection is enabled only by a `selection` object containing
  `selectedRowIds` and `onSelectionChange`. Optional row labels and selectable
  policy stay consumer supplied.

## Variants and states matrix

| State | Markup/behavior | Selection behavior |
| --- | --- | --- |
| Rows, no selection | Native head/body/cells | No selection column |
| Empty | One full-width body cell | Select-all disabled when selection exists |
| Sticky (default) | Header cells stick inside root scroll viewport | Unchanged |
| Non-sticky | Header scrolls with rows | Unchanged |
| Comfortable/compact | Tokenized cell density | Touch control semantics unchanged |
| None selected | Normal rows | Header and row labels state none/not selected, then select action |
| Some selected | Selected token background | Header is mixed and offers select all |
| All selected | Selected token background | Header offers clear selection |
| Unselectable row | Normal or controlled selected rendering | Native checkbox disabled and excluded from select all |

## Accessibility contract

- The primitive always renders native `table`, `caption`/accessible name,
  `thead`, `tbody`, column headers with `scope="col"`, and optional row headers
  with `scope="row"`.
- Selection uses native checkboxes. The mixed header state sets both the DOM
  `indeterminate` property and `aria-checked="mixed"`.
- Every selection checkbox follows ui-affordance: its synchronized accessible
  name and tooltip state the current selection first, then the resulting
  action (for example, `Alpha: selected — Deselect row`).
- Disabled rows use the native disabled attribute and do not participate in
  select-all calculations.
- Selection is controlled; the primitive never presents an internal state that
  can drift from the consumer's source of truth.

## UI density

The scroll root introduces no outer padding, margin, border, radius, shadow, or
card surface. Cell padding is one tokenized table inset, not a nested surface.
The consuming page owns the table's surrounding surface and sibling gap.

## Non-goals

No replacement for `DataTable`, sorting, pagination, filtering, data
fetching, loading/error panels, row activation, virtualization, or persisted
selection.
