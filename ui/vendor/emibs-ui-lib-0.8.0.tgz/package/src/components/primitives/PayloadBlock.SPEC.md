# PayloadBlock

## Purpose

`PayloadBlock` is a presentational primitive for preformatted JSON, command,
log, and diagnostic payloads. It standardizes the repeated title, status, meta,
action, copy-control, and scroll/wrap chrome around raw text surfaces without
owning the payload source or interpretation.

## Source Evidence

- Score `ui/src/features/settings/containers/SettingsContainer.tsx` passes a
  summary log into the project settings surface with clear/send actions.
- Score `ui/src/features/schedulers/containers/SchedulersContainer.tsx` maps
  scheduler command, log path, and recent run output into operational panels.
- Score `ui/src/features/subscriptions/containers/SubscriptionsContainer.tsx`
  passes provider capacity JSON into a subscription-row payload disclosure.
- emibs-ui-lib `ProjectSettingsPanel`, `ProcessRunHistoryPanel`,
  `OperationalDiagnosticPanel`, and `SchedulerControlPanel` compose the
  primitive for settings logs, commands, output, and diagnostic payloads.
- eLitua `ui/src/pages/admin/TestDbPage/TestDbPage.tsx` renders a database
  diagnostic response with a raw `JSON.stringify(status, null, 2)` `<pre>`.

## Contract

- Accepts controlled `payload`, optional title, description, label/language,
  status badge, metadata rows, action slot, copy callback, density, panel/plain
  variant, and wrap mode.
- Supports controlled or uncontrolled disclosure mode through `collapsible`,
  `defaultCollapsed`, `collapsed`, and `onCollapsedChange`. Disclosure state
  hides metadata/actions/body while preserving a keyboard-operable header with
  `aria-expanded` and `aria-controls`.
- Uses the shared tone vocabulary for status and metadata emphasis.
- Keeps fetching, parsing, redaction, retention, clipboard persistence, routing,
  localization, and audit behavior in consuming apps.

## Non-Goals

- No JSON parsing, syntax highlighting, redaction, clipboard write, polling,
  download, toast, persistence, or route ownership.
- No replacement for larger shells such as `OperationalDiagnosticPanel`,
  `ProcessRunHistoryPanel`, `ProjectSettingsPanel`, or `SchedulerControlPanel`.

## Review Checks

- Long payload lines scroll horizontally by default and wrap only when requested.
- Header actions and status badges wrap without covering labels or metadata.
- Collapsed mode keeps a stable header footprint and expands without layout
  text overlap in table/detail/sidebar contexts.
- Compact and plain variants remain stable in narrow catalog previews.
