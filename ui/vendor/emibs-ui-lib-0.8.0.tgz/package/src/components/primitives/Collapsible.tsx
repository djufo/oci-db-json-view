import { type ReactNode, useId, useState } from "react";
import { ChevronDown, ChevronRight } from "lucide-react";
import { cn } from "../../lib/cn";

export type CollapsibleProps = {
  /** Header label. */
  title: ReactNode;
  /** Body content shown when expanded. */
  children: ReactNode;
  /** Uncontrolled initial state. */
  defaultCollapsed?: boolean;
  /** Controlled collapsed state (overrides internal state when provided). */
  collapsed?: boolean;
  /** Fires with the next collapsed state on toggle. */
  onCollapsedChange?: (collapsed: boolean) => void;
  /** Optional count/badge shown beside the title. */
  count?: ReactNode;
  /** Header actions, shown only when expanded. */
  actions?: ReactNode;
  density?: "compact" | "comfortable";
  className?: string;
};

export function Collapsible({
  title,
  children,
  defaultCollapsed = false,
  collapsed,
  onCollapsedChange,
  count,
  actions,
  density = "comfortable",
  className,
}: CollapsibleProps) {
  const bodyId = useId();
  const [internal, setInternal] = useState(defaultCollapsed);
  const isControlled = collapsed !== undefined;
  const isCollapsed = isControlled ? collapsed : internal;
  const toggle = () => {
    const next = !isCollapsed;
    if (!isControlled) setInternal(next);
    onCollapsedChange?.(next);
  };
  return (
    <section
      className={cn("ui-collapsible", `ui-collapsible--${density}`, isCollapsed && "is-collapsed", className)}
    >
      <div className="ui-collapsible__header">
        <button
          type="button"
          className="ui-collapsible__toggle"
          aria-controls={bodyId}
          aria-expanded={!isCollapsed}
          onClick={toggle}
        >
          {isCollapsed ? (
            <ChevronRight size={16} aria-hidden="true" />
          ) : (
            <ChevronDown size={16} aria-hidden="true" />
          )}
          <span className="ui-collapsible__title">{title}</span>
          {count != null ? <span className="ui-collapsible__count">{count}</span> : null}
        </button>
        {actions && !isCollapsed ? <div className="ui-collapsible__actions">{actions}</div> : null}
      </div>
      {!isCollapsed ? <div className="ui-collapsible__body" id={bodyId}>{children}</div> : null}
    </section>
  );
}
