# Skeleton

## Purpose

`Skeleton` is a visual placeholder for content whose geometry is known while it
loads. It does not own loading state, timing, data fetching, or layout.

## Public API

- `variant` is `text`, `rectangular`, or `circular` and defaults to `text`.
- `animation` is `pulse`, `wave`, or `none` and defaults to `pulse`.
- The default accessibility mode is hidden. To expose a meaningful loading
  status, pass the paired `exposed={true}` and non-empty `ariaLabel` props.
- Standard span attributes, `className`, and `style` pass through so the parent
  layout may set the final geometry.

## Variants and states matrix

| Variant/state | Shape | Motion | Assistive technology |
| --- | --- | --- | --- |
| `text` | One line-height bar | Selected animation | Hidden by default |
| `rectangular` | Content/media placeholder | Selected animation | Hidden by default |
| `circular` | Avatar/icon placeholder | Selected animation | Hidden by default |
| `animation="none"` | Any shape | Static | Follows hidden/exposed mode |
| Exposed status | Any shape | Any animation | `role="status"` with required label |
| Reduced motion | Any shape | Animation disabled by media query | Semantics unchanged |

## Accessibility contract

- Decorative skeletons render `aria-hidden="true"` by default so repeated
  placeholders do not pollute the accessibility tree.
- An exposed skeleton renders a labelled live status. The discriminated prop
  contract requires its accessible label at compile time.
- A containing loading region should generally own `aria-busy`; do not expose
  every child skeleton in a repeated layout.
- `prefers-reduced-motion: reduce` disables pulse and wave animation.

## UI density

The placeholder is content, not a surface. It carries no outer margin, padding,
border, or shadow. Parents own sibling gaps and final width/height; composing a
skeleton never introduces another padded box.

## Non-goals

No layout inference, asynchronous state machine, progress semantics, content
measurement, or loading timeout policy.
