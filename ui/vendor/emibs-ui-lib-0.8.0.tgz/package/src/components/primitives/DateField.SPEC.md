# DateField

## Purpose

`DateField` is a controlled single-date control for compact operator and account
forms. It implements the shared `FieldControl` contract over a native
`type="date"` input so screen-reader, keyboard, and mobile date-picker behavior
stay native, while owning label, description, hint, error, and clear chrome
without owning form state or validation.

## Source Evidence

- Score scheduler, board planning, and project settings forms repeat single-date
  fields (start/end, due, cutoff) around bare native date inputs with
  inconsistent labelling and no clear affordance.
- eLitua admin and account edit forms repeat date-of-record and validity-window
  fields that need min/max bounds and consistent required/error chrome.
- Existing catalog coverage was checked first: `TemporalInputControl` owns the
  broader date/time/datetime-local extraction, `NumberInputControl` owns numeric
  entry, and `TextInputControl` owns free text — none provides the focused,
  contract-wired single-date field with a clear affordance.

## Contract

- Implements the shared `FieldControl<string>` contract: `value`,
  `onChange(value)`, `name`, `id`, `label`, `description`, `hint`, `error`,
  `required`, `disabled`, and `readOnly`.
- Wraps a native `type="date"` input so its `value` and emitted `onChange` value
  are ISO calendar dates (`YYYY-MM-DD`) or an empty string when unset; native
  picker, keyboard, and mobile semantics are preserved.
- Forwards `min`/`max` bounds to the native input for constraint validation.
- Wires `<label htmlFor>`, `aria-describedby` (description, hint, error, meta,
  and any caller-supplied ids), `aria-invalid` when `error` is present, and
  `aria-required` plus a visible "Required" marker when required.
- Renders an optional clear affordance (default on) — a screen-reader-labelled
  button shown only when a value is set and the field is editable — that emits an
  empty string through `onChange`.
- Supports hidden labels, status text, meta text, disabled/read-only state, and
  compact and comfortable density.
- Exports `isIsoDateString` and `isDateWithinRange` helpers for consumers and
  tests; the component itself does not override caller-supplied errors.

## Non-Goals

- No validation schema, form library integration, date parsing/formatting,
  locale masking, range/multi-date selection, calendar popover, persistence,
  route synchronization, or submit orchestration.
- No time or datetime entry; use `TemporalInputControl` for time and
  datetime-local variants.

## Review Checks

- Label `htmlFor` matches the input id; description, hint, error, and meta text
  are linked through `aria-describedby`.
- Emitted values are ISO dates or empty; `min`/`max` reach the native input.
- Required renders a visible marker plus `aria-required`/`required`; error
  renders with `role="alert"` and sets `aria-invalid`.
- The clear button appears only with a value on an editable field, is
  screen-reader labelled, and clears to an empty string.
- Meets a 44px minimum target and renders correctly in light and dark themes.
