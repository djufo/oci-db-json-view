# NumberInputControl

## Purpose

`NumberInputControl` is a controlled native number input wrapper for priority,
points, coordinate, file metadata, and numeric admin form rows. It keeps numeric
field chrome, label/status layout, hint/error/meta text, unit placement, icon
placement, and density consistent without owning parsing, rounding, validation,
or persistence.

## Source Evidence

- Score `ui/src/features/board/containers/BoardContainer.tsx` repeats native
  number fields for issue points and priority.
- Score `ui/src/features/projects/containers/ProjectPage.tsx` repeats a native
  number field for project priority.
- eLitua `ui/src/admin/geos/components/GeoEdit/GeoEdit.tsx` repeats number
  inputs for latitude and longitude editing.
- eLitua `ui/src/pages/admin/pictures/PictureEditPage.tsx` repeats number
  inputs for file id and image width/height metadata.
- Existing catalog coverage was checked first: larger shells and page layouts
  are already represented, `WorkItemPlanningPanel` owns Score-specific planning
  rows, `ComponentPlaygroundPanel` owns catalog playground number controls, and
  `Field.Input` is a low-level native input helper rather than a numeric control
  primitive.

## Contract

- Requires an `id`, `label`, controlled `value`, and optional `onValueChange`.
- Uses native `type="number"` and forwards native attributes such as `min`,
  `max`, `step`, `required`, `disabled`, `readOnly`, `autoComplete`, and
  `inputMode`.
- Emits both the raw string value and the browser `valueAsNumber` value, using
  `null` for empty or invalid numeric input.
- Supports leading icon, prefix, suffix, status, hint, error, metadata text,
  hidden-label mode, compact and comfortable density, disabled and read-only
  states.
- Links hint, error, and metadata text through `aria-describedby` and sets the
  invalid state when an error is present.

## Non-Goals

- No currency formatting, coordinate formatting, unit conversion, rounding,
  localization, validation schema, spinbutton replacement, range slider,
  keyboard shortcut handling, async loading, route state, persistence, or
  product-specific copy.
- No replacement for Score task planning or eLitua admin form composition;
  products can use this control inside their own forms after review.

## Review Checks

- Hidden labels still provide an accessible input name.
- Hint, error, and metadata text are linked through `aria-describedby`.
- Empty values emit `null` as the parsed number without preventing product-owned
  validation.
- Prefixes, suffixes, long labels, hints, errors, metadata, and status text wrap
  without overlapping native number affordances in compact and comfortable
  densities.
