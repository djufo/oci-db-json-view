# Button

## Purpose

`Button` is the canonical text/action button primitive. It provides Material-style
visual parity without owning confirmation, permission, routing, analytics, or
product mutation behavior.

## Public API

- Inherits native `ButtonHTMLAttributes<HTMLButtonElement>` and forwards its ref.
- `variant`: `primary | danger | ghost | quiet`; the legacy `secondary` variant
  remains supported for existing consumers.
- `size`: `sm | md | lg | icon`.
- `loading`: blocks activation while keeping the button focusable, renders a
  decorative progress indicator, and sets `aria-busy` plus `aria-disabled`.
- `loadingLabel`: optional accessible name for the busy action. Without it the
  component derives `Loading: <aria-label or textual children>`, falling back to
  `Loading` for non-text content.

## Variants

| Variant | Surface | Intended use |
| --- | --- | --- |
| `primary` | Accent-filled | Main action |
| `danger` | Danger-filled | Destructive action |
| `ghost` | Transparent, outlined | Lower-emphasis action with a boundary |
| `quiet` | Transparent, borderless | Lowest-emphasis inline/toolbar action |
| `secondary` | Neutral surface, outlined | Backward-compatible secondary action |

## States matrix

| State | Native state | Visual/behavior contract | Accessible contract |
| --- | --- | --- | --- |
| Rest | enabled | Variant styling | Native button name/role |
| Hover | enabled | Tokenized state surface | No semantic change |
| Focus | enabled | Visible focus-token outline | Keyboard focus remains on button |
| Disabled | `disabled` | Muted and non-actionable | Native disabled semantics |
| Loading | `aria-busy`, `aria-disabled` | Activation blocked; progress indicator plus stable content | Busy, contextual accessible name; remains focusable |

## Accessibility contract

- Uses the native `<button>` element and preserves native attributes and event
  handlers.
- `size="icon"` does not invent a name; callers must provide `aria-label` when
  children do not include text.
- Loading cannot fire the action, but stays keyboard-focusable so its busy
  status can be discovered; its progress glyph is decorative.
- Focus remains visibly disclosed through the shared `--state-focus-ring`
  token.

## UI density

The button owns only its intrinsic control hit area. It adds no outer wrapper,
margin, panel, card, shadow, or layout spacing. A parent owns spacing between
buttons with tokenized `gap`.

## Boundaries

No async state, mutation, dialog, routing, toast, or permission policy lives in
the primitive.
