/**
 * Reduced-motion helpers. The overlay engine stays headless — it never animates
 * anything itself — but it surfaces the user's motion preference so the styled
 * primitives built on top (Dialog/Drawer/Popover) can skip transitions.
 */

/** The media query string used for the reduce-motion preference. */
export const REDUCED_MOTION_QUERY = "(prefers-reduced-motion: reduce)";

/** Current reduced-motion preference. `false` when there is no `matchMedia`. */
export function prefersReducedMotion(): boolean {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    return false;
  }
  return window.matchMedia(REDUCED_MOTION_QUERY).matches;
}

/**
 * Subscribe to reduced-motion changes. Returns an unsubscribe function; a no-op
 * in environments without `matchMedia`.
 */
export function subscribeReducedMotion(listener: () => void): () => void {
  if (typeof window === "undefined" || typeof window.matchMedia !== "function") {
    return () => {};
  }
  const media = window.matchMedia(REDUCED_MOTION_QUERY);
  media.addEventListener("change", listener);
  return () => media.removeEventListener("change", listener);
}
