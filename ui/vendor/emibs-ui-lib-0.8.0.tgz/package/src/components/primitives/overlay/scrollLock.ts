/**
 * Body scroll lock with scrollbar-width compensation.
 *
 * Locks are reference-counted so multiple stacked overlays share a single lock:
 * the body is frozen when the first overlay opens and restored only when the
 * last one closes. `computeScrollbarCompensation` is pure and unit-tested; the
 * DOM writes live in `lockBodyScroll`.
 */

/**
 * Width (px) of the vertical scrollbar that removing overflow would reclaim.
 * Padding the body by this amount prevents the content from shifting when the
 * scrollbar disappears under the lock. Never negative.
 */
export function computeScrollbarCompensation(windowInnerWidth: number, documentClientWidth: number): number {
  return Math.max(0, windowInnerWidth - documentClientWidth);
}

let lockCount = 0;
let restore: { overflow: string; paddingRight: string } | null = null;

/**
 * Freeze body scroll and compensate for the reclaimed scrollbar. Returns a
 * release function; scroll is restored only once every acquired lock is
 * released. Safe to call in non-DOM environments (returns a no-op release).
 */
export function lockBodyScroll(): () => void {
  if (typeof document === "undefined") {
    return () => {};
  }
  lockCount += 1;
  if (lockCount === 1) {
    const body = document.body;
    const compensation = computeScrollbarCompensation(window.innerWidth, document.documentElement.clientWidth);
    restore = { overflow: body.style.overflow, paddingRight: body.style.paddingRight };
    body.style.overflow = "hidden";
    if (compensation > 0) {
      const currentPadding = Number.parseFloat(window.getComputedStyle(body).paddingRight) || 0;
      body.style.paddingRight = `${currentPadding + compensation}px`;
    }
  }
  let released = false;
  return () => {
    if (released) {
      return;
    }
    released = true;
    releaseBodyScroll();
  };
}

function releaseBodyScroll(): void {
  if (typeof document === "undefined") {
    return;
  }
  lockCount = Math.max(0, lockCount - 1);
  if (lockCount === 0 && restore) {
    document.body.style.overflow = restore.overflow;
    document.body.style.paddingRight = restore.paddingRight;
    restore = null;
  }
}

/** Test-only: reset lock bookkeeping. */
export function __resetScrollLock(): void {
  lockCount = 0;
  restore = null;
}
