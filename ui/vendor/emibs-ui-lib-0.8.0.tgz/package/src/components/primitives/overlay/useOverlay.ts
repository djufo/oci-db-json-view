import {
  useCallback,
  useEffect,
  useId,
  useRef,
  useSyncExternalStore,
  type CSSProperties,
  type HTMLAttributes,
  type MouseEvent as ReactMouseEvent,
  type RefObject,
} from "react";
import { getTabbableElements, resolveTrapTarget } from "./focusTrap";
import { prefersReducedMotion, subscribeReducedMotion } from "./reducedMotion";
import { lockBodyScroll } from "./scrollLock";
import {
  isTopOverlay,
  overlayDepth,
  pushOverlay,
  removeOverlay,
  subscribeOverlayStack,
} from "./stacking";

/**
 * Base CSS custom property that the z-index of an overlay layer is derived from.
 * The token scale it belongs to is defined in `styles.css` (`--ui-z-base` …
 * `--ui-z-toast`). The literal fallback is retained deliberately: the engine is
 * contractually functional standalone, i.e. for consumers that import
 * `useOverlay`/`OverlayPortal` without loading the package stylesheet. It must
 * stay equal to the `--ui-z-overlay` value in `styles.css`.
 */
export const OVERLAY_Z_INDEX_VAR = "--ui-z-overlay";
const OVERLAY_Z_INDEX_FALLBACK = 1000;
/** Each stacked overlay is lifted by this much above the one beneath it. */
export const OVERLAY_Z_INDEX_STEP = 10;

export type UseOverlayOptions = {
  /** Whether the overlay is currently open. */
  open: boolean;
  /** Requested close (Escape, outside click, etc.). The caller owns `open`. */
  onClose: () => void;
  /**
   * Modal overlays trap focus, lock body scroll, mark `aria-modal`, and set a
   * `dialog` role by default. Non-modal overlays (e.g. popovers) do none of
   * these unless individually enabled. Defaults to `true`.
   */
  modal?: boolean;
  /** Close when Escape is pressed while top-most. Defaults to `true`. */
  closeOnEscape?: boolean;
  /** Close when the backdrop / outside is clicked. Defaults to `true`. */
  closeOnOutsideClick?: boolean;
  /** Trap Tab focus within the overlay. Defaults to `modal`. */
  trapFocus?: boolean;
  /** Lock body scroll while open. Defaults to `modal`. */
  lockScroll?: boolean;
  /** Return focus to the previously focused element on close. Defaults to `true`. */
  restoreFocus?: boolean;
  /** Element to focus on open; falls back to the first tabbable child. */
  initialFocusRef?: RefObject<HTMLElement | null>;
  /** Stable id for the stacking model. Generated when omitted. */
  id?: string;
};

export type OverlaySurfaceProps = {
  ref: RefObject<HTMLDivElement | null>;
  role: string;
  tabIndex: number;
  "aria-modal": true | undefined;
  onKeyDown: (event: React.KeyboardEvent<HTMLElement>) => void;
  "data-overlay-top": "" | undefined;
  style: CSSProperties;
};

export type OverlayBackdropProps = {
  /**
   * The backdrop is a pointer-only dismissal target. It must be spread onto a
   * non-interactive element.
   */
  tabIndex: -1;
  onClick: ((event: ReactMouseEvent<HTMLElement>) => void) | undefined;
  style: CSSProperties;
};

export type UseOverlayResult = {
  /** Ref for the overlay surface — the focus-trap boundary. */
  overlayRef: RefObject<HTMLDivElement | null>;
  /** Whether this overlay is the top-most open one. */
  isTop: boolean;
  /** Zero-based stacking depth (bottom = 0), or -1 when closed. */
  depth: number;
  /** Computed z-index expression for this layer. */
  zIndex: string;
  /** User's reduced-motion preference. */
  reducedMotion: boolean;
  /** Props to spread onto the overlay surface element. */
  getSurfaceProps: (overrides?: HTMLAttributes<HTMLElement>) => OverlaySurfaceProps;
  /**
   * Props for a decorative, non-focusable backdrop element. Every overlay
   * supplies a visible close control and Escape handling for keyboard and
   * assistive-technology users.
   */
  getBackdropProps: (overrides?: HTMLAttributes<HTMLElement>) => OverlayBackdropProps;
};

function overlayZIndex(depth: number): string {
  const safeDepth = depth < 0 ? 0 : depth;
  return `calc(var(${OVERLAY_Z_INDEX_VAR}, ${OVERLAY_Z_INDEX_FALLBACK}) + ${safeDepth * OVERLAY_Z_INDEX_STEP})`;
}

/**
 * Headless overlay engine. Owns focus trap + focus return, Escape, outside
 * click, body scroll lock, stacking/z-index, and reduced-motion — with no
 * opinion on visual chrome. The styled Dialog/Drawer/Popover primitives compose
 * this and provide their own markup.
 */
export function useOverlay(options: UseOverlayOptions): UseOverlayResult {
  const {
    open,
    onClose,
    modal = true,
    closeOnEscape = true,
    closeOnOutsideClick = true,
    trapFocus = modal,
    lockScroll = modal,
    restoreFocus = true,
    initialFocusRef,
    id,
  } = options;

  const generatedId = useId();
  const overlayId = id ?? generatedId;

  const overlayRef = useRef<HTMLDivElement | null>(null);
  const previousActiveRef = useRef<HTMLElement | null>(null);

  // Keep the latest callbacks/flags in refs so the long-lived document listener
  // and cleanup closures read current values without re-subscribing.
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  const initialFocusRefRef = useRef(initialFocusRef);
  initialFocusRefRef.current = initialFocusRef;
  const restoreFocusRef = useRef(restoreFocus);
  restoreFocusRef.current = restoreFocus;

  const isTop = useSyncExternalStore(
    subscribeOverlayStack,
    () => isTopOverlay(overlayId),
    () => false,
  );
  const depth = useSyncExternalStore(
    subscribeOverlayStack,
    () => overlayDepth(overlayId),
    () => -1,
  );
  const reducedMotion = useSyncExternalStore(
    subscribeReducedMotion,
    prefersReducedMotion,
    () => false,
  );

  // Register in the stacking model while open.
  useEffect(() => {
    if (!open) {
      return undefined;
    }
    pushOverlay(overlayId);
    return () => removeOverlay(overlayId);
  }, [open, overlayId]);

  // Capture the trigger, move focus in on open, restore it on close.
  useEffect(() => {
    if (!open) {
      return undefined;
    }
    previousActiveRef.current =
      typeof document !== "undefined" && document.activeElement instanceof HTMLElement
        ? document.activeElement
        : null;

    const frame = requestAnimationFrame(() => {
      const initial = initialFocusRefRef.current?.current;
      if (initial) {
        initial.focus({ preventScroll: true });
        return;
      }
      const tabbable = getTabbableElements(overlayRef.current);
      if (tabbable.length > 0) {
        tabbable[0].focus({ preventScroll: true });
      } else {
        overlayRef.current?.focus({ preventScroll: true });
      }
    });

    return () => {
      cancelAnimationFrame(frame);
      if (restoreFocusRef.current) {
        const previous = previousActiveRef.current;
        if (previous && typeof document !== "undefined" && document.contains(previous)) {
          previous.focus({ preventScroll: true });
        }
      }
    };
  }, [open]);

  // Body scroll lock (shared, reference-counted across stacked overlays).
  useEffect(() => {
    if (!open || !lockScroll) {
      return undefined;
    }
    return lockBodyScroll();
  }, [open, lockScroll]);

  // Global key handling: only the top-most overlay reacts, so Escape closes the
  // stack one layer at a time and Tab wraps within the focused overlay.
  useEffect(() => {
    if (!open || (!closeOnEscape && !trapFocus)) {
      return undefined;
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (!isTopOverlay(overlayId)) {
        return;
      }
      if (event.key === "Escape" && closeOnEscape) {
        event.preventDefault();
        event.stopPropagation();
        onCloseRef.current();
        return;
      }
      if (event.key === "Tab" && trapFocus) {
        const tabbable = getTabbableElements(overlayRef.current);
        if (tabbable.length === 0) {
          event.preventDefault();
          overlayRef.current?.focus({ preventScroll: true });
          return;
        }
        const active = document.activeElement as HTMLElement | null;
        const activeIndex = active ? tabbable.indexOf(active) : -1;
        const target = resolveTrapTarget({ count: tabbable.length, activeIndex, shiftKey: event.shiftKey });
        if (target !== null) {
          event.preventDefault();
          tabbable[target].focus({ preventScroll: true });
        }
      }
    };
    document.addEventListener("keydown", onKeyDown, true);
    return () => document.removeEventListener("keydown", onKeyDown, true);
  }, [open, closeOnEscape, trapFocus, overlayId]);

  const zIndex = overlayZIndex(depth);

  const getSurfaceProps = useCallback(
    (overrides: HTMLAttributes<HTMLElement> = {}): OverlaySurfaceProps => {
      const { onKeyDown: overrideKeyDown, style: overrideStyle, ...rest } = overrides;
      return {
        ...(rest as OverlaySurfaceProps),
        ref: overlayRef,
        role: (rest as { role?: string }).role ?? "dialog",
        tabIndex: (rest as { tabIndex?: number }).tabIndex ?? -1,
        "aria-modal": modal ? true : undefined,
        "data-overlay-top": isTop ? "" : undefined,
        onKeyDown: (event) => {
          overrideKeyDown?.(event);
        },
        style: overrideStyle ?? {},
      };
    },
    [isTop, modal],
  );

  const getBackdropProps = useCallback(
    (overrides: HTMLAttributes<HTMLElement> = {}): OverlayBackdropProps => {
      const { onClick: overrideClick, style: overrideStyle } = overrides;
      return {
        tabIndex: -1,
        onClick: closeOnOutsideClick
          ? (event) => {
              overrideClick?.(event);
              if (event.defaultPrevented) {
                return;
              }
              // Only a click that lands on the backdrop itself (not a child that
              // bubbled up) closes the overlay.
              if (event.target === event.currentTarget) {
                onCloseRef.current();
              }
            }
          : overrideClick,
        style: overrideStyle ?? {},
      };
    },
    [closeOnOutsideClick],
  );

  return {
    overlayRef,
    isTop,
    depth,
    zIndex,
    reducedMotion,
    getSurfaceProps,
    getBackdropProps,
  };
}
