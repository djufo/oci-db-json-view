import {
  useEffect,
  useId,
  useState,
  type CSSProperties,
  type HTMLAttributes,
  type ReactNode,
  type RefObject,
} from "react";
import { X } from "lucide-react";
import { cn } from "../../../lib/cn";
import { OverlayPortal } from "./OverlayPortal";
import { resolveSurfaceLabelling } from "./surfaceLabelling";
import { useOverlay } from "./useOverlay";

/** Panel max-inline-size for each named size. */
const DIALOG_SIZE: Record<DialogSize, string> = {
  sm: "min(100%, 420px)",
  md: "min(100%, 520px)",
  lg: "min(100%, 640px)",
  xl: "min(100%, 820px)",
};

export type DialogSize = "sm" | "md" | "lg" | "xl";
export type DialogChrome = "default" | "bare";

export type DialogProps = {
  /** Whether the dialog is open. The caller owns this state. */
  open: boolean;
  /** Requested close (Escape, backdrop, close button). */
  onClose: () => void;
  /**
   * Dialog title; renders the header and provides the accessible name.
   * Inert under `chrome="bare"`, which renders no chrome — name a bare dialog
   * with `aria-label` or `surfaceProps["aria-labelledby"]`.
   */
  title?: ReactNode;
  /** Small label above the title. Inert under `chrome="bare"`. */
  eyebrow?: ReactNode;
  /**
   * Supporting copy under the title; wired as `aria-describedby`.
   * Inert under `chrome="bare"`; describe a bare dialog with
   * `surfaceProps["aria-describedby"]`.
   */
  description?: ReactNode;
  /** Header action slot rendered before the close button. */
  actions?: ReactNode;
  /** Footer slot (e.g. confirm / cancel buttons). */
  footer?: ReactNode;
  children?: ReactNode;
  /**
   * Render the built-in dialog chrome or only the engine-backed layer/surface.
   *
   * `"bare"` renders no chrome, so `title`, `eyebrow`, `description`, `actions`,
   * `footer`, `size`, `showClose` and `closeLabel` are inert in this mode —
   * including their `aria-labelledby` / `aria-describedby` wiring, which would
   * otherwise point at elements bare chrome never renders.
   */
  chrome?: DialogChrome;
  /** Modal overlays trap focus, lock body scroll, and set aria-modal. */
  modal?: boolean;
  /** Panel width preset. Defaults to `lg`. */
  size?: DialogSize;
  /** Show the header close button. Defaults to `true`. */
  showClose?: boolean;
  /** Accessible label for the close button. Defaults to `"Close dialog"`. */
  closeLabel?: string;
  /**
   * @deprecated Backdrops are decorative pointer targets and are excluded from
   * the accessibility tree. Use `closeLabel` to name the visible close button.
   */
  backdropLabel?: string;
  /** Close when the backdrop is clicked. Defaults to `true`. */
  closeOnBackdrop?: boolean;
  /** Close when Escape is pressed while top-most. Defaults to `true`. */
  closeOnEscape?: boolean;
  /**
   * `alertdialog` for destructive confirmations, otherwise `dialog`.
   * Defaults to `dialog`.
   */
  role?: "dialog" | "alertdialog";
  /** Accessible name when no `title` is rendered. */
  "aria-label"?: string;
  /** Element to focus on open; falls back to the first tabbable child. */
  initialFocusRef?: RefObject<HTMLElement | null>;
  /** Portal target. Defaults to `document.body`. */
  container?: HTMLElement | null;
  /** Render the layer inline instead of portalling, for contained review surfaces. */
  inline?: boolean;
  /** Extra class names on the portal/layer root. */
  layerClassName?: string;
  /** Extra styles on the portal/layer root. */
  layerStyle?: CSSProperties;
  /** Extra class names on the backdrop. */
  backdropClassName?: string;
  /** Extra styles on the backdrop. */
  backdropStyle?: CSSProperties;
  /**
   * Extra attributes on the focus-trapped surface (e.g. `id`, `aria-labelledby`).
   *
   * Precedence, one rule in both directions:
   * - **Labelling and identity** — `aria-label`, `aria-labelledby`,
   *   `aria-describedby`, `id`: the caller wins. A value passed here is never
   *   replaced by one `Dialog` derives from `title`/`description`/`aria-label`,
   *   and a derived id is only emitted when the element it points at is
   *   actually rendered (never under `chrome="bare"`).
   * - **Structure** — `role`, `ref`, `tabIndex`, `aria-modal`,
   *   `data-overlay-top`, `onKeyDown`, and, under `chrome="default"`, the panel
   *   box inline styles: `Dialog` and the overlay engine win; these carry the
   *   dialog semantics and the focus trap. Use the `role` prop, not
   *   `surfaceProps`, for `alertdialog`.
   * - `className` is merged with `className`, not replaced; `style` is replaced
   *   by the dedicated `surfaceStyle` prop when that is set.
   */
  surfaceProps?: HTMLAttributes<HTMLElement>;
  /** Extra styles on the focus-trapped surface. */
  surfaceStyle?: CSSProperties;
  /** Extra class names on the panel. */
  className?: string;
  /** Extra class names on the body region. */
  bodyClassName?: string;
};

const baseBackdropStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  border: 0,
  margin: 0,
  padding: 0,
  cursor: "pointer",
  background: "color-mix(in srgb, var(--text) 45%, transparent)",
};

const centerStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  display: "grid",
  placeItems: "center",
  padding: "clamp(12px, 4vw, 32px)",
  pointerEvents: "none",
  overflowY: "auto",
};

/**
 * Styled modal dialog built on the headless overlay engine. It composes
 * `useOverlay` (focus trap + focus return, Escape, scroll lock, stacking,
 * `aria-modal`) and `<OverlayPortal>`, and adds the centered panel, backdrop,
 * and header/title/close/footer chrome. All colors come from theme tokens
 * and transitions honor reduced-motion.
 */
export function Dialog({
  open,
  onClose,
  title,
  eyebrow,
  description,
  actions,
  footer,
  children,
  chrome = "default",
  modal = true,
  size = "lg",
  showClose = true,
  closeLabel = "Close dialog",
  closeOnBackdrop = true,
  closeOnEscape = true,
  role = "dialog",
  "aria-label": ariaLabel,
  initialFocusRef,
  container,
  inline = false,
  layerClassName,
  layerStyle,
  backdropClassName,
  backdropStyle: customBackdropStyle,
  surfaceProps: surfaceAttributeProps,
  surfaceStyle,
  className,
  bodyClassName,
}: DialogProps) {
  const { getSurfaceProps, getBackdropProps, reducedMotion, zIndex } = useOverlay({
    open,
    onClose,
    modal,
    closeOnEscape,
    closeOnOutsideClick: closeOnBackdrop,
    initialFocusRef,
  });

  const titleId = useId();
  const descriptionId = useId();

  // Enter transition: mount hidden, then flip to "entered" on the next frame so
  // the panel animates in. Reduced-motion skips straight to the resting state.
  const [entered, setEntered] = useState(false);
  useEffect(() => {
    if (!open) {
      setEntered(false);
      return undefined;
    }
    if (reducedMotion) {
      setEntered(true);
      return undefined;
    }
    const frame = requestAnimationFrame(() => setEntered(true));
    return () => cancelAnimationFrame(frame);
  }, [open, reducedMotion]);

  if (!open) {
    return null;
  }

  const { className: surfaceAttributeClassName, style: surfaceAttributeStyle, ...surfaceRestProps } =
    surfaceAttributeProps ?? {};
  // Bare chrome renders no header and no description paragraph, so it has no
  // title/description element for a generated id to point at: those ids stay
  // unset there and the caller's `surfaceProps` labelling passes through
  // untouched. See `resolveSurfaceLabelling` for the precedence rule.
  const renderedTitleId = chrome === "default" && title ? titleId : undefined;
  const renderedDescriptionId = chrome === "default" && description ? descriptionId : undefined;
  const sharedSurfaceProps: HTMLAttributes<HTMLElement> = {
    ...surfaceRestProps,
    ...resolveSurfaceLabelling(surfaceRestProps, {
      titleId: renderedTitleId,
      descriptionId: renderedDescriptionId,
      ariaLabel,
    }),
    role,
    style: surfaceStyle ?? surfaceAttributeStyle,
  };

  const backdrop = (
    <div
      className={backdropClassName}
      data-ui-overlay-backdrop=""
      {...getBackdropProps({
        style:
          chrome === "default"
            ? {
                ...baseBackdropStyle,
                ...customBackdropStyle,
                cursor: closeOnBackdrop ? "pointer" : "default",
                opacity: entered ? 1 : 0,
                transition: reducedMotion ? "none" : "opacity 160ms ease",
              }
            : customBackdropStyle,
      })}
    />
  );

  if (chrome === "bare") {
    const bareSurfaceProps = getSurfaceProps(sharedSurfaceProps);
    const content = (
      <>
        {backdrop}
        <div {...bareSurfaceProps} className={cn(surfaceAttributeClassName, className)}>
          {children}
        </div>
      </>
    );

    if (inline) {
      return (
        <div className={cn("ui-overlay-portal", layerClassName)} data-ui-overlay-portal="" style={layerStyle}>
          {content}
        </div>
      );
    }

    return (
      <OverlayPortal zIndex={zIndex} container={container} className={layerClassName} style={layerStyle}>
        {content}
      </OverlayPortal>
    );
  }

  const surfaceOverrides: HTMLAttributes<HTMLElement> = {
    ...sharedSurfaceProps,
    style: {
      ...(surfaceStyle ?? surfaceAttributeStyle),
      position: "relative",
      pointerEvents: "auto",
      width: DIALOG_SIZE[size],
      maxHeight: "100%",
      display: "flex",
      flexDirection: "column",
      gap: "16px",
      padding: "22px",
      borderRadius: "var(--radius-lg, 14px)",
      border: "1px solid var(--border)",
      background: "var(--surface)",
      color: "var(--text)",
      boxShadow: "0 26px 64px color-mix(in srgb, var(--text) 26%, transparent)",
      opacity: entered ? 1 : 0,
      transform: entered ? "none" : "translateY(8px) scale(0.98)",
      transition: reducedMotion ? "none" : "opacity 160ms ease, transform 160ms ease",
    },
  };

  const surfaceProps = getSurfaceProps(surfaceOverrides);
  const content = (
    <>
      {backdrop}
      <div style={centerStyle}>
        <div
          {...surfaceProps}
          className={cn("ui-overlay-dialog", surfaceAttributeClassName, className)}
          data-ui-overlay-dialog=""
        >
          {title || actions || showClose ? (
            <header
              style={{
                display: "flex",
                alignItems: "flex-start",
                justifyContent: "space-between",
                gap: "12px",
              }}
            >
              <div style={{ display: "grid", gap: "4px", minWidth: 0 }}>
                {eyebrow ? (
                  <span
                    style={{
                      fontSize: "var(--type-sm, 0.8125rem)",
                      color: "var(--text-muted)",
                      textTransform: "uppercase",
                      letterSpacing: "0.04em",
                    }}
                  >
                    {eyebrow}
                  </span>
                ) : null}
                {title ? (
                  <h2 id={titleId} style={{ margin: 0, fontSize: "var(--type-lg, 1.25rem)", lineHeight: 1.25 }}>
                    {title}
                  </h2>
                ) : null}
              </div>
              {actions || showClose ? (
                <div style={{ display: "flex", alignItems: "center", gap: "6px", flexShrink: 0 }}>
                  {actions}
                  {showClose ? (
                    <button
                      type="button"
                      aria-label={closeLabel}
                      onClick={onClose}
                      style={closeButtonStyle}
                      data-ui-overlay-dialog-close=""
                    >
                      <X size={17} aria-hidden="true" />
                    </button>
                  ) : null}
                </div>
              ) : null}
            </header>
          ) : null}

          {description ? (
            <p id={descriptionId} style={{ margin: 0, color: "var(--text-muted)" }}>
              {description}
            </p>
          ) : null}

          {children ? (
            <div className={cn(bodyClassName)} style={{ minHeight: 0, overflowY: "auto" }}>
              {children}
            </div>
          ) : null}

          {footer ? (
            <footer style={{ display: "flex", justifyContent: "flex-end", gap: "8px", flexWrap: "wrap" }}>
              {footer}
            </footer>
          ) : null}
        </div>
      </div>
    </>
  );

  return (
    <OverlayPortal zIndex={zIndex} container={container} className={layerClassName} style={layerStyle}>
      {content}
    </OverlayPortal>
  );
}

const closeButtonStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  width: "32px",
  height: "32px",
  padding: 0,
  borderRadius: "var(--radius-sm, 8px)",
  border: "1px solid var(--border)",
  background: "transparent",
  color: "var(--text-muted)",
  cursor: "pointer",
};
