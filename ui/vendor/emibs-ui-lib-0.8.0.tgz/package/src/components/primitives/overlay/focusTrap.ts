/**
 * Focus-trap primitives for the overlay engine.
 *
 * `getTabbableElements` reads the DOM; `resolveTrapTarget` is pure so the wrap
 * logic can be unit-tested without a DOM. The keydown handler in `useOverlay`
 * composes the two: it queries the tabbable elements, finds the active one, and
 * asks `resolveTrapTarget` where (if anywhere) focus should wrap.
 */

/** Selector matching the elements a Tab press can reach. */
export const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button:not([disabled])",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  "[tabindex]:not([tabindex='-1'])",
].join(",");

/**
 * All tabbable elements inside `container`, in DOM order. Filters out disabled,
 * `aria-hidden`, and explicitly `tabindex="-1"` nodes so the trap wraps around
 * the real focus ring only.
 */
export function getTabbableElements(container: HTMLElement | null): HTMLElement[] {
  if (!container) {
    return [];
  }
  return Array.from(container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR)).filter((element) => {
    if (element.hasAttribute("disabled")) {
      return false;
    }
    if (element.getAttribute("aria-hidden") === "true") {
      return false;
    }
    return element.tabIndex !== -1;
  });
}

export type ResolveTrapTargetArgs = {
  /** Number of tabbable elements inside the trap. */
  count: number;
  /** Index of the currently focused element in the tabbable list, or -1. */
  activeIndex: number;
  /** Whether Shift was held (reverse tabbing). */
  shiftKey: boolean;
};

/**
 * Given the tabbable count, the active element's index, and the Shift state,
 * return the index focus should move to — or `null` when the browser's native
 * Tab handling already keeps focus inside the trap (no wrap needed).
 *
 * `activeIndex === -1` means focus is on the container itself (or otherwise
 * outside the tabbable list): a forward Tab lands on the first element, a
 * reverse Tab wraps to the last.
 */
export function resolveTrapTarget({ count, activeIndex, shiftKey }: ResolveTrapTargetArgs): number | null {
  if (count === 0) {
    return null;
  }
  const last = count - 1;
  if (shiftKey) {
    return activeIndex <= 0 ? last : null;
  }
  return activeIndex === -1 || activeIndex === last ? 0 : null;
}
