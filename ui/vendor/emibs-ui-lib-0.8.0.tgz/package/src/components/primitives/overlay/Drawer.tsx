import {
  useEffect,
  useId,
  useState,
  type CSSProperties,
  type HTMLAttributes,
  type ReactNode,
  type RefObject,
} from "react";
import { X } from "lucide-react";
import { cn } from "../../../lib/cn";
import { OverlayPortal } from "./OverlayPortal";
import { resolveSurfaceLabelling } from "./surfaceLabelling";
import { useOverlay } from "./useOverlay";

export type DrawerSide = "left" | "right" | "top" | "bottom";
export type DrawerChrome = "default" | "bare";

export type DrawerProps = {
  /** Whether the drawer is open. The caller owns this state. */
  open: boolean;
  /** Requested close (Escape, backdrop, close button). */
  onClose: () => void;
  /** Edge the drawer is pinned to and slides in from. Defaults to `right`. */
  side?: DrawerSide;
  /**
   * Panel size along the sliding axis: width for `left`/`right`, height for
   * `top`/`bottom`. Any CSS length. Defaults to `min(90vw, 380px)` (horizontal)
   * or `min(80vh, 360px)` (vertical).
   */
  size?: string;
  /**
   * Drawer title; renders the header and provides the accessible name.
   * Inert under `chrome="bare"`, which renders no chrome — name a bare drawer
   * with `aria-label` or `surfaceProps["aria-labelledby"]`.
   */
  title?: ReactNode;
  /** Small label above the title. Inert under `chrome="bare"`. */
  eyebrow?: ReactNode;
  /**
   * Supporting copy under the title; wired as `aria-describedby`.
   * Inert under `chrome="bare"`; describe a bare drawer with
   * `surfaceProps["aria-describedby"]`.
   */
  description?: ReactNode;
  /** Header action slot rendered before the close button. */
  actions?: ReactNode;
  /** Footer slot. */
  footer?: ReactNode;
  children?: ReactNode;
  /**
   * Render the built-in drawer chrome, or only the engine-backed layer/surface.
   *
   * `"bare"` drops the anchored panel box, the slide-in transform, the backdrop
   * fade, and the header/description/body/footer chrome, leaving the caller's
   * own markup and CSS in charge of the panel. Use it with `layerClassName` /
   * `backdropClassName` / `surfaceProps` to compose the overlay engine under an
   * already-styled panel. Because it renders no chrome, `title`, `eyebrow`,
   * `description`, `actions`, `footer`, `side`, `size`, `showClose` and
   * `closeLabel` are all inert in this mode — including their `aria-labelledby`
   * / `aria-describedby` wiring, which would otherwise point at elements bare
   * chrome never renders.
   */
  chrome?: DrawerChrome;
  /** Modal drawers trap focus, lock body scroll, and set aria-modal. */
  modal?: boolean;
  /** Show the header close button. Defaults to `true`. */
  showClose?: boolean;
  /** Accessible label for the close button. Defaults to `"Close drawer"`. */
  closeLabel?: string;
  /** Close when the backdrop is clicked. Defaults to `true`. */
  closeOnBackdrop?: boolean;
  /** Close when Escape is pressed while top-most. Defaults to `true`. */
  closeOnEscape?: boolean;
  /** Accessible name when no `title` is rendered. */
  "aria-label"?: string;
  /** Element to focus on open; falls back to the first tabbable child. */
  initialFocusRef?: RefObject<HTMLElement | null>;
  /** Portal target. Defaults to `document.body`. */
  container?: HTMLElement | null;
  /** Extra class names on the portal/layer root. */
  layerClassName?: string;
  /** Extra styles on the portal/layer root. */
  layerStyle?: CSSProperties;
  /** Extra class names on the backdrop. */
  backdropClassName?: string;
  /** Extra styles on the backdrop. */
  backdropStyle?: CSSProperties;
  /**
   * Extra attributes on the focus-trapped surface (e.g. `id`, `aria-labelledby`).
   *
   * Precedence, one rule in both directions:
   * - **Labelling and identity** — `aria-label`, `aria-labelledby`,
   *   `aria-describedby`, `id`: the caller wins. A value passed here is never
   *   replaced by one `Drawer` derives from `title`/`description`/`aria-label`,
   *   and a derived id is only emitted when the element it points at is
   *   actually rendered (never under `chrome="bare"`).
   * - **Structure** — `role`, `ref`, `tabIndex`, `aria-modal`,
   *   `data-overlay-top`, `onKeyDown`, and, under `chrome="default"`, the panel
   *   box inline styles: `Drawer` and the overlay engine win; these carry the
   *   dialog semantics and the focus trap.
   * - `className` is merged with `className`, not replaced; `style` is replaced
   *   by the dedicated `surfaceStyle` prop when that is set.
   */
  surfaceProps?: HTMLAttributes<HTMLElement>;
  /** Extra styles on the focus-trapped surface. */
  surfaceStyle?: CSSProperties;
  /** Extra class names on the panel. */
  className?: string;
  /** Extra class names on the body region. */
  bodyClassName?: string;
};

const HORIZONTAL: Record<"left" | "right", true> = { left: true, right: true };

function isHorizontal(side: DrawerSide): side is "left" | "right" {
  return side in HORIZONTAL;
}

/** Position + size the panel against its pinned edge. */
function panelAnchorStyle(side: DrawerSide, size: string): CSSProperties {
  const horizontal = isHorizontal(side);
  return {
    position: "absolute",
    top: side === "bottom" ? "auto" : 0,
    bottom: side === "top" ? "auto" : 0,
    left: side === "right" ? "auto" : 0,
    right: side === "left" ? "auto" : 0,
    width: horizontal ? size : "auto",
    height: horizontal ? "auto" : size,
  };
}

/** The hidden (offscreen) transform for the drawer's edge. */
function hiddenTransform(side: DrawerSide): string {
  switch (side) {
    case "left":
      return "translateX(-100%)";
    case "right":
      return "translateX(100%)";
    case "top":
      return "translateY(-100%)";
    case "bottom":
      return "translateY(100%)";
  }
}

const baseBackdropStyle: CSSProperties = {
  position: "absolute",
  inset: 0,
  border: 0,
  margin: 0,
  padding: 0,
  cursor: "pointer",
  background: "color-mix(in srgb, var(--text) 45%, transparent)",
};

/**
 * Styled edge drawer built on the headless overlay engine. It slides in from any
 * of the four sides, composes `useOverlay` for focus trap + focus return,
 * Escape, scroll lock, stacking, and `aria-modal`, and renders a backdrop plus
 * header/close/footer chrome. Colors are theme tokens and the
 * slide transition honors reduced-motion.
 *
 * `chrome="bare"` keeps only the engine-backed layer, backdrop, and
 * focus-trapped surface — no panel box, no slide/fade, no chrome — so an
 * already-styled product panel can compose the engine without fighting inline
 * styles. Pair it with `layerClassName`/`layerStyle`, `backdropClassName`/
 * `backdropStyle`, and `surfaceProps` (for `id`, `aria-labelledby`, …).
 */
export function Drawer({
  open,
  onClose,
  side = "right",
  size,
  title,
  eyebrow,
  description,
  actions,
  footer,
  children,
  chrome = "default",
  modal = true,
  showClose = true,
  closeLabel = "Close drawer",
  closeOnBackdrop = true,
  closeOnEscape = true,
  "aria-label": ariaLabel,
  initialFocusRef,
  container,
  layerClassName,
  layerStyle,
  backdropClassName,
  backdropStyle: customBackdropStyle,
  surfaceProps: surfaceAttributeProps,
  surfaceStyle,
  className,
  bodyClassName,
}: DrawerProps) {
  const { getSurfaceProps, getBackdropProps, reducedMotion, zIndex } = useOverlay({
    open,
    onClose,
    modal,
    closeOnEscape,
    closeOnOutsideClick: closeOnBackdrop,
    initialFocusRef,
  });

  const titleId = useId();
  const descriptionId = useId();

  const [entered, setEntered] = useState(false);
  useEffect(() => {
    if (!open) {
      setEntered(false);
      return undefined;
    }
    if (reducedMotion) {
      setEntered(true);
      return undefined;
    }
    const frame = requestAnimationFrame(() => setEntered(true));
    return () => cancelAnimationFrame(frame);
  }, [open, reducedMotion]);

  if (!open) {
    return null;
  }

  const horizontal = isHorizontal(side);
  const resolvedSize = size ?? (horizontal ? "min(90vw, 380px)" : "min(80vh, 360px)");

  const { className: surfaceAttributeClassName, style: surfaceAttributeStyle, ...surfaceRestProps } =
    surfaceAttributeProps ?? {};
  // Bare chrome renders no header and no description paragraph, so it has no
  // title/description element for a generated id to point at: those ids stay
  // unset there and the caller's `surfaceProps` labelling passes through
  // untouched. See `resolveSurfaceLabelling` for the precedence rule.
  const renderedTitleId = chrome === "default" && title ? titleId : undefined;
  const renderedDescriptionId = chrome === "default" && description ? descriptionId : undefined;
  const sharedSurfaceProps: HTMLAttributes<HTMLElement> = {
    ...surfaceRestProps,
    ...resolveSurfaceLabelling(surfaceRestProps, {
      titleId: renderedTitleId,
      descriptionId: renderedDescriptionId,
      ariaLabel,
    }),
    role: "dialog",
    style: surfaceStyle ?? surfaceAttributeStyle,
  };

  const backdrop = (
    <div
      className={backdropClassName}
      data-ui-overlay-backdrop=""
      {...getBackdropProps({
        style:
          chrome === "default"
            ? {
                ...baseBackdropStyle,
                ...customBackdropStyle,
                cursor: closeOnBackdrop ? "pointer" : "default",
                opacity: entered ? 1 : 0,
                transition: reducedMotion ? "none" : "opacity 200ms ease",
              }
            : customBackdropStyle,
      })}
    />
  );

  if (chrome === "bare") {
    const bareSurfaceProps = getSurfaceProps(sharedSurfaceProps);
    return (
      <OverlayPortal zIndex={zIndex} container={container} className={layerClassName} style={layerStyle}>
        {backdrop}
        <div {...bareSurfaceProps} className={cn(surfaceAttributeClassName, className)}>
          {children}
        </div>
      </OverlayPortal>
    );
  }

  const surfaceOverrides: HTMLAttributes<HTMLElement> = {
    ...sharedSurfaceProps,
    style: {
      ...(surfaceStyle ?? surfaceAttributeStyle),
      ...panelAnchorStyle(side, resolvedSize),
      pointerEvents: "auto",
      display: "flex",
      flexDirection: "column",
      gap: "16px",
      padding: "20px",
      border: "1px solid var(--border)",
      background: "var(--surface)",
      color: "var(--text)",
      boxShadow: "0 24px 60px color-mix(in srgb, var(--text) 26%, transparent)",
      transform: entered ? "none" : hiddenTransform(side),
      transition: reducedMotion ? "none" : "transform 200ms ease",
    },
  };

  const surfaceProps = getSurfaceProps(surfaceOverrides);

  return (
    <OverlayPortal zIndex={zIndex} container={container} className={layerClassName} style={layerStyle}>
      {backdrop}
      <div
        {...surfaceProps}
        className={cn("ui-overlay-drawer", `ui-overlay-drawer--${side}`, surfaceAttributeClassName, className)}
        data-ui-overlay-drawer=""
      >
        {title || actions || showClose ? (
          <header
            style={{
              display: "flex",
              alignItems: "flex-start",
              justifyContent: "space-between",
              gap: "12px",
            }}
          >
            <div style={{ display: "grid", gap: "4px", minWidth: 0 }}>
              {eyebrow ? (
                <span
                  style={{
                    fontSize: "var(--type-sm, 0.8125rem)",
                    color: "var(--text-muted)",
                    textTransform: "uppercase",
                    letterSpacing: "0.04em",
                  }}
                >
                  {eyebrow}
                </span>
              ) : null}
              {title ? (
                <h2 id={titleId} style={{ margin: 0, fontSize: "var(--type-lg, 1.25rem)", lineHeight: 1.25 }}>
                  {title}
                </h2>
              ) : null}
            </div>
            {actions || showClose ? (
              <div style={{ display: "flex", alignItems: "center", gap: "6px", flexShrink: 0 }}>
                {actions}
                {showClose ? (
                  <button
                    type="button"
                    aria-label={closeLabel}
                    onClick={onClose}
                    style={closeButtonStyle}
                    data-ui-overlay-drawer-close=""
                  >
                    <X size={17} aria-hidden="true" />
                  </button>
                ) : null}
              </div>
            ) : null}
          </header>
        ) : null}

        {description ? (
          <p id={descriptionId} style={{ margin: 0, color: "var(--text-muted)" }}>
            {description}
          </p>
        ) : null}

        {children ? (
          <div className={cn(bodyClassName)} style={{ flex: 1, minHeight: 0, overflowY: "auto" }}>
            {children}
          </div>
        ) : null}

        {footer ? (
          <footer style={{ display: "flex", justifyContent: "flex-end", gap: "8px", flexWrap: "wrap" }}>
            {footer}
          </footer>
        ) : null}
      </div>
    </OverlayPortal>
  );
}

const closeButtonStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  width: "32px",
  height: "32px",
  padding: 0,
  borderRadius: "var(--radius-sm, 8px)",
  border: "1px solid var(--border)",
  background: "transparent",
  color: "var(--text-muted)",
  cursor: "pointer",
};
