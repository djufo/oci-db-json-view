import type { HTMLAttributes } from "react";

/**
 * Labelling attributes a styled overlay (Dialog/Drawer) may derive from its own
 * props, for the surface it hands to `useOverlay`.
 */
export type GeneratedSurfaceLabelling = {
  /**
   * Id of the title element the overlay ACTUALLY RENDERS in this configuration,
   * or `undefined` when it renders none. Pass `undefined` whenever the title
   * node is not in the tree — `chrome="bare"` renders no chrome, so it never has
   * a title element to point at.
   */
  titleId?: string;
  /**
   * Id of the description element the overlay ACTUALLY RENDERS, or `undefined`
   * when it renders none. Same rule as `titleId`.
   */
  descriptionId?: string;
  /** Literal accessible name from the overlay's own `aria-label` prop. */
  ariaLabel?: string;
};

export type SurfaceLabellingAttributes = {
  "aria-label": string | undefined;
  "aria-labelledby": string | undefined;
  "aria-describedby": string | undefined;
};

type CallerLabelling = Pick<
  HTMLAttributes<HTMLElement>,
  "aria-label" | "aria-labelledby" | "aria-describedby"
>;

/**
 * Resolve the surface's labelling attributes from what the caller passed
 * through `surfaceProps` and what the overlay generated for its own chrome.
 *
 * Two rules, and they are the whole contract (issue: bare-chrome dangling
 * `aria-labelledby`, found by the cross-provider review of PR #484):
 *
 * 1. **The caller wins.** A value supplied in `surfaceProps` is never silently
 *    replaced by a generated one. `surfaceProps` exists so an already-styled
 *    panel can own its own labelling; overriding it defeats the seam.
 * 2. **No reference to an element that is not rendered.** A generated id is only
 *    a fallback, and only when the overlay actually renders the element the id
 *    is on. Callers pass `undefined` for a node they do not render, which is why
 *    the fields are named for the *rendered element*, not for the prop.
 *
 * The returned object is total: every key is present (possibly `undefined`), so
 * spreading it after the caller's own props resolves the attribute in one place
 * rather than leaving a stale value behind.
 */
export function resolveSurfaceLabelling(
  caller: CallerLabelling,
  generated: GeneratedSurfaceLabelling,
): SurfaceLabellingAttributes {
  const labelledBy = caller["aria-labelledby"] ?? generated.titleId;
  return {
    "aria-labelledby": labelledBy,
    // A rendered title names the surface; `aria-label` is the no-title
    // fallback, and the caller's own `aria-label` outranks both.
    "aria-label": caller["aria-label"] ?? (generated.titleId ? undefined : generated.ariaLabel),
    "aria-describedby": caller["aria-describedby"] ?? generated.descriptionId,
  };
}
