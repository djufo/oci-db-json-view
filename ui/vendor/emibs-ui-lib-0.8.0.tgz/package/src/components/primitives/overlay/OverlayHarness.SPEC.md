# OverlayHarness

## Purpose

`OverlayHarness` is the review surface for the headless overlay engine
(`useOverlay` + `OverlayPortal`, specified in `overlay.SPEC.md`). The engine has
no markup of its own, so nothing about it can be looked at directly; the harness
is the thing you look at instead. It renders two deliberately unstyled overlays
— a primary one and a nested one opened from inside it — so that focus trap,
focus return, Escape, outside click, body scroll lock, stacking order and
reduced motion are all observable at once, and it carries an axe-core button so
the same surface can be audited in the running app.

It is a harness, not a product component: it ships no chrome worth reusing, and
a consumer building a real overlay should compose `Dialog`, `Drawer`, `Popover`
or the engine directly. It is catalogued because it is exported from the package
barrel (uif/issue-4678) — an exported thing that renders belongs in the coverage
figure, and "it is only a harness" is a reason to say so in a spec, not a reason
to leave it undocumented.

## Source Evidence

- `overlay.SPEC.md` § Review Expectations names this harness as the proof of the
  engine's behaviours, and its "Deferred shared-file wiring" section recorded
  the catalog registration this entry completes.
- `tests/overlay/backdropA11y.test.tsx` mounts the harness to assert the
  backdrop stays out of the accessibility tree.

## Contract

- Renders a trigger, an axe-core audit button, and two overlays. The nested
  overlay is opened from a button inside the primary one, so the stacking rule
  (Escape closes the top-most overlay first) has something to close.
- Both overlays are controllable and uncontrolled by default. `open` /
  `defaultOpen` / `onOpenChange` govern the primary overlay and `nestedOpen` /
  `defaultNestedOpen` / `onNestedOpenChange` the nested one, following the
  package's existing controlled shape (`Menu`, `FilePreviewDialog`,
  `Collapsible`, `SectionCard`, `DataTable`): the value prop wins whenever it is
  defined, the default-prefixed prop seeds the internal value, and the change
  callback fires on every change in both modes. Passing neither leaves the
  harness owning its own state, exactly as before. A controlled value supplied without its callback only
  requests changes and does not move until the caller rerenders it.
- `container` is forwarded to `OverlayPortal` and `modal` to `useOverlay`, so a
  contained preview can host the overlays inside its own stage rather than over
  the page — the containment the catalog's `Dialog` / `Drawer` / `Popover`
  states already rely on.
- `scrollProbe` (default on) renders the tall spacer that makes body scroll lock
  observable. It is off in contained previews, where there is no page scroll to
  lock and the spacer would only stretch the card.
- Heading ids are derived per instance, because the catalog renders the demo,
  the variants grid and the states grid on one page and a fixed id would
  duplicate across them.
- No hard-coded colours: the backdrop and panel derive from `--text`,
  `--surface` and `--border` through `color-mix`.

## Boundaries

- No product state, routing or content, and no reusable chrome — the styled
  surfaces are `Dialog`, `Drawer` and `Popover`.
- The behaviours themselves live in the engine; the harness only exercises them.
  Their contract is `overlay.SPEC.md`, not this file.

## Review Checks

- Opening the primary overlay traps Tab inside it and returns focus to the
  trigger on close.
- Opening the nested overlay stacks above the primary one, and Escape closes the
  nested one first.
- The axe-core audit reports clean with an overlay open.
- Rendering with no props behaves exactly as the harness did before it took any.
