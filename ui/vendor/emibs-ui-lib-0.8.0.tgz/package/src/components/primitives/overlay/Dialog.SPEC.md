# Overlays/Dialog

## Purpose

`Dialog` is the styled modal dialog primitive of the UIF overlay family. It
composes the headless overlay engine (`useOverlay` + `<OverlayPortal>`, issue
690) and adds the visual chrome — centered panel, backdrop, and
header/title/close/footer slots — so product dialogs get focus trap, focus
return, Escape, body scroll lock, stacking, and `aria-modal` for free. Parent
epic: issue 682; this is story S2 (issue 691).

## Source Evidence

- `components/feedback/DialogFrame.tsx` is the canonical Score dialog shell, but
  it hand-rolls only Escape + backdrop close — it has **no focus trap** and
  **no body scroll lock**. `ConfirmationDialog`/`CreationDialog` build on it.
- The overlay engine (`components/primitives/overlay/`) already owns those
  cross-cutting behaviors; `Dialog` is the styled surface that delegates to it,
  closing the DialogFrame a11y gap once refactored onto this primitive.

## Contract

- `Dialog({ open, onClose })` renders through `useOverlay` (modal) +
  `<OverlayPortal>`: backdrop button (`getBackdropProps`) and a centered panel
  surface (`getSurfaceProps`) with `role="dialog"` (or `alertdialog`),
  `aria-modal`, focus trap, scroll lock, Escape, and focus return.
- `chrome="bare"` keeps only the engine-backed layer, backdrop, and focus
  surface so existing dialog chrome can migrate without changing class names;
  `inline` supports contained catalog/review surfaces and `modal={false}` skips
  focus trap, scroll lock, and `aria-modal`. It renders no chrome, so
  `title`/`eyebrow`/`description`/`actions`/`footer` are inert there —
  *including their `aria-labelledby`/`aria-describedby` wiring*: with no title or
  description element rendered, no generated reference to one is emitted. A bare
  dialog is named by `aria-label` or `surfaceProps["aria-labelledby"]`.
- **Surface attribute precedence** — labelling and identity (`aria-label`,
  `aria-labelledby`, `aria-describedby`, `id`) are the caller's: a `surfaceProps`
  value is never silently replaced by one derived from
  `title`/`description`/`aria-label`, and a derived id is emitted only when the
  element it points at is rendered. Structure (`role`, `ref`, `tabIndex`,
  `aria-modal`, `data-overlay-top`, `onKeyDown`, and the default-chrome panel box
  styles) belongs to `Dialog`/the engine — use the `role` prop for
  `alertdialog`. `className` merges; `style` yields to `surfaceStyle`. Shared
  with `Drawer` via `overlay/surfaceLabelling.ts`.
- Slots: `title` (renders `<h2>` and provides `aria-labelledby`), `eyebrow`,
  `description` (`aria-describedby`), header `actions`, `children` body, and
  `footer`. `aria-label` supplies the name when there is no `title`.
- Sizing via `size` (`sm|md|lg|xl`); `showClose`/`closeLabel`,
  `closeOnBackdrop`, `closeOnEscape`, `initialFocusRef`, and `container`
  (portal target) are configurable.
- Enter transition (fade + rise) is gated on the engine's `reducedMotion`.
- Colors come from theme tokens (`--surface`, `--border`, `--text`,
  `--text-muted`, `--radius-*`, `--type-*`) with standalone fallbacks; no
  hard-coded palette.

## Non-Goals

- No product state: open/close ownership, data, routing, validation, and busy
  handling stay with the consumer.
- No form/confirmation semantics — those compose `Dialog` in the product /
  feedback layer (ConfirmationDialog/CreationDialog).

## Review Expectations

- Focus moves in on open and returns to the trigger on close; Tab cycles within;
  Escape closes the top-most dialog first when stacked.
- axe-core clean; keyboard-only operable; labelled by its title (or
  `aria-label`).
- Renders correctly in light/dark + community themes (token-driven), and honors
  reduced-motion.

