/**
 * Overlay stacking manager.
 *
 * A tiny module-level store that tracks the order in which overlays are open so
 * that nested/multiple overlays layer correctly and the top-most one owns
 * "global" behaviors (Escape closes the top-most first). It is intentionally
 * framework-agnostic and side-effect-light: React binds to it via
 * `useSyncExternalStore` in `useOverlay`.
 */

let stack: string[] = [];
const listeners = new Set<() => void>();

function emit(): void {
  for (const listener of listeners) {
    listener();
  }
}

/**
 * Register an overlay as open and move it to the top of the stack. Re-pushing an
 * id that is already present is idempotent in membership but re-orders it to the
 * top, which keeps the last-opened overlay top-most.
 */
export function pushOverlay(id: string): void {
  const next = stack.filter((entry) => entry !== id);
  next.push(id);
  stack = next;
  emit();
}

/** Remove an overlay from the stack (on close/unmount). No-op if absent. */
export function removeOverlay(id: string): void {
  if (!stack.includes(id)) {
    return;
  }
  stack = stack.filter((entry) => entry !== id);
  emit();
}

/** Snapshot of the current stack, bottom-most first. */
export function getOverlayStack(): readonly string[] {
  return stack;
}

/** Zero-based depth of an overlay (bottom = 0). `-1` when not in the stack. */
export function overlayDepth(id: string): number {
  return stack.indexOf(id);
}

/** Whether the given overlay is the top-most (last-opened) one. */
export function isTopOverlay(id: string): boolean {
  return stack.length > 0 && stack[stack.length - 1] === id;
}

/** Subscribe to stack changes. Returns an unsubscribe function. */
export function subscribeOverlayStack(listener: () => void): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/** Test-only: clear all stack state and listeners. */
export function __resetOverlayStack(): void {
  stack = [];
  listeners.clear();
}
