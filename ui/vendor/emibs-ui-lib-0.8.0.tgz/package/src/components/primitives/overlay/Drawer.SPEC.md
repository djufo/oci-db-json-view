# Overlays/Drawer

## Purpose

`Drawer` is the styled edge-drawer primitive of the UIF overlay family. It
slides a modal panel in from any of the four viewport edges and composes the
headless overlay engine (`useOverlay` + `<OverlayPortal>`, issue 690) for focus
trap, focus return, Escape, body scroll lock, stacking, and `aria-modal`. Parent
epic: issue 682; this is story S3 (issue 692).

## Source Evidence

- `components/data/FilterDrawerPanel.tsx` rendered a right-side filter drawer
  with a backdrop and close button, but hand-rolled the shell and lacked a focus
  trap and scroll lock. `Drawer` supplies those via the engine, and
  FilterDrawerPanel now composes it (`chrome="bare"`) rather than
  `useOverlay`/`OverlayPortal` directly.

## Contract

- `Drawer({ open, onClose, side })` supports `side` = `left|right|top|bottom`;
  the panel is pinned to that edge (full height for `left`/`right`, full width
  for `top`/`bottom`) and slides in from it. `size` sets the panel extent along
  the sliding axis (sensible horizontal/vertical defaults).
- Composes `useOverlay` (modal by default): backdrop button + panel surface with
  `role="dialog"`, `aria-modal`, focus trap, scroll lock, Escape, focus return.
  `modal={false}` keeps the drawer dismissible without trapping focus or locking
  body scroll for review/non-blocking surfaces.
- Slots: `title` (`aria-labelledby`), `eyebrow`, `description`
  (`aria-describedby`), header `actions`, `children` body, `footer`;
  `aria-label` names it when there is no `title`. `showClose`/`closeLabel`,
  `closeOnBackdrop`, `closeOnEscape`, `initialFocusRef`, and `container` are
  configurable.
- Slide transition is per-side and gated on `reducedMotion`.
- Theme-token colors with standalone fallbacks; no hard-coded palette.
- `chrome="bare"` is the engine-only adapter mode, matching `Dialog`'s existing
  `chrome` contract. It keeps the portal layer, the backdrop element, and the
  focus-trapped surface — and therefore focus trap + focus return, Escape,
  scroll lock, stacking, and `aria-modal` — while dropping the anchored panel
  box, the slide-in transform, the backdrop fade, and the
  header/description/body/footer chrome, so an already-styled product panel owns
  its own markup and CSS. `side`/`size`/`showClose`/`closeLabel` are inert in
  this mode by definition, and so are `title`/`eyebrow`/`description`/`actions`/
  `footer` — *including their `aria-labelledby`/`aria-describedby` wiring*. Bare
  chrome renders no title or description element, so it emits no generated
  reference to one; a bare drawer is named by `aria-label` or by
  `surfaceProps["aria-labelledby"]`.
- **Surface attribute precedence** (one rule, both primitives):
  - *Labelling and identity* — `aria-label`, `aria-labelledby`,
    `aria-describedby`, `id`: **`surfaceProps` wins.** A caller value is never
    silently replaced by one derived from `title`/`description`/`aria-label`,
    and a derived id is emitted only when the element it points at is actually
    rendered. (Before this rule, bare chrome overrode a caller's
    `aria-labelledby` with an id for a header it had not rendered — a dangling
    reference and an unnamed dialog, i.e. the exact `aria-valid-attr-value`
    failure `surfaceProps` exists to avoid.)
  - *Structure* — `role`, `ref`, `tabIndex`, `aria-modal`, `data-overlay-top`,
    `onKeyDown`, and (default chrome only) the panel box inline styles:
    **`Drawer`/the engine win.** These carry the dialog semantics and the focus
    trap and are not a caller's to swap out through the attribute bag.
  - `className` is merged with the `className` prop rather than replaced;
    `style` is replaced by the dedicated `surfaceStyle` prop when set.
  - The rule lives in one place, `overlay/surfaceLabelling.ts`, shared by
    `Dialog` and `Drawer`.
- Layer, backdrop, and surface hooks (also mirroring `Dialog`):
  `layerClassName`/`layerStyle` on the portal root, `backdropClassName`/
  `backdropStyle` on the backdrop, `surfaceProps`/`surfaceStyle` on the surface.
  `surfaceProps` is how a consumer supplies the panel's `id` (so a trigger's
  `aria-controls` resolves) or its own `aria-labelledby`. Every one of these is
  additive: with `chrome="default"` and none of them set, the rendered tree,
  inline styles, and transitions are byte-for-byte what they were before.

## Non-Goals

- No product state: open/close ownership, filter derivation, persistence,
  routing, and analytics stay with the consumer.
- No trigger button/summary chrome — that stays in the product panel
  (FilterDrawerPanel) that composes `Drawer`.

## Review Expectations

- All four sides slide from the correct edge with focus trap + scroll lock +
  Escape + focus return.
- axe-core clean; full keyboard operability; labelled by title or `aria-label`.
- Light/dark + community themes (token-driven); reduced-motion honored.
- The `chrome`/layer/backdrop/surface API is additive: no existing consumer
  passes any of it, and `chrome="default"` output is unchanged.

## Shared-file wiring — done

`components/data/FilterDrawerPanel.tsx` composes `Drawer` (`chrome="bare"`). The
four capability gaps that previously made the migration lossy are closed, and
each is closed by contract rather than by a workaround:

- **Panel `id`.** `surfaceProps={{ id: panelId, "aria-labelledby": titleId }}`
  puts the panel's `id` back on the surface, so the trigger's
  `aria-controls={panelId}` still resolves (a dangling reference would fail
  axe's `aria-valid-attr-value`) and the panel is still named by its own `h2`.
- **Portal layer + backdrop.** `layerClassName="ui-filter-drawer__mount"` keeps
  the `display: grid; justify-items: end` layer — and therefore its
  `max-width: 640px` flip to `justify-items: stretch; align-items: end`, the
  side-panel-to-bottom-sheet behaviour. `backdropClassName="ui-filter-drawer__overlay"`
  keeps the panel's own `color-mix(in srgb, var(--bg) 62%, transparent)` wash
  instead of `Drawer`'s `var(--text) 45%`; bare chrome adds no inline backdrop
  style, so the class is unopposed.
- **Panel box.** Bare chrome emits no inline box styles on the surface, so
  `.ui-filter-drawer__panel--drawer`'s `display: grid` /
  `grid-template-rows: auto minmax(0, 1fr) auto` / `width: min(430px, calc(100vw - 24px))`
  layout applies unopposed, and no entrance slide or backdrop fade is
  introduced — the panel has never had either.
- **Chrome ownership.** Bare chrome renders `children` and nothing else, so the
  one `panelContents` tree (badges, summary `Badge`, header/close/body/footer,
  `ui-filter-drawer__*` classes) stays shared between the inline and drawer
  modes, and the labelling stays with the panel's own heading.

The catalog entry (states, variants, prop docs, usage snippets) and
`catalog/metadata.ts` registration cover the `chrome`/layer/backdrop/surface
API. The package-index export (`lib/index.ts`) was already done.
