/**
 * Overlays/engine — headless foundation every floating surface composes.
 *
 * Public surface: the `useOverlay` hook and `<OverlayPortal>` component, plus
 * the lower-level utilities (stacking, focus trap, scroll lock, reduced motion)
 * for consumers that need direct access.
 */

export { useOverlay, OVERLAY_Z_INDEX_VAR, OVERLAY_Z_INDEX_STEP } from "./useOverlay";
export type {
  UseOverlayOptions,
  UseOverlayResult,
  OverlaySurfaceProps,
  OverlayBackdropProps,
} from "./useOverlay";

export { OverlayContainerProvider, OverlayPortal } from "./OverlayPortal";
export type { OverlayPortalProps } from "./OverlayPortal";

export { Dialog } from "./Dialog";
export type { DialogChrome, DialogProps, DialogSize } from "./Dialog";

export { Drawer } from "./Drawer";
export type { DrawerChrome, DrawerProps, DrawerSide } from "./Drawer";

export { Popover, getPopoverTriggerProps } from "./Popover";
export type { PopoverProps, PopoverSide, PopoverAlign } from "./Popover";

export {
  computePopoverPosition,
  resolvePopoverSide,
} from "./positioning";
export type {
  ComputePopoverPositionArgs,
  PopoverPosition,
  PopoverTriggerAria,
  Rect as PopoverRect,
  Size as PopoverSize,
  Viewport as PopoverViewport,
} from "./positioning";

export {
  getOverlayStack,
  isTopOverlay,
  overlayDepth,
  pushOverlay,
  removeOverlay,
  subscribeOverlayStack,
} from "./stacking";

export { FOCUSABLE_SELECTOR, getTabbableElements, resolveTrapTarget } from "./focusTrap";
export type { ResolveTrapTargetArgs } from "./focusTrap";

export { computeScrollbarCompensation, lockBodyScroll } from "./scrollLock";

export { REDUCED_MOTION_QUERY, prefersReducedMotion, subscribeReducedMotion } from "./reducedMotion";
