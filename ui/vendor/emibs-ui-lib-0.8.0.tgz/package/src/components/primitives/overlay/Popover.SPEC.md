# Overlays/Popover

## Purpose

`Popover` is the anchored, collision-aware floating-surface primitive of the UIF
overlay family. It positions content relative to a trigger and flips/shifts to
stay within the viewport. Unlike Dialog/Drawer it is **non-modal**: it does not
lock body scroll or trap focus by default, the page stays interactive, and it
light-dismisses on outside click or Escape. Parent epic: issue 682; this is
story S6 (issue 693).

## Source Evidence

- Score/eLitua menus, filter poppers, and quick actions currently anchor ad-hoc
  floating panels without shared collision handling or dismiss/focus wiring. The
  overlay engine (issue 690) already provides portal, stacking, Escape, and
  focus-return; `Popover` adds anchored positioning on top.

## Contract

- `Popover({ open, onClose, anchorRef, side, align })` measures `anchorRef` and
  its own surface, then computes `{ left, top, side }` with the pure
  `computePopoverPosition` helper: `side` (`top|bottom|left|right`) flips to the
  opposite edge when clipped; `align` (`start|center|end`) shifts on the cross
  axis and clamps within the padded viewport. Recomputes on scroll/resize and
  on its own resize (`ResizeObserver`).
- Non-modal by default (`modal={false}`): the portal layer is
  `pointer-events:none` so the page stays clickable; a document `pointerdown`
  outside the surface and anchor dismisses; Escape dismisses via the engine;
  focus returns to the trigger on close. `modal` is an escape hatch that reuses
  the engine's focus trap + scroll lock.
- ARIA: the surface carries `role` (default `dialog`), an `id`, and
  `aria-label`/`aria-labelledby`; wire the trigger with
  `getPopoverTriggerProps({ open, id })` for `aria-haspopup` /
  `aria-expanded` / `aria-controls`.
- `matchAnchorWidth` matches the surface min-width to the anchor. Theme-token
  colors with fallbacks; opacity transition gated on `reducedMotion`.
- The floating surface stays hidden until first measured, so it never flashes at
  the origin.

## Non-Goals

- No product state: open/close ownership, menu/listbox item semantics, hover
  intent, and content stay with the consumer.
- No arrow/caret rendering or virtual-anchor (rect-only) support in this story;
  it anchors to a real element ref.

## Review Expectations

- Positions correctly for all sides/alignments and flips/shifts near viewport
  edges (covered by `tests/overlay/positioning.test.ts`).
- Dismisses on outside click + Escape; focus returns to the anchor.
- axe-core clean; keyboard operable; reduced-motion honored; theme tokens only.

## Deferred shared-file wiring

- Catalog demo + `catalog/metadata.ts` registration (shared files outside
  `primitives/overlay/`). The package-index export (`lib/index.ts`) is done.
