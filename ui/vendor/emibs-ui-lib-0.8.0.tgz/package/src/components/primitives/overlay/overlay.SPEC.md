# Overlays/engine — `useOverlay` + `OverlayPortal`

## Purpose

The headless foundation every floating surface in the UIF composes. It owns the
cross-cutting overlay behaviors — focus trap, focus return, Escape, outside
click, body scroll lock, stacking/z-index, and reduced-motion — with **no visual
chrome**. Styled Dialog/Drawer/Popover primitives (issues 691–693) provide their
own markup and delegate behavior here, mirroring the Forms headless-engine
pattern (issue 552). Parent epic: issue 682.

## Source Evidence

- `CommandPalette` (`components/primitives/CommandPalette.tsx`) already
  hand-rolls focus trap, focus return, Escape, and a focusable-element query;
  `DialogFrame`/`ConfirmationDialog`/`CreationDialog` each re-implement an
  Escape + backdrop-close overlay shell. The engine extracts that shared
  behavior once so those surfaces can converge on it.

## Contract

- `useOverlay({ open, onClose, modal })` returns `overlayRef`, `isTop`, `depth`,
  `zIndex`, `reducedMotion`, `getSurfaceProps`, and `getBackdropProps`.
  - `modal` (default `true`) enables focus trap, scroll lock, and `aria-modal`;
    `trapFocus` / `lockScroll` default to `modal` and can be toggled
    independently. `closeOnEscape` / `closeOnOutsideClick` default `true`.
  - Focus trap: Tab cycles within the surface, Shift+Tab wraps; focus moves to
    the first tabbable child (or `initialFocusRef`) on open and returns to the
    trigger on close (`restoreFocus`, default `true`).
  - Stacking: opening a second overlay layers above the first via a module-level
    stack; only the **top-most** overlay reacts to Escape and Tab. z-index is
    `calc(var(--ui-z-overlay, 1000) + depth * 10)`. `--ui-z-overlay` is the base
    of the layering scale defined in `styles.css` (`--ui-z-base` …
    `--ui-z-toast`); the literal fallback is retained so the engine stays
    functional for consumers that do not load the package stylesheet.
  - Scroll lock is reference-counted across stacked overlays and compensates the
    reclaimed scrollbar width so content does not shift; it restores on close.
- `<OverlayPortal>` mounts children into `document.body` (or a supplied
  `container`) inside a fixed, full-viewport positioning layer carrying the
  z-index. SSR-safe; `disabled` renders inline.
- Utilities are exported for direct use: `getTabbableElements`,
  `resolveTrapTarget`, `computeScrollbarCompensation`, `lockBodyScroll`,
  `prefersReducedMotion`, and the stacking accessors.

## Non-Goals

- No backdrop, panel, sizing, animation, or color chrome — those belong to the
  styled primitives (issues 691–693).
- No product state: open/close ownership, routing, data, and content stay with
  the consumer.

## Review Expectations

- `OverlayHarness` proves focus trap/return, Escape, outside-click, scroll lock,
  stacking (Escape closes top-most first), reduced-motion, and runs an in-app
  axe-core audit that must report clean.
- No hard-coded colors; the harness derives its demo backdrop/panel from theme
  tokens via `color-mix`.

## Catalog wiring

- `OverlayHarness` is registered in `catalog/metadata.ts` + `catalog/registry`
  with its full six-facet surface (uif/issue-4678); the harness's own contract
  lives in `OverlayHarness.SPEC.md`. The package-index export (`lib/index.ts`)
  was already done.
