/**
 * Pure anchored-positioning math for the Popover primitive.
 *
 * `computePopoverPosition` is DOM-free so the collision logic (flip on the main
 * axis, shift/clamp on the cross axis) can be unit-tested without a browser. The
 * `Popover` component measures the anchor + floating rects and viewport, then
 * delegates the arithmetic here — mirroring how `useOverlay` delegates its wrap
 * logic to `resolveTrapTarget`.
 */

export type PopoverSide = "top" | "bottom" | "left" | "right";
export type PopoverAlign = "start" | "center" | "end";

export type Rect = { top: number; left: number; width: number; height: number };
export type Size = { width: number; height: number };
export type Viewport = { width: number; height: number };

export type ComputePopoverPositionArgs = {
  /** Anchor/trigger rect in viewport coordinates. */
  anchor: Rect;
  /** Measured size of the floating popover. */
  floating: Size;
  /** Available viewport (typically innerWidth/innerHeight). */
  viewport: Viewport;
  /** Preferred side. Defaults to `bottom`. */
  side?: PopoverSide;
  /** Cross-axis alignment. Defaults to `center`. */
  align?: PopoverAlign;
  /** Gap between anchor and floating element, in px. Defaults to `8`. */
  offset?: number;
  /** Minimum gap kept from the viewport edges, in px. Defaults to `8`. */
  padding?: number;
};

export type PopoverPosition = {
  /** Final viewport-space coordinates for the floating element. */
  left: number;
  top: number;
  /** The side actually used after collision flipping. */
  side: PopoverSide;
};

const OPPOSITE: Record<PopoverSide, PopoverSide> = {
  top: "bottom",
  bottom: "top",
  left: "right",
  right: "left",
};

function clamp(value: number, min: number, max: number): number {
  if (max < min) {
    // Floating is larger than the available band; pin to the near edge.
    return min;
  }
  return Math.min(Math.max(value, min), max);
}

/** Space (px) between the anchor and the viewport edge on the given side. */
function spaceOnSide(anchor: Rect, viewport: Viewport, side: PopoverSide): number {
  switch (side) {
    case "top":
      return anchor.top;
    case "bottom":
      return viewport.height - (anchor.top + anchor.height);
    case "left":
      return anchor.left;
    case "right":
      return viewport.width - (anchor.left + anchor.width);
  }
}

/**
 * Resolve the effective side: keep the preferred one unless it lacks room and
 * the opposite side has strictly more space.
 */
export function resolvePopoverSide(args: {
  anchor: Rect;
  floating: Size;
  viewport: Viewport;
  side: PopoverSide;
  offset: number;
}): PopoverSide {
  const { anchor, floating, viewport, side, offset } = args;
  const needed = (side === "top" || side === "bottom" ? floating.height : floating.width) + offset;
  const space = spaceOnSide(anchor, viewport, side);
  if (space >= needed) {
    return side;
  }
  const opposite = OPPOSITE[side];
  return spaceOnSide(anchor, viewport, opposite) > space ? opposite : side;
}

/** Cross-axis start coordinate before clamping, for a given alignment. */
function alignStart(anchorStart: number, anchorLength: number, floatLength: number, align: PopoverAlign): number {
  switch (align) {
    case "start":
      return anchorStart;
    case "end":
      return anchorStart + anchorLength - floatLength;
    case "center":
      return anchorStart + anchorLength / 2 - floatLength / 2;
  }
}

/**
 * Compute the final `{ left, top, side }` for an anchored popover, flipping to
 * the opposite side when the preferred one is clipped and shifting the cross
 * axis to stay within the padded viewport.
 */
export function computePopoverPosition(args: ComputePopoverPositionArgs): PopoverPosition {
  const { anchor, floating, viewport, side = "bottom", align = "center", offset = 8, padding = 8 } = args;

  const resolvedSide = resolvePopoverSide({ anchor, floating, viewport, side, offset });

  let left: number;
  let top: number;

  if (resolvedSide === "top" || resolvedSide === "bottom") {
    // Main axis = vertical, cross axis = horizontal.
    top = resolvedSide === "bottom" ? anchor.top + anchor.height + offset : anchor.top - floating.height - offset;
    top = clamp(top, padding, viewport.height - floating.height - padding);
    const rawLeft = alignStart(anchor.left, anchor.width, floating.width, align);
    left = clamp(rawLeft, padding, viewport.width - floating.width - padding);
  } else {
    // Main axis = horizontal, cross axis = vertical.
    left = resolvedSide === "right" ? anchor.left + anchor.width + offset : anchor.left - floating.width - offset;
    left = clamp(left, padding, viewport.width - floating.width - padding);
    const rawTop = alignStart(anchor.top, anchor.height, floating.height, align);
    top = clamp(rawTop, padding, viewport.height - floating.height - padding);
  }

  return { left, top, side: resolvedSide };
}

export type PopoverTriggerAria = {
  "aria-haspopup": "dialog" | "menu" | "listbox" | "grid" | "tree" | true;
  "aria-expanded": boolean;
  "aria-controls": string | undefined;
};

/**
 * ARIA props for the element that toggles a popover. Spread these onto the
 * trigger so assistive tech announces the expanded state and the controlled
 * surface. `aria-controls` is only meaningful while the popover is in the DOM.
 */
export function getPopoverTriggerProps(args: {
  open: boolean;
  /** The popover surface id (matches the surface's `id`). */
  id: string;
  haspopup?: PopoverTriggerAria["aria-haspopup"];
}): PopoverTriggerAria {
  const { open, id, haspopup = "dialog" } = args;
  return {
    "aria-haspopup": haspopup,
    "aria-expanded": open,
    "aria-controls": open ? id : undefined,
  };
}
