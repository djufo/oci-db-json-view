# Menu

## Purpose

`Menu` is the canonical Material-style dropdown action menu. It composes the
shared `Popover` positioning/overlay mechanism and adds menu-specific item and
keyboard semantics in one place.

## Public API

- `triggerLabel: string`: visible trigger copy and subject of the synchronized
  state-first accessible label.
- `items: readonly MenuItem[]`: `{ id, label, disabled?, tone?, onSelect? }`.
- `menuLabel`: optional accessible name for the popup; defaults to
  `triggerLabel`.
- `open` / `onOpenChange`: controlled state; omit `open` and use `defaultOpen`
  for uncontrolled state.
- `onSelect(item)`: optional shared item selection callback.
- `align: start | center | end`, `disabled`, and `triggerVariant`.

## Variants

| Variant | Contract |
| --- | --- |
| Default item | Normal action color |
| Danger item | Danger token; behavior is otherwise identical |
| Disabled item | Native disabled and skipped by keyboard movement |
| Controlled | Consumer is state source of truth |
| Uncontrolled | Component owns open state from `defaultOpen` |

## States matrix

| State | Trigger contract | Popup/focus contract |
| --- | --- | --- |
| Closed | `aria-expanded=false`; label begins `Menu closed` then names open action | Popup absent |
| Open | `aria-expanded=true`; label begins `Menu open` then names close action | `role=menu`; initial enabled item focused |
| Keyboard open | ArrowDown opens at first; ArrowUp opens at last | Disabled items skipped |
| Navigate | Trigger remains expanded | ArrowUp/Down wrap; Home/End jump |
| Select | Requests closed state | Item callbacks run; focus returns to trigger |
| Dismiss | Requests closed state | Escape/outside press dismiss; focus returns after Escape |
| Disabled trigger | Native disabled | Cannot open |

## Accessibility contract

- Trigger uses a native button with `aria-haspopup="menu"`, synchronized
  `aria-expanded`, and `aria-controls` while the popup exists.
- The ui-affordance label states current state first and next action second:
  `Menu closed — open …` / `Menu open — close …`.
- Popup uses `role="menu"`; action buttons use `role="menuitem"`. Disabled
  items expose both native disabled behavior and `aria-disabled`.
- ArrowUp, ArrowDown, Home, End, and Escape follow menu keyboard conventions.
  Escape restores focus to the trigger through the canonical overlay engine.

## UI density

The trigger and popup are intrinsic control surfaces, not Card/Panel wrappers.
The integration strips `Popover`'s generic content padding; the menu item parent
owns tokenized gaps and item hit-area padding. The component adds no outer
margin or page-level surface.

## Boundaries

Items are actions only. Navigation trees, nested submenus, product permissions,
confirmation policy, persistence, analytics, and toasts stay with consumers.
