import { type CSSProperties, type ReactNode } from "react";
import { ExternalLink } from "lucide-react";
import { cn } from "../../lib/cn";
import type { BadgeTone } from "./Badge";

export type DescriptionListItem = {
  id: string;
  label: ReactNode;
  value?: ReactNode;
  icon?: ReactNode;
  href?: string;
  external?: boolean;
  tone?: BadgeTone;
  meta?: ReactNode;
  hidden?: boolean;
};

export type DescriptionListProps = {
  items: DescriptionListItem[];
  ariaLabel?: string;
  emptyLabel?: ReactNode;
  density?: "compact" | "comfortable";
  columns?: 1 | 2 | 3 | "auto";
  className?: string;
};

export function DescriptionList({
  items,
  ariaLabel,
  emptyLabel = "No details available.",
  density = "comfortable",
  columns = "auto",
  className,
}: DescriptionListProps) {
  const visibleItems = items.filter((item) => !item.hidden && item.value !== null && item.value !== undefined && item.value !== "");
  const style = columns === "auto" ? undefined : ({ "--ui-description-list-columns": columns } as CSSProperties);

  return (
    <dl
      aria-label={ariaLabel}
      className={cn(
        "ui-description-list",
        `ui-description-list--${density}`,
        columns === "auto" ? "ui-description-list--auto" : "ui-description-list--fixed",
        className,
      )}
      style={style}
    >
      {visibleItems.length > 0 ? (
        visibleItems.map((item) => <FieldRow item={item} key={item.id} />)
      ) : (
        <div className="ui-description-list__empty">
          <dt className="ui-sr-only">Details</dt>
          <dd>{emptyLabel}</dd>
        </div>
      )}
    </dl>
  );
}

export function FieldRow({ item }: { item: DescriptionListItem }) {
  const content = (
    <>
      {item.icon ? <span className="ui-description-list__icon">{item.icon}</span> : null}
      <span className="ui-description-list__value-text">{item.value}</span>
      {item.external ? <ExternalLink aria-hidden="true" size={14} /> : null}
    </>
  );

  return (
    <div className={cn("ui-field-row", item.tone && `ui-field-row--${item.tone}`)}>
      <dt>{item.label}</dt>
      <dd>
        {item.href ? (
          <a href={item.href} rel={item.external ? "noreferrer" : undefined} target={item.external ? "_blank" : undefined}>
            {content}
          </a>
        ) : (
          <span>{content}</span>
        )}
        {item.meta ? <small>{item.meta}</small> : null}
      </dd>
    </div>
  );
}
