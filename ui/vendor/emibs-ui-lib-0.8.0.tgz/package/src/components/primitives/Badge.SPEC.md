# Badge

## Purpose

`Badge` is the minimal pill label: one `<span>`, one tone, whatever text you put
in it. It is the library's smallest annotation primitive — used for status
words, category tags, and inline callouts across the catalog, and composed
inside other components (`StatusStrip`'s badge variant, `WorkItemCard` badges,
`FilterDrawerPanel`'s filter-summary chips, `ThemeAuditPanel` header actions)
so those surfaces do not each re-declare pill chrome.

`Badge` and `Chip` coexist and are not interchangeable. `Chip` is the tokenized
taxonomy primitive: it has `variant`, `size`, `leading`/`trailing` slots, and
semantic adapters (`StatusChip`, `BandChip`, `ClassChip`, `ModelChip`) that map
a domain value to a tone. `Badge` has none of that — it is a flat label with a
colour, and the caller supplies the meaning as text.

## Public contract

```tsx
type BadgeTone = "neutral" | "info" | "success" | "warning" | "danger" | "accent";

function Badge(
  props: HTMLAttributes<HTMLSpanElement> & { tone?: BadgeTone },
): JSX.Element;
```

- `tone` selects the colour treatment and defaults to `"neutral"`. It is the
  only component-specific prop.
- `className` is merged ahead of nothing — `cn("ui-badge", "ui-badge--<tone>",
  className)` — so a caller's class can override the defaults by specificity or
  order.
- Every remaining `HTMLAttributes<HTMLSpanElement>` is spread onto the span,
  including `children`, `title`, `id`, `style`, `data-*`, and `aria-*`. That
  spread is how content reaches the element; there is no separate `label` prop.
- The component is not `forwardRef`, so it takes no ref.

There are no size, shape, density, or filled/outlined variants, and no
leading/trailing icon slots. `BadgeTone` is exported and is reused by
`StatusStrip` and `WorkItemCard` for their own tone props.

## Variants and states matrix

| Tone | Foreground | Background | Border |
| --- | --- | --- | --- |
| `neutral` (default) | `var(--text-muted)` | `var(--surface-muted)` | `var(--border)` |
| `info` | `#1d4ed8` | `#dbeafe` | `#bfdbfe` |
| `success` | `#166534` | `#dcfce7` | `#bbf7d0` |
| `warning` | `#854d0e` | `#fef3c7` | `#fde68a` |
| `danger` | `#9a3412` | `#ffedd5` | `#fed7aa` |
| `accent` | `#115e59` | `#ccfbf1` | `#99f6e4` |

Shared chrome for every tone: `inline-flex`, `width: fit-content`,
`min-height: 24px`, `border-radius: 999px`, `padding: 2px 9px`, `font-size:
0.78rem`, `font-weight: 740`.

There is no hover, focus, active, disabled, or selected state — the badge is
static in every respect.

## Accessibility

- A badge is a plain `<span>` with no role and no ARIA of its own. It is
  content, not a control or a status region.
- The visible text is the entire meaning. Tone is supplementary decoration and
  is never the only signal — a caller that renders a coloured badge with no
  text conveys nothing to assistive technology, and nothing in the component
  prevents that.
- Because it is not a live region, changing a badge's text will not be
  announced. Wrap it in a `role="status"` region, or use `SignalDot` /
  `StatusIndicator`, when a change needs to be heard.
- Badges are non-interactive and have no focus styling. A clickable or
  removable badge must be a real `<button>` or `<a>` that composes a badge as
  its visible content — do not attach `onClick` to the span.
- `aria-*` attributes pass through the spread, so a caller can add
  `aria-label`, `aria-hidden`, or `title` where the text alone is not enough.

## Theming

Only the **neutral** tone is tokenized (`--text-muted`, `--surface-muted`,
`--border`). The other five tones are written as literal hex values in
`styles.css` with no custom-property indirection and no
`[data-theme]`/dark-mode override.

The practical consequence: a themed or dark surface re-tints a neutral badge but
leaves info / success / warning / danger / accent badges on their fixed light
pastel backgrounds. This is the primitive's main theming gap — components that
need theme-following semantic colour should use `Chip`, whose tones resolve
through the token layer.

## Density and composition

`Badge` is a bare label. It carries no outer margin, no surface wrapper, no
Card/Panel, and no shadow; it sets only its own pill padding. Parents own
sibling spacing with a tokenized `gap`. It reads no `--density-*` alias and does
not participate in `DensityScope`, so it keeps its 24px min-height in compact
layouts.

## Consumer / product boundary

The component owns pill geometry and the tone-to-colour mapping. Everything
else belongs to the consuming app:

- **Choosing the tone.** There is no status→tone policy here — no equivalent of
  `Chip`'s `statusChipTone()` or `modelChipTone()`. The caller decides that a
  given state is "warning".
- The label text, its wording, its localization, and its truncation policy.
- Any interaction: removal, filtering, navigation, tooltips.
- Data, thresholds, and derivation — nothing about the value being annotated is
  computed here.

## Known limitations

- Non-neutral tones are untokenized (see Theming) and will not follow a theme
  or dark palette.
- No size scale, no outlined variant, no icon slots, and no maximum-width or
  overflow handling: a long label simply makes a wider pill, and any truncation
  must come from the caller's `className`/`style`.
- No ref forwarding, so a badge cannot be measured or used as a positioning
  anchor without an extra wrapper element.
- The tone set is closed; adding one means editing `BadgeTone` and `styles.css`
  together.
