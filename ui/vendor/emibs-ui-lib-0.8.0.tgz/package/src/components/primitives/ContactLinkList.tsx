import { type ReactNode } from "react";
import { cn } from "../../lib/cn";
import { useDensity, type Density } from "../../theme/DensityScope";

export type ContactLinkListTone = "neutral" | "accent" | "info" | "success" | "warning" | "danger";

export type ContactLinkListItem = {
  id: string;
  label: ReactNode;
  href?: string;
  icon?: ReactNode;
  meta?: ReactNode;
  title?: string;
  external?: boolean;
  disabled?: boolean;
  tone?: ContactLinkListTone;
  onClick?: () => void;
};

export type ContactLinkListProps = {
  items: ContactLinkListItem[];
  label?: string;
  emptyLabel?: ReactNode;
  density?: Density;
  variant?: "pills" | "plain";
  align?: "start" | "end";
  className?: string;
};

export function ContactLinkList({
  items,
  label,
  emptyLabel,
  density,
  variant = "pills",
  align = "start",
  className,
}: ContactLinkListProps) {
  const resolvedDensity = useDensity(density);
  if (items.length === 0 && !emptyLabel) {
    return null;
  }
  const visibleItems = items.length > 0 ? items : [{ id: "__empty", label: emptyLabel, disabled: true }];

  return (
    <ul
      aria-label={label}
      className={cn(
        "ui-contact-link-list",
        `ui-contact-link-list--${resolvedDensity}`,
        `ui-contact-link-list--${variant}`,
        `ui-contact-link-list--${align}`,
        className
      )}
      data-id="contact-link-list"
    >
      {visibleItems.map((item) => (
        <li key={item.id}>
          <ContactLinkItem item={item} empty={items.length === 0} />
        </li>
      ))}
    </ul>
  );
}

function ContactLinkItem({ item, empty }: { item: ContactLinkListItem; empty: boolean }) {
  const className = cn(
    "ui-contact-link-list__item",
    `ui-contact-link-list__item--${item.tone ?? "neutral"}`,
    empty && "ui-contact-link-list__item--empty",
    item.disabled && "is-disabled"
  );
  const content = (
    <>
      {item.icon ? <span className="ui-contact-link-list__icon">{item.icon}</span> : null}
      <span className="ui-contact-link-list__label">{item.label}</span>
      {item.meta ? <small>{item.meta}</small> : null}
    </>
  );

  if (item.href && !item.disabled) {
    return (
      <a
        className={className}
        href={item.href}
        rel={item.external ? "noopener noreferrer" : undefined}
        target={item.external ? "_blank" : undefined}
        title={item.title}
      >
        {content}
      </a>
    );
  }

  if (item.onClick && !item.disabled) {
    return (
      <button className={className} title={item.title} type="button" onClick={item.onClick}>
        {content}
      </button>
    );
  }

  return (
    <span aria-disabled={item.disabled || undefined} className={className} title={item.title}>
      {content}
    </span>
  );
}
