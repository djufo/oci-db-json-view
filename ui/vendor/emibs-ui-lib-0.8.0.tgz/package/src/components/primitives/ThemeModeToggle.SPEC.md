# ThemeModeToggle Spec

## Purpose

Present a controlled light/dark/system theme action for headers, account menus,
toolbars, and settings surfaces without sharing theme provider state.

## Sources

- eLitua theme button in
  `/engineering/projects/elitua/ui/src/features/ThemeToggle/ThemeToggle.tsx`.
- eLitua header/account chrome where compact icon actions sit beside navigation
  and identity controls.

## Contract

- `ThemeModeToggle` renders one button for the current theme mode.
- The component accepts `mode`, optional `nextMode`, optional icons/labels, and
  `onModeChange`.
- It supports compact and comfortable density, icon-only and icon-plus-label
  presentation, and button or ghost variants.
- It provides an accessible action label and pressed state while keeping visual
  dimensions stable.

## Boundaries

- No theme context, local storage, media-query detection, localization, or app
  route behavior lives in the component.
- Consuming apps own theme resolution, allowed mode cycle, persistence,
  analytics, and translated labels.

## Review Checks

- Icon-only and labeled variants must remain stable across light, dark, and
  system states.
- Long labels must wrap without overflowing on mobile.
- Disabled controls must preserve the accessible label and avoid firing
  `onModeChange`.
