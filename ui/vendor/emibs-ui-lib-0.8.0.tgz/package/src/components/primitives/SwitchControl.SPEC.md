# SwitchControl

## Purpose

`SwitchControl` is a controlled, presentational switch row for binary settings
such as enablement, sync preferences, consent categories, and scheduler toggles.

## Source Evidence

- eLitua `ui/src/pages/account/bokun/BókunPage.tsx` repeats track/thumb toggle
  rows for integration sync settings.
- eLitua `ui/src/features/cookieConsent/CookieConsentBanner.tsx` repeats locked
  and optional preference toggles.
- Score scheduler, project, and agent settings use enabled/disabled checkbox
  rows that need a neutral switch-row primitive separate from workflow commands.

## Contract

- Renders one labeled checkbox with `role="switch"`, controlled `checked`
  state, optional description, optional status, disabled/read-only states,
  compact or comfortable density, and framed or plain variants.
- Calls `onChange(checked, event)` only when the control is not read-only.
- Styling uses only `ui-switch-control*` classes and shared token variables.
- When the controlled `checked` value changes after initial render, the track
  gives a brief direction-specific pulse while the thumb moves. This confirms
  both enable and disable actions without adding a persistent status surface;
  `prefers-reduced-motion: reduce` suppresses the pulse and movement.
- `busy` marks an in-flight write. It is the same state
  `src/theme/STATES.md` rule 5 defines and `NotificationToggle` already ships —
  the library has one name for this concept, so there is no separate `pending`
  prop.
  - The control **stays focusable** and in the tab order: `busy` never reaches
    the native `disabled` attribute, so a keyboard user does not lose the switch
    at the moment they activate it.
  - It announces `aria-busy="true"` on the input for the duration.
  - Re-entry is blocked in the change handler instead, so a change event while
    busy emits **nothing** through `onChange`.
  - The thumb rests at the **midpoint** of its travel rather than at either end,
    because the outcome is not yet known — parking it at the requested end would
    assert a result the write has not returned.
  - Per rule 4 (`disabled` > `readonly` > `busy`), `disabled` and `readOnly`
    outrank `busy`: when either is set the busy treatment — the
    `--state-busy-opacity` dim, the track pulse and the midpoint thumb — is
    withheld. The component decides this and simply does not emit `is-busy` or
    `data-busy`, so the stylesheet never has to re-derive the ordering.
    `aria-busy` still reflects the raw prop, matching `NotificationToggle`: it is
    a truthful claim that a write is in flight, which is independent of whether
    the control is currently interactive.
  - **Failure-revert is the consumer's, by construction.** The component holds no
    internal checked state, so when an async write fails the consumer keeps the
    previous `checked` value and drops `busy`, and the control lands back exactly
    where it started. No internal state, no rollback path, nothing to get out of
    sync with the caller's store.
- `--motion-switch` (default `280ms`) is the switch's motion-duration token. The
  on/off pulses use it directly and the busy loop derives from it, so one hook
  retunes every switch animation together. Under
  `prefers-reduced-motion: reduce` the busy pulse is suppressed while the dim and
  the midpoint position remain — they carry the meaning; only the motion is
  decoration.

## Non-Goals

- No settings persistence, API calls, provider sync behavior, consent policy,
  scheduler authorization, or local storage behavior lives in the component.

## Review Expectations

- Long labels/descriptions must wrap without shifting the switch off-screen.
- Disabled, read-only, busy, checked, unchecked, compact, framed, and plain
  states must be visible in the catalog before app adoption.
- A review must confirm `busy` never sets `disabled`: the regression it guards
  against is the busy control dropping out of the tab order.

## Field contract (issue-564)

Brought under the shared FieldControl contract, **additively and back-compat**
(no existing prop removed):

- `error` — validation message; sets `aria-invalid` on the control and renders a
  `role="alert"` message wired via `aria-describedby`.
- `required` — renders a Required affordance and sets `aria-required` + the native
  `required` attribute.
- `hint` — supplementary help text below the row (in addition to `description`).
