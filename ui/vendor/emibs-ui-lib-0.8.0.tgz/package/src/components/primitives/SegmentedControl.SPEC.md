# SegmentedControl

## Purpose

`SegmentedControl` is a presentational single-choice control for compact
utility choices such as language, theme, view mode, or display density. It keeps
the repeated segmented button grammar reusable without owning translations,
theme providers, route state, local storage, or domain-specific dispatch.

## Source Evidence

- eLitua `ui/src/features/LanguageSwitcher/LanguageSwitcher.tsx` provides a
  language segmented button group wired to `react-i18next`.
- eLitua `ui/src/features/ThemeToggle/ThemeToggle.tsx` provides compact
  light/dark utility switching wired to the theme provider.
- eLitua `ui/src/features/ViewSwitcher/ViewSwitcher.tsx` and
  `ui/src/features/PageSidebar/PageSidebar.tsx` provide map/table/card mode
  switching inside entity explorer sidebars.

## Contract

- Accepts controlled `value`, `options`, `ariaLabel`, and optional
  `onValueChange`.
- Renders a radiogroup with radio-style buttons and disabled option support.
- Supports compact/icon-only and comfortable label modes.
- Uses only `ui-segmented-control*` CSS classes and shared token variables.

## Non-Goals

- No i18n calls, theme mutation, route updates, local-storage persistence,
  entity view dispatch, analytics, or product-specific icon selection.
