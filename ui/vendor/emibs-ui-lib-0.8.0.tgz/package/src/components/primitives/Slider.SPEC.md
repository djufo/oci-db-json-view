# Slider

## Purpose

`Slider` is the dependency-free Material-style primitive for choosing one
numeric value from a bounded interval. It keeps the browser's native range
input semantics and keyboard behavior while standardizing token styling,
visible value output, disabled state, and an explicitly non-editable state.

## Public API

- `label` and controlled `value` are required.
- `min`, `max`, and `step` default to `0`, `100`, and `1` and are forwarded to
  the native `input[type="range"]`.
- `onValueChange(value, event)` reports native changes; the consumer owns the
  value and all domain validation or persistence.
- `showValue` controls the adjacent `<output>`. `formatValue` changes only that
  display; the native numeric value remains authoritative.
- Native input attributes such as `name`, `form`, `aria-describedby`,
  `aria-valuetext`, and `required` pass through.

## Variants and states matrix

| State | Native behavior | Visual/value behavior |
| --- | --- | --- |
| Default | Pointer and range keyboard keys edit | Accent progress and thumb; value output shown |
| Hidden value | Same as default | `showValue=false` removes only the visual output |
| Read-only | Remains focusable; mutation keys/pointer edits are suppressed | `aria-readonly=true`; value remains visible |
| Disabled | Native `disabled` removes interaction and tab stop | Disabled opacity and cursor |
| Custom bounds/step | Native range clamps and steps | Progress is clamped to the supplied interval |

## Accessibility contract

- The visible `<label>` is programmatically bound to the native range input.
- The input preserves native Arrow, Page Up/Down, Home, and End behavior unless
  explicitly read-only; do not replace it with a generic `div` slider.
- `disabled` uses the native attribute. Read-only is distinct: the input stays
  discoverable and focusable, carries `aria-readonly`, and emits no value
  callback.
- Consumers provide `aria-valuetext` when the number represents a non-obvious
  category or formatted unit.
- The focus ring uses the shared interaction-state token.

## UI density

The primitive is flat: it adds no surface, outer margin, padding, border, or
shadow. Its root owns only the gap between its own label/value row and native
control. A page or form layout owns surrounding spacing and surfaces.

## Non-goals

No multi-thumb range, marks, validation policy, persistence, unit conversion,
or product-specific scale interpretation.
