// @vitest-environment happy-dom
//
// Gaps found while migrating four product UIs onto the house style. Each one
// forced a product to write a workaround; each test pins the fix so the
// workaround stays unnecessary.
import { act, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { DataTable, type DataTableColumn } from "./data/DataTable";
import { WorkspaceShell } from "./layout/WorkspaceShell";
import { ButtonLink } from "./primitives/Button";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let container: HTMLDivElement;
let root: ReturnType<typeof createRoot>;

function render(node: ReactNode) {
  act(() => root.render(node));
}

beforeEach(() => {
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(() => {
  act(() => root.unmount());
  container.remove();
});

type Row = { id: string; name: string; size: number };
const rows: Row[] = [
  { id: "a", name: "Alpha", size: 2 },
  { id: "b", name: "Beta", size: 1 },
];

describe("DataTable", () => {
  const sortButtons = () => Array.from(container.querySelectorAll(".ui-data-table-composite__sort"));

  it("sorts every column that has a value, by default", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "name", header: "Name", accessor: (row) => row.name },
      { id: "size", header: "Size", accessor: (row) => row.size },
    ];
    render(<DataTable columns={columns} data={rows} />);
    expect(sortButtons().length).toBe(2);
  });

  it("turns sorting off for the whole table with one prop", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "name", header: "Name", accessor: (row) => row.name },
      { id: "size", header: "Size", accessor: (row) => row.size, sortable: true },
    ];
    render(<DataTable columns={columns} data={rows} sortable={false} />);
    // The table default is off; a column that opts back in still sorts.
    expect(sortButtons().map((button) => button.textContent)).toEqual(["Size"]);
  });

  it("accepts a render-only column with no accessor, and never offers to sort it", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "name", header: "Name", accessor: (row) => row.name },
      { id: "actions", header: "Actions", cell: (row) => <button type="button">Open {row.name}</button> },
    ];
    render(<DataTable columns={columns} data={rows} />);
    expect(sortButtons().map((button) => button.textContent)).toEqual(["Name"]);
    expect(Array.from(container.querySelectorAll("tbody button")).map((button) => button.textContent)).toEqual([
      "Open Alpha",
      "Open Beta",
    ]);
  });

  it("still sorts by the accessor when a column also renders a cell", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "size", header: "Size", accessor: (row) => row.size, cell: (row) => <b>{row.size} GB</b> },
    ];
    render(<DataTable columns={columns} data={rows} />);
    const cells = () => Array.from(container.querySelectorAll("tbody b")).map((cell) => cell.textContent);
    expect(cells()).toEqual(["2 GB", "1 GB"]);
    act(() => sortButtons()[0].dispatchEvent(new MouseEvent("click", { bubbles: true })));
    expect(cells()).toEqual(["1 GB", "2 GB"]);
  });

  it("renders every row when pagination was not asked for", () => {
    const many: Row[] = Array.from({ length: 37 }, (_, index) => ({ id: `r${index}`, name: `Row ${index}`, size: index }));
    const columns: DataTableColumn<Row>[] = [{ id: "name", header: "Name", accessor: (row) => row.name }];
    render(<DataTable columns={columns} data={many} />);
    // The engine's default page is 10 rows; with no pager there was no way to
    // reach rows 11 and up, so they were silently lost.
    expect(container.querySelectorAll("tbody tr").length).toBe(37);
    expect(container.querySelector(".ui-data-table-composite__pagination")).toBeNull();
  });

  it("pages when asked, and shows the control that reaches the rest", () => {
    const many: Row[] = Array.from({ length: 37 }, (_, index) => ({ id: `r${index}`, name: `Row ${index}`, size: index }));
    const columns: DataTableColumn<Row>[] = [{ id: "name", header: "Name", accessor: (row) => row.name }];
    render(<DataTable columns={columns} data={many} showPagination />);
    expect(container.querySelectorAll("tbody tr").length).toBe(10);
    expect(container.querySelector(".ui-data-table-composite__pagination")).not.toBeNull();

    // Page size is initial state, so a different size needs a fresh table.
    render(<DataTable key="p25" columns={columns} data={many} pageSize={25} showPagination />);
    expect(container.querySelectorAll("tbody tr").length).toBe(25);
  });

  it("exposes the body height limit as a prop", () => {
    const columns: DataTableColumn<Row>[] = [{ id: "name", header: "Name", accessor: (row) => row.name }];
    render(<DataTable columns={columns} data={rows} maxHeight="none" />);
    const table = container.querySelector<HTMLElement>(".ui-data-table-composite");
    expect(table?.style.getPropertyValue("--ui-table-primitive-max-height")).toBe("none");

    render(<DataTable columns={columns} data={rows} />);
    expect(
      container.querySelector<HTMLElement>(".ui-data-table-composite")?.style.getPropertyValue("--ui-table-primitive-max-height"),
    ).toBe("");
  });
});

describe("WorkspaceShell tabs", () => {
  it("hands the click event to onSelect so a router can take over navigation", () => {
    const onSelect = vi.fn((_: string, event: { preventDefault: () => void }) => event.preventDefault());
    render(
      <WorkspaceShell brand="App" tabs={[{ id: "jobs", label: "Jobs", href: "/jobs", onSelect }]}>
        <p>page</p>
      </WorkspaceShell>,
    );
    const tab = container.querySelector<HTMLAnchorElement>(".ui-workspace-shell__tab");
    const click = new MouseEvent("click", { bubbles: true, cancelable: true });
    act(() => {
      tab!.dispatchEvent(click);
    });
    expect(onSelect).toHaveBeenCalledTimes(1);
    expect(onSelect.mock.calls[0][0]).toBe("jobs");
    expect(click.defaultPrevented).toBe(true);
  });

  it("does not call onSelect for a disabled tab", () => {
    const onSelect = vi.fn();
    render(
      <WorkspaceShell brand="App" tabs={[{ id: "jobs", label: "Jobs", href: "/jobs", disabled: true, onSelect }]}>
        <p>page</p>
      </WorkspaceShell>,
    );
    act(() => {
      container.querySelector(".ui-workspace-shell__tab")!.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    });
    expect(onSelect).not.toHaveBeenCalled();
  });
});

describe("WorkspaceShell rail navigation", () => {
  const tabs = [
    { id: "jobs", label: "Jobs", href: "/jobs", icon: <i data-icon="jobs" />, active: true },
    { id: "agents", label: "Agents", href: "/agents", icon: <i data-icon="agents" /> },
    { id: "admin", label: "Admin", href: "/admin", icon: <i data-icon="admin" />, group: "footer" as const },
  ];

  it("lists sections in a rail, footer items last, with no tab row", () => {
    render(
      <WorkspaceShell brand="App" navigation="rail" tabLabel="Sections" tabs={tabs}>
        <p>page</p>
      </WorkspaceShell>,
    );
    const rail = container.querySelector("nav.ui-workspace-shell__rail");
    expect(rail?.getAttribute("aria-label")).toBe("Sections");
    expect(container.querySelector(".ui-workspace-shell__tabs")).toBeNull();
    const order = Array.from(rail!.children).map((node) =>
      node.classList.contains("ui-workspace-shell__rail-spacer") ? "<spacer>" : node.textContent,
    );
    expect(order).toEqual(["Jobs", "Agents", "<spacer>", "Admin"]);
    expect(rail?.querySelector('[aria-current="page"]')?.textContent).toBe("Jobs");
  });

  it("keeps an icon-only item named and titled by its label", () => {
    render(
      <WorkspaceShell brand="App" navigation="rail" railItems="icons" tabs={tabs}>
        <p>page</p>
      </WorkspaceShell>,
    );
    const items = Array.from(container.querySelectorAll<HTMLAnchorElement>(".ui-workspace-shell__rail-item"));
    expect(items.map((item) => item.getAttribute("aria-label"))).toEqual(["Jobs", "Agents", "Admin"]);
    expect(items.map((item) => item.title)).toEqual(["Jobs", "Agents", "Admin"]);
    // The label text is not rendered; the icon is.
    expect(items[0].textContent).toBe("");
    expect(items[0].querySelector("[data-icon=jobs]")).not.toBeNull();
  });

  it("ignores the footer group in the tab row", () => {
    render(
      <WorkspaceShell brand="App" tabs={tabs}>
        <p>page</p>
      </WorkspaceShell>,
    );
    expect(Array.from(container.querySelectorAll(".ui-workspace-shell__tab")).map((tab) => tab.textContent)).toEqual([
      "Jobs",
      "Agents",
      "Admin",
    ]);
    expect(container.querySelector(".ui-workspace-shell__rail")).toBeNull();
  });
});

describe("WorkspaceShell top bar and inspector", () => {
  it("renders an app-owned top bar in place of the default one", () => {
    render(
      <WorkspaceShell brand="Hidden brand" identity="hidden@example.org" topbar={<div data-bar="">command bar</div>}>
        <p>page</p>
      </WorkspaceShell>,
    );
    expect(container.querySelector("[data-bar]")?.textContent).toBe("command bar");
    expect(container.textContent).not.toContain("Hidden brand");
    expect(container.textContent).not.toContain("hidden@example.org");
  });

  it("adds the inspector column only while an inspector is passed", () => {
    render(
      <WorkspaceShell brand="App" inspector={<aside data-inspector="">record</aside>} navigation="rail">
        <p>page</p>
      </WorkspaceShell>,
    );
    expect(container.querySelector(".ui-workspace-shell--inspector")).not.toBeNull();
    expect(container.querySelector(".ui-workspace-shell__inspector [data-inspector]")?.textContent).toBe("record");

    render(
      <WorkspaceShell brand="App" navigation="rail">
        <p>page</p>
      </WorkspaceShell>,
    );
    expect(container.querySelector(".ui-workspace-shell--inspector")).toBeNull();
    expect(container.querySelector(".ui-workspace-shell__inspector")).toBeNull();
  });
});

describe("ButtonLink", () => {
  it("is a real link with the button's look", () => {
    render(
      <ButtonLink href="/jobs/new" size="sm" variant="secondary">
        New job
      </ButtonLink>,
    );
    const link = container.querySelector("a");
    expect(link?.getAttribute("href")).toBe("/jobs/new");
    expect(link?.textContent).toBe("New job");
    for (const name of ["ui-button", "ui-button--secondary", "ui-button--sm", "ui-button--link"]) {
      expect(link?.classList.contains(name), name).toBe(true);
    }
    expect(container.querySelector("button")).toBeNull();
  });
});
