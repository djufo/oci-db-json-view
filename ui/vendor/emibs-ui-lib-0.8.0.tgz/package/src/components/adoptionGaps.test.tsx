// @vitest-environment happy-dom
//
// Gaps found while migrating four product UIs onto the house style. Each one
// forced a product to write a workaround; each test pins the fix so the
// workaround stays unnecessary.
import { act, type ReactNode } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { DataTable, type DataTableColumn } from "./data/DataTable";
import { WorkspaceShell } from "./layout/WorkspaceShell";
import { ButtonLink } from "./primitives/Button";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let container: HTMLDivElement;
let root: ReturnType<typeof createRoot>;

function render(node: ReactNode) {
  act(() => root.render(node));
}

beforeEach(() => {
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(() => {
  act(() => root.unmount());
  container.remove();
});

type Row = { id: string; name: string; size: number };
const rows: Row[] = [
  { id: "a", name: "Alpha", size: 2 },
  { id: "b", name: "Beta", size: 1 },
];

describe("DataTable", () => {
  const sortButtons = () => Array.from(container.querySelectorAll(".ui-data-table-composite__sort"));

  it("sorts every column that has a value, by default", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "name", header: "Name", accessor: (row) => row.name },
      { id: "size", header: "Size", accessor: (row) => row.size },
    ];
    render(<DataTable columns={columns} data={rows} />);
    expect(sortButtons().length).toBe(2);
  });

  it("turns sorting off for the whole table with one prop", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "name", header: "Name", accessor: (row) => row.name },
      { id: "size", header: "Size", accessor: (row) => row.size, sortable: true },
    ];
    render(<DataTable columns={columns} data={rows} sortable={false} />);
    // The table default is off; a column that opts back in still sorts.
    expect(sortButtons().map((button) => button.textContent)).toEqual(["Size"]);
  });

  it("accepts a render-only column with no accessor, and never offers to sort it", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "name", header: "Name", accessor: (row) => row.name },
      { id: "actions", header: "Actions", cell: (row) => <button type="button">Open {row.name}</button> },
    ];
    render(<DataTable columns={columns} data={rows} />);
    expect(sortButtons().map((button) => button.textContent)).toEqual(["Name"]);
    expect(Array.from(container.querySelectorAll("tbody button")).map((button) => button.textContent)).toEqual([
      "Open Alpha",
      "Open Beta",
    ]);
  });

  it("still sorts by the accessor when a column also renders a cell", () => {
    const columns: DataTableColumn<Row>[] = [
      { id: "size", header: "Size", accessor: (row) => row.size, cell: (row) => <b>{row.size} GB</b> },
    ];
    render(<DataTable columns={columns} data={rows} />);
    const cells = () => Array.from(container.querySelectorAll("tbody b")).map((cell) => cell.textContent);
    expect(cells()).toEqual(["2 GB", "1 GB"]);
    act(() => sortButtons()[0].dispatchEvent(new MouseEvent("click", { bubbles: true })));
    expect(cells()).toEqual(["1 GB", "2 GB"]);
  });

  it("exposes the body height limit as a prop", () => {
    const columns: DataTableColumn<Row>[] = [{ id: "name", header: "Name", accessor: (row) => row.name }];
    render(<DataTable columns={columns} data={rows} maxHeight="none" />);
    const table = container.querySelector<HTMLElement>(".ui-data-table-composite");
    expect(table?.style.getPropertyValue("--ui-table-primitive-max-height")).toBe("none");

    render(<DataTable columns={columns} data={rows} />);
    expect(
      container.querySelector<HTMLElement>(".ui-data-table-composite")?.style.getPropertyValue("--ui-table-primitive-max-height"),
    ).toBe("");
  });
});

describe("WorkspaceShell tabs", () => {
  it("hands the click event to onSelect so a router can take over navigation", () => {
    const onSelect = vi.fn((_: string, event: { preventDefault: () => void }) => event.preventDefault());
    render(
      <WorkspaceShell brand="App" tabs={[{ id: "jobs", label: "Jobs", href: "/jobs", onSelect }]}>
        <p>page</p>
      </WorkspaceShell>,
    );
    const tab = container.querySelector<HTMLAnchorElement>(".ui-workspace-shell__tab");
    const click = new MouseEvent("click", { bubbles: true, cancelable: true });
    act(() => {
      tab!.dispatchEvent(click);
    });
    expect(onSelect).toHaveBeenCalledTimes(1);
    expect(onSelect.mock.calls[0][0]).toBe("jobs");
    expect(click.defaultPrevented).toBe(true);
  });

  it("does not call onSelect for a disabled tab", () => {
    const onSelect = vi.fn();
    render(
      <WorkspaceShell brand="App" tabs={[{ id: "jobs", label: "Jobs", href: "/jobs", disabled: true, onSelect }]}>
        <p>page</p>
      </WorkspaceShell>,
    );
    act(() => {
      container.querySelector(".ui-workspace-shell__tab")!.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    });
    expect(onSelect).not.toHaveBeenCalled();
  });
});

describe("ButtonLink", () => {
  it("is a real link with the button's look", () => {
    render(
      <ButtonLink href="/jobs/new" size="sm" variant="secondary">
        New job
      </ButtonLink>,
    );
    const link = container.querySelector("a");
    expect(link?.getAttribute("href")).toBe("/jobs/new");
    expect(link?.textContent).toBe("New job");
    for (const name of ["ui-button", "ui-button--secondary", "ui-button--sm", "ui-button--link"]) {
      expect(link?.classList.contains(name), name).toBe(true);
    }
    expect(container.querySelector("button")).toBeNull();
  });
});
