import { readFileSync } from "node:fs";
import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { DataTable, type DataTableColumn } from "./data/DataTable";
import { DataStatePanel } from "./feedback/DataStatePanel";
import { LoadingState } from "./feedback/LoadingState";
import { SectionCard } from "./layout/SectionCard";
import { DescriptionList } from "./primitives/DescriptionList";

type Row = { id: string; name: string; points: number };

const columns: DataTableColumn<Row>[] = [
  { id: "name", header: "Name", accessor: (row) => row.name, rowHeader: true },
  { id: "points", header: "Points", accessor: (row) => row.points },
];

describe("UIF-E4 canonical composites", () => {
  it("renders DataTable through the table primitive and a DataStatePanel empty preset", () => {
    const ready = renderToStaticMarkup(
      createElement(DataTable<Row>, {
        ariaLabel: "Jobs",
        columns,
        data: [{ id: "a", name: "Alpha", points: 3 }],
        getRowId: (row) => row.id,
      }),
    );
    const empty = renderToStaticMarkup(
      createElement(DataTable<Row>, {
        ariaLabel: "Jobs",
        columns,
        data: [],
        getRowId: (row) => row.id,
      }),
    );

    expect(ready).toContain('data-id="table-primitive"');
    expect(ready).toContain('scope="row"');
    expect(empty).toContain("ui-data-state--empty");
  });

  it("keeps the densest SectionCard and DescriptionList composition at one surface depth", () => {
    const markup = renderToStaticMarkup(
      <SectionCard title="Runtime settings" footer={<span>Saved locally</span>}>
        <DescriptionList
          density="compact"
          items={[
            { id: "owner", label: "Owner", value: "Codex" },
            { id: "status", label: "Status", value: "Ready" },
          ]}
        />
      </SectionCard>,
    );

    expect(markup.match(/class="ui-section-card(?:\s|")/g)).toHaveLength(1);
    expect(markup.match(/ui-field-row/g)).toHaveLength(2);
    expect(markup).toContain("Saved locally");
  });

  it("renders every description fact through the flat FieldRow", () => {
    const markup = renderToStaticMarkup(
      <DescriptionList items={[{ id: "owner", label: "Owner", value: "Codex" }]} />,
    );

    expect(markup).toContain("ui-field-row");
    expect(markup).not.toContain("ui-field-row--cards");
  });

  it("uses one status announcement for decorative loading skeletons", () => {
    const markup = renderToStaticMarkup(
      <LoadingState title="Loading jobs" description="Fetching the latest records." />,
    );

    expect(markup).toContain('aria-busy="true"');
    expect(markup).toContain('role="status"');
    expect(markup).toContain('aria-hidden="true"');
    expect(markup).toContain("ui-skeleton");
    expect(markup).toContain("ui-data-state--loading");
  });

  it("keeps DataStatePanel available as the shared state owner", () => {
    const markup = renderToStaticMarkup(<DataStatePanel title="Ready" tone="success" />);
    expect(markup).toContain("ui-data-state--success");
  });

  it("keeps DataStatePanel flat and leaves surface chrome to the demos", () => {
    const css = readFileSync(new URL("../styles.css", import.meta.url), "utf8");
    const rootBlock = css.match(/\.ui-data-state \{([\s\S]*?)\}\n\n\.ui-data-state--comfortable/s)?.[1] ?? "";

    expect(css).toMatch(/\.ui-data-state \{\n  min-width: 0;\n  display: grid;\n  color: var\(--text\);\n\}/);
    expect(css).toMatch(/\.ui-data-state--comfortable \{\n  justify-items: center;\n  gap: var\(--space-4\);\n  text-align: center;\n\}/);
    expect(css).toMatch(/\.ui-data-state--compact \{\n  grid-template-columns: auto minmax\(0, 1fr\) auto;\n  align-items: center;\n  justify-items: stretch;\n  gap: var\(--space-3\) var\(--space-3\);\n  text-align: left;\n\}/);
    expect(rootBlock).not.toContain("border:");
    expect(rootBlock).not.toContain("padding:");
    expect(rootBlock).not.toContain("background:");
    expect(rootBlock).not.toContain("box-shadow:");
  });
});
