# PaymentAccountPanel Spec

## Goal

Provide a presentational payment account surface for checkout review, saved
methods, customer payment history, provider payout history, and account-level
payment metrics.

## Source Pressure

- eLitua payment work already has separate local `CheckoutForm`, `SavedCards`,
  `PaymentHistory`, and `PayoutDashboard` components.
- Those components share a larger account/billing workspace shape: balance
  summary, saved method list, checkout action area, transaction ledger, payout
  ledger, status pills, and empty/error-ready states.

## Contract

- `PaymentAccountPanel` renders a page-level payment account shell with title,
  summary, metric cards, saved methods, optional checkout slot, payment rows,
  and payout rows.
- Consumers pass preformatted amounts, dates, descriptions, status labels, and
  action slots.
- `PaymentMethodList` and `PaymentLedgerTable` expose the repeated subpatterns
  for review and later composition.
- Styling uses catalog tokens and avoids Stripe, eLitua, or Score class names.
- Sub-panel heading ids are generated per instance with `useId`, so two billing
  panels on one page keep their own `aria-labelledby` wiring.

## Non-Goals

- No Stripe Elements integration, payment confirmation, card tokenization,
  persistence, webhook handling, invoice generation, currency conversion, or
  refund business rules.
- No formatting assumptions for money or dates.

## Review Expectations

- Payment methods and ledger tables must remain readable on mobile.
- Checkout and provider payout panels must compose in the same surface without
  requiring a product API or payment SDK.
