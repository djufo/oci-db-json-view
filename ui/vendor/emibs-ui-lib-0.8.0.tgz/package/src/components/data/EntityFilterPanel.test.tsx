import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { EntityFilterPanel, type EntityFilterControl } from "./EntityFilterPanel";

const CONTROLS: EntityFilterControl[] = [
  { id: "q", kind: "text", label: "Search", value: "" },
];

describe("EntityFilterPanel clear affordance", () => {
  it("shows the clear control when only onClear is supplied", () => {
    const html = renderToStaticMarkup(<EntityFilterPanel controls={CONTROLS} onClear={() => undefined} />);
    expect(html).toContain("ui-entity-filter__clear");
    expect(html).not.toContain("ui-entity-filter__clear is-hidden");
    expect(html).not.toContain("is-hidden");
  });

  it("still honours an explicit clearVisible={false}", () => {
    const html = renderToStaticMarkup(
      <EntityFilterPanel clearVisible={false} controls={CONTROLS} onClear={() => undefined} />,
    );
    expect(html).toContain("is-hidden");
  });

  it("renders no clear control at all without onClear", () => {
    const html = renderToStaticMarkup(<EntityFilterPanel controls={CONTROLS} />);
    expect(html).not.toContain("ui-entity-filter__clear");
  });
});
