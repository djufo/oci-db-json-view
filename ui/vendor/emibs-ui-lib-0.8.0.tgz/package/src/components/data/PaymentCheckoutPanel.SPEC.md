# PaymentCheckoutPanel Spec

## Purpose

`PaymentCheckoutPanel` is a presentational checkout form shell for payment flows
that need a reviewable amount summary, an opaque payment-provider control slot,
error messaging, submit state, and footer/action copy without sharing payment
SDK behavior.

## Source Evidence

- eLitua `ui/src/emibs-lib/entities/payments/components/CheckoutForm.tsx`
  renders the repeated checkout shape around Stripe Elements: total amount,
  provider element, transient error message, and processing-aware submit button.
- `PaymentAccountPanel` already captures the larger billing/account workspace,
  but its checkout area was only an untyped slot. This extraction captures the
  smaller reusable checkout chrome inside that slot.

## Existing Coverage Check

- Page shells and account billing layout are already represented by
  `PaymentAccountPanel`, `PortalShell`, `PortalHeader`, `PortalFooter`,
  `PortalMobileNavigation`, and related route panels.
- Saved cards, payment history, provider payouts, and summary metrics remain
  represented by `PaymentAccountPanel`, `PaymentMethodList`, and
  `PaymentLedgerTable`.
- Form primitives such as `TextInputControl`, `NumberInputControl`, and
  `SelectControl` do not cover provider SDK slots or checkout submit state.

## Contract

- Renders a controlled form shell with optional title, eyebrow, description,
  icon, actions, footer, error, processing state, and disabled state.
- Renders a caller-formatted amount value and optional amount detail. The
  component performs no money formatting.
- Renders `providerSlot` as opaque React content. Products own Stripe Elements,
  wallet buttons, 3D Secure flows, SDK loading, consent, and provider DOM.
- Emits native form submission through `onSubmit`. Products own validation,
  payment confirmation, success/error handling, routing, localization,
  analytics, persistence, and security-sensitive behavior.

## Non-Goals

- No Stripe, Bókun, PayPal, card tokenization, payment-intent confirmation,
  redirect handling, webhook logic, saved-method mutation, currency conversion,
  invoice/refund behavior, or amount/date formatting.
- No replacement for the larger `PaymentAccountPanel` billing workspace.

## Review Checks

- Provider slot, long amounts, error messages, and submit/action rows remain
  readable on mobile.
- Processing and disabled states prevent duplicate submit actions visually and
  semantically.
- Error text is exposed with `role="alert"`.
