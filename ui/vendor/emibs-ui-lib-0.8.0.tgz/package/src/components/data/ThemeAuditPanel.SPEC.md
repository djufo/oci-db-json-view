# ThemeAuditPanel

## Purpose

`ThemeAuditPanel` is a presentational review surface for theme-token coverage,
token group listings, hardcoded value gaps, and handoff notes before a shared UI
component is adopted into a product app.

## Source Evidence

- Score `ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  renders `ThemeAuditPanel` locally for each catalog fixture.
- The source panel groups consumed Score theme tokens, reports token coverage,
  lists hardcoded-value gaps, and shows review notes next to component previews.

## Contract

- Accepts caller-computed metrics, token groups, gap rows, notes, and actions.
- Renders theme-token groups and hardcoded-value gaps without reading app theme
  state or calculating product-specific coverage.
- Empty token and gap labels are controlled by props so consuming apps can keep
  their audit language local.
- Uses `ui-theme-audit*` CSS classes and shared token variables only.

## Non-Goals

- No token scanning, CSS parsing, theme generation, hardcoded-value detection,
  registry loading, route synchronization, persistence, analytics, or adoption
  workflow.
- No assumption that the token vocabulary is Score, eLitua, Tailwind, or
  shadcn-specific; consuming apps supply already-normalized audit data.
