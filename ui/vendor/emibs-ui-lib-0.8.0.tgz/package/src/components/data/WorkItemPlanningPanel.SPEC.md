# WorkItemPlanningPanel

## Goal

Provide a presentational planning and triage panel for Score-style work items:
metadata editing, route fields, automation eligibility, and triage enrichment.

## Source Pressure

- Score `ui/src/features/board/components/TaskDetail.tsx` keeps separate
  `TaskEditForm` and `TriageForm` sections inside the larger task detail page.
- Larger detail, document, media, confirmation, and creation surfaces are already
  represented in the catalog, leaving work-item planning controls as the next
  reusable Score pattern.

## Contract

- `WorkItemPlanningPanel` renders controlled fields and emits field changes,
  save, cancel, and triage callbacks.
- Consumers own route parsing, project/epic validation, task DTO mapping,
  workflow permissions, persistence, toasts, and audit behavior.
- Native controls and datalists keep the component framework-neutral for later
  adoption by Score or other operator apps.
- Combobox field ids are generated per instance with `useId`, so two planning
  panels on one page keep their own `htmlFor` and datalist wiring.

## Non-Goals

- No Score API calls, workflow transition rules, actor lookup, epic validation,
  branch/PR handling, or task detail/document/attachment rendering.

## Review Expectations

- The metadata form and triage form must sit side by side on desktop and stack
  cleanly on narrow screens.
- Long titles, actor ids, epic ids, and notes must not overflow their panels.
