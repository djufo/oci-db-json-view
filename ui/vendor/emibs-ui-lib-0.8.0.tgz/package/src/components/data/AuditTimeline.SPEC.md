# AuditTimeline

## Purpose

`AuditTimeline` is the timeline atom behind every audit / delivery-record rail: a
vertically-aligned run of typed entries, each with a state-coloured tick dot, a
mono actor, and a left-aligned time column so the sequence reads as a spine.

## Source Evidence

- Score `requirements/v4/ui` (SPEC G2 Audit tab, V4-3 delivery record): the
  inspector's Audit tab and the task page interleave typed dispositions,
  carriers, leases and maestro actions into one reconstructable-from-server
  timeline. Score's v4 renders this inline per surface; this atom extracts the
  shared timeline shape so board / fleet / task reuse one implementation.

## Contract

- `entries: AuditEntry[]` (`{ id, time, title, actor?, tone?, kind?, detail?,
  href?, meta? }`). The caller formats `time` and reconstructs the list from
  server data; the atom owns alignment, dot semantics and the empty state.
- `tone` (`neutral`/`info`/`success`/`warning`/`danger`/`critical`/`accent`)
  colours the tick dot through the emibs-theme/2 `--severity-*` / status tokens.
  Untoned entries default to the neutral tick.
- `actor` renders in mono (`--font-mono`); `kind` is an uppercase eyebrow;
  `href` links the title.
- `time` sits in a fixed left column so ticks and connectors align down the run.
- `density` (or an ambient `DensityScope`) tightens row spacing.

## Boundaries

- No data shaping, sorting, grouping, fetching, or time formatting; it renders
  the typed entries it is given in order.
- Not a full activity dashboard (`ActivityDashboard`) or a process-run history
  table (`ProcessRunHistoryPanel`); it is the atomic vertical timeline.

## Review Checks

- Every tick carries `data-tone`, so dot colour is token-driven.
- The connector line joins ticks and stops at the last row.
- The empty state renders a note when there are no entries.
