// @vitest-environment happy-dom

import { act, createElement } from "react";
import { createRoot } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { DataTable, type DataTableColumn } from "./DataTable";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

type Row = { id: string; name: string; points: number };

const columns: DataTableColumn<Row>[] = [
  { id: "name", header: "Name", accessor: (row) => row.name, rowHeader: true },
  { id: "points", header: "Points", accessor: (row) => row.points },
];

const rows: Row[] = [
  { id: "a", name: "Alpha", points: 3 },
  { id: "b", name: "Beta", points: 1 },
];

describe("DataTable", () => {
  it("renders the explicit caller-owned search, filter, export, and selected-row action slots", () => {
    const markup = renderToStaticMarkup(
      createElement(DataTable as React.ComponentType<Record<string, unknown>>, {
        ariaLabel: "Jobs",
        columns,
        data: rows,
        getRowId: (row: Row) => row.id,
        selectionMode: "multi",
        defaultSelection: ["a"],
        searchSlot: <input aria-label="Search jobs" />,
        filterSlot: <button type="button">Filter status</button>,
        exportAction: <button type="button">Export rows</button>,
        selectedRowActions: <button type="button">Archive selected</button>,
      }),
    );

    expect(markup).toContain('aria-label="Search jobs"');
    expect(markup).toContain("Filter status");
    expect(markup).toContain("Export rows");
    expect(markup).toContain("Archive selected");
    expect(markup).toContain('role="toolbar"');
  });

  it("keeps controlled canonical sort state synchronized with the state-first label", () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    const onSortChange = vi.fn();

    try {
      act(() => {
        root.render(
          createElement(DataTable<Row>, {
            ariaLabel: "Jobs",
            columns,
            data: rows,
            getRowId: (row) => row.id,
            onSortChange,
            sort: { columnId: "name", direction: "asc" },
          }),
        );
      });

      const sort = container.querySelector<HTMLButtonElement>(".ui-data-table-composite__sort");
      expect(sort?.getAttribute("aria-label")).toBe("Sort Name: ascending — Sort descending");
      act(() => sort?.click());
      expect(onSortChange).toHaveBeenCalledWith({ columnId: "name", direction: "desc" });
    } finally {
      act(() => root.unmount());
      container.remove();
    }
  });

  it("updates uncontrolled sort labels and rows after a sort interaction", () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);

    try {
      act(() => {
        root.render(
          createElement(DataTable<Row>, {
            ariaLabel: "Jobs",
            columns,
            data: rows,
            getRowId: (row) => row.id,
          }),
        );
      });

      const sort = Array.from(container.querySelectorAll<HTMLButtonElement>(".ui-data-table-composite__sort"))
        .find((button) => button.textContent?.includes("Points"));
      expect(sort?.getAttribute("aria-label")).toBe("Sort Points: not sorted — Sort ascending");
      act(() => sort?.click());
      expect(sort?.getAttribute("aria-label")).toBe("Sort Points: ascending — Sort descending");
      expect(Array.from(container.querySelectorAll("tbody tr")).map((row) => row.textContent)).toEqual([
        "Beta1",
        "Alpha3",
      ]);
    } finally {
      act(() => root.unmount());
      container.remove();
    }
  });

  it("derives selected rows for bulk-action slots after an uncontrolled selection change", () => {
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);

    try {
      act(() => {
        root.render(
          createElement(DataTable<Row>, {
            ariaLabel: "Jobs",
            columns,
            data: rows,
            getRowId: (row) => row.id,
            selectionMode: "multi",
            selectedRowActions: ({ selectedRows }) => <span>{selectedRows.length} rows selected</span>,
          }),
        );
      });

      expect(container.textContent).not.toContain("rows selected");
      const rowSelection = container.querySelectorAll<HTMLInputElement>('input[type="checkbox"]')[1];
      act(() => rowSelection?.click());
      expect(container.textContent).toContain("1 rows selected");
      expect(rowSelection?.getAttribute("aria-label")).toBe("Row 1: selected — Deselect row");
    } finally {
      act(() => root.unmount());
      container.remove();
    }
  });

  it("follows showPagination changes on rerender in both directions", () => {
    const many: Row[] = Array.from({ length: 37 }, (_, index) => ({ id: `r${index}`, name: `Row ${index}`, points: index }));
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    const render = (showPagination: boolean) => act(() => {
      root.render(createElement(DataTable<Row>, { ariaLabel: "Many", columns, data: many, getRowId: (row) => row.id, showPagination }));
    });
    const bodyRows = () => container.querySelectorAll("tbody tr").length;

    try {
      render(true);
      expect(bodyRows()).toBe(10);
      render(false);
      expect(bodyRows()).toBe(37);
      expect(container.querySelector("nav")).toBeNull();
      render(true);
      expect(bodyRows()).toBe(10);
    } finally {
      act(() => root.unmount());
      container.remove();
    }
  });

  it("renders every row when started unpaginated and then paginated", () => {
    const many: Row[] = Array.from({ length: 37 }, (_, index) => ({ id: `r${index}`, name: `Row ${index}`, points: index }));
    const container = document.createElement("div");
    document.body.append(container);
    const root = createRoot(container);
    try {
      act(() => { root.render(createElement(DataTable<Row>, { ariaLabel: "Many", columns, data: many, getRowId: (row) => row.id })); });
      expect(container.querySelectorAll("tbody tr").length).toBe(37);
      act(() => { root.render(createElement(DataTable<Row>, { ariaLabel: "Many", columns, data: many, getRowId: (row) => row.id, showPagination: true })); });
      expect(container.querySelectorAll("tbody tr").length).toBe(10);
    } finally {
      act(() => root.unmount());
      container.remove();
    }
  });
});
