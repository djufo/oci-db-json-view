# DataTable

`DataTable` is the sole table composite. It derives client sort, pagination and
selection through `useDataTable`, renders rows exclusively through
`TablePrimitive`, accepts caller-owned controls through `Toolbar`, and delegates
loading, empty and error states to `DataStatePanel`.

It is flat: pages own any surrounding section surface. `searchSlot`,
`filterSlot`, `exportAction`, and `selectedRowActions` are opaque caller-owned
toolbar slots. The bulk-action function receives the selected ids, selected
rows, and a clear-selection callback; it appears only when a row is selected.
Fetching, server pagination, filter schemas, CSV serialization, routes, and
persistence remain consumer-owned.

## State contract

- Client sort, pagination, and selection are controlled or uncontrolled through
  `useDataTable`; `DataTable` only adapts those results into `TablePrimitive`.
- Columns use the canonical headless `ColumnDef` contract. Retired static and
  per-column controlled adapters are forbidden; server pagination remains
  caller-owned outside this component.
- `TablePrimitive` remains the only native `<table>` renderer. Loading, empty,
  and error states are always rendered by `DataStatePanel`.
- A column sorts when it has a value to sort by (`accessor` or `compare`) and
  has not opted out. `sortable` on the table sets the default for its columns
  (true unless passed); a column's own `sortable` overrides it. A column with a
  `cell` and no `accessor` only renders, and is never sortable.
- The table paginates only when asked: `showPagination`, or any of
  `pagination`, `defaultPagination`, `pageSize`, `onPaginationChange`. With
  none of them it renders every row. It must never render a subset of the rows
  without a control that reaches the rest.
- `maxHeight` sets the height limit of the scrolling body as a CSS length;
  `"none"` lets the table grow with its rows so the page scrolls instead.

## Accessibility

- Captions or an accessible table label name the table.
- Sort labels state the current order and next action.
- Selection labels state current selection before the next action.
- Row headers use `scope="row"`; non-ready states use the shared live semantics.
