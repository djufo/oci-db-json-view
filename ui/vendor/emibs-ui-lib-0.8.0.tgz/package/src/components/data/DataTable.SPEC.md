# DataTable

`DataTable` is the sole table composite. It derives client sort, pagination and
selection through `useDataTable`, renders rows exclusively through
`TablePrimitive`, accepts caller-owned controls through `Toolbar`, and delegates
loading, empty and error states to `DataStatePanel`.

It is flat: pages own any surrounding section surface. `searchSlot`,
`filterSlot`, `exportAction`, and `selectedRowActions` are opaque caller-owned
toolbar slots. The bulk-action function receives the selected ids, selected
rows, and a clear-selection callback; it appears only when a row is selected.
Fetching, server pagination, filter schemas, CSV serialization, routes, and
persistence remain consumer-owned.

## State contract

- Client sort, pagination, and selection are controlled or uncontrolled through
  `useDataTable`; `DataTable` only adapts those results into `TablePrimitive`.
- Columns use the canonical headless `ColumnDef` contract. Retired static and
  per-column controlled adapters are forbidden; server pagination remains
  caller-owned outside this component.
- `TablePrimitive` remains the only native `<table>` renderer. Loading, empty,
  and error states are always rendered by `DataStatePanel`.

## Accessibility

- Captions or an accessible table label name the table.
- Sort labels state the current order and next action.
- Selection labels state current selection before the next action.
- Row headers use `scope="row"`; non-ready states use the shared live semantics.
