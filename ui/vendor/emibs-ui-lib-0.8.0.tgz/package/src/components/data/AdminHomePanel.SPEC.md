# AdminHomePanel

## Purpose

`AdminHomePanel` is a presentational admin landing surface for products that
need a role or operator home page with status chrome, metric cards, navigation
cards, notices, and optional detail sections.

## Source Evidence

- Score `ui/src/features/admin/components/AdminDashboard.tsx` provides the
  admin header, actor/project counts, refresh action, error state, and child
  admin section slot.
- eLitua `ui/src/pages/account/admin-profile/AdminProfilePage.tsx` provides the
  admin landing grid for users, accommodations, profiles, sessions, plus account
  summary links.

## Contract

- Accepts preformatted title, status, actions, metrics, notices, action items,
  sections, and footer props.
- Renders loading, error, empty, disabled, featured, linked, and controlled
  action states.
- Action cards render links when `href` is supplied, controlled buttons when
  `onActionSelect` is supplied, or read-only titles otherwise.
- A `disabled` action item is inert in every branch, not merely dimmed. The
  button takes the native `disabled` attribute; the link keeps its `<a>` and
  gains `role="link"` + `aria-disabled="true"` but **loses its `href`**, which
  is what removes it from the tab order and takes away its activation
  behaviour.
- Product apps own auth/session loading, route registries, RBAC, persistence,
  counts, localization, refresh behavior, and toast/error handling.
- Uses `ui-admin-home*` CSS classes and shared token variables only.

## Non-Goals

- No Score admin API client, eLitua auth service, role policy, session revoke,
  project access mutation, router adapter, or dashboard data fetching.
- No adoption into Score or eLitua in this extraction; adoption is tracked by
  separate low-priority UI Framework refactor tasks.
