import { type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { MetricGrid } from "./MetricGrid";

export type ActivityDashboardQueueItem = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
  tone?: BadgeTone;
};

export type ActivityDashboardMetric = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
  tone?: BadgeTone;
  icon?: ReactNode;
};

export type ActivityDashboardFeedItem = {
  id: string;
  title: ReactNode;
  href?: string;
  kind?: ReactNode;
  kindTone?: BadgeTone;
  status?: ReactNode;
  statusTone?: BadgeTone;
  project?: ReactNode;
  time?: ReactNode;
  meta?: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
};

export type ActivityDashboardProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  queues?: ActivityDashboardQueueItem[];
  metrics?: ActivityDashboardMetric[];
  items?: ActivityDashboardFeedItem[];
  error?: ReactNode;
  feedTitle?: ReactNode;
  queueLabel?: string;
  metricLabel?: string;
  emptyLabel?: ReactNode;
  className?: string;
};

export function ActivityDashboard({
  title,
  eyebrow,
  subtitle,
  status,
  statusTone = "neutral",
  actions,
  queues = [],
  metrics = [],
  items = [],
  error,
  feedTitle = "Recent activity",
  queueLabel = "Activity queues",
  metricLabel = "Activity metrics",
  emptyLabel = "No recent activity.",
  className,
}: ActivityDashboardProps) {
  return (
    <section className={cn("ui-activity-dashboard", className)}>
      <header className="ui-activity-dashboard__header">
        <div className="ui-activity-dashboard__title-block">
          {eyebrow ? <span className="ui-activity-dashboard__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
        <div className="ui-activity-dashboard__header-actions">
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {error ? (
        <div className="ui-activity-dashboard__error" role="alert">
          {error}
        </div>
      ) : null}

      {queues.length > 0 ? (
        <dl className="ui-activity-dashboard__queues" aria-label={queueLabel}>
          {queues.map((queue) => (
            <div className={cn("ui-activity-dashboard__queue", queue.tone && `ui-activity-dashboard__queue--${queue.tone}`)} key={queue.id}>
              <dt>{queue.label}</dt>
              <dd>{queue.value}</dd>
              {queue.detail ? <small>{queue.detail}</small> : null}
            </div>
          ))}
        </dl>
      ) : null}

      <div className="ui-activity-dashboard__body">
        <section className="ui-activity-dashboard__panel" aria-label={metricLabel}>
          <div className="ui-activity-dashboard__panel-header">
            <h3>Metrics</h3>
          </div>
          <MetricGrid
            ariaLabel={metricLabel}
            className="ui-activity-dashboard__metrics"
            emptyLabel="No metrics available."
            items={metrics}
          />
        </section>

        <section className="ui-activity-dashboard__panel ui-activity-dashboard__panel--feed">
          <div className="ui-activity-dashboard__panel-header">
            <h3>{feedTitle}</h3>
          </div>
          {items.length > 0 ? (
            <ul className="ui-activity-dashboard__feed">
              {items.map((item) => (
                <li className="ui-activity-dashboard__feed-item" key={item.id}>
                  <div className="ui-activity-dashboard__feed-main">
                    {item.icon ? <span className="ui-activity-dashboard__feed-icon">{item.icon}</span> : null}
                    <div className="ui-activity-dashboard__feed-copy">
                      <div className="ui-activity-dashboard__feed-title-row">
                        {item.kind ? <Badge tone={item.kindTone}>{item.kind}</Badge> : null}
                        {item.href ? (
                          <a className="ui-activity-dashboard__feed-title" href={item.href}>
                            {item.title}
                          </a>
                        ) : (
                          <strong className="ui-activity-dashboard__feed-title">{item.title}</strong>
                        )}
                      </div>
                      {item.description ? <p>{item.description}</p> : null}
                    </div>
                  </div>
                  <div className="ui-activity-dashboard__feed-meta">
                    {item.status ? <Badge tone={item.statusTone}>{item.status}</Badge> : null}
                    {item.project ? <span>{item.project}</span> : null}
                    {item.time ? <span>{item.time}</span> : null}
                    {item.meta ? <span>{item.meta}</span> : null}
                  </div>
                </li>
              ))}
            </ul>
          ) : (
            <p className="ui-activity-dashboard__empty">{emptyLabel}</p>
          )}
        </section>
      </div>
    </section>
  );
}
