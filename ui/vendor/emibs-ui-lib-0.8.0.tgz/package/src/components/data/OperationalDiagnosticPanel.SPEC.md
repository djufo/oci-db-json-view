# OperationalDiagnosticPanel

## Purpose

`OperationalDiagnosticPanel` is a presentational admin surface for operational
tool embeds and diagnostic results: header/status chrome, metric tiles, loading
and error states, optional iframe embed, key/value result rows, and JSON or text
payload output.

## Contract

- Accepts preformatted status, metric, detail, embed, payload, action, and
  footer props.
- Renders optional iframe embeds for product-owned diagnostic tools or database
  browsers without owning routes, authentication, query parameters, proxying, or
  resize behavior.
- Always renders the embed frame with a `sandbox` attribute and
  `referrerPolicy="no-referrer"`.

## Embed Trust Boundary

The embed frame is hostile-content-tolerant by construction, not by convention.

- **`srcDoc` is never trusted and never sanitized.** Inline markup is rendered
  with `sandbox=""` — no scripts, no same-origin, no forms, no navigation, no
  popups — and an `embed.sandbox` request is ignored on this path. Script tags
  in the markup are therefore inert, but the panel does not strip them and does
  not escape the markup, so the consuming app still owns redaction: anything it
  puts in `srcDoc` will be laid out and displayed as HTML.
- **`src` starts with zero capabilities.** Without `embed.sandbox` the frame is
  `sandbox=""`. The consuming app opts in per capability, e.g.
  `sandbox: ["allow-scripts", "allow-forms"]` for an interactive database
  browser.
- **`allow-scripts` + `allow-same-origin` is not expressible.** When both are
  requested the panel drops `allow-same-origin`, because a frame holding both
  can reach its own frame element's document and remove the sandbox attribute.
  A tool that genuinely needs same-origin script access must be embedded by the
  consuming app directly, not through this panel.
- The panel does not proxy, authenticate, validate, or same-origin-check the
  `src` URL. Choosing a URL the app trusts to be framed remains app-owned.
- Renders diagnostic payloads through `PayloadBlock` from caller-supplied text
  or React content; fetching, parsing, redaction, localization, polling,
  retries, and error mapping remain in the consuming app.
- Uses `ui-operational-diagnostic*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/app-shell/AppShell.tsx` renders the Database tab as an embedded
  `oci-db-json-view` iframe mounted inside `dbview-panel` chrome.
- eLitua `ui/src/pages/admin/TestDbPage/TestDbPage.tsx` renders a database
  diagnostic page with loading state, success/error result panel, and raw JSON
  payload output.

## Non-Goals

- No database queries, API calls, iframe source selection, auth, token handling,
  proxy configuration, polling cadence, localization, or result interpretation.
- No sanitization of `srcDoc` markup, and no framing policy for `src` URLs
  beyond the sandbox above.
- No adoption into Score or eLitua in this extraction; adoption is tracked by
  low-priority UI Framework refactor tasks.
