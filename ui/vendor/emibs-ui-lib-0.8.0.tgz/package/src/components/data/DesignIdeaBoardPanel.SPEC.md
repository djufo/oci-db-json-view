# DesignIdeaBoardPanel

## Purpose

`DesignIdeaBoardPanel` is a presentational lane board for static design ideas,
mockup porting notes, and pre-adoption review queues. It captures Score Catalog
Explorer's design-idea board without moving real workflow state into the shared
library.

## Source Evidence

- Score `ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  renders `DesignIdeaBoardMockup` as a lane-based planning fixture with summary
  metrics, target-product badges, source links, owner-boundary notes, and
  blocker chips.
- Existing `IdeaBacklogPanel` covers a project-related ideas table, not a
  cross-product lane board for mockup porting decisions.

## Contract

- Accepts controlled lane definitions, item rows, optional metrics, badges,
  header actions, source links, owner-boundary copy, blocker chips, and per-card
  action slots.
- Computes default review metrics only from supplied item props when explicit
  metrics are omitted.
- Renders labelled lane sections and visible text for priority, target product,
  source, owner boundary, and blockers.
- Keeps Score tasks, assignment, workflow state, persistence, route handling,
  comments, acceptance criteria, analytics, localization, and product delivery
  decisions in the consuming app.
- Uses `ui-design-idea-board*` CSS classes and shared token variables only.

## Non-Goals

- No Score issue API, drag/drop, status mutation, saved filters, comments,
  assignment controls, or product adoption automation.

## Review States

- Cross-product populated board, product-filtered board, empty lane, compact
  density, long blocker labels, and long owner-boundary text should remain
  readable at mobile and desktop widths.
