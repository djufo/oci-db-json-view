# EntityCard

## Purpose

`EntityCard` is a presentational record card for tourism and admin entities that
need optional media, fallback icons, title and description copy, badges, compact
metadata chips, selected/disabled state, and caller-owned actions or links.

## Source Evidence

- eLitua `ui/src/components/ui/Card.tsx` provides the local card primitive used
  across public and admin record browsing surfaces.
- eLitua `ui/src/components/ui/Card.module.scss` defines the repeated media
  aspect ratio, fallback icon area, content spacing, title/description clamp
  behavior, metadata row, badges, hover affordance, and rounded card surface.
- eLitua card view consumers such as `GuidesCardView`, `AccmsCardView`, and
  `PlacesCardView` compose the primitive into entity browser cards with images,
  meta labels, verification badges, and route actions.

## Contract

- Accepts display-ready title, subtitle, description, eyebrow, badges, tags,
  metadata, media, footer, action slots, links, and controlled select callbacks.
- Keeps entity loading, image policy, map synchronization, route generation,
  filtering, pagination, localization, analytics, and persistence in the
  consuming app.
- Preserves the original `title`, `subtitle`, `meta`, `tags`, and `action`
  props so existing emibs demos remain compatible while richer eLitua card
  states can be reviewed.
- Uses `ui-entity-card*` CSS classes and shared token variables only.

## Non-Goals

- No entity API client, record formatting, router integration, image optimizer,
  skeleton loader, moderation policy, or eLitua adoption in this extraction.
  Adoption is tracked by a separate low-priority UI Framework refactor task.
