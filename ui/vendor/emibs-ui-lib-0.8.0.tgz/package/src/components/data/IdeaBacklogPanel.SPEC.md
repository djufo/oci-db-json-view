# IdeaBacklogPanel

## Purpose

`IdeaBacklogPanel` is a presentational project-idea backlog surface for product
administration views that need a compact related-ideas table with project
context, status chips, dates, source metadata, empty/loading/error states, and
optional row actions.

## Source Evidence

- Score `ui/src/features/projects/components/IdeasList.tsx` renders the project
  ideas card: selected-project context, idea count copy, empty state, and a
  dense table with idea title, status, and created date.
- Score `ui/src/features/admin/containers/AdminContainer.tsx` mounts that list
  inside the admin dashboard as a related collection tied to the selected
  project.
- eLitua was inspected for larger unrepresented page shells and layout
  structures during this extraction. Its current public, auth, account, admin,
  map, explorer, payment, and editorial surfaces are already represented in the
  catalog, so this extraction moves one level deeper into Score's project-admin
  related-record controls.

## Contract

- Accepts preformatted title, project/context copy, status, actions, item rows,
  metadata badges, dates, source labels, descriptions, and row action slots.
- Renders no-context, loading, error, empty, and populated table states.
- Renders item links when `href` is supplied, controlled selection buttons when
  `onItemSelect` is supplied, or read-only titles otherwise.
- Keeps routing, idea lifecycle policy, project selection, API loading,
  timestamp formatting, RBAC, localization, creation/editing workflows, and
  toast handling in the consuming app.
- Uses `ui-idea-backlog*` CSS classes and shared token variables only.

## Non-Goals

- No Score ideas API client, project selector, idea creation form, bulk action
  logic, saved filters, pagination, sorting, or adoption into Score in this
  extraction. Adoption is tracked by a separate low-priority UI Framework
  refactor task.
