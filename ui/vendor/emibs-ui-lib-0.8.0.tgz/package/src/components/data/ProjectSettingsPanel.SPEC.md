# ProjectSettingsPanel Spec

## Goal

Provide a presentational settings page surface for runtime project
configuration, public config documents, and owner-facing status summary digests.

## Source Pressure

- Score `ui/src/features/settings/containers/SettingsContainer.tsx` uses one
  runtime Settings page for JSON config, summary email recipient, title
  template, status log, send-now, clear-log, loading, and save feedback.
- `/engineering/specs/patterns/project-settings.md` defines Settings as the
  shared pattern for non-source changeable values and summary digest controls.
- eLitua was inspected for a matching Settings route; it does not yet expose one,
  so this extraction is based on Score's proven surface.

## Contract

- `ProjectSettingsPanel` renders project settings header chrome, status badges,
  notices, summary stats, digest controls, a `PayloadBlock` summary log, and a
  config document editor slot.
- Consuming apps pass controlled input/editor nodes and action slots; the shared
  component does not parse JSON, validate values, send email, persist settings,
  fetch public config, or own toast behavior.
- `ProjectSettingsControl` is a label plus the caller's control node, and
  carries no `id`. The digest controls are rendered by name rather than mapped,
  so the panel needs no key and emits no id of its own; the control node the
  caller supplies owns its id and label association.
- Settings values, secrets policy, public config exposure, mail delivery,
  localization, audit events, and route guards remain product-owned.

## Non-Goals

- No schema registry, config merge logic, provider credential storage, email
  delivery, summary queue, or settings API client.
- No assumption that every app has the same settings fields beyond config
  document and status-summary digest slots.

## Review Expectations

- JSON editors, long summary lines, and action rows must stay readable at narrow
  widths without page-level horizontal overflow.
- The panel must be useful as a whole Settings route without forcing apps to
  adopt `EditableFormPanel`.
