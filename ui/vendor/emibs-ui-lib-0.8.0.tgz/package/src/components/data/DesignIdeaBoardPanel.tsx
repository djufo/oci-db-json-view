import { type ReactNode } from "react";
import { ExternalLink, Lightbulb, ListChecks } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type DesignIdeaBoardBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type DesignIdeaBoardLane = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  emptyLabel?: ReactNode;
};

export type DesignIdeaBoardMetric = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
};

export type DesignIdeaBoardItem = {
  id: string;
  title: ReactNode;
  laneId: string;
  note?: ReactNode;
  source?: ReactNode;
  sourceHref?: string;
  target?: ReactNode;
  priority?: ReactNode;
  ownerBoundary?: ReactNode;
  blockers?: ReactNode[];
  badges?: DesignIdeaBoardBadge[];
  actions?: ReactNode;
};

export type DesignIdeaBoardPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  icon?: ReactNode;
  badges?: DesignIdeaBoardBadge[];
  actions?: ReactNode;
  metrics?: DesignIdeaBoardMetric[];
  lanes: DesignIdeaBoardLane[];
  items: DesignIdeaBoardItem[];
  sourceLabel?: ReactNode;
  metricsLabel?: string;
  blockersLabel?: ReactNode;
  ownerBoundaryLabel?: ReactNode;
  emptyLaneLabel?: ReactNode;
  density?: "compact" | "comfortable";
  className?: string;
};

export function DesignIdeaBoardPanel({
  title,
  eyebrow,
  subtitle,
  icon,
  badges = [],
  actions,
  metrics,
  lanes,
  items,
  sourceLabel = "Open source",
  metricsLabel = "Design idea board summary",
  blockersLabel = "Before porting",
  ownerBoundaryLabel = "Owner boundary",
  emptyLaneLabel = "No ideas are parked in this lane.",
  density = "comfortable",
  className,
}: DesignIdeaBoardPanelProps) {
  const summaryMetrics = metrics ?? defaultMetrics(items);

  return (
    <section className={cn("ui-design-idea-board", `ui-design-idea-board--${density}`, className)} aria-label={plainLabel(title)}>
      <header className="ui-design-idea-board__header">
        <div className="ui-design-idea-board__title-row">
          <span className="ui-design-idea-board__icon" aria-hidden="true">
            {icon ?? <Lightbulb size={20} />}
          </span>
          <div className="ui-design-idea-board__title-block">
            {eyebrow ? <span className="ui-design-idea-board__eyebrow">{eyebrow}</span> : null}
            <h2>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
            {badges.length > 0 ? (
              <div className="ui-design-idea-board__badges">
                {badges.map((badge) => (
                  <Badge key={badge.id} tone={badge.tone}>
                    {badge.label}
                  </Badge>
                ))}
              </div>
            ) : null}
          </div>
        </div>
        {actions ? <div className="ui-design-idea-board__actions">{actions}</div> : null}
      </header>

      {summaryMetrics.length > 0 ? (
        <dl aria-label={metricsLabel} className="ui-design-idea-board__metrics">
          {summaryMetrics.map((metric) => (
            <div className="ui-design-idea-board__metric" key={metric.id}>
              <dt>{metric.label}</dt>
              <dd>{metric.value}</dd>
              {metric.detail ? <small>{metric.detail}</small> : null}
            </div>
          ))}
        </dl>
      ) : null}

      <div className="ui-design-idea-board__lanes">
        {lanes.map((lane) => {
          const laneItems = items.filter((item) => item.laneId === lane.id);
          return (
            <section className="ui-design-idea-board__lane" aria-labelledby={`design-idea-lane-${lane.id}`} key={lane.id}>
              <header className="ui-design-idea-board__lane-header">
                <div className="ui-design-idea-board__lane-title-row">
                  <h3 id={`design-idea-lane-${lane.id}`}>{lane.title}</h3>
                  <Badge>{laneItems.length}</Badge>
                </div>
                {lane.description ? <p>{lane.description}</p> : null}
              </header>
              {laneItems.length > 0 ? (
                <div className="ui-design-idea-board__cards">
                  {laneItems.map((item) => (
                    <DesignIdeaCard
                      blockersLabel={blockersLabel}
                      item={item}
                      key={item.id}
                      ownerBoundaryLabel={ownerBoundaryLabel}
                      sourceLabel={sourceLabel}
                    />
                  ))}
                </div>
              ) : (
                <p className="ui-design-idea-board__empty">{lane.emptyLabel ?? emptyLaneLabel}</p>
              )}
            </section>
          );
        })}
      </div>
    </section>
  );
}

function DesignIdeaCard({
  blockersLabel,
  item,
  ownerBoundaryLabel,
  sourceLabel,
}: {
  blockersLabel: ReactNode;
  item: DesignIdeaBoardItem;
  ownerBoundaryLabel: ReactNode;
  sourceLabel: ReactNode;
}) {
  const blockers = item.blockers ?? [];

  return (
    <article className="ui-design-idea-board__card">
      <header className="ui-design-idea-board__card-header">
        <div className="ui-design-idea-board__card-badges">
          {item.priority ? <Badge tone="warning">{item.priority}</Badge> : null}
          {item.target ? <Badge>{item.target}</Badge> : null}
          {item.badges?.map((badge) => (
            <Badge key={badge.id} tone={badge.tone}>
              {badge.label}
            </Badge>
          ))}
        </div>
        <div className="ui-design-idea-board__card-title">
          <h4>{item.title}</h4>
          {item.source ? <DesignIdeaSource item={item} sourceLabel={sourceLabel} /> : null}
        </div>
      </header>

      {item.note ? <p className="ui-design-idea-board__note">{item.note}</p> : null}

      {item.ownerBoundary ? (
        <div className="ui-design-idea-board__boundary">
          <strong>{ownerBoundaryLabel}</strong>
          <span>{item.ownerBoundary}</span>
        </div>
      ) : null}

      {blockers.length > 0 ? (
        <div className="ui-design-idea-board__blockers">
          <span>{blockersLabel}</span>
          <div className="ui-design-idea-board__blocker-list">
            {blockers.map((blocker, index) => (
              <span className="ui-design-idea-board__blocker" key={typeof blocker === "string" ? blocker : `${item.id}-${index}`}>
                <ListChecks aria-hidden="true" size={13} />
                {blocker}
              </span>
            ))}
          </div>
        </div>
      ) : null}

      {item.actions ? <div className="ui-design-idea-board__card-actions">{item.actions}</div> : null}
    </article>
  );
}

function DesignIdeaSource({ item, sourceLabel }: { item: DesignIdeaBoardItem; sourceLabel: ReactNode }) {
  const content = (
    <>
      <span>{item.source}</span>
      {item.sourceHref ? <ExternalLink aria-hidden="true" size={13} /> : null}
    </>
  );

  if (!item.sourceHref) {
    return <span className="ui-design-idea-board__source">{content}</span>;
  }

  return (
    <a className="ui-design-idea-board__source" href={item.sourceHref} aria-label={plainLabel(sourceLabel)}>
      {content}
    </a>
  );
}

function defaultMetrics(items: DesignIdeaBoardItem[]): DesignIdeaBoardMetric[] {
  const targetLabels = new Set(items.map((item) => plainLabel(item.target)).filter(Boolean));
  return [
    { id: "ready", label: "Ready to port", value: items.filter((item) => item.laneId === "ready").length },
    { id: "blockers", label: "Known blockers", value: items.reduce((total, item) => total + (item.blockers?.length ?? 0), 0) },
    { id: "targets", label: "Target products", value: targetLabels.size },
  ];
}

function plainLabel(value: ReactNode): string | undefined {
  return typeof value === "string" || typeof value === "number" ? String(value) : undefined;
}
