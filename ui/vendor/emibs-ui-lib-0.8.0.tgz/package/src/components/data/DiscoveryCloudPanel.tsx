import { type ReactNode } from "react";
import { Hash } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type DiscoveryCloudItemSize = "sm" | "md" | "lg";

export type DiscoveryCloudItem = {
  id: string;
  label: ReactNode;
  href?: string;
  count?: ReactNode;
  detail?: ReactNode;
  title?: string;
  active?: boolean;
  disabled?: boolean;
  tone?: BadgeTone;
  size?: DiscoveryCloudItemSize;
  onSelect?: () => void;
};

export type DiscoveryCloudGroup = {
  id: string;
  label: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
  items: DiscoveryCloudItem[];
  emptyLabel?: ReactNode;
};

export type DiscoveryCloudPanelProps = {
  title?: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
  resultCount?: ReactNode;
  groups: DiscoveryCloudGroup[];
  actions?: ReactNode;
  emptyLabel?: ReactNode;
  density?: "compact" | "comfortable";
  className?: string;
};

export function DiscoveryCloudPanel({
  title = "Discovery",
  description,
  icon,
  resultCount,
  groups,
  actions,
  emptyLabel = "No discovery groups available.",
  density = "comfortable",
  className,
}: DiscoveryCloudPanelProps) {
  return (
    <section className={cn("ui-discovery-cloud", `ui-discovery-cloud--${density}`, className)}>
      <header className="ui-discovery-cloud__header">
        <div className="ui-discovery-cloud__title-row">
          <span className="ui-discovery-cloud__icon" aria-hidden="true">
            {icon ?? <Hash size={18} />}
          </span>
          <div className="ui-discovery-cloud__title-block">
            <h2>{title}</h2>
            {description ? <p>{description}</p> : null}
          </div>
        </div>
        <div className="ui-discovery-cloud__header-actions">
          {resultCount ? <Badge tone="info">{resultCount}</Badge> : null}
          {actions}
        </div>
      </header>

      <div className="ui-discovery-cloud__groups">
        {groups.length > 0 ? (
          groups.map((group) => <DiscoveryCloudGroupView group={group} key={group.id} />)
        ) : (
          <p className="ui-discovery-cloud__empty">{emptyLabel}</p>
        )}
      </div>
    </section>
  );
}

function DiscoveryCloudGroupView({ group }: { group: DiscoveryCloudGroup }) {
  const headingId = `discovery-cloud-${group.id}-heading`;
  return (
    <section className="ui-discovery-cloud__group" aria-labelledby={headingId}>
      <div className="ui-discovery-cloud__group-header">
        {group.icon ? (
          <span className="ui-discovery-cloud__group-icon" aria-hidden="true">
            {group.icon}
          </span>
        ) : null}
        <div className="ui-discovery-cloud__group-copy">
          <h3 id={headingId}>{group.label}</h3>
          {group.description ? <p>{group.description}</p> : null}
        </div>
      </div>

      {group.items.length > 0 ? (
        <div className="ui-discovery-cloud__items">
          {group.items.map((item) => (
            <DiscoveryCloudItemView item={item} key={item.id} />
          ))}
        </div>
      ) : (
        <p className="ui-discovery-cloud__empty">{group.emptyLabel ?? "No items."}</p>
      )}
    </section>
  );
}

function DiscoveryCloudItemView({ item }: { item: DiscoveryCloudItem }) {
  const className = cn(
    "ui-discovery-cloud__item",
    `ui-discovery-cloud__item--${item.size ?? "md"}`,
    item.tone && `ui-discovery-cloud__item--${item.tone}`,
    item.active && "is-active",
    item.disabled && "is-disabled",
  );
  const content = (
    <>
      <span className="ui-discovery-cloud__item-label">{item.label}</span>
      {item.count !== undefined ? <span className="ui-discovery-cloud__item-count">{item.count}</span> : null}
      {item.detail ? <small>{item.detail}</small> : null}
    </>
  );

  if (item.href && !item.disabled) {
    return (
      <a className={className} href={item.href} title={item.title} aria-current={item.active ? "page" : undefined} onClick={item.onSelect}>
        {content}
      </a>
    );
  }

  if (item.onSelect && !item.disabled) {
    return (
      <button type="button" className={className} title={item.title} aria-pressed={item.active} onClick={item.onSelect}>
        {content}
      </button>
    );
  }

  return (
    <span className={className} title={item.title} aria-disabled={item.disabled || undefined}>
      {content}
    </span>
  );
}
