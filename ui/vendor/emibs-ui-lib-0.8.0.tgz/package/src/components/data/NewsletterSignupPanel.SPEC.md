# NewsletterSignupPanel Spec

## Purpose

`NewsletterSignupPanel` captures eLitua's editorial newsletter CTA/form block as
a presentational signup surface for content, travel, product, or operations
pages.

## Source Evidence

- eLitua `ui/src/pages/blog/BlogListingPage/BlogListingPage.tsx` renders a
  reusable newsletter CTA after the editorial listing grid: icon, headline,
  supporting copy, email input, submit action, and submitted-state message.
- The larger `EditorialListingPage` shell is already represented in the catalog.
  This extraction moves one level deeper into the repeated form CTA chrome left
  inside that page.

## Existing Coverage Check

- `EditorialListingPage`, `PortalShell`, `PortalHeader`, `PortalFooter`, and
  `PortalMobileNavigation` already cover the page shell and portal chrome.
- `TextInputControl` covers generic field rows, but not the combined CTA,
  email-only form layout, submitted state, and newsletter/action footer chrome.
- `NoticeBanner` and `AuthStatusPanel` cover status messages, not signup form
  composition.

## Contract

- Renders a controlled email signup panel with title, description, optional
  eyebrow/icon, submit action, success message, error message, footer, and
  optional extra actions.
- The email value is controlled through `value` and `onValueChange`.
- Native submit is exposed through `onSubmit`. Consumers own subscription API
  calls, validation beyond native email constraints, persistence, analytics,
  localization, consent policy, anti-spam handling, and toast behavior.
- `submitted`, `busy`, `disabled`, and `error` are controlled state props.
- `busy` and `disabled` are different states (`src/theme/STATES.md` rule 5).
  `disabled` takes the native `disabled` attribute on both the email field and
  the submit button: not interactive, not focusable. `busy` never does. While a
  submission is in flight the submit button stays **focusable** and announces
  `aria-busy="true"`, and the email field becomes `readonly` — the state model's
  own "shown, not editable" — so its value stays announced and reachable.
  Re-submission is refused in the form's `onSubmit`, which also covers Enter
  pressed inside the field.

## Non-Goals

- No newsletter provider SDK, mailing-list API call, email confirmation flow,
  double opt-in, CAPTCHA, consent storage, route mutation, analytics event, or
  toast queue.
- No replacement for generic field primitives or full editorial page shells.

## Review Checks

- Long titles, descriptions, placeholders, and submit labels wrap without
  horizontal overflow.
- Mobile layout stacks the input and submit action.
- Success and error states are exposed with `role="status"` and `role="alert"`.
