# FacetFilterPanel

## Purpose

`FacetFilterPanel` is a presentational counted-filter surface for catalog,
registry, board, and admin review screens. It keeps facet groups, counted
options, match-mode controls, removable active chips, and reset chrome reusable
without owning search, routes, or filter semantics.

## Source Evidence

- Score Catalog Explorer renders local `CatalogFacets`, `FacetButton`, and
  `CatalogFilterChips` in
  `/engineering/projects/score/ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`.
- emibs-ui-lib Catalog Explorer has internal faceted slicing, but no exported
  component contract that product apps can adopt.
- eLitua larger layout, shell, portal, map, table, card, auth, account, and form
  candidates were checked first and are already represented by earlier
  extractions.

## Contract

- Consumers pass normalized facet groups, option counts, selected state, optional
  match-mode controls, active filter chips, and reset actions.
- `FacetFilterPanel` renders only UI chrome. Apps keep registry loading, query
  parsing, URL synchronization, saved filters, count derivation, and whether a
  facet behaves as single-select or multi-select.
- Groups support an optional controlled Any/All mode so products with multi-facet
  semantics can expose the same compact control without sharing business logic.
- Styling uses `ui-facet-filter*` classes and shared token variables only.

## Non-Goals

- No filtering algorithm, search parser, route ownership, local storage,
  registry schema, analytics, persistence, or product DTO mapping.
- No assumption that facet values come from Score, eLitua, Tailwind, or the
  emibs catalog metadata shape.

## Review Expectations

- Long facet labels and chip values truncate or wrap without pushing controls
  outside the panel.
- Empty, single-select, multi-select, and active-chip states are visible in the
  catalog.
- Keyboard users can focus every option, mode button, chip removal, and reset
  action.
