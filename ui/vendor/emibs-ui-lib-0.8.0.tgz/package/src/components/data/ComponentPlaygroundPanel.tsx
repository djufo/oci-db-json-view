import { type ReactNode, useId } from "react";
import { Copy, RotateCcw, SlidersHorizontal } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { Button } from "../primitives/Button";

export type ComponentPlaygroundValue = boolean | number | string;
export type ComponentPlaygroundValues = Record<string, ComponentPlaygroundValue>;

export type ComponentPlaygroundControlOption = {
  value: string;
  label: ReactNode;
  disabled?: boolean;
};

type ComponentPlaygroundControlBase = {
  name: string;
  label: ReactNode;
  description?: ReactNode;
  defaultValue?: ComponentPlaygroundValue;
  disabled?: boolean;
};

export type ComponentPlaygroundBooleanControl = ComponentPlaygroundControlBase & {
  kind: "boolean";
};

export type ComponentPlaygroundEnumControl = ComponentPlaygroundControlBase & {
  kind: "enum";
  options: ComponentPlaygroundControlOption[];
};

export type ComponentPlaygroundNodeControl = ComponentPlaygroundControlBase & {
  kind: "node";
  options: ComponentPlaygroundControlOption[];
};

export type ComponentPlaygroundSelectControl = ComponentPlaygroundEnumControl | ComponentPlaygroundNodeControl;

export type ComponentPlaygroundNumberControl = ComponentPlaygroundControlBase & {
  kind: "number";
  min?: number;
  max?: number;
  step?: number;
};

export type ComponentPlaygroundStringControl = ComponentPlaygroundControlBase & {
  kind: "string";
  placeholder?: string;
};

export type ComponentPlaygroundTextControl = ComponentPlaygroundControlBase & {
  kind: "text";
  placeholder?: string;
  rows?: number;
};

export type ComponentPlaygroundControl =
  | ComponentPlaygroundBooleanControl
  | ComponentPlaygroundSelectControl
  | ComponentPlaygroundNumberControl
  | ComponentPlaygroundStringControl
  | ComponentPlaygroundTextControl;

export type ComponentPlaygroundBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type ComponentPlaygroundPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  controls: ComponentPlaygroundControl[];
  values: ComponentPlaygroundValues;
  onValueChange?: (name: string, value: ComponentPlaygroundValue) => void;
  stage: ReactNode;
  snippet?: ReactNode;
  badges?: ComponentPlaygroundBadge[];
  actions?: ReactNode;
  footer?: ReactNode;
  controlsLabel?: ReactNode;
  stageLabel?: ReactNode;
  stageBadge?: ReactNode;
  snippetLabel?: ReactNode;
  emptyControlsLabel?: ReactNode;
  resetLabel?: ReactNode;
  onReset?: () => void;
  copyLabel?: ReactNode;
  copiedLabel?: ReactNode;
  copied?: boolean;
  onCopySnippet?: () => void;
  density?: "compact" | "comfortable";
  className?: string;
};

export function ComponentPlaygroundPanel({
  title,
  eyebrow,
  subtitle,
  controls,
  values,
  onValueChange,
  stage,
  snippet,
  badges = [],
  actions,
  footer,
  controlsLabel = "Controls",
  stageLabel = "Live stage",
  stageBadge,
  snippetLabel = "JSX snippet",
  emptyControlsLabel = "No playground controls are available.",
  resetLabel = "Reset",
  onReset,
  copyLabel = "Copy",
  copiedLabel = "Copied",
  copied = false,
  onCopySnippet,
  density = "comfortable",
  className,
}: ComponentPlaygroundPanelProps) {
  const generatedId = useId().replace(/:/g, "");
  const titleId = `ui-component-playground-${generatedId}-title`;
  const controlsId = `ui-component-playground-${generatedId}-controls`;
  const stageId = `ui-component-playground-${generatedId}-stage`;
  const snippetId = `ui-component-playground-${generatedId}-snippet`;

  return (
    <section
      aria-labelledby={titleId}
      className={cn("ui-component-playground", `ui-component-playground--${density}`, className)}
    >
      <header className="ui-component-playground__header">
        <div className="ui-component-playground__title-row">
          <span className="ui-component-playground__icon" aria-hidden="true">
            <SlidersHorizontal size={19} />
          </span>
          <div className="ui-component-playground__title-block">
            {eyebrow ? <span className="ui-component-playground__eyebrow">{eyebrow}</span> : null}
            <h2 id={titleId}>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
        </div>
        {badges.length > 0 || actions ? (
          <div className="ui-component-playground__header-actions">
            {badges.map((badge) => (
              <Badge key={badge.id} tone={badge.tone}>
                {badge.label}
              </Badge>
            ))}
            {actions}
          </div>
        ) : null}
      </header>

      <div className="ui-component-playground__body">
        <aside className="ui-component-playground__rail" aria-labelledby={controlsId}>
          <header className="ui-component-playground__panel-header">
            <h3 id={controlsId}>{controlsLabel}</h3>
            {onReset ? (
              <Button size="sm" type="button" variant="secondary" onClick={onReset}>
                <RotateCcw size={14} aria-hidden="true" />
                {resetLabel}
              </Button>
            ) : null}
          </header>
          {controls.length > 0 ? (
            <div className="ui-component-playground__controls">
              {controls.map((control) => (
                <ComponentPlaygroundControlField
                  key={control.name}
                  baseId={generatedId}
                  control={control}
                  value={values[control.name] ?? control.defaultValue}
                  onChange={(value) => onValueChange?.(control.name, value)}
                />
              ))}
            </div>
          ) : (
            <p className="ui-component-playground__empty">{emptyControlsLabel}</p>
          )}
        </aside>

        <section className="ui-component-playground__stage-panel" aria-labelledby={stageId}>
          <header className="ui-component-playground__panel-header">
            <h3 id={stageId}>{stageLabel}</h3>
            {stageBadge ? <Badge tone="info">{stageBadge}</Badge> : null}
          </header>
          <div className="ui-component-playground__canvas">
            <div className="ui-component-playground__stage">{stage}</div>
          </div>
        </section>

        {snippet !== undefined ? (
          <section className="ui-component-playground__snippet-panel" aria-labelledby={snippetId}>
            <header className="ui-component-playground__panel-header">
              <h3 id={snippetId}>{snippetLabel}</h3>
              {onCopySnippet ? (
                <Button size="sm" type="button" variant="secondary" onClick={onCopySnippet}>
                  <Copy size={14} aria-hidden="true" />
                  {copied ? copiedLabel : copyLabel}
                </Button>
              ) : null}
            </header>
            {typeof snippet === "string" ? (
              <pre>
                <code>{snippet}</code>
              </pre>
            ) : (
              <div className="ui-component-playground__snippet-content">{snippet}</div>
            )}
          </section>
        ) : null}
      </div>

      {footer ? <footer className="ui-component-playground__footer">{footer}</footer> : null}
    </section>
  );
}

function ComponentPlaygroundControlField({
  baseId,
  control,
  onChange,
  value,
}: {
  baseId: string;
  control: ComponentPlaygroundControl;
  onChange: (value: ComponentPlaygroundValue) => void;
  value?: ComponentPlaygroundValue;
}) {
  const controlId = `ui-component-playground-${baseId}-${control.name}`.replace(/[^a-zA-Z0-9_-]/g, "-");
  const disabled = control.disabled;

  if (control.kind === "boolean") {
    const checked = Boolean(value ?? control.defaultValue ?? false);
    return (
      <div className="ui-component-playground-control ui-component-playground-control--boolean">
        {/* The label WRAPS the checkbox as well as keeping `htmlFor`, so the
            whole row is the hit target (TOUCH-TARGETS rule 5) while the glyph
            keeps its native size. `htmlFor` still names the association, so the
            control is labelled once, by this label's text — the description
            stays outside it and is not part of the accessible name. */}
        <label className="ui-component-playground-control__boolean-row" htmlFor={controlId}>
          <span>{control.label}</span>
          <input
            checked={checked}
            disabled={disabled}
            id={controlId}
            type="checkbox"
            onChange={(event) => onChange(event.currentTarget.checked)}
          />
        </label>
        {control.description ? <p>{control.description}</p> : null}
      </div>
    );
  }

  if (control.kind === "enum" || control.kind === "node") {
    return (
      <div className="ui-component-playground-control">
        <label htmlFor={controlId}>{control.label}</label>
        {control.description ? <p>{control.description}</p> : null}
        <select
          disabled={disabled || control.options.length === 0}
          id={controlId}
          value={String(value ?? control.defaultValue ?? "")}
          onChange={(event) => onChange(event.currentTarget.value)}
        >
          {control.options.map((option) => (
            <option key={option.value} disabled={option.disabled} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>
    );
  }

  if (control.kind === "number") {
    const numberValue = typeof value === "number" ? value : Number(control.defaultValue ?? 0);
    return (
      <div className="ui-component-playground-control">
        <label htmlFor={controlId}>{control.label}</label>
        {control.description ? <p>{control.description}</p> : null}
        <input
          disabled={disabled}
          id={controlId}
          inputMode="numeric"
          max={control.max}
          min={control.min}
          step={control.step}
          type="number"
          value={Number.isFinite(numberValue) ? numberValue : 0}
          onChange={(event) =>
            onChange(
              Number.isNaN(event.currentTarget.valueAsNumber)
                ? Number(control.defaultValue ?? 0)
                : event.currentTarget.valueAsNumber,
            )
          }
        />
      </div>
    );
  }

  const stringValue = String(value ?? control.defaultValue ?? "");
  if (control.kind === "text") {
    return (
      <div className="ui-component-playground-control">
        <label htmlFor={controlId}>{control.label}</label>
        {control.description ? <p>{control.description}</p> : null}
        <textarea
          disabled={disabled}
          id={controlId}
          placeholder={control.placeholder}
          rows={control.rows ?? 3}
          value={stringValue}
          onChange={(event) => onChange(event.currentTarget.value)}
        />
      </div>
    );
  }

  return (
    <div className="ui-component-playground-control">
      <label htmlFor={controlId}>{control.label}</label>
      {control.description ? <p>{control.description}</p> : null}
      <input
        disabled={disabled}
        id={controlId}
        placeholder={control.placeholder}
        type="text"
        value={stringValue}
        onChange={(event) => onChange(event.currentTarget.value)}
      />
    </div>
  );
}
