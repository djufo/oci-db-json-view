import { type CSSProperties, type ReactNode } from "react";
import { ExternalLink, ImageIcon } from "lucide-react";
import { cn } from "../../lib";
import { disableableLinkAttributes } from "../../lib/disabledLink";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type EntityCardGridBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type EntityCardGridMeta = {
  id: string;
  label: ReactNode;
  icon?: ReactNode;
};

export type EntityCardGridImage = {
  src: string;
  alt: string;
};

export type EntityCardGridItem = {
  id: string;
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  description?: ReactNode;
  image?: EntityCardGridImage;
  icon?: ReactNode;
  accentColor?: string;
  badges?: EntityCardGridBadge[];
  meta?: EntityCardGridMeta[];
  footer?: ReactNode;
  href?: string;
  external?: boolean;
  selected?: boolean;
  disabled?: boolean;
  actions?: ReactNode;
};

export type EntityCardGridPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  description?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  toolbar?: ReactNode;
  pagination?: ReactNode;
  items: EntityCardGridItem[];
  selectedItemId?: string;
  loading?: boolean;
  loadingLabel?: ReactNode;
  error?: ReactNode;
  emptyLabel?: ReactNode;
  itemActionLabel?: ReactNode;
  density?: "comfortable" | "compact";
  onItemSelect?: (itemId: string) => void;
  className?: string;
};

export function EntityCardGridPanel({
  title,
  eyebrow,
  description,
  status,
  statusTone = "neutral",
  actions,
  toolbar,
  pagination,
  items,
  selectedItemId,
  loading = false,
  loadingLabel = "Loading records...",
  error,
  emptyLabel = "No records returned.",
  itemActionLabel = "Open record",
  density = "comfortable",
  onItemSelect,
  className,
}: EntityCardGridPanelProps) {
  return (
    <section className={cn("ui-entity-card-grid", `ui-entity-card-grid--${density}`, className)} aria-label={plainLabel(title)}>
      <header className="ui-entity-card-grid__header">
        <div className="ui-entity-card-grid__title-block">
          {eyebrow ? <span className="ui-entity-card-grid__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {description ? <p>{description}</p> : null}
        </div>
        <div className="ui-entity-card-grid__header-actions">
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {toolbar || pagination ? (
        <div className="ui-entity-card-grid__toolbar">
          <div className="ui-entity-card-grid__toolbar-main">{toolbar}</div>
          {pagination ? <div className="ui-entity-card-grid__pagination">{pagination}</div> : null}
        </div>
      ) : null}

      {loading ? (
        <div className="ui-entity-card-grid__state" role="status">
          <span className="ui-entity-card-grid__spinner" aria-hidden="true" />
          <span>{loadingLabel}</span>
        </div>
      ) : null}

      {!loading && error ? (
        <div className="ui-entity-card-grid__state ui-entity-card-grid__state--error" role="alert">
          {error}
        </div>
      ) : null}

      {!loading && !error && items.length === 0 ? (
        <div className="ui-entity-card-grid__state">{emptyLabel}</div>
      ) : null}

      {!loading && !error && items.length > 0 ? (
        <div className="ui-entity-card-grid__grid">
          {items.map((item) => (
            <EntityCardGridCard
              item={item}
              itemActionLabel={itemActionLabel}
              key={item.id}
              selected={item.selected || item.id === selectedItemId}
              onItemSelect={onItemSelect}
            />
          ))}
        </div>
      ) : null}
    </section>
  );
}

function EntityCardGridCard({
  item,
  itemActionLabel,
  selected,
  onItemSelect,
}: {
  item: EntityCardGridItem;
  itemActionLabel: ReactNode;
  selected: boolean;
  onItemSelect?: (itemId: string) => void;
}) {
  const style = item.accentColor
    ? ({ "--ui-entity-card-grid-accent": item.accentColor } as CSSProperties)
    : undefined;

  return (
    <article
      className={cn(
        "ui-entity-card-grid__card",
        selected && "is-selected",
        item.disabled && "is-disabled",
      )}
      style={style}
    >
      <EntityCardGridCardMain item={item} itemActionLabel={itemActionLabel} onItemSelect={onItemSelect} />
      {item.actions ? <div className="ui-entity-card-grid__card-actions">{item.actions}</div> : null}
    </article>
  );
}

function EntityCardGridCardMain({
  item,
  itemActionLabel,
  onItemSelect,
}: {
  item: EntityCardGridItem;
  itemActionLabel: ReactNode;
  onItemSelect?: (itemId: string) => void;
}) {
  const content = <EntityCardGridCardContent item={item} />;

  if (item.href) {
    // A disabled card is inert whether it renders as a link or as a button.
    // See `src/lib/disabledLink.ts`.
    return (
      <a
        className="ui-entity-card-grid__card-main"
        {...disableableLinkAttributes({
          href: item.href,
          disabled: item.disabled,
          rel: item.external ? "noreferrer" : undefined,
          target: item.external ? "_blank" : undefined,
        })}
      >
        {content}
      </a>
    );
  }

  if (onItemSelect) {
    return (
      <button
        className="ui-entity-card-grid__card-main"
        disabled={item.disabled}
        onClick={() => onItemSelect(item.id)}
        type="button"
      >
        {content}
        <span className="ui-sr-only">{itemActionLabel}</span>
      </button>
    );
  }

  return <div className="ui-entity-card-grid__card-main">{content}</div>;
}

function EntityCardGridCardContent({ item }: { item: EntityCardGridItem }) {
  return (
    <>
      <div className="ui-entity-card-grid__media" aria-hidden={!item.image}>
        {item.image ? (
          <img src={item.image.src} alt={item.image.alt} />
        ) : (
          <span>{item.icon ?? <ImageIcon size={24} aria-hidden="true" />}</span>
        )}
      </div>
      <div className="ui-entity-card-grid__body">
        <div className="ui-entity-card-grid__title-row">
          <div className="ui-entity-card-grid__title-copy">
            {item.eyebrow ? <span className="ui-entity-card-grid__item-eyebrow">{item.eyebrow}</span> : null}
            <h3>
              <span>{item.title}</span>
              {item.external ? <ExternalLink size={14} aria-hidden="true" /> : null}
            </h3>
          </div>
          {item.badges && item.badges.length > 0 ? (
            <div className="ui-entity-card-grid__badges">
              {item.badges.map((badge) => (
                <Badge key={badge.id} tone={badge.tone}>
                  {badge.label}
                </Badge>
              ))}
            </div>
          ) : null}
        </div>
        {item.subtitle ? <p className="ui-entity-card-grid__subtitle">{item.subtitle}</p> : null}
        {item.description ? <p className="ui-entity-card-grid__description">{item.description}</p> : null}
        {item.meta && item.meta.length > 0 ? (
          <div className="ui-entity-card-grid__meta">
            {item.meta.map((meta) => (
              <span key={meta.id}>
                {meta.icon}
                {meta.label}
              </span>
            ))}
          </div>
        ) : null}
        {item.footer ? <div className="ui-entity-card-grid__footer">{item.footer}</div> : null}
      </div>
    </>
  );
}

function plainLabel(value: ReactNode): string | undefined {
  return typeof value === "string" || typeof value === "number" ? String(value) : undefined;
}
