import { type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { StatusIndicator, type StatusIndicatorTone } from "../primitives/StatusIndicator";
import { DataTable, type DataTableColumn } from "./DataTable";
import { MetricGrid } from "./MetricGrid";

export type AgentManagementHealthTone = "running" | "idle" | "capacity" | "disabled" | "danger";

export type AgentManagementMetric = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
  tone?: BadgeTone;
  icon?: ReactNode;
};

export type AgentManagementRunnerOption = {
  value: string;
  label: string;
};

export type AgentManagementAgent = {
  id: string;
  displayName?: string;
  purpose?: ReactNode;
  role?: ReactNode;
  provider?: ReactNode;
  runnerId?: string;
  enabled: boolean;
  enabledDisabled?: boolean;
  runnerDisabled?: boolean;
  state?: ReactNode;
  stateTone?: BadgeTone;
  healthTone?: AgentManagementHealthTone;
  dayCapacity?: ReactNode;
  dayReset?: ReactNode;
  weekCapacity?: ReactNode;
  weekReset?: ReactNode;
  minimum?: ReactNode;
  cooldownUntil?: ReactNode;
  available?: boolean;
  availableAt?: ReactNode;
  releaseProjects?: string[];
  actions?: ReactNode;
};

export type AgentManagementRunner = {
  id: string;
  displayName?: string;
  responsibilities?: string;
  enabled: boolean;
  enabledDisabled?: boolean;
  actions?: ReactNode;
};

export type AgentManagementPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  metrics?: AgentManagementMetric[];
  agents: AgentManagementAgent[];
  runners?: AgentManagementRunner[];
  runnerOptions?: AgentManagementRunnerOption[];
  loading?: boolean;
  error?: ReactNode;
  emptyAgentsLabel?: ReactNode;
  emptyRunnersLabel?: ReactNode;
  agentsLabel?: ReactNode;
  runnersLabel?: ReactNode;
  runnersDescription?: ReactNode;
  onAgentOpen?: (agentId: string) => void;
  onAgentEnabledChange?: (agentId: string, enabled: boolean) => void;
  onAgentRunnerChange?: (agentId: string, runnerId: string) => void;
  onRunnerEnabledChange?: (runnerId: string, enabled: boolean) => void;
  onRunnerNameChange?: (runnerId: string, displayName: string) => void;
  onRunnerResponsibilitiesChange?: (runnerId: string, responsibilities: string) => void;
  className?: string;
};

export function AgentManagementPanel({
  title,
  eyebrow,
  subtitle,
  status,
  statusTone = "neutral",
  actions,
  metrics = [],
  agents,
  runners = [],
  runnerOptions = [],
  loading = false,
  error,
  emptyAgentsLabel = "No agents returned.",
  emptyRunnersLabel = "No runners returned.",
  agentsLabel = "Agents",
  runnersLabel = "Runners",
  runnersDescription = "Runners define execution responsibilities; agents attach to one runner at a time.",
  onAgentOpen,
  onAgentEnabledChange,
  onAgentRunnerChange,
  onRunnerEnabledChange,
  onRunnerNameChange,
  onRunnerResponsibilitiesChange,
  className,
}: AgentManagementPanelProps) {
  const agentColumns: DataTableColumn<AgentManagementAgent>[] = [
    {
      id: "agent",
      header: "Agent",
      accessor: (agent) => agent.displayName || agent.id,
      rowHeader: true,
      cell: (agent) => <AgentManagementAgentIdentity agent={agent} />,
    },
    {
      id: "role",
      header: "Role",
      accessor: (agent) => plainLabel(agent.role) ?? "",
      cell: (agent) => <AgentManagementRole agent={agent} />,
    },
    {
      id: "runner",
      header: "Runner",
      accessor: (agent) => agent.runnerId ?? "",
      cell: (agent) => (
        <AgentManagementRunnerSelect
          agent={agent}
          loading={loading}
          onAgentRunnerChange={onAgentRunnerChange}
          runnerOptions={runnerOptions}
        />
      ),
    },
    {
      id: "enabled",
      header: "Enabled",
      accessor: (agent) => agent.enabled,
      cell: (agent) => (
        <AgentManagementEnabledControl
          agent={agent}
          loading={loading}
          onAgentEnabledChange={onAgentEnabledChange}
        />
      ),
    },
    {
      id: "capacity",
      header: "Capacity",
      accessor: (agent) => plainLabel(agent.state) ?? "",
      cell: (agent) => <AgentManagementCapacity agent={agent} />,
    },
    {
      id: "availability",
      header: "Availability",
      accessor: (agent) => (agent.available ? "Available" : "Unavailable"),
      cell: (agent) => <AgentManagementAvailability agent={agent} />,
    },
    {
      id: "release",
      header: "Release",
      accessor: (agent) => agent.releaseProjects?.join(" ") ?? "",
      cell: (agent) => <AgentManagementRelease agent={agent} />,
    },
    {
      id: "actions",
      header: "Actions",
      accessor: () => "",
      sortable: false,
      cell: (agent) => <AgentManagementActions actions={agent.actions} />,
    },
  ];

  const runnerColumns: DataTableColumn<AgentManagementRunner>[] = [
    {
      id: "runner",
      header: "Runner",
      accessor: (runner) => runner.displayName || runner.id,
      rowHeader: true,
      cell: (runner) => (
        <AgentManagementRunnerIdentity
          loading={loading}
          onRunnerNameChange={onRunnerNameChange}
          runner={runner}
        />
      ),
    },
    {
      id: "responsibilities",
      header: "Responsibilities",
      accessor: (runner) => runner.responsibilities ?? "",
      cell: (runner) => (
        <AgentManagementRunnerResponsibilities
          loading={loading}
          onRunnerResponsibilitiesChange={onRunnerResponsibilitiesChange}
          runner={runner}
        />
      ),
    },
    {
      id: "enabled",
      header: "Enabled",
      accessor: (runner) => runner.enabled,
      cell: (runner) => (
        <AgentManagementRunnerEnabled
          loading={loading}
          onRunnerEnabledChange={onRunnerEnabledChange}
          runner={runner}
        />
      ),
    },
    {
      id: "agents",
      header: "Agents",
      accessor: (runner) => agents.filter((agent) => agent.runnerId === runner.id).length,
      cell: (runner) => <AgentManagementAssignedAgents agents={agents} runner={runner} />,
    },
    {
      id: "actions",
      header: "Actions",
      accessor: () => "",
      sortable: false,
      cell: (runner) => <AgentManagementActions actions={runner.actions} />,
    },
  ];

  return (
    <section className={cn("ui-agent-management", className)}>
      <header className="ui-agent-management__header">
        <div className="ui-agent-management__title-block">
          {eyebrow ? <span className="ui-agent-management__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
        <div className="ui-agent-management__header-actions">
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {error ? (
        <div className="ui-agent-management__error" role="alert">
          {error}
        </div>
      ) : null}

      {metrics.length > 0 ? (
        <MetricGrid
          ariaLabel="Agent management metrics"
          className="ui-agent-management__metrics"
          items={metrics}
        />
      ) : null}

      <section className="ui-agent-management__panel" aria-label="Agent configuration">
        <div className="ui-agent-management__panel-header">
          <h3>{agentsLabel}</h3>
        </div>
        <DataTable
          ariaLabel={plainLabel(agentsLabel) ?? "Agents"}
          className="ui-agent-management__data-table"
          columns={agentColumns}
          data={agents}
          density="compact"
          emptyState={{ title: "No agents", description: emptyAgentsLabel }}
          getRowId={(agent) => agent.id}
          loading={loading}
          loadingState={{ title: "Loading agents", description: "Loading agents." }}
          onRowActivate={onAgentOpen ? (agent) => onAgentOpen(agent.id) : undefined}
          striped={false}
        />
      </section>

      <section className="ui-agent-management__panel" aria-label="Runner configuration">
        <div className="ui-agent-management__panel-header">
          <div>
            <h3>{runnersLabel}</h3>
            {runnersDescription ? <p>{runnersDescription}</p> : null}
          </div>
        </div>
        <DataTable
          ariaLabel={plainLabel(runnersLabel) ?? "Runners"}
          className="ui-agent-management__data-table ui-agent-management__data-table--runners"
          columns={runnerColumns}
          data={runners}
          density="compact"
          emptyState={{ title: "No runners", description: emptyRunnersLabel }}
          getRowId={(runner) => runner.id}
          loading={loading}
          loadingState={{ title: "Loading runners", description: "Loading runners." }}
          striped={false}
        />
      </section>
    </section>
  );
}

function AgentManagementAgentIdentity({ agent }: { agent: AgentManagementAgent }) {
  const agentLabel = agent.displayName || agent.id;

  return (
    <span className="ui-agent-management__identity">
      <strong>{agentLabel}</strong>
      {agent.displayName ? <span>{agent.id}</span> : null}
      {agent.purpose ? <small>{agent.purpose}</small> : null}
    </span>
  );
}

function AgentManagementRole({ agent }: { agent: AgentManagementAgent }) {
  return (
    <span className="ui-agent-management__stacked">
      <strong>{agent.role ?? "Unassigned"}</strong>
      {agent.provider ? <small>{agent.provider}</small> : null}
    </span>
  );
}

function AgentManagementRunnerSelect({
  agent,
  loading,
  onAgentRunnerChange,
  runnerOptions,
}: {
  agent: AgentManagementAgent;
  loading: boolean;
  onAgentRunnerChange?: (agentId: string, runnerId: string) => void;
  runnerOptions: AgentManagementRunnerOption[];
}) {
  const agentLabel = agent.displayName || agent.id;

  return (
    <select
      aria-label={`Runner for ${agentLabel}`}
      className="ui-agent-management__select"
      disabled={loading || agent.runnerDisabled || !onAgentRunnerChange}
      onChange={(event) => onAgentRunnerChange?.(agent.id, event.target.value)}
      onClick={(event) => event.stopPropagation()}
      value={agent.runnerId ?? ""}
    >
      <option value="">Unassigned</option>
      {runnerOptions.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

function AgentManagementEnabledControl({
  agent,
  loading,
  onAgentEnabledChange,
}: {
  agent: AgentManagementAgent;
  loading: boolean;
  onAgentEnabledChange?: (agentId: string, enabled: boolean) => void;
}) {
  return (
    <label className="ui-agent-management__check">
      <input
        checked={agent.enabled}
        disabled={loading || agent.enabledDisabled || !onAgentEnabledChange}
        onChange={(event) => onAgentEnabledChange?.(agent.id, event.target.checked)}
        onClick={(event) => event.stopPropagation()}
        readOnly={!onAgentEnabledChange}
        type="checkbox"
      />
      <span>{agent.enabled ? "Enabled" : "Disabled"}</span>
    </label>
  );
}

function AgentManagementCapacity({ agent }: { agent: AgentManagementAgent }) {
  const healthTone = agent.healthTone ?? (agent.enabled ? "idle" : "disabled");
  const capacityDetail = (
    <>
      Day {agent.dayCapacity ?? "Unknown"} · Week {agent.weekCapacity ?? "Unknown"}
      <br />
      Min {agent.minimum ?? "None"} · Cooldown {agent.cooldownUntil ?? "None"}
      {agent.dayReset || agent.weekReset ? (
        <>
          <br />
          Reset {agent.dayReset ?? "Unknown"} / {agent.weekReset ?? "Unknown"}
        </>
      ) : null}
    </>
  );

  return (
    <StatusIndicator
      className="ui-agent-management__status"
      detail={capacityDetail}
      label={agent.state ?? "Unknown"}
      size="sm"
      tone={agent.stateTone ?? healthStatusTone(healthTone)}
    />
  );
}

function AgentManagementAvailability({ agent }: { agent: AgentManagementAgent }) {
  return (
    <StatusIndicator
      className="ui-agent-management__status"
      detail={agent.availableAt ? `At ${agent.availableAt}` : "No time reported"}
      label={agent.available ? "Available" : "Unavailable"}
      size="sm"
      tone={agent.available ? "success" : "warning"}
    />
  );
}

function AgentManagementRelease({ agent }: { agent: AgentManagementAgent }) {
  if (!agent.releaseProjects?.length) {
    return <span className="ui-agent-management__muted">No grants</span>;
  }

  return (
    <span className="ui-agent-management__badges">
      {agent.releaseProjects.map((project) => (
        <Badge key={project} tone="info">
          {project}
        </Badge>
      ))}
    </span>
  );
}

function healthStatusTone(tone: AgentManagementHealthTone): StatusIndicatorTone {
  if (tone === "running") {
    return "success";
  }
  if (tone === "capacity") {
    return "warning";
  }
  if (tone === "danger") {
    return "danger";
  }
  return "neutral";
}

function AgentManagementRunnerIdentity({
  loading,
  onRunnerNameChange,
  runner,
}: {
  loading: boolean;
  onRunnerNameChange?: (runnerId: string, displayName: string) => void;
  runner: AgentManagementRunner;
}) {
  const runnerLabel = runner.displayName || runner.id;

  if (onRunnerNameChange) {
    return (
      <label className="ui-agent-management__field">
        <span className="ui-sr-only">Runner name for {runner.id}</span>
        <input
          disabled={loading}
          onChange={(event) => onRunnerNameChange(runner.id, event.target.value)}
          value={runner.displayName ?? ""}
        />
      </label>
    );
  }

  return (
    <span className="ui-agent-management__identity">
      <strong>{runnerLabel}</strong>
      {runner.displayName ? <span>{runner.id}</span> : null}
    </span>
  );
}

function AgentManagementRunnerResponsibilities({
  loading,
  onRunnerResponsibilitiesChange,
  runner,
}: {
  loading: boolean;
  onRunnerResponsibilitiesChange?: (runnerId: string, responsibilities: string) => void;
  runner: AgentManagementRunner;
}) {
  if (onRunnerResponsibilitiesChange) {
    return (
      <label className="ui-agent-management__field">
        <span className="ui-sr-only">Responsibilities for {runner.id}</span>
        <input
          disabled={loading}
          onChange={(event) => onRunnerResponsibilitiesChange(runner.id, event.target.value)}
          value={runner.responsibilities ?? ""}
        />
      </label>
    );
  }

  return <span>{runner.responsibilities || "No responsibilities set."}</span>;
}

function AgentManagementRunnerEnabled({
  loading,
  onRunnerEnabledChange,
  runner,
}: {
  loading: boolean;
  onRunnerEnabledChange?: (runnerId: string, enabled: boolean) => void;
  runner: AgentManagementRunner;
}) {
  return (
    <label className="ui-agent-management__check">
      <input
        checked={runner.enabled}
        disabled={loading || runner.enabledDisabled || !onRunnerEnabledChange}
        onChange={(event) => onRunnerEnabledChange?.(runner.id, event.target.checked)}
        readOnly={!onRunnerEnabledChange}
        type="checkbox"
      />
      <span>{runner.enabled ? "Enabled" : "Disabled"}</span>
    </label>
  );
}

function AgentManagementAssignedAgents({
  agents,
  runner,
}: {
  agents: AgentManagementAgent[];
  runner: AgentManagementRunner;
}) {
  const assignedAgents = agents.filter((agent) => agent.runnerId === runner.id);

  if (!assignedAgents.length) {
    return <span className="ui-agent-management__muted">No agents</span>;
  }

  return (
    <span className="ui-agent-management__badges">
      {assignedAgents.map((agent) => (
        <Badge key={agent.id}>{agent.displayName || agent.id}</Badge>
      ))}
    </span>
  );
}

function AgentManagementActions({ actions }: { actions?: ReactNode }) {
  return actions ? (
    <div className="ui-agent-management__actions">{actions}</div>
  ) : (
    <span className="ui-agent-management__muted">-</span>
  );
}

function plainLabel(value: ReactNode): string | undefined {
  return typeof value === "string" || typeof value === "number" ? String(value) : undefined;
}
