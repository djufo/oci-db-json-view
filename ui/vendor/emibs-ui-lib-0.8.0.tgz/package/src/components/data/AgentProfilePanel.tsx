import { type ChangeEvent, type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { IdentityAvatar } from "../primitives/IdentityAvatar";
import { MetricGrid } from "./MetricGrid";

export type AgentProfileMetric = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
  tone?: BadgeTone;
  icon?: ReactNode;
};

export type AgentProfileField = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
  href?: string;
  external?: boolean;
};

export type AgentProfileFieldOption = {
  value: string;
  label: ReactNode;
};

export type AgentProfileFormField = {
  id: string;
  label: ReactNode;
  value: string | boolean;
  control?: "text" | "select" | "checkbox";
  type?: "text" | "email" | "password" | "number";
  options?: AgentProfileFieldOption[];
  readOnly?: boolean;
  disabled?: boolean;
  hint?: ReactNode;
  placeholder?: string;
};

export type AgentProfileGrant = {
  id: string;
  project: ReactNode;
  allowed: boolean;
  detail?: ReactNode;
  action?: ReactNode;
};

export type AgentProfileSection = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
};

export type AgentProfilePanelProps = {
  title: ReactNode;
  agentId: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  avatar?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  busyState?: ReactNode;
  metrics?: AgentProfileMetric[];
  formTitle?: ReactNode;
  formDescription?: ReactNode;
  formFields?: AgentProfileFormField[];
  onFormFieldChange?: (fieldId: string, value: string | boolean) => void;
  grantsTitle?: ReactNode;
  grantsDescription?: ReactNode;
  grants?: AgentProfileGrant[];
  emptyGrantsLabel?: ReactNode;
  fieldsTitle?: ReactNode;
  fields?: AgentProfileField[];
  sections?: AgentProfileSection[];
  error?: ReactNode;
  loading?: boolean;
  className?: string;
};

export function AgentProfilePanel({
  title,
  agentId,
  eyebrow,
  subtitle,
  avatar,
  status,
  statusTone = "neutral",
  actions,
  busyState,
  metrics = [],
  formTitle = "Configuration",
  formDescription,
  formFields = [],
  onFormFieldChange,
  grantsTitle = "Release model",
  grantsDescription = "Release is a direct per-project grant managed outside the profile form.",
  grants = [],
  emptyGrantsLabel = "No project access grants.",
  fieldsTitle = "Agent details",
  fields = [],
  sections = [],
  error,
  loading = false,
  className,
}: AgentProfilePanelProps) {
  // The loading branch used to return early, before the header existed, which
  // suppressed `error`, `status`, `actions` and the identity chrome outright. An
  // app that sets `loading` and `error` together — the ordinary failed-refresh
  // case — showed a spinner and silently dropped the alert it had passed.
  //
  // The states compose instead: the header and its chrome always render, and
  // only the GENERATED body (metrics, form, grants, fields, sections) is
  // replaced while loading, because that is the part with no data yet.
  //
  // Precedence: an error outranks the spinner. "It failed" is actionable and
  // terminal; "still working" is neither, and showing both invites the user to
  // wait for a request that has already finished.
  const showLoadingSurface = loading && !error;

  return (
    <section aria-busy={loading || undefined} className={cn("ui-agent-profile", className)}>
      <header className="ui-agent-profile__header">
        <div className="ui-agent-profile__identity">
          {avatar ? (
            <span className="ui-agent-profile__avatar" aria-hidden="true">
              {avatar}
            </span>
          ) : (
            <IdentityAvatar label={identityLabel(title, "Agent profile")} size="lg" shape="rounded" tone="info" />
          )}
          <div className="ui-agent-profile__title-block">
            {eyebrow ? <span className="ui-agent-profile__eyebrow">{eyebrow}</span> : null}
            <h2>{title}</h2>
            <p>{agentId}</p>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
        </div>
        <div className="ui-agent-profile__header-actions">
          {busyState ? <span className="ui-agent-profile__busy">{busyState}</span> : null}
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {error ? (
        <div className="ui-agent-profile__error" role="alert">
          {error}
        </div>
      ) : null}

      {showLoadingSurface ? (
        <div className="ui-agent-profile__panel" role="status">
          <p className="ui-agent-profile__muted">Loading agent profile.</p>
        </div>
      ) : null}

      {loading ? null : (
        <>
          {metrics.length > 0 ? (
            <MetricGrid
              ariaLabel="Agent capacity metrics"
              className="ui-agent-profile__metrics"
              items={metrics}
            />
          ) : null}

          {formFields.length > 0 ? (
            <section className="ui-agent-profile__panel" aria-label="Agent configuration">
              <header className="ui-agent-profile__panel-header">
                <div>
                  <h3>{formTitle}</h3>
                  {formDescription ? <p>{formDescription}</p> : null}
                </div>
              </header>
              <div className="ui-agent-profile__form-grid">
                {formFields.map((field) => (
                  <AgentProfileInputField
                    field={field}
                    key={field.id}
                    onChange={(value) => onFormFieldChange?.(field.id, value)}
                  />
                ))}
              </div>
            </section>
          ) : null}

          <section className="ui-agent-profile__panel" aria-label="Agent release grants">
            <header className="ui-agent-profile__panel-header">
              <div>
                <h3>{grantsTitle}</h3>
                {grantsDescription ? <p>{grantsDescription}</p> : null}
              </div>
            </header>
            {grants.length === 0 ? <p className="ui-agent-profile__muted">{emptyGrantsLabel}</p> : null}
            {grants.length > 0 ? (
              <div className="ui-agent-profile__grant-list">
                {grants.map((grant) => (
                  <article className="ui-agent-profile__grant" key={grant.id}>
                    <div>
                      <strong>{grant.project}</strong>
                      {grant.detail ? <p>{grant.detail}</p> : null}
                    </div>
                    <div className="ui-agent-profile__grant-actions">
                      <Badge tone={grant.allowed ? "success" : "neutral"}>{grant.allowed ? "Allowed" : "Not allowed"}</Badge>
                      {grant.action}
                    </div>
                  </article>
                ))}
              </div>
            ) : null}
          </section>

          {fields.length > 0 ? (
            <section className="ui-agent-profile__panel" aria-label="Agent details">
              <header className="ui-agent-profile__panel-header">
                <h3>{fieldsTitle}</h3>
              </header>
              <dl className="ui-agent-profile__fields">
                {fields.map((field) => (
                  <div key={field.id}>
                    <dt>{field.label}</dt>
                    <dd>
                      {field.href ? (
                        <a href={field.href} rel={field.external ? "noreferrer" : undefined} target={field.external ? "_blank" : undefined}>
                          {field.value}
                        </a>
                      ) : (
                        field.value
                      )}
                      {field.detail ? <small>{field.detail}</small> : null}
                    </dd>
                  </div>
                ))}
              </dl>
            </section>
          ) : null}

          {sections.map((section) => (
            <section className="ui-agent-profile__panel" key={section.id}>
              <header className="ui-agent-profile__panel-header">
                <div>
                  <h3>{section.title}</h3>
                  {section.description ? <p>{section.description}</p> : null}
                </div>
                {section.actions ? <div className="ui-agent-profile__section-actions">{section.actions}</div> : null}
              </header>
              <div className="ui-agent-profile__section-body">{section.children}</div>
            </section>
          ))}
        </>
      )}
    </section>
  );
}

function AgentProfileInputField({
  field,
  onChange,
}: {
  field: AgentProfileFormField;
  onChange: (value: string | boolean) => void;
}) {
  const control = field.control ?? "text";
  const disabled = field.disabled || field.readOnly;

  if (control === "checkbox") {
    return (
      <label className="ui-agent-profile__field ui-agent-profile__field--check">
        <input
          checked={Boolean(field.value)}
          disabled={disabled}
          onChange={(event) => onChange(event.currentTarget.checked)}
          type="checkbox"
        />
        <span>{field.label}</span>
        {field.hint ? <small>{field.hint}</small> : null}
      </label>
    );
  }

  return (
    <label className="ui-agent-profile__field">
      <span>{field.label}</span>
      {control === "select" ? (
        <select
          disabled={disabled}
          onChange={(event: ChangeEvent<HTMLSelectElement>) => onChange(event.currentTarget.value)}
          value={String(field.value)}
        >
          {field.options?.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      ) : (
        <input
          disabled={field.disabled}
          onChange={(event: ChangeEvent<HTMLInputElement>) => onChange(event.currentTarget.value)}
          placeholder={field.placeholder}
          readOnly={field.readOnly}
          type={field.type ?? "text"}
          value={String(field.value)}
        />
      )}
      {field.hint ? <small>{field.hint}</small> : null}
    </label>
  );
}

function identityLabel(value: ReactNode, fallback: string): string {
  if (typeof value === "string" || typeof value === "number") {
    const label = String(value).trim();
    return label || fallback;
  }
  return fallback;
}
