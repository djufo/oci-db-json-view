# ChecklistEditorPanel

## Purpose

`ChecklistEditorPanel` is a controlled presentational editor for definition of
done lists, setup checklists, and similar ordered criteria rows.

## Source Evidence

- Score's `ui/src/features/projects/containers/ProjectPage.tsx` renders a
  project "Definition of done" editor with add, editable text rows, remove
  actions, and empty state for both create and edit flows.
- Existing `EditableChecklist` covers labelled checked rows inside
  `EditableFormPanel`, with an optional row toggle; it does not own add/remove
  or editable text-row chrome.

## Contract

- Items, checked state, text values, disabled state, metadata, and placeholders
  are controlled by props.
- Add, text change, checked change, and remove actions emit item ids to the
  consuming app.
- Header copy, status badge, action slot, empty label, footer, density, and row
  labels are customizable.

## Non-Goals

- No persistence, autosave, task generation, project validation, ordering
  policy, localization, toast handling, permissions, or route behavior.
- No internal draft state; consuming apps own item identity and validation.

## Review Expectations

- Long checklist text must wrap and remain editable without expanding beyond the
  panel width.
- Compact density must fit inside larger form sections.
- Read-only mode must hide remove controls and keep text inputs non-editable.
