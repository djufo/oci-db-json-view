# WorkItemCard

## Purpose

`WorkItemCard` is a presentational card for board and queue work items. It
standardizes the title/open affordance, id, metadata badges, parent-epic link,
compact facts, secondary open link, action row, selected state, and dense
board-card sizing.

## Source Evidence

- Score `ui/src/features/board/components/TaskCard.tsx` renders the repeated
  task-card shell used in work, all-work, epic, and closed board routes.
- Score `ui/src/features/board/components/BoardColumns.tsx` repeats the same
  card density inside workflow columns and single-epic lanes.
- Existing `WorkflowCommandBar` owns transition commands only; the board card
  shell around those commands was still local to Score.

## Contract

- Accepts controlled title, item id, optional href or `onOpen`, secondary
  external link, metadata badges, compact key facts, parent-epic descriptor,
  action slot, and footer slot.
- Supports compact and comfortable density plus selected and disabled states.
- `disabled` makes the open affordance genuinely inert in **both** branches, not
  just dimmed. The `onOpen` button takes the native `disabled` attribute; the
  `href` title keeps its `<a>` and gains `role="link"` + `aria-disabled="true"`
  but **loses its `href`**, which is what removes it from the tab order and
  takes away its activation behaviour. The `epic` and `externalLink` chips stay
  live: they address other resources, not this item.
- Leaves all routing, workflow legality, actor labels, status mapping,
  transition dispatch, persistence, notifications, and toast behavior to the
  consuming product.

## Non-Goals

- No Score task DTO, workflow graph, project access policy, search parsing,
  board column layout, drag/drop, API call, subscription state, or mutation
  behavior lives in this component.
