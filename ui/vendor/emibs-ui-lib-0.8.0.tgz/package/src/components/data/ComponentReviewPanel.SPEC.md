# ComponentReviewPanel

## Purpose

`ComponentReviewPanel` is a controlled presentational surface for reviewing one
UI component or reusable pattern at a time.

## Source Evidence

- Score's `ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  renders a component inspection page with metadata, an isolated preview
  canvas, canvas-width controls, review tabs, and variant cards.
- eLitua was inspected for larger remaining page shells during this extraction;
  the visible Bokun, payments, explorer, public profile, portal, map, and admin
  surfaces are already represented by existing catalog entries.

## Contract

- Consumers pass component title, summary, badges, metadata rows, preview
  variants, review tabs, canvas sizes, and selected ids.
- Variant, tab, and canvas-size state is controlled by the consuming app through
  `active*Id` props and `on*Change` callbacks.
- The component renders only review chrome: metadata, preview stage, controls,
  tab panels, and variant grid.
- Styling uses `ui-component-review*` classes and shared catalog tokens.

## Non-Goals

- No component registry, search, route ownership, package discovery, markdown
  parsing, code loading, access policy, analytics, persistence, or product API
  calls.
- No product-specific Score or eLitua DTOs.

## Review Expectations

- Long titles, source paths, package names, code blocks, and notes must wrap or
  scroll without overlapping controls.
- The canvas-size selector must constrain the preview while keeping the panel
  responsive.
- Empty, single-variant, multi-variant, and tabbed review states must be
  representable in the catalog.
