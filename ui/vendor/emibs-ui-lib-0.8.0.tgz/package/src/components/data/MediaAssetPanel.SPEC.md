# MediaAssetPanel

## Purpose

`MediaAssetPanel` is a presentational media and attachment management surface
for product-owned file collections. It represents asset stats, upload/dropzone
chrome, image/file cards, metadata badges, loading/error/empty states, selected
asset detail, and action slots without owning transport or persistence.

## Source Evidence

- Score `ui/src/features/board/components/TaskDetail.tsx` and
  `AttachmentTile.tsx` provide task attachment upload, image/document tiles,
  size metadata, authenticated URLs, and delete actions.
- eLitua `ui/src/pages/admin/pictures/PicturesPage.tsx`,
  `PictureEditPage.tsx`, and `ProfileEditPage.tsx` provide picture resource
  administration, profile upload affordances, file/picture metadata, and
  delete/update flows.

## Contract

- Accepts `assets`, optional `stats`, optional `upload`, status, actions,
  loading, error, `emptyLabel`, and selected-detail props. There is no
  standalone `empty` prop.
- Asset items provide their own `previewSrc`, links, metadata, badges, and
  action slots; product apps own authenticated asset URLs.
- `onAssetSelect` is controlled by the consuming app and never mutates state
  internally.
- A `disabled` asset is inert in every branch, not merely dimmed. The button
  takes the native `disabled` attribute; the link keeps its `<a>` and gains
  `role="link"` + `aria-disabled="true"` but **loses its `href`**, which is what
  removes it from the tab order and takes away its activation behaviour.
- Uses only `ui-media-asset*` CSS classes and shared token variables.

## Non-Goals

- No file input wiring, uploads, delete confirmations, validation, image
  processing, signed URL generation, GraphQL/DataProxy calls, task attachment
  rules, route updates, localization, or toast handling.
