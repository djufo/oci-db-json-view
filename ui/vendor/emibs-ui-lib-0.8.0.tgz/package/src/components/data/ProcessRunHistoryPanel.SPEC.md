# ProcessRunHistoryPanel

## Purpose

`ProcessRunHistoryPanel` is a controlled presentational timeline for recent
host-side or background process runs.

## Source Evidence

- Score's `ui/src/features/schedulers/containers/SchedulersContainer.tsx`
  renders a "Recent runs" list for each mapped scheduler using start time and
  exit-code state.
- Existing `SchedulerControlPanel` covers mapped-job cards and enablement, but
  it does not own a reusable run-history/timeline surface.

## Contract

- Runs, status labels, timestamps, exit codes, command text, summary, output,
  row metadata, and row actions are passed in through props; command and output
  text render through `PayloadBlock`.
- Exit-code rendering derives neutral labels when custom status props are not
  provided: `null` means running, `0` means succeeded, non-zero means failed.
- Header copy, status badge, loading/error/empty states, footer, density, and
  actions are controlled by the consuming app.

## Non-Goals

- No polling, process execution, log retention, command authorization,
  scheduler catalog validation, date formatting, output redaction, persistence,
  routing, toasts, or audit behavior.

## Review Expectations

- Long commands and output lines must scroll or wrap without expanding the
  panel beyond its container.
- Compact density must work inside scheduler cards or detail panels.
- Running, successful, failed, empty, loading, and error states must be visible
  in the catalog.
