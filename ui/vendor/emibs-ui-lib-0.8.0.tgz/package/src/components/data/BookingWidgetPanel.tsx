import { type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { StatusIndicator, type StatusIndicatorTone } from "../primitives/StatusIndicator";

export type BookingWidgetPanelBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type BookingWidgetPanelDetail = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
  tone?: BadgeTone;
};

export type BookingWidgetPanelStatus = {
  label: ReactNode;
  detail?: ReactNode;
  tone?: StatusIndicatorTone;
  icon?: ReactNode;
  action?: ReactNode;
};

export type BookingWidgetPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  provider?: ReactNode;
  providerLogo?: ReactNode;
  badges?: BookingWidgetPanelBadge[];
  details?: BookingWidgetPanelDetail[];
  status?: BookingWidgetPanelStatus;
  summary?: ReactNode;
  widget?: ReactNode;
  widgetLabel?: ReactNode;
  emptyWidgetLabel?: ReactNode;
  consentNotice?: ReactNode;
  fallback?: ReactNode;
  actions?: ReactNode;
  footer?: ReactNode;
  className?: string;
};

export function BookingWidgetPanel({
  title,
  eyebrow,
  subtitle,
  provider,
  providerLogo,
  badges = [],
  details = [],
  status,
  summary,
  widget,
  widgetLabel = "Booking widget",
  emptyWidgetLabel = "Booking widget preview is supplied by the consuming app.",
  consentNotice,
  fallback,
  actions,
  footer,
  className,
}: BookingWidgetPanelProps) {
  const eyebrowLabel = eyebrow ?? provider;

  return (
    <section className={cn("ui-booking-widget-panel", className)}>
      <header className="ui-booking-widget-panel__header">
        {providerLogo ? <div className="ui-booking-widget-panel__logo">{providerLogo}</div> : null}
        <div className="ui-booking-widget-panel__title-block">
          {eyebrowLabel ? <span className="ui-booking-widget-panel__eyebrow">{eyebrowLabel}</span> : null}
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
          {badges.length > 0 ? (
            <div className="ui-booking-widget-panel__badges">
              {badges.map((badge) => (
                <Badge key={badge.id} tone={badge.tone}>
                  {badge.label}
                </Badge>
              ))}
            </div>
          ) : null}
        </div>
        {actions ? <div className="ui-booking-widget-panel__actions">{actions}</div> : null}
      </header>

      {status ? (
        <StatusIndicator
          action={status.action}
          className="ui-booking-widget-panel__status"
          detail={status.detail}
          icon={status.icon}
          label={status.label}
          tone={status.tone}
          variant="bar"
        />
      ) : null}

      <div className="ui-booking-widget-panel__body">
        <div className="ui-booking-widget-panel__summary">
          {summary ? <div className="ui-booking-widget-panel__intro">{summary}</div> : null}
          {details.length > 0 ? <BookingWidgetDetails details={details} /> : null}
          {consentNotice ? <div className="ui-booking-widget-panel__notice">{consentNotice}</div> : null}
          {fallback ? <div className="ui-booking-widget-panel__fallback">{fallback}</div> : null}
        </div>

        <aside className="ui-booking-widget-panel__widget">
          <div className="ui-booking-widget-panel__widget-header">
            <span>{widgetLabel}</span>
            {provider ? <Badge tone="info">{provider}</Badge> : null}
          </div>
          <div className="ui-booking-widget-panel__widget-frame">
            {widget ?? <p className="ui-booking-widget-panel__empty">{emptyWidgetLabel}</p>}
          </div>
        </aside>
      </div>

      {footer ? <footer className="ui-booking-widget-panel__footer">{footer}</footer> : null}
    </section>
  );
}

export function BookingWidgetDetails({ details }: { details: BookingWidgetPanelDetail[] }) {
  return (
    <dl className="ui-booking-widget-panel__details">
      {details.map((detail) => (
        <div
          className={cn("ui-booking-widget-panel__detail", detail.tone && `ui-booking-widget-panel__detail--${detail.tone}`)}
          key={detail.id}
        >
          <dt>
            {detail.icon ? <span className="ui-booking-widget-panel__detail-icon">{detail.icon}</span> : null}
            {detail.label}
          </dt>
          <dd>{detail.value}</dd>
          {detail.description ? <small>{detail.description}</small> : null}
        </div>
      ))}
    </dl>
  );
}
