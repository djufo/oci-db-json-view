# ComponentPlaygroundPanel

`ComponentPlaygroundPanel` is a controlled presentational surface for previewing
one component with editable playground controls, a live stage, and a JSX snippet.
It was extracted from Score's Catalog Explorer playground tab so catalog apps can
review the pattern before replacing local page code.

## Contract

- Accepts caller-defined `controls`, `values`, and `onValueChange`; the consuming
  app owns schema defaults, registry lookups, route state, persistence, and
  validation.
- Renders boolean, enum/node, number, string, and multiline text controls with
  native form fields and visible labels.
- Accepts a caller-rendered `stage` slot; theme scopes, preview width, fixture
  rendering, and component-specific `renderWith` logic stay product-owned.
- Accepts a caller-rendered or string `snippet` plus optional copy/reset actions;
  clipboard writes, toasts, analytics, and permission checks stay product-owned.
- Supports header badges, action slots, footer copy, compact density, and
  configurable labels without encoding Score-specific catalog data.

## Accessibility

- The panel is labelled by its title, and each sub-panel is labelled by its
  visible heading.
- Every control is associated with a stable generated `id` and native `label`.
- Boolean controls use native checkboxes, select controls use native `select`,
  and copy/reset actions are ordinary buttons supplied through shared primitives.

## Boundaries

Do not move catalog registry discovery, markdown/spec parsing, preview theme
generation, responsive width state, clipboard side effects, or toast handling
into this component. It should remain a reviewable shell that product apps feed
with normalized playground data.
