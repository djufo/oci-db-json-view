# FilePreviewPanel

## Purpose

`FilePreviewPanel` is a presentational attachment preview surface for a single
file. It covers Score-style markdown attachment previews, download actions,
metadata rows, generic unsupported-file states, and caller-owned action slots.

## Contract

- Accepts a caller-supplied file record, preview kind, metadata, badges, actions,
  markdown text, and loading/error/empty labels.
- Renders markdown previews by composing `MarkdownDocumentPanel`; consumers own
  attachment fetching, authentication, MIME/extension detection, and sanitizer
  policy through the markdown panel boundary.
- Renders non-markdown files as a compact download-oriented fallback with title,
  type, metadata, badges, actions, loading, error, and unavailable-preview states.
- Provides an optional download control from `file.downloadHref` or an explicit
  `downloadAction`; consumers may hide it with `downloadAction={false}`.
- Uses `ui-file-preview*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/components/file-preview/FilePreviewPanel.tsx` renders markdown
  attachments through `MarkdownDocumentPanel`, includes a download action, and
  falls back to a generic unavailable preview for unsupported file types.
- Score `ui/src/components/file-preview/SPEC.md` says the local component should
  remain until UIF owns it.
- Score task detail and project profile attachment previews consume the local
  file preview surface while keeping attachment APIs, authenticated URLs,
  permissions, route links, and toasts local.

## Non-Goals

- No file fetching, upload handling, delete behavior, MIME allow-list policy,
  authenticated URL creation, route ownership, or toast/error side effects.
- No adoption into Score in this extraction; adoption is tracked by a
  low-priority UI Framework refactor task.
