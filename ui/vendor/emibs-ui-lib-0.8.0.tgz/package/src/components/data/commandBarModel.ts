import type { CommandPaletteGroup, CommandPaletteItem } from "../primitives/CommandPalette";

/**
 * CommandBar query grammar (UIF-E3, generalized from Score v4 G6). The command
 * bar extends the existing CommandPalette with three query modes:
 *   - `> <verb> <target>`  — a verb action, e.g. `> park issue-2098`.
 *   - an entity id         — a jump straight to that entity (matched by the
 *                            injected `matchEntity`, so the entity vocabulary is
 *                            the app's, not hardcoded here).
 *   - anything else        — free-text search over the navigation group.
 * Parsing is pure so it is unit-testable without a DOM. Verbs do not mutate from
 * the bar; selecting one calls `onVerb(verb, target)`, which the app routes to
 * its own write path (typically the target's inspector behind a blast-radius
 * confirm). This is additive over the app's navigation group — the palette
 * machinery is reused, never reimplemented.
 */

export type CommandVerb = {
  readonly id: string;
  readonly label: string;
  /** Consequence hint shown in the palette item description. */
  readonly description?: string;
};

/** Resolve a raw token to a canonical entity id, or null when it is not one. */
export type EntityMatcher = (raw: string) => string | null;

const ISSUE_PATTERN = /^(issue-\d+|\d+)$/i;

/**
 * The default entity matcher: a bare `1234` or `issue-1234` canonicalises to
 * `issue-1234`. Apps with a different id vocabulary pass their own matcher.
 */
export const issueEntityMatcher: EntityMatcher = (raw) => {
  const trimmed = raw.trim();
  if (!ISSUE_PATTERN.test(trimmed)) {
    return null;
  }
  return /^\d+$/.test(trimmed) ? `issue-${trimmed}` : trimmed.toLowerCase();
};

export type ParsedCommand =
  | { readonly kind: "verb"; readonly verb: string; readonly arg: string; readonly known: boolean }
  | { readonly kind: "entity"; readonly id: string }
  | { readonly kind: "search"; readonly text: string };

export type ParseOptions = {
  readonly verbs: readonly CommandVerb[];
  readonly matchEntity: EntityMatcher;
};

export function parseCommandQuery(query: string, options: ParseOptions): ParsedCommand {
  const trimmed = query.trim();
  if (trimmed.startsWith(">")) {
    const rest = trimmed.slice(1).trim();
    const [verb, ...argParts] = rest.split(/\s+/);
    const verbId = (verb ?? "").toLowerCase();
    const known = options.verbs.some((candidate) => candidate.id === verbId);
    return { kind: "verb", verb: verbId, arg: argParts.join(" ").trim(), known };
  }
  const entityId = options.matchEntity(trimmed);
  if (entityId) {
    return { kind: "entity", id: entityId };
  }
  return { kind: "search", text: trimmed };
}

export type CommandBarContext = {
  /** Navigate the app to a hash/route (drives entity jump + nav items). */
  readonly navigate: (hash: string) => void;
  /** Invoked when a verb action is chosen with the parsed (or empty) target. */
  readonly onVerb: (verb: string, targetId: string) => void;
  /** Route builder for an entity's detail/inspector. */
  readonly entityHref: (id: string) => string;
  /** Baseline navigation group (the existing palette navigation items). */
  readonly navigation: CommandPaletteGroup;
  /** The verbs available from `>`. */
  readonly verbs: readonly CommandVerb[];
  /** Entity id matcher; defaults to `issueEntityMatcher`. */
  readonly matchEntity?: EntityMatcher;
};

/**
 * Build the palette groups for a query. A verb query surfaces the matching
 * verb(s) applied to the parsed target; an entity query surfaces a jump item;
 * every query keeps the navigation group so the bar never dead-ends.
 */
export function buildCommandGroups(query: string, ctx: CommandBarContext): CommandPaletteGroup[] {
  const matchEntity = ctx.matchEntity ?? issueEntityMatcher;
  const parsed = parseCommandQuery(query, { verbs: ctx.verbs, matchEntity });
  const groups: CommandPaletteGroup[] = [];

  if (parsed.kind === "verb") {
    const target = parsed.arg ? matchEntity(parsed.arg) ?? parsed.arg : "";
    const verbs = parsed.known ? ctx.verbs.filter((verb) => verb.id === parsed.verb) : ctx.verbs;
    const items: CommandPaletteItem[] = verbs.map((verb) => ({
      id: `verb-${verb.id}`,
      label: target ? `${verb.label} ${target}` : `${verb.label}…`,
      description: verb.description,
      meta: target ? "run action" : "type a target id",
      disabled: target === "",
      onSelect: () => {
        if (target) {
          ctx.onVerb(verb.id, target);
        }
      },
    }));
    groups.push({ id: "verbs", title: "Actions", items, emptyLabel: "No matching verb" });
  }

  if (parsed.kind === "entity") {
    const href = ctx.entityHref(parsed.id);
    groups.push({
      id: "jump",
      title: "Jump to",
      items: [
        {
          id: `jump-${parsed.id}`,
          label: parsed.id,
          description: "Open",
          meta: href,
          onSelect: () => ctx.navigate(href),
        },
      ],
    });
  }

  groups.push(ctx.navigation);
  return groups;
}
