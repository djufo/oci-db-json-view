# GeoCoordinatePicker

Flat controlled coordinate editor, imported from
`emibs-ui-lib/components/data/GeoCoordinatePicker`.

| Prop | Behavior |
| --- | --- |
| `latitude` | Number in [-90, 90], or null |
| `longitude` | Number in [-180, 180], or null |
| `onChange` | Emits both coordinates; clearing a manual input emits null for that coordinate |
| `readOnly` | Defaults false. Locks manual fields and omits the adapter's selection callback |
| `mapAdapter` | Optional AddressMapAdapter; its View receives the current point and read-only state |

Manual entry remains available without a map. Non-finite or out-of-range picks
and manual edits are ignored. An incomplete or invalid controlled pair sends
null to the map, clearing its selection. Zero and boundary coordinates are valid.

The map starts hidden. The toggle's title, accessible name, expanded state and
controlled-region id stay in sync. Showing the map mounts the adapter inside
MapViewport; hiding it unmounts the adapter. Without an adapter, showing it
explains how to enter coordinates manually. Read-only mode still allows viewing.
Instances own their visibility and unique region/field ids independently.

The map viewport has no extra surface chrome in this composition. Address and
coordinate layouts use parent gaps and theme tokens, wrap to one column on
narrow containers, and reuse Field/Input/Button accessibility and touch targets.

See [AddressField](AddressField.SPEC.md) for adapter and consumer boundaries.
`tests/primitives/addressField.test.tsx` covers the picker contract with a fake
adapter, without a provider SDK or network calls.
