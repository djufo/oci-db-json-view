# MetricGrid

## Purpose

`MetricGrid` is a presentational label/value/detail tile grid for operational,
admin, account, integration, and public-summary metrics. It makes the repeated
metric-card grammar reusable without owning data loading, formatting, polling,
threshold calculation, routing, or analytics.

## Source Evidence

- Score `ui/src/features/live-activity/components/ActivityDashboardView.tsx`
  maps worker queue and scheduler metrics into tile data.
- eLitua `ui/src/pages/account/bokun/BókunPage.tsx` renders integration detail
  status, channel, sync, and provider tiles.
- eLitua payment/profile/public surfaces repeat comparable summary and stat
  grids through local page components and existing shared panel slots.

Existing catalog coverage was checked first: `StatusStrip` covers a compact
overview strip, while `ActivityDashboard`, `AdminHomePanel`,
`IntegrationSetupPanel`, `PaymentAccountPanel`, `PublicProfilePage`, and other
larger panels embed metric tiles inside product-specific shells. No standalone
component owns a reusable metric grid primitive.

## Contract

- Accepts controlled `items` with `label`, `value`, optional `detail`, icon, and
  tone.
- Renders semantic `dl`/`dt`/`dd` markup for non-interactive metrics.
- Supports compact and comfortable density plus auto, 2, 3, and 4 column modes.
- Renders an empty state when no metrics are supplied.
- Uses only `ui-metric-grid*` CSS classes and shared token variables.
- Product-specific panels may compose `MetricGrid` for their metric slots while
  keeping product polling, threshold calculation, API mapping, routes, actions,
  toasts, and formatting in the consuming app.

## Non-Goals

- No fetch/polling behavior, number/date/currency formatting, trend
  calculation, alert thresholds, route navigation, analytics, localization, or
  product status policy.
