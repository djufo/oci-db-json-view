import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { AuditTimeline, type AuditEntry } from "./AuditTimeline";

const ENTRIES: AuditEntry[] = [
  { id: "e1", time: "12:04", title: "Approved", actor: "agent-codex-reviewer", tone: "success", kind: "disposition" },
  { id: "e2", time: "12:31", title: "Lease taken", actor: "agent-claude-dev", tone: "info", kind: "lease", href: "#/lease/1" },
];

describe("AuditTimeline", () => {
  it("renders the empty state note when there are no entries", () => {
    const html = renderToStaticMarkup(<AuditTimeline entries={[]} emptyLabel="No history" />);
    expect(html).toContain("ui-audit-timeline__empty");
    expect(html).toContain("No history");
  });

  it("renders an ordered list with a tick tone per entry", () => {
    const html = renderToStaticMarkup(<AuditTimeline entries={ENTRIES} />);
    expect(html).toContain("<ol");
    expect(html).toContain('data-tone="success"');
    expect(html).toContain('data-tone="info"');
  });

  it("keeps time, actor, and kind columns for alignment + mono actor", () => {
    const html = renderToStaticMarkup(<AuditTimeline entries={ENTRIES} />);
    expect(html).toContain("ui-audit-timeline__time");
    expect(html).toContain("ui-audit-timeline__actor");
    expect(html).toContain("agent-codex-reviewer");
    expect(html).toContain("ui-audit-timeline__kind");
  });

  it("links the title when an href is provided", () => {
    const html = renderToStaticMarkup(<AuditTimeline entries={[ENTRIES[1]]} />);
    expect(html).toContain('href="#/lease/1"');
  });

  it("defaults an untoned entry to the neutral tick", () => {
    const html = renderToStaticMarkup(<AuditTimeline entries={[{ id: "x", time: "now", title: "Created" }]} />);
    expect(html).toContain('data-tone="neutral"');
  });
});
