import { type ChangeEvent, type ReactNode } from "react";
import { LayoutGrid, Search } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type ComponentCatalogBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type ComponentCatalogItem = {
  id: string;
  label: ReactNode;
  meta?: ReactNode;
  description?: ReactNode;
  href?: string;
  active?: boolean;
  disabled?: boolean;
  badges?: ComponentCatalogBadge[];
  onSelect?: () => void;
};

export type ComponentCatalogSearch = {
  value: string;
  label?: string;
  placeholder?: string;
  resultMeta?: ReactNode;
  onChange?: (value: string) => void;
};

export type ComponentCatalogPanelProps = {
  title: ReactNode;
  description?: ReactNode;
  eyebrow?: ReactNode;
  icon?: ReactNode;
  badges?: ComponentCatalogBadge[];
  actions?: ReactNode;
  search?: ComponentCatalogSearch;
  navigationTitle?: ReactNode;
  navigationDescription?: ReactNode;
  navigationLabel?: string;
  items: ComponentCatalogItem[];
  emptyItemsLabel?: ReactNode;
  sidebar?: ReactNode;
  sidebarFooter?: ReactNode;
  children: ReactNode;
  density?: "compact" | "comfortable";
  className?: string;
};

export function ComponentCatalogPanel({
  title,
  description,
  eyebrow,
  icon,
  badges = [],
  actions,
  search,
  navigationTitle = "Components",
  navigationDescription,
  navigationLabel = "Catalog components",
  items,
  emptyItemsLabel = "No catalog entries match these filters.",
  sidebar,
  sidebarFooter,
  children,
  density = "comfortable",
  className,
}: ComponentCatalogPanelProps) {
  return (
    <section className={cn("ui-component-catalog", `ui-component-catalog--${density}`, className)}>
      <header className="ui-component-catalog__header">
        <div className="ui-component-catalog__title-row">
          <span className="ui-component-catalog__icon" aria-hidden="true">
            {icon ?? <LayoutGrid size={19} />}
          </span>
          <div className="ui-component-catalog__title-block">
            {eyebrow ? <span className="ui-component-catalog__eyebrow">{eyebrow}</span> : null}
            <h2>{title}</h2>
            {description ? <p>{description}</p> : null}
          </div>
        </div>
        {badges.length > 0 || actions ? (
          <div className="ui-component-catalog__header-actions">
            {badges.map((badge) => (
              <Badge key={badge.id} tone={badge.tone}>
                {badge.label}
              </Badge>
            ))}
            {actions}
          </div>
        ) : null}
      </header>

      <div className="ui-component-catalog__body">
        <aside className="ui-component-catalog__sidebar" aria-label={navigationLabel}>
          <div className="ui-component-catalog__nav-card">
            <div className="ui-component-catalog__nav-header">
              <div>
                <h3>{navigationTitle}</h3>
                {navigationDescription ? <p>{navigationDescription}</p> : null}
              </div>
              {search?.resultMeta ? <Badge tone="info">{search.resultMeta}</Badge> : null}
            </div>
            {search ? <ComponentCatalogSearchField search={search} /> : null}
            <div className="ui-component-catalog__items">
              {items.length > 0 ? (
                items.map((item) => <ComponentCatalogItemView item={item} key={item.id} />)
              ) : (
                <p className="ui-component-catalog__empty">{emptyItemsLabel}</p>
              )}
            </div>
          </div>

          {sidebar ? <div className="ui-component-catalog__side-panel">{sidebar}</div> : null}
          {sidebarFooter ? <div className="ui-component-catalog__sidebar-footer">{sidebarFooter}</div> : null}
        </aside>

        <main className="ui-component-catalog__content">{children}</main>
      </div>
    </section>
  );
}

function ComponentCatalogSearchField({ search }: { search: ComponentCatalogSearch }) {
  const label = search.label ?? "Search catalog";
  const handleChange = (event: ChangeEvent<HTMLInputElement>) => {
    search.onChange?.(event.currentTarget.value);
  };

  return (
    <label className="ui-component-catalog__search">
      <span>{label}</span>
      <span className="ui-component-catalog__search-control">
        <Search size={15} aria-hidden="true" />
        <input
          aria-label={label}
          placeholder={search.placeholder}
          type="search"
          value={search.value}
          onChange={handleChange}
        />
      </span>
    </label>
  );
}

function ComponentCatalogItemView({ item }: { item: ComponentCatalogItem }) {
  const className = cn(
    "ui-component-catalog__item",
    item.active && "is-active",
    item.disabled && "is-disabled",
  );
  const content = (
    <>
      <span className="ui-component-catalog__item-copy">
        <span>{item.label}</span>
        {item.meta ? <small>{item.meta}</small> : null}
        {item.description ? <small>{item.description}</small> : null}
      </span>
      {item.badges?.length ? (
        <span className="ui-component-catalog__item-badges">
          {item.badges.map((badge) => (
            <Badge key={badge.id} tone={badge.tone}>
              {badge.label}
            </Badge>
          ))}
        </span>
      ) : null}
    </>
  );

  if (item.href && !item.disabled) {
    return (
      <a
        aria-current={item.active ? "page" : undefined}
        className={className}
        href={item.href}
        onClick={item.onSelect}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      aria-pressed={item.active && !item.href ? true : undefined}
      className={className}
      disabled={item.disabled}
      type="button"
      onClick={item.onSelect}
    >
      {content}
    </button>
  );
}
