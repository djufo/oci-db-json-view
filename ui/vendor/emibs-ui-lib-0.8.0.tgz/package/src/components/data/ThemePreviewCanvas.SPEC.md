# ThemePreviewCanvas

Presentational theme preview canvas extracted from Score Catalog Explorer:

- current/single fixture preview canvas;
- generated light/dark theme preview surfaces;
- side-by-side comparison surfaces for product-owned theme scopes.

## Contract

- `mode` selects `single`, `generated`, or `compare` rendering.
- `generatedSurfaces` and `compareSurfaces` describe the preview scopes with
  label, badge, optional icon, className, style, and accessible label.
- `children` can be a React node reused across surfaces or a render function
  receiving the active surface and index.
- `canvasWidth` constrains the fixture width inside each preview surface.
- `minWidth` preserves Score's horizontally scrollable multi-surface review
  canvas without forcing consuming apps to use a fixed page layout.

## Boundaries

- No theme generation API calls, prompt state, persistence, registry loading,
  routing, analytics, permission checks, or toast behavior.
- No component fixture selection, variant state, or generated-token validation.
- Consuming apps own concrete token maps, theme class names, URL state, and
  adoption workflow.

## Source

- Score: `projects/score/ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  `CatalogCanvas` current/generated/compare preview branches.

## Adoption Notes

- Score can later replace the local `CatalogCanvas` shell with
  `ThemePreviewCanvas` while keeping `ThemeProposal`, `ThemePreviewMode`,
  variant rendering, `themeStyle`, and `catalogThemeScopes` in Score.
