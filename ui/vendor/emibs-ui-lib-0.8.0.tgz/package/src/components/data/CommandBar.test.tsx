// @vitest-environment happy-dom
import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import { CommandBar, type CommandBarProps } from "./CommandBar";
import type { CommandPaletteGroup } from "../primitives/CommandPalette";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const navigation: CommandPaletteGroup = {
  id: "nav",
  title: "Go to",
  items: [{ id: "board", label: "Board", meta: "#/board", href: "#/board" }],
};

const verbs = [{ id: "park", label: "Park", description: "Park it" }];

/**
 * `useId` values carry React's per-render-tree counter, so they legitimately
 * differ between test orders. Everything else in the markup is the component's
 * own output and must not move.
 */
function normalizeIds(markup: string): string {
  return markup.replace(/_r_[0-9a-z]+_/g, "_rN_");
}

/**
 * The uncontrolled markup as CommandBar emitted it BEFORE it took any
 * controlled props (uif/issue-4678), captured from the component at
 * 14eea8ea and pasted here verbatim. The owner's constraint on that change was
 * that a caller passing neither `open` nor `query` must behave byte-identically
 * afterwards; these two strings are what "byte-identically" means, so a
 * regression shows up as a diff rather than as a judgement call.
 */
const CLOSED_MARKUP =
  '<div class="ui-command-bar"><span class="ui-command-bar__brand">SCORE</span>' +
  '<button aria-haspopup="dialog" aria-label="Open command bar (Cmd or Ctrl K)" class="ui-command-bar__field" type="button">' +
  '<span class="ui-command-bar__hint">Jump, act, or search…</span><kbd class="ui-command-bar__kbd">⌘K</kbd></button>' +
  '<div class="ui-command-bar__status"><span>strip</span></div></div>';

const OPEN_MARKUP =
  '<div class="ui-command-bar"><span class="ui-command-bar__brand">SCORE</span>' +
  '<button aria-haspopup="dialog" aria-label="Open command bar (Cmd or Ctrl K)" class="ui-command-bar__field" type="button">' +
  '<span class="ui-command-bar__hint">Jump, act, or search…</span><kbd class="ui-command-bar__kbd">⌘K</kbd></button>' +
  '<div class="ui-command-bar__status"><span>strip</span></div>' +
  '<div class="ui-command-palette-layer ui-command-palette-layer--fixed">' +
  '<button aria-label="Close command bar" class="ui-command-palette__overlay" type="button"></button>' +
  '<section aria-label="Command bar" aria-modal="true" class="ui-command-palette ui-command-palette--fixed" role="dialog">' +
  '<header class="ui-command-palette__header">' +
  '<svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-search" aria-hidden="true">' +
  '<circle cx="11" cy="11" r="8"></circle><path d="m21 21-4.3-4.3"></path></svg>' +
  '<input aria-autocomplete="list" aria-controls="_rN_-results" aria-expanded="true" aria-haspopup="listbox" aria-label="Command palette search" class="ui-command-palette__input" placeholder="Jump to an entity, run a verb (> …), or search" role="combobox" type="search" value="" aria-activedescendant="ui-command-palette-item-nav-board-0">' +
  '<span class="ui-command-palette__shortcut">⌘K</span>' +
  '<button aria-label="Close command bar" class="ui-command-palette__close" data-command-palette-close="" type="button">' +
  '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-x" aria-hidden="true">' +
  '<path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg></button></header>' +
  '<div class="ui-command-palette__body" id="_rN_-results"><section class="ui-command-palette__group"><h3>Go to</h3>' +
  '<div class="ui-command-palette__group-list" role="listbox">' +
  '<a aria-selected="true" class="ui-command-palette__item is-highlighted" href="#/board" id="ui-command-palette-item-nav-board-0" role="option">' +
  '<span class="ui-command-palette__item-copy"><span class="ui-command-palette__item-label">Board</span></span>' +
  '<span class="ui-command-palette__item-meta">#/board</span></a></div></section></div></section></div></div>';

describe("CommandBar", () => {
  let container: HTMLDivElement;
  let root: ReturnType<typeof createRoot>;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
  });

  const renderBar = async (props: Partial<CommandBarProps> = {}) => {
    await act(async () => {
      root.render(
        <CommandBar
          brand="SCORE"
          entityHref={(id) => `#/issue/${id}`}
          navigate={() => undefined}
          navigation={navigation}
          onVerb={() => undefined}
          statusStrip={<span>strip</span>}
          verbs={verbs}
          {...props}
        />,
      );
    });
  };

  const typeQuery = async (value: string) => {
    const input = container.querySelector<HTMLInputElement>("input.ui-command-palette__input");
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
    await act(async () => {
      setter?.call(input, value);
      input?.dispatchEvent(new window.Event("input", { bubbles: true }));
    });
  };

  it("emits byte-identical markup, closed and open, when neither open nor query is passed", async () => {
    await renderBar();
    expect(normalizeIds(container.innerHTML)).toBe(CLOSED_MARKUP);

    await act(async () => {
      container
        .querySelector<HTMLButtonElement>("button.ui-command-bar__field")
        ?.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    });
    expect(normalizeIds(container.innerHTML)).toBe(OPEN_MARKUP);
  });

  it("keeps the whole uncontrolled lifecycle — shortcut, typing, select, reopen", async () => {
    const navigated: string[] = [];
    const verbCalls: [string, string][] = [];
    await renderBar({
      navigate: (hash) => navigated.push(hash),
      onVerb: (verb, target) => verbCalls.push([verb, target]),
    });

    // ⌘K opens from outside any field.
    await act(async () => {
      window.dispatchEvent(new window.KeyboardEvent("keydown", { key: "k", metaKey: true, bubbles: true }));
    });
    expect(container.querySelector("section.ui-command-palette")).not.toBeNull();
    expect(container.querySelector<HTMLInputElement>("input.ui-command-palette__input")?.value).toBe("");

    // Typing a verb query reaches the verb grammar and firing it closes the bar.
    await typeQuery("> park issue-2098");
    const verbItem = container.querySelector<HTMLElement>("[id^='ui-command-palette-item-verbs-verb-park']");
    expect(verbItem?.textContent).toContain("Park issue-2098");
    await act(async () => {
      verbItem?.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    });
    expect(verbCalls).toEqual([["park", "issue-2098"]]);
    expect(container.querySelector("section.ui-command-palette")).toBeNull();

    // Reopening from the trigger clears the previous query.
    await act(async () => {
      container
        .querySelector<HTMLButtonElement>("button.ui-command-bar__field")
        ?.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    });
    expect(container.querySelector<HTMLInputElement>("input.ui-command-palette__input")?.value).toBe("");

    // An entity query jumps through navigate() and closes.
    await typeQuery("2098");
    const jumpItem = container.querySelector<HTMLElement>("[id^='ui-command-palette-item-jump-jump-issue-2098']");
    expect(jumpItem).not.toBeNull();
    await act(async () => {
      jumpItem?.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    });
    expect(navigated).toEqual(["#/issue/issue-2098"]);
    expect(container.querySelector("section.ui-command-palette")).toBeNull();
    expect(navigated.length + verbCalls.length).toBe(2);
  });

  it("honours defaultOpen and defaultQuery as uncontrolled seeds", async () => {
    await renderBar({ defaultOpen: true, defaultQuery: "issue-2098" });
    expect(container.querySelector<HTMLInputElement>("input.ui-command-palette__input")?.value).toBe("issue-2098");
    expect(container.querySelector("[id^='ui-command-palette-item-jump-']")).not.toBeNull();

    // A seed is a starting point, not a lock: the bar still owns the value.
    await typeQuery("board");
    expect(container.querySelector("[id^='ui-command-palette-item-jump-']")).toBeNull();
  });

  it("lets a controlled open/query pair drive the palette and reports every change", async () => {
    const opens: boolean[] = [];
    const queries: string[] = [];
    await renderBar({
      open: true,
      query: "> park issue-2098",
      onOpenChange: (next) => opens.push(next),
      onQueryChange: (next) => queries.push(next),
    });

    expect(container.querySelector<HTMLInputElement>("input.ui-command-palette__input")?.value).toBe("> park issue-2098");

    // Controlled without a rerender: the request is reported, the value stays.
    await typeQuery("issue-2098");
    expect(queries).toEqual(["issue-2098"]);
    expect(container.querySelector<HTMLInputElement>("input.ui-command-palette__input")?.value).toBe("> park issue-2098");

    await act(async () => {
      container
        .querySelector<HTMLButtonElement>("button.ui-command-palette__close")
        ?.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    });
    expect(opens).toEqual([false]);
    expect(container.querySelector("section.ui-command-palette")).not.toBeNull();

    // …until the caller supplies the next value.
    await renderBar({ open: false, query: "", onOpenChange: (next) => opens.push(next) });
    expect(container.querySelector("section.ui-command-palette")).toBeNull();
  });

  it("controls each half independently — a controlled query with an uncontrolled open", async () => {
    await renderBar({ query: "issue-2098", onQueryChange: () => undefined });

    expect(container.querySelector("section.ui-command-palette")).toBeNull();
    await act(async () => {
      container
        .querySelector<HTMLButtonElement>("button.ui-command-bar__field")
        ?.dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    });
    // Open moved on its own; the caller-owned query did not get cleared.
    expect(container.querySelector("section.ui-command-palette")).not.toBeNull();
    expect(container.querySelector<HTMLInputElement>("input.ui-command-palette__input")?.value).toBe("issue-2098");
  });

  it("reaches all three query modes through props alone", async () => {
    const modeGroups = async (query: string) => {
      await renderBar({ open: true, query, onQueryChange: () => undefined, placement: "contained", autoFocus: false });
      return Array.from(container.querySelectorAll("section.ui-command-palette__group h3")).map(
        (heading) => heading.textContent,
      );
    };

    expect(await modeGroups("> park issue-2098")).toEqual(["Actions", "Go to"]);
    expect(await modeGroups("issue-2098")).toEqual(["Jump to", "Go to"]);
    expect(await modeGroups("board")).toEqual(["Go to"]);
  });
});
