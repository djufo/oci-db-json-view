# ThemeLabPanel

## Purpose

`ThemeLabPanel` captures Score Catalog Explorer's Theme Lab review chrome:
prompt and iteration controls, generate/apply actions, proposal summary,
model/status badges, contrast guardrails, and swatch previews before apply.

The component is presentational. It does not call model APIs, persist tokens,
write CSS variables, or decide whether a proposal can be applied.

## Contract

- Consumers pass controlled prompt and optional iteration text-area controls.
- Consumers may pass a refinement context summary so users can see the current
  generated proposal and kept edits that the next iteration request should
  preserve.
- Consumers pass generate/apply action descriptors and own disabled, busy, and
  click behavior. The two are different states (`src/theme/STATES.md` rule 5):
  `disabled` takes the native attribute and is not focusable, while a `busy`
  action stays **focusable**, announces `aria-busy="true"`, and has its
  activation blocked in the handler instead.
- Consumers pass a proposal with rationale, badges, swatch groups, and optional
  contrast guardrails and footer content. A generated proposal is previewed in
  this review surface before any apply action is enabled by the product.
- The empty proposal state is explicit so API-backed products can show a stable
  review surface before the first response.
- `buildVibeThemePrompt` and `vibeThemeProposalFromJson` provide the pure model
  boundary for prompt-to-token-set flows: the prompt contract pins
  `claude-opus-4-8`, requires exactly 16 proposed tokens for both light and dark
  modes, validates the returned JSON, expands it into full `EmibsTheme` maps,
  and computes contrast summaries for preview guardrails.

## Product-Owned Behavior

Score keeps the theme generation API call, prompt validation, previous-proposal
iteration payload, manual edit merge semantics, model/provider selection,
preview application, persistence, portable artifact export/import, token
vocabulary, route state, analytics, permissions, and toast behavior. Generated
themes can be normalized with `vibeThemeProposalFromJson` and checked with
`evaluateThemeContrast` before proposal application; the panel only renders
normalized guardrail results.

Other products keep their own theme provider, token naming, localization, and
save/export flows.

## Accessibility

- Prompt and iteration controls render visible labels and optional
  `aria-describedby` descriptions.
- Refinement context rows render text labels next to badges, so preserved state
  is not represented by color alone.
- Generate/apply actions are native buttons.
- Swatches expose labels that include group, token label, and value so color is
  not the only information.
- Header and proposal headings are semantic and responsive.
