# ThemeExportPanel

## Purpose

`ThemeExportPanel` captures Score Catalog Explorer's Theme Lab export controls:
format selection, copy/download command rows, export-scope badges, and an
optional generated output preview for a portable `emibs-theme/1` artifact.

The component is presentational. It does not serialize theme tokens, read CSS
custom properties, touch the clipboard, create downloads, persist a theme, or
apply preview CSS.

## Contract

- Consumers pass controlled `formats` and `activeFormatId` values.
- Consumers pass copy/download/custom action descriptors and own disabled,
  busy, and click behavior.
- Consumers may pass a string preview, arbitrary preview node, or no preview.
- Badges communicate product-owned export scope, selected theme, or review
  state.

## Product-Owned Behavior

Score keeps theme-token serialization, portable-artifact import/export, CSS
selector construction, generated theme mapping, local Score theme reading,
clipboard writes, browser downloads, toast messages, route state, analytics,
permissions, and Theme Lab API state.

Other products keep their own token vocabularies, file formats, localization,
import/export persistence, and design-system adoption decisions.

## Accessibility

- The format selector is a labelled button group with `aria-pressed` on the
  active format.
- Export actions are native buttons and expose caller-supplied disabled/busy
  states. Per `src/theme/STATES.md` rule 5 these are different states: only
  `disabled` takes the native `disabled` attribute, while a `busy` action stays
  **focusable**, announces `aria-busy="true"`, and blocks its own re-activation
  in the handler.
- String previews render in `pre > code` while custom preview nodes remain
  caller-owned.
- The panel wraps long token values and command labels without horizontal page
  overflow.
