# AddressField

Controlled, flat address editor extracted from eLitua's shared AddressField.
The page owns its surface, state, saving, validation and organization context.

## Contract

Import from `emibs-ui-lib/components/data/AddressField` and load
`emibs-ui-lib/styles.css`. The module exports `AddressField`, its props and
`AddressValue`, `AddressMapAdapter`, `MapAdapterViewProps` and `GeoPoint` types.

| Prop | Behavior |
| --- | --- |
| `value` | Complete `AddressValue`: street, number, city, postcode, countryCode, nullable latitude/longitude, optional id, private and canEdit metadata |
| `onChange` | Emits a complete value for manual edits, map picks, geocoding or an existing-address selection; never persists |
| `canEdit` | Defaults to value.canEdit, then true. False locks fields and coordinates; existing-address selection remains available |
| `readOnly` | Defaults false. Locks fields, coordinates, geocoding and existing-address selection; map viewing remains available |
| `searchAddresses` | Optional `(query, signal) => Promise<AddressValue[]>`; caller owns API and permissions. Query limited to 128 characters; renders at most 50 results |
| `mapAdapter` | Optional provider-neutral map view and optional geocode callback; absent means manual coordinates still work |
| `countryLabel` | Display name for countryCode, defaulting to the code. Country is controlled by the consumer and displayed read-only |

Text bounds retain the original editor contract: street 127 characters; number,
city and postcode 31 each. Coordinate behavior is owned by
[GeoCoordinatePicker](GeoCoordinatePicker.SPEC.md).
Search results preserve the selected id and metadata without creating a record.
Search is explicit, supports Enter without submitting a containing form, aborts
on query/callback/readOnly changes and unmount, and ignores cancelled responses.
Search errors show fixed safe text. Changing a query clears old results/errors.

## Map adapter

`AddressMapAdapter.View` is a stable React component accepting a controlled
`point: GeoPoint | null`, `readOnly`, and optional `onPick(point)`. Null means
clear the selected point. The adapter owns its SDK, loading/errors, provider
configuration and resource cleanup; the library owns the surrounding
[MapViewport](../layout/MapViewport.SPEC.md). The adapter must fit that viewport
and disable selection when onPick is absent. No provider, API key, shared map
context, browser storage or network request is supplied by the library.

Optional `geocode(query, signal)` returns a point or null. The explicit
“Locate address” action supplies the comma-separated address fields and country
code. It runs only when editable; pending work is cancelled when the value,
callback or permission changes, or on unmount. Invalid/no-match results and
failures show fixed text and keep manual entry available. Late cancelled
responses never emit changes. No reverse geocoding or automatic address rewrite.

```tsx
import { AddressField, type AddressMapAdapter } from "emibs-ui-lib/components/data/AddressField";

const adapter: AddressMapAdapter = { View: ApplicationMap, geocode: lookupPoint };
<AddressField value={address} onChange={setAddress} mapAdapter={adapter}
  countryLabel="Lithuania" searchAddresses={searchExisting} />;
```

## Consumer boundary

Ownership props are presentation hints. Consumers must authorize searches,
reads and writes on their server and validate all values there. Optional id,
private and canEdit fields are carried through without interpreting ownership.
The library neither stores nor logs addresses. Consumers own the lawful basis,
disclosure, access, retention and erasure of any personal address data. Supplying
search or geocoding callbacks explicitly opts into the consumer's chosen data
recipient; no data leaves the component by default. Catalog data is synthetic.

The eLitua consumer change owns replacing its local implementation and updating
its supplier-listing-model section 23; that repository is outside this release.

## Proof

`tests/primitives/addressField.test.tsx` exercises manual/no-map mode, existing
selection, permissions, cancellation, safe failures, adapter points and
geocoding. `tests/catalog/addressCatalog.test.tsx` verifies editable, read-only
and no-map variants. Both components have explorer entries, props, usage,
states and demos.

The native Python Playwright smoke `tests/browser/address_field_smoke.py`
checks live editing, point selection, the three modes, light/dark and mobile
layout, touch height and browser errors. After building, serve `dist` locally
and run it with the base URL and an optional screenshot directory (requires
Python Playwright and Chromium).
