# CommandConsole

## Purpose

Reusable operator command surface for prompt-driven workflows: session rail,
terminal-style transcript, queued-work links, working state, and prompt composer.

## Contract

- `CommandConsole` is presentational and does not create tasks, store sessions,
  fetch transcripts, parse commands, or own routing.
- Sessions, messages, draft text, submitting state, links, actions, and labels
  are controlled by props.
- Transcript links require concrete `href` values. Product route adapters and
  permissions stay in the consuming app.
- The prompt composer emits `onDraftChange` and `onSubmit`; consuming apps own
  validation beyond non-empty draft and busy-state disabling.
- The component keeps a stable two-pane layout on desktop and stacks the session
  list above the terminal on narrow screens.

## Source

- `/engineering/projects/score/ui/src/features/maestro-chat/containers/MaestroChatContainer.tsx`
- `/engineering/projects/score/ui/src/styles.css`

## Return Path

After review, Score can replace its local Maestro chat chrome with
`CommandConsole` while keeping session persistence, task creation, API calls,
toast behavior, route ownership, and live refresh logic in Score.
