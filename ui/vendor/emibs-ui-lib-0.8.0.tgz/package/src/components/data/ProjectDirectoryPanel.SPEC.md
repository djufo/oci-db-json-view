# ProjectDirectoryPanel

## Purpose

`ProjectDirectoryPanel` is a presentational Score project directory surface for
the public `#/projects` route: title/status chrome, loading/error/empty states,
and a responsive grid of project cards with key, description, metadata badges,
and open affordances.

## Contract

- Accepts preformatted project items, badges, header status, actions, and state
  labels from the consuming app.
- Renders item links when `href` is supplied, selection buttons when
  `onItemSelect` is supplied, or read-only cards when neither exists.
- Keeps project loading, route parsing, API calls, permission checks, project
  sorting, metadata derivation, toasts, and hash/Router adapters in the product.
- Uses `ui-project-directory*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/features/projects/containers/ProjectsContainer.tsx` renders the
  route-level project directory when no `projectKey` route parameter is active.
- The directory is distinct from `ProjectProfilePanel`, which covers one
  project detail route, and from `ResourceIndexPanel`, which covers admin
  resource lists with selection/order controls.
- eLitua was inspected for larger remaining layout patterns; its entity grids
  and public portal layouts are already represented by existing catalog entries.

## Non-Goals

- No Score project API client, project sorting, access filtering, route
  construction, repository URL normalization, attachment handling, or adoption
  into Score in this extraction.
