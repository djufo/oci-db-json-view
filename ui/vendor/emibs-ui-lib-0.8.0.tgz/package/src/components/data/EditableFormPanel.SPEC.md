# EditableFormPanel Spec

## Goal

Provide a presentational editable form shell for dense operator and admin
screens before product apps adopt it.

## Source Pressure

- Score project and settings pages use repeated header/action chrome, autosave
  status, field grids, text areas, and definition-of-done checklist editors.
- eLitua geo and guide admin edit surfaces use repeated compact edit panels,
  action strips, geocode result lists, status messages, and dense field rows.
- Current eLitua admin `GeoForm` implementations pass selectable geocode
  candidates through local `EditableFormResultList` rows so choosing a result
  can update coordinates and map pins.

## Contract

- `EditableFormPanel` renders a form shell with title, subtitle, badges,
  messages, action slot, sections, optional body, and footer.
- Sections accept presentational field descriptors. Consuming apps own field
  state, validation, submission, autosave, API calls, translations, and route
  behavior.
- `EditableFormActionStrip`, `EditableFormResultList`, and `EditableChecklist`
  provide reviewable helper markup for common admin form subpatterns.
- `EditableChecklist` rows are interactive when a toggle handler resolves for
  them: the item's own `onToggle(checked)`, or the list-level
  `onToggle(id, checked)`. Checked state stays caller-owned; the component holds
  no state.
- A row with no toggle handler, or `disabled: true`, renders `disabled` and
  `aria-readonly`. `readOnly` alone is inert on a checkbox — the box still took
  clicks and React reverted them — so an unhandled row must not advertise an
  affordance it does not have.
- `EditableFormResultList` rows may expose `onSelect`, selected state,
  disabled state, and trailing action slots for geocoding or lookup candidate
  pickers.
- Styling uses catalog tokens and avoids project-specific class names.

## Non-Goals

- No validation schema, persistence, debouncing, geocoding, map mutation, or
  checklist business rules.
- No product-specific form field registry.

## Review Expectations

- Comfortable and compact density must both work inside existing catalog
  layouts.
- Long labels, JSON text areas, and action rows must not overflow on mobile.
