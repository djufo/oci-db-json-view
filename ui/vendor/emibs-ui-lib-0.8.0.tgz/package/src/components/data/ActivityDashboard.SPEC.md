# ActivityDashboard

## Purpose

Reusable operator activity surface for products that need live queue status,
orchestration metrics, transient errors, and a recent-work feed in one reviewable
dashboard.

## Contract

- `ActivityDashboard` is presentational and does not fetch, poll, persist, route,
  claim work, or subscribe to realtime updates.
- Queue counts, metrics, feed items, status labels, errors, and actions are
  supplied by props so consuming apps keep workflow semantics local.
- Feed item links require concrete `href` values. Router adapters stay in the
  consuming app.
- Counts and metrics accept preformatted values so products can decide date,
  duration, number, and capacity formatting.

## Source

- `/engineering/projects/score/ui/src/features/live-activity/components/ActivityBar.tsx`
- `/engineering/projects/score/ui/src/features/live-activity/components/ActivityFeed.tsx`
- `/engineering/projects/score/ui/src/features/live-activity/components/StatusStrip.tsx`
- `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`

## Non-Goals

- No Score API client, refresh timer, websocket wiring, task sorting, workflow
  transitions, task claiming, toast handling, or authorization.
- No product-specific status machine or relative-time calculation.

## Review Expectations

- Queue badges, metrics, and feed rows remain readable at narrow widths.
- Empty and error states are visible without requiring a live Score backend.
- The component can sit inside `WorkspaceShell` or another app-owned page shell.
