# CommandBar

## Purpose

`CommandBar` is the top command bar: an optional brand mark, the ⌘K command
field, and a status-strip slot. It extends the existing `CommandPalette`
primitive so ⌘K reaches every entity (jump) and every verb (`> park issue-…`) in
addition to navigation — one palette, three query modes.

## Source Evidence

- Score `requirements/v4/ui` (SPEC V4-1 / G6): the shell's command bar reuses the
  existing palette, extended with entity jump, field-query search, and `>` verb
  actions; ⌘K reaches every entity and every action in the spec.
- Score's v4 `CommandBar.tsx` + `commandBar.ts` hardcode the SCORE brand and the
  Score task verbs / `issue-<n>` ids. This library version injects the brand,
  verb set, and entity matcher so the bar is product-agnostic.

## Contract

- Composes `CommandPalette` (no second palette). Owns the ⌘K / Ctrl+K shortcut
  (ignored while typing in a field or another dialog).
- Open and query state are controllable, and uncontrolled by default: omit both
  and the bar owns them exactly as it always has. `open`/`defaultOpen`/
  `onOpenChange` and `query`/`defaultQuery`/`onQueryChange` follow the package's
  existing controlled shape (`Menu`, `FilePreviewDialog`, `Collapsible`,
  `SectionCard`, `DataTable`) — the value prop wins whenever it is defined, the
  default-prefixed prop seeds the internal value, and the change callback fires
  on every change in both modes. The two halves are independent; controlling
  one leaves the other uncontrolled. A controlled value supplied without its callback only *requests*
  changes and does not move until the caller rerenders it, which is what makes a
  catalog state preview a stable state rather than a live demo.
- `placement` and `autoFocus` are forwarded to `CommandPalette` unchanged, so a
  contained preview can render the palette in flow without taking focus.
- `buildCommandGroups(query, ctx)` (pure, in `commandBarModel.ts`) parses the query:
  - `> <verb> <target>` → verb items, disabled until a target is typed, firing
    `onVerb(verb, targetId)`;
  - an entity id (via the injected `matchEntity`, default `issueEntityMatcher`)
    → a jump item to `entityHref(id)`;
  - anything else → the app's `navigation` group.
  The `navigation` group is always kept last so the bar never dead-ends.
- `verbs: CommandVerb[]` and `matchEntity` are injected; `brand`, `statusStrip`,
  `hint`, and `placeholder` are slots.
- Verbs never mutate from the bar; selecting one calls back so the app routes it
  to its own write path (typically an inspector behind a `BlastRadiusConfirm`).

## Boundaries

- No navigation, write, or entity-vocabulary logic of its own: `navigate`,
  `onVerb`, `entityHref`, `matchEntity`, and `verbs` are all supplied.
- Not the palette itself; the listbox, keyboard nav, and focus trap live in
  `CommandPalette`.

## Review Checks

- ⌘K opens the palette from anywhere except while typing in an input/dialog.
- A verb item is disabled until its target is parsed, then fires `onVerb` once.
- An entity query surfaces a jump wired to `entityHref`.
- Passing neither `open` nor `query` leaves the rendered markup and the whole
  open/type/select/reopen lifecycle unchanged from the uncontrolled bar.
- All three query modes are documented catalog states, each reached from props
  only.
