# ScheduleEditorDialog

## Purpose

`ScheduleEditorDialog` is a controlled presentational dialog for editing a
reviewed scheduled job's mutable runtime settings: enabled state, optional
secondary checks such as suspended state, cron-like schedule pattern, optional
first-start timestamp, scheduler/nudger configuration fields, status, metadata,
and save actions.

## Source Evidence

- Score's `#/schedulers` page has an edit dialog for each mapped host scheduler
  and a create/edit surface for database-backed nudgers.
- The source dialog edits `enabled`, `suspended`, `schedule`, `firstStartAt`,
  nudger identity/copy, assigned agent, project key, workflow, and prompt while
  Score owns catalog validation, API persistence, date conversion, toasts, and
  audit behavior.
- `SchedulerControlPanel` already represents the scheduler card grid; this
  component covers the separate edit surface that was not in that extraction.

## Contract

- The component is controlled: `enabled`, `schedule`, `firstStartAt`, `checks`,
  and `fields` values come from props and changes are emitted through callbacks.
- The dialog supports fixed and contained placements, close actions, disabled
  saving state, optional error copy, metadata rows, secondary checkbox rows,
  configurable text/select/textarea fields, and footer guidance.
- `saving` is the dialog's busy state, which is not `disabled`
  (`src/theme/STATES.md` rule 5). While saving, the save button stays
  **focusable** and announces `aria-busy="true"`; re-submission is refused in
  the form's `onSubmit`, which also covers Enter pressed inside a field. Only
  `submitDisabled` and an empty schedule take the native `disabled` attribute.
- The component does not parse cron syntax or format date values. Consuming apps
  provide the display copy and valid `datetime-local` value when used.

## Non-Goals

- No scheduler API client, catalog lookup, cron validation, time-zone conversion,
  option loading, command execution, log retention, permissions, localization,
  toasts, or audit events.
- No automatic confirmation around disabling a job. Product apps decide when a
  confirmation is required.

## Review Expectations

- Long scheduler ids, cron patterns, and metadata values must wrap without
  expanding the dialog past narrow viewports.
- The enabled state must be visible both as a badge and as an editable checkbox.
- Long nudger prompts must stay inside the scrollable dialog body and text areas
  must not force a horizontal viewport.
- Fixed placement should handle Escape close; contained placement should stay
  reviewable inside the catalog demo stage.
