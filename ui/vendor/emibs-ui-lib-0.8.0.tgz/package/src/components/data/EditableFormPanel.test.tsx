// @vitest-environment happy-dom
import { act } from "react";
import { createRoot } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { EditableChecklist } from "./EditableFormPanel";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

describe("EditableChecklist", () => {
  let container: HTMLDivElement;
  let root: ReturnType<typeof createRoot>;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.appendChild(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
  });

  const boxes = () => Array.from(container.querySelectorAll<HTMLInputElement>('input[type="checkbox"]'));

  const clickBox = async (index: number) => {
    const box = boxes()[index];
    await act(async () => {
      box.click();
    });
  };

  it("reports a row toggle through the panel-level onToggle", async () => {
    const onToggle = vi.fn();
    await act(async () => {
      root.render(
        <EditableChecklist
          items={[
            { id: "a", label: "Spec reviewed", checked: false },
            { id: "b", label: "Tests added", checked: true },
          ]}
          onToggle={onToggle}
        />,
      );
    });

    expect(boxes()).toHaveLength(2);
    expect(boxes()[0].disabled).toBe(false);

    await clickBox(0);
    expect(onToggle).toHaveBeenCalledWith("a", true);

    await clickBox(1);
    expect(onToggle).toHaveBeenCalledWith("b", false);
  });

  it("reports a row toggle through the per-item onToggle", async () => {
    const onToggle = vi.fn();
    await act(async () => {
      root.render(<EditableChecklist items={[{ id: "a", label: "Spec reviewed", checked: false, onToggle }]} />);
    });

    await clickBox(0);
    expect(onToggle).toHaveBeenCalledWith(true);
  });

  it("does not fire a toggle for a disabled row", async () => {
    const onToggle = vi.fn();
    await act(async () => {
      root.render(
        <EditableChecklist items={[{ id: "a", label: "Locked", checked: true, disabled: true }]} onToggle={onToggle} />,
      );
    });

    expect(boxes()[0].disabled).toBe(true);
    await clickBox(0);
    expect(onToggle).not.toHaveBeenCalled();
  });

  it("renders a row with no toggle handler as an explicitly inert control", async () => {
    await act(async () => {
      root.render(<EditableChecklist items={[{ id: "a", label: "Read only", checked: true }]} />);
    });

    const box = boxes()[0];
    expect(box.disabled).toBe(true);
    expect(box.getAttribute("aria-readonly")).toBe("true");
  });
});
