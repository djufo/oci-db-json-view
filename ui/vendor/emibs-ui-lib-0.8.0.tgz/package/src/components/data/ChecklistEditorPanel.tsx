import { type ReactNode, useId } from "react";
import { Plus, Trash2 } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { Button } from "../primitives/Button";

export type ChecklistEditorItem = {
  id: string;
  text: string;
  checked?: boolean;
  disabled?: boolean;
  placeholder?: string;
  meta?: ReactNode;
};

export type ChecklistEditorPanelProps = {
  items: ChecklistEditorItem[];
  title?: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  emptyLabel?: ReactNode;
  addLabel?: ReactNode;
  addDisabled?: boolean;
  readOnly?: boolean;
  disabled?: boolean;
  density?: "compact" | "comfortable";
  actions?: ReactNode;
  footer?: ReactNode;
  className?: string;
  itemLabel?: (item: ChecklistEditorItem, index: number) => string;
  checkLabel?: (item: ChecklistEditorItem, index: number) => string;
  removeLabel?: (item: ChecklistEditorItem, index: number) => string;
  onAddItem?: () => void;
  onItemTextChange?: (itemId: string, text: string) => void;
  onItemCheckedChange?: (itemId: string, checked: boolean) => void;
  onRemoveItem?: (itemId: string) => void;
};

export function ChecklistEditorPanel({
  items,
  title,
  eyebrow,
  subtitle,
  status,
  statusTone = "info",
  emptyLabel = "No checklist items.",
  addLabel = "Add item",
  addDisabled = false,
  readOnly = false,
  disabled = false,
  density = "comfortable",
  actions,
  footer,
  className,
  itemLabel = (_item, index) => `Checklist item ${index + 1}`,
  checkLabel = (_item, index) => `Toggle checklist item ${index + 1}`,
  removeLabel = (_item, index) => `Remove checklist item ${index + 1}`,
  onAddItem,
  onItemTextChange,
  onItemCheckedChange,
  onRemoveItem,
}: ChecklistEditorPanelProps) {
  const hasHeader = Boolean(title || eyebrow || subtitle || status || actions || onAddItem);

  return (
    <section className={cn("ui-checklist-editor", `ui-checklist-editor--${density}`, className)}>
      {hasHeader ? (
        <header className="ui-checklist-editor__header">
          <div className="ui-checklist-editor__title-block">
            {eyebrow ? <span className="ui-checklist-editor__eyebrow">{eyebrow}</span> : null}
            {title ? <h2>{title}</h2> : null}
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
          <div className="ui-checklist-editor__header-actions">
            {status ? <Badge tone={statusTone}>{status}</Badge> : null}
            {actions}
            {onAddItem ? (
              <Button disabled={disabled || addDisabled} onClick={onAddItem} size="sm" type="button">
                <Plus size={15} aria-hidden="true" />
                {addLabel}
              </Button>
            ) : null}
          </div>
        </header>
      ) : null}

      <div className="ui-checklist-editor__body">
        {items.length === 0 ? <p className="ui-checklist-editor__empty">{emptyLabel}</p> : null}
        {items.map((item, index) => (
          <ChecklistEditorRow
            checkLabel={checkLabel(item, index)}
            disabled={disabled}
            item={item}
            itemLabel={itemLabel(item, index)}
            key={item.id}
            readOnly={readOnly}
            removeLabel={removeLabel(item, index)}
            onItemCheckedChange={onItemCheckedChange}
            onItemTextChange={onItemTextChange}
            onRemoveItem={onRemoveItem}
          />
        ))}
      </div>

      {footer ? <footer className="ui-checklist-editor__footer">{footer}</footer> : null}
    </section>
  );
}

function ChecklistEditorRow({
  item,
  itemLabel,
  checkLabel,
  removeLabel,
  readOnly,
  disabled,
  onItemTextChange,
  onItemCheckedChange,
  onRemoveItem,
}: {
  item: ChecklistEditorItem;
  itemLabel: string;
  checkLabel: string;
  removeLabel: string;
  readOnly: boolean;
  disabled: boolean;
  onItemTextChange?: (itemId: string, text: string) => void;
  onItemCheckedChange?: (itemId: string, checked: boolean) => void;
  onRemoveItem?: (itemId: string) => void;
}) {
  const inputId = useId();
  const rowDisabled = disabled || item.disabled;
  const textReadOnly = readOnly || !onItemTextChange;

  return (
    <div className={cn("ui-checklist-editor__row", item.checked && "is-checked", rowDisabled && "is-disabled")}>
      <label className="ui-checklist-editor__check" aria-label={checkLabel}>
        <input
          checked={Boolean(item.checked)}
          disabled={rowDisabled || readOnly || !onItemCheckedChange}
          type="checkbox"
          onChange={(event) => onItemCheckedChange?.(item.id, event.target.checked)}
        />
        <span aria-hidden="true" />
      </label>
      <label className="ui-checklist-editor__field" htmlFor={inputId}>
        <span>{itemLabel}</span>
        <input
          id={inputId}
          readOnly={textReadOnly}
          disabled={rowDisabled}
          value={item.text}
          placeholder={item.placeholder}
          onChange={(event) => onItemTextChange?.(item.id, event.target.value)}
        />
        {item.meta ? <small>{item.meta}</small> : null}
      </label>
      {onRemoveItem && !readOnly ? (
        <button
          aria-label={removeLabel}
          className="ui-checklist-editor__remove"
          disabled={rowDisabled}
          type="button"
          onClick={() => onRemoveItem(item.id)}
        >
          <Trash2 size={15} aria-hidden="true" />
        </button>
      ) : null}
    </div>
  );
}
