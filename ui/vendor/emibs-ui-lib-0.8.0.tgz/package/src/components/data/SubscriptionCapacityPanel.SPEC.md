# SubscriptionCapacityPanel

## Goal

Provide a presentational Score-style operator surface for provider subscription
capacity: account identity, status, capacity/reset summaries, bound agents,
reporter diagnostics, payload disclosure, summary metrics, and route/action
slots.

## Source Pressure

- Score `ui/src/features/subscriptions/containers/SubscriptionsContainer.tsx`
  renders a subscriptions route for provider account capacity and shared agent
  bindings.
- Score `ui/src/features/subscriptions/capacity.ts` parses provider capacity
  payloads and derives day/week/binding capacity values.
- Score `specs/agents.md` and `specs/scoreworker-contract.md` describe provider
  subscription capacity as worker scheduling policy, not reusable UI behavior.

## Contract

- `SubscriptionCapacityPanel` accepts caller-computed metrics and subscription
  rows.
- Rows render identity, provider, status indicator, capacity/reset summaries,
  agent badges, diagnostics, optional `PayloadBlock` disclosure, and action
  slots.
- Loading, empty, error, compact, and comfortable states preserve the panel
  footprint.
- Column labels are overrideable for localization or future product vocabulary.

## Non-Goals

- No provider API calls, Score task/agent loading, capacity JSON parsing, date
  formatting, threshold calculations, scheduling decisions, suspension logic,
  route construction, persistence, RBAC, polling, toasts, or localization.

## Review Expectations

- Long subscription ids, provider names, reporter errors, and payload snippets
  must wrap without breaking the layout.
- The table remains horizontally scrollable at narrow widths instead of
  overlapping neighboring content.
- Agent and diagnostic slots remain presentational so Score can keep policy and
  action behavior local.
