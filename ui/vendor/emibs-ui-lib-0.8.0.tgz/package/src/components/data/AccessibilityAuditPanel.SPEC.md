# AccessibilityAuditPanel

## Goal

Provide a presentational Score-style accessibility audit surface for catalog
previews: review notes, automated-audit status, pass/issue summaries,
violation detail, affected selectors, documentation links, and an optional
preview canvas.

## Source Pressure

- Score `ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  renders local axe audit state in the component review A11y tab.
- `emibs-ui-lib` Catalog Explorer already runs browser-local axe checks for
  isolated previews, but its audit result chrome was local to the explorer.

## Contract

- `AccessibilityAuditPanel` accepts caller-supplied audit status, pass count,
  notes, violations, actions, and optional canvas content.
- The component renders idle, running, complete pass, complete issues, and
  unavailable states without fetching or running an audit engine.
- Violation rows include severity, rule id, help text, optional docs link,
  description, target selectors, and failure summaries.
- Consumers may use compact or comfortable density.

## Non-Goals

- No axe-core import, DOM scanning, WCAG rule selection, preview rendering,
  registry loading, route synchronization, persistence, analytics, RBAC,
  generated theme state, toast behavior, or localization.

## Review Expectations

- Long selectors and failure summaries wrap without widening the page.
- Pass and issue states remain visually distinct without relying on color alone.
- The optional canvas remains a review slot; product apps keep ownership of
  what is rendered and when audits run.
