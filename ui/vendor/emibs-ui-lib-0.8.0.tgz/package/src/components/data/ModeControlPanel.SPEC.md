# ModeControlPanel

## Purpose

`ModeControlPanel` is a presentational admin control panel for entity workspaces
that need a compact mode selector, controlled automation toggles, a refresh or
action slot, status feedback, and local error/message states.

## Contract

- Accepts controlled mode options and reports mode changes through
  `onModeChange`.
- Renders controlled boolean toggles and delegates changes through each toggle's
  `onChange` handler.
- Exposes an action slot for refresh, save, map, or other product-owned commands.
- Renders disabled, status, message, error, and footer states without owning
  persistence or entity behavior.
- Uses `ui-mode-control*` CSS classes and shared token variables only.

## Source Evidence

- eLitua `ui/src/admin/accms/components/AccmsControlsState/AccmsControlsState.tsx`
  renders admin mode selection plus auto-navigate and auto-next toggles during
  geocoding review.
- eLitua `ui/src/admin/geos/components/GeosControlsState/GeosControlsState.tsx`
  repeats the same mode/toggle control surface for geo records.
- eLitua `ui/src/admin/guides/components/GuidesControlsState/GuidesControlsState.tsx`
  uses the same compact admin control panel shape with a refresh action instead
  of geocoding toggles.

## Non-Goals

- No eLitua state dispatch, translation, loading derivation, map/geocoding
  mutation, route behavior, or entity refresh policy.
- No assumption that mode values are `view`, `edit`, or `geo`; consumers supply
  the option registry.
- No adoption into eLitua in this extraction; adoption is tracked by a separate
  low-priority UI Framework refactor task.
