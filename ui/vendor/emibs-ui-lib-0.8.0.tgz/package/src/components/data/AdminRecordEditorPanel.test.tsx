// @vitest-environment happy-dom
import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, describe, expect, it, vi } from "vitest";

import { AdminRecordEditorPanel } from "./AdminRecordEditorPanel";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let root: Root | undefined;

afterEach(() => {
  act(() => root?.unmount());
  root = undefined;
  document.body.replaceChildren();
});

function mount(markup: string) {
  const container = document.createElement("div");
  container.innerHTML = markup;
  document.body.append(container);
  return container;
}

async function render(node: React.ReactNode) {
  const container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  await act(async () => {
    root!.render(node);
  });
  return container;
}

const FOOTER = <button type="submit">Save record</button>;

/**
 * The SPEC promises "a stable save/delete footer", but `footer` was rendered
 * inside `EditorBody`, which only exists in the loaded branch — so the footer
 * disappeared in the `loading` and `empty` states. The save/delete commands
 * vanishing and reappearing as a record resolves is exactly the layout shift the
 * "stable" wording rules out.
 */
describe("AdminRecordEditorPanel — the footer is stable across states", () => {
  it.each([
    ["loading", { loading: true }],
    ["empty", { empty: true }],
    ["loaded", {}],
  ])("renders the footer in the %s state", (_name, stateProps) => {
    const container = mount(
      renderToStaticMarkup(
        <AdminRecordEditorPanel
          backLabel="Back to records"
          footer={FOOTER}
          title="Edit record"
          {...stateProps}
        />,
      ),
    );

    const footer = container.querySelector("footer.ui-admin-record-editor__footer");
    expect(footer?.textContent).toBe("Save record");
  });

  it.each([
    ["loading", { loading: true }],
    ["empty", { empty: true }],
    ["loaded", {}],
  ])("keeps the footer inside the form in the %s state when onSubmit is supplied", (_name, stateProps) => {
    const container = mount(
      renderToStaticMarkup(
        <AdminRecordEditorPanel
          backLabel="Back to records"
          footer={FOOTER}
          onSubmit={() => undefined}
          title="Edit record"
          {...stateProps}
        />,
      ),
    );

    // A submit button outside its form does nothing, so the footer has to stay
    // within the <form> in every state, not only the loaded one.
    const form = container.querySelector("form.ui-admin-record-editor__form");
    expect(form?.querySelector("footer.ui-admin-record-editor__footer")?.textContent).toBe("Save record");
  });
});

/**
 * `backHref` rendered an anchor whose `onClick` called `onBack` without ever
 * calling `preventDefault`, so supplying both ran the handler AND let the
 * browser navigate — a double back.
 *
 * Decision: supplying both is legitimate and `onBack` suppresses the navigation.
 * That is the standard SPA-link shape — the real URL stays on the anchor so it
 * can be middle-clicked, copied and crawled, while a plain left click is handled
 * in-app. Only a plain left click is intercepted; a modified click (new tab, new
 * window) is left to the browser.
 */
describe("AdminRecordEditorPanel — back control with both backHref and onBack", () => {
  it("suppresses the native navigation when onBack handles the plain click", async () => {
    const onBack = vi.fn();
    const container = await render(
      <AdminRecordEditorPanel backHref="/records" backLabel="Back" onBack={onBack} title="Edit" />,
    );
    const back = container.querySelector<HTMLAnchorElement>("a.ui-admin-record-editor__back")!;

    expect(back.getAttribute("href")).toBe("/records");

    const event = new MouseEvent("click", { bubbles: true, cancelable: true });
    await act(async () => {
      back.dispatchEvent(event);
    });

    expect(onBack).toHaveBeenCalledTimes(1);
    expect(event.defaultPrevented).toBe(true);
  });

  it("leaves a modified click to the browser so the link still opens in a new tab", async () => {
    const onBack = vi.fn();
    const container = await render(
      <AdminRecordEditorPanel backHref="/records" backLabel="Back" onBack={onBack} title="Edit" />,
    );
    const back = container.querySelector<HTMLAnchorElement>("a.ui-admin-record-editor__back")!;

    const event = new MouseEvent("click", { bubbles: true, cancelable: true, metaKey: true });
    await act(async () => {
      back.dispatchEvent(event);
    });

    expect(onBack).not.toHaveBeenCalled();
    expect(event.defaultPrevented).toBe(false);
  });

  it("navigates natively when only backHref is supplied", async () => {
    const container = await render(
      <AdminRecordEditorPanel backHref="/records" backLabel="Back" title="Edit" />,
    );
    const back = container.querySelector<HTMLAnchorElement>("a.ui-admin-record-editor__back")!;

    const event = new MouseEvent("click", { bubbles: true, cancelable: true });
    await act(async () => {
      back.dispatchEvent(event);
    });

    expect(event.defaultPrevented).toBe(false);
  });

  it("renders a button when only onBack is supplied", async () => {
    const onBack = vi.fn();
    const container = await render(
      <AdminRecordEditorPanel backLabel="Back" onBack={onBack} title="Edit" />,
    );

    const back = container.querySelector<HTMLButtonElement>("button.ui-admin-record-editor__back")!;
    await act(async () => {
      back.click();
    });

    expect(onBack).toHaveBeenCalledTimes(1);
  });
});
