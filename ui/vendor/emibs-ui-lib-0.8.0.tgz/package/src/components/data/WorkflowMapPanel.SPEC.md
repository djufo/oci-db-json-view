# WorkflowMapPanel

## Goal

Provide a presentational workflow inspection panel for Score-style lifecycle
maps: ordered stages, current work rows, ownership metadata, stage/item status
badges, recovery hints, route links, and summary metrics.

## Source Pressure

- Score `ui/src/features/workflow/SPEC.md` defines an operator-facing workflow
  map for lifecycle columns, routing signals, review handoffs, release gates,
  and recovery paths.
- Score `specs/workflow.md` remains the canonical lifecycle and recovery
  contract.
- Score `specs/ui.md` requires the UI to avoid becoming a second workflow or
  permission engine while still surfacing actionable state.

## Contract

- `WorkflowMapPanel` accepts controlled summary insights and ordered stage
  descriptors.
- Stages render title, description, count, status, action slots, and work rows.
- Work rows render caller-supplied links, status badges, owner/meta text,
  summaries, recovery badges, and action slots.
- Stage and work-row card text clamps to three lines with ellipsis so dense
  workflow maps remain scannable.
- Loading, error, and empty states preserve the panel footprint.

## Non-Goals

- No Score status model, lifecycle ordering rules, transition validation,
  lease expiry math, claim priority, release grant logic, reviewer eligibility,
  audit loading, route construction, API calls, or toasts.

## Review Expectations

- Dense maps must fit inside board/workflow pages without horizontal overflow.
- Recovery and blocked states must be visually distinct through caller-supplied
  badge tones.
- Link and action slots must remain optional so read-only lifecycle reviews can
  use the same component.
