import type { ComponentType } from "react";

export interface GeoPoint {
  latitude: number;
  longitude: number;
}

export interface AddressValue {
  id?: number;
  /** Opaque consumer metadata; the library never makes access decisions. */
  private?: boolean;
  street: string;
  number: string;
  city: string;
  postcode: string;
  countryCode: string;
  latitude: number | null;
  longitude: number | null;
  /** Caller-provided presentation permission, enforced by the consumer's server. */
  canEdit?: boolean;
}

export interface MapAdapterViewProps {
  /** Null clears the selected point, including incomplete manual coordinates. */
  point: GeoPoint | null;
  readOnly: boolean;
  /** Absent when locked. The adapter must disable its selection gestures. */
  onPick?: (point: GeoPoint) => void;
}

export interface AddressMapAdapter {
  /** Stable React component; the consumer owns SDK loading, credentials and cleanup. */
  View: ComponentType<MapAdapterViewProps>;
  /** Optional, explicit address lookup. Respect cancellation; return null for no match. */
  geocode?: (query: string, signal: AbortSignal) => Promise<GeoPoint | null>;
}

export function isGeoPoint(point: GeoPoint): boolean {
  return Number.isFinite(point.latitude) && Math.abs(point.latitude) <= 90
    && Number.isFinite(point.longitude) && Math.abs(point.longitude) <= 180;
}
