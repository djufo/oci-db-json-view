# AgentProfilePanel

## Purpose

`AgentProfilePanel` is a presentational operator detail surface for Score-style
agent profiles: identity header, capacity metrics, editable configuration
fields, direct release-grant visibility, detail metadata, error/loading states,
and product-owned action slots.

## Contract

- Accepts preformatted identity, status, metric, form, grant, field, and section
  props, and renders default agent identity chrome through `IdentityAvatar`.
- Renders controlled text/select/checkbox fields and reports changes through
  `onFormFieldChange`; persistence, debouncing, validation, and toast behavior
  stay in the consuming app.
- Renders release grants as read-only visibility rows with optional action
  slots. Grant mutations and RBAC semantics stay product-owned.
- `loading` and `error` compose rather than exclude each other. The identity
  header, `status`, `actions`, and `error` render in every state; `loading`
  replaces only the generated body (metrics, form, grants, fields, sections) —
  the part with no data yet — and marks the panel `aria-busy`. An `error`
  outranks the loading surface: "it failed" is actionable and terminal, while a
  spinner shown next to it would invite the user to wait for a request that has
  already finished.
- Keeps delete confirmations, route closing, provider login, token secret
  handling, date/percentage formatting, and Score API calls outside the shared
  component.
- Uses `ui-agent-profile*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/features/agent-admin/containers/AgentAdminContainer.tsx`
  provides `AgentProfilePage`: individual agent identity chrome, saving/deleting
  signals, capacity metric panel, editable display/role/provider/enabled
  controls, release model rows, and detail metadata.
- Score `ui/src/features/agents/components/AgentCard.tsx` provides the compact
  capacity language reused by the profile metrics.
- eLitua was inspected for comparable agent detail surfaces; no eLitua
  agent/runner profile page exists today.

## Non-Goals

- No Score API client, worker policy, local auth, provider login, delete flow,
  route mutation, or release-grant persistence.
- No assumption that consumers use Score role, provider, or runner names.
- No adoption into Score in this extraction; adoption is tracked by a separate
  low-priority UI Framework refactor task.
