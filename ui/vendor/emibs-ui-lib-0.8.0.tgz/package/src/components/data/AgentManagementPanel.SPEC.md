# AgentManagementPanel

## Purpose

`AgentManagementPanel` is a presentational operator surface for Score-style
agent administration: agent identity rows, runner assignment, enablement gates,
capacity windows, availability state, release-grant chips, runner responsibility
rows, loading/empty/error states, and product-owned action slots.

## Contract

- Accepts preformatted agent, runner, metric, status, and action props.
- Composes the shared `StatusIndicator` primitive for agent capacity and
  availability cells while the consumer supplies state labels, capacity values,
  thresholds, and dates.
- Renders controlled runner selects and enablement checkboxes when callback props
  are supplied; otherwise the controls render disabled/read-only.
- Runner names and responsibilities render as editable inputs only when matching
  callbacks are supplied.
- Keeps API calls, routing, persistence, delete confirmation, capacity policy,
  provider login, role semantics, and date/percentage formatting in the
  consuming app.
- Uses `ui-agent-management*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/features/agent-admin/containers/AgentAdminContainer.tsx`
  provides the agent configuration table, runner table, runner assignment
  select, enablement checkboxes, profile links, and capacity status summary.
- Score `ui/src/features/agents/containers/AgentsContainer.tsx`,
  `AgentCard.tsx`, and `CapacityRow.tsx` provide the scheduling/capacity
  overview pressure that the metrics and capacity cells preserve.
- eLitua was inspected for comparable user/admin management surfaces; it does
  not currently have an agent-runner scheduling screen to adopt this component.

## Non-Goals

- No Score API client, worker policy, local auth, capacity calculations, or
  delete/create flows.
- No assumption that every consumer uses Score role/provider names.
- No assumption that agent health thresholds are reusable across consumers.
