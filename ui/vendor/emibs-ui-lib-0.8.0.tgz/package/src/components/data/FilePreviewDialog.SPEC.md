# FilePreviewDialog

## Purpose

`FilePreviewDialog` is a presentational popup viewer for a single document or
file preview. It captures Score's project-file preview dialog pattern: rendered
Markdown first, raw source as a secondary mode, and dialog-chrome download/open
actions.

## Contract

- Accepts controlled `open`, caller-supplied `file`, preview `kind`, optional
  Markdown text/loading/error state, metadata, badges, and close/mode callbacks.
- Composes `DialogFrame` for modal chrome and `FilePreviewPanel` for rendered
  preview content.
- Supports controlled or uncontrolled `view`/`src` mode selection. Markdown
  defaults to rendered view; non-preview files resolve directly to source mode.
- Renders raw source through either a caller-supplied `source` node or a
  sandboxed iframe pointed at a caller-supplied source URL.
- Always renders the raw-source frame with a `sandbox` attribute and
  `referrerPolicy="no-referrer"`.
- Exposes header download/open actions from caller-owned URLs or custom action
  descriptors while leaving file APIs and authorization outside the component.
- Uses `ui-file-preview-dialog*` CSS classes and shared token variables only.

## Raw-Source Trust Boundary

The raw-source frame is hostile-content-tolerant by construction, not by
convention. The dialog displays files the consuming app does not control — user
uploads, project attachments — so the frame is treated as untrusted.

- **The frame starts with zero capabilities.** Without `sourceSandbox` it is
  `sandbox=""`: no scripts, no same-origin, no forms, no navigation, no popups.
  The consuming app opts in per capability, e.g.
  `sourceSandbox: ["allow-popups"]`.
- **`sourceSandbox` is a token list, not a free string.** It is typed as
  `FilePreviewDialogSandboxToken[]`, so an arbitrary attribute value cannot be
  injected and a typo is a compile error rather than a silently ignored token.
- **`allow-scripts` + `allow-same-origin` is not expressible.** When both are
  requested the dialog drops `allow-same-origin`, because a frame holding both
  can reach its own frame element's document and remove the sandbox attribute.
  A source that genuinely needs same-origin script access must be embedded by
  the consuming app directly, not through this dialog.
- **The referrer is never leaked.** `referrerPolicy="no-referrer"` keeps the
  hosting document's URL — which for a file preview commonly carries project,
  record, or token path segments — out of the request for the source URL.
- The sandbox policy has one implementation, `resolveDiagnosticEmbedSandbox` in
  `OperationalDiagnosticPanel`; this dialog reuses it rather than restating it.
- The `source` node path is caller-rendered React, not framed content, and is
  outside this boundary: whatever the app puts there it owns.
- The dialog does not proxy, authenticate, validate, sanitize, or
  same-origin-check the source URL. Choosing a URL the app trusts to be framed,
  and its signing/expiry, remain app-owned.

## Source Evidence

- Score `ui/src/components/file-preview/FilePreviewDialog.tsx` wraps the local
  attachment preview adapter in a popup, defaults Markdown files to `View`, and
  offers `Src`, `Download`, and `Open` actions in the header.
- Score `ui/src/components/file-preview/SPEC.md` records that shared dialog
  extraction was reserved for later UIF work after `FilePreviewPanel`.
- Score project profile file rows open Markdown attachments through this popup
  while project attachment fetching, signed URLs, permissions, and toasts remain
  Score-owned.

## Non-Goals

- No file fetching, signed URL creation, attachment upload/delete/copy/move
  behavior, MIME allow-list policy, route ownership, focus-trap library choice,
  or toast/error side effects.
- No sanitization of the framed source, and no framing policy for the source URL
  beyond the sandbox above.
- No adoption into Score in this extraction; adoption is tracked by a
  low-priority UI Framework refactor task.
