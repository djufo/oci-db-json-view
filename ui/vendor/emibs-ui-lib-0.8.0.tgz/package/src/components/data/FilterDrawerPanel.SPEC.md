# FilterDrawerPanel

`FilterDrawerPanel` is a presentational shell for compact filter surfaces that
must work as either an always-visible sidebar panel or a controlled mobile
drawer.

## Sources

- Score `ui/src/features/board/containers/BoardContainer.tsx` uses a board
  toolbar filter reveal with project, epic, search, reset, and active-filter
  summary state.
- eLitua `ui/src/features/PageSidebar/PageSidebar.tsx` frames explorer filters,
  map controls, view switching, and selected-record detail in a persistent side
  rail.
- eLitua `ui/src/client/{accms,guides,places}/components/*Filters.tsx` and
  `ui/src/admin/*/components/*Filters.tsx` repeat compact search/select filter
  surfaces with counts, clear actions, refresh actions, and loading states.

## Contract

- Renders controlled inline or drawer chrome through `mode`.
- Accepts title, eyebrow, description, summary badge, additional badges,
  header actions, footer copy, footer action slot, and arbitrary filter
  children.
- Exposes `open` and `onOpenChange` for drawer state but does not own routing,
  query parsing, filtering, persistence, or data loading.
- Drawer mode composes the shared overlay engine: it portals above app chrome,
  traps and restores focus, locks body scroll, participates in overlay stacking,
  and handles Escape/backdrop dismissal through `onOpenChange(false)`.
- Uses native button controls for trigger and close affordance; the decorative
  backdrop stays out of the accessibility tree.

## Product Boundaries

- Score keeps board query parsing, saved filters, project/epic counts,
  task creation, claim/refresh commands, route synchronization, permissions,
  and toasts.
- eLitua keeps RxJS/DataProxy dispatch, filter schemas, translated labels,
  map synchronization, pagination, entity refresh, route state, and result
  derivation.

## Accessibility

- Drawer mode labels the panel as a dialog through the supplied title.
- Trigger uses `aria-expanded` and `aria-controls`.
- Inline mode uses a labelled region.
- The overlay engine restores focus to the opening control. Consumers own any
  product-level keyboard shortcut that opens the drawer.

## Responsive Rules

- Header actions, badges, and footer actions wrap without covering title text.
- Drawer width is bounded on desktop and uses the viewport width on mobile.
- The body scrolls independently so footer actions stay reachable.
