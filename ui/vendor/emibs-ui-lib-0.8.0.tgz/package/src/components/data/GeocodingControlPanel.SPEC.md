# GeocodingControlPanel Spec

## Purpose

`GeocodingControlPanel` captures eLitua's repeated GeoForm geocoding action
strip as a presentational control surface for choosing a coordinate source,
searching an address or `lat, lng` pair, reviewing selected coordinates, and
selecting returned geocoding candidates.

## Source Evidence

- eLitua `ui/src/admin/geos/components/GeoForm/GeoForm.tsx` renders source
  actions for address, name, existing coordinates, and map selection, then
  combines a geocoding search input with candidate result rows.
- eLitua `ui/src/admin/accms/components/GeoForm/GeoForm.tsx` repeats the same
  workflow for accommodation coordinates with different state and dispatch
  adapters.

## Existing Coverage Check

- `EditableFormPanel` covers the broader admin form sections and action strip
  container, but not the full geocoding source/search/candidate/coordinate
  workflow.
- `EditableFormResultList` covers selectable candidate rows only.
- `NumberInputControl` covers latitude/longitude fields, not coordinate source
  selection or candidate review.
- `MapControlPanel`, `MapViewport`, and `MapMarkerPin` cover map chrome and
  markers, not geocoding input and result selection.

## Contract

- Accepts controlled `query` and optional `onQueryChange`.
- Accepts controlled coordinate source buttons through `sources`.
- Accepts controlled candidate rows through `candidates`.
- Accepts optional selected coordinate summary, loading, error, status, header
  action, search action, and footer slots.
- All copy is caller-supplied where localization matters.

## Non-Goals

- No Google Maps API call, debounce timing, coordinate parsing, map pin
  dispatch, entity selection, persistence, validation, toast behavior, route
  mutation, or localization lookup.
- No replacement for full admin edit forms or generic field primitives.

## Review Checks

- Long addresses and coordinate strings wrap without horizontal overflow.
- Source actions fit four-up on desktop and stack on narrow screens.
- Loading and error states use `role="status"` and `role="alert"`.
- Candidate selection remains keyboard accessible when `onSelect` is supplied.
