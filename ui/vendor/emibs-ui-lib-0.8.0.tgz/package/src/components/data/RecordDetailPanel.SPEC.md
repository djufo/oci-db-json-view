# RecordDetailPanel

## Purpose

Reusable selected-record detail surface for operational task detail pages and
portal explorer side panels. The component presents a record title, metadata
badges, dense key/value fields, content sections, actions, and an optional close
control without owning product state.

## Contract

- `RecordDetailPanel` is presentational and does not fetch, persist, translate,
  route, or subscribe to data.
- Header title, badges, actions, fields, sections, and footer are all driven by
  props so consuming apps keep domain-specific editing, permissions, and API
  behavior local.
- Field links require concrete `href` values. Framework-specific route/link
  adapters stay in the consuming app.
- `variant="comfortable"` supports full page or dialog detail pages.
  `variant="compact"` supports selected-record explorer cards.

## Source

- `/engineering/projects/score/ui/src/features/board/components/TaskDetail.tsx`
- `/engineering/projects/score/ui/src/features/projects/containers/ProjectPage.tsx`
- `/engineering/projects/elitua/ui/src/admin/accms/components/AccmDetailCard/AccmDetailCard.tsx`
- `/engineering/projects/elitua/ui/src/admin/geos/components/GeoDetailCard/GeoDetailCard.tsx`
- `/engineering/projects/elitua/ui/src/admin/guides/components/GuideDetailCard/GuideDetailCard.tsx`
