# ResourceIndexPanel

## Purpose

`ResourceIndexPanel` is a presentational admin collection surface for resources
that need a scannable summary list or grid, selected state, metadata badges,
optional open actions, and optional ordering controls.

## Contract

- Accepts preformatted title, subtitle, description, metadata, status, action,
  leading, and trailing props.
- Renders selected, disabled, empty, and normal item states.
- Renders item links when `href` is supplied, selection buttons when
  `onItemSelect` is supplied, or read-only titles when neither exists.
- Supports `layout="list"` for ordered/selected rows and `layout="grid"` for
  compact admin record-index cards.
- Renders controlled up/down order buttons only when `onItemMove` is supplied.
- Keeps routing, persistence, ordering mutations, RBAC, entity type rules,
  timestamp formatting, and deletion confirmations in the consuming app.
- Uses `ui-resource-index*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/features/admin/components/ProjectAdminList.tsx` provides the
  selected project list, project metadata badges, open links, descriptions, and
  up/down project ordering controls.
- eLitua `ui/src/pages/admin/users/UsersPage.tsx` and
  `ui/src/pages/admin/profiles/ProfilesPage.tsx` provide comparable admin index
  card grids for user/profile resources, but without ordering controls.
- eLitua `ui/src/pages/admin/pictures/PicturesPage.tsx` repeats the same
  admin record grid with picture metadata and edit links.
- eLitua explorer/entity pages are already represented by `ExplorerWorkspace`,
  `EntityCard`, `DataTable`, and `RecordDetailPanel`; this component is for the
  admin resource index pattern that stays outside those map/table workspaces.

## Non-Goals

- No Score project API, eLitua data proxies, route generation, project priority
  policy, entity search/filtering, or drag-and-drop ordering.
- No adoption into Score or eLitua in this extraction; adoption is tracked by
  separate low-priority UI Framework refactor tasks.
