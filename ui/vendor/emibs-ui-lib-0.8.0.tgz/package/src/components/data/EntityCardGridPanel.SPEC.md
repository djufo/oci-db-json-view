# EntityCardGridPanel

## Purpose

`EntityCardGridPanel` is a presentational card-grid browsing surface for tourism
and admin records that need current-page summary chrome, selected-card state,
record metadata, badges, optional media, loading/error/empty states, and
product-owned pagination controls.

## Source Evidence

- eLitua `ui/src/client/accms/components/AccmsCardView/AccmsCardView.tsx`
  renders accommodation card grids with selected state, accent/category styling,
  region/address/capacity/license metadata, paging chrome, and empty state.
- eLitua `ui/src/client/guides/components/GuidesCardView/GuidesCardView.tsx`
  renders guide card grids with verification/language/region/contact metadata,
  profile actions, row selection, paging chrome, and empty state.
- eLitua `ui/src/client/places/components/PlacesCardView/PlacesCardView.tsx`
  renders place card grids with verified/type/location metadata, selection, page
  controls, and empty state.
- eLitua admin guide card views repeat the same card-grid/selection/pagination
  structure with denser management metadata.

## Contract

- Accepts pre-paged `items`; pagination calculation, route/query state, filters,
  sorting, translations, and selected entity state stay in the consuming app.
- Renders title/status/action chrome, toolbar and pagination slots, media or icon
  placeholders, badges, metadata rows, footer copy, selected/disabled states,
  item links, controlled item selection, loading, error, and empty states.
- A `disabled` item is inert in every branch, not merely dimmed. The button
  takes the native `disabled` attribute; the link keeps its `<a>` and gains
  `role="link"` + `aria-disabled="true"` but **loses its `href`**, which is what
  removes it from the tab order and takes away its activation behaviour.
- Supports comfortable and compact density for public browsing and admin lists.
- Uses `ui-entity-card-grid*` CSS classes and shared token variables only.

## Non-Goals

- No entity API client, RxJS dispatch, filtering, sort state, pagination math,
  map synchronization, profile routing, localization, image policy, analytics,
  or adoption into eLitua in this extraction. Adoption is tracked by a separate
  low-priority UI Framework refactor task.
