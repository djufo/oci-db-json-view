# MapInfoCard

## Purpose

`MapInfoCard` is a compact selected-marker information surface for map
workspaces that need a lightweight title, key/value rows, status badges, actions,
and a close control without using a full record-detail panel.

## Contract

- Renders controlled title, eyebrow, subtitle, badges, rows, actions, footer,
  and onClose/closeLabel props. There is no standalone `close` prop; the close
  control renders only when `onClose` is supplied.
- Supports `placement="inline"` for side-panel or catalog use and
  `placement="overlay"` for absolute top-right map overlay use.
- Omits empty rows while preserving supplied row order.
- Uses shared token classes only; no map engine, geocoding, translation,
  selection dispatch, routing, clustering, or persistence behavior.

## Source Evidence

- eLitua `ui/src/admin/accms/components/AccmInfoCard/AccmInfoCard.tsx`
  and `ui/src/admin/geos/components/GeoInfoCard/GeoInfoCard.tsx` render the
  same selected marker card with title, close action, id, coordinates, and geo
  status.
- eLitua `ui/src/client/guides/components/GuideInfoCard/GuideInfoCard.tsx`
  renders the public map overlay variant with a selected place title, count row,
  close action, and route/action button.
- eLitua `ui/src/emibs-lib/features/googleMaps/components/MapView.tsx` owns the
  Google Maps lifecycle and passes selected-record info card content through the
  map viewport, so the reusable unit is the presentational card only.

## Non-Goals

- Does not wrap Google Maps or manage markers, clustering, map settings,
  selected entity state, or map click behavior.
- Does not replace `RecordDetailPanel`; use `MapInfoCard` for compact marker
  overlays and `RecordDetailPanel` for larger detail sidebars.
- No product adoption is included in this extraction; eLitua adoption is tracked
  by a low-priority UI Framework refactor task.
