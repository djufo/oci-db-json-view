# ResourceTransferDialog

`ResourceTransferDialog` is a controlled presentational dialog for copy/move
target selection. It was extracted from Score's project attachment copy/move
workflow so the reviewed modal chrome, resource summary, destination list, move
toggle, empty/error state, and footer actions can be reused.

## Contract

- Renders only when `open` is true.
- Accepts a `resource` summary, controlled `targets`, `targetId`, and `move`
  boolean.
- Emits `onTargetChange`, `onMoveChange`, `onCancel`, and `onConfirm`; it never
  mutates resources itself.
- Supports fixed runtime dialogs and contained catalog/review placement through
  `DialogFrame`.
- Disables confirmation when no enabled target is selected or when the caller
  passes `confirmDisabled`.
- `busy` is a different state from `disabled` (`src/theme/STATES.md` rule 5).
  While a transfer is in flight the confirm button, the destination radios and
  the move checkbox all stay **focusable** and keep announcing their values; the
  confirm button announces `aria-busy="true"`, and the inputs are marked
  `aria-readonly` and refuse changes in their handlers. Disabling them would
  drop the whole dialog out of the accessibility tree at the one moment the user
  most needs to read it back.
- Keeps labels, status copy, target metadata, busy/error/empty copy, and button
  labels controlled by props.

## Product Ownership

Consuming apps own attachment/project APIs, project permission filtering, signed
URLs, copy versus move persistence, optimistic updates, file deletion, browser
download behavior, localization, toasts, and route state.

## Non-Goals

- No data fetching or project lookup.
- No attachment upload, download, delete, or copy/move transport.
- No confirmation side effects beyond calling the supplied handlers.
