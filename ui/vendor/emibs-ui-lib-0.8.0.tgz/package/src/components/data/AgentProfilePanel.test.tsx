// @vitest-environment happy-dom
import { renderToStaticMarkup } from "react-dom/server";
import { afterEach, describe, expect, it } from "vitest";

import { AgentProfilePanel } from "./AgentProfilePanel";

/**
 * The loading branch used to `return` a bare surface before the header was
 * rendered at all, so `error`, `status`, `actions` and the identity header were
 * all suppressed while `loading` was set. An app that sets both — the ordinary
 * "the refresh failed" case — showed the user a spinner and nothing else, with
 * the alert it had passed silently dropped.
 *
 * The states are composable now: the header and its chrome always render, and
 * an `error` outranks the spinner rather than being hidden behind it.
 */

function mount(markup: string) {
  const container = document.createElement("div");
  container.innerHTML = markup;
  document.body.append(container);
  return container;
}

afterEach(() => {
  document.body.replaceChildren();
});

describe("AgentProfilePanel — loading composes with the other states", () => {
  it("keeps the error visible when it arrives alongside loading", () => {
    const container = mount(
      renderToStaticMarkup(
        <AgentProfilePanel
          agentId="agent-7"
          error="Could not refresh the agent."
          loading
          title="Release runner"
        />,
      ),
    );

    const alert = container.querySelector('[role="alert"]');
    expect(alert?.textContent).toBe("Could not refresh the agent.");
  });

  it("keeps the header, status and actions visible while loading", () => {
    const container = mount(
      renderToStaticMarkup(
        <AgentProfilePanel
          actions={<button type="button">Retry</button>}
          agentId="agent-7"
          loading
          status="Degraded"
          title="Release runner"
        />,
      ),
    );

    expect(container.querySelector("h2")?.textContent).toBe("Release runner");
    expect(container.textContent).toContain("agent-7");
    expect(container.textContent).toContain("Degraded");
    expect(container.querySelector("button")?.textContent).toBe("Retry");
  });

  it("marks the panel aria-busy and announces the loading surface while loading", () => {
    const container = mount(
      renderToStaticMarkup(<AgentProfilePanel agentId="agent-7" loading title="Release runner" />),
    );

    expect(container.querySelector("section")?.getAttribute("aria-busy")).toBe("true");
    expect(container.querySelector('[role="status"]')?.textContent).toContain("Loading agent profile");
  });

  it("lets the error outrank the spinner rather than showing both", () => {
    const container = mount(
      renderToStaticMarkup(
        <AgentProfilePanel agentId="agent-7" error="Could not refresh." loading title="Release runner" />,
      ),
    );

    expect(container.querySelector('[role="status"]')).toBeNull();
    expect(container.textContent).not.toContain("Loading agent profile");
  });

  it("renders the generated body only once loading has finished", () => {
    const loading = mount(
      renderToStaticMarkup(<AgentProfilePanel agentId="agent-7" loading title="Release runner" />),
    );
    expect(loading.textContent).not.toContain("Release model");
    document.body.replaceChildren();

    const loaded = mount(
      renderToStaticMarkup(<AgentProfilePanel agentId="agent-7" title="Release runner" />),
    );
    expect(loaded.textContent).toContain("Release model");
    expect(loaded.querySelector("section")?.getAttribute("aria-busy")).toBeNull();
  });
});
