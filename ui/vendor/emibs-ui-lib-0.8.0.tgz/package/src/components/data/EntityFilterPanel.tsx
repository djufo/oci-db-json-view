import { type ReactNode } from "react";
import { RefreshCw, Search, X } from "lucide-react";
import { cn } from "../../lib";
import { Badge } from "../primitives/Badge";
import { Button } from "../primitives/Button";
import { Field, Input, Select } from "../primitives/Field";

export type EntityFilterOption = {
  value: string;
  label: string;
  disabled?: boolean;
};

export type EntityFilterTextControl = {
  id: string;
  kind: "text";
  label: string;
  value: string;
  placeholder?: string;
  disabled?: boolean;
  onChange?: (value: string) => void;
};

export type EntityFilterSelectControl = {
  id: string;
  kind: "select";
  label: string;
  value: string;
  options: EntityFilterOption[];
  disabled?: boolean;
  onChange?: (value: string) => void;
};

export type EntityFilterControl = EntityFilterTextControl | EntityFilterSelectControl;

export type EntityFilterPanelStat = {
  id: string;
  label: ReactNode;
  value: ReactNode;
};

export type EntityFilterPanelProps = {
  title?: ReactNode;
  subtitle?: ReactNode;
  icon?: ReactNode;
  controls: EntityFilterControl[];
  stats?: EntityFilterPanelStat[];
  resultCount?: ReactNode;
  totalCount?: ReactNode;
  resultLabel?: ReactNode;
  loading?: boolean;
  loadingLabel?: ReactNode;
  clearLabel?: ReactNode;
  /** Hides the clear control while reserving its space. Defaults to visible whenever `onClear` is supplied. */
  clearVisible?: boolean;
  clearDisabled?: boolean;
  onClear?: () => void;
  refreshLabel?: ReactNode;
  refreshingLabel?: ReactNode;
  refreshDisabled?: boolean;
  refreshing?: boolean;
  onRefresh?: () => void;
  actions?: ReactNode;
  footer?: ReactNode;
  className?: string;
};

export function EntityFilterPanel({
  title = "Search filters",
  subtitle,
  icon = <Search size={14} aria-hidden="true" />,
  controls,
  stats = [],
  resultCount,
  totalCount,
  resultLabel = "records",
  loading = false,
  loadingLabel = "Loading",
  clearLabel = "Clear",
  clearVisible,
  clearDisabled = false,
  onClear,
  refreshLabel = "Refresh",
  refreshingLabel = "Refreshing",
  refreshDisabled = false,
  refreshing = false,
  onRefresh,
  actions,
  footer,
  className,
}: EntityFilterPanelProps) {
  const hasSummary = resultCount !== undefined || totalCount !== undefined;
  // Supplying `onClear` IS the intent to offer a reset. `clearVisible` used to
  // default to false, so the most likely call — `onClear` alone — rendered a
  // `visibility: hidden` button and silently did nothing. The flag now only
  // suppresses a control the caller already opted into, which keeps the
  // reserved-space behaviour for callers that bind it to "filters are active".
  const showClear = clearVisible ?? true;

  return (
    <section className={cn("ui-entity-filter", loading && "is-loading", className)}>
      <div className="ui-entity-filter__header">
        <div className="ui-entity-filter__title-row">
          {icon ? <span className="ui-entity-filter__icon">{icon}</span> : null}
          <div>
            <h2>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
        </div>
        <div className="ui-entity-filter__header-actions">
          {onClear ? (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              disabled={clearDisabled || loading}
              className={cn("ui-entity-filter__clear", !showClear && "is-hidden")}
              onClick={onClear}
            >
              <X size={14} aria-hidden="true" />
              {clearLabel}
            </Button>
          ) : null}
          {actions}
        </div>
      </div>

      <div className="ui-entity-filter__controls">
        {controls.map((control) => (
          <EntityFilterControlField key={control.id} control={control} />
        ))}
      </div>

      <div className="ui-entity-filter__footer">
        <div className="ui-entity-filter__summary" aria-live="polite">
          {loading ? (
            <Badge tone="neutral">{loadingLabel}</Badge>
          ) : hasSummary ? (
            <>
              {resultCount !== undefined ? <strong>{resultCount}</strong> : null}
              {totalCount !== undefined ? <span>/ {totalCount}</span> : null}
              <span>{resultLabel}</span>
            </>
          ) : null}
        </div>
        <div className="ui-entity-filter__footer-actions">
          {stats.map((stat) => (
            <span className="ui-entity-filter__stat" key={stat.id}>
              <span>{stat.label}</span>
              <strong>{stat.value}</strong>
            </span>
          ))}
          {onRefresh ? (
            <Button type="button" size="sm" disabled={refreshDisabled || loading || refreshing} onClick={onRefresh}>
              <RefreshCw size={14} aria-hidden="true" />
              {refreshing ? refreshingLabel : refreshLabel}
            </Button>
          ) : null}
        </div>
      </div>
      {footer ? <div className="ui-entity-filter__note">{footer}</div> : null}
    </section>
  );
}

function EntityFilterControlField({ control }: { control: EntityFilterControl }) {
  if (control.kind === "text") {
    return (
      <Field label={control.label}>
        <div className="ui-input-icon">
          <Search size={16} aria-hidden="true" />
          <Input
            disabled={control.disabled}
            onChange={(event) => control.onChange?.(event.target.value)}
            placeholder={control.placeholder}
            type="search"
            value={control.value}
          />
        </div>
      </Field>
    );
  }

  return (
    <Field label={control.label}>
      <Select
        disabled={control.disabled}
        onChange={(event) => control.onChange?.(event.target.value)}
        value={control.value}
      >
        {control.options.map((option) => (
          <option key={option.value} value={option.value} disabled={option.disabled}>
            {option.label}
          </option>
        ))}
      </Select>
    </Field>
  );
}
