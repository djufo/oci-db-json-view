// @vitest-environment happy-dom
import { renderToStaticMarkup } from "react-dom/server";
import axe from "axe-core";
import { afterEach, describe, expect, it } from "vitest";

import { ChecklistEditorPanel } from "./ChecklistEditorPanel";

/**
 * The row checkbox is named by `aria-label` on the wrapping `<label>` rather
 * than by label text, because the label's only visible content is a decorative
 * `<span aria-hidden="true">` that draws the box.
 *
 * That was reported (uif/issue-4673 defect 3) as "a label element's own
 * aria-label does not name the wrapped control". It does. Per accname §2D and
 * HTML-AAM, a labelled control takes the *accessible name of its label element*,
 * and computing that name starts at step 2A — so the label's own `aria-label`
 * is honoured, exactly as it is when a label is referenced by `aria-labelledby`.
 *
 * Verified, not read: axe-core (below), `dom-accessibility-api`, and real
 * Chromium via CDP `Accessibility.getPartialAXTree` all return
 * "Toggle checklist item 1" here, and Chromium reports the name source as the
 * related label element. The same markup with the `aria-label` removed computes
 * to the empty string in all three, which is what makes the attribute
 * load-bearing rather than decorative.
 *
 * So this file is a characterization test, not a regression test: it locks in
 * behaviour that is already correct, so that "simplifying" the naming away is a
 * red suite rather than a silent loss of the name.
 */

function mount() {
  const container = document.createElement("div");
  container.innerHTML = renderToStaticMarkup(
    <ChecklistEditorPanel
      items={[{ id: "a", text: "Write the spec" }]}
      onItemCheckedChange={() => undefined}
      title="Checklist"
    />,
  );
  document.body.append(container);
  return container;
}

afterEach(() => {
  document.body.replaceChildren();
});

describe("ChecklistEditorPanel — row checkbox accessible name", () => {
  it("computes a non-empty accessible name for the row checkbox", () => {
    const container = mount();
    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!;

    // axe's own accessible-name computation, over its virtual tree.
    const internals = axe as unknown as {
      setup: (node: Node) => unknown;
      teardown: () => void;
      commons: { text: { accessibleText: (node: Element) => string } };
    };
    internals.setup(document.documentElement);
    try {
      expect(internals.commons.text.accessibleText(checkbox)).toBe("Toggle checklist item 1");
    } finally {
      internals.teardown();
    }
  });

  it("honours a caller-supplied checkLabel", () => {
    const container = document.createElement("div");
    container.innerHTML = renderToStaticMarkup(
      <ChecklistEditorPanel
        checkLabel={(item) => `Mark "${item.text}" done`}
        items={[{ id: "a", text: "Write the spec" }]}
        onItemCheckedChange={() => undefined}
        title="Checklist"
      />,
    );
    document.body.append(container);
    const checkbox = container.querySelector<HTMLInputElement>('input[type="checkbox"]')!;

    const internals = axe as unknown as {
      setup: (node: Node) => unknown;
      teardown: () => void;
      commons: { text: { accessibleText: (node: Element) => string } };
    };
    internals.setup(document.documentElement);
    try {
      expect(internals.commons.text.accessibleText(checkbox)).toBe('Mark "Write the spec" done');
    } finally {
      internals.teardown();
    }
  });

  it("raises no axe naming violation for the checklist row", async () => {
    const container = mount();

    const results = await axe.run(container, {
      runOnly: { type: "rule", values: ["label", "form-field-multiple-labels", "aria-input-field-name"] },
    });

    expect(results.violations.map((violation) => violation.id)).toEqual([]);
  });
});
