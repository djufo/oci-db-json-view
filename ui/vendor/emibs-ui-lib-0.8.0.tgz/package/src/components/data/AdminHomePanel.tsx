import { type ReactNode } from "react";
import { ExternalLink } from "lucide-react";
import { cn } from "../../lib";
import { disableableLinkAttributes } from "../../lib/disabledLink";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { MetricGrid } from "./MetricGrid";

export type AdminHomeMetric = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
  tone?: BadgeTone;
  icon?: ReactNode;
};

export type AdminHomeMeta = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type AdminHomeActionItem = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  href?: string;
  external?: boolean;
  icon?: ReactNode;
  meta?: AdminHomeMeta[];
  trailing?: ReactNode;
  actions?: ReactNode;
  featured?: boolean;
  disabled?: boolean;
};

export type AdminHomeNotice = {
  id: string;
  title: ReactNode;
  children?: ReactNode;
  tone?: BadgeTone;
  icon?: ReactNode;
  action?: ReactNode;
};

export type AdminHomeSection = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
};

export type AdminHomePanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  icon?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  metrics?: AdminHomeMetric[];
  notices?: AdminHomeNotice[];
  actionItems?: AdminHomeActionItem[];
  actionLabel?: ReactNode;
  emptyLabel?: ReactNode;
  loading?: boolean;
  loadingLabel?: ReactNode;
  error?: ReactNode;
  sections?: AdminHomeSection[];
  footer?: ReactNode;
  onActionSelect?: (itemId: string) => void;
  className?: string;
};

export function AdminHomePanel({
  title,
  eyebrow,
  subtitle,
  icon,
  status,
  statusTone = "neutral",
  actions,
  metrics = [],
  notices = [],
  actionItems = [],
  actionLabel = "Open admin area",
  emptyLabel = "No admin actions available.",
  loading = false,
  loadingLabel = "Loading admin dashboard...",
  error,
  sections = [],
  footer,
  onActionSelect,
  className,
}: AdminHomePanelProps) {
  return (
    <section className={cn("ui-admin-home", className)}>
      <header className="ui-admin-home__header">
        <div className="ui-admin-home__title-row">
          {icon ? <span className="ui-admin-home__icon" aria-hidden="true">{icon}</span> : null}
          <div className="ui-admin-home__title-block">
            {eyebrow ? <span className="ui-admin-home__eyebrow">{eyebrow}</span> : null}
            <h2>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
        </div>
        <div className="ui-admin-home__header-actions">
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {notices.length > 0 ? (
        <div className="ui-admin-home__notices">
          {notices.map((notice) => (
            <div className={cn("ui-admin-home__notice", `ui-admin-home__notice--${notice.tone ?? "info"}`)} key={notice.id}>
              {notice.icon ? <span className="ui-admin-home__notice-icon" aria-hidden="true">{notice.icon}</span> : null}
              <div>
                <strong>{notice.title}</strong>
                {notice.children ? <p>{notice.children}</p> : null}
              </div>
              {notice.action ? <div className="ui-admin-home__notice-action">{notice.action}</div> : null}
            </div>
          ))}
        </div>
      ) : null}

      {metrics.length > 0 ? (
        <MetricGrid
          ariaLabel="Admin dashboard metrics"
          className="ui-admin-home__metrics"
          columns={2}
          items={metrics}
        />
      ) : null}

      {loading ? (
        <div className="ui-admin-home__loading" role="status">
          <span className="ui-admin-home__spinner" aria-hidden="true" />
          <span>{loadingLabel}</span>
        </div>
      ) : null}

      {!loading && error ? (
        <div className="ui-admin-home__error" role="alert">
          {error}
        </div>
      ) : null}

      {!loading && !error ? (
        <div className="ui-admin-home__body">
          {actionItems.length > 0 ? (
            <div className="ui-admin-home__action-grid" role="list">
              {actionItems.map((item) => (
                <div
                  className={cn(
                    "ui-admin-home__action-card",
                    item.featured && "is-featured",
                    item.disabled && "is-disabled"
                  )}
                  key={item.id}
                  role="listitem"
                >
                  <div className="ui-admin-home__action-main">
                    {item.icon ? <span className="ui-admin-home__action-icon" aria-hidden="true">{item.icon}</span> : null}
                    <div className="ui-admin-home__action-summary">
                      <AdminHomeActionTitle actionLabel={actionLabel} item={item} onActionSelect={onActionSelect} />
                      {item.description ? <p>{item.description}</p> : null}
                      {item.meta && item.meta.length > 0 ? (
                        <div className="ui-admin-home__meta">
                          {item.meta.map((meta) => (
                            <Badge key={meta.id} tone={meta.tone ?? "neutral"}>
                              {meta.label}
                            </Badge>
                          ))}
                        </div>
                      ) : null}
                    </div>
                  </div>
                  {item.trailing || item.actions ? (
                    <div className="ui-admin-home__action-extra">
                      {item.trailing ? <div className="ui-admin-home__trailing">{item.trailing}</div> : null}
                      {item.actions ? <div className="ui-admin-home__item-actions">{item.actions}</div> : null}
                    </div>
                  ) : null}
                </div>
              ))}
            </div>
          ) : (
            <div className="ui-admin-home__empty">{emptyLabel}</div>
          )}

          {sections.length > 0 ? (
            <div className="ui-admin-home__sections">
              {sections.map((section) => (
                <section className="ui-admin-home__section" key={section.id}>
                  <header className="ui-admin-home__section-header">
                    <div>
                      <h3>{section.title}</h3>
                      {section.description ? <p>{section.description}</p> : null}
                    </div>
                    {section.actions ? <div className="ui-admin-home__section-actions">{section.actions}</div> : null}
                  </header>
                  <div className="ui-admin-home__section-body">{section.children}</div>
                </section>
              ))}
            </div>
          ) : null}
        </div>
      ) : null}

      {!loading && footer ? <footer className="ui-admin-home__footer">{footer}</footer> : null}
    </section>
  );
}

function AdminHomeActionTitle({
  item,
  actionLabel,
  onActionSelect,
}: {
  item: AdminHomeActionItem;
  actionLabel: ReactNode;
  onActionSelect?: (itemId: string) => void;
}) {
  const content = (
    <>
      <span>{item.title}</span>
      {item.external ? <ExternalLink aria-hidden="true" size={15} /> : null}
    </>
  );

  if (item.href) {
    // `href` still wins over `onActionSelect`, but a disabled item is inert in
    // both branches now. See `src/lib/disabledLink.ts`.
    return (
      <a
        className="ui-admin-home__action-title"
        {...disableableLinkAttributes({
          href: item.href,
          disabled: item.disabled,
          rel: item.external ? "noreferrer" : undefined,
          target: item.external ? "_blank" : undefined,
        })}
      >
        {content}
      </a>
    );
  }

  if (onActionSelect) {
    return (
      <button className="ui-admin-home__action-title" disabled={item.disabled} onClick={() => onActionSelect(item.id)} type="button">
        {content}
        <span className="ui-sr-only">{actionLabel}</span>
      </button>
    );
  }

  return <strong className="ui-admin-home__action-title">{content}</strong>;
}
