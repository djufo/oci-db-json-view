import { type FormEventHandler, type FormHTMLAttributes, type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type EditableFormBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type EditableFormMessage = {
  id: string;
  tone?: BadgeTone;
  children: ReactNode;
};

export type EditableFormField = {
  id: string;
  label: ReactNode;
  control: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  meta?: ReactNode;
  required?: boolean;
  wide?: boolean;
};

export type EditableFormSection = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  fields?: EditableFormField[];
  actions?: ReactNode;
  children?: ReactNode;
};

export type EditableFormPanelProps = Omit<FormHTMLAttributes<HTMLFormElement>, "title" | "onSubmit"> & {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  badges?: EditableFormBadge[];
  messages?: EditableFormMessage[];
  actions?: ReactNode;
  sections?: EditableFormSection[];
  footer?: ReactNode;
  variant?: "comfortable" | "compact";
  onSubmit?: FormEventHandler<HTMLFormElement>;
};

export function EditableFormPanel({
  title,
  eyebrow,
  subtitle,
  badges = [],
  messages = [],
  actions,
  sections = [],
  footer,
  variant = "comfortable",
  className,
  children,
  onSubmit,
  noValidate = true,
  ...props
}: EditableFormPanelProps) {
  return (
    <form
      className={cn("ui-editable-form", `ui-editable-form--${variant}`, className)}
      noValidate={noValidate}
      onSubmit={onSubmit}
      {...props}
    >
      <header className="ui-editable-form__header">
        <div className="ui-editable-form__title-block">
          {eyebrow ? <span className="ui-editable-form__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
        {actions ? <div className="ui-editable-form__actions">{actions}</div> : null}
      </header>

      {badges.length > 0 ? (
        <div className="ui-editable-form__badges">
          {badges.map((badge) => (
            <Badge key={badge.id} tone={badge.tone}>
              {badge.label}
            </Badge>
          ))}
        </div>
      ) : null}

      {messages.length > 0 ? (
        <div className="ui-editable-form__messages">
          {messages.map((message) => (
            <div className={cn("ui-editable-form__message", `ui-editable-form__message--${message.tone ?? "info"}`)} key={message.id}>
              {message.children}
            </div>
          ))}
        </div>
      ) : null}

      {sections.length > 0 ? (
        <div className="ui-editable-form__sections">
          {sections.map((section) => (
            <EditableFormSectionView key={section.id} section={section} />
          ))}
        </div>
      ) : null}

      {children ? <div className="ui-editable-form__body">{children}</div> : null}
      {footer ? <footer className="ui-editable-form__footer">{footer}</footer> : null}
    </form>
  );
}

export function EditableFormActionStrip({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("ui-editable-form__action-strip", className)}>{children}</div>;
}

export type EditableFormResultItem = {
  id: string;
  label: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
  onSelect?: () => void;
  selected?: boolean;
  disabled?: boolean;
  selectLabel?: string;
};

export function EditableFormResultList({
  items,
  emptyLabel = "No results.",
}: {
  items: EditableFormResultItem[];
  emptyLabel?: ReactNode;
}) {
  return (
    <ul className="ui-editable-form__result-list">
      {items.length === 0 ? <li className="ui-editable-form__result-empty">{emptyLabel}</li> : null}
      {items.map((item) => (
        <li
          key={item.id}
          className={cn(
            "ui-editable-form__result-item",
            item.selected && "is-selected",
            item.disabled && "is-disabled",
          )}
        >
          {item.onSelect ? (
            <button
              type="button"
              className="ui-editable-form__result-button"
              aria-current={item.selected ? "true" : undefined}
              aria-label={item.selectLabel}
              disabled={item.disabled}
              onClick={item.onSelect}
            >
              <EditableFormResultContent item={item} />
            </button>
          ) : (
            <EditableFormResultContent item={item} />
          )}
          {item.action ? <span className="ui-editable-form__result-action">{item.action}</span> : null}
        </li>
      ))}
    </ul>
  );
}

export type EditableChecklistItem = {
  id: string;
  label: ReactNode;
  checked?: boolean;
  /** Blocks the row's toggle without removing the checked state from the a11y tree. */
  disabled?: boolean;
  /** Per-row toggle intent; takes precedence over the list-level `onToggle`. */
  onToggle?: (checked: boolean) => void;
  action?: ReactNode;
};

export type EditableChecklistProps = {
  items: EditableChecklistItem[];
  emptyLabel?: ReactNode;
  /** Toggle intent for any row without its own `onToggle`. */
  onToggle?: (id: string, checked: boolean) => void;
};

/**
 * Checked rows for review and sign-off subsections of an `EditableFormPanel`.
 *
 * A row is interactive when a toggle handler resolves for it — its own
 * `onToggle`, or the list-level `onToggle`. Rows without one render `disabled`
 * and `aria-readonly`, because `readOnly` is inert on a checkbox: the box still
 * accepted clicks and React silently reverted them, so the control advertised
 * an affordance it never had. Checked state stays caller-owned either way; this
 * component holds no state.
 */
export function EditableChecklist({ items, emptyLabel = "No checklist items.", onToggle }: EditableChecklistProps) {
  return (
    <div className="ui-editable-form__checklist">
      {items.length === 0 ? <p className="ui-editable-form__checklist-empty">{emptyLabel}</p> : null}
      {items.map((item) => {
        const toggle = item.onToggle ?? (onToggle ? (checked: boolean) => onToggle(item.id, checked) : undefined);
        const interactive = Boolean(toggle) && !item.disabled;
        return (
          <label className="ui-editable-form__checklist-row" key={item.id}>
            <input
              aria-readonly={interactive ? undefined : true}
              checked={item.checked ?? false}
              disabled={!interactive}
              readOnly={!interactive}
              type="checkbox"
              onChange={interactive ? (event) => toggle?.(event.currentTarget.checked) : undefined}
            />
            <span>{item.label}</span>
            {item.action ? <span className="ui-editable-form__checklist-action">{item.action}</span> : null}
          </label>
        );
      })}
    </div>
  );
}

function EditableFormSectionView({ section }: { section: EditableFormSection }) {
  return (
    <section className="ui-editable-form__section">
      <div className="ui-editable-form__section-header">
        <div>
          <h3>{section.title}</h3>
          {section.description ? <p>{section.description}</p> : null}
        </div>
        {section.actions ? <div className="ui-editable-form__section-actions">{section.actions}</div> : null}
      </div>
      {section.fields?.length ? (
        <div className="ui-editable-form__grid">
          {section.fields.map((field) => (
            <EditableFormFieldView field={field} key={field.id} />
          ))}
        </div>
      ) : null}
      {section.children ? <div className="ui-editable-form__section-body">{section.children}</div> : null}
    </section>
  );
}

function EditableFormFieldView({ field }: { field: EditableFormField }) {
  return (
    <label className={cn("ui-editable-form__field", field.wide && "is-wide")}>
      <span className="ui-editable-form__field-label">
        <span>{field.label}</span>
        {field.required ? <strong aria-hidden="true">*</strong> : null}
        {field.meta ? <small>{field.meta}</small> : null}
      </span>
      {field.control}
      {field.hint ? <span className="ui-editable-form__hint">{field.hint}</span> : null}
      {field.error ? <span className="ui-editable-form__error">{field.error}</span> : null}
    </label>
  );
}

function EditableFormResultContent({ item }: { item: EditableFormResultItem }) {
  return (
    <span className="ui-editable-form__result-content">
      <strong>{item.label}</strong>
      {item.description ? <small>{item.description}</small> : null}
    </span>
  );
}
