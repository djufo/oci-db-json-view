# WorkflowCommandBar

## Goal

Provide a presentational command bar for Score-style work item workflow
transitions: current state, legal next/back actions, permission-disabled
commands, release-gate notes, compact card usage, and comfortable detail usage.

## Source Pressure

- Score `ui/src/features/board/components/TaskCard.tsx` renders legal move
  commands inside each task card.
- Score `ui/src/features/board/containers/BoardContainer.tsx` filters commands
  through actor role, project access, and release grants.
- Score `ui/src/features/board/components/TaskDetail.tsx` keeps detail header
  actions such as edit, subscription, and delete adjacent to workflow context.

## Contract

- `WorkflowCommandBar` accepts controlled command descriptors and emits
  `onSelect` callbacks.
- Commands can mark next, back, or neutral direction, show destination state,
  metadata, disabled/busy states, and optional custom icons.
- `disabled` and `busy` are different states (`src/theme/STATES.md` rule 5).
  Only `disabled` takes the native `disabled` attribute. A `busy` command stays
  **focusable**, announces `aria-busy="true"`, keeps an accessible name naming
  that specific command, and refuses re-activation in its handler.
- Consumers own workflow legality, transition DTOs, release-gate permission
  checks, persistence, audit events, toasts, and route updates.

## Non-Goals

- No Score status model, actor lookup, permission rules, release policy, API
  call, transition validation, subscription state, or destructive confirmation.

## Review Expectations

- Compact layout must fit in task-card action rows without overflow.
- Comfortable layout must support explanatory command copy in detail panels.
- Disabled and busy commands must remain visually distinct and keyboard-safe.
