# DiscoveryCloudPanel

## Purpose

`DiscoveryCloudPanel` is a presentational linked-cloud surface for catalog,
registry, search, and content-discovery screens. It makes keyword, pattern, tag,
or category clouds reusable without owning search, routes, count derivation, or
analytics.

## Source Evidence

- Score Catalog Explorer renders local `CatalogCloud` and `CloudGroup` sections
  in
  `/engineering/projects/score/ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`.
- eLitua larger layout, shell, sidebar, bottom-sheet, account-menu, portal,
  explorer, map, table, and public-page structures were checked first and are
  already represented by earlier `emibs-ui-lib` extractions.
- Existing `FacetFilterPanel` covers selected filters and counted options, but
  it does not cover lightweight linked discovery clouds for pattern and keyword
  navigation.

## Contract

- Consumers pass groups of cloud items with labels, optional counts, details,
  size/emphasis, active state, hrefs, or item callbacks.
- `DiscoveryCloudPanel` renders only the cloud chrome. Apps keep query parsing,
  search matching, URL synchronization, cloud generation, active-state
  derivation, persistence, and analytics.
- Items render as anchors when `href` is provided, buttons when only `onSelect`
  is provided, and inert labels when neither exists.
- Styling uses `ui-discovery-cloud*` classes and shared token variables only.

## Non-Goals

- No search parser, keyword extraction, count calculation, registry schema,
  route adapter, saved filter behavior, local storage, or product DTO mapping.
- No assumption that cloud values come from Score catalog metadata.

## Review Expectations

- Long labels wrap without pushing counts or details out of the panel.
- Empty panel, empty group, anchor, button, active, disabled, compact, and
  comfortable states are visible in the catalog.
- Keyboard users can focus and activate every linked or button-backed cloud
  item.
