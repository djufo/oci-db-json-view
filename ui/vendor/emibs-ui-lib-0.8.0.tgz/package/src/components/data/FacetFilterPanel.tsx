import { type ReactNode } from "react";
import { ListFilter, X } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type FacetFilterMode = "any" | "all";

export type FacetFilterOption = {
  id: string;
  label: ReactNode;
  count?: ReactNode;
  detail?: ReactNode;
  tone?: BadgeTone;
  selected?: boolean;
  disabled?: boolean;
  onSelect?: () => void;
};

export type FacetFilterModeControl = {
  value: FacetFilterMode;
  anyLabel?: ReactNode;
  allLabel?: ReactNode;
  onChange?: (mode: FacetFilterMode) => void;
};

export type FacetFilterGroup = {
  id: string;
  label: ReactNode;
  description?: ReactNode;
  options: FacetFilterOption[];
  allOption?: FacetFilterOption;
  modeControl?: FacetFilterModeControl;
  emptyLabel?: ReactNode;
};

export type FacetFilterChip = {
  id: string;
  label: ReactNode;
  value?: ReactNode;
  tone?: BadgeTone;
  onRemove?: () => void;
};

export type FacetFilterPanelProps = {
  title?: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
  resultCount?: ReactNode;
  groups: FacetFilterGroup[];
  activeFilters?: FacetFilterChip[];
  actions?: ReactNode;
  resetLabel?: ReactNode;
  emptyLabel?: ReactNode;
  density?: "compact" | "comfortable";
  className?: string;
  onReset?: () => void;
};

export function FacetFilterPanel({
  title = "Filters",
  description,
  icon,
  resultCount,
  groups,
  activeFilters = [],
  actions,
  resetLabel = "Clear filters",
  emptyLabel = "No facet options available.",
  density = "comfortable",
  className,
  onReset,
}: FacetFilterPanelProps) {
  return (
    <section className={cn("ui-facet-filter", `ui-facet-filter--${density}`, className)}>
      <header className="ui-facet-filter__header">
        <div className="ui-facet-filter__title-row">
          <span className="ui-facet-filter__icon" aria-hidden="true">
            {icon ?? <ListFilter size={18} />}
          </span>
          <div className="ui-facet-filter__title-block">
            <h2>{title}</h2>
            {description ? <p>{description}</p> : null}
          </div>
        </div>
        <div className="ui-facet-filter__header-actions">
          {resultCount ? <Badge tone="info">{resultCount}</Badge> : null}
          {actions}
        </div>
      </header>

      {activeFilters.length > 0 || onReset ? (
        <div className="ui-facet-filter__active" aria-label="Active filters">
          {activeFilters.length > 0 ? (
            <div className="ui-facet-filter__chips">
              {activeFilters.map((filter) => (
                <FacetFilterChipView filter={filter} key={filter.id} />
              ))}
            </div>
          ) : (
            <span className="ui-facet-filter__active-empty">No active filters.</span>
          )}
          {onReset ? (
            <button type="button" className="ui-facet-filter__reset" onClick={onReset}>
              {resetLabel}
            </button>
          ) : null}
        </div>
      ) : null}

      <div className="ui-facet-filter__groups">
        {groups.length > 0 ? (
          groups.map((group) => <FacetFilterGroupView group={group} key={group.id} />)
        ) : (
          <p className="ui-facet-filter__empty">{emptyLabel}</p>
        )}
      </div>
    </section>
  );
}

function FacetFilterGroupView({ group }: { group: FacetFilterGroup }) {
  const options = group.allOption ? [group.allOption, ...group.options] : group.options;
  const headingId = `facet-filter-${group.id}-heading`;
  return (
    <section className="ui-facet-filter__group" aria-labelledby={headingId}>
      <div className="ui-facet-filter__group-header">
        <h3 id={headingId}>{group.label}</h3>
        {group.modeControl ? <FacetFilterModeToggle control={group.modeControl} groupLabel={group.label} /> : null}
      </div>
      {group.description ? <p className="ui-facet-filter__group-description">{group.description}</p> : null}
      <div className="ui-facet-filter__options">
        {options.length > 0 ? (
          options.map((option) => <FacetFilterOptionButton key={option.id} option={option} />)
        ) : (
          <span className="ui-facet-filter__empty">{group.emptyLabel ?? "No options."}</span>
        )}
      </div>
    </section>
  );
}

function FacetFilterModeToggle({
  control,
  groupLabel,
}: {
  control: FacetFilterModeControl;
  groupLabel: ReactNode;
}) {
  return (
    <span className="ui-facet-filter__mode" role="group" aria-label={`${plainLabel(groupLabel)} match mode`}>
      <button
        type="button"
        className={cn(control.value === "any" && "is-active")}
        aria-pressed={control.value === "any"}
        onClick={() => control.onChange?.("any")}
      >
        {control.anyLabel ?? "Any"}
      </button>
      <button
        type="button"
        className={cn(control.value === "all" && "is-active")}
        aria-pressed={control.value === "all"}
        onClick={() => control.onChange?.("all")}
      >
        {control.allLabel ?? "All"}
      </button>
    </span>
  );
}

function FacetFilterOptionButton({ option }: { option: FacetFilterOption }) {
  return (
    <button
      type="button"
      className={cn("ui-facet-filter__option", option.selected && "is-selected")}
      disabled={option.disabled}
      aria-pressed={option.selected}
      onClick={option.onSelect}
    >
      <span className="ui-facet-filter__option-copy">
        <span>{option.label}</span>
        {option.detail ? <small>{option.detail}</small> : null}
      </span>
      {option.count !== undefined ? <span className="ui-facet-filter__count">{option.count}</span> : null}
    </button>
  );
}

function FacetFilterChipView({ filter }: { filter: FacetFilterChip }) {
  const content = (
    <>
      <span className="ui-facet-filter__chip-label">{filter.label}</span>
      {filter.value ? <span className="ui-facet-filter__chip-value">{filter.value}</span> : null}
    </>
  );

  if (filter.onRemove) {
    return (
      <button
        type="button"
        className={cn("ui-facet-filter__chip", filter.tone && `ui-facet-filter__chip--${filter.tone}`)}
        onClick={filter.onRemove}
      >
        {content}
        <X size={13} aria-hidden="true" />
      </button>
    );
  }

  return <span className={cn("ui-facet-filter__chip", filter.tone && `ui-facet-filter__chip--${filter.tone}`)}>{content}</span>;
}

function plainLabel(value: ReactNode): string {
  return typeof value === "string" ? value : "Facet";
}
