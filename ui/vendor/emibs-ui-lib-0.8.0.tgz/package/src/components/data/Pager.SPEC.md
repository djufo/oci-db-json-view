# Pager

## Purpose

`Pager` is a controlled presentational pagination control for entity tables,
card grids, record footers, and map/browser bottom bars.

## Source Evidence

- eLitua `ui/src/emibs-lib/components/Pager/Pager.tsx` repeats first,
  previous, next, and last page controls with disabled boundary states.
- eLitua `ui/src/emibs-lib/components/PaginationInfo/PaginationInfo.tsx`
  pairs that pager with full and compact result summaries.
- eLitua client/admin accommodation, guide, geo, and place table/card views
  compose those two pieces across many entity browsing surfaces.

## Contract

- Accepts controlled `page`, `total`, optional `summary`, optional
  `compactSummary`, and optional `onPageChange`.
- Clamps the rendered page label to a valid range and disables movement
  controls at the first/last page or when no callback is supplied.
- Renders first/last controls by default, with `showFirstLast={false}` for
  tighter footers.
- Callers may localize all accessible labels and summary content.

## Non-Goals

- No item counting, page-size state, URL synchronization, filtering, sorting,
  persistence, translations, data fetching, or selected-record synchronization.
- No table/card layout ownership; `DataTable`, `EntityCardGridPanel`, and
  product screens own the surrounding browser shell.

## Review Expectations

- Full and compact summaries must not overlap controls in narrow containers.
- Boundary buttons must be disabled and keyboard-inert on the first and last
  page.
- Controls must remain stable when embedded in dense table toolbars and record
  detail footers.
