import { useEffect, useRef, useState } from "react";
import { Button } from "../primitives/Button";
import { Field, Input } from "../primitives/Field";
import { GeoCoordinatePicker } from "./GeoCoordinatePicker";
import { isGeoPoint, type AddressMapAdapter, type AddressValue } from "./addressTypes";

export type { AddressValue, AddressMapAdapter, GeoPoint, MapAdapterViewProps } from "./addressTypes";

export type AddressFieldProps = {
  value: AddressValue;
  onChange: (value: AddressValue) => void;
  canEdit?: boolean;
  readOnly?: boolean;
  searchAddresses?: (query: string, signal: AbortSignal) => Promise<AddressValue[]>;
  mapAdapter?: AddressMapAdapter;
  /** Display name for the caller-controlled countryCode. */
  countryLabel?: string;
};

export function AddressField({ value, onChange, canEdit = value.canEdit ?? true, readOnly = false, searchAddresses, mapAdapter, countryLabel = value.countryCode }: AddressFieldProps) {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<AddressValue[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [locating, setLocating] = useState(false);
  const [locationError, setLocationError] = useState("");
  const request = useRef<AbortController | null>(null);
  const locationRequest = useRef<AbortController | null>(null);
  const locked = readOnly || !canEdit;
  const geocode = mapAdapter?.geocode;
  const addressQuery = [value.street, value.number, value.city, value.postcode, value.countryCode].filter(Boolean).join(", ");

  useEffect(() => {
    request.current?.abort();
    setResults(null);
    setLoading(false);
    setError("");
    return () => { request.current?.abort(); };
  }, [searchAddresses, readOnly]);

  useEffect(() => {
    locationRequest.current?.abort();
    setLocating(false);
    setLocationError("");
    return () => { locationRequest.current?.abort(); };
  }, [geocode, locked, value]);

  async function search() {
    if (!searchAddresses || readOnly || loading) return;
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setLoading(true);
    setError("");
    setResults(null);
    try {
      const addresses = await searchAddresses(query.slice(0, 128), controller.signal);
      if (!controller.signal.aborted) setResults(addresses.slice(0, 50));
    } catch {
      if (!controller.signal.aborted) setError("Address search unavailable. Try again.");
    } finally {
      if (!controller.signal.aborted) setLoading(false);
    }
  }

  async function locate() {
    if (!geocode || locked || locating) return;
    locationRequest.current?.abort();
    const controller = new AbortController();
    locationRequest.current = controller;
    setLocating(true);
    setLocationError("");
    try {
      const point = await geocode(addressQuery, controller.signal);
      if (controller.signal.aborted) return;
      if (point && isGeoPoint(point)) onChange({ ...value, ...point });
      else setLocationError("Location not found. Enter coordinates manually.");
    } catch {
      if (!controller.signal.aborted) setLocationError("Address location unavailable. Enter coordinates manually.");
    } finally {
      if (!controller.signal.aborted) setLocating(false);
    }
  }

  return (
    <div className="ui-address-field">
      {searchAddresses && !readOnly && (
        <div className="ui-address-field">
          <div className="ui-address-field__search">
            <Field label="Find existing address">
              <Input value={query} maxLength={128} onChange={event => {
                request.current?.abort();
                setLoading(false);
                setResults(null);
                setError("");
                setQuery(event.currentTarget.value.slice(0, 128));
              }} onKeyDown={event => {
                if (event.key === "Enter") { event.preventDefault(); void search(); }
              }} />
            </Field>
            <Button type="button" loading={loading} onClick={() => void search()}>Search addresses</Button>
          </div>
          {error && <p role="alert">{error}</p>}
          {results && <div aria-live="polite" className="ui-address-field">
            {results.length === 0 && <p>No addresses found.</p>}
            {results.map((address, index) => <Button type="button" key={address.id ?? index} onClick={() => {
              if (readOnly) return;
              onChange(address);
              setResults(null);
            }}>
              {[address.street, address.number, address.city, address.postcode].filter(Boolean).join(", ")}
              {address.canEdit === false ? " · Read-only" : ""}
            </Button>)}
          </div>}
        </div>
      )}
      <div className="ui-address-field__grid">
        {([
          ["street", "Street", 127], ["number", "Number", 31],
          ["city", "Town / city", 31], ["postcode", "Postcode", 31],
        ] as const).map(([field, label, maxLength]) => (
          <Field key={field} label={label}>
            <Input value={value[field]} readOnly={locked} maxLength={maxLength} onChange={event => {
              if (!locked) onChange({ ...value, [field]: event.currentTarget.value.slice(0, maxLength) });
            }} />
          </Field>
        ))}
        <Field label="Country"><Input value={countryLabel} readOnly /></Field>
      </div>
      {locked && <p className="ui-address-field__help">Read-only address</p>}
      {geocode && !locked && <div>
        <Button type="button" loading={locating} onClick={() => void locate()}>Locate address</Button>
      </div>}
      {locationError && <p role="alert">{locationError}</p>}
      <GeoCoordinatePicker latitude={value.latitude} longitude={value.longitude} readOnly={locked} mapAdapter={mapAdapter} onChange={point => {
        if (!locked) onChange({ ...value, ...point });
      }} />
    </div>
  );
}
