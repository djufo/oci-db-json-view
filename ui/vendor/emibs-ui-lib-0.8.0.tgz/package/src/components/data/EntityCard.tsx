import { type CSSProperties, type ReactNode } from "react";
import { ExternalLink, ImageIcon } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type EntityCardBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type EntityCardMeta = {
  id: string;
  label: ReactNode;
  icon?: ReactNode;
};

export type EntityCardImage = {
  src: string;
  alt: string;
};

export type EntityCardProps = {
  title: ReactNode;
  subtitle?: ReactNode;
  description?: ReactNode;
  eyebrow?: ReactNode;
  meta?: ReactNode;
  metaItems?: EntityCardMeta[];
  tags?: string[];
  badges?: EntityCardBadge[];
  image?: EntityCardImage;
  icon?: ReactNode;
  imageFallback?: ReactNode;
  showMedia?: boolean;
  accentColor?: string;
  footer?: ReactNode;
  action?: ReactNode;
  actions?: ReactNode;
  href?: string;
  external?: boolean;
  selected?: boolean;
  disabled?: boolean;
  density?: "comfortable" | "compact";
  actionLabel?: ReactNode;
  onSelect?: () => void;
  className?: string;
};

export function EntityCard({
  title,
  subtitle,
  description,
  eyebrow,
  meta,
  metaItems = [],
  tags,
  badges = [],
  image,
  icon,
  imageFallback,
  showMedia,
  accentColor,
  footer,
  action,
  actions,
  href,
  external = false,
  selected = false,
  disabled = false,
  density = "comfortable",
  actionLabel = "Open record",
  onSelect,
  className,
}: EntityCardProps) {
  const hasMedia = Boolean(showMedia || image || icon || imageFallback);
  const style = accentColor
    ? ({ "--ui-entity-card-accent": accentColor } as CSSProperties)
    : undefined;

  return (
    <article
      className={cn(
        "ui-entity-card",
        `ui-entity-card--${density}`,
        selected && "is-selected",
        disabled && "is-disabled",
        className,
      )}
      style={style}
    >
      <EntityCardMain
        actionLabel={actionLabel}
        disabled={disabled}
        external={external}
        href={href}
        onSelect={onSelect}
      >
        {hasMedia ? <EntityCardMedia fallback={imageFallback} icon={icon} image={image} /> : null}
        <div className="ui-entity-card__body">
          <div className="ui-entity-card__title-row">
            <div className="ui-entity-card__title-copy">
              {eyebrow ? <span className="ui-entity-card__eyebrow">{eyebrow}</span> : null}
              <h3>
                <span>{title}</span>
                {external ? <ExternalLink size={14} aria-hidden="true" /> : null}
              </h3>
            </div>
            <EntityCardBadges badges={badges} tags={tags} />
          </div>
          {subtitle ? <p className="ui-entity-card__subtitle">{subtitle}</p> : null}
          {description ? <p className="ui-entity-card__description">{description}</p> : null}
          {meta ? <span className="ui-entity-card__legacy-meta">{meta}</span> : null}
          {metaItems.length > 0 ? <EntityCardMetaList items={metaItems} /> : null}
          {footer ? <div className="ui-entity-card__footer">{footer}</div> : null}
        </div>
      </EntityCardMain>
      {action || actions ? <div className="ui-entity-card__actions">{action ?? actions}</div> : null}
    </article>
  );
}

function EntityCardMain({
  actionLabel,
  children,
  disabled,
  external,
  href,
  onSelect,
}: {
  actionLabel: ReactNode;
  children: ReactNode;
  disabled: boolean;
  external: boolean;
  href?: string;
  onSelect?: () => void;
}) {
  if (href && !disabled) {
    return (
      <a
        className="ui-entity-card__main"
        href={href}
        rel={external ? "noreferrer" : undefined}
        target={external ? "_blank" : undefined}
      >
        {children}
      </a>
    );
  }

  if (onSelect) {
    return (
      <button className="ui-entity-card__main" disabled={disabled} onClick={onSelect} type="button">
        {children}
        <span className="ui-sr-only">{actionLabel}</span>
      </button>
    );
  }

  return <div className="ui-entity-card__main">{children}</div>;
}

function EntityCardMedia({
  fallback,
  icon,
  image,
}: {
  fallback?: ReactNode;
  icon?: ReactNode;
  image?: EntityCardImage;
}) {
  return (
    <div className="ui-entity-card__media" aria-hidden={!image}>
      {image ? <img src={image.src} alt={image.alt} /> : <span>{fallback ?? icon ?? <ImageIcon size={24} aria-hidden="true" />}</span>}
    </div>
  );
}

function EntityCardBadges({
  badges,
  tags,
}: {
  badges: EntityCardBadge[];
  tags?: string[];
}) {
  const tagBadges = (tags ?? []).map<EntityCardBadge>((tag) => ({
    id: tag,
    label: tag,
    tone: "accent",
  }));
  const items = [...badges, ...tagBadges];
  if (items.length === 0) {
    return null;
  }
  return (
    <div className="ui-entity-card__badges">
      {items.map((badge) => (
        <Badge key={badge.id} tone={badge.tone}>
          {badge.label}
        </Badge>
      ))}
    </div>
  );
}

function EntityCardMetaList({ items }: { items: EntityCardMeta[] }) {
  return (
    <div className="ui-entity-card__meta">
      {items.map((item) => (
        <span key={item.id}>
          {item.icon}
          {item.label}
        </span>
      ))}
    </div>
  );
}
