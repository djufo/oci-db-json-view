import { type ReactNode } from "react";
import { GitCompare, Pin, X } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type CompareTrayBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type CompareTrayAction = {
  label: ReactNode;
  activeLabel?: ReactNode;
  icon?: ReactNode;
  active?: boolean;
  disabled?: boolean;
  ariaLabel?: string;
  onClick?: () => void;
};

export type CompareTrayItem = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  meta?: ReactNode;
  href?: string;
  external?: boolean;
  badges?: CompareTrayBadge[];
  preview: ReactNode;
  previewLabel?: string;
  previewInert?: boolean;
  removeLabel?: string;
  onRemove?: () => void;
  actions?: ReactNode;
};

export type CompareTrayPanelProps = {
  title?: ReactNode;
  description?: ReactNode;
  icon?: ReactNode;
  resultCount?: ReactNode;
  currentAction?: CompareTrayAction;
  actions?: ReactNode;
  items: CompareTrayItem[];
  emptyLabel?: ReactNode;
  density?: "compact" | "comfortable";
  className?: string;
};

export function CompareTrayPanel({
  title = "Compare tray",
  description,
  icon,
  resultCount,
  currentAction,
  actions,
  items,
  emptyLabel = "Pin items to compare them side by side.",
  density = "comfortable",
  className,
}: CompareTrayPanelProps) {
  return (
    <section className={cn("ui-compare-tray", `ui-compare-tray--${density}`, className)}>
      <header className="ui-compare-tray__header">
        <div className="ui-compare-tray__title-row">
          <span className="ui-compare-tray__icon" aria-hidden="true">
            {icon ?? <GitCompare size={18} />}
          </span>
          <div className="ui-compare-tray__title-block">
            <h2>{title}</h2>
            {description ? <p>{description}</p> : null}
          </div>
        </div>
        <div className="ui-compare-tray__header-actions">
          {resultCount ? <Badge tone="info">{resultCount}</Badge> : null}
          {currentAction ? <CompareTrayActionButton action={currentAction} /> : null}
          {actions}
        </div>
      </header>

      {items.length > 0 ? (
        <div className="ui-compare-tray__grid">
          {items.map((item) => (
            <CompareTrayCard item={item} key={item.id} />
          ))}
        </div>
      ) : (
        <p className="ui-compare-tray__empty">{emptyLabel}</p>
      )}
    </section>
  );
}

function CompareTrayActionButton({ action }: { action: CompareTrayAction }) {
  const label = action.active && action.activeLabel ? action.activeLabel : action.label;
  return (
    <button
      aria-label={action.ariaLabel}
      aria-pressed={action.active}
      className={cn("ui-compare-tray__action", action.active && "is-active")}
      disabled={action.disabled}
      type="button"
      onClick={action.onClick}
    >
      <span aria-hidden="true">{action.icon ?? <Pin size={15} />}</span>
      <span>{label}</span>
    </button>
  );
}

function CompareTrayCard({ item }: { item: CompareTrayItem }) {
  return (
    <article className="ui-compare-tray__card">
      <header className="ui-compare-tray__card-header">
        <div className="ui-compare-tray__card-copy">
          <h3>{item.href ? <CompareTrayLink item={item} /> : item.title}</h3>
          {item.meta ? <p>{item.meta}</p> : null}
          {item.description ? <small>{item.description}</small> : null}
        </div>
        <div className="ui-compare-tray__card-actions">
          {item.actions}
          {item.onRemove ? (
            <button
              aria-label={item.removeLabel ?? `Remove ${plainLabel(item.title)} from compare tray`}
              className="ui-compare-tray__remove"
              type="button"
              onClick={item.onRemove}
            >
              <X size={15} aria-hidden="true" />
            </button>
          ) : null}
        </div>
      </header>
      {item.badges?.length ? (
        <div className="ui-compare-tray__badges">
          {item.badges.map((badge) => (
            <Badge key={badge.id} tone={badge.tone}>
              {badge.label}
            </Badge>
          ))}
        </div>
      ) : null}
      <div
        aria-label={item.previewLabel}
        className={cn("ui-compare-tray__preview", item.previewInert && "is-inert")}
        role={item.previewLabel ? "group" : undefined}
      >
        {item.preview}
      </div>
    </article>
  );
}

function CompareTrayLink({ item }: { item: CompareTrayItem }) {
  return (
    <a href={item.href} rel={item.external ? "noreferrer" : undefined} target={item.external ? "_blank" : undefined}>
      {item.title}
    </a>
  );
}

function plainLabel(value: ReactNode): string {
  if (typeof value === "string" || typeof value === "number") {
    const label = String(value).trim();
    return label || "item";
  }
  return "item";
}
