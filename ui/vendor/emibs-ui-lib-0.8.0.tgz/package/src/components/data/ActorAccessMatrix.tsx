import { type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { CheckboxControl } from "../primitives/CheckboxControl";

export type ActorAccessRoleOption = {
  value: string;
  label: ReactNode;
};

export type ActorAccessGrant = {
  id: string;
  label: ReactNode;
  checked: boolean;
  description?: ReactNode;
  disabled?: boolean;
  saving?: boolean;
};

export type ActorAccessItem = {
  id: string;
  primary: ReactNode;
  secondary?: ReactNode;
  meta?: ReactNode;
  interfaceLabel?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  role?: string;
  roleOptions?: ActorAccessRoleOption[];
  roleDisabled?: boolean;
  grants?: ActorAccessGrant[];
  actions?: ReactNode;
};

export type ActorAccessMatrixProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  contextLabel?: ReactNode;
  contextValue?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  actors: ActorAccessItem[];
  loading?: boolean;
  error?: ReactNode;
  emptyLabel?: ReactNode;
  actorColumnLabel?: ReactNode;
  interfaceColumnLabel?: ReactNode;
  statusColumnLabel?: ReactNode;
  roleColumnLabel?: ReactNode;
  grantsColumnLabel?: ReactNode;
  actionsColumnLabel?: ReactNode;
  onRoleChange?: (actorId: string, role: string) => void;
  onGrantChange?: (actorId: string, grantId: string, checked: boolean) => void;
  className?: string;
};

export function ActorAccessMatrix({
  title,
  eyebrow,
  subtitle,
  contextLabel,
  contextValue,
  status,
  statusTone = "neutral",
  actions,
  actors,
  loading = false,
  error,
  emptyLabel = "No actors returned.",
  actorColumnLabel = "Actor",
  interfaceColumnLabel = "Interface",
  statusColumnLabel = "Status",
  roleColumnLabel = "Role",
  grantsColumnLabel = "Grants",
  actionsColumnLabel = "Actions",
  onRoleChange,
  onGrantChange,
  className,
}: ActorAccessMatrixProps) {
  const rowState = loading ? "loading" : actors.length === 0 ? "empty" : "ready";

  return (
    <section className={cn("ui-actor-access", className)}>
      <header className="ui-actor-access__header">
        <div className="ui-actor-access__title-block">
          {eyebrow ? <span className="ui-actor-access__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
        <div className="ui-actor-access__header-actions">
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {contextLabel || contextValue ? (
        <div className="ui-actor-access__context">
          {contextLabel ? <span>{contextLabel}</span> : null}
          {contextValue ? <strong>{contextValue}</strong> : null}
        </div>
      ) : null}

      {error ? (
        <div className="ui-actor-access__error" role="alert">
          {error}
        </div>
      ) : null}

      <div className="ui-actor-access__table-wrap">
        <table className="ui-actor-access__table">
          <thead>
            <tr>
              <th scope="col">{actorColumnLabel}</th>
              <th scope="col">{interfaceColumnLabel}</th>
              <th scope="col">{statusColumnLabel}</th>
              <th scope="col">{roleColumnLabel}</th>
              <th scope="col">{grantsColumnLabel}</th>
              <th scope="col">{actionsColumnLabel}</th>
            </tr>
          </thead>
          <tbody>
            {rowState === "loading" ? (
              <tr>
                <td colSpan={6}>Loading access rows.</td>
              </tr>
            ) : null}
            {rowState === "empty" ? (
              <tr>
                <td colSpan={6}>{emptyLabel}</td>
              </tr>
            ) : null}
            {rowState === "ready"
              ? actors.map((actor) => (
                  <tr key={actor.id}>
                    <th scope="row">
                      <span className="ui-actor-access__identity">
                        <strong>{actor.primary}</strong>
                        {actor.secondary ? <span>{actor.secondary}</span> : null}
                        {actor.meta ? <small>{actor.meta}</small> : null}
                      </span>
                    </th>
                    <td>{actor.interfaceLabel ?? "Actor"}</td>
                    <td>
                      {actor.status ? <Badge tone={actor.statusTone}>{actor.status}</Badge> : <span className="ui-actor-access__muted">Unknown</span>}
                    </td>
                    <td>
                      <ActorRoleSelect actor={actor} onRoleChange={onRoleChange} />
                    </td>
                    <td>
                      <ActorGrantList actor={actor} onGrantChange={onGrantChange} />
                    </td>
                    <td>{actor.actions ? <div className="ui-actor-access__actions">{actor.actions}</div> : null}</td>
                  </tr>
                ))
              : null}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function ActorRoleSelect({
  actor,
  onRoleChange,
}: {
  actor: ActorAccessItem;
  onRoleChange?: (actorId: string, role: string) => void;
}) {
  if (!actor.roleOptions?.length) {
    return <span>{actor.role || "Unassigned"}</span>;
  }

  return (
    <select
      className="ui-actor-access__select"
      value={actor.role ?? ""}
      aria-label={`Role for ${actor.id}`}
      disabled={actor.roleDisabled || !onRoleChange}
      onChange={(event) => onRoleChange?.(actor.id, event.target.value)}
    >
      {actor.roleOptions.map((option) => (
        <option key={option.value} value={option.value}>
          {option.label}
        </option>
      ))}
    </select>
  );
}

function ActorGrantList({
  actor,
  onGrantChange,
}: {
  actor: ActorAccessItem;
  onGrantChange?: (actorId: string, grantId: string, checked: boolean) => void;
}) {
  if (!actor.grants?.length) {
    return <span className="ui-actor-access__muted">No grants</span>;
  }

  return (
    <div className="ui-actor-access__grants">
      {actor.grants.map((grant) => (
        <CheckboxControl
          checked={grant.checked}
          className="ui-actor-access__grant-control"
          density="compact"
          description={grant.description}
          disabled={grant.disabled || !onGrantChange}
          key={grant.id}
          label={grant.label}
          status={grant.saving ? <Badge tone="info">Saving</Badge> : undefined}
          onChange={(checked) => onGrantChange?.(actor.id, grant.id, checked)}
        />
      ))}
    </div>
  );
}
