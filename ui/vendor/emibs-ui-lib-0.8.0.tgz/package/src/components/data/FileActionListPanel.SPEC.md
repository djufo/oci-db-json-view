# FileActionListPanel

## Purpose

`FileActionListPanel` is a presentational row-based file list for project or
record attachments that need metadata, status badges, and a compact per-file
action menu.

## Contract

- Accepts caller-supplied file rows, preformatted metadata, badges, header
  status/actions, loading/error/empty states, and per-row action descriptors.
- Renders a dense list layout optimized for project evidence and file libraries,
  separate from `MediaAssetPanel`'s thumbnail grid and `FilePreviewPanel`'s
  single-file preview surface.
- Supports controlled per-row action menu state through `menuOpenItemId` and
  `onMenuOpenChange`; consumers own command execution, confirmations, browser
  file-system APIs, routing, permissions, and toasts.
- Provides link and button action descriptors for open, download, copy/move,
  delete, or product-specific commands.
- Uses `ui-file-action-list*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/features/projects/containers/ProjectsContainer.tsx` renders
  project profile attachments as a file row list with kind icon, filename,
  content type, size/date/uploader metadata, action menu, open/download,
  browser-supported download-to-folder, copy/move to another project, and delete
  confirmation.
- Existing `MediaAssetPanel` covers task attachment and profile media grids with
  preview detail; this extraction targets the newer project-file evidence list
  where row density and action menus matter more than preview thumbnails.
- Existing `FilePreviewPanel` covers single attachment preview chrome and stays
  complementary to this list.

## Non-Goals

- No attachment fetching, upload transport, signed URL creation, copy/move API
  calls, browser directory picker calls, destructive confirmations, permission
  policy, persistence, routing, localization, or toast side effects.
- No adoption into Score in this extraction; adoption is tracked by a
  low-priority UI Framework refactor task.
