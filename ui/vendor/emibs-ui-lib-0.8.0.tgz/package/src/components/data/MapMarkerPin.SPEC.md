# MapMarkerPin

## Purpose

`MapMarkerPin` is a presentational map marker glyph for reviewable map pins,
selected entity markers, compact dot markers, and cluster counts before product
apps wire them into a real map engine.

## Contract

- Renders a stable-size marker in `pin`, `dot`, or `cluster` form.
- Supports info, success, warning, danger, and neutral tones, with selected
  state overriding the tone for parity with eLitua's selected marker treatment.
- Accepts caller-supplied icon and label content. `showLabel` renders adjacent
  marker text for static map previews; otherwise the label is used for
  accessibility.
- Product apps own marker lifecycle, Google Maps instances, clustering, z-index
  calculation, click handlers, coordinate dispatch, localization, and entity
  selection state.
- Uses `ui-map-marker-pin*` CSS classes and shared token variables only.

## Source Evidence

- eLitua `ui/src/emibs-lib/features/googleMaps/services/MarkerIconService.tsx`
  builds bed, guide, selected, color, circle, and cluster SVG marker chrome.
- eLitua `ui/src/emibs-lib/features/googleMaps/services/MarkerService.tsx`
  maps marker icon types to selected and default marker variants before creating
  Google Maps AdvancedMarkerElement instances.
- emibs-ui-lib `MapViewport` already owns static review map chrome, but not the
  reusable pin glyph used by product marker services.

## Non-Goals

- No Google Maps dependency, DOM parser, SVG string service, marker cache,
  cluster algorithm, map bounds behavior, or route/query ownership.
- No adoption into eLitua in this extraction; adoption is tracked by a separate
  low-priority UI Framework refactor task.
