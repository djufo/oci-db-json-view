/**
 * DataTable engine — headless `useDataTable` hook (Part A, issue-758).
 *
 * Framework-agnostic state/logic for a data table: column model, 3-way sort,
 * client pagination, and optional single/multi row selection. Each concern is
 * usable both controlled (value + onChange) and uncontrolled (internal state).
 * The hook owns no JSX, styling, or DOM assumptions — it composes the pure
 * helpers in `core.ts` and hands the consumer the derived visible rows. A
 * styled DataTable renders on top of it in Part B (issue-760).
 */

import { useCallback, useMemo, useState } from "react";
import type {
  ColumnDef,
  PaginationState,
  SelectionMode,
  SortDirection,
  SortState,
} from "./types";
import {
  areAllSelected,
  clampPageIndex,
  columnSortDirection,
  derivePageCount,
  nextSortState,
  paginateRows,
  resolveControlled,
  sortRows,
  toggleAllSelection,
  toggleSelectionId,
} from "./core";

/** Default page size when no `pageSize` / `defaultPagination.pageSize` is given. */
const DEFAULT_PAGE_SIZE = 10;

export type UseDataTableOptions<T> = {
  /** Full client-side data set. */
  data: readonly T[];
  /** Column model. */
  columns: readonly ColumnDef<T>[];
  /** Stable row id accessor — keys selection and row identity. */
  getRowId: (row: T) => string;

  /** Controlled sort value. Pair with `onSortChange` for controlled usage. */
  sort?: SortState;
  /** Initial sort for uncontrolled usage. */
  defaultSort?: SortState;
  /** Called on every sort change (controlled and uncontrolled). */
  onSortChange?: (next: SortState) => void;

  /** Controlled pagination value. Pair with `onPaginationChange`. */
  pagination?: PaginationState;
  /** Initial pagination for uncontrolled usage. */
  defaultPagination?: Partial<PaginationState>;
  /** Convenience default page size when `defaultPagination.pageSize` is omitted. */
  pageSize?: number;
  /** Called on every pagination change. */
  onPaginationChange?: (next: PaginationState) => void;

  /** Enables row selection in the given mode. Selection is off when omitted. */
  selectionMode?: SelectionMode;
  /** Controlled selected row ids. Pair with `onSelectionChange`. */
  selection?: readonly string[];
  /** Initial selection for uncontrolled usage. */
  defaultSelection?: readonly string[];
  /** Called on every selection change. */
  onSelectionChange?: (next: string[]) => void;
};

export type UseDataTableResult<T> = {
  /** The column model passed in (echoed for renderer convenience). */
  columns: readonly ColumnDef<T>[];

  /* sort */
  sortState: SortState;
  /** Cycle a column's sort asc -> desc -> none. No-op for non-sortable columns. */
  toggleSort: (columnId: string) => void;
  /** Set the sort state directly. */
  setSort: (next: SortState) => void;
  /** Direction currently applied to a column, or null. */
  getColumnSortDirection: (columnId: string) => SortDirection | null;

  /* rows */
  /** All rows in sorted order (pre-pagination). New array; input unmutated. */
  sortedRows: T[];
  /** Visible rows for the current page (sorted + paginated). */
  rows: T[];
  /** Total row count in `data`. */
  rowCount: number;

  /* pagination */
  pageIndex: number;
  pageSize: number;
  pageCount: number;
  canPrev: boolean;
  canNext: boolean;
  gotoPage: (index: number) => void;
  nextPage: () => void;
  prevPage: () => void;
  /** Set the page size and reset to the first page. */
  setPageSize: (size: number) => void;

  /* selection */
  selectionEnabled: boolean;
  selectedIds: string[];
  isSelected: (rowId: string) => boolean;
  isAllSelected: boolean;
  /** Replace the selected ids directly (controlled and uncontrolled). */
  setSelection: (next: string[]) => void;
  toggleRow: (rowId: string) => void;
  toggleAll: () => void;
  clearSelection: () => void;
};

export function useDataTable<T>(
  options: UseDataTableOptions<T>,
): UseDataTableResult<T> {
  const {
    data,
    columns,
    getRowId,
    sort,
    defaultSort = null,
    onSortChange,
    pagination,
    defaultPagination,
    pageSize: pageSizeOption,
    onPaginationChange,
    selectionMode,
    selection,
    defaultSelection,
    onSelectionChange,
  } = options;

  /* ------------------------------- sort -------------------------------- */
  const [internalSort, setInternalSort] = useState<SortState>(defaultSort);
  const sortState = resolveControlled(sort, internalSort);

  const setSort = useCallback(
    (next: SortState) => {
      if (sort === undefined) setInternalSort(next);
      onSortChange?.(next);
    },
    [sort, onSortChange],
  );

  const toggleSort = useCallback(
    (columnId: string) => {
      const column = columns.find((c) => c.id === columnId);
      if (!column || column.sortable === false) return;
      setSort(nextSortState(sortState, columnId));
    },
    [columns, sortState, setSort],
  );

  const getColumnSortDirection = useCallback(
    (columnId: string) => columnSortDirection(sortState, columnId),
    [sortState],
  );

  const sortedRows = useMemo(
    () => sortRows(data, columns, sortState),
    [data, columns, sortState],
  );

  /* ---------------------------- pagination ----------------------------- */
  const [internalPagination, setInternalPagination] = useState<PaginationState>(
    () => ({
      pageIndex: defaultPagination?.pageIndex ?? 0,
      pageSize:
        defaultPagination?.pageSize ?? pageSizeOption ?? DEFAULT_PAGE_SIZE,
    }),
  );
  const effectivePagination = resolveControlled(pagination, internalPagination);

  const rowCount = data.length;
  const pageSize = effectivePagination.pageSize;
  const pageCount = derivePageCount(rowCount, pageSize);
  const pageIndex = clampPageIndex(effectivePagination.pageIndex, pageCount);

  const rows = useMemo(
    () => paginateRows(sortedRows, pageIndex, pageSize),
    [sortedRows, pageIndex, pageSize],
  );

  const commitPagination = useCallback(
    (next: PaginationState) => {
      if (pagination === undefined) setInternalPagination(next);
      onPaginationChange?.(next);
    },
    [pagination, onPaginationChange],
  );

  const gotoPage = useCallback(
    (index: number) => {
      commitPagination({
        pageIndex: clampPageIndex(index, pageCount),
        pageSize,
      });
    },
    [commitPagination, pageCount, pageSize],
  );
  const nextPage = useCallback(
    () => gotoPage(pageIndex + 1),
    [gotoPage, pageIndex],
  );
  const prevPage = useCallback(
    () => gotoPage(pageIndex - 1),
    [gotoPage, pageIndex],
  );
  const setPageSize = useCallback(
    (size: number) => {
      commitPagination({ pageIndex: 0, pageSize: size });
    },
    [commitPagination],
  );

  const canPrev = pageIndex > 0;
  const canNext = pageIndex < pageCount - 1;

  /* ----------------------------- selection ----------------------------- */
  const selectionEnabled = selectionMode !== undefined;
  const [internalSelection, setInternalSelection] = useState<string[]>(() => [
    ...(defaultSelection ?? []),
  ]);
  const selectedIds = useMemo(
    () => [...resolveControlled(selection, internalSelection)],
    [selection, internalSelection],
  );
  const allIds = useMemo(() => data.map(getRowId), [data, getRowId]);

  const commitSelection = useCallback(
    (next: string[]) => {
      if (selection === undefined) setInternalSelection(next);
      onSelectionChange?.(next);
    },
    [selection, onSelectionChange],
  );

  const isSelected = useCallback(
    (rowId: string) => selectedIds.includes(rowId),
    [selectedIds],
  );
  const isAllSelected = selectionEnabled && areAllSelected(selectedIds, allIds);

  const toggleRow = useCallback(
    (rowId: string) => {
      if (selectionMode === undefined) return;
      commitSelection(toggleSelectionId(selectedIds, rowId, selectionMode));
    },
    [selectionMode, commitSelection, selectedIds],
  );
  const toggleAll = useCallback(() => {
    if (selectionMode === undefined) return;
    commitSelection(toggleAllSelection(selectedIds, allIds, selectionMode));
  }, [selectionMode, commitSelection, selectedIds, allIds]);
  const clearSelection = useCallback(() => {
    if (selectedIds.length === 0) return;
    commitSelection([]);
  }, [selectedIds, commitSelection]);

  return {
    columns,
    sortState,
    toggleSort,
    setSort,
    getColumnSortDirection,
    sortedRows,
    rows,
    rowCount,
    pageIndex,
    pageSize,
    pageCount,
    canPrev,
    canNext,
    gotoPage,
    nextPage,
    prevPage,
    setPageSize,
    selectionEnabled,
    selectedIds,
    isSelected,
    isAllSelected,
    setSelection: commitSelection,
    toggleRow,
    toggleAll,
    clearSelection,
  };
}
