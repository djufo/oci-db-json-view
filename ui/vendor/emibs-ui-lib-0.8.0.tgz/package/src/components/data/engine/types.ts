/**
 * DataTable engine — framework-agnostic type surface.
 *
 * Part A of the DataTable epic (issue-720 / issue-758). These types describe
 * the column model plus sort / pagination / selection state shared by the
 * headless `useDataTable` hook and any renderer built on top of it (Part B,
 * issue-760). There are intentionally no React, DOM, or styling types here —
 * the engine mirrors the Forms (issue-552) / Overlays (issue-682) layering
 * where logic is renderer-agnostic.
 */

/** Ascending / descending sort directions. Unsorted is a `null` SortState. */
export type SortDirection = "asc" | "desc";

/** Active sort: a single column plus its direction, or `null` for unsorted. */
export type SortState = {
  columnId: string;
  direction: SortDirection;
} | null;

/** Horizontal alignment hint for a column (a renderer decides how to apply it). */
export type ColumnAlign = "left" | "center" | "right";

/**
 * Column definition, generic over the row type `T`.
 *
 * `accessor` yields the value used for default sorting/derivation; supply an
 * explicit `compare` for custom ordering.
 */
export type ColumnDef<T> = {
  /** Stable column identity (used by sort state and as a render key). */
  id: string;
  /** Human-readable header label. */
  header: string;
  /** Extracts the sortable/derivable value for a row. */
  accessor: (row: T) => unknown;
  /** When `false`, the column cannot be toggled into a sort. Defaults to sortable. */
  sortable?: boolean;
  /** Optional alignment hint for renderers. */
  align?: ColumnAlign;
  /** Optional width hint for renderers (number = px, string = raw CSS length). */
  width?: number | string;
  /** Optional custom comparator; overrides accessor-based ordering. */
  compare?: (a: T, b: T) => number;
};

/** Optional single- or multi-row selection mode. */
export type SelectionMode = "single" | "multi";

/** Client pagination position. */
export type PaginationState = {
  pageIndex: number;
  pageSize: number;
};
