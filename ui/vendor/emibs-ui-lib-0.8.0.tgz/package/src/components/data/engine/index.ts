/**
 * DataTable engine — public barrel.
 *
 * Headless state/logic core for the DataTable epic (issue-720). Import the
 * `useDataTable` hook and its types/pure helpers from here.
 */

export * from "./types";
export * from "./core";
export * from "./useDataTable";
