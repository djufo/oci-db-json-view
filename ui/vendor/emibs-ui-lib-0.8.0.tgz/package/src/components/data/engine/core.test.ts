import { describe, expect, it } from "vitest";
import type { ColumnDef } from "./types";
import {
  areAllSelected,
  clampPageIndex,
  columnSortDirection,
  defaultCompare,
  derivePageCount,
  nextSortState,
  paginateRows,
  resolveControlled,
  sortRows,
  toggleAllSelection,
  toggleSelectionId,
} from "./core";

type Row = { id: string; name: string; age: number; active?: boolean };

const columns: ColumnDef<Row>[] = [
  { id: "name", header: "Name", accessor: (r) => r.name },
  { id: "age", header: "Age", accessor: (r) => r.age },
  { id: "active", header: "Active", accessor: (r) => r.active },
  { id: "locked", header: "Locked", accessor: (r) => r.name, sortable: false },
];

const rows: Row[] = [
  { id: "a", name: "Charlie", age: 30, active: true },
  { id: "b", name: "Alice", age: 25, active: false },
  { id: "c", name: "Bob", age: 30, active: true },
  { id: "d", name: "Dana", age: 20, active: false },
];

/* ---------------------------------- sort --------------------------------- */

describe("nextSortState — 3-way cycle", () => {
  it("goes unsorted -> asc -> desc -> unsorted for the same column", () => {
    let s = nextSortState(null, "name");
    expect(s).toEqual({ columnId: "name", direction: "asc" });
    s = nextSortState(s, "name");
    expect(s).toEqual({ columnId: "name", direction: "desc" });
    s = nextSortState(s, "name");
    expect(s).toBeNull();
  });

  it("switching to a different column starts at asc", () => {
    const s = nextSortState({ columnId: "name", direction: "desc" }, "age");
    expect(s).toEqual({ columnId: "age", direction: "asc" });
  });
});

describe("columnSortDirection", () => {
  it("returns direction only for the active column", () => {
    const s = { columnId: "age", direction: "desc" } as const;
    expect(columnSortDirection(s, "age")).toBe("desc");
    expect(columnSortDirection(s, "name")).toBeNull();
    expect(columnSortDirection(null, "age")).toBeNull();
  });
});

describe("defaultCompare", () => {
  it("orders numbers, strings, booleans, and dates", () => {
    expect(defaultCompare(1, 2)).toBeLessThan(0);
    expect(defaultCompare("b", "a")).toBeGreaterThan(0);
    expect(defaultCompare(false, true)).toBeLessThan(0);
    expect(defaultCompare(new Date(1), new Date(2))).toBeLessThan(0);
  });

  it("sorts nullish and NaN values last", () => {
    expect(defaultCompare(null, 1)).toBeGreaterThan(0);
    expect(defaultCompare(1, undefined)).toBeLessThan(0);
    expect(defaultCompare(null, undefined)).toBe(0);
    expect(defaultCompare(NaN, 1)).toBeGreaterThan(0);
  });
});

describe("sortRows", () => {
  it("returns a new array and does not mutate the input", () => {
    const out = sortRows(rows, columns, { columnId: "name", direction: "asc" });
    expect(out).not.toBe(rows);
    expect(rows.map((r) => r.id)).toEqual(["a", "b", "c", "d"]);
    expect(out.map((r) => r.id)).toEqual(["b", "c", "a", "d"]); // Alice, Bob, Charlie, Dana
  });

  it("sorts descending", () => {
    const out = sortRows(rows, columns, { columnId: "age", direction: "desc" });
    expect(out.map((r) => r.age)).toEqual([30, 30, 25, 20]);
  });

  it("is stable — equal rows keep original order (asc and desc)", () => {
    const asc = sortRows(rows, columns, { columnId: "age", direction: "asc" });
    // ages: Dana20, Alice25, Charlie30, Bob30 — a(Charlie) before c(Bob) preserved
    expect(asc.map((r) => r.id)).toEqual(["d", "b", "a", "c"]);
    const desc = sortRows(rows, columns, { columnId: "age", direction: "desc" });
    // the two age=30 rows still keep original a-before-c order
    expect(desc.slice(0, 2).map((r) => r.id)).toEqual(["a", "c"]);
  });

  it("returns original order for no sort, unknown column, or non-sortable column", () => {
    expect(sortRows(rows, columns, null).map((r) => r.id)).toEqual(["a", "b", "c", "d"]);
    expect(
      sortRows(rows, columns, { columnId: "missing", direction: "asc" }).map((r) => r.id),
    ).toEqual(["a", "b", "c", "d"]);
    expect(
      sortRows(rows, columns, { columnId: "locked", direction: "asc" }).map((r) => r.id),
    ).toEqual(["a", "b", "c", "d"]);
  });

  it("uses a custom column comparator when provided", () => {
    const cols: ColumnDef<Row>[] = [
      { id: "byIdDesc", header: "X", accessor: (r) => r.id, compare: (a, b) => b.id.localeCompare(a.id) },
    ];
    const out = sortRows(rows, cols, { columnId: "byIdDesc", direction: "asc" });
    expect(out.map((r) => r.id)).toEqual(["d", "c", "b", "a"]);
  });
});

/* ------------------------------- pagination ------------------------------ */

describe("derivePageCount", () => {
  it("handles empty data (0 pages)", () => {
    expect(derivePageCount(0, 10)).toBe(0);
  });
  it("single page when all rows fit", () => {
    expect(derivePageCount(4, 10)).toBe(1);
    expect(derivePageCount(10, 10)).toBe(1);
  });
  it("rounds up for a last partial page", () => {
    expect(derivePageCount(11, 10)).toBe(2);
    expect(derivePageCount(25, 10)).toBe(3);
  });
  it("collapses to one page when pageSize <= 0", () => {
    expect(derivePageCount(5, 0)).toBe(1);
    expect(derivePageCount(5, -1)).toBe(1);
  });
});

describe("clampPageIndex", () => {
  it("clamps into [0, pageCount - 1]", () => {
    expect(clampPageIndex(5, 3)).toBe(2);
    expect(clampPageIndex(-2, 3)).toBe(0);
    expect(clampPageIndex(1, 3)).toBe(1);
  });
  it("returns 0 for empty data or non-finite input", () => {
    expect(clampPageIndex(3, 0)).toBe(0);
    expect(clampPageIndex(Number.NaN, 3)).toBe(0);
  });
});

describe("paginateRows", () => {
  it("slices the requested page", () => {
    expect(paginateRows(rows, 0, 2).map((r) => r.id)).toEqual(["a", "b"]);
    expect(paginateRows(rows, 1, 2).map((r) => r.id)).toEqual(["c", "d"]);
  });
  it("returns the partial last page", () => {
    expect(paginateRows(rows, 1, 3).map((r) => r.id)).toEqual(["d"]);
  });
  it("returns empty for a page past the end", () => {
    expect(paginateRows(rows, 5, 2)).toEqual([]);
  });
  it("returns all rows when pageSize <= 0", () => {
    expect(paginateRows(rows, 0, 0)).toHaveLength(4);
  });
});

/* -------------------------------- selection ------------------------------ */

describe("toggleSelectionId", () => {
  it("multi mode adds and removes", () => {
    expect(toggleSelectionId([], "a", "multi")).toEqual(["a"]);
    expect(toggleSelectionId(["a", "b"], "b", "multi")).toEqual(["a"]);
  });
  it("single mode keeps at most one id", () => {
    expect(toggleSelectionId(["a"], "b", "single")).toEqual(["b"]);
    expect(toggleSelectionId(["a"], "a", "single")).toEqual([]);
  });
  it("does not mutate the input", () => {
    const input = ["a"];
    toggleSelectionId(input, "b", "multi");
    expect(input).toEqual(["a"]);
  });
});

describe("areAllSelected", () => {
  it("true only when every id is selected and the set is non-empty", () => {
    expect(areAllSelected(["a", "b", "c"], ["a", "b", "c"])).toBe(true);
    expect(areAllSelected(["a", "b"], ["a", "b", "c"])).toBe(false);
    expect(areAllSelected([], [])).toBe(false);
  });
});

describe("toggleAllSelection", () => {
  const allIds = ["a", "b", "c"];
  it("selects all when not all selected, clears when all selected", () => {
    expect(toggleAllSelection([], allIds, "multi")).toEqual(allIds);
    expect(toggleAllSelection(["a"], allIds, "multi")).toEqual(allIds);
    expect(toggleAllSelection(["a", "b", "c"], allIds, "multi")).toEqual([]);
  });
  it("is a no-op in single mode", () => {
    expect(toggleAllSelection(["a"], allIds, "single")).toEqual(["a"]);
  });
});

/* ------------------------------ controllable ----------------------------- */

describe("resolveControlled", () => {
  it("prefers the controlled value when defined, else the internal value", () => {
    expect(resolveControlled(5, 1)).toBe(5);
    expect(resolveControlled(undefined, 1)).toBe(1);
    expect(resolveControlled(0, 9)).toBe(0); // 0 is defined
  });
});

/* ---------------------- integration-style behavior ----------------------- */

describe("end-to-end derivation (sort -> paginate)", () => {
  it("derives visible rows for a page from a sorted set", () => {
    const sorted = sortRows(rows, columns, { columnId: "name", direction: "asc" });
    const visible = paginateRows(sorted, 1, 2);
    // sorted names: Alice, Bob, Charlie, Dana -> page 1 (0-based) = Charlie, Dana
    expect(visible.map((r) => r.name)).toEqual(["Charlie", "Dana"]);
  });

  it("walks a 3-toggle sort cycle producing asc, desc, then original", () => {
    let s = null as ReturnType<typeof nextSortState>;
    s = nextSortState(s, "age");
    expect(sortRows(rows, columns, s).map((r) => r.age)).toEqual([20, 25, 30, 30]);
    s = nextSortState(s, "age");
    expect(sortRows(rows, columns, s).map((r) => r.age)).toEqual([30, 30, 25, 20]);
    s = nextSortState(s, "age");
    expect(sortRows(rows, columns, s).map((r) => r.id)).toEqual(["a", "b", "c", "d"]);
  });
});
