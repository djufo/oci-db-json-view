/**
 * DataTable engine — pure logic core.
 *
 * Every derivation and state transition used by `useDataTable` lives here as a
 * pure, side-effect-free, React-free function so the behavior can be unit
 * tested directly (see `core.test.ts`). The hook is a thin binding over these.
 */

import type {
  ColumnDef,
  SelectionMode,
  SortDirection,
  SortState,
} from "./types";

/* --------------------------------- sort ---------------------------------- */

/**
 * 3-way sort cycle for a column: unsorted/other-column -> asc -> desc ->
 * unsorted. Returns the next SortState for a toggle of `columnId`.
 */
export function nextSortState(current: SortState, columnId: string): SortState {
  if (!current || current.columnId !== columnId) {
    return { columnId, direction: "asc" };
  }
  if (current.direction === "asc") {
    return { columnId, direction: "desc" };
  }
  return null;
}

/** Direction applied to a column, or `null` when it is not the active sort. */
export function columnSortDirection(
  sort: SortState,
  columnId: string,
): SortDirection | null {
  return sort && sort.columnId === columnId ? sort.direction : null;
}

/**
 * Total ordering for arbitrary accessor values. Nullish values sort last;
 * numbers/booleans/dates compare numerically, everything else by locale string.
 */
export function defaultCompare(a: unknown, b: unknown): number {
  if (a === b) return 0;

  const aNil = a === null || a === undefined;
  const bNil = b === null || b === undefined;
  if (aNil && bNil) return 0;
  if (aNil) return 1;
  if (bNil) return -1;

  if (typeof a === "number" && typeof b === "number") {
    const aNaN = Number.isNaN(a);
    const bNaN = Number.isNaN(b);
    if (aNaN && bNaN) return 0;
    if (aNaN) return 1;
    if (bNaN) return -1;
    return a - b;
  }
  if (typeof a === "boolean" && typeof b === "boolean") {
    return (a ? 1 : 0) - (b ? 1 : 0);
  }
  if (a instanceof Date && b instanceof Date) {
    return a.getTime() - b.getTime();
  }
  return String(a).localeCompare(String(b));
}

/**
 * Stable sort of `rows` for the active sort. Returns a new array; the input is
 * never mutated. Rows that compare equal keep their original relative order
 * (index tiebreak) so derivation is deterministic across JS engines. Returns
 * the original order when there is no active sort, or when the sorted column is
 * missing or explicitly non-sortable.
 */
export function sortRows<T>(
  rows: readonly T[],
  columns: readonly ColumnDef<T>[],
  sort: SortState,
): T[] {
  if (!sort) return rows.slice();

  const column = columns.find((c) => c.id === sort.columnId);
  if (!column || column.sortable === false) return rows.slice();

  const compare =
    column.compare ??
    ((a: T, b: T) => defaultCompare(column.accessor(a), column.accessor(b)));
  const direction = sort.direction === "desc" ? -1 : 1;

  return rows
    .map((row, index) => ({ row, index }))
    .sort((a, b) => {
      const cmp = compare(a.row, b.row) * direction;
      return cmp !== 0 ? cmp : a.index - b.index;
    })
    .map((entry) => entry.row);
}

/* ------------------------------- pagination ------------------------------ */

/** Number of pages for a row count / page size. Empty data yields 0 pages. */
export function derivePageCount(rowCount: number, pageSize: number): number {
  if (rowCount <= 0) return 0;
  if (pageSize <= 0) return 1;
  return Math.ceil(rowCount / pageSize);
}

/** Clamp a requested page index into the valid range `[0, pageCount - 1]`. */
export function clampPageIndex(pageIndex: number, pageCount: number): number {
  if (!Number.isFinite(pageIndex)) return 0;
  const max = Math.max(0, pageCount - 1);
  if (pageIndex < 0) return 0;
  if (pageIndex > max) return max;
  return Math.floor(pageIndex);
}

/** Slice `rows` to a single page. `pageSize <= 0` returns all rows. */
export function paginateRows<T>(
  rows: readonly T[],
  pageIndex: number,
  pageSize: number,
): T[] {
  if (pageSize <= 0) return rows.slice();
  const start = pageIndex * pageSize;
  return rows.slice(start, start + pageSize);
}

/* -------------------------------- selection ------------------------------ */

/**
 * Toggle a row id within a selection set. In `single` mode the result holds at
 * most one id. Returns a new array; the input is never mutated.
 */
export function toggleSelectionId(
  selected: readonly string[],
  rowId: string,
  mode: SelectionMode,
): string[] {
  const isSelected = selected.includes(rowId);
  if (mode === "single") {
    return isSelected ? [] : [rowId];
  }
  return isSelected
    ? selected.filter((id) => id !== rowId)
    : [...selected, rowId];
}

/** True when `allIds` is non-empty and every id is present in `selected`. */
export function areAllSelected(
  selected: readonly string[],
  allIds: readonly string[],
): boolean {
  if (allIds.length === 0) return false;
  const set = new Set(selected);
  return allIds.every((id) => set.has(id));
}

/**
 * Toggle every id: clears when all are already selected, otherwise selects all.
 * Multi-selection only — `single` mode returns the input unchanged.
 */
export function toggleAllSelection(
  selected: readonly string[],
  allIds: readonly string[],
  mode: SelectionMode,
): string[] {
  if (mode === "single") return selected.slice();
  return areAllSelected(selected, allIds) ? [] : allIds.slice();
}

/* ------------------------------ controllable ----------------------------- */

/**
 * Resolve the effective value of a possibly-controlled prop: the controlled
 * value wins when defined, otherwise the internal (uncontrolled) value is used.
 */
export function resolveControlled<V>(controlled: V | undefined, internal: V): V {
  return controlled !== undefined ? controlled : internal;
}
