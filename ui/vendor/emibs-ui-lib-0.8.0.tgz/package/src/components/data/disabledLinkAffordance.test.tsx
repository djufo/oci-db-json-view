// @vitest-environment happy-dom
import { renderToStaticMarkup } from "react-dom/server";
import axe from "axe-core";
import { afterEach, describe, expect, it } from "vitest";

import { AdminHomePanel } from "./AdminHomePanel";
import { EntityCardGridPanel } from "./EntityCardGridPanel";
import { MediaAssetPanel } from "./MediaAssetPanel";
import { WorkItemCard } from "./WorkItemCard";

/**
 * The four panels that render their activation affordance as an `<a>` when the
 * caller supplies `href`, and as a `<button>` when the caller supplies a
 * handler. The anchor branch used to ignore `disabled` altogether, so a disabled
 * card stayed fully navigable by keyboard and pointer while being dimmed.
 *
 * The contract asserted here is the one documented in `src/lib/disabledLink.ts`:
 * a disabled link keeps its `<a>` element and `role="link"`, gains
 * `aria-disabled="true"`, and LOSES its `href` — which is what actually takes it
 * out of the tab order and removes its activation behaviour.
 */

const HREF = "/records/disabled-target";

function mount(markup: string) {
  const container = document.createElement("div");
  container.innerHTML = markup;
  document.body.append(container);
  return container;
}

afterEach(() => {
  document.body.replaceChildren();
});

/** Everything a user can reach with Tab, per the focusable-element rules. */
function focusableNodes(container: HTMLElement) {
  return [
    ...container.querySelectorAll<HTMLElement>(
      'a[href], area[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])',
    ),
  ];
}

const cases: { name: string; className: string; render: (disabled: boolean) => string }[] = [
  {
    name: "WorkItemCard title control",
    className: "ui-work-item-card__title-control",
    render: (disabled) =>
      renderToStaticMarkup(
        <WorkItemCard disabled={disabled} href={HREF} itemId="ISSUE-1" title="Ship the gate" />,
      ),
  },
  {
    name: "AdminHomePanel action item",
    className: "ui-admin-home__action-title",
    render: (disabled) =>
      renderToStaticMarkup(
        <AdminHomePanel
          actionItems={[{ id: "users", title: "Users", href: HREF, disabled }]}
          title="Admin"
        />,
      ),
  },
  {
    name: "EntityCardGridPanel item",
    className: "ui-entity-card-grid__card-main",
    render: (disabled) =>
      renderToStaticMarkup(
        <EntityCardGridPanel
          items={[{ id: "one", title: "Record one", href: HREF, disabled }]}
          title="Records"
        />,
      ),
  },
  {
    name: "MediaAssetPanel asset",
    className: "ui-media-asset__card-main",
    render: (disabled) =>
      renderToStaticMarkup(
        <MediaAssetPanel
          assets={[{ id: "one", title: "Poster.png", href: HREF, disabled }]}
          showDetail={false}
          title="Media"
        />,
      ),
  },
];

describe.each(cases)("$name — disabled link affordance", ({ className, render }) => {
  it("stays a navigable link while enabled", () => {
    const container = mount(render(false));
    const control = container.querySelector<HTMLElement>(`.${className}`)!;

    expect(control.tagName).toBe("A");
    expect(control.getAttribute("href")).toBe(HREF);
    expect(control.getAttribute("aria-disabled")).toBeNull();
    expect(focusableNodes(container)).toContain(control);
  });

  it("drops href so a disabled link cannot be activated by pointer or keyboard", () => {
    const container = mount(render(true));
    const control = container.querySelector<HTMLElement>(`.${className}`)!;

    // Pointer: no href means the anchor has no navigation behaviour to fire.
    expect(control.hasAttribute("href")).toBe(false);
    expect(container.querySelector(`a[href="${HREF}"]`)).toBeNull();

    // Keyboard: an hrefless anchor with no tabindex is outside the tab order,
    // so it can never receive the Enter key that would activate it.
    //
    // The tab-order query is the assertion, NOT `control.focus()`: happy-dom's
    // `focus()` moves `document.activeElement` onto any element it is called on,
    // focusable or not, so an activeElement check here would pass against markup
    // that is genuinely reachable. Verified against real Chromium instead —
    // `.focus()` leaves activeElement on `<body>`, Tab skips straight past the
    // control, and even a forced click does not navigate.
    expect(focusableNodes(container)).toEqual([]);
    expect(control.hasAttribute("tabindex")).toBe(false);
  });

  it("announces the disabled link rather than silently degrading to generic markup", () => {
    const container = mount(render(true));
    const control = container.querySelector<HTMLElement>(`.${className}`)!;

    expect(control.getAttribute("aria-disabled")).toBe("true");
    expect(control.getAttribute("role")).toBe("link");
  });

  it("raises no axe violation in the disabled state", async () => {
    const container = mount(render(true));

    const results = await axe.run(container, {
      runOnly: {
        type: "rule",
        values: [
          "aria-allowed-attr",
          "aria-allowed-role",
          "aria-required-attr",
          "aria-valid-attr-value",
          "link-name",
          "nested-interactive",
        ],
      },
    });

    expect(results.violations.map((violation) => violation.id)).toEqual([]);
  });
});

describe("AdminHomePanel and MediaAssetPanel list markup (uif/issue-4685)", () => {
  it("AdminHomePanel exposes action items as list/listitem with no aria-allowed-role violation", async () => {
    const container = mount(
      renderToStaticMarkup(
        <AdminHomePanel
          actionItems={[
            { id: "users", title: "Users", href: "/users" },
            { id: "billing", title: "Billing", href: "/billing" },
          ]}
          title="Admin"
        />,
      ),
    );

    const list = container.querySelector('[role="list"].ui-admin-home__action-grid')!;
    const items = list.querySelectorAll(':scope > [role="listitem"]');

    expect(items).toHaveLength(2);
    expect(items[0].tagName).toBe("DIV");
    expect(items[0].textContent).toContain("Users");
    expect(items[1].textContent).toContain("Billing");

    const results = await axe.run(container, { runOnly: { type: "rule", values: ["aria-allowed-role"] } });
    expect(results.violations.map((violation) => violation.id)).toEqual([]);
  });

  it("MediaAssetPanel exposes assets as list/listitem with no aria-allowed-role violation", async () => {
    const container = mount(
      renderToStaticMarkup(
        <MediaAssetPanel
          assets={[
            { id: "one", title: "Poster.png", href: "/assets/one" },
            { id: "two", title: "Brochure.pdf", href: "/assets/two" },
          ]}
          showDetail={false}
          title="Media"
        />,
      ),
    );

    const list = container.querySelector('[role="list"].ui-media-asset__grid')!;
    const items = list.querySelectorAll(':scope > [role="listitem"]');

    expect(items).toHaveLength(2);
    expect(items[0].tagName).toBe("DIV");
    expect(items[0].textContent).toContain("Poster.png");
    expect(items[1].textContent).toContain("Brochure.pdf");

    const results = await axe.run(container, { runOnly: { type: "rule", values: ["aria-allowed-role"] } });
    expect(results.violations.map((violation) => violation.id)).toEqual([]);
  });
});
