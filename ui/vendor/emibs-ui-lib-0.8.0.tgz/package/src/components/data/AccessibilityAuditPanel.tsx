import { type ReactNode } from "react";
import { CheckCircle2, ExternalLink, Info, ShieldCheck } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type AccessibilityAuditStatus = "idle" | "running" | "complete" | "unavailable";
export type AccessibilityAuditSeverity = "critical" | "serious" | "moderate" | "minor" | "unknown";

export type AccessibilityAuditNote = {
  id: string;
  body: ReactNode;
};

export type AccessibilityAuditNode = {
  target: string[];
  failureSummary?: ReactNode;
};

export type AccessibilityAuditViolation = {
  id: string;
  impact?: AccessibilityAuditSeverity | string | null;
  help: ReactNode;
  description?: ReactNode;
  helpUrl?: string;
  nodes?: AccessibilityAuditNode[];
};

export type AccessibilityAuditPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  status?: AccessibilityAuditStatus;
  statusLabel?: ReactNode;
  notes?: AccessibilityAuditNote[];
  violations?: AccessibilityAuditViolation[];
  passCount?: number;
  actions?: ReactNode;
  canvas?: ReactNode;
  canvasLabel?: ReactNode;
  emptyLabel?: ReactNode;
  density?: "compact" | "comfortable";
  className?: string;
};

export function AccessibilityAuditPanel({
  title,
  eyebrow,
  subtitle,
  status = "idle",
  statusLabel,
  notes = [],
  violations = [],
  passCount,
  actions,
  canvas,
  canvasLabel = "Preview under audit",
  emptyLabel = "No automated accessibility issues were found.",
  density = "comfortable",
  className,
}: AccessibilityAuditPanelProps) {
  const issueCount = status === "complete" ? violations.length : 0;
  const tone = statusTone(status, issueCount);
  const summary = statusSummary(status, issueCount, passCount);

  return (
    <section className={cn("ui-accessibility-audit", `ui-accessibility-audit--${density}`, className)}>
      <header className="ui-accessibility-audit__header">
        <div className="ui-accessibility-audit__title-row">
          <span className="ui-accessibility-audit__icon" aria-hidden="true">
            <ShieldCheck size={19} />
          </span>
          <div className="ui-accessibility-audit__title-block">
            {eyebrow ? <span className="ui-accessibility-audit__eyebrow">{eyebrow}</span> : null}
            <h2>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
        </div>
        <div className="ui-accessibility-audit__header-actions">
          <Badge tone={tone}>{statusLabel ?? defaultStatusLabel(status, issueCount)}</Badge>
          {actions}
        </div>
      </header>

      <div className="ui-accessibility-audit__body">
        <div className="ui-accessibility-audit__review">
          {notes.length > 0 ? (
            <ul className="ui-accessibility-audit__notes" aria-label="Accessibility notes">
              {notes.map((note) => (
                <li key={note.id}>
                  <Info size={15} aria-hidden="true" />
                  <span>{note.body}</span>
                </li>
              ))}
            </ul>
          ) : null}

          <p className={cn("ui-accessibility-audit__summary", `ui-accessibility-audit__summary--${tone}`)}>
            {summary}
          </p>

          {status === "complete" && violations.length > 0 ? (
            <ul className="ui-accessibility-audit__violations" aria-label="Accessibility violations">
              {violations.map((violation) => (
                <AccessibilityViolationItem key={violation.id} violation={violation} />
              ))}
            </ul>
          ) : null}

          {status === "complete" && violations.length === 0 ? (
            <div className="ui-accessibility-audit__empty">
              <CheckCircle2 size={17} aria-hidden="true" />
              <span>{emptyLabel}</span>
            </div>
          ) : null}
        </div>

        {canvas ? (
          <aside className="ui-accessibility-audit__canvas" aria-label={plainLabel(canvasLabel) ?? "Audit preview"}>
            <div className="ui-accessibility-audit__canvas-label">{canvasLabel}</div>
            <div className="ui-accessibility-audit__canvas-body">{canvas}</div>
          </aside>
        ) : null}
      </div>
    </section>
  );
}

function AccessibilityViolationItem({ violation }: { violation: AccessibilityAuditViolation }) {
  const impact = normalizeSeverity(violation.impact);
  const nodes = violation.nodes ?? [];

  return (
    <li className={cn("ui-accessibility-audit__violation", `ui-accessibility-audit__violation--${impact}`)}>
      <div className="ui-accessibility-audit__violation-head">
        <span className={cn("ui-accessibility-audit__severity", `ui-accessibility-audit__severity--${impact}`)}>
          {impact}
        </span>
        <strong>{violation.help}</strong>
        {violation.helpUrl ? (
          <a href={violation.helpUrl} target="_blank" rel="noreferrer">
            docs
            <ExternalLink size={13} aria-hidden="true" />
          </a>
        ) : null}
      </div>
      {violation.description ? <p>{violation.description}</p> : null}
      <code className="ui-accessibility-audit__rule">Rule: {violation.id}</code>
      {nodes.length > 0 ? (
        <div className="ui-accessibility-audit__nodes">
          {nodes.map((node, index) => (
            <div key={`${violation.id}-${index}`}>
              <code>{node.target.join(" ")}</code>
              {node.failureSummary ? <small>{node.failureSummary}</small> : null}
            </div>
          ))}
        </div>
      ) : null}
    </li>
  );
}

function statusTone(status: AccessibilityAuditStatus, issueCount: number): BadgeTone {
  if (status === "complete") return issueCount > 0 ? "danger" : "success";
  if (status === "running") return "info";
  if (status === "unavailable") return "warning";
  return "neutral";
}

function defaultStatusLabel(status: AccessibilityAuditStatus, issueCount: number): ReactNode {
  if (status === "complete") return issueCount > 0 ? `${issueCount} issues` : "A11y pass";
  if (status === "running") return "Running";
  if (status === "unavailable") return "Unavailable";
  return "Not run";
}

function statusSummary(status: AccessibilityAuditStatus, issueCount: number, passCount?: number): ReactNode {
  if (status === "running") return "Running automated accessibility checks for this preview.";
  if (status === "unavailable") return "Automated audit results are unavailable for this preview.";
  if (status === "idle") return "Audit results have not been supplied yet.";
  if (issueCount === 0) {
    return passCount === undefined ? "No violations reported." : `No violations reported. ${passCount} checks passed.`;
  }
  return passCount === undefined
    ? `${issueCount} violation${issueCount === 1 ? "" : "s"} reported.`
    : `${issueCount} violation${issueCount === 1 ? "" : "s"} reported. ${passCount} checks passed.`;
}

function normalizeSeverity(value: AccessibilityAuditViolation["impact"]): AccessibilityAuditSeverity {
  return value === "critical" || value === "serious" || value === "moderate" || value === "minor" ? value : "unknown";
}

function plainLabel(value: ReactNode): string | undefined {
  return typeof value === "string" || typeof value === "number" ? String(value) : undefined;
}
