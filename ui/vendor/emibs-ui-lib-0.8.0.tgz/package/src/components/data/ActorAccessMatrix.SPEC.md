# ActorAccessMatrix Spec

## Goal

Provide a presentational access-management matrix for actor, user, role, and
project-grant administration screens before product apps adopt it.

## Source Pressure

- Score admin screens use repeated actor identity rows, interface labels, enabled
  badges, role selectors, direct project-release grants, saving states, and
  empty/loading rows.
- eLitua admin user/profile surfaces expose account role, active state, and
  management entry points that can later reuse the same matrix shape.

## Contract

- `ActorAccessMatrix` renders a panel header, optional context/status/action
  chrome, alert state, and a horizontally scrollable actor access table.
- It stays bespoke instead of using `DataTable` because each row contains a
  pivoted grant-control set, not a uniform scalar row model.
- Rows accept actor identity text, interface/status metadata, optional role
  options, optional grant checkboxes, and row actions.
- Consuming apps own selected project state, API calls, authorization,
  confirmation prompts, persistence, route handling, and toast behavior.

## Non-Goals

- No RBAC policy engine, role hierarchy, permission validation, actor fetching,
  optimistic persistence, or audit-event behavior.
- No Score-specific project access rules or eLitua-specific account semantics.

## Review Expectations

- Loading, empty, error, saving, disabled, and mixed-grant states must be visible
  in catalog demos.
- Long actor identifiers and email addresses must wrap or truncate without
  breaking the table.
