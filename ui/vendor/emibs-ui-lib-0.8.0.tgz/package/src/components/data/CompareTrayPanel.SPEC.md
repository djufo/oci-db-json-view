# CompareTrayPanel

## Purpose

`CompareTrayPanel` captures Score Catalog Explorer's pinned compare tray chrome:
a titled comparison surface, current-item pin action, pinned item cards,
removable previews, badge/meta rows, and empty state.

The component is presentational. It does not own query parameters, registry
loading, pinned-id persistence, preview generation, analytics, or adoption
workflow.

## Source Evidence

- Score `ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  renders local `CompareTray` markup for URL-backed pinned component previews.
- eLitua larger layout, portal, explorer, account, map, table, and profile
  structures were checked first and are already represented by earlier
  `emibs-ui-lib` extractions.
- Existing `PreviewMatrixPanel` covers component x variant x theme matrix rows,
  but its extraction explicitly leaves pinned URL comparisons product-owned.
  `CompareTrayPanel` covers the smaller pinned-card review surface.

## Contract

- Consumers pass pinned `items` with title, optional link/meta/description,
  optional badges/actions, a caller-rendered preview slot, and an optional
  remove callback.
- Consumers pass an optional controlled `currentAction` for pinning or unpinning
  the current item.
- `previewInert` can be set per item when review thumbnails should not receive
  pointer interaction.
- Styling uses `ui-compare-tray*` classes and shared token variables only.

## Product-Owned Behavior

Score keeps catalog route parsing, compare-id URL persistence, selected-current
logic, registry fixtures, search/filter context, preview rendering semantics,
analytics, permissions, and adoption workflow.

Other consumers keep their own item identity, route adapters, persistence,
localization, and preview contents.

## Review Expectations

- Empty, compact, comfortable, active current-action, multiple pinned cards,
  linked title, badges, remove buttons, and inert previews are visible in the
  catalog.
- Long item names and descriptions wrap without resizing controls or hiding
  remove buttons.
- Keyboard users can focus linked titles, the current action, and remove
  buttons in a predictable order.
