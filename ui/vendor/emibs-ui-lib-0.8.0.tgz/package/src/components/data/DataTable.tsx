import { ArrowDown, ArrowUp, ChevronLeft, ChevronRight, ChevronsUpDown } from "lucide-react";
import { type ReactNode } from "react";
import { cn } from "../../lib/cn";
import { DataStatePanel, type DataStatePanelProps } from "../feedback/DataStatePanel";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { Button } from "../primitives/Button";
import { TablePrimitive, type TablePrimitiveColumn } from "../primitives/TablePrimitive";
import { Toolbar } from "../primitives/Toolbar";
import { useDataTable } from "./engine/useDataTable";
import type { ColumnDef, PaginationState, SelectionMode, SortDirection, SortState } from "./engine/types";

export type DataTableColumn<T> = ColumnDef<T> & {
  cell?: (row: T) => ReactNode;
  headerContent?: ReactNode;
  rowHeader?: boolean;
};

export type { SortDirection } from "./engine/types";

export type DataTableSelectedRowsContext<T> = {
  selectedIds: readonly string[];
  selectedRows: readonly T[];
  clearSelection: () => void;
};

export type DataTableProps<T> = {
  data: readonly T[];
  columns: readonly DataTableColumn<T>[];
  getRowId?: (row: T) => string;
  sort?: SortState;
  defaultSort?: SortState;
  onSortChange?: (next: SortState) => void;
  pagination?: PaginationState;
  defaultPagination?: Partial<PaginationState>;
  pageSize?: number;
  onPaginationChange?: (next: PaginationState) => void;
  selectionMode?: SelectionMode;
  selection?: readonly string[];
  defaultSelection?: readonly string[];
  onSelectionChange?: (next: string[]) => void;
  caption?: ReactNode;
  showCaption?: boolean;
  ariaLabel?: string;
  stickyHeader?: boolean;
  density?: "comfortable" | "compact";
  striped?: boolean;
  showPagination?: boolean;
  /** Caller-owned search control rendered in the table toolbar. */
  searchSlot?: ReactNode;
  /** Caller-owned filter controls rendered in the table toolbar. */
  filterSlot?: ReactNode;
  /** Caller-owned export action. DataTable does not serialize or download data. */
  exportAction?: ReactNode;
  /** Caller-owned bulk actions, rendered only while rows are selected. */
  selectedRowActions?: ReactNode | ((context: DataTableSelectedRowsContext<T>) => ReactNode);
  toolbarLabel?: string;
  onRowActivate?: (row: T) => void;
  className?: string;
  loading?: boolean;
  error?: ReactNode;
  loadingState?: Partial<DataStatePanelProps>;
  emptyState?: Partial<DataStatePanelProps>;
  errorState?: Partial<DataStatePanelProps>;
  sortLabel?: (columnHeader: string, current: SortDirection | null, next: "ascending" | "descending" | "clear") => string;
  paginationLabel?: string;
  previousPageLabel?: string;
  nextPageLabel?: string;
};

export function DataTable<T>(props: DataTableProps<T>): ReactNode {
  const {
    data, columns, getRowId, sort, defaultSort, onSortChange, pagination,
    defaultPagination, pageSize, onPaginationChange, selectionMode, selection,
    defaultSelection, onSelectionChange, caption, showCaption, ariaLabel,
    stickyHeader = true, density = "comfortable", striped = false,
    showPagination = false, searchSlot, filterSlot, exportAction, selectedRowActions,
    toolbarLabel = "Table actions", onRowActivate,
    className, loading = false, error, loadingState, emptyState, errorState,
    sortLabel = defaultSortLabel, paginationLabel = "Table pagination",
    previousPageLabel = "Previous page", nextPageLabel = "Next page",
  } = props;
  const sourceData = data;
  const rowId = getRowId ?? ((row: T) => String((row as { id?: string }).id ?? ""));
  const table = useDataTable({
    data: sourceData, columns, getRowId: rowId, sort, defaultSort, onSortChange, pagination,
    defaultPagination, pageSize, onPaginationChange, selectionMode, selection,
    defaultSelection, onSelectionChange,
  });
  const hasError = error !== null && error !== undefined && error !== false;
  const state = resolveDataTableState({ loading, hasError, rowCount: table.rowCount });
  const tableColumns: TablePrimitiveColumn<T>[] = columns.map((column) => {
    const direction = table.getColumnSortDirection(column.id);
    const sortable = column.sortable !== false;
    const next = nextSortIntent(direction);
    return {
      id: column.id,
      align: column.align === "left" ? "start" : column.align === "right" ? "end" : column.align,
      rowHeader: column.rowHeader,
      sortDirection: sortable ? dataTableAriaSort(direction) : undefined,
      header: sortable ? (
        <button
          aria-label={sortLabel(column.header, direction, next)}
          className={cn("ui-data-table-composite__sort", direction && "is-active")}
          onClick={() => table.toggleSort(column.id)}
          type="button"
        >
          <span>{column.headerContent ?? column.header}</span>
          <SortIcon direction={direction} />
        </button>
      ) : column.headerContent ?? column.header,
      cell: (row) => column.cell?.(row) ?? renderCellValue(column.accessor(row)),
    };
  });

  const selectedRows = sourceData.filter((row) => table.selectedIds.includes(rowId(row)));
  const bulkActions = table.selectedIds.length > 0
    ? typeof selectedRowActions === "function"
      ? selectedRowActions({ selectedIds: table.selectedIds, selectedRows, clearSelection: table.clearSelection })
      : selectedRowActions
    : null;
  const hasToolbar = Boolean(searchSlot || filterSlot || exportAction || bulkActions);

  return (
    <div className={cn("ui-data-table-composite", `ui-data-table-composite--${density}`, className)}>
      {hasToolbar ? <Toolbar ariaLabel={toolbarLabel}>{searchSlot}{filterSlot}{bulkActions}{exportAction}</Toolbar> : null}
      {state === "ready" ? (
        <TablePrimitive
          caption={caption ?? "Data table"}
          columns={tableColumns}
          density={density}
          getRowId={rowId}
          onRowActivate={onRowActivate}
          rows={table.rows}
          selection={selectionMode ? {
            mode: selectionMode,
            onSelectionChange: table.setSelection,
            selectedRowIds: table.selectedIds,
          } : undefined}
          showCaption={showCaption}
          stickyHeader={stickyHeader}
          striped={striped}
        />
      ) : (
        <DataTableState
          error={error}
          emptyState={emptyState}
          errorState={errorState}
          loadingState={loadingState}
          state={state}
        />
      )}
      {showPagination && state === "ready" ? (
        <nav aria-label={paginationLabel} className="ui-data-table-composite__pagination">
          <span aria-live="polite">{dataTablePageSummary(table.pageIndex, table.pageSize, table.rowCount)}</span>
          <div className="ui-data-table-composite__page-controls">
            <Button aria-label={previousPageLabel} disabled={!table.canPrev} onClick={table.prevPage} size="sm" type="button" variant="secondary"><ChevronLeft aria-hidden="true" size={16} />Prev</Button>
            <strong aria-live="polite">{`${table.pageCount === 0 ? 0 : table.pageIndex + 1} / ${table.pageCount}`}</strong>
            <Button aria-label={nextPageLabel} disabled={!table.canNext} onClick={table.nextPage} size="sm" type="button" variant="secondary">Next<ChevronRight aria-hidden="true" size={16} /></Button>
          </div>
        </nav>
      ) : null}
    </div>
  );
}

function DataTableState({ state, error, loadingState, emptyState, errorState }: {
  state: "loading" | "error" | "empty"; error?: ReactNode; loadingState?: Partial<DataStatePanelProps>;
  emptyState?: Partial<DataStatePanelProps>; errorState?: Partial<DataStatePanelProps>;
}) {
  if (state === "loading") return <DataStatePanel density="compact" description="Fetching the latest records." title="Loading rows" tone="loading" {...loadingState} />;
  if (state === "error") return <DataStatePanel density="compact" description={typeof error === "boolean" ? undefined : error} title="Unable to load rows" tone="danger" {...errorState} />;
  return <DataStatePanel density="compact" description="There is nothing to show yet." title="No records" tone="empty" {...emptyState} />;
}

function SortIcon({ direction }: { direction: SortDirection | null }) {
  if (direction === "asc") return <ArrowUp aria-hidden="true" size={14} />;
  if (direction === "desc") return <ArrowDown aria-hidden="true" size={14} />;
  return <ChevronsUpDown aria-hidden="true" size={14} />;
}

function renderCellValue(value: unknown): ReactNode { return value === null || value === undefined ? "" : String(value); }
function nextSortIntent(direction: SortDirection | null): "ascending" | "descending" | "clear" { return direction === "asc" ? "descending" : direction === "desc" ? "clear" : "ascending"; }
function defaultSortLabel(header: string, current: SortDirection | null, next: "ascending" | "descending" | "clear") { return `Sort ${header}: ${current === "asc" ? "ascending" : current === "desc" ? "descending" : "not sorted"} — ${next === "clear" ? "Clear sort" : `Sort ${next}`}`; }
export function dataTableAriaSort(direction: SortDirection | null): "ascending" | "descending" | "none" { return direction === "asc" ? "ascending" : direction === "desc" ? "descending" : "none"; }
export function dataTablePageSummary(pageIndex: number, pageSize: number, rowCount: number, emptyLabel = "No rows"): string { if (rowCount <= 0) return emptyLabel; const size = pageSize > 0 ? pageSize : rowCount; return `Showing ${pageIndex * size + 1}–${Math.min((pageIndex + 1) * size, rowCount)} of ${rowCount}`; }
export function resolveDataTableState(input: { loading?: boolean; hasError: boolean; rowCount: number }): "loading" | "error" | "empty" | "ready" { return input.hasError ? "error" : input.loading ? "loading" : input.rowCount <= 0 ? "empty" : "ready"; }
export function dataTableColumnCount(columnCount: number, selectionEnabled: boolean): number { return Math.max(1, columnCount + (selectionEnabled ? 1 : 0)); }
export function StatusPill({ label, tone }: { label: string; tone: BadgeTone }) { return <Badge tone={tone}>{label}</Badge>; }
