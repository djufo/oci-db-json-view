# ProjectProfilePanel

## Purpose

Reusable project detail surface for Score-style project profiles. The component
presents project identity, status badges, high-value metadata, description,
definition-of-done checklist rows, state messages, actions, and an attachment
slot without owning route or API behavior.

## Contract

- `ProjectProfilePanel` is presentational and does not fetch, persist, delete,
  route, authorize, or subscribe to project data.
- Header identity, badges, actions, fields, description, checklist, attachment
  content, state messages, and custom children are all passed as props.
- Field links require concrete `href` values. Framework-specific route/link
  adapters stay in the consuming app.
- Attachment management is a slot. Consumers may compose `MediaAssetPanel` or
  project-specific upload chrome while keeping transport, confirmation, and
  persistence local.
- `loading`, `empty`, and `error` render project-profile state surfaces while
  keeping the same header chrome available for route context.

## Source

- `/engineering/projects/score/ui/src/features/projects/containers/ProjectsContainer.tsx`
