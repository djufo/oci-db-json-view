# RelationshipPickerPanel

## Purpose

`RelationshipPickerPanel` is a presentational selector for assigning related
records to a parent item, such as regions attached to a guide profile.

## Source Evidence

- eLitua `ui/src/admin/guides/components/GuideGeoEdit/GuideGeoEdit.tsx`
  renders a selected guide heading, region count, loading state, checklist of
  geographic records, and save/cancel footer while entity loading and mutation
  stay local.
- eLitua `ui/src/admin/guides/components/GuideGeoEdit/GuideGeoEdit.module.scss`
  provides compact panel spacing for the association editor.
- Existing larger eLitua shells, detail panels, editable form panels, filters,
  and data tables are already represented in this catalog; this extraction moves
  one level deeper into the reusable relationship-selection control.

## Contract

- Renders title/status chrome, selected and total counts, optional select-all
  and clear actions, loading/error/empty states, checkbox rows, metadata badges,
  optional record links, and footer/action slots.
- Consuming apps supply relationship data, selected state, toggle callbacks,
  save/cancel behavior, routing, fetch/mutation calls, authorization,
  localization, and toast delivery.
- Uses `ui-relationship-picker*` CSS classes and shared catalog tokens only.

## Non-Goals

- No data fetching, search indexing, relationship persistence, route generation,
  entity-type registry, RBAC policy, or localization.
- Does not replace `EditableFormPanel`; it is the focused association selector
  that can be placed inside a form panel or page-level editor.

## Review Checks

- Loading, empty, selected, disabled, and error states are visible or
  representable in the catalog.
- Long related-record labels, descriptions, badges, and footer actions wrap
  cleanly on narrow screens.
- Checkbox state is fully controlled by props; the shared component does not
  keep product relationship state.
