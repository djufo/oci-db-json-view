import { type FormEvent, type ReactNode } from "react";
import { Check, Plus, X } from "lucide-react";
import { cn } from "../../lib";
import { Button } from "../primitives/Button";

export type CommandConsoleSession = {
  id: string;
  title: ReactNode;
  meta?: ReactNode;
  active?: boolean;
};

export type CommandConsoleMessageRole = "user" | "assistant" | "system";

export type CommandConsoleMessage = {
  id: string;
  role: CommandConsoleMessageRole;
  body: ReactNode;
  meta?: ReactNode;
  href?: string;
  hrefLabel?: ReactNode;
  external?: boolean;
};

export type CommandConsoleProps = {
  title: ReactNode;
  sessions: CommandConsoleSession[];
  messages: CommandConsoleMessage[];
  draft: string;
  actions?: ReactNode;
  activeSessionId?: string;
  sessionLabel?: string;
  transcriptLabel?: string;
  emptyState?: ReactNode;
  submitting?: boolean;
  submittingLabel?: ReactNode;
  draftLabel?: string;
  draftPlaceholder?: string;
  sendLabel?: string;
  newSessionLabel?: string;
  closeSessionLabel?: string;
  className?: string;
  onDraftChange?: (draft: string) => void;
  onSubmit?: () => void;
  onSessionSelect?: (id: string) => void;
  onNewSession?: () => void;
  onCloseSession?: (id: string) => void;
};

export function CommandConsole({
  title,
  sessions,
  messages,
  draft,
  actions,
  activeSessionId,
  sessionLabel = "Command sessions",
  transcriptLabel = "Command transcript",
  emptyState = "Open a prompt. Work is queued outside this presentational console and outcome summaries return to the transcript.",
  submitting = false,
  submittingLabel = "Working...",
  draftLabel = "Command prompt",
  draftPlaceholder = "Type a command",
  sendLabel = "Send command",
  newSessionLabel = "New session",
  closeSessionLabel = "Close session",
  className,
  onDraftChange,
  onSubmit,
  onSessionSelect,
  onNewSession,
  onCloseSession,
}: CommandConsoleProps) {
  const activeSession = sessions.find((session) => session.id === activeSessionId) ?? sessions[0];
  const canSend = draft.trim() !== "" && !submitting;

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (canSend) {
      onSubmit?.();
    }
  }

  return (
    <section className={cn("ui-command-console", className)}>
      <aside className="ui-command-console__sessions" aria-label={sessionLabel}>
        <div className="ui-command-console__sessions-header">
          <h2>{title}</h2>
          {onNewSession ? (
            <Button type="button" size="sm" onClick={onNewSession}>
              <Plus size={15} aria-hidden="true" />
              {newSessionLabel}
            </Button>
          ) : null}
        </div>
        <div className="ui-command-console__session-list">
          {sessions.map((session) => {
            const active = session.active ?? session.id === activeSession?.id;
            return (
              <button
                className={cn("ui-command-console__session", active && "is-active")}
                key={session.id}
                type="button"
                aria-pressed={active}
                onClick={() => onSessionSelect?.(session.id)}
              >
                <span>{session.title}</span>
                {session.meta ? <small>{session.meta}</small> : null}
              </button>
            );
          })}
        </div>
      </aside>

      <div className="ui-command-console__terminal">
        <div className="ui-command-console__terminal-bar">
          <strong>{activeSession?.title ?? title}</strong>
          <div className="ui-command-console__terminal-actions">
            {actions}
            {activeSession && onCloseSession ? (
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label={closeSessionLabel}
                onClick={() => onCloseSession(activeSession.id)}
              >
                <X size={16} aria-hidden="true" />
              </Button>
            ) : null}
          </div>
        </div>

        <div className="ui-command-console__transcript" aria-label={transcriptLabel} aria-live="polite">
          {messages.length === 0 ? <p className="ui-command-console__empty">{emptyState}</p> : null}
          {messages.map((message) => (
            <article className={cn("ui-command-console__message", `ui-command-console__message--${message.role}`)} key={message.id}>
              <div className="ui-command-console__prompt" aria-hidden="true">
                {promptForRole(message.role)}
              </div>
              <div className="ui-command-console__message-body">
                <pre>{message.body}</pre>
                {message.meta ? <small>{message.meta}</small> : null}
                {message.href ? (
                  <a href={message.href} target={message.external ? "_blank" : undefined} rel={message.external ? "noreferrer" : undefined}>
                    {message.hrefLabel ?? message.href}
                  </a>
                ) : null}
              </div>
            </article>
          ))}
          {submitting ? <p className="ui-command-console__working">{submittingLabel}</p> : null}
        </div>

        <form className="ui-command-console__input" onSubmit={submit}>
          <span className="ui-command-console__input-prompt" aria-hidden="true">
            $
          </span>
          <textarea
            aria-label={draftLabel}
            onChange={(event) => onDraftChange?.(event.target.value)}
            placeholder={draftPlaceholder}
            value={draft}
          />
          <Button
            className={cn("ui-command-console__send", canSend && "is-active")}
            disabled={!canSend}
            title={canSend ? sendLabel : draftPlaceholder}
            aria-label={sendLabel}
            type="submit"
            variant="secondary"
            size="icon"
          >
            <Check size={18} strokeWidth={3} aria-hidden="true" />
          </Button>
        </form>
      </div>
    </section>
  );
}

function promptForRole(role: CommandConsoleMessageRole): string {
  if (role === "assistant") {
    return ">";
  }
  if (role === "system") {
    return "#";
  }
  return "$";
}
