# ComponentCatalogPanel

## Purpose

`ComponentCatalogPanel` is a presentational catalog-browsing shell for
component registries and review surfaces. It standardizes the page header,
searchable component navigation rail, sidebar slots, and main review content
without owning registry loading, URL synchronization, preview rendering, theme
state, or adoption workflow.

## Source Evidence

- Score `ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
  repeats a catalog page header with metric badges and actions, a searchable
  component list, discovery/facet sidebar panels, and a main review stack.
- Existing coverage was checked first: `ComponentReviewPanel` owns single
  component inspection, `DiscoveryCloudPanel` owns pattern/keyword clouds,
  `FacetFilterPanel` owns counted filters, and `PreviewMatrixPanel` owns
  comparison matrices. No exported component owns the top-level catalog browser
  shell that composes those regions.

## Contract

- Accepts controlled `search`, `items`, `sidebar`, `actions`, badges, and main
  content slots.
- Renders a responsive header, left navigation rail, optional sidebar content,
  and main content region.
- Supports link or button navigation items, active and disabled states, item
  metadata, per-item badges, and empty item state.
- Uses only `ui-component-catalog*` CSS classes and shared catalog tokens.

## Non-Goals

- No registry fetches, static metadata mining, saved filters, URL construction,
  hash routes, theme generation, preview execution, component adoption workflow,
  or clipboard/toast behavior.

## Review States

- Search, empty list, active item, compact density, long labels, and wrapped
  header actions must remain usable in catalog desktop and mobile widths.
