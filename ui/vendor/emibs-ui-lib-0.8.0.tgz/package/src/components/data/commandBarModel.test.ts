import { describe, expect, it, vi } from "vitest";
import type { CommandPaletteGroup } from "../primitives/CommandPalette";
import {
  buildCommandGroups,
  issueEntityMatcher,
  parseCommandQuery,
  type CommandVerb,
} from "./commandBarModel";

const VERBS: CommandVerb[] = [
  { id: "park", label: "Park", description: "Park a task" },
  { id: "hold", label: "Hold", description: "Hold a task" },
];

const NAV: CommandPaletteGroup = { id: "nav", title: "Go to", items: [{ id: "board", label: "Board" }] };

const parseOpts = { verbs: VERBS, matchEntity: issueEntityMatcher };

describe("issueEntityMatcher", () => {
  it("canonicalises a bare number to issue-<n>", () => {
    expect(issueEntityMatcher("2098")).toBe("issue-2098");
  });
  it("lowercases an issue id", () => {
    expect(issueEntityMatcher("Issue-2098")).toBe("issue-2098");
  });
  it("returns null for non-entity text", () => {
    expect(issueEntityMatcher("deploy train")).toBeNull();
  });
});

describe("parseCommandQuery", () => {
  it("parses a known verb + target", () => {
    expect(parseCommandQuery("> park issue-2098", parseOpts)).toEqual({
      kind: "verb",
      verb: "park",
      arg: "issue-2098",
      known: true,
    });
  });
  it("flags an unknown verb", () => {
    expect(parseCommandQuery("> frobnicate 12", parseOpts)).toMatchObject({ kind: "verb", verb: "frobnicate", known: false });
  });
  it("parses an entity jump", () => {
    expect(parseCommandQuery("2098", parseOpts)).toEqual({ kind: "entity", id: "issue-2098" });
  });
  it("falls back to search", () => {
    expect(parseCommandQuery("runtime", parseOpts)).toEqual({ kind: "search", text: "runtime" });
  });
});

describe("buildCommandGroups", () => {
  const ctx = {
    navigate: vi.fn(),
    onVerb: vi.fn(),
    entityHref: (id: string) => `#/issue/${id}`,
    navigation: NAV,
    verbs: VERBS,
  };

  it("always keeps the navigation group", () => {
    const groups = buildCommandGroups("", ctx);
    expect(groups.at(-1)).toBe(NAV);
  });

  it("surfaces a jump item wired to entityHref", () => {
    const groups = buildCommandGroups("2098", ctx);
    const jump = groups.find((group) => group.id === "jump");
    expect(jump?.items[0].meta).toBe("#/issue/issue-2098");
    jump?.items[0].onSelect?.(jump.items[0]);
    expect(ctx.navigate).toHaveBeenCalledWith("#/issue/issue-2098");
  });

  it("disables a verb until a target is typed and fires onVerb once it is", () => {
    const noTarget = buildCommandGroups("> park", ctx);
    const parkItem = noTarget.find((group) => group.id === "verbs")?.items.find((item) => item.id === "verb-park");
    expect(parkItem?.disabled).toBe(true);

    const withTarget = buildCommandGroups("> park 2098", ctx);
    const ready = withTarget.find((group) => group.id === "verbs")?.items.find((item) => item.id === "verb-park");
    expect(ready?.disabled).toBe(false);
    ready?.onSelect?.(ready);
    expect(ctx.onVerb).toHaveBeenCalledWith("park", "issue-2098");
  });

  it("offers every verb when the verb is not yet known", () => {
    const groups = buildCommandGroups("> ", ctx);
    const verbs = groups.find((group) => group.id === "verbs");
    expect(verbs?.items).toHaveLength(VERBS.length);
  });
});
