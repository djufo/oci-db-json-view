import type { ReactNode } from "react";
import { cn } from "../../lib";
import { useDensity, type Density } from "../../theme/DensityScope";

/**
 * AuditTimeline (UIF-E3). The timeline atom behind every Audit / delivery-record
 * rail: a vertically-aligned run of typed entries, each with a tick dot coloured
 * by its state (via emibs-theme/2 `--severity-*` / status tokens), an actor shown
 * in mono, and a time column that stays left-aligned across rows so the sequence
 * reads as a spine.
 *
 * It is purely presentational and takes typed entries — the caller reconstructs
 * the entry list from server data (dispositions, leases, actions) and formats the
 * time; this atom owns the alignment, the dot semantics and the empty state, not
 * the data shape of any one product.
 */

export type AuditEntryTone = "neutral" | "info" | "success" | "warning" | "danger" | "critical" | "accent";

export type AuditEntry = {
  readonly id: string;
  /** Caller-formatted time / relative age; rendered in the aligned time column. */
  readonly time: ReactNode;
  /** Primary line for the entry. */
  readonly title: ReactNode;
  /** Actor that produced the entry; rendered in mono. */
  readonly actor?: ReactNode;
  /** Tick-dot state; defaults to `neutral`. */
  readonly tone?: AuditEntryTone;
  /** Short kind label (e.g. "disposition", "lease") shown as an eyebrow. */
  readonly kind?: ReactNode;
  /** Secondary detail line. */
  readonly detail?: ReactNode;
  /** Optional deep link for the entry title. */
  readonly href?: string;
  /** Extra trailing meta (e.g. carrier, revision). */
  readonly meta?: ReactNode;
};

export type AuditTimelineProps = {
  readonly entries: readonly AuditEntry[];
  readonly ariaLabel?: string;
  readonly emptyLabel?: ReactNode;
  readonly density?: Density;
  readonly className?: string;
};

export function AuditTimeline({
  entries,
  ariaLabel = "Audit timeline",
  emptyLabel = "No audit entries yet.",
  density,
  className,
}: AuditTimelineProps) {
  const resolvedDensity = useDensity(density);

  if (entries.length === 0) {
    return (
      <p className={cn("ui-audit-timeline__empty", className)} role="note">
        {emptyLabel}
      </p>
    );
  }

  return (
    <ol
      aria-label={ariaLabel}
      className={cn("ui-audit-timeline", `ui-audit-timeline--${resolvedDensity}`, className)}
    >
      {entries.map((entry) => {
        const title = entry.href ? (
          <a className="ui-audit-timeline__link" href={entry.href}>
            {entry.title}
          </a>
        ) : (
          entry.title
        );
        return (
          <li className="ui-audit-timeline__row" key={entry.id}>
            <time className="ui-audit-timeline__time">{entry.time}</time>
            <span className="ui-audit-timeline__tick" data-tone={entry.tone ?? "neutral"} aria-hidden="true">
              <i className="ui-audit-timeline__dot" />
            </span>
            <div className="ui-audit-timeline__body">
              {entry.kind ? <span className="ui-audit-timeline__kind">{entry.kind}</span> : null}
              <span className="ui-audit-timeline__title">{title}</span>
              {entry.detail ? <span className="ui-audit-timeline__detail">{entry.detail}</span> : null}
              <span className="ui-audit-timeline__foot">
                {entry.actor ? <span className="ui-audit-timeline__actor">{entry.actor}</span> : null}
                {entry.meta ? <span className="ui-audit-timeline__meta">{entry.meta}</span> : null}
              </span>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
