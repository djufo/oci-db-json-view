# WorkBoardToolbar

## Goal

Provide a presentational toolbar for Score-style work boards: page title,
operator status badges, responsive filter reveal, search, project/epic selectors,
active route filter chips, workflow actions, and transient error state.

## Source Pressure

- Score `ui/src/features/board/containers/BoardContainer.tsx` keeps the board
  title, actor/status badges, search query input, route-backed project and epic
  filters, active filter chips, mobile filter toggle, reset, refresh, new issue,
  and claim actions in one local `BoardToolbar`.
- Larger Score shells, board columns/cards, creation dialogs, task planning,
  trace, markdown, media, and activity views are already represented in the
  catalog, leaving the board toolbar as the next reusable Score operator pattern.

## Contract

- `WorkBoardToolbar` is controlled and presentational.
- Consumers provide formatted badges, option labels, search values, selected
  route filters, active filter chip labels, actions, error copy, and callbacks.
- The component owns layout, labels, responsive filter grouping, and accessible
  control relationships only.
- Active filters render as removable chips through caller-provided `onRemove`
  handlers. The optional clear action slot lets products keep reset semantics
  local while sharing the chip strip chrome.

## Non-Goals

- No task fetching, search parsing, project/epic validation, route updates, task
  creation, claiming, workflow permissions, toast delivery, or local storage.
- No active filter derivation or reset semantics; products decide which filters
  are active and how removing a chip changes URL state.
- No adoption into Score or eLitua in this extraction; adoption is tracked by a
  separate UI Framework refactor task.

## Review Expectations

- The toolbar remains readable with long titles, actor labels, and project names.
- Controls wrap on desktop and collapse behind the filter toggle on narrow
  screens.
- Active filter labels truncate instead of overflowing, and chip remove buttons
  remain keyboard reachable.
- The action slot supports refresh/create/claim buttons without changing layout.
