# SchedulerControlPanel

## Purpose

`SchedulerControlPanel` is a presentational operator surface for reviewed
scheduled jobs that need enablement controls, command visibility, runtime
metadata, tags, loading/empty/error states, and product-owned action slots.

## Source Evidence

- Score's `#/schedulers` page renders mapped host cron jobs as cards with a
  header, enabled/disabled toggle, schedule/runner/workflow metadata, command
  block, log/lock paths, and tags.
- Score owns the scheduler catalog and mutable enablement state; the visual
  pattern is reusable for other EMIBS operator tools that expose reviewed jobs or
  automation controls.

## Contract

- Accepts controlled `schedulers`, optional `busySchedulerId`,
  `onToggleScheduler`, status, actions, loading, empty, and error props.
- Scheduler rows supply preformatted labels, metadata values, command text,
  paths, tags, and optional actions. Command text renders through `PayloadBlock`,
  and the component does not format dates or interpret cron expressions.
- If `onToggleScheduler` is not supplied, enablement renders as a badge instead
  of an interactive button.
- Product apps own fetching, auth, persistence, scheduler catalog validation,
  command execution policy, date formatting, toasts, audit events, and routing.

## Non-Goals

- No scheduler API client, polling, cron parsing, host command launching, lock
  inspection, log viewing, confirmation dialog, localization, or permissions.
- No automatic refresh behavior. Refresh buttons belong in the `actions` slot.

## Review Expectations

- Long commands and file paths must scroll or wrap without expanding the page
  beyond the viewport.
- Toggle buttons must retain pressed state and disabled/busy affordance.
- Cards must stack cleanly at narrow widths while keeping metadata labels
  readable.
