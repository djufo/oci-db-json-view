import { useCallback, useEffect, useMemo, useState, type ReactNode } from "react";
import { cn } from "../../lib";
import {
  CommandPalette,
  type CommandPaletteGroup,
  type CommandPalettePlacement,
} from "../primitives/CommandPalette";
import { buildCommandGroups, issueEntityMatcher, type CommandVerb, type EntityMatcher } from "./commandBarModel";

/**
 * CommandBar (UIF-E3, generalized from Score v4 G6). The top command bar: an
 * optional brand slot, the ⌘K command field, and a status-strip slot. It reuses
 * the existing `CommandPalette` primitive and extends its groups via
 * `buildCommandGroups`, so ⌘K reaches every entity (jump) and every verb
 * (`> park issue-…`) in addition to navigation — no second palette. The ⌘K /
 * Ctrl+K shortcut lives here; the entity vocabulary and verb set are injected,
 * so the bar is not tied to any one product's ids.
 *
 * Open and query state are controllable but not required (uif/issue-4678). The
 * bar owns them by default — a caller that passes neither `open` nor `query`
 * behaves exactly as before — while a caller that supplies either becomes the
 * source of truth for it, which is what makes the three query modes (verb,
 * entity jump, navigation) reachable from a props-only catalog StatePreview.
 * The prop shape is the package's existing one (`Menu`'s `open` /`defaultOpen`
 * /`onOpenChange`, `FilePreviewDialog`'s `mode`/`defaultMode`/`onModeChange`):
 * `X` wins when defined, `defaultX` seeds the uncontrolled value, `onXChange`
 * fires on every change either way. Each half is independent — a caller may
 * control the query and leave open uncontrolled, or the reverse.
 */

export type CommandBarProps = {
  /** Baseline navigation group shown for every query. */
  readonly navigation: CommandPaletteGroup;
  /** Navigate the app to a hash/route. */
  readonly navigate: (hash: string) => void;
  /** Invoked when a verb action is chosen. */
  readonly onVerb: (verb: string, targetId: string) => void;
  /** Route builder for an entity jump. */
  readonly entityHref: (id: string) => string;
  /** Verbs available from `>`. Default: none (navigation + jump only). */
  readonly verbs?: readonly CommandVerb[];
  /** Entity id matcher; defaults to the `issue-<n>` matcher. */
  readonly matchEntity?: EntityMatcher;
  /** Controlled palette open state. Pair with `onOpenChange` for controlled usage. */
  readonly open?: boolean;
  /** Initial palette open state for uncontrolled usage. */
  readonly defaultOpen?: boolean;
  /** Called on every open change (controlled and uncontrolled). */
  readonly onOpenChange?: (open: boolean) => void;
  /** Controlled palette query. Pair with `onQueryChange` for controlled usage. */
  readonly query?: string;
  /** Initial palette query for uncontrolled usage. */
  readonly defaultQuery?: string;
  /** Called on every query change (controlled and uncontrolled). */
  readonly onQueryChange?: (query: string) => void;
  /** Brand mark shown at the far left. */
  readonly brand?: ReactNode;
  /** Live status-strip slot shown at the far right. */
  readonly statusStrip?: ReactNode;
  /** Trigger-field hint copy. */
  readonly hint?: ReactNode;
  readonly placeholder?: string;
  readonly ariaLabel?: string;
  /** Palette placement, forwarded to CommandPalette; `contained` keeps it in flow. */
  readonly placement?: CommandPalettePlacement;
  /** Whether the palette takes focus when it opens; forwarded to CommandPalette. */
  readonly autoFocus?: boolean;
  readonly className?: string;
};

function isTypingTarget(target: EventTarget | null): boolean {
  return (
    target instanceof HTMLElement &&
    target.closest("input, textarea, select, [contenteditable='true'], dialog, [role='dialog']") !== null
  );
}

export function CommandBar({
  navigation,
  navigate,
  onVerb,
  entityHref,
  verbs = [],
  matchEntity = issueEntityMatcher,
  open,
  defaultOpen = false,
  onOpenChange,
  query,
  defaultQuery = "",
  onQueryChange,
  brand,
  statusStrip,
  hint = "Jump, act, or search…",
  placeholder = "Jump to an entity, run a verb (> …), or search",
  ariaLabel = "Command bar",
  placement,
  autoFocus,
  className,
}: CommandBarProps) {
  const [internalOpen, setInternalOpen] = useState(defaultOpen);
  const [internalQuery, setInternalQuery] = useState(defaultQuery);
  const openControlled = open !== undefined;
  const queryControlled = query !== undefined;
  const isOpen = openControlled ? open : internalOpen;
  const currentQuery = queryControlled ? query : internalQuery;

  // Commit helpers, one per controllable value: the internal value only moves
  // while that value is uncontrolled, and the callback fires either way. A
  // controlled value passed without its callback therefore stays put until the
  // caller rerenders it — the same contract SectionCard.SPEC.md records for
  // `collapsed`, and what makes a catalog StatePreview a stable state rather
  // than an interactive demo.
  const requestOpenChange = useCallback(
    (next: boolean) => {
      if (!openControlled) setInternalOpen(next);
      onOpenChange?.(next);
    },
    [openControlled, onOpenChange],
  );

  const requestQueryChange = useCallback(
    (next: string) => {
      if (!queryControlled) setInternalQuery(next);
      onQueryChange?.(next);
    },
    [queryControlled, onQueryChange],
  );

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if (isOpen) {
        return;
      }
      if (!(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "k") {
        return;
      }
      if (isTypingTarget(event.target)) {
        return;
      }
      event.preventDefault();
      requestQueryChange("");
      requestOpenChange(true);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [isOpen, requestOpenChange, requestQueryChange]);

  const groups = useMemo(
    () =>
      buildCommandGroups(currentQuery, {
        navigate: (hash) => {
          navigate(hash);
          requestOpenChange(false);
        },
        onVerb: (verb, targetId) => {
          onVerb(verb, targetId);
          requestOpenChange(false);
        },
        entityHref,
        navigation,
        verbs,
        matchEntity,
      }),
    [currentQuery, navigate, onVerb, entityHref, navigation, verbs, matchEntity, requestOpenChange],
  );

  return (
    <div className={cn("ui-command-bar", className)}>
      {brand ? <span className="ui-command-bar__brand">{brand}</span> : null}
      <button
        aria-haspopup="dialog"
        aria-label="Open command bar (Cmd or Ctrl K)"
        className="ui-command-bar__field"
        onClick={() => {
          requestQueryChange("");
          requestOpenChange(true);
        }}
        type="button"
      >
        <span className="ui-command-bar__hint">{hint}</span>
        <kbd className="ui-command-bar__kbd">⌘K</kbd>
      </button>
      {statusStrip ? <div className="ui-command-bar__status">{statusStrip}</div> : null}
      <CommandPalette
        ariaLabel={ariaLabel}
        autoFocus={autoFocus}
        closeLabel="Close command bar"
        closeOnSelect
        groups={groups}
        onOpenChange={requestOpenChange}
        onQueryChange={requestQueryChange}
        open={isOpen}
        placeholder={placeholder}
        placement={placement}
        query={currentQuery}
        shortcutHint="⌘K"
      />
    </div>
  );
}
