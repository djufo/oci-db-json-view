# AdminRecordEditorPanel

## Purpose

`AdminRecordEditorPanel` is a presentational page shell for admin record edit
screens that need a back action, title/status chrome, notices, loading/missing
states, an injected form body, and a stable save/delete footer.

## Source Evidence

- eLitua `ui/src/pages/admin/users/UserEditPage.tsx`,
  `ui/src/pages/admin/profiles/ProfileEditPage.tsx`, and
  `ui/src/pages/admin/pictures/PictureEditPage.tsx` repeat the same admin edit
  page structure: back link, title, loading state, error/success notices, form
  body, save action, delete action, and optional upload control.
- Score `ui/src/features/projects/containers/ProjectPage.tsx` has comparable
  project create/edit page chrome with loading/not-found handling, close action,
  record metadata, save status, and form composition.

## Contract

- Renders the page-level editor shell, back control, status badge, metadata
  badges, notices, loading and empty states, body slot, and footer slot.
- Only the **body** varies by state. The footer is stable: it renders in the
  loading, empty, and loaded states alike, so the save/delete commands do not
  disappear and re-appear as a record resolves.
- Can wrap the body/footer in a form when `onSubmit` is supplied. The form wraps
  every state, not only the loaded one, because a `type="submit"` command in the
  footer is inert outside its form.
- `backHref` and `onBack` may be supplied together, and that is the router case
  rather than a caller error. The anchor keeps its real `href` — so it stays
  middle-clickable, copyable, and crawlable — and a plain left click is
  intercepted with `preventDefault` and handed to `onBack`. A modified click
  (new tab, new window, non-primary button) and an already-handled event are
  left to the browser.
- Consuming apps supply controlled inputs, upload controls, route links,
  confirmation dialogs, save/delete handlers, validation, and localized copy.
- Uses `ui-admin-record-editor*` CSS classes and shared catalog tokens only.

## Non-Goals

- No data fetching, router dependency, mutation, upload transport, delete
  confirmation, validation schema, toast handling, autosave policy, or entity
  field registry.
- Does not replace `EditableFormPanel`; it frames full-page admin edit routes
  that may contain product-specific form bodies or existing form panels.

## Review Checks

- Loading, success, and error states are visible in the catalog.
- Long titles, notice text, metadata badges, and footer actions wrap cleanly on
  narrow screens.
- The body slot supports simple form fields, checkboxes, read-only fields, and
  upload/dropzone-style controls without forcing product state into the library.
