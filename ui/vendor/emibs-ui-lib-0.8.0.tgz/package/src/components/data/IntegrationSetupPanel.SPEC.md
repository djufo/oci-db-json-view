# IntegrationSetupPanel Spec

## Purpose

Reusable setup surface for external integrations that need provider identity,
connection state, credential/configuration fields, sync toggles, operational
metrics, and a save/test action footer.

## Contract

- `IntegrationSetupPanel` is presentational and controlled by props.
- Consumers own secrets, validation, provider SDKs, persistence, test calls,
  disconnect flows, translations, analytics, and routing.
- Credential and configuration inputs are render slots through
  `IntegrationSetupField.control`; the shared component never reads or masks
  secret values itself.
- `IntegrationSetupField.id` is the field's stable identity: the React list key
  and, prefixed with a per-panel `useId()` scope, the DOM id of the field
  wrapper. The scope is what lets two panels render the same section
  descriptors without emitting duplicate ids.
- Toggle rows are controlled through `checked` and `onChange`.
- Status, messages, badges, metrics, sections, and footer actions accept
  preformatted React nodes so product teams keep domain wording and formatting.

## Required Demo Coverage

- Integration header with provider logo, title, subtitle, badges, and actions.
- Connection status bar with connected and disconnect action affordances.
- Credential fields with required/optional metadata and hint text.
- Sync setting toggles.
- Integration detail metrics for status, channel, last sync, and provider.
- Success message and save/test footer actions.

## Non-Goals

- No API calls, credential storage, provider SDK loading, or webhook behavior.
- No opinion on secret materialization, encryption, vault naming, or token
  refresh. Those remain in the consuming app.
