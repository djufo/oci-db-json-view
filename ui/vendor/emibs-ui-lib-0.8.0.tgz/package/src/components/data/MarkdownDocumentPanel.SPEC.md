# MarkdownDocumentPanel

## Purpose

`MarkdownDocumentPanel` is a presentational document-review surface for
work-item documents, notes, runbooks, and markdown attachments. It provides
header/action chrome, badges, metadata rows, loading/error/empty states, a
sanitized markdown body, and a small markdown download helper.

## Contract

- Accepts caller-supplied markdown content, metadata, badges, actions, state
  labels, and footer content.
- Renders GitHub-flavored markdown with line breaks through `marked` and
  sanitizes the produced HTML through `DOMPurify`.
- Allows products with their own parser to inject `renderMarkdown`, and an
  optional additional narrowing pass through `sanitizeHtml`.
- Exports `downloadMarkdown(filename, content)` for browser-side markdown file
  downloads.

## Markdown Trust Boundary

Markdown content may be untrusted; the panel's sanitization is not bypassable
through props.

- The pipeline is fixed as `renderMarkdown` → optional caller `sanitizeHtml` →
  **built-in `DOMPurify.sanitize`** → `dangerouslySetInnerHTML`. The built-in
  pass always runs last, on whatever the caller's functions produced.
- `renderMarkdown` changes how markdown becomes HTML. It cannot emit markup
  that skips sanitization: an inserted `<script>` or `onerror=` payload is
  stripped before it reaches the DOM.
- `sanitizeHtml` is an *extra* narrowing pass (e.g. drop all links, drop all
  images), not a replacement. It can only remove more. It cannot re-admit
  anything `DOMPurify` strips, and passing an identity function or an
  incomplete sanitizer does not weaken the output.
- What remains app-owned: whether the markdown source should be shown to this
  viewer at all (permissions, redaction of secrets in prose), and any policy
  beyond `DOMPurify`'s default profile — enforce that by narrowing in
  `sanitizeHtml`, never by expecting the panel to widen.
- Uses `ui-markdown-document*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/components/MarkdownViewer.tsx` renders task documents through
  `marked` and `DOMPurify`, then exposes a browser markdown download helper.
- Score `ui/src/features/board/components/TaskDetail.tsx` presents task
  document content inside the detail surface with a markdown download action.
- Score `ui/src/styles.css` defines the markdown body typography, code block,
  table, quote, and link rules used by the task document preview.

## Non-Goals

- No task fetching, attachment fetching, permission checks, route ownership,
  task status interpretation, generated document creation, upload handling, or
  product-specific filename rules.
- No opt-out from sanitization, and no seam that widens the sanitizer's default
  profile.
- No adoption into Score in this extraction; adoption is tracked by a
  low-priority UI Framework refactor task.
