# KanbanBoard

## Goal

Provide a presentational workflow lane shell for Score-style boards: horizontal
or wrapped lanes, controlled lane counts, optional lane descriptions and
actions, stable empty states, and caller-rendered task cards.

## Source Pressure

- Score `ui/src/features/board/components/BoardColumns.tsx` maps workflow
  statuses into columns, supports a `board` or `single` layout, renders a stable
  empty state, and delegates card behavior to the local `TaskCard`.
- Score `ui/src/design-system/Column.tsx` owns the lane header, count, and body
  shell used by the board.
- Score `ui/src/styles.css` keeps board lanes horizontally scrollable with a
  300px minimum lane width and switches to a single-column layout when needed.
- Existing emibs coverage included an early fixed `KanbanBoard` demo and the
  later `WorkItemCard`, but no shared component owned the reusable lane shell
  with layout modes and render slots.

## Contract

- `KanbanBoard` is controlled and presentational.
- Consumers provide columns, tasks, formatted counts, empty labels, optional
  lane descriptions, lane action/footer slots, and task rendering.
- The default task renderer supports the legacy demo shape: id, title, owner,
  priority, tone, and age.
- `renderTask` lets products render specialized cards such as `WorkItemCard`
  while sharing only the board/lane chrome.
- `layout` supports horizontal scrolling lanes, a single lane stack, or wrapped
  responsive columns. `columnMinWidth` controls the lane track minimum.
  `density` scales lane/card spacing (`"compact"` default, or `"comfortable"`).
- `ariaLabel` names the board landmark for assistive tech, defaulting to
  `"Task workflow board"`.
- `getTaskKey` overrides the React key used per task (the task's own `id` by
  default), for callers whose task ids are not unique across columns.
- `collapsible` turns each lane header into a disclosure. The collapsed state is
  derived from props on every render — `column.defaultCollapsed`, falling back
  to the board-level `defaultCollapsed` — with the reader's manual toggles
  layered on top. So a lane added later honours its own default, flipping
  `collapsible` on applies the defaults immediately, and a lane that leaves
  `columns` drops its override instead of leaking its id.
- Tie-break, deliberate: once a lane has been toggled by hand, that override
  wins over any later change to `defaultCollapsed`. A prop update must never
  yank a lane shut under the reader. The override lives only as long as the lane
  is in `columns`; a re-added id starts from its default again.

## Non-Goals

- No task fetching, status derivation, route synchronization, workflow command
  filtering, move dispatch, drag and drop, permissions, persistence, toasts, or
  analytics.
- No adoption into Score in this extraction; adoption is tracked by a separate
  UI Framework refactor task.

## Review Expectations

- Lanes keep a stable readable width and scroll horizontally before task cards
  collapse.
- Empty lanes render a visible non-interactive empty state.
- Long lane titles and task titles wrap without resizing the board tracks.
- Custom task cards receive the full task and column objects without the shared
  component knowing product DTO details.
