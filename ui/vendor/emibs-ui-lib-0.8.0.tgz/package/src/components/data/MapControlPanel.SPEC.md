# MapControlPanel

## Purpose

`MapControlPanel` is a presentational control group for map workspaces that need
visible zoom/reset/layer actions, compact map status stats, and sidebar or
viewport action placement without owning map engine state.

## Contract

- Accepts controlled action descriptors and delegates every command through
  `onSelect`.
- Supports compact or comfortable density and wrapping or stacked layouts.
- Renders optional title, eyebrow, subtitle, status badge, stat badges, and
  footer copy.
- Returns `null` when `visible=false` so consumers can keep map-specific
  visibility policy local.
- Uses `ui-map-control-panel*` CSS classes and shared token variables only.

## Source Evidence

- eLitua `ui/src/features/map/MapControls/MapControls.tsx` renders a map
  control block with a heading and zoom/reset buttons in entity workspaces.
- eLitua `ui/src/features/map/MapControls/MapControls.module.scss` defines the
  compact stacked sidebar surface.
- eLitua `ui/src/features/PageSidebar/PageSidebar.tsx` composes the control
  block with view switching, filters, and detail-card slots.

## Non-Goals

- No Google Maps, clustering, coordinates, map service dispatch, route state,
  translation lookup, or entity selection behavior.
- No assumption that map actions are limited to zoom in/out/reset; consumers
  supply the action registry and command handlers.
- No adoption into eLitua in this extraction; adoption is tracked by a separate
  low-priority UI Framework refactor task.
