# PreviewMatrixPanel

## Source

Extracted from Score Catalog Explorer's `AllPossibilitiesMatrix` and
`AllPossibilitiesPreview` in
`/engineering/projects/score/ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`.

## Purpose

`PreviewMatrixPanel` renders a controlled review matrix for product/catalog
fixtures across multiple comparison columns such as themes, viewport modes,
runtime states, or release targets. It is presentational: callers provide
precomputed rows, columns, coverage status, links, and preview nodes.

## Contract

- Render a titled section with optional description, icon, and action slot.
- Render item and variant columns plus one preview column per supplied axis.
- It stays bespoke instead of using `DataTable` because comparison axes
  become dynamic preview columns with per-cell rendered canvases.
- Allow each preview cell to provide its own React node, theme/style scope,
  status badge, support flag, and cell class.
- Show empty and missing-cell states without deriving data.
- Keep table columns stable and horizontally scrollable when preview content
  does not fit the viewport.

## Product-Owned Behavior

Consumers own registry loading, theme definitions, coverage calculations,
variant generation, route state, URL persistence, saved comparisons, analytics,
preview interactivity, permissions, and adoption workflow.

## Accessibility

- The matrix renders as a native table with column headers and row headers.
- Preview cells expose generated `aria-label` text from the row, variant, and
  column labels when those labels are plain strings or numbers.
- Links use normal anchors; consumers decide whether a link is external.

## Non-Goals

- No theme generation or token validation.
- No virtualization, sorting, or filtering.
- No ownership of preview content behavior.
