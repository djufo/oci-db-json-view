# EntityFilterPanel Spec

## Goal

Provide a presentational entity search/filter panel for explorer and admin
collection surfaces before eLitua adopts it.

## Source Pressure

- eLitua accommodation, geo, and guide admin browsers repeat a vertical filter
  panel with search input, select filters, clear action, refresh action,
  loading/refresh disabled states, and filtered/total record counts.
- `ExplorerWorkspace` already owns the page shell and filter slot; this
  component represents the reusable filter content placed inside that slot.

## Contract

- `EntityFilterPanel` renders title/action chrome, controlled text/select
  controls, optional clear/refresh actions with caller-supplied labels, loading
  summary, filtered/total count summary, optional stats, and a footer note.
- Controls are controlled by props. Consuming apps own filter state, result
  derivation, refresh dispatch, data fetching, translations, route/query
  synchronization, and persistence.
- Supplying `onClear` is the intent to offer a reset, so the clear control is
  visible by default. `clearVisible={false}` is an explicit opt-out that keeps
  the button's reserved space (`visibility: hidden`) for callers that bind
  visibility to "filters are active"; it never becomes the default for a caller
  that passed a handler.
- The component uses `ui-entity-filter*` CSS classes and shared catalog tokens
  only.

## Non-Goals

- No entity-specific filter schema, query parsing, data fetching, RxJS dispatch,
  pagination, map integration, persistence, localization, or route ownership.

## Review Expectations

- Search and select controls must stack cleanly in narrow sidebar slots.
- Clear action visibility must not shift the header.
- Loading, refreshing, disabled select, empty-result, and filtered-count states
  must be visible in the catalog demo.
