import { type FormEventHandler, type MouseEvent, type ReactNode } from "react";
import { ArrowLeft } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";

export type AdminRecordEditorNotice = {
  id: string;
  tone?: BadgeTone;
  title?: ReactNode;
  message: ReactNode;
  action?: ReactNode;
};

export type AdminRecordEditorMeta = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type AdminRecordEditorPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  backLabel: ReactNode;
  backHref?: string;
  onBack?: () => void;
  status?: ReactNode;
  statusTone?: BadgeTone;
  meta?: AdminRecordEditorMeta[];
  notices?: AdminRecordEditorNotice[];
  actions?: ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
  loading?: boolean;
  loadingLabel?: ReactNode;
  empty?: boolean;
  emptyLabel?: ReactNode;
  onSubmit?: FormEventHandler<HTMLFormElement>;
  className?: string;
};

export function AdminRecordEditorPanel({
  title,
  eyebrow,
  subtitle,
  backLabel,
  backHref,
  onBack,
  status,
  statusTone = "neutral",
  meta = [],
  notices = [],
  actions,
  children,
  footer,
  loading = false,
  loadingLabel = "Loading record...",
  empty = false,
  emptyLabel = "Record not found.",
  onSubmit,
  className,
}: AdminRecordEditorPanelProps) {
  // Only the BODY varies by state. The footer used to live inside the loaded
  // branch, so the save/delete commands the SPEC calls "stable" disappeared
  // while a record was loading or missing, and reappeared underneath the form
  // once it resolved — the layout shift that wording exists to rule out.
  const body = loading ? (
    <div className="ui-admin-record-editor__state" role="status">
      {loadingLabel}
    </div>
  ) : empty ? (
    <div className="ui-admin-record-editor__state" role="status">
      {emptyLabel}
    </div>
  ) : (
    <div className="ui-admin-record-editor__body">{children}</div>
  );

  return (
    <section className={cn("ui-admin-record-editor", className)} aria-busy={loading || undefined}>
      <header className="ui-admin-record-editor__header">
        <div className="ui-admin-record-editor__title-row">
          <BackControl backHref={backHref} backLabel={backLabel} onBack={onBack} />
          <div className="ui-admin-record-editor__title-block">
            {eyebrow ? <span className="ui-admin-record-editor__eyebrow">{eyebrow}</span> : null}
            <h2>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
          </div>
        </div>
        <div className="ui-admin-record-editor__header-actions">
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {meta.length > 0 ? (
        <div className="ui-admin-record-editor__meta">
          {meta.map((item) => (
            <Badge key={item.id} tone={item.tone}>
              {item.label}
            </Badge>
          ))}
        </div>
      ) : null}

      {notices.length > 0 ? (
        <div className="ui-admin-record-editor__notices">
          {notices.map((notice) => (
            <article
              className={cn("ui-admin-record-editor__notice", `ui-admin-record-editor__notice--${notice.tone ?? "info"}`)}
              key={notice.id}
              role={notice.tone === "danger" ? "alert" : "status"}
            >
              <div className="ui-admin-record-editor__notice-copy">
                {notice.title ? <strong>{notice.title}</strong> : null}
                <p>{notice.message}</p>
              </div>
              {notice.action ? <div className="ui-admin-record-editor__notice-action">{notice.action}</div> : null}
            </article>
          ))}
        </div>
      ) : null}

      <EditorShell footer={footer} onSubmit={onSubmit}>
        {body}
      </EditorShell>
    </section>
  );
}

function BackControl({
  backHref,
  backLabel,
  onBack,
}: {
  backHref?: string;
  backLabel: ReactNode;
  onBack?: () => void;
}) {
  const content = (
    <>
      <ArrowLeft aria-hidden="true" size={18} />
      <span>{backLabel}</span>
    </>
  );

  if (backHref) {
    // Supplying BOTH is legitimate, not a caller error: the href is what makes
    // the control a real link — middle-clickable, copyable, crawlable — while
    // `onBack` is how a router-owning app goes back without a document load.
    // Previously nothing called `preventDefault`, so both ran and the user went
    // back twice.
    //
    // Only a PLAIN left click is intercepted. A modified click (new tab, new
    // window, download) and any non-primary button belong to the browser, and an
    // event something upstream already handled is left alone.
    const handleClick = onBack
      ? (event: MouseEvent<HTMLAnchorElement>) => {
          if (
            event.defaultPrevented ||
            event.button !== 0 ||
            event.metaKey ||
            event.ctrlKey ||
            event.shiftKey ||
            event.altKey
          ) {
            return;
          }
          event.preventDefault();
          onBack();
        }
      : undefined;

    return (
      <a className="ui-admin-record-editor__back" href={backHref} onClick={handleClick}>
        {content}
      </a>
    );
  }

  return (
    <button className="ui-admin-record-editor__back" onClick={onBack} type="button">
      {content}
    </button>
  );
}

/**
 * Wraps whichever body the current state produced, plus the footer, keeping both
 * inside the `<form>` when `onSubmit` is supplied. The form has to stay in every
 * state: a `type="submit"` button in the footer is inert outside its form, so
 * hoisting the footer out of the loaded branch without hoisting the form with it
 * would have made the save command silently stop working while loading.
 */
function EditorShell({
  children,
  footer,
  onSubmit,
}: {
  children?: ReactNode;
  footer?: ReactNode;
  onSubmit?: FormEventHandler<HTMLFormElement>;
}) {
  const footerNode = footer ? (
    <footer className="ui-admin-record-editor__footer">{footer}</footer>
  ) : null;

  if (onSubmit) {
    return (
      <form className="ui-admin-record-editor__form" onSubmit={onSubmit}>
        {children}
        {footerNode}
      </form>
    );
  }

  return (
    <>
      {children}
      {footerNode}
    </>
  );
}
