# BookingWidgetPanel Spec

## Purpose

Presentational public booking section for guide, product, tour, or attraction
pages that need a provider-branded booking widget container, availability
summary, consent notice, fallback messaging, and caller-owned actions.

## Contract

- `BookingWidgetPanel` is presentational and controlled by props.
- Consumers own provider widget SDK/script loading, cookie-consent gating,
  product/widget ids, availability data, checkout flow, analytics, routing,
  localization, and fallback policy.
- The booking widget itself is a `widget` slot. The shared component never loads
  third-party scripts or assumes Bókun-specific DOM requirements.
- Status, badges, summary copy, detail rows, consent notice, fallback content,
  actions, and footer are preformatted React nodes so products keep domain
  wording and formatting.
- Empty widget state preserves the panel layout while provider scripts are not
  yet allowed, unavailable, or pending review.

## Required Demo Coverage

- Public booking header with provider identity, title, subtitle, badges, and
  action slot.
- Availability/status bar with product-owned status detail.
- Booking detail rows for duration, price, language, and meeting information.
- Provider widget slot with a reviewable placeholder.
- Consent notice and fallback/assistive booking message.

## Non-Goals

- No Bókun API calls, checkout state, payment behavior, provider credential
  handling, webhook/sync logic, calendar calculations, or script loading.
- No opinion on consent storage, analytics events, route structure, translations,
  or widget product-id mapping. Those stay in the consuming app.
