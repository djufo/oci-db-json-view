# WorkItemRelationEditorPanel

## Goal

Provide a presentational editor panel for work-item relation lists such as
dependencies, blockers, and related tasks. It standardizes the repeated
multi-list `TagInput` layout, status chrome, action row, loading/error states,
and footer notes without owning task data.

## Source Pressure

- Score `ui/src/features/board/components/TaskDetail.tsx` now renders a local
  `TaskRelationEditor` with dependency, blocker, and related-task tag inputs
  plus cancel, reset, and save actions.
- `WorkItemTracePanel` covers the read-only relationship and review trail, and
  `TagInput` covers one tag field. No shared component represented the
  multi-relation edit surface that composes several controlled relation lists
  with one action row.
- eLitua relationship editing is already represented by `RelationshipPickerPanel`
  for entity associations, so this extraction is Score-specific for work-item
  graph editing.

## Contract

- `WorkItemRelationEditorPanel` accepts controlled relation fields. Each field
  supplies its own draft input value, committed tags, suggestions, add/remove
  callbacks, empty label, hint, and disabled state.
- Consumers own task DTO mapping, relation normalization, duplicate/self-link
  prevention, route parsing, permission checks, dirty-state calculation,
  persistence, confirmations, toasts, and localization.
- The panel renders only presentational chrome: title/status/badges, field grid,
  error/loading state, footer, and action slot.

## Non-Goals

- No direct knowledge of Score task ids, task routes, issue graph rules,
  workflow permissions, autosave policy, or server mutations.
- No replacement for `WorkItemTracePanel` read-only relation review, or for
  eLitua entity relationship selection.

## Review Expectations

- Three relation fields fit side by side on desktop and stack on narrow screens.
- Long task ids and relation labels wrap without overflowing.
- Footer actions remain usable when labels are long or when only one action is
  supplied.
