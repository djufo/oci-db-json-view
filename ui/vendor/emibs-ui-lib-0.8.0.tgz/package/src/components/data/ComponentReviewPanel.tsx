import { type ReactNode, useId } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { Button } from "../primitives/Button";

export type ComponentReviewBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type ComponentReviewMetaItem = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  href?: string;
  external?: boolean;
};

export type ComponentReviewVariant = {
  id: string;
  title: string;
  description?: ReactNode;
  preview: ReactNode;
};

export type ComponentReviewCanvasSize = {
  id: string;
  label: string;
  maxWidth?: number | string;
};

export type ComponentReviewTab = {
  id: string;
  label: string;
  icon?: ReactNode;
  items?: Array<{ id: string; body: ReactNode; icon?: ReactNode }>;
  body?: ReactNode;
  emptyLabel?: ReactNode;
};

export type ComponentReviewPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  summary?: ReactNode;
  badges?: ComponentReviewBadge[];
  meta?: ComponentReviewMetaItem[];
  actions?: ReactNode;
  variants: ComponentReviewVariant[];
  activeVariantId?: string;
  onVariantChange?: (variantId: string) => void;
  canvasSizes?: ComponentReviewCanvasSize[];
  activeCanvasSizeId?: string;
  onCanvasSizeChange?: (sizeId: string) => void;
  tabs?: ComponentReviewTab[];
  activeTabId?: string;
  onTabChange?: (tabId: string) => void;
  reviewNotes?: ReactNode[];
  variantCountLabel?: ReactNode;
  canvasLabel?: ReactNode;
  emptyLabel?: ReactNode;
  className?: string;
};

const defaultCanvasSizes: ComponentReviewCanvasSize[] = [
  { id: "narrow", label: "Narrow", maxWidth: 360 },
  { id: "default", label: "Default", maxWidth: 760 },
  { id: "wide", label: "Wide", maxWidth: 1040 },
  { id: "full", label: "Full" },
];

export function ComponentReviewPanel({
  title,
  eyebrow,
  summary,
  badges = [],
  meta = [],
  actions,
  variants,
  activeVariantId,
  onVariantChange,
  canvasSizes = defaultCanvasSizes,
  activeCanvasSizeId,
  onCanvasSizeChange,
  tabs = [],
  activeTabId,
  onTabChange,
  reviewNotes = [],
  variantCountLabel,
  canvasLabel = "Preview canvas",
  emptyLabel = "No preview variants are available.",
  className,
}: ComponentReviewPanelProps) {
  const generatedId = useId().replace(/:/g, "");
  const variantSelectId = `ui-component-review-${generatedId}-variant`;
  const canvasSizeSelectId = `ui-component-review-${generatedId}-canvas-size`;
  const activeVariant = variants.find((variant) => variant.id === activeVariantId) ?? variants[0];
  const activeCanvasSize = canvasSizes.find((size) => size.id === activeCanvasSizeId) ?? canvasSizes[1] ?? canvasSizes[0];
  const activeTab = tabs.find((tab) => tab.id === activeTabId) ?? tabs[0];
  const stageStyle = activeCanvasSize?.maxWidth
    ? { maxWidth: typeof activeCanvasSize.maxWidth === "number" ? `${activeCanvasSize.maxWidth}px` : activeCanvasSize.maxWidth }
    : undefined;

  return (
    <section className={cn("ui-component-review", className)}>
      <header className="ui-component-review__header">
        <div className="ui-component-review__title-block">
          {eyebrow ? <span className="ui-component-review__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {summary ? <p>{summary}</p> : null}
        </div>
        {actions ? <div className="ui-component-review__actions">{actions}</div> : null}
      </header>

      {badges.length > 0 || meta.length > 0 ? (
        <div className="ui-component-review__meta-panel">
          {badges.length > 0 ? (
            <div className="ui-component-review__badges" aria-label="Review tags">
              {badges.map((badge) => (
                <Badge key={badge.id} tone={badge.tone}>
                  {badge.label}
                </Badge>
              ))}
            </div>
          ) : null}
          {meta.length > 0 ? <ComponentReviewMeta items={meta} /> : null}
        </div>
      ) : null}

      {activeVariant ? (
        <div className="ui-component-review__workspace">
          <article
            className="ui-component-review__canvas-card"
            aria-label={typeof canvasLabel === "string" ? canvasLabel : "Component preview canvas"}
          >
            <header className="ui-component-review__card-header">
              <div>
                <h3>{canvasLabel}</h3>
                {activeVariant.description ? <p>{activeVariant.description}</p> : null}
              </div>
              {activeCanvasSize ? <Badge tone="info">{activeCanvasSize.label}</Badge> : null}
            </header>
            <div className="ui-component-review__canvas">
              <div className="ui-component-review__stage" style={stageStyle}>
                {activeVariant.preview}
              </div>
            </div>
          </article>

          <aside className="ui-component-review__controls" aria-label="Review controls">
            <div className="ui-component-review__control">
              <label htmlFor={variantSelectId}>Variant</label>
              <select
                id={variantSelectId}
                value={activeVariant.id}
                onChange={(event) => onVariantChange?.(event.currentTarget.value)}
              >
                {variants.map((variant) => (
                  <option key={variant.id} value={variant.id}>
                    {variant.title}
                  </option>
                ))}
              </select>
            </div>
            {canvasSizes.length > 0 && activeCanvasSize ? (
              <div className="ui-component-review__control">
                <label htmlFor={canvasSizeSelectId}>Canvas width</label>
                <select
                  id={canvasSizeSelectId}
                  value={activeCanvasSize.id}
                  onChange={(event) => onCanvasSizeChange?.(event.currentTarget.value)}
                >
                  {canvasSizes.map((size) => (
                    <option key={size.id} value={size.id}>
                      {size.label}
                    </option>
                  ))}
                </select>
              </div>
            ) : null}
            {reviewNotes.length > 0 ? (
              <div className="ui-component-review__notes">
                <strong>Review scope</strong>
                <ul>
                  {reviewNotes.map((note, index) => (
                    <li key={index}>{note}</li>
                  ))}
                </ul>
              </div>
            ) : null}
          </aside>
        </div>
      ) : (
        <p className="ui-component-review__empty">{emptyLabel}</p>
      )}

      {tabs.length > 0 && activeTab ? (
        <article className="ui-component-review__tabs">
          <div className="ui-component-review__tab-list" role="tablist" aria-label="Review sections">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                type="button"
                role="tab"
                aria-selected={tab.id === activeTab.id}
                className={cn("ui-component-review__tab", tab.id === activeTab.id && "is-active")}
                onClick={() => onTabChange?.(tab.id)}
              >
                {tab.icon ? <span className="ui-component-review__tab-icon">{tab.icon}</span> : null}
                <span>{tab.label}</span>
              </button>
            ))}
          </div>
          <div className="ui-component-review__tab-panel" role="tabpanel">
            {activeTab.body ? activeTab.body : <ComponentReviewTabList tab={activeTab} />}
          </div>
        </article>
      ) : null}

      {variants.length > 0 ? (
        <section className="ui-component-review__variants" aria-label="Preview variants">
          <header className="ui-component-review__variants-header">
            <div>
              <h3>Variants</h3>
              <p>Representative states for visual review.</p>
            </div>
            <Badge>{variantCountLabel ?? `${variants.length} states`}</Badge>
          </header>
          <div className="ui-component-review__variant-grid">
            {variants.map((variant) => (
              <article
                key={variant.id}
                className={cn("ui-component-review__variant", variant.id === activeVariant?.id && "is-active")}
              >
                <header>
                  <div>
                    <h4>{variant.title}</h4>
                    {variant.description ? <p>{variant.description}</p> : null}
                  </div>
                  <Button
                    type="button"
                    size="sm"
                    variant={variant.id === activeVariant?.id ? "primary" : "secondary"}
                    onClick={() => onVariantChange?.(variant.id)}
                  >
                    Inspect
                  </Button>
                </header>
                <div className="ui-component-review__variant-preview">{variant.preview}</div>
              </article>
            ))}
          </div>
        </section>
      ) : null}
    </section>
  );
}

function ComponentReviewMeta({ items }: { items: ComponentReviewMetaItem[] }) {
  return (
    <dl className="ui-component-review__meta">
      {items.map((item) => (
        <div key={item.id}>
          <dt>{item.label}</dt>
          <dd>
            {item.href ? (
              <a href={item.href} target={item.external ? "_blank" : undefined} rel={item.external ? "noreferrer" : undefined}>
                {item.value}
              </a>
            ) : (
              item.value
            )}
          </dd>
        </div>
      ))}
    </dl>
  );
}

function ComponentReviewTabList({ tab }: { tab: ComponentReviewTab }) {
  if (!tab.items?.length) {
    return <p className="ui-component-review__empty">{tab.emptyLabel ?? "No review notes for this section."}</p>;
  }
  return (
    <ul className="ui-component-review__tab-items">
      {tab.items.map((item) => (
        <li key={item.id}>
          {item.icon ? <span className="ui-component-review__item-icon">{item.icon}</span> : null}
          <span>{item.body}</span>
        </li>
      ))}
    </ul>
  );
}
