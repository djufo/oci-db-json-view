# WorkItemTracePanel

## Goal

Provide a presentational trace panel for work-item relationships and review
notes: dependency groups, related links, reviewer decisions, timestamps, note
bodies, loading/error states, and optional local actions.

## Source Pressure

- Score `ui/src/features/board/components/TaskDetail.tsx` renders task
  relations and review notes as local sections after larger detail, document,
  attachment, confirmation, creation, and planning controls have already been
  extracted.
- eLitua does not currently have an equivalent review-thread surface; its
  remaining larger shells and profile/media/admin pages are already represented
  by earlier catalog components or follow-up tasks.

## Contract

- `WorkItemTracePanel` accepts controlled relation groups and review notes.
- Relation items may be plain labels or links; consumers decide route shape,
  entity labels, access rules, and external-link policy.
- Review notes render author, decision, metadata, body, and action slots without
  creating or mutating reviews.
- Loading and error states are visual only.

## Non-Goals

- No Score workflow transitions, review creation, permission checks, actor
  lookup, task DTO mapping, route parsing, subscription state, notifications,
  audit events, or relative-time formatting.

## Review Expectations

- Relation chips and note bodies must wrap without overflowing.
- Desktop layout places relations and notes side by side; narrow screens stack
  them with full-width actions.
- Empty relation groups and empty notes remain explicit.
