# PortalInfoPage Spec

## Goal

Provide a presentational public information page shell for portal About,
mission, founder, and trust pages before consuming apps adopt it.

## Source Pressure

- eLitua's `AboutPage` combines an identity-led information page: headline and
  lead copy, landscape banner, proof metrics, long-form explanatory sections,
  business bullet points, mission callout, and founder/contact card.
- The shape is distinct from `PortalLandingPage`, which is conversion-oriented,
  and from `EditorialArticlePage`, which is author/date/article oriented.
  Informational portal pages need a stable way to explain product mission and
  organization context without creating another bespoke page shell.

## Contract

- `PortalInfoPage` renders supplied hero copy, optional image, stat highlights,
  structured content sections, mission callout, optional author/founder card,
  custom child content, and footer slot.
- Sections are structured data with optional title, paragraphs, list items,
  actions, children, and tone.
- Consuming apps own copy, localization, routing, analytics, external links,
  image source policy, CMS integration, and any contact form or video behavior.
- Styling uses catalog tokens and avoids project-specific class names.

## Non-Goals

- No CMS adapter, markdown parser, translation loader, route lookup, video
  embed, contact form, analytics hook, image optimizer, or organization schema
  metadata.
- No eLitua-specific text, founder data, or external URLs are hardcoded in the
  component.

## Review Expectations

- Long translated text, metric labels, list items, author copy, and action rows
  must wrap without overlap at catalog desktop and mobile widths.
- The information page should remain readable without nested cards and without
  depending on eLitua theme variables.
