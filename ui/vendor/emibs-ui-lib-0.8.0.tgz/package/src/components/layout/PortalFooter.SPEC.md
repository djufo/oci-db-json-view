# PortalFooter

## Purpose

Reusable desktop portal footer extracted from eLitua's global layout chrome:
brand mark, centered policy/about links, optional action slot, and copyright
text aligned to the trailing edge.

## Contract

- `PortalFooter` is presentational and does not own routing, translations,
  current-year calculation, legal content, or responsive layout orchestration.
- Links require concrete `href` values so consuming apps keep URL-owned
  navigation. Framework-specific link adapters stay in the app.
- Brand, action controls, and copyright text are slots so product-specific
  identity, locale, theme, and legal copy remain outside the shared component.
- `visibility="desktop"` matches eLitua's current paired desktop-footer/mobile-nav
  layout. `visibility="always"` is available for apps that do not pair it with a
  mobile bottom navigation.

## Source

- `/engineering/projects/elitua/ui/src/components/layout/footer/FooterDesktop/FooterDesktop.tsx`
- `/engineering/projects/elitua/ui/src/components/layout/footer/FooterDesktop/FooterDesktop.module.scss`
- `/engineering/projects/elitua/ui/src/components/layout/Layout/Layout.tsx`
