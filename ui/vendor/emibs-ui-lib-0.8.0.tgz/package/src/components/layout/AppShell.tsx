import { type ReactNode } from "react";
import { cn } from "../../lib";

export type NavItem = {
  label: string;
  href: string;
  icon?: ReactNode;
  active?: boolean;
};

export function AppShell({
  brand,
  nav,
  actions,
  children,
}: {
  brand: ReactNode;
  nav: NavItem[];
  actions?: ReactNode;
  children: ReactNode;
}) {
  return (
    <div className="ui-shell">
      <aside className="ui-shell__side">
        <div className="ui-shell__brand">{brand}</div>
        <nav className="ui-shell__nav" aria-label="Catalog sections">
          {nav.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={cn("ui-shell__nav-item", item.active && "is-active")}
            >
              {item.icon}
              <span>{item.label}</span>
            </a>
          ))}
        </nav>
      </aside>
      <main className="ui-shell__main">
        <div className="ui-shell__bar">{actions}</div>
        {children}
      </main>
    </div>
  );
}

