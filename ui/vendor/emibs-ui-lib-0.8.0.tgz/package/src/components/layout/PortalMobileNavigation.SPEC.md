# PortalMobileNavigation

## Purpose

Reusable mobile portal navigation extracted from eLitua's bottom navigation and
full-menu bottom sheet pattern.

## Contract

- `PortalMobileNavigation` is presentational and does not own routing, auth,
  translations, theme switching, or menu registry state.
- Bottom navigation items and sheet links use concrete `href` values when they
  navigate. Button-only items are reserved for consumer-owned callbacks.
- Sheet open state is controlled by props so apps keep URL, menu, and layout
  state outside the shared component.
- `dock="fixed"` matches app usage at the viewport bottom. `dock="contained"`
  exists only for demos, screenshots, and embedded review surfaces.

## Source

- `/engineering/projects/elitua/ui/src/components/layout/footer/FooterMobileNav/FooterMobileNav.tsx`
- `/engineering/projects/elitua/ui/src/components/layout/footer/FooterMobileNav/FooterMobileNav.module.scss`
- `/engineering/projects/elitua/ui/src/components/layout/footer/BottomSheet/BottomSheet.tsx`
- `/engineering/projects/elitua/ui/src/components/layout/footer/BottomSheet/BottomSheet.module.scss`
