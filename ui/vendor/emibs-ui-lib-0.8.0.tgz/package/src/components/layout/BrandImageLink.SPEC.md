# BrandImageLink

`BrandImageLink` is a presentational responsive brand/logo link for app
headers, portal shells, and compact mobile chrome.

## Source Evidence

- eLitua `ui/src/components/layout/header/DesktopLogo/DesktopLogo.tsx` renders a
  linked responsive desktop logo image with `srcSet`, `sizes`, explicit
  dimensions, and async decoding.
- eLitua `ui/src/components/layout/header/MobileLogo/MobileLogo.tsx` repeats the
  same linked-logo pattern at a compact mobile size.
- `PortalHeader` already accepts `brand` and `mobileBrand` slots, but the shared
  catalog did not yet own the reusable image-link pattern that feeds those
  slots.

## Contract

- Renders one anchor with an accessible `label`, optional external-link
  behavior, and optional `onClick` hook.
- Renders desktop and optional mobile image sources with explicit sizing,
  `srcSet`, `sizes`, decoding, and loading attributes supplied by the consuming
  app.
- Treats images as decorative inside the labeled link to avoid duplicate screen
  reader text.
- Optional title/subtitle text can accompany the image for compact text lockups.
- Does not own asset paths, route adapters, brand policy, analytics, or theme
  selection.

## Review Notes

- eLitua keeps `useSystemValues`, React Router link adaptation, logo file
  hosting, alt/brand copy policy, and route behavior local.
- Score can continue using text-only shell branding unless it later adopts a
  concrete visual identity; this extraction does not create Score adoption
  pressure.
