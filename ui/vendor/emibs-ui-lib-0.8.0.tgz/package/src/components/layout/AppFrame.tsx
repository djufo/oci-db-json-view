import { createContext, useContext, type HTMLAttributes, type ReactNode } from "react";
import { cn } from "../../lib/cn";
import { useAppearance, type Appearance, type AppearanceOptions } from "../../theme/appearance";
import { DensityScope } from "../../theme/DensityScope";
import { ThemeScope } from "../../theme/ThemeScope";
import "./pageTemplates.css";

const AppFrameContext = createContext<Appearance | null>(null);

/**
 * The appearance of the nearest <AppFrame>: the current family, mode, density
 * and the setters. Returns null outside a frame so a component can render
 * without one (a catalog demo, a test) instead of throwing.
 */
export function useAppFrame(): Appearance | null {
  return useContext(AppFrameContext);
}

export type AppFrameProps = Omit<HTMLAttributes<HTMLDivElement>, "children"> &
  AppearanceOptions & {
    children: ReactNode;
  };

/**
 * The root of an app that uses the house style.
 *
 * It owns the three things every app otherwise wires by hand: the theme scope,
 * the density scope, and the user's persisted appearance choice. Everything
 * inside reads the theme tokens; <AppearanceControls> placed anywhere inside
 * edits the choice.
 *
 * The frame fills the viewport and paints the page background, so an app needs
 * no body or root styles of its own.
 */
export function AppFrame({
  storageKey,
  families,
  defaultFamilyId,
  defaultMode,
  defaultDensity,
  className,
  children,
  ...props
}: AppFrameProps) {
  const appearance = useAppearance({ storageKey, families, defaultFamilyId, defaultMode, defaultDensity });

  return (
    <AppFrameContext.Provider value={appearance}>
      <ThemeScope {...props} className={cn("ui-app-frame", className)} theme={appearance.theme}>
        <DensityScope className="ui-app-frame__body" density={appearance.density}>
          {children}
        </DensityScope>
      </ThemeScope>
    </AppFrameContext.Provider>
  );
}
