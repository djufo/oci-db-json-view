import { type CSSProperties, type ReactNode } from "react";
import { LayoutGrid, List, Map as MapIcon, X } from "lucide-react";
import { cn } from "../../lib";
import { Button } from "../primitives/Button";

export type ExplorerView = "map" | "table" | "cards";

export type ExplorerViewOption = {
  id: ExplorerView;
  label: string;
  icon?: ReactNode;
  disabled?: boolean;
};

export type ExplorerWorkspaceProps = {
  views: ExplorerViewOption[];
  activeView: ExplorerView;
  onViewChange: (view: ExplorerView) => void;
  controls?: ReactNode;
  filters?: ReactNode;
  mapControls?: ReactNode;
  detail?: ReactNode;
  children: ReactNode;
  bottomPanel?: ReactNode;
  loading?: boolean;
  loadingLabel?: string;
  error?: string | null;
  onDismissError?: () => void;
};

const viewIcons: Record<ExplorerView, ReactNode> = {
  map: <MapIcon size={16} aria-hidden="true" />,
  table: <List size={16} aria-hidden="true" />,
  cards: <LayoutGrid size={16} aria-hidden="true" />,
};

export function ExplorerWorkspace({
  views,
  activeView,
  onViewChange,
  controls,
  filters,
  mapControls,
  detail,
  children,
  bottomPanel,
  loading = false,
  loadingLabel = "Loading records",
  error,
  onDismissError,
}: ExplorerWorkspaceProps) {
  return (
    <div className="ui-explorer">
      {error ? (
        <div className="ui-explorer__error" role="alert">
          <span>{error}</span>
          {onDismissError ? (
            <Button type="button" variant="ghost" size="icon" onClick={onDismissError} aria-label="Dismiss error">
              <X size={16} aria-hidden="true" />
            </Button>
          ) : null}
        </div>
      ) : null}

      <aside className="ui-explorer__sidebar" aria-label="Explorer controls">
        <ExplorerViewSwitcher views={views} activeView={activeView} onViewChange={onViewChange} />
        {controls ? <ExplorerSidebarSection title="Controls">{controls}</ExplorerSidebarSection> : null}
        {filters ? <ExplorerSidebarSection title="Filters">{filters}</ExplorerSidebarSection> : null}
        {mapControls ? <ExplorerSidebarSection title="Map">{mapControls}</ExplorerSidebarSection> : null}
        {detail ? <div className="ui-explorer__detail">{detail}</div> : null}
      </aside>

      <main className="ui-explorer__main">
        <div className={cn("ui-explorer__content", `ui-explorer__content--${activeView}`)}>
          {loading ? (
            <div className="ui-explorer__loading">
              <span className="ui-explorer__spinner" aria-hidden="true" />
              <span>{loadingLabel}</span>
            </div>
          ) : (
            children
          )}
        </div>
        {bottomPanel ? <div className="ui-explorer__bottom-panel">{bottomPanel}</div> : null}
      </main>
    </div>
  );
}

export function ExplorerViewSwitcher({
  views,
  activeView,
  onViewChange,
}: {
  views: ExplorerViewOption[];
  activeView: ExplorerView;
  onViewChange: (view: ExplorerView) => void;
}) {
  const style = { "--ui-view-count": views.length } as CSSProperties;

  return (
    <div className="ui-explorer-switcher" role="radiogroup" aria-label="Explorer view" style={style}>
      {views.map((view) => (
        <button
          key={view.id}
          type="button"
          role="radio"
          aria-checked={view.id === activeView}
          disabled={view.disabled}
          className={cn("ui-explorer-switcher__item", view.id === activeView && "is-active")}
          onClick={() => onViewChange(view.id)}
        >
          {view.icon ?? viewIcons[view.id]}
          <span>{view.label}</span>
        </button>
      ))}
    </div>
  );
}

export function ExplorerSidebarSection({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <section className="ui-explorer__section">
      <h3>{title}</h3>
      <div className="ui-explorer__section-body">{children}</div>
    </section>
  );
}
