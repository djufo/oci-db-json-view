# EditorialArticlePage Spec

## Goal

Provide a presentational editorial article shell for public content pages before
product apps adopt it.

## Source Pressure

- eLitua's blog article route uses a repeated article page structure: back link,
  category pill, author/meta header, visual hero, mobile and desktop table of
  contents, rich body sections, inline CTA, paywall prompt, tags, share actions,
  author bio, and related articles.
- The same shell can support travel guides, itinerary articles, B2B insights,
  and future long-form product documentation without binding the component to
  eLitua routing or data loading.

## Contract

- `EditorialArticlePage` renders supplied article metadata, hero, table of
  contents, sections, paywall, tags, share actions, author bio, and related
  items.
- Body sections are structured data. Supported section types are headings,
  paragraphs, unordered lists, quotes, images, and inline CTA rows.
- Consuming apps own routing, article lookup, active heading observation,
  clipboard behavior, subscription access rules, analytics, and localization.
- Styling uses catalog tokens and avoids project-specific class names.

## Non-Goals

- No markdown parser, CMS adapter, fetch logic, route lookup, generated table of
  contents, share URL builder, or paywall authorization logic.
- No product-specific author/category/tag taxonomy.

## Review Expectations

- The article header, hero, content column, sticky desktop TOC, mobile TOC, and
  related grid must stay readable at catalog desktop and mobile widths.
- Long titles, related article names, tags, and share buttons must wrap without
  overlapping adjacent content.
