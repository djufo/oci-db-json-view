# WorkspacePageFrame

## Purpose

Reusable route-content frame extracted from Score's app shell. It gives
operator workspaces a consistent page-width, padding, overflow, and standalone
object-detail frame after the topbar/tab shell has selected a route.

## Contract

- `WorkspacePageFrame` is presentational and does not own routing, auth, route
  selection, live data, or feature rendering.
- `layout` selects the visual frame: `default`, `board`, `operational`, `full`,
  or `object`.
- `operational` constrains dense admin/settings-style surfaces to a readable
  maximum width.
- `full` keeps route content edge-to-edge for map/workflow-style canvases.
- `object` constrains standalone task, agent, and project detail surfaces and
  applies a stable internal scroll region.
- Consumers own route-to-layout mapping, close/back behavior, object max-height
  policy, and any product-specific nested panel styles.

## Source

- `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`
- `/engineering/projects/score/ui/src/styles.css`
- `/engineering/projects/score/AGENT.md`

## Return Path

After review, Score can replace its local `score-app-main`,
`score-operational-route`, `score-full-route`, and `score-object-route` frame
classes with `WorkspacePageFrame` while keeping route parsing, boot state,
feature container selection, object-route closing, and toasts in Score.
