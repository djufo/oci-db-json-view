import { type ImgHTMLAttributes, type ReactNode } from "react";
import { cn } from "../../lib";

export type BrandImageSource = {
  src: string;
} & Pick<ImgHTMLAttributes<HTMLImageElement>, "srcSet" | "sizes" | "width" | "height" | "loading" | "decoding">;

export type BrandImageLinkProps = {
  href: string;
  label: string;
  desktopImage: BrandImageSource;
  mobileImage?: BrandImageSource;
  title?: ReactNode;
  subtitle?: ReactNode;
  external?: boolean;
  className?: string;
  imageClassName?: string;
  textClassName?: string;
  onClick?: () => void;
};

export function BrandImageLink({
  href,
  label,
  desktopImage,
  mobileImage,
  title,
  subtitle,
  external = false,
  className,
  imageClassName,
  textClassName,
  onClick,
}: BrandImageLinkProps) {
  return (
    <a
      className={cn("ui-brand-image-link", className)}
      href={href}
      aria-label={label}
      target={external ? "_blank" : undefined}
      rel={external ? "noreferrer" : undefined}
      onClick={onClick}
    >
      <span className="ui-brand-image-link__media" aria-hidden="true">
        <BrandImage
          image={desktopImage}
          className={cn("ui-brand-image-link__image", mobileImage && "ui-brand-image-link__image--desktop", imageClassName)}
        />
        {mobileImage ? (
          <BrandImage image={mobileImage} className={cn("ui-brand-image-link__image", "ui-brand-image-link__image--mobile", imageClassName)} />
        ) : null}
      </span>
      {title || subtitle ? (
        <span className={cn("ui-brand-image-link__text", textClassName)}>
          {title ? <span className="ui-brand-image-link__title">{title}</span> : null}
          {subtitle ? <span className="ui-brand-image-link__subtitle">{subtitle}</span> : null}
        </span>
      ) : null}
    </a>
  );
}

function BrandImage({ image, className }: { image: BrandImageSource; className?: string }) {
  return (
    <img
      {...image}
      alt=""
      className={className}
      decoding={image.decoding ?? "async"}
      loading={image.loading ?? "eager"}
    />
  );
}
