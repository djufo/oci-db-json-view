# PageHeader

## Purpose

Reusable page and section heading contract for Score operator routes and eLitua
account/admin pages. It keeps route-level chrome consistent while leaving app
navigation, permissions, state, localization, and persistence to the consuming
project.

## Contract

- `PageHeader` is presentational and does not own routing, data loading, auth,
  form submission, save state, or localization.
- `title` is required and can render as `h1`, `h2`, or `h3` through `level`.
- `eyebrow`, `description`, `status`, `badges`, and `meta` render optional
  route context without requiring product-specific data shapes.
- `actions` is an opaque slot for product commands such as save, refresh,
  create, open, disconnect, or export.
- `back` renders an anchor when `href` is supplied and a button otherwise;
  consumers still own route handlers and history policy.
- `leading` supports icons, avatars, or product marks without embedding app
  assets in the shared component.
- `density` selects comfortable or compact spacing for full pages versus nested
  admin/card sections.

## Source

- `/engineering/projects/score/ui/src/features/catalog/containers/CatalogExplorerContainer.tsx`
- `/engineering/projects/score/ui/src/features/projects/containers/ProjectPage.tsx`
- `/engineering/projects/elitua/ui/src/pages/account/guide-profile/GuideProfilePage.tsx`
- `/engineering/projects/elitua/ui/src/pages/account/bokun/`
- `/engineering/projects/elitua/ui/src/pages/admin/payments/PaymentsPage.tsx`
- `/engineering/projects/elitua/ui/src/pages/admin/AdminEdit.module.scss`

## Boundaries

- Keep route selection, back navigation, dialog orchestration, API calls,
  validation, permissions, and persisted draft state in the product app.
- Keep translation strings, date/number formatting, and provider-specific labels
  in the consuming project.
- Do not embed Score task semantics, eLitua booking/provider behavior, or admin
  form lifecycle logic in this component.

## Return Path

After review, Score can replace compatible catalog, project, and admin route
heading clusters with `PageHeader` while keeping live sync, permissions, route
parsing, and mutations local. eLitua can replace compatible account and admin
page headings, including guide profile, Bokun, payments, and admin edit/list
surfaces, while keeping routing, i18n, auth, provider widgets, and persistence
local.
