# PageScaffold

## Purpose

The body of a page inside an app shell. Every list, detail, dashboard and form
page is the same stack — header, optional notice and toolbar, content, footer —
so the spacing, the width limits and the loading/empty/error decision are made
here once instead of in each app's stylesheet.

## Contract

- Renders, in order: `header`, `notice`, `toolbar`, then the content and
  `footer`. A slot that is not passed renders nothing.
- `state` replaces the content with a `DataStatePanel`: `loading` (status,
  busy), `empty` (status) or `error` (alert). `header`, `notice` and `toolbar`
  stay, so the user keeps their place and their filters. `state.action` renders
  as the panel's action, for example a retry button.
- `footer` renders whenever it is passed, including while `state` is set. An
  empty page of a cursor-paged list still needs its "Previous" control, and the
  scaffold cannot tell that case from an empty first page; the consumer can, so
  the consumer omits the footer when it would be meaningless.
- A page that already has content and is refreshing passes no `state`; use
  `notice` for a message that should not hide the content.
- `width` limits the content width: `default` (90rem), `narrow` (48rem, for
  forms), `wide` (120rem) or `full` (no limit). The scaffold centres itself.
- The scaffold adds no padding of its own; the shell's content area supplies
  it. It draws no surface: content brings its own `SectionCard` or table.

### PageColumns

A two-region row for page content, exported from the same module.

- `layout` is `aside-main` (default), `main-aside` or `halves`. The supporting
  region takes about a third of the width in the first two.
- Below 980px every layout becomes one column, in source order.

## Consumer boundary

The consuming app owns data loading, which state applies, the header's
content, filter state and pagination state.
