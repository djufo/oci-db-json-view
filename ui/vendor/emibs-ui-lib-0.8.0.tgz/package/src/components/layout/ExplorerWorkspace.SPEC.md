# ExplorerWorkspace

## Purpose

`ExplorerWorkspace` is the fixed-height browse shell for a record set that can
be looked at three ways: on a map, in a table, or as cards. A persistent left
rail holds the view switcher plus stacked control / filter / map-control
sections and an optional selected-record detail box; the main column renders
whichever view the app currently has active, with an optional pinned bottom
panel underneath. It keeps the explorer *frame* — rail width, section chrome,
scroll boundaries, error banner, loading placeholder — in one place so map,
table, and card surfaces do not each grow their own.

The module also exports the two pieces the shell composes, `ExplorerViewSwitcher`
and `ExplorerSidebarSection`, so a product can reuse them outside the frame.

## Public contract

```tsx
type ExplorerView = "map" | "table" | "cards";

type ExplorerViewOption = {
  id: ExplorerView;
  label: string;
  icon?: ReactNode;
  disabled?: boolean;
};
```

| Prop | Type | Default | Meaning |
| --- | --- | --- | --- |
| `views` | `ExplorerViewOption[]` | — | Switcher options, in order. Also sets `--ui-view-count` for the switcher grid |
| `activeView` | `ExplorerView` | — | Which option reads as checked, and the `ui-explorer__content--<view>` modifier |
| `onViewChange` | `(view: ExplorerView) => void` | — | Fired on option click. Required — the component is fully controlled |
| `controls` | `ReactNode` | — | Rail section titled "Controls"; omitted entirely when falsy |
| `filters` | `ReactNode` | — | Rail section titled "Filters" |
| `mapControls` | `ReactNode` | — | Rail section titled "Map" |
| `detail` | `ReactNode` | — | Highlighted box at the bottom of the rail, for the selected record |
| `children` | `ReactNode` | — | The active view's content, in the main column |
| `bottomPanel` | `ReactNode` | — | Pinned strip below the content (pager, summary) |
| `loading` | `boolean` | `false` | Replaces `children` with the spinner placeholder |
| `loadingLabel` | `string` | `"Loading records"` | Visible text beside the spinner |
| `error` | `string \| null` | — | When truthy, renders the banner across the top of the grid |
| `onDismissError` | `() => void` | — | When present, adds the banner's dismiss button |

`ExplorerWorkspaceProps` is exported as a named type.

DOM shape:

```
div.ui-explorer
  div.ui-explorer__error [role=alert]        (only while `error`)
  aside.ui-explorer__sidebar
    ExplorerViewSwitcher
    ExplorerSidebarSection "Controls"        (only if `controls`)
    ExplorerSidebarSection "Filters"         (only if `filters`)
    ExplorerSidebarSection "Map"             (only if `mapControls`)
    div.ui-explorer__detail                  (only if `detail`)
  main.ui-explorer__main
    div.ui-explorer__content--<activeView>   → spinner or children
    div.ui-explorer__bottom-panel            (only if `bottomPanel`)
```

`ExplorerViewSwitcher({ views, activeView, onViewChange })` renders a
`radiogroup` of `<button type="button" role="radio">` options. Each shows
`option.icon` if given, otherwise the built-in lucide default for its id — map →
`Map`, table → `List`, cards → `LayoutGrid`, all at 16px with
`aria-hidden="true"`. `option.disabled` disables the button.

`ExplorerSidebarSection({ title, children })` renders `<section>` → `<h3>` +
`div.ui-explorer__section-body`.

The component holds **no state of its own** — no `useState`, no `useEffect`, no
refs. Section titles are hardcoded; the rail slots are positional, not a list.

## Variants and states matrix

| State | Trigger | Result |
| --- | --- | --- |
| Map / table / cards | `activeView` | `ui-explorer__content--<view>`; the map modifier switches the content box from `overflow: auto` to `hidden` |
| Loading | `loading` | Content is replaced by a centred spinner + `loadingLabel`, min-height 420px; `children` are unmounted |
| Error | `error` truthy | Amber full-width banner above both columns |
| Dismissible error | `error` + `onDismissError` | Banner gains an icon button labelled "Dismiss error" |
| Disabled view | `option.disabled` | Button disabled, `not-allowed` cursor, 50% opacity |
| Rail sections | each of `controls` / `filters` / `mapControls` | Section renders only when its slot is non-empty |
| Detail | `detail` | Blue-tinted inset card at the bottom of the rail |
| Bottom panel | `bottomPanel` | Strip capped at 220px, scrolls internally |
| Narrow viewport | ≤ breakpoint | Grid collapses to one column; the rail moves above the main column, capped at 360px with a bottom border; the switcher becomes one column of left-aligned 44px rows |

Loading and error are independent: an error banner stays visible over a loading
content area.

## Accessibility

Implemented today:

- `aside` carries `aria-label="Explorer controls"`; the content column is a real
  `<main>`.
- The switcher is `role="radiogroup"` with `aria-label="Explorer view"`, and
  each option is `role="radio"` with `aria-checked` reflecting `activeView`.
- The error banner is `role="alert"`, so it is announced when it mounts. Its
  dismiss control is an icon button with `aria-label="Dismiss error"`.
- Built-in switcher icons are marked `aria-hidden="true"`, and every option
  keeps a visible text label, so the view is never conveyed by icon alone.
- The loading spinner span is `aria-hidden="true"`; the `loadingLabel` text is
  the visible, readable part.

Gaps that the source makes clear, stated rather than papered over:

- **The radiogroup has no keyboard pattern.** The options are plain buttons with
  no roving tabindex and no arrow/Home/End handling, so each option is
  separately tabbable and arrow keys do nothing. This diverges from the
  WAI-ARIA radiogroup pattern that the announced roles imply. (Contrast
  `ContentTabs`, which does implement roving tabindex.)
- **Loading is not announced.** The loading region has no `role="status"`, no
  `aria-live`, and no `aria-busy` anywhere on the content column, so assistive
  technology is not told when a view starts or finishes loading. The consumer
  cannot add it from outside — there is no pass-through for content-column
  attributes.
- **The spinner ignores reduced motion.** `.ui-explorer__spinner` animates
  `ui-spin` with no `prefers-reduced-motion: reduce` override, unlike
  `LoadingSpinner` and `DataStatePanel`, which do have one.
- Rail sections use `<section>` with a heading but no `aria-labelledby`, so they
  are not exposed as named regions; the `<h3>` gives visual and heading
  structure only, and its level is fixed at 3 regardless of the surrounding
  document outline.
- Consumer-supplied `option.icon` nodes are not hidden from assistive technology
  automatically — pass `aria-hidden="true"` on decorative glyphs.

## Theming

Token-driven: `--border` (frame, rail divider, section rules, switcher rules,
spinner track), `--surface` (frame and main column background), `--text-muted`
(section headings, switcher rest state, detail body copy), `--accent` (spinner
leading arc).

Hardcoded hex, **not tokenized**, so these do not follow a theme or dark
palette:

- rail background and bottom-panel background `#f8fafc`;
- switcher hover/active `#e0f2fe` on `#075985`;
- detail card `#eff6ff` on a `#bfdbfe` border;
- error banner `#fff7ed` / `#fed7aa` / `#9a3412`.

The component sets one custom property itself: `--ui-view-count`, from
`views.length`, which drives the switcher's `repeat(var(--ui-view-count, 3),
minmax(0, 1fr))` grid. Geometry is fixed: `270px` rail, `560px` frame
min-height, `220px` bottom-panel cap. There is no `--density-*` support and no
`DensityScope` participation.

## Consumer / product boundary

`ExplorerWorkspace` owns the frame, the slot arrangement, the view switcher
chrome, and the scroll boundaries. **The consuming app owns everything with
meaning in it:**

- **View state.** `activeView` is fully controlled; the shell never stores or
  restores it and never touches the URL. Deep links, back/forward behaviour, and
  view persistence are the app's.
- **Data.** No fetching, pagination, sorting, selection, or record model. The
  map, table, and card renderers are passed in as `children`.
- **The map engine.** `mapControls` is a slot; zoom, fit, tiles, markers, and
  geocoding all live outside.
- **Filtering and search.** `controls` and `filters` are slots — compose
  `SearchField`, `EntityFilterPanel`, or `FacetFilterPanel` into them; the shell
  applies nothing.
- **Selection.** `detail` is rendered as given; which record is selected, and
  how it is loaded, is the app's.
- **Error lifecycle.** The app produces the `error` string, decides the wording,
  owns retry, and clears it in `onDismissError` — the shell only displays and
  requests dismissal.

## Known limitations

- `ExplorerView` is a closed union of `"map" | "table" | "cards"`. A fourth view
  is a type error, and the built-in icon map covers exactly those three ids.
- The rail slots are three fixed positions with hardcoded English titles
  ("Controls", "Filters", "Map"). An app needing a fourth section, different
  wording, reordering, or collapsible sections must compose
  `ExplorerSidebarSection` itself rather than configure the shell.
- Only one error at a time, as a plain string — no severity, no error list, no
  retry affordance.
- `loading` unmounts `children` rather than overlaying them, so the active
  view's internal state (map viewport, table scroll position) is lost across a
  reload rather than preserved.
