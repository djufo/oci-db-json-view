# TableOfContentsNav Spec

## Purpose

Review-ready article and document section navigation extracted from eLitua's
blog article table of contents and the existing editorial article shell TOC.

## Contract

- `TableOfContentsNav` renders a presentational `<nav>` with an ordered list of
  caller-supplied heading links.
- Items require `id`, `label`, and `href`; `level: 3` renders as a nested row.
- `activeItemId` marks the matching link with `aria-current="location"`.
- `variant` supports bordered `card` and unframed `plain` presentations.
- `density` supports `comfortable` and `compact` spacing.
- `title`, `titleIcon`, and `ariaLabel` are caller-controlled.
- Optional item `meta`, `disabled`, `onSelect`, and top-level `onItemSelect`
  support review demos and product hooks without owning routing.

## Product Boundaries

- Heading extraction, slug generation, IntersectionObserver state, scroll
  offset policy, routing, analytics, localization, CMS content, and link
  persistence stay in the consuming app.
- The component does not fetch article data or mutate browser history.
- Consumers decide whether the nav appears in a sidebar, mobile disclosure, or
  document header.
