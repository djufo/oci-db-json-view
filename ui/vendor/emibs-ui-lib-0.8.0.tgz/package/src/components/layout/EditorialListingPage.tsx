import { type ReactNode } from "react";
import { cn } from "../../lib";

export type EditorialListingCategory = {
  id: string;
  label: ReactNode;
  href?: string;
  active?: boolean;
  count?: ReactNode;
  onClick?: () => void;
};

export type EditorialListingAuthor = {
  name: ReactNode;
  avatar?: ReactNode;
};

export type EditorialListingMetaItem = {
  id: string;
  label: ReactNode;
  icon?: ReactNode;
};

export type EditorialListingArticle = {
  id: string;
  title: ReactNode;
  href: string;
  excerpt?: ReactNode;
  subtitle?: ReactNode;
  category?: ReactNode;
  imageSrc?: string;
  imageAlt?: string;
  fallback?: ReactNode;
  author?: EditorialListingAuthor;
  meta?: EditorialListingMetaItem[];
  actionLabel?: ReactNode;
};

export type EditorialListingNewsletter = {
  icon?: ReactNode;
  title: ReactNode;
  description?: ReactNode;
  form?: ReactNode;
  success?: ReactNode;
  footer?: ReactNode;
};

export type EditorialListingPageProps = {
  eyebrow?: ReactNode;
  title: ReactNode;
  subtitle?: ReactNode;
  categories?: EditorialListingCategory[];
  categoryLabel?: string;
  featured?: EditorialListingArticle;
  featuredLabel?: ReactNode;
  articles?: EditorialListingArticle[];
  articlesTitle?: ReactNode;
  emptyState?: ReactNode;
  newsletter?: EditorialListingNewsletter;
  className?: string;
};

export function EditorialListingPage({
  eyebrow,
  title,
  subtitle,
  categories = [],
  categoryLabel = "Article categories",
  featured,
  featuredLabel = "Featured",
  articles = [],
  articlesTitle,
  emptyState = "No articles in this category yet.",
  newsletter,
  className,
}: EditorialListingPageProps) {
  return (
    <section className={cn("ui-editorial-listing", className)}>
      <header className="ui-editorial-listing__hero">
        {eyebrow ? <span className="ui-editorial-listing__eyebrow">{eyebrow}</span> : null}
        <h1>{title}</h1>
        {subtitle ? <p>{subtitle}</p> : null}
      </header>

      {categories.length > 0 ? (
        <nav className="ui-editorial-listing__categories" aria-label={categoryLabel}>
          {categories.map((category) => (
            <EditorialListingCategoryControl category={category} key={category.id} />
          ))}
        </nav>
      ) : null}

      {featured ? (
        <section className="ui-editorial-listing__featured-section" aria-label="Featured article">
          <EditorialListingFeaturedCard article={featured} label={featuredLabel} />
        </section>
      ) : null}

      <section className="ui-editorial-listing__articles" aria-label={articlesTitle ? undefined : "Articles"}>
        {articlesTitle ? <h2>{articlesTitle}</h2> : null}
        {articles.length > 0 ? (
          <div className="ui-editorial-listing__grid">
            {articles.map((article) => (
              <EditorialListingCard article={article} key={article.id} />
            ))}
          </div>
        ) : (
          <div className="ui-editorial-listing__empty">{emptyState}</div>
        )}
      </section>

      {newsletter ? <EditorialListingNewsletterPanel newsletter={newsletter} /> : null}
    </section>
  );
}

function EditorialListingCategoryControl({ category }: { category: EditorialListingCategory }) {
  const content = (
    <>
      <span>{category.label}</span>
      {category.count ? <small>{category.count}</small> : null}
    </>
  );

  if (category.href) {
    return (
      <a
        className={cn("ui-editorial-listing__category", category.active && "is-active")}
        href={category.href}
        aria-current={category.active ? "page" : undefined}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      className={cn("ui-editorial-listing__category", category.active && "is-active")}
      type="button"
      aria-pressed={category.active}
      onClick={category.onClick}
    >
      {content}
    </button>
  );
}

function EditorialListingFeaturedCard({ article, label }: { article: EditorialListingArticle; label: ReactNode }) {
  return (
    <a className="ui-editorial-listing__featured" href={article.href}>
      <EditorialListingMedia article={article} featured />
      <div className="ui-editorial-listing__featured-body">
        <div className="ui-editorial-listing__featured-kicker">
          <span>{label}</span>
          {article.category ? <EditorialListingCategoryBadge>{article.category}</EditorialListingCategoryBadge> : null}
        </div>
        <h2>{article.title}</h2>
        {article.subtitle ? <p className="ui-editorial-listing__featured-subtitle">{article.subtitle}</p> : null}
        {article.excerpt ? <p className="ui-editorial-listing__featured-excerpt">{article.excerpt}</p> : null}
        <EditorialListingArticleMeta article={article} />
        <span className="ui-editorial-listing__read-more">{article.actionLabel ?? "Read article"}</span>
      </div>
    </a>
  );
}

function EditorialListingCard({ article }: { article: EditorialListingArticle }) {
  return (
    <a className="ui-editorial-listing__card" href={article.href}>
      <EditorialListingMedia article={article} />
      <div className="ui-editorial-listing__card-body">
        {article.category ? <EditorialListingCategoryBadge>{article.category}</EditorialListingCategoryBadge> : null}
        <h3>{article.title}</h3>
        {article.excerpt ? <p>{article.excerpt}</p> : null}
        <EditorialListingArticleMeta article={article} />
        <span className="ui-editorial-listing__read-more">{article.actionLabel ?? "Read more"}</span>
      </div>
    </a>
  );
}

function EditorialListingMedia({ article, featured = false }: { article: EditorialListingArticle; featured?: boolean }) {
  return (
    <div className={cn("ui-editorial-listing__media", featured && "ui-editorial-listing__media--featured")}>
      {article.imageSrc ? (
        <img src={article.imageSrc} alt={article.imageAlt ?? ""} />
      ) : (
        <div className="ui-editorial-listing__media-fallback" aria-hidden="true">
          {article.fallback ?? article.title}
        </div>
      )}
    </div>
  );
}

function EditorialListingCategoryBadge({ children }: { children: ReactNode }) {
  return <span className="ui-editorial-listing__badge">{children}</span>;
}

function EditorialListingArticleMeta({ article }: { article: EditorialListingArticle }) {
  const hasMeta = article.author || (article.meta && article.meta.length > 0);

  if (!hasMeta) return null;

  return (
    <div className="ui-editorial-listing__meta">
      {article.author ? (
        <span className="ui-editorial-listing__author">
          {article.author.avatar ? <span className="ui-editorial-listing__avatar">{article.author.avatar}</span> : null}
          <span>{article.author.name}</span>
        </span>
      ) : null}
      {article.meta?.map((item) => (
        <span className="ui-editorial-listing__meta-item" key={item.id}>
          {item.icon}
          {item.label}
        </span>
      ))}
    </div>
  );
}

function EditorialListingNewsletterPanel({ newsletter }: { newsletter: EditorialListingNewsletter }) {
  return (
    <section className="ui-editorial-listing__newsletter" aria-label="Newsletter">
      {newsletter.icon ? <span className="ui-editorial-listing__newsletter-icon">{newsletter.icon}</span> : null}
      <div className="ui-editorial-listing__newsletter-copy">
        <h2>{newsletter.title}</h2>
        {newsletter.description ? <p>{newsletter.description}</p> : null}
      </div>
      {newsletter.success ? <div className="ui-editorial-listing__newsletter-success">{newsletter.success}</div> : null}
      {newsletter.form ? <div className="ui-editorial-listing__newsletter-form">{newsletter.form}</div> : null}
      {newsletter.footer ? <div className="ui-editorial-listing__newsletter-footer">{newsletter.footer}</div> : null}
    </section>
  );
}
