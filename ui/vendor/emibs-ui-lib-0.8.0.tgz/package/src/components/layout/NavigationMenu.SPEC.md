# NavigationMenu

## Purpose

`NavigationMenu` is a presentational grouped/list navigation surface extracted
from eLitua's menu list, group, item, sidebar, header, and mobile menu patterns.
It renders controlled navigation items for sidebars, header rows, mobile sheets,
and compact icon-heavy action menus without owning route state.

## Contract

- Accepts `items` for flat menus and `groups` for titled grouped menus.
- Supports vertical, horizontal, and grid layouts plus compact/comfortable
  density.
- Renders anchors when `href` is supplied and buttons otherwise.
- Exposes active, disabled, external, danger-tone, icon, description, meta, and
  badge affordances.
- Calls item-local `onSelect` and optional top-level `onItemSelect`.
- Does not fetch data, translate labels, filter by role, resolve icon names, or
  integrate with a router.

## Product Ownership

Consumers own menu registries, route adapters, localization, role filtering,
active-route derivation, analytics, close-on-navigation behavior, and any theme
or account controls placed near the menu.
