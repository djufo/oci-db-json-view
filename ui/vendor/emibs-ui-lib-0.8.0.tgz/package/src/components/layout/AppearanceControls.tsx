import { Palette, Rows3, Rows4 } from "lucide-react";
import { useId } from "react";
import { cn } from "../../lib/cn";
import type { Appearance, AppearanceMode } from "../../theme/appearance";
import { SelectControl } from "../primitives/SelectControl";
import { ThemeModeToggle } from "../primitives/ThemeModeToggle";
import { useAppFrame } from "./AppFrame";
import "./pageTemplates.css";

export type AppearanceControlsProps = {
  /**
   * The appearance to edit. Defaults to the enclosing <AppFrame>; pass one
   * explicitly to drive the controls from a `useAppearance()` call of your own.
   */
  appearance?: Appearance;
  /** Offer "system" as a third mode after light and dark. */
  allowSystem?: boolean;
  /** Show the comfortable/compact switch. */
  showDensity?: boolean;
  /** Accessible name for the group. */
  label?: string;
  className?: string;
};

function nextMode(mode: AppearanceMode, allowSystem: boolean): AppearanceMode {
  if (mode === "light") return "dark";
  if (mode === "dark") return allowSystem ? "system" : "light";
  return "light";
}

/**
 * The theme picker, mode switch and optional density switch for an app's
 * chrome. The family picker disappears when the app offers a single family, so
 * a fixed-brand app shows only the mode switch.
 *
 * Renders nothing when there is no appearance to edit.
 */
export function AppearanceControls({
  appearance: appearanceProp,
  allowSystem = true,
  showDensity = false,
  label = "Appearance",
  className,
}: AppearanceControlsProps) {
  const framed = useAppFrame();
  const appearance = appearanceProp ?? framed;
  const selectId = useId();
  if (!appearance) return null;

  const { families, family, mode, density, setFamilyId, setMode, setDensity } = appearance;
  const upcoming = nextMode(mode, allowSystem);
  const compact = density === "compact";

  return (
    <div className={cn("ui-appearance-controls", className)} role="group" aria-label={label}>
      {families.length > 1 ? (
        <SelectControl
          density="compact"
          hideLabel
          icon={<Palette size={16} aria-hidden="true" />}
          id={selectId}
          label="Theme"
          onValueChange={setFamilyId}
          options={families.map((candidate) => ({ value: candidate.id, label: candidate.label }))}
          value={family.id}
        />
      ) : null}
      <ThemeModeToggle
        density="compact"
        mode={mode}
        nextMode={upcoming}
        onModeChange={setMode}
        showLabel
        variant="ghost"
      />
      {showDensity ? (
        <button
          aria-label={compact ? "Density: compact. Switch to comfortable" : "Density: comfortable. Switch to compact"}
          aria-pressed={compact}
          className="ui-appearance-controls__density"
          onClick={() => setDensity(compact ? "comfortable" : "compact")}
          title={compact ? "Switch to comfortable density" : "Switch to compact density"}
          type="button"
        >
          {compact ? <Rows4 size={16} aria-hidden="true" /> : <Rows3 size={16} aria-hidden="true" />}
          <span>{compact ? "Compact" : "Comfortable"}</span>
        </button>
      ) : null}
    </div>
  );
}
