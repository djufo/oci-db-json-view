# AppearanceControls

## Purpose

The theme picker, mode switch and optional density switch for an app's chrome.
One implementation of a control every operator app had re-written.

## Contract

- Edits the appearance of the enclosing `AppFrame`, or the `appearance` prop
  when one is passed (for an app that calls `useAppearance()` itself).
- Renders nothing when there is neither a prop nor an enclosing frame.
- The theme picker is a `SelectControl` listing the offered families. It is not
  rendered when only one family is offered.
- The mode switch is a `ThemeModeToggle` that shows the current mode and moves
  light → dark → system → light. With `allowSystem={false}` it moves light →
  dark → light. Its accessible name states the mode it will switch to.
- `showDensity` adds a button that toggles comfortable/compact. Its accessible
  name states the current density and the one it will switch to, and
  `aria-pressed` is true while compact.
- The group has `role="group"` and an accessible name (`label`, default
  "Appearance").

## Consumer boundary

Placement is the consumer's: a shell's `actions` slot, a sign-in page's
`corner`. Persistence belongs to the frame, not to this component.
