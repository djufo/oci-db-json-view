# LegalDocumentPage Spec

## Goal

Provide a presentational legal and policy document shell for public product
pages before consuming apps adopt it.

## Source Pressure

- eLitua's privacy and terms routes share a stable legal document layout:
  constrained readable width, legal eyebrow, document title, updated metadata,
  authority/summary box, numbered clause headings, nested paragraphs and lists,
  inline links, and a closing contact/related-document callout.
- The shell is distinct from `EditorialArticlePage`: it optimizes for policy
  readability, revision metadata, legal callouts, and cross-document contact
  actions instead of author metadata, images, table of contents, tags, sharing,
  paywalls, or related story cards.

## Contract

- `LegalDocumentPage` renders supplied title, metadata, optional summary
  callout, structured legal blocks, optional custom content, and a closing
  contact block.
- Body blocks are structured data. Supported block types are h2, h3, paragraph,
  unordered list, ordered list, and callout.
- Consuming apps own legal copy, routing, links, translations, consent capture,
  version history, print/export behavior, analytics, and acceptance workflows.
- Styling uses catalog tokens and avoids project-specific class names.

## Non-Goals

- No legal text generator, markdown parser, CMS adapter, route lookup, locale
  loader, acceptance checkbox, cookie consent state, or version diffing.
- No product-specific controller, company identity, or regulatory rule
  enforcement.

## Review Expectations

- Long clause headings, list items, metadata, links, and contact actions must
  wrap without overlapping at catalog desktop and mobile widths.
- The summary and contact callouts must remain visually distinct from the legal
  body without depending on eLitua theme variables.
