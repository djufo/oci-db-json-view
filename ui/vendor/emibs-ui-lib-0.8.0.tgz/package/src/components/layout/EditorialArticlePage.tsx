import { type ReactNode } from "react";
import { cn } from "../../lib";
import { TableOfContentsNav, type TableOfContentsNavItem } from "./TableOfContentsNav";

export type EditorialArticleAuthor = {
  name: ReactNode;
  role?: ReactNode;
  avatar?: ReactNode;
  bio?: ReactNode;
};

export type EditorialArticleMetaItem = {
  id: string;
  label: ReactNode;
  icon?: ReactNode;
};

export type EditorialArticleHero = {
  src?: string;
  alt?: string;
  fallback?: ReactNode;
};

export type EditorialArticleTocEntry = TableOfContentsNavItem;

export type EditorialArticleSection =
  | { id: string; type: "h2" | "h3"; text: ReactNode }
  | { id: string; type: "p"; text: ReactNode }
  | { id: string; type: "ul"; items: ReactNode[] }
  | { id: string; type: "quote"; text: ReactNode; attribution?: ReactNode }
  | { id: string; type: "image"; src?: string; alt?: string; caption?: ReactNode; fallback?: ReactNode }
  | { id: string; type: "cta"; title: ReactNode; description?: ReactNode; href: string; label: ReactNode; icon?: ReactNode };

export type EditorialArticleShareAction = {
  id: string;
  label: ReactNode;
  href?: string;
  icon?: ReactNode;
  external?: boolean;
  onClick?: () => void;
};

export type EditorialArticleRelatedItem = {
  id: string;
  title: ReactNode;
  href: string;
  category?: ReactNode;
  meta?: ReactNode;
  imageSrc?: string;
  imageAlt?: string;
  fallback?: ReactNode;
};

export type EditorialArticlePaywall = {
  title: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
};

export type EditorialArticlePageProps = {
  backHref?: string;
  backLabel?: ReactNode;
  category?: ReactNode;
  title: ReactNode;
  subtitle?: ReactNode;
  author?: EditorialArticleAuthor;
  meta?: EditorialArticleMetaItem[];
  hero?: EditorialArticleHero;
  toc?: EditorialArticleTocEntry[];
  activeTocId?: string;
  sections?: EditorialArticleSection[];
  tags?: ReactNode[];
  shareLabel?: ReactNode;
  shareActions?: EditorialArticleShareAction[];
  paywall?: EditorialArticlePaywall;
  relatedTitle?: ReactNode;
  related?: EditorialArticleRelatedItem[];
  className?: string;
};

export function EditorialArticlePage({
  backHref,
  backLabel,
  category,
  title,
  subtitle,
  author,
  meta = [],
  hero,
  toc = [],
  activeTocId,
  sections = [],
  tags = [],
  shareLabel = "Share",
  shareActions = [],
  paywall,
  relatedTitle = "Related articles",
  related = [],
  className,
}: EditorialArticlePageProps) {
  const hasToc = toc.length > 0;

  return (
    <article className={cn("ui-editorial-article", className)}>
      {hasToc ? (
        <div className="ui-editorial-article__mobile-toc">
          <TableOfContentsNav
            className="ui-editorial-article__toc"
            items={toc}
            activeItemId={activeTocId}
          />
        </div>
      ) : null}

      <header className="ui-editorial-article__header">
        {backHref || backLabel ? (
          <a className="ui-editorial-article__back" href={backHref ?? "#"}>
            {backLabel}
          </a>
        ) : null}
        {category ? <span className="ui-editorial-article__category">{category}</span> : null}
        <h1>{title}</h1>
        {subtitle ? <p className="ui-editorial-article__subtitle">{subtitle}</p> : null}
        {author || meta.length > 0 ? (
          <div className="ui-editorial-article__meta-row">
            {author ? <EditorialArticleAuthorView author={author} /> : null}
            {meta.length > 0 ? (
              <div className="ui-editorial-article__meta-items">
                {meta.map((item) => (
                  <span className="ui-editorial-article__meta-item" key={item.id}>
                    {item.icon}
                    {item.label}
                  </span>
                ))}
              </div>
            ) : null}
          </div>
        ) : null}
      </header>

      {hero ? <EditorialArticleHeroView hero={hero} title={title} /> : null}

      <div className={cn("ui-editorial-article__layout", !hasToc && "has-no-toc")}>
        <div className="ui-editorial-article__content">
          <EditorialArticleBody sections={sections} />
          {paywall ? <EditorialArticlePaywallView paywall={paywall} /> : null}
          {tags.length > 0 ? (
            <div className="ui-editorial-article__tags" aria-label="Article tags">
              {tags.map((tag, index) => (
                <span key={index}>{tag}</span>
              ))}
            </div>
          ) : null}
          {shareActions.length > 0 ? (
            <EditorialArticleShare label={shareLabel} actions={shareActions} />
          ) : null}
          {author?.bio ? <EditorialArticleAuthorBio author={author} /> : null}
        </div>

        {hasToc ? (
          <aside className="ui-editorial-article__sidebar">
            <div className="ui-editorial-article__sticky">
              <TableOfContentsNav
                className="ui-editorial-article__toc"
                items={toc}
                activeItemId={activeTocId}
              />
            </div>
          </aside>
        ) : null}
      </div>

      {related.length > 0 ? (
        <section className="ui-editorial-article__related">
          <h2>{relatedTitle}</h2>
          <div className="ui-editorial-article__related-grid">
            {related.map((item) => (
              <EditorialArticleRelatedCard item={item} key={item.id} />
            ))}
          </div>
        </section>
      ) : null}
    </article>
  );
}

function EditorialArticleAuthorView({ author }: { author: EditorialArticleAuthor }) {
  return (
    <div className="ui-editorial-article__author">
      {author.avatar ? <span className="ui-editorial-article__avatar">{author.avatar}</span> : null}
      <span>
        <strong>{author.name}</strong>
        {author.role ? <small>{author.role}</small> : null}
      </span>
    </div>
  );
}

function EditorialArticleHeroView({ hero, title }: { hero: EditorialArticleHero; title: ReactNode }) {
  return (
    <div className="ui-editorial-article__hero">
      {hero.src ? (
        <img src={hero.src} alt={hero.alt ?? ""} />
      ) : (
        <div className="ui-editorial-article__hero-fallback" aria-hidden="true">
          {hero.fallback ?? title}
        </div>
      )}
    </div>
  );
}

function EditorialArticleBody({ sections }: { sections: EditorialArticleSection[] }) {
  return (
    <div className="ui-editorial-article__body">
      {sections.map((section) => {
        switch (section.type) {
          case "h2":
            return <h2 key={section.id} id={section.id}>{section.text}</h2>;
          case "h3":
            return <h3 key={section.id} id={section.id}>{section.text}</h3>;
          case "p":
            return <p key={section.id}>{section.text}</p>;
          case "ul":
            return (
              <ul key={section.id}>
                {section.items.map((item, index) => (
                  <li key={index}>{item}</li>
                ))}
              </ul>
            );
          case "quote":
            return (
              <blockquote key={section.id}>
                <p>{section.text}</p>
                {section.attribution ? <cite>{section.attribution}</cite> : null}
              </blockquote>
            );
          case "image":
            return (
              <figure key={section.id}>
                {section.src ? (
                  <img src={section.src} alt={section.alt ?? ""} />
                ) : (
                  <div className="ui-editorial-article__image-fallback" aria-hidden="true">
                    {section.fallback}
                  </div>
                )}
                {section.caption ? <figcaption>{section.caption}</figcaption> : null}
              </figure>
            );
          case "cta":
            return (
              <div className="ui-editorial-article__cta" key={section.id}>
                <span>
                  <strong>{section.title}</strong>
                  {section.description ? <small>{section.description}</small> : null}
                </span>
                <a href={section.href}>
                  {section.label}
                  {section.icon}
                </a>
              </div>
            );
        }
      })}
    </div>
  );
}

function EditorialArticlePaywallView({ paywall }: { paywall: EditorialArticlePaywall }) {
  return (
    <div className="ui-editorial-article__paywall">
      <h2>{paywall.title}</h2>
      {paywall.description ? <p>{paywall.description}</p> : null}
      {paywall.action ? <div>{paywall.action}</div> : null}
    </div>
  );
}

function EditorialArticleShare({
  label,
  actions,
}: {
  label: ReactNode;
  actions: EditorialArticleShareAction[];
}) {
  return (
    <div className="ui-editorial-article__share">
      <span>{label}</span>
      {actions.map((action) => {
        const content = (
          <>
            {action.icon}
            {action.label}
          </>
        );
        if (action.href) {
          return (
            <a
              key={action.id}
              href={action.href}
              target={action.external ? "_blank" : undefined}
              rel={action.external ? "noreferrer" : undefined}
            >
              {content}
            </a>
          );
        }
        return (
          <button type="button" key={action.id} onClick={action.onClick}>
            {content}
          </button>
        );
      })}
    </div>
  );
}

function EditorialArticleAuthorBio({ author }: { author: EditorialArticleAuthor }) {
  return (
    <section className="ui-editorial-article__bio">
      {author.avatar ? <span className="ui-editorial-article__bio-avatar">{author.avatar}</span> : null}
      <div>
        <h2>{author.name}</h2>
        {author.role ? <p className="ui-editorial-article__bio-role">{author.role}</p> : null}
        <p>{author.bio}</p>
      </div>
    </section>
  );
}

function EditorialArticleRelatedCard({ item }: { item: EditorialArticleRelatedItem }) {
  return (
    <a className="ui-editorial-article__related-card" href={item.href}>
      <span className="ui-editorial-article__related-media">
        {item.imageSrc ? <img src={item.imageSrc} alt={item.imageAlt ?? ""} /> : item.fallback}
      </span>
      <span className="ui-editorial-article__related-body">
        {item.category ? <small>{item.category}</small> : null}
        <strong>{item.title}</strong>
        {item.meta ? <span>{item.meta}</span> : null}
      </span>
    </a>
  );
}
