# PortalShell

## Purpose

Reusable public portal page shell extracted from eLitua's app-level layout:
header slot, centered or full-width body, controlled full-menu sidebar, desktop
footer slot, and mobile navigation slot.

## Contract

- `PortalShell` is presentational and does not own routing, auth, translation,
  menu registry, theme state, or mobile-sheet state.
- Header, footer, mobile navigation, sidebar body, and sidebar footer are slots
  so consuming apps can keep product-specific chrome and route adapters local.
- Sidebar open state is controlled through `sidebarOpen` and
  `onSidebarOpenChange`; menu toggles can live in the supplied header slot.
- `layout="centered"` matches public content pages; `layout="full"` allows
  map/explorer pages to occupy the available width.

## Source

- `/engineering/projects/elitua/ui/src/components/layout/Layout/Layout.tsx`
- `/engineering/projects/elitua/ui/src/components/layout/Layout/Layout.module.scss`
- `/engineering/projects/elitua/ui/src/components/layout/Sidebar/Sidebar.tsx`
- `/engineering/projects/elitua/ui/src/components/layout/Sidebar/Sidebar.module.scss`
