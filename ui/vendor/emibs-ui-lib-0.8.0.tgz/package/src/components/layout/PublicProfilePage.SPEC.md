# PublicProfilePage Spec

## Goal

Provide a presentational public profile shell for people, providers, guides, and
marketplace participants before product apps adopt it.

## Source Pressure

- eLitua's public guide profile route renders a reusable profile structure:
  identity hero, avatar, verification/license badges, contact actions, language
  tags, covered routes, and credential details.
- eLitua account guide/accommodation profile pages repeat related provider
  information architecture, but they own editing and persistence. The shared
  public shell should stay read-only and route-neutral.

## Contract

- `PublicProfilePage` renders identity, badges, contact actions, primary/secondary
  actions, profile stats, information panels, optional aside content, and footer
  slots from props.
- Actions can render as anchors or buttons. Navigating actions require concrete
  `href` values so consuming apps keep URL ownership.
- Panels accept tags, detail rows, freeform children, and panel actions for
  provider-specific sections such as languages, coverage, credentials, or
  availability.

## Non-Goals

- No profile lookup, route parsing, booking flow, authentication, verification,
  formatting, translation, editing, or persistence behavior.
- No product-owned taxonomy for guide credentials, routes, languages, or booking
  status.

## Review Expectations

- Identity, badges, contact actions, stats, panels, and aside content must wrap
  cleanly on mobile without overlapping.
- Long profile names, route names, contact labels, and credential values must
  stay readable in constrained catalog and product layouts.
