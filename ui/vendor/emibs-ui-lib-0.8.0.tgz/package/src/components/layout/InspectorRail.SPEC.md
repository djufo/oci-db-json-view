# InspectorRail

## Purpose

`InspectorRail` is the one shared right-rail inspector for a single target
entity: a slot-based, tabbed panel (Overview / Edit / Audit or any tab set) that
every surface reuses instead of hand-rolling its own detail drawer. It is the
generalization of Score's v4 G2 inspector.

## Source Evidence

- Score `requirements/v4/ui` (SPEC G2) makes one right-rail component, shared by
  board / fleet / admin, with a URL-owned target (`?inspect=<id>&itab=<tab>`) so
  the underlying list never loses scroll or selection on inspect or refetch.
- Score's v4 `InspectorRail.tsx` computes tab/close hrefs from the hash via an
  `inspectorRoute` helper. This library version keeps the same behavior but is
  routing-agnostic: the app owns the URL and passes hrefs / change callbacks in.

## Contract

- `targetId`, `eyebrow`, `title` render the identity header; `actions` is a
  header slot and a close control sits at the far right.
- `tabs` is a slot array (`{ id, label, content, disabled?, emptyLabel? }`);
  `activeTab` selects which slot renders. A tab with no `content` shows its
  `emptyLabel`.
- URL ownership is a CONTRACT, not an assumption: pass `tabHref(id)` and
  `closeHref` to render real anchors (copyable links, back/forward navigation),
  or omit them and handle `onTabChange(id)` / `onClose` as callbacks. The
  component never reads or writes the URL itself.
- Tab chrome, roving-tabindex keyboard support (arrow / home / end) and density
  come from the shared `ContentTabs` primitive — no second tab implementation.
- `density` (or an ambient `DensityScope`) tightens header padding, control
  height, and panel spacing through the `--density-*` aliases.

## Boundaries

- No data fetching, field editing, hash parsing, or write semantics: it renders
  the slots it is handed. Edit forms, audit timelines and blast-radius confirms
  are composed INTO the tab slots by the app.
- Not a modal or drawer; it is an inline rail. Use `Drawer`/`Dialog` for overlay
  surfaces.

## Review Checks

- Switching tabs via `tabHref` produces anchors whose `href` preserves the
  surrounding query (target + list filters) — the app is responsible for that.
- Close renders an anchor when `closeHref` is set, otherwise a button.
- Only the active tab's content is in the DOM; empty tabs show the note.
