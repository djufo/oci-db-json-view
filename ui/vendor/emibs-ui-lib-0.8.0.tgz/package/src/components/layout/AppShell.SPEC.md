# AppShell

## Purpose

`AppShell` is the outermost two-column application frame: a sticky full-height
left rail carrying a brand slot and a vertical link nav, and a main column with
a right-aligned action bar above the page body. The catalog's own live surface
(`src/explorer/CatalogExplorer.tsx`) carries bespoke explorer chrome rather than
this shell, so `AppShell` is exercised here through its catalog demo, variant
and state previews. It is published so a product can adopt the same frame
without re-deriving the rail geometry and nav item chrome.

It is deliberately the thinnest of the shells in this library. `WorkspaceShell`
is the operational shell with topbar identity and route-backed view tabs;
`PortalShell` is the public-site frame. `AppShell` is just rail + main.

## Public contract

```tsx
type NavItem = {
  label: string;
  href: string;
  icon?: ReactNode;
  active?: boolean;
};
```

| Prop | Type | Required | Meaning |
| --- | --- | --- | --- |
| `brand` | `ReactNode` | yes | Free slot at the top of the rail (the catalog passes a logo anchor) |
| `nav` | `NavItem[]` | yes | Rail links, rendered in array order |
| `actions` | `ReactNode` | no | Right-aligned content in the top bar of the main column |
| `children` | `ReactNode` | yes | Page body, below the action bar |

`NavItem` is exported alongside the component. Each item renders a real
`<a href>` keyed by `item.href`, with `item.icon` (if any) before a `<span>`
holding `item.label`, and the class `ui-shell__nav-item` plus `is-active` when
`item.active` is true.

DOM shape:

```
div.ui-shell
  aside.ui-shell__side
    div.ui-shell__brand           → brand
    nav.ui-shell__nav             → one <a> per NavItem
  main.ui-shell__main
    div.ui-shell__bar             → actions
    children
```

There is no `className` prop, no `...rest` spread, no ref forwarding, and no
state: `AppShell` is a pure function of its props.

## Variants and states matrix

| State | Trigger | Result |
| --- | --- | --- |
| Default | any `nav` | Sticky 260px rail beside a fluid main column |
| Active item | `item.active` | `is-active` styling — white text on a translucent white wash |
| Icon item | `item.icon` | Glyph rendered before the label inside the anchor |
| No actions | `actions` omitted | `div.ui-shell__bar` still renders, keeping its 44px min-height and 18px bottom margin |
| ≤960px | viewport | Grid collapses to one column; the rail becomes static and auto-height; nav becomes a 2-column grid |
| ≤560px | viewport | Main inline padding drops to 12px; the action bar wraps and left-aligns; nav becomes 1 column |

There are no tones, sizes, or density variants.

## Accessibility

- The three landmarks come from real elements: `<aside>` (complementary),
  `<nav>`, and `<main>`. The nav carries `aria-label="Catalog sections"`.
- Nav entries are genuine anchors with an `href`, so they get native focus
  order, Enter activation, middle-click, and copyable links for free. Keyboard
  navigation is the browser's, not a custom roving-tabindex implementation.
- The `brand` and `actions` slots are rendered verbatim; their semantics and
  labelling belong to whatever the consumer passes in.
- Consumer-supplied `icon` nodes are **not** hidden from assistive technology by
  this component. Pass `aria-hidden="true"` on decorative glyphs; the label
  string is the accessible name.

Two gaps are real and worth stating plainly:

- **`active` is visual only.** The component sets a CSS class and never sets
  `aria-current="page"` (or any other `aria-current` value), so a screen-reader
  user gets no signal about which section they are in. A consumer cannot fix
  this from the outside — `NavItem` has no pass-through for extra anchor
  attributes.
- **The nav label is hardcoded** to "Catalog sections". A product adopting
  `AppShell` inherits catalog wording it cannot override.

## Theming

- `.ui-shell` — `min-height: 100vh`, grid `260px minmax(0, 1fr)`.
- `.ui-shell__side` — `position: sticky; top: 0; height: 100vh`, background
  `var(--surface-strong)`; the text colour (`#f8fafc`), nav item colour
  (`#cbd5e1`), and hover/active treatment (`rgb(255 255 255 / 0.09)`,
  `#ffffff`) are **hardcoded hex/rgb literals, not tokens**.
- `.ui-shell__main` — `padding: 18px clamp(16px, 3vw, 32px) 42px`.
- `.ui-shell__bar` — flex row, right-aligned, 8px gap, 44px min-height.

`--surface-strong` is the only theme custom property the shell consumes. The
practical consequence is that **the rail is a fixed dark surface**: swapping the
theme or moving to a light/dark variant re-tints its background but leaves its
foreground colours unchanged. `AppShell` reads no `--density-*` alias and does
not participate in `DensityScope`.

## Consumer / product boundary

`AppShell` owns the frame — rail geometry, nav item chrome, action-bar
alignment, and the responsive collapse. The consuming app owns:

- **Routing.** The shell never reads or writes the URL. `href` values are
  supplied whole, and `active` must be computed by the app from its own router
  or hash state.
- The nav model itself: which sections exist, their order, labels, icons, and
  any permission-based filtering.
- Everything in `brand`, `actions`, and `children` — identity, auth state,
  refresh/deploy controls, toasts, page content.
- Data fetching, persistence, and scroll restoration.

## Known limitations

- The shell assumes it owns the viewport (`min-height: 100vh` plus a `100vh`
  sticky rail). Embedding it in a smaller region requires the parent to bound
  and scroll it — the catalog's own registry demo wraps it in a
  `maxHeight: 520; overflow: auto` box for exactly this reason.
- Nav items are keyed by `href`; two items sharing an href collide.
- There is no collapsed/mini-rail mode, no nav grouping or section headings, and
  no overflow handling — a long nav simply makes the sticky rail taller than the
  viewport, and below 960px the rail scrolls with the page.
- No slot exists for rail footer content (version, account) below the nav.
