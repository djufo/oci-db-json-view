# StatusStrip

## Purpose

`StatusStrip` is a compact operational summary row for route headers, app
shells, and dashboard top bars that need short state badges and dense metric
tiles without owning product data.

## Source Evidence

- Score `ui/src/features/live-activity/components/StatusStrip.tsx` renders
  manual refresh state, ready/review queue counts, scheduler ticks, and worker
  errors in the authenticated app shell.
- Score `ui/src/features/live-activity/components/ActivityDashboardView.tsx`
  uses the same queue and scheduler metrics in a larger dashboard; this
  component keeps the lightweight shell/header form separate from the full
  dashboard.
- eLitua explorer and account pages already use larger metric and state panels,
  so this extraction stays focused on the compact status-strip shape.

## Contract

- Accepts controlled `items` with stable label, optional id, value, detail,
  icon, tone, and `metric` or `badge` variants.
- Metric items render as compact cards for numeric or short text values.
- Badge items render with shared `Badge` styling for short mode/state labels
  such as manual refresh, live, syncing, or paused.
- `ariaLabel` names the strip when surrounding copy does not.
- Styling uses shared catalog tokens and fixed responsive grid behavior.

## v2: live signal + freshness (UIF-E3)

- Adds a third item `variant: "signal"` for live health signals in the command
  bar / shell top row (Score v4 SPEC V4-1 status strip). A signal item renders a
  leading state dot + label/value.
- `signal` (`ok`/`warn`/`critical`/`unknown`) colours the dot through the
  emibs-theme/2 `--capacity-*` tokens; `unknown` is the neutral striped dot and
  never reads as healthy (mirrors the CapacityMeter rule).
- `freshness` (`fresh`/`stale`/`offline`) colours the dot through the
  `--freshness-*` tokens and wins over `signal` for the dot colour (a stale
  heartbeat is a freshness fact first).
- `signalLabel` supplies the visually-hidden state description; it defaults to
  the state name.
- Fully back-compatible: `metric` and `badge` items are unchanged, and the new
  fields are optional.

## Boundaries

- No polling, refresh command, queue calculation, scheduling semantics, routing,
  toast behavior, localization, or date/number formatting.
- Signals render the state they are handed; computing tick age, capacity %, or
  freshness from live data stays in the consuming app.
- No replacement for `ActivityDashboard`, `MetricGrid`, or `StatusIndicator`;
  use those for richer panels, repeated metric grids, or single state rows.

## Review Checks

- Badge and metric variants can be mixed without changing layout height
  unpredictably.
- Long labels and details wrap within tiles on mobile.
- Icons remain decorative unless consumers include accessible text in labels.
