# PortalHeader

## Purpose

Reusable public portal header extracted from eLitua's global chrome: brand,
primary navigation, prominent search, compact social/action controls, identity
slot, and mobile menu toggle.

## Contract

- `PortalHeader` is presentational and does not own routing, auth, search
  execution, translations, or menu state.
- Navigation and action links require concrete `href` values when they navigate.
  Local callbacks are only for consumer-owned controls such as menu toggles,
  search submit, and utility buttons.
- Search is controlled by props and may be read-only in demos. Product search
  indexing, image search, and query persistence stay in the consuming app.
- Brand, identity, icons, locale controls, theme controls, and auth controls are
  slots or action props so product-specific behavior remains outside the shared
  component.

## Source

- `/engineering/projects/elitua/ui/src/components/layout/header/Header/Header.tsx`
- `/engineering/projects/elitua/ui/src/components/layout/header/Header/Header.module.scss`
- `/engineering/projects/elitua/ui/src/features/menu/components/Menu/Menu.tsx`
