# SignInPage

## Purpose

A full-viewport sign-in page: one centred card holding the product mark, a
title, the sign-in form and an optional footer. It replaces the login page and
card styles each app wrote for itself.

## Contract

- Presentational. It renders `children` as the form area and performs no
  sign-in, validation or navigation.
- The page is a `main` landmark. The card is a `section` named by the title
  (`aria-labelledby`).
- `level` sets the title's heading level: `1` (default) when the sign-in page
  is the document, `2` when it is shown inside another page.
- `notice` renders between the copy and the form; the consumer decides its
  content and tone (typically a `NoticeBanner` after a rejected attempt).
- `corner` is positioned at the top right on wide viewports. Below 640px it
  joins the flow above the card, so it cannot overlap the title.
- `brand`, `eyebrow`, `description` and `footer` are optional and leave no
  empty box when omitted.

## Consumer boundary

The consuming app owns the credential fields or provider button, the sign-in
request, error wording, and what happens after success.
