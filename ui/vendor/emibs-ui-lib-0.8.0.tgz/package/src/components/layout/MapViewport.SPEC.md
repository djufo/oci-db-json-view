# MapViewport Spec

## Purpose

`MapViewport` is the presentational chrome for a map area: stable viewport
dimensions, loading and error states, stat overlay, title overlay, optional
action controls, optional selected-record info panel, and a fallback static map
preview for demos.

## Contract

- `MapViewport` does not import Google Maps, route state, translations, map
  services, or product data stores.
- Consuming apps can pass a real map engine through `children`; when omitted,
  the component renders a lightweight static map preview from `markers`.
- Stats, actions, title, loading label, error content, and info panel are all
  prop-driven.
- `titleMode="transient"` may fade the title overlay for eLitua-style map
  introductions. Persistent title is the default.
- Marker coordinates are percentages within the demo viewport and are only for
  review/demo placeholders.

## Source Pattern

- `/engineering/projects/elitua/ui/src/emibs-lib/features/googleMaps/components/MapView.tsx`
- `/engineering/projects/elitua/ui/src/emibs-lib/features/googleMaps/components/MapView.scss`
- `/engineering/projects/elitua/ui/src/emibs-lib/features/googleMaps/components/MapStats.tsx`
- `/engineering/projects/elitua/ui/src/emibs-lib/features/googleMaps/components/MapStats.scss`
- `/engineering/projects/elitua/ui/src/pages/client/places/PlacesPage.tsx`

## Return Path

After review, eLitua can wrap its `@vis.gl/react-google-maps` `Map` with
`MapViewport`, pass `MapStats` values as data props, and keep marker lifecycle,
clusterer management, Google Maps settings, selection dispatch, translations,
and route ownership local.
