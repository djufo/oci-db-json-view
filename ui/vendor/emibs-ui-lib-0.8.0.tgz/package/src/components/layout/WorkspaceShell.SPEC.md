# WorkspaceShell

## Purpose

Reusable operational app shell extracted from Score's authenticated workspace:
topbar identity, compact status/action area, route-backed view tabs, and a main
content slot.

## Contract

- `WorkspaceShell` is presentational and does not own routing, auth, live data,
  or persistence.
- Tabs require concrete `href` values so consuming apps can keep navigation in
  URLs. `onSelect(id, event)` runs on activation; a single-page app calls
  `event.preventDefault()` there and navigates with its own router, and the tab
  stays a real link (open in new tab, copy address) either way. A disabled tab
  does not call it.
- The tab row is a single line that scrolls horizontally when it does not fit,
  at every viewport width. It does not stack into a column on a phone.
- Header status, identity, and actions are slots so product-specific metrics,
  actors, and commands remain in the consuming app.
- `WorkspaceShellPanel` is an optional dense content panel for shell demos and
  simple workspace sections.

## Source

- `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`
- `/engineering/projects/score/specs/refactoring-decisions/0006-shadcn-app-shell-layout.md`
