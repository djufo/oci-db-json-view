# WorkspaceShell

## Purpose

Reusable operational app shell extracted from Score's authenticated workspace:
topbar identity, compact status/action area, route-backed view tabs, and a main
content slot.

## Contract

- `WorkspaceShell` is presentational and does not own routing, auth, live data,
  or persistence.
- Tabs require concrete `href` values so consuming apps can keep navigation in
  URLs. `onSelect(id, event)` runs on activation; a single-page app calls
  `event.preventDefault()` there and navigates with its own router, and the tab
  stays a real link (open in new tab, copy address) either way. A disabled tab
  does not call it.
- The tab row is a single line that scrolls horizontally when it does not fit,
  at every viewport width. It does not stack into a column on a phone.
- `navigation="rail"` lists the sections in a vertical rail on the left instead
  of a tab row, for a console with many sections. A tab with `group: "footer"`
  sits at the bottom of the rail. `railItems="icons"` shows each item as its
  icon only; the label is then the accessible name and the tooltip, so an
  icon-only item needs an `icon`. In rail mode the shell has a fixed height
  (`--ui-workspace-shell-height`, the viewport inside an `AppFrame`) and the
  rail, the content and the inspector scroll independently. Below 760px the rail
  becomes a bottom bar that scrolls sideways.
- `topbar` replaces the default top bar with one the app owns (for example a
  `CommandBar` with its own brand and status strip); `brand`, `subtitle`,
  `status`, `identity` and `actions` are then not rendered.
- `inspector` adds a column beside the content, normally an `InspectorRail`.
  The shell widens for it when present. Below 760px it sits under the content.
- Header status, identity, and actions are slots so product-specific metrics,
  actors, and commands remain in the consuming app.
- `WorkspaceShellPanel` is an optional dense content panel for shell demos and
  simple workspace sections.

## Source

- `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`
- `/engineering/projects/score/specs/refactoring-decisions/0006-shadcn-app-shell-layout.md`
