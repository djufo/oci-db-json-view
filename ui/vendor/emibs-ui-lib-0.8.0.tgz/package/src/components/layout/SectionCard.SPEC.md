# SectionCard

`SectionCard` is the one page-owned, depth-one section surface. It provides a
v4 header, flat body and optional footer using token spacing and no outer margin.
Only page/layout boundaries may import it; shared data, feedback, form and auth
components stay flat.

## Contract

- The page chooses this sole depth-one surface; child components do not add
  another card, padding, border, shadow, or outer margin.
- Header slots are title, optional eyebrow, description, icon, badges, and
  caller-owned actions. Body and footer remain flat slots with parent-owned
  token gaps.
- `collapsible` supports uncontrolled `defaultCollapsed` or controlled
  `collapsed` / `onCollapsedChange`. Its heading stays outside the native
  toggle; the toggle controls one persistent, heading-labelled body region with
  `aria-controls` / `aria-expanded` and names the current state before the next
  action (for example, "Section is collapsed — expand"). Controlled clicks only
  request a state change until the caller rerenders the supplied state.
- `SectionPanel` is a retired E4 migration path and must not be reintroduced.

## Accessibility

Its semantic element is configurable (`section`, `article`, or `aside`) and its
heading names the section. The disclosure toggle is the labelled control when
collapsible; actions remain caller-owned controls.
