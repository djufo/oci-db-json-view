# EditorialListingPage Spec

## Goal

Provide a presentational editorial listing shell for public content hubs before
product apps adopt it.

## Source Pressure

- eLitua's blog listing route uses a repeated content hub structure: centered
  heading, category tabs, featured article, article card grid, empty category
  state, and newsletter call-to-action.
- The listing shell is distinct from `EditorialArticlePage`: this component
  owns the discovery/index surface, while article rendering remains in the
  existing long-form page component.

## Contract

- `EditorialListingPage` renders supplied hero copy, category controls, optional
  featured article, article cards, empty state, and newsletter panel.
- Articles accept preformatted metadata, author display data, images or fallback
  slots, category labels, excerpts, and action labels.
- Category controls are controlled by the consuming app through active flags,
  `href`, or `onClick` props.
- Newsletter submit state and input controls are supplied as slots.

## Non-Goals

- No blog data lookup, CMS adapter, routing framework binding, category
  filtering, newsletter submission, analytics, localization, or date formatting.
- No product-owned taxonomy or subscription rules.

## Review Expectations

- Featured article, category controls, article grid, and newsletter panel must
  remain readable at catalog desktop and mobile widths.
- Long article titles, category names, author labels, and metadata must wrap or
  truncate without overlapping adjacent content.
