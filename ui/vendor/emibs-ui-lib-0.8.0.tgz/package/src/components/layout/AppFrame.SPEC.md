# AppFrame

## Purpose

The root of an app that uses the house style. It replaces the theme wrapper,
density wrapper, appearance state and storage code that each operator app used
to copy from the last one.

## Contract

- `AppFrame` renders a `ThemeScope` containing a `DensityScope` and provides the
  current appearance to everything inside through `useAppFrame()`.
- The appearance is owned by `useAppearance` (`src/theme/appearance.ts`): a
  theme family, a mode (`light`, `dark` or `system`) and a density.
- `families` defaults to `houseAppearanceFamilies` — Score, Neutral, Nord and
  High contrast, in that order. The first family is the default, so an app that
  passes nothing gets the house look. A fixed-brand app passes its own single
  family.
- With `storageKey` set, each choice persists under `<storageKey>:theme-family`,
  `<storageKey>:theme-mode` and `<storageKey>:density`. These are the key names
  the operator apps already used, so adopting the frame keeps a user's choice.
  A stored value that is no longer valid (a family the app stopped offering)
  falls back to the default. Storage that throws is treated as empty.
- `system` follows the OS colour-scheme preference and updates live.
- The frame fills the viewport (`min-height: 100vh`) and paints the page
  background. A `WorkspaceShell` placed directly inside it fills the viewport
  too and drops the border and radius it carries when embedded as a panel.
- Overlays opened inside the frame (`Dialog`, `Drawer`, `Popover` and anything
  else built on `OverlayPortal`) mount in an element inside the frame's theme
  and density scopes, not on `document.body`, so they render in the app's
  theme. An overlay given an explicit `container` still goes where it is told.
- `useAppFrame()` returns `null` outside a frame.

## Consumer boundary

The consuming app owns routing, the shell's content, and where the appearance
controls sit. It supplies no body, root or theme CSS of its own.
