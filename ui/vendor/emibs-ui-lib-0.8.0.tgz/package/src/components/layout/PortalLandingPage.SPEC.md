# PortalLandingPage Spec

## Goal

Provide a reusable public landing page shell for destination, venue, and portal
home pages that need a first-viewport image hero, intent cards, featured content,
planner/CTA rail, and quote/footer-style band without product-specific data or
routing.

## Contract

- `PortalLandingPage` is presentational and accepts all content through props.
- The hero image is required and rendered as the hero surface, with copy and
  stats overlaid through controlled slots.
- Navigation uses anchors supplied by the consuming app. React Router, analytics,
  AI planning execution, translation, and content fetching stay outside the
  component.
- Intent cards and feature cards are data-driven; icons and actions are passed as
  `ReactNode` slots.
- The component must collapse from desktop feature grids to a single-column
  mobile layout without text overlap.

## Source Pattern

Adapted from eLitua's home page structure: large tourism hero, proof metrics,
intent route cards, featured destination grid, AI planner prompt, chips, and
quote band.
