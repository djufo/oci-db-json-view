import { type InputHTMLAttributes, type ReactNode } from "react";
import { cn } from "../../lib/cn";

export type AuthAccessTone = "info" | "success" | "warning" | "danger";

export type AuthAccessMessage = {
  tone?: AuthAccessTone;
  children: ReactNode;
};

export type AuthProviderAction = {
  id: string;
  label: ReactNode;
  ariaLabel?: string;
  icon?: ReactNode;
  href?: string;
  external?: boolean;
  disabled?: boolean;
  featured?: boolean;
  onClick?: () => void;
};

export type AuthAccessPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  message?: AuthAccessMessage;
  providers?: AuthProviderAction[];
  providerSlot?: ReactNode;
  providerLabel?: string;
  dividerLabel?: ReactNode;
  actions?: ReactNode;
  footer?: ReactNode;
  variant?: "operator" | "portal";
  className?: string;
  cardClassName?: string;
  children?: ReactNode;
};

export function AuthAccessPanel({
  title,
  eyebrow,
  subtitle,
  message,
  providers = [],
  providerSlot,
  providerLabel = "Authentication providers",
  dividerLabel,
  actions,
  footer,
  variant = "portal",
  className,
  cardClassName,
  children,
}: AuthAccessPanelProps) {
  const hasProviderArea = providers.length > 0 || Boolean(providerSlot);

  return (
    <section className={cn("ui-auth-access", `ui-auth-access--${variant}`, className)}>
      <div className={cn("ui-auth-access__card", cardClassName)}>
        <header className="ui-auth-access__header">
          {eyebrow ? <span className="ui-auth-access__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </header>

        {message ? (
          <div className={cn("ui-auth-access__message", `ui-auth-access__message--${message.tone ?? "info"}`)} role="status">
            {message.children}
          </div>
        ) : null}

        {providers.length > 0 ? <AuthProviderGrid actions={providers} label={providerLabel} /> : null}
        {providerSlot ? (
          <div className="ui-auth-access__provider-slot" aria-label={providerLabel}>
            {providerSlot}
          </div>
        ) : null}

        {dividerLabel && hasProviderArea && children ? (
          <div className="ui-auth-access__divider">
            <span>{dividerLabel}</span>
          </div>
        ) : null}

        {children ? <div className="ui-auth-access__body">{children}</div> : null}
        {actions ? <div className="ui-auth-access__actions">{actions}</div> : null}
        {footer ? <footer className="ui-auth-access__footer">{footer}</footer> : null}
      </div>
    </section>
  );
}

export function AuthProviderGrid({
  actions,
  label = "Authentication providers",
}: {
  actions: AuthProviderAction[];
  label?: string;
}) {
  if (actions.length === 0) {
    return null;
  }

  return (
    <div className="ui-auth-provider-grid" aria-label={label}>
      {actions.map((action) => (
        <AuthProviderControl action={action} key={action.id} />
      ))}
    </div>
  );
}

function AuthProviderControl({ action }: { action: AuthProviderAction }) {
  const classes = cn("ui-auth-provider", action.featured && "ui-auth-provider--featured");
  const content = (
    <>
      {action.icon ? <span className="ui-auth-provider__icon">{action.icon}</span> : null}
      <span>{action.label}</span>
    </>
  );

  if (action.href && !action.disabled) {
    return (
      <a
        className={classes}
        href={action.href}
        aria-label={action.ariaLabel}
        target={action.external ? "_blank" : undefined}
        rel={action.external ? "noreferrer" : undefined}
        onClick={action.onClick}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      type="button"
      className={classes}
      aria-label={action.ariaLabel}
      disabled={action.disabled}
      onClick={action.onClick}
    >
      {content}
    </button>
  );
}

export function AuthFieldRow({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("ui-auth-field-row", className)}>{children}</div>;
}

export type AuthInputFieldProps = InputHTMLAttributes<HTMLInputElement> & {
  id: string;
  label: ReactNode;
  labelAction?: ReactNode;
  icon?: ReactNode;
  action?: ReactNode;
  after?: ReactNode;
  hint?: ReactNode;
  error?: ReactNode;
  rootClassName?: string;
};

export function AuthInputField({
  id,
  label,
  labelAction,
  icon,
  action,
  after,
  hint,
  error,
  className,
  rootClassName,
  ...props
}: AuthInputFieldProps) {
  const describedBy = [
    hint ? `${id}-hint` : "",
    error ? `${id}-error` : "",
  ]
    .filter(Boolean)
    .join(" ");

  return (
    <div className={cn("ui-auth-field", rootClassName)}>
      <div className="ui-auth-field__label-row">
        <label htmlFor={id}>{label}</label>
        {labelAction ? <span className="ui-auth-field__label-action">{labelAction}</span> : null}
      </div>
      <div className="ui-auth-field__control">
        {icon ? <span className="ui-auth-field__icon">{icon}</span> : null}
        <input
          id={id}
          className={cn("ui-auth-field__input", icon && "has-icon", action && "has-action", className)}
          aria-describedby={describedBy || undefined}
          aria-invalid={error ? true : undefined}
          {...props}
        />
        {action ? <span className="ui-auth-field__action">{action}</span> : null}
      </div>
      {hint ? (
        <span className="ui-auth-field__hint" id={`${id}-hint`}>
          {hint}
        </span>
      ) : null}
      {error ? (
        <span className="ui-auth-field__error" id={`${id}-error`}>
          {error}
        </span>
      ) : null}
      {after ? <div className="ui-auth-field__after">{after}</div> : null}
    </div>
  );
}

export function AuthStrengthMeter({
  score,
  max = 4,
  tone = "info",
  label,
  hint,
}: {
  score: number;
  max?: number;
  tone?: AuthAccessTone;
  label: ReactNode;
  hint?: ReactNode;
}) {
  const normalizedMax = Math.max(1, Math.round(max));
  const filled = Math.max(0, Math.min(normalizedMax, Math.round(score)));

  return (
    <div className={cn("ui-auth-strength", `ui-auth-strength--${tone}`)}>
      <div className="ui-auth-strength__bars" aria-hidden="true">
        {Array.from({ length: normalizedMax }).map((_, index) => (
          <span className={cn(index < filled && "is-filled")} key={index} />
        ))}
      </div>
      <div className="ui-auth-strength__text">
        <strong>{label}</strong>
        {hint ? <span>{hint}</span> : null}
      </div>
    </div>
  );
}
