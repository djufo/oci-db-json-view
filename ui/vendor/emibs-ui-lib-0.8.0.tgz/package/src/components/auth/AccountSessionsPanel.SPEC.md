# AccountSessionsPanel Spec

## Purpose

Reusable account-security panel for products that need to show active browser or
device sessions, support per-session revoke actions, and expose bulk session
actions without sharing auth runtime state.

## Sources

- eLitua active sessions page:
  `/engineering/projects/elitua/ui/src/pages/account/sessions/SessionsPage.tsx`.
- eLitua account profile page:
  `/engineering/projects/elitua/ui/src/pages/account/user-profile/UserProfilePage.tsx`.
- Score profile surface inspected as a future operator-account consumer:
  `/engineering/projects/score/ui/src/features/profile/containers/ProfileContainer.tsx`.

## Contract

- `AccountSessionsPanel` owns the panel header, status/action chrome, loading,
  error, empty state, and active session list layout.
- `AccountSessionItem` accepts preformatted device, location/IP, created,
  expiry, current-session, status, and action values.
- Device icons are presentational defaults only; consuming apps may provide their
  own `icon` per row.
- Revoke and bulk actions are controlled by props or action slots.

## Boundaries

- No auth service, fetch, revoke mutation, session parsing, user-agent parsing,
  token storage, confirmation policy, route link, or toast behavior lives in the
  component.
- Consuming apps own date formatting, current-session detection, session
  invalidation, "revoke all other sessions" semantics, and localization.
- Styling uses catalog tokens in `src/styles.css`.

## Review Checks

- Loading, error, empty, current-session, and multi-device states are visible in
  the catalog without a live auth backend.
- Long user-agent or IP/location values wrap without forcing horizontal page
  overflow.
- Revoke controls remain keyboard reachable and preserve a useful text label or
  supplied accessible action content.
