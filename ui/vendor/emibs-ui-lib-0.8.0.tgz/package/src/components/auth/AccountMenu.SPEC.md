# AccountMenu

## Purpose

`AccountMenu` is a controlled account dropdown for authenticated and guest
header states. It keeps IdentityAvatar-backed avatar trigger, identity summary, role badge,
sectioned navigation, sign-in calls to action, and destructive sign-out styling
reusable without owning auth or routing.

## Source Evidence

- eLitua account dropdown:
  `/engineering/projects/elitua/ui/src/components/layout/header/AuthDropdown/AuthDropdown.tsx`.
- eLitua account dropdown styles:
  `/engineering/projects/elitua/ui/src/components/layout/header/AuthDropdown/AuthDropdown.module.scss`.
- Score authenticated shell identity/sign-out area:
  `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`.

## Contract

- `open` and `onOpenChange` are controlled by the consuming app.
- `identity` renders the signed-in profile summary; omitted identity renders the
  guest prompt and `guestActions`.
- Built-in identity initials render through `IdentityAvatar`; consumers may
  still provide a custom `identity.avatar` node when they own the media.
- `sections` render role-filtered menu items supplied by the consuming app.
- Items may be links or buttons and may include icons, descriptions, current
  state, disabled state, and danger tone.
- An item that sets `target="_blank"` without its own `rel` is rendered with
  `rel="noopener noreferrer"`, since the item `href` is consumer-supplied and
  therefore untrusted. An explicit `item.rel` is always preserved, so a consumer
  who wants the referrer sent to a same-origin destination can still say so.
- The component may request close on select, but routing, auth mutation, outside
  click handling, and persistence stay product-owned.

## Boundaries

- No auth context, logout call, React Router dependency, role policy, menu
  registry, translations, analytics, or document-level click listeners live in
  the shared component.
- Consumer apps own role filtering, route adapters, focus restoration, OAuth
  state, session invalidation, and localized labels.
- Styling uses catalog tokens in `src/styles.css`.

## Review Checks

- Authenticated and guest variants are visible in the catalog.
- Long display names and email addresses wrap without overflowing the menu.
- Links and button actions remain keyboard reachable with clear focus styling.
