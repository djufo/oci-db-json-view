# SessionRefreshDialog Spec

## Purpose

Controlled session-refresh dialog for apps that need to interrupt a protected
workspace, collect a fresh credential, and keep the current page state visible
behind the modal.

## Source Evidence

- Score re-auth overlay and login panel composition in
  `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`.
- Existing shared `AuthAccessPanel` contract in
  `/engineering/projects/emibs/packages/emibs-ui-lib/src/components/auth/AuthAccessPanel.tsx`.

## Contract

- `SessionRefreshDialog` owns fixed or contained modal chrome, backdrop, close
  affordance, and the auth-card placement while composing the shared `Dialog`
  overlay engine for fixed-placement focus trap, body scroll lock, top-most
  Escape handling, and focus return.
- Auth copy, provider actions, custom provider SDK slots, credential form
  children, dismiss footer, and busy/disabled states are controlled by props.
- `providerSlot` supports SDK-rendered buttons such as Google Identity Services;
  `providers` supports simple button/anchor provider actions.

## Boundaries

- No token exchange, OAuth SDK loading, session polling, persistence, routing,
  focus restoration, or draft preservation behavior lives in the shared
  component.
- Consuming apps own current actor state, unauthorized handling, form validation,
  provider callback wiring, toasts, and localization.

## Review Checks

- Fixed and contained placements should both center the card and keep the
  backdrop behind it.
- Provider-only, form-only, and mixed provider/form content must wrap on mobile.
- Escape and close actions are disabled when `closeDisabled` is true.
