import { AlertTriangle, CheckCircle2, Info, LoaderCircle } from "lucide-react";
import { useId, type ReactNode } from "react";
import { cn } from "../../lib";

export type AuthStatusTone = "loading" | "success" | "info" | "warning" | "danger";

export type AuthStatusPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  tone?: AuthStatusTone;
  icon?: ReactNode;
  actions?: ReactNode;
  footer?: ReactNode;
  variant?: "operator" | "portal";
  fullHeight?: boolean;
  className?: string;
  cardClassName?: string;
  children?: ReactNode;
};

export function AuthStatusPanel({
  title,
  eyebrow,
  subtitle,
  tone = "info",
  icon,
  actions,
  footer,
  variant = "portal",
  fullHeight = false,
  className,
  cardClassName,
  children,
}: AuthStatusPanelProps) {
  const titleId = useId();
  const bodyId = useId();
  const role = tone === "danger" ? "alert" : "status";

  return (
    <section
      aria-describedby={subtitle || children ? bodyId : undefined}
      aria-labelledby={titleId}
      className={cn(
        "ui-auth-status",
        `ui-auth-status--${variant}`,
        fullHeight && "ui-auth-status--full",
        className,
      )}
      role={role}
    >
      <div className={cn("ui-auth-status__card", cardClassName)}>
        <div className={cn("ui-auth-status__icon", `ui-auth-status__icon--${tone}`)} aria-hidden="true">
          {icon ?? defaultAuthStatusIcon(tone)}
        </div>
        <header className="ui-auth-status__header">
          {eyebrow ? <span className="ui-auth-status__eyebrow">{eyebrow}</span> : null}
          <h2 id={titleId}>{title}</h2>
          {subtitle ? <p id={bodyId}>{subtitle}</p> : null}
        </header>
        {children ? (
          <div className="ui-auth-status__body" id={subtitle ? undefined : bodyId}>
            {children}
          </div>
        ) : null}
        {actions ? <div className="ui-auth-status__actions">{actions}</div> : null}
        {footer ? <footer className="ui-auth-status__footer">{footer}</footer> : null}
      </div>
    </section>
  );
}

function defaultAuthStatusIcon(tone: AuthStatusTone) {
  if (tone === "loading") {
    return <LoaderCircle size={32} />;
  }
  if (tone === "success") {
    return <CheckCircle2 size={32} />;
  }
  if (tone === "warning") {
    return <AlertTriangle size={32} />;
  }
  if (tone === "danger") {
    return <AlertTriangle size={32} />;
  }
  return <Info size={32} />;
}
