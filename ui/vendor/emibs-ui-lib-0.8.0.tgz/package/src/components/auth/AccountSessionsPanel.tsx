import { CircleHelp, Monitor, Smartphone, Tablet } from "lucide-react";
import { type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { Button } from "../primitives/Button";

export type AccountSessionDevice = "desktop" | "mobile" | "tablet" | "unknown";

export type AccountSessionItem = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  device?: AccountSessionDevice;
  icon?: ReactNode;
  current?: boolean;
  currentLabel?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  startedAt?: ReactNode;
  expiresAt?: ReactNode;
  meta?: ReactNode[];
  action?: ReactNode;
  revokeLabel?: string;
  actionDisabled?: boolean;
  onRevoke?: () => void;
};

export type AccountSessionsPanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  sessions?: AccountSessionItem[];
  loading?: boolean;
  loadingLabel?: ReactNode;
  error?: ReactNode;
  emptyTitle?: ReactNode;
  emptyDescription?: ReactNode;
  listLabel?: string;
  className?: string;
};

export function AccountSessionsPanel({
  title,
  eyebrow,
  subtitle,
  status,
  statusTone = "neutral",
  actions,
  sessions = [],
  loading = false,
  loadingLabel = "Loading sessions.",
  error,
  emptyTitle = "No active sessions",
  emptyDescription = "Sessions will appear here after sign-in.",
  listLabel = "Active account sessions",
  className,
}: AccountSessionsPanelProps) {
  return (
    <section className={cn("ui-account-sessions", className)} aria-busy={loading}>
      <header className="ui-account-sessions__header">
        <div className="ui-account-sessions__title-block">
          {eyebrow ? <span className="ui-account-sessions__eyebrow">{eyebrow}</span> : null}
          <h2>{title}</h2>
          {subtitle ? <p>{subtitle}</p> : null}
        </div>
        <div className="ui-account-sessions__header-actions">
          {status ? <Badge tone={statusTone}>{status}</Badge> : null}
          {actions}
        </div>
      </header>

      {error ? (
        <div className="ui-account-sessions__error" role="alert">
          {error}
        </div>
      ) : null}

      {loading ? (
        <div className="ui-account-sessions__state">{loadingLabel}</div>
      ) : sessions.length > 0 ? (
        <ul className="ui-account-sessions__list" aria-label={listLabel}>
          {sessions.map((session) => (
            <AccountSessionRow key={session.id} session={session} />
          ))}
        </ul>
      ) : (
        <div className="ui-account-sessions__state">
          <strong>{emptyTitle}</strong>
          {emptyDescription ? <span>{emptyDescription}</span> : null}
        </div>
      )}
    </section>
  );
}

function AccountSessionRow({ session }: { session: AccountSessionItem }) {
  const currentLabel = session.currentLabel ?? "Current session";
  const revokeLabel = session.revokeLabel ?? "Revoke session";

  return (
    <li className={cn("ui-account-sessions__item", session.current && "is-current")}>
      <span className="ui-account-sessions__device" aria-hidden="true">
        {session.icon ?? deviceIcon(session.device ?? "unknown")}
      </span>
      <div className="ui-account-sessions__item-main">
        <div className="ui-account-sessions__item-title">
          <strong>{session.title}</strong>
          {session.current ? <Badge tone="success">{currentLabel}</Badge> : null}
          {session.status ? <Badge tone={session.statusTone}>{session.status}</Badge> : null}
        </div>
        {session.description ? <p>{session.description}</p> : null}
        <div className="ui-account-sessions__meta">
          {session.startedAt ? <span>{session.startedAt}</span> : null}
          {session.expiresAt ? <span>{session.expiresAt}</span> : null}
          {session.meta?.map((item, index) => <span key={index}>{item}</span>)}
        </div>
      </div>
      {session.action || session.onRevoke ? (
        <div className="ui-account-sessions__item-actions">
          {session.action ?? (
            <Button type="button" variant="ghost" size="sm" disabled={session.actionDisabled} onClick={session.onRevoke}>
              {revokeLabel}
            </Button>
          )}
        </div>
      ) : null}
    </li>
  );
}

function deviceIcon(device: AccountSessionDevice) {
  if (device === "desktop") {
    return <Monitor size={20} />;
  }
  if (device === "mobile") {
    return <Smartphone size={20} />;
  }
  if (device === "tablet") {
    return <Tablet size={20} />;
  }
  return <CircleHelp size={20} />;
}
