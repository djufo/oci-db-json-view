# AccountProfilePanel

## Purpose

`AccountProfilePanel` is a presentational authenticated account profile surface
for identity, verification, contact, preference, provider-profile, and related
security links.

## Contract

- Renders account identity chrome with IdentityAvatar-backed avatar/initials,
  title, subtitle, badges,
  action slot, optional stats, notices, form sections, secondary links, and
  footer note.
- Sections accept controlled form controls from the consuming product; the
  shared component owns layout and accessible labels only.
- Notices support info, success, warning, danger, accent, and neutral tones for
  verification prompts, save messages, and account status messages.
- Product apps own auth state, profile persistence, validation, verification
  email delivery, provider-specific profile records, routing, localization, and
  toast behavior.
- Uses `IdentityAvatar` for default identity fallback rendering, plus
  `ui-account-profile*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/features/profile/containers/ProfileContainer.tsx` provides an
  authenticated profile/preferences form with autosave status and notification
  frequency.
- eLitua `ui/src/pages/account/user-profile/UserProfilePage.tsx` provides
  account identity fields, email verification notices, save actions, password
  and session links.
- eLitua `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` and
  `ui/src/pages/account/accommodation-profile/AccommodationProfilePage.tsx`
  provide larger provider-owned profile forms with contact, license, language,
  business, location, and check-in sections.

## Non-Goals

- No profile API calls, auth context integration, GraphQL mutations, password
  handling, session revocation, verification delivery, or provider-profile
  business rules.
- No adoption into Score or eLitua in this extraction; adoption is tracked by
  separate low-priority UI Framework refactor tasks.
