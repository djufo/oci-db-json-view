# PasswordRevealButton

## Purpose

`PasswordRevealButton` is a presentational password visibility toggle for auth
forms that need the same labeled eye/eye-off action inside password fields.

## Source Evidence

- eLitua `LoginPage`, `RegisterPage`, `ChangePasswordPage`, and
  `ResetPasswordPage` repeat the same show/hide password button inside
  `AuthInputField` action slots.
- Score's operator sign-in keeps token handling local, but can use the same
  action control if it later allows revealing development tokens.

## Contract

- Accepts controlled `visible` state and optional `onVisibleChange`.
- Renders a native `button type="button"` with `aria-label`, `aria-pressed`,
  tooltip title, and decorative lucide eye/eye-off icons. `type`,
  `aria-label` and `aria-pressed` are set after caller attributes, so a caller
  cannot turn it into a submit button.
- The accessible name and tooltip state the current state and the action
  (skill `ui-affordance`). Defaults: "Password hidden — show password" while
  hidden, "Password shown — hide password" while shown (EMIBS AuthN
  `specs/sign-in-methods.md` SM.11.1); every consumer inherits them.
  `aria-pressed` is true while shown.
- After a toggle, focus stays on the button (it focuses itself on click, for
  browsers that do not focus clicked buttons). Space and Enter toggle it as a
  native button; it never submits the surrounding form.
- Supports custom labels for each state (`showLabel` while hidden, `hideLabel`
  while shown) and standard non-child button attributes. Custom labels keep
  both parts: the state and the action.
- Uses only `ui-password-reveal-button` CSS and shared token variables.

## Non-Goals

- Does not own input type, password value, validation, password strength,
  persistence, analytics, form submission, or auth service calls.
- Does not manage hidden/visible state internally; consuming forms keep state.
