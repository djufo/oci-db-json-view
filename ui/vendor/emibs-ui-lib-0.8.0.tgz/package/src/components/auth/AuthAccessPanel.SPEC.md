# AuthAccessPanel Spec

## Purpose

Reusable authentication entry surface for EMIBS apps that need a centered
sign-in, registration, or session-refresh panel without sharing product auth
state.

## Sources

- Score `LoginState` and `ReauthDialog` in
  `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`.
- eLitua account pages in
  `/engineering/projects/elitua/ui/src/features/users/components/*`.
- eLitua forgot-password request/success flow in
  `/engineering/projects/elitua/ui/src/features/users/components/ForgotPasswordPage/ForgotPasswordPage.tsx`.
- eLitua auth page styling in
  `/engineering/projects/elitua/ui/src/features/users/AuthPages.module.scss`.

## Contract

- `AuthAccessPanel` owns page/card structure, title copy, provider grid or
  opaque provider slot, divider, message, body, action row, and footer slots.
- `AuthProviderGrid` renders provider actions as buttons or anchors from props.
- `AuthInputField` renders labeled auth inputs with optional leading icon,
  label action, trailing action, hint, error text, and after-content slot.
- `AuthFieldRow` supports compact two-column field groups.
- `AuthStrengthMeter` renders a controlled password-strength preview.

## Boundaries

- No auth exchange, token persistence, redirects, provider SDK loading, password
  analysis, or form validation lives in the component. SDK-rendered providers
  are passed as inert React nodes through `providerSlot`.
- Consuming apps own route links, submit handlers, provider callbacks, current
  session state, and product-specific copy.
- Styling uses the catalog token roles in `src/styles.css`.

## Review Checks

- Provider-only, form-only, and mixed provider/form panels must render without
  layout shifts.
- Long field labels and error messages must wrap inside the card on mobile.
- Label actions and after-content must stack cleanly on narrow screens.
- Primary and secondary action rows must wrap cleanly for password recovery and
  similar account flows without crowding footer copy.
- Interactive controls must be supplied by consuming apps through props or slots.
