import { UserRound } from "lucide-react";
import { type MouseEvent, type ReactNode } from "react";
import { cn } from "../../lib";
import { externalLinkRel } from "../../lib/externalLinkRel";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { IdentityAvatar } from "../primitives/IdentityAvatar";

export type AccountMenuIdentity = {
  name: ReactNode;
  secondary?: ReactNode;
  avatar?: ReactNode;
  initials?: string;
  role?: ReactNode;
  roleTone?: BadgeTone;
};

export type AccountMenuItem = {
  id: string;
  label: ReactNode;
  href?: string;
  icon?: ReactNode;
  description?: ReactNode;
  current?: boolean;
  disabled?: boolean;
  tone?: "default" | "danger";
  target?: string;
  rel?: string;
  onSelect?: () => void;
};

export type AccountMenuSection = {
  id: string;
  label?: ReactNode;
  items: AccountMenuItem[];
};

export type AccountMenuProps = {
  open: boolean;
  onOpenChange?: (open: boolean) => void;
  identity?: AccountMenuIdentity;
  sections?: AccountMenuSection[];
  guestTitle?: ReactNode;
  guestDescription?: ReactNode;
  guestActions?: AccountMenuItem[];
  trigger?: ReactNode;
  triggerLabel?: string;
  menuLabel?: string;
  align?: "start" | "end";
  closeOnSelect?: boolean;
  className?: string;
  menuClassName?: string;
};

export function AccountMenu({
  open,
  onOpenChange,
  identity,
  sections = [],
  guestTitle = "Account",
  guestDescription,
  guestActions = [],
  trigger,
  triggerLabel = "Account menu",
  menuLabel = "Account menu",
  align = "end",
  closeOnSelect = true,
  className,
  menuClassName,
}: AccountMenuProps) {
  const hasMenuContent = Boolean(identity) || sections.length > 0 || guestActions.length > 0 || guestDescription;

  return (
    <div className={cn("ui-account-menu", className)}>
      <button
        aria-expanded={open}
        aria-haspopup="menu"
        aria-label={triggerLabel}
        className={cn("ui-account-menu__trigger", open && "is-open")}
        onClick={() => onOpenChange?.(!open)}
        type="button"
      >
        {trigger ?? <AccountMenuAvatar identity={identity} />}
      </button>

      {open && hasMenuContent ? (
        <div
          aria-label={menuLabel}
          className={cn("ui-account-menu__panel", `ui-account-menu__panel--${align}`, menuClassName)}
          role="menu"
        >
          {identity ? <AccountMenuProfile identity={identity} /> : null}

          {identity ? (
            <AccountMenuSections sections={sections} closeOnSelect={closeOnSelect} onOpenChange={onOpenChange} />
          ) : (
            <div className="ui-account-menu__guest">
              <strong>{guestTitle}</strong>
              {guestDescription ? <p>{guestDescription}</p> : null}
              {guestActions.length > 0 ? (
                <div className="ui-account-menu__guest-actions">
                  {guestActions.map((item) => (
                    <AccountMenuAction
                      closeOnSelect={closeOnSelect}
                      item={item}
                      key={item.id}
                      onOpenChange={onOpenChange}
                    />
                  ))}
                </div>
              ) : null}
            </div>
          )}
        </div>
      ) : null}
    </div>
  );
}

function AccountMenuAvatar({ identity }: { identity?: AccountMenuIdentity }) {
  if (identity?.avatar) {
    return <span className="ui-account-menu__avatar">{identity.avatar}</span>;
  }
  if (!identity) {
    return <UserRound size={18} aria-hidden="true" />;
  }
  return (
    <IdentityAvatar
      initials={identity.initials}
      label={identityLabel(identity.name, "Account")}
      size="sm"
      tone={identity.roleTone ?? "accent"}
    />
  );
}

function AccountMenuProfile({ identity }: { identity: AccountMenuIdentity }) {
  return (
    <div className="ui-account-menu__profile">
      <AccountMenuAvatar identity={identity} />
      <div className="ui-account-menu__profile-copy">
        <strong>{identity.name}</strong>
        {identity.secondary ? <span>{identity.secondary}</span> : null}
        {identity.role ? <Badge tone={identity.roleTone}>{identity.role}</Badge> : null}
      </div>
    </div>
  );
}

function AccountMenuSections({
  sections,
  closeOnSelect,
  onOpenChange,
}: {
  sections: AccountMenuSection[];
  closeOnSelect: boolean;
  onOpenChange?: (open: boolean) => void;
}) {
  if (sections.length === 0) {
    return null;
  }
  return (
    <div className="ui-account-menu__sections">
      {sections.map((section) => (
        <section className="ui-account-menu__section" key={section.id}>
          {section.label ? <h3>{section.label}</h3> : null}
          <div className="ui-account-menu__items">
            {section.items.map((item) => (
              <AccountMenuAction
                closeOnSelect={closeOnSelect}
                item={item}
                key={item.id}
                onOpenChange={onOpenChange}
              />
            ))}
          </div>
        </section>
      ))}
    </div>
  );
}

function AccountMenuAction({
  item,
  closeOnSelect,
  onOpenChange,
}: {
  item: AccountMenuItem;
  closeOnSelect: boolean;
  onOpenChange?: (open: boolean) => void;
}) {
  const className = cn(
    "ui-account-menu__item",
    item.tone === "danger" && "ui-account-menu__item--danger",
    item.current && "is-current"
  );
  const content = (
    <>
      {item.icon ? <span className="ui-account-menu__item-icon">{item.icon}</span> : null}
      <span className="ui-account-menu__item-copy">
        <strong>{item.label}</strong>
        {item.description ? <small>{item.description}</small> : null}
      </span>
    </>
  );
  const onClick = (event: MouseEvent<HTMLAnchorElement | HTMLButtonElement>) => {
    if (item.disabled) {
      event.preventDefault();
      return;
    }
    item.onSelect?.();
    if (closeOnSelect) {
      onOpenChange?.(false);
    }
  };

  if (item.href) {
    return (
      <a
        aria-current={item.current ? "page" : undefined}
        aria-disabled={item.disabled || undefined}
        className={className}
        href={item.disabled ? undefined : item.href}
        onClick={onClick}
        rel={externalLinkRel(item.target, item.rel)}
        role="menuitem"
        target={item.target}
      >
        {content}
      </a>
    );
  }

  return (
    <button
      aria-current={item.current ? "page" : undefined}
      className={className}
      disabled={item.disabled}
      onClick={onClick}
      role="menuitem"
      type="button"
    >
      {content}
    </button>
  );
}

function identityLabel(value: ReactNode, fallback: string): string {
  if (typeof value === "string" || typeof value === "number") {
    const label = String(value).trim();
    return label || fallback;
  }
  return fallback;
}
