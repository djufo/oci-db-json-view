import { type FormEventHandler, type FormHTMLAttributes, type ReactNode } from "react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { IdentityAvatar } from "../primitives/IdentityAvatar";

export type AccountProfileBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
};

export type AccountProfileStat = {
  id: string;
  label: ReactNode;
  value: ReactNode;
  detail?: ReactNode;
  icon?: ReactNode;
  tone?: BadgeTone;
};

export type AccountProfileNotice = {
  id: string;
  tone?: BadgeTone;
  icon?: ReactNode;
  title: ReactNode;
  description?: ReactNode;
  action?: ReactNode;
};

export type AccountProfileField = {
  id: string;
  label: ReactNode;
  control: ReactNode;
  hint?: ReactNode;
  meta?: ReactNode;
  icon?: ReactNode;
  wide?: boolean;
};

export type AccountProfileSection = {
  id: string;
  title: ReactNode;
  description?: ReactNode;
  badge?: AccountProfileBadge;
  fields?: AccountProfileField[];
  actions?: ReactNode;
  children?: ReactNode;
};

export type AccountProfileLink = {
  id: string;
  label: ReactNode;
  href?: string;
  external?: boolean;
  icon?: ReactNode;
  onClick?: () => void;
};

export type AccountProfilePanelProps = Omit<FormHTMLAttributes<HTMLFormElement>, "title" | "onSubmit"> & {
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  avatar?: ReactNode;
  avatarLabel?: string;
  badges?: AccountProfileBadge[];
  stats?: AccountProfileStat[];
  notices?: AccountProfileNotice[];
  sections?: AccountProfileSection[];
  actions?: ReactNode;
  secondaryLinks?: AccountProfileLink[];
  footer?: ReactNode;
  onSubmit?: FormEventHandler<HTMLFormElement>;
};

export function AccountProfilePanel({
  title,
  eyebrow,
  subtitle,
  avatar,
  avatarLabel,
  badges = [],
  stats = [],
  notices = [],
  sections = [],
  actions,
  secondaryLinks = [],
  footer,
  className,
  children,
  onSubmit,
  ...props
}: AccountProfilePanelProps) {
  return (
    <form className={cn("ui-account-profile", className)} onSubmit={onSubmit} {...props}>
      <header className="ui-account-profile__header">
        <div className="ui-account-profile__identity">
          {avatar ? (
            <span className="ui-account-profile__avatar" aria-label={avatarLabel} role={avatarLabel ? "img" : undefined}>
              {avatar}
            </span>
          ) : (
            <IdentityAvatar label={avatarLabel ?? identityLabel(title, "Account profile")} size="lg" tone="accent" />
          )}
          <div className="ui-account-profile__title-block">
            {eyebrow ? <span className="ui-account-profile__eyebrow">{eyebrow}</span> : null}
            <h2>{title}</h2>
            {subtitle ? <p>{subtitle}</p> : null}
            {badges.length > 0 ? (
              <div className="ui-account-profile__badges">
                {badges.map((badge) => (
                  <Badge key={badge.id} tone={badge.tone}>
                    {badge.label}
                  </Badge>
                ))}
              </div>
            ) : null}
          </div>
        </div>
        {actions ? <div className="ui-account-profile__actions">{actions}</div> : null}
      </header>

      {stats.length > 0 ? (
        <dl className="ui-account-profile__stats">
          {stats.map((stat) => (
            <div className={cn("ui-account-profile__stat", stat.tone && `ui-account-profile__stat--${stat.tone}`)} key={stat.id}>
              <dt>
                {stat.icon ? <span aria-hidden="true">{stat.icon}</span> : null}
                {stat.label}
              </dt>
              <dd>{stat.value}</dd>
              {stat.detail ? <small>{stat.detail}</small> : null}
            </div>
          ))}
        </dl>
      ) : null}

      {notices.length > 0 ? (
        <div className="ui-account-profile__notices">
          {notices.map((notice) => (
            <div className={cn("ui-account-profile__notice", `ui-account-profile__notice--${notice.tone ?? "info"}`)} key={notice.id}>
              {notice.icon ? <span className="ui-account-profile__notice-icon">{notice.icon}</span> : null}
              <div>
                <strong>{notice.title}</strong>
                {notice.description ? <p>{notice.description}</p> : null}
              </div>
              {notice.action ? <div className="ui-account-profile__notice-action">{notice.action}</div> : null}
            </div>
          ))}
        </div>
      ) : null}

      {sections.length > 0 ? (
        <div className="ui-account-profile__sections">
          {sections.map((section) => (
            <AccountProfileSectionView key={section.id} section={section} />
          ))}
        </div>
      ) : null}

      {children ? <div className="ui-account-profile__body">{children}</div> : null}

      {(secondaryLinks.length > 0 || footer) ? (
        <footer className="ui-account-profile__footer">
          {secondaryLinks.length > 0 ? (
            <div className="ui-account-profile__links">
              {secondaryLinks.map((link) => (
                <AccountProfileLinkView key={link.id} link={link} />
              ))}
            </div>
          ) : null}
          {footer ? <div className="ui-account-profile__footer-note">{footer}</div> : null}
        </footer>
      ) : null}
    </form>
  );
}

function AccountProfileSectionView({ section }: { section: AccountProfileSection }) {
  return (
    <section className="ui-account-profile__section">
      <header className="ui-account-profile__section-header">
        <div>
          <h3>{section.title}</h3>
          {section.description ? <p>{section.description}</p> : null}
        </div>
        <div className="ui-account-profile__section-actions">
          {section.badge ? <Badge tone={section.badge.tone}>{section.badge.label}</Badge> : null}
          {section.actions}
        </div>
      </header>
      {section.fields?.length ? (
        <div className="ui-account-profile__field-grid">
          {section.fields.map((field) => (
            <label className={cn("ui-account-profile__field", field.wide && "is-wide")} key={field.id}>
              <span className="ui-account-profile__field-label">
                <span>
                  {field.icon ? <span aria-hidden="true">{field.icon}</span> : null}
                  {field.label}
                </span>
                {field.meta ? <small>{field.meta}</small> : null}
              </span>
              {field.control}
              {field.hint ? <small className="ui-account-profile__hint">{field.hint}</small> : null}
            </label>
          ))}
        </div>
      ) : null}
      {section.children ? <div className="ui-account-profile__section-body">{section.children}</div> : null}
    </section>
  );
}

function AccountProfileLinkView({ link }: { link: AccountProfileLink }) {
  const content = (
    <>
      {link.icon ? <span aria-hidden="true">{link.icon}</span> : null}
      <span>{link.label}</span>
    </>
  );
  if (link.href) {
    return (
      <a href={link.href} rel={link.external ? "noreferrer" : undefined} target={link.external ? "_blank" : undefined}>
        {content}
      </a>
    );
  }
  return (
    <button onClick={link.onClick} type="button">
      {content}
    </button>
  );
}

function identityLabel(value: ReactNode, fallback: string): string {
  if (typeof value === "string" || typeof value === "number") {
    const label = String(value).trim();
    return label || fallback;
  }
  return fallback;
}
