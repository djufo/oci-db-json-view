# AuthStatusPanel Spec

## Purpose

Reusable authentication status surface for OAuth callbacks, email verification,
session boot checks, guest/no-access states, and other account flow outcomes
that should not include a credential form.

## Sources

- eLitua OAuth callback and email verification pages in
  `/engineering/projects/elitua/ui/src/pages/account/oauth-callback/OAuthCallbackPage.tsx`
  and `/engineering/projects/elitua/ui/src/pages/account/verify-email/VerifyEmailPage.tsx`.
- Score boot and no-access states in
  `/engineering/projects/score/ui/src/app-shell/AppShell.tsx`.

## Contract

- `AuthStatusPanel` owns the centered status card shell, tone icon, title,
  subtitle, optional detail body, action slot, footer slot, and portal/operator
  variants.
- Supported tones are `loading`, `success`, `info`, `warning`, and `danger`.
- Loading and non-error states use status semantics; danger states use alert
  semantics.
- Consuming apps may override the default icon and supply product-owned links,
  buttons, details, and footer copy through slots.

## Boundaries

- No OAuth exchange, token persistence, resend verification, redirect, session
  refresh, route guard, timeout, or product copy policy lives in the component.
- The component does not render credential inputs; use `AuthAccessPanel` for
  sign-in, registration, password reset, and reauth forms.

## Review Checks

- Loading, success, info, warning, and danger tones render without layout shifts.
- Long callback errors and no-access messages wrap inside the card on mobile.
- Action slots support one or more buttons/links while preserving centered card
  layout.
