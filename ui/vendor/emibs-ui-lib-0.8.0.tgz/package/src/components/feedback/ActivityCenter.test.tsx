// @vitest-environment happy-dom

import { act, createElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ActivityCenter, type ActivityCenterItem } from "./ActivityCenter";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

const ITEMS: ActivityCenterItem[] = [
  { id: "a", title: "Newest unread", body: "with a link", read: false, createdAt: "2026-08-12T10:00:00Z", link: "#/a" },
  { id: "b", title: "Older read", read: true, createdAt: "2026-08-12T09:00:00Z" },
];

describe("ActivityCenter", () => {
  let container: HTMLDivElement;
  let root: Root;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
  });

  function render(props: Parameters<typeof ActivityCenter>[0]) {
    act(() => root.render(createElement(ActivityCenter, props)));
  }

  it("lists items in a labelled group with read/unread rows", () => {
    render({ items: ITEMS, id: "ac" });
    const panel = container.querySelector('[role="group"]');
    expect(panel?.getAttribute("aria-label")).toBe("Notifications");
    const rows = container.querySelectorAll(".ui-activity-center__row");
    expect(rows).toHaveLength(2);
    // A row with a link is an anchor; without a link it is a button.
    expect(rows[0].tagName).toBe("A");
    expect(rows[0].getAttribute("href")).toBe("#/a");
    expect(rows[0].classList.contains("is-unread")).toBe(true);
    expect(rows[1].tagName).toBe("BUTTON");
    expect(rows[1].classList.contains("is-unread")).toBe(false);
    // Unread rows carry a visually-hidden marker for assistive tech.
    expect(rows[0].querySelector(".ui-activity-center__sr")?.textContent).toContain("Unread");
  });

  it("fires onItemSelect when a row is activated", () => {
    const onItemSelect = vi.fn();
    render({ items: ITEMS, onItemSelect });
    const row = container.querySelector<HTMLElement>(".ui-activity-center__row");
    act(() => row?.click());
    expect(onItemSelect).toHaveBeenCalledWith(ITEMS[0]);
  });

  it("mark-all-read reflects unread count and disables at zero", () => {
    const onMarkAllRead = vi.fn();
    render({ items: ITEMS, onMarkAllRead });
    const markAll = container.querySelector<HTMLButtonElement>(".ui-activity-center__mark-all");
    expect(markAll?.disabled).toBe(false);
    act(() => markAll?.click());
    expect(onMarkAllRead).toHaveBeenCalledTimes(1);

    render({ items: [{ id: "b", title: "read", read: true, createdAt: "2026-08-12T09:00:00Z" }], onMarkAllRead });
    expect(container.querySelector<HTMLButtonElement>(".ui-activity-center__mark-all")?.disabled).toBe(true);
  });

  it("renders the empty state when there are no items", () => {
    render({ items: [] });
    expect(container.querySelector(".ui-activity-center__state-title")?.textContent).toContain("caught up");
    expect(container.querySelector(".ui-activity-center__list")).toBeNull();
  });

  it("renders an alert error state with a retry", () => {
    const onRetry = vi.fn();
    render({ items: [], status: "error", error: "boom", onRetry });
    const alert = container.querySelector('[role="alert"]');
    expect(alert?.textContent).toContain("boom");
    act(() => container.querySelector<HTMLButtonElement>(".ui-activity-center__retry")?.click());
    expect(onRetry).toHaveBeenCalledTimes(1);
  });

  it("renders the loading skeleton with an accessible busy region", () => {
    render({ items: [], status: "loading" });
    const busy = container.querySelector('[aria-busy="true"]');
    expect(busy).not.toBeNull();
    expect(container.querySelectorAll(".ui-activity-center__skeleton")).toHaveLength(3);
  });
});
