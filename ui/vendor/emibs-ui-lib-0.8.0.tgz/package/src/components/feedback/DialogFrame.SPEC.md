# DialogFrame

## Purpose

`DialogFrame` is the shared presentational shell for arbitrary modal content.
It captures Score's task-detail and design-system dialog frame without moving
task loading, editing, routing, validation, permissions, persistence, focus
restoration, or toast behavior into the library.

Use purpose-built dialogs such as `ConfirmationDialog`, `CreationDialog`,
`ScheduleEditorDialog`, or `SessionRefreshDialog` when the interaction has a
fixed semantic workflow. Use `DialogFrame` when the product needs a reusable
header/body/footer modal frame around product-owned content.

## Contract

- Controlled by `open` and `onClose`.
- Supports `fixed` product placement and `contained` catalog/review placement.
- Renders an accessible `role="dialog"` shell with labelled title and optional
  subtitle description.
- Provides optional eyebrow, status badge, header actions, close control, body,
  and footer slots.
- Provides `sm`, `md`, `lg`, and `xl` width presets.
- Handles Escape and backdrop close in fixed placement when not `busy`.
- Disables close affordances while `busy` is true.

## Product Ownership

`DialogFrame` composes the shared `Dialog` overlay engine for fixed/contained
placements, so it inherits focus placement and restoration, focus trapping,
body scroll lock, stacking, Escape handling, and backdrop dismissal while the
product owns the content and workflow inside the frame.

## Accessibility Notes

- The `title` prop is required and is wired through `aria-labelledby`.
- The optional `subtitle` prop is wired through `aria-describedby`.
- `closeLabel` must name the close action when the default copy is not specific
  enough for the product context.
- If a dialog contains form errors or destructive actions, the consuming app
  should provide the appropriate live regions, confirmation wording, and focus
  management inside the body slot.
