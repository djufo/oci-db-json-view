import { useId, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "../../lib";
import { Dialog } from "../primitives/overlay";

export type AlertDialogFramePlacement = "fixed" | "contained";
export type AlertDialogFrameSize = "default" | "sm";

export type AlertDialogFrameProps = {
  open: boolean;
  title: ReactNode;
  description?: ReactNode;
  media?: ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
  placement?: AlertDialogFramePlacement;
  size?: AlertDialogFrameSize;
  showClose?: boolean;
  closeLabel?: string;
  closeOnBackdrop?: boolean;
  busy?: boolean;
  className?: string;
  panelClassName?: string;
  bodyClassName?: string;
  footerClassName?: string;
  onClose: () => void;
};

export function AlertDialogFrame({
  open,
  title,
  description,
  media,
  children,
  footer,
  placement = "fixed",
  size = "default",
  showClose = false,
  closeLabel = "Close alert dialog",
  closeOnBackdrop = false,
  busy = false,
  className,
  panelClassName,
  bodyClassName,
  footerClassName,
  onClose,
}: AlertDialogFrameProps) {
  const titleId = useId();
  const descriptionId = useId();
  const bodyId = useId();

  if (!open) {
    return null;
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      chrome="bare"
      modal={placement === "fixed"}
      inline={placement === "contained"}
      backdropLabel={closeLabel}
      backdropClassName="ui-alert-dialog-frame__backdrop"
      closeLabel={closeLabel}
      closeOnBackdrop={closeOnBackdrop && !busy}
      closeOnEscape={placement === "fixed" && !busy}
      layerClassName={cn("ui-alert-dialog-frame", `ui-alert-dialog-frame--${placement}`, className)}
      role="alertdialog"
      surfaceProps={{
        "aria-describedby": description ? descriptionId : children ? bodyId : undefined,
        "aria-labelledby": titleId,
      }}
    >
      <section
        className={cn("ui-alert-dialog-frame__panel", `ui-alert-dialog-frame__panel--${size}`, panelClassName)}
        role="presentation"
      >
        <header className={cn("ui-alert-dialog-frame__header", media && "has-media", showClose && "has-close")}>
          {media ? (
            <div className="ui-alert-dialog-frame__media" aria-hidden="true">
              {media}
            </div>
          ) : null}
          <div className="ui-alert-dialog-frame__copy">
            <h2 id={titleId}>{title}</h2>
            {description ? <p id={descriptionId}>{description}</p> : null}
          </div>
          {showClose ? (
            <button
              aria-label={closeLabel}
              className="ui-alert-dialog-frame__close"
              disabled={busy}
              onClick={onClose}
              type="button"
            >
              <X size={17} aria-hidden="true" />
            </button>
          ) : null}
        </header>

        {children ? (
          <div className={cn("ui-alert-dialog-frame__body", bodyClassName)} id={description ? undefined : bodyId}>
            {children}
          </div>
        ) : null}

        {footer ? <footer className={cn("ui-alert-dialog-frame__footer", footerClassName)}>{footer}</footer> : null}
      </section>
    </Dialog>
  );
}
