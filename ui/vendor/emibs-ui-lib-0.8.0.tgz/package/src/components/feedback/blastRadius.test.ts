import { describe, expect, it } from "vitest";
import { blastRadius, maxBlastSeverity, type BlastImpactItem } from "./blastRadius";

describe("maxBlastSeverity", () => {
  it("is info for an empty item set", () => {
    expect(maxBlastSeverity([])).toBe("info");
  });

  it("returns the worst severity across items (danger > warn > info)", () => {
    const items: BlastImpactItem[] = [
      { label: "a", detail: "x", severity: "info" },
      { label: "b", detail: "y", severity: "danger" },
      { label: "c", detail: "z", severity: "warn" },
    ];
    expect(maxBlastSeverity(items)).toBe("danger");
  });

  it("treats a missing item severity as info", () => {
    expect(maxBlastSeverity([{ label: "a", detail: "x" }])).toBe("info");
    expect(maxBlastSeverity([{ label: "a", detail: "x" }, { label: "b", detail: "y", severity: "warn" }])).toBe("warn");
  });
});

describe("blastRadius", () => {
  it("derives overall severity from its items so they cannot disagree", () => {
    const impact = blastRadius("Disable pool score", [
      { label: "Lanes stopped", detail: "Disabling 3 of 4 lanes.", severity: "danger" },
      { label: "Affected lanes", detail: "a, b, c", severity: "warn" },
    ]);
    expect(impact.summary).toBe("Disable pool score");
    expect(impact.items).toHaveLength(2);
    expect(impact.severity).toBe("danger");
  });

  it("is info when every item is informational", () => {
    const impact = blastRadius("Re-band to 0", [{ label: "Already at target", detail: "2 unchanged.", severity: "info" }]);
    expect(impact.severity).toBe("info");
  });
});
