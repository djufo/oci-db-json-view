import { useId, type ReactNode } from "react";
import { cn } from "../../lib";
import { ConfirmationDialog, type ConfirmationDialogPlacement, type ConfirmationDialogTone } from "./ConfirmationDialog";
import type { BlastRadius, BlastSeverity } from "./blastRadius";

/**
 * BlastRadiusConfirm (UIF-E3, generalized from Score v4 G3). The confirm surface
 * shown before a consequential write commits. It renders ONLY the `impact` it is
 * handed — a `BlastRadius` computed from live data by the caller — so it carries
 * no hardcoded consequence text of its own and can never display a stale or
 * fabricated blast radius.
 *
 * It does NOT invent a third dialog frame: it composes `ConfirmationDialog`
 * (which owns the overlay, focus trap, primary/cancel actions and tone accent),
 * mapping the impact severity to the dialog tone. A server error (403/409 body)
 * is surfaced verbatim through the `error` slot; the server owns policy, this
 * component owns only the pre-commit disclosure.
 */

const SEVERITY_TONE: Record<BlastSeverity, ConfirmationDialogTone> = {
  info: "info",
  warn: "warning",
  danger: "danger",
};

const ITEM_SEVERITY: Record<BlastSeverity, BlastSeverity> = {
  info: "info",
  warn: "warn",
  danger: "danger",
};

export type BlastRadiusConfirmProps = {
  /** Whether the confirm surface is open. */
  open: boolean;
  /** Computed blast radius (never hardcoded here). */
  impact: BlastRadius;
  /** The action verb used on the confirm button, e.g. "Disable pool". */
  confirmLabel: ReactNode;
  onConfirm: () => void;
  onCancel: () => void;
  /** Dialog heading; defaults to the computed `impact.summary`. */
  title?: ReactNode;
  cancelLabel?: ReactNode;
  /** Server error (e.g. a verbatim 403/409 body) surfaced with role=alert. */
  error?: ReactNode;
  /** Disable the confirm button and lock the surface while a write is in flight. */
  pending?: boolean;
  /** Fixed overlay (default) or contained/inline for review surfaces. */
  placement?: ConfirmationDialogPlacement;
  className?: string;
};

export function BlastRadiusConfirm({
  open,
  impact,
  confirmLabel,
  onConfirm,
  onCancel,
  title,
  cancelLabel = "Cancel",
  error,
  pending = false,
  placement = "fixed",
  className,
}: BlastRadiusConfirmProps) {
  const listId = useId();

  return (
    <ConfirmationDialog
      open={open}
      title={title ?? impact.summary}
      tone={SEVERITY_TONE[impact.severity]}
      confirmLabel={confirmLabel}
      cancelLabel={cancelLabel}
      busy={pending}
      placement={placement}
      className={cn("ui-blast-radius", `ui-blast-radius--${impact.severity}`, className)}
      onCancel={onCancel}
      onConfirm={onConfirm}
    >
      <div className="ui-blast-radius__impact" data-severity={impact.severity} role="group" aria-label="Computed blast radius">
        <ul className="ui-blast-radius__items" id={listId}>
          {impact.items.map((item, index) => (
            <li
              className="ui-blast-radius__item"
              data-severity={ITEM_SEVERITY[item.severity ?? "info"]}
              key={`${item.label}-${index}`}
            >
              <span className="ui-blast-radius__item-label">{item.label}</span>
              <span className="ui-blast-radius__item-detail">{item.detail}</span>
            </li>
          ))}
        </ul>
        {error !== undefined && error !== null ? (
          <p className="ui-blast-radius__error" role="alert">
            {error}
          </p>
        ) : null}
      </div>
    </ConfirmationDialog>
  );
}
