# NotificationBell

## Purpose

`NotificationBell` is the persistent header affordance that opens the
`ActivityCenter` and shows the current unread count. It pairs with the
`useNotifications` hook (`src/lib/notifications`) but owns no data itself, so any
app — Score, eLitua (S4), or another — can embed it against its own scope.

## Contract

- Controlled by `unreadCount` and `open`; clicks are delegated through `onClick`.
- Renders a numeric badge only when `unreadCount > 0`; totals above `max`
  (default 99) render as `{max}+`. Negative/fractional counts are clamped.
- Announces both the current unread state and the open/close action through a
  count-aware `aria-label` (state-first, then action; see SK ui-affordance).
  `label(unreadCount, open)` overrides the copy for localization.
- Exposes `aria-haspopup` (defaults to `"menu"`; pass `"dialog"` via the
  `haspopup` prop when the panel this bell opens is a real modal dialog),
  `aria-expanded`, and `aria-controls` (pass the panel id via `controlsId`) so
  the bell and panel form one disclosure widget.
- `size` (`sm` | `md`), `icon`, and `disabled` are prop-driven.
- Uses `ui-notification-bell*` classes and shared token variables only.

## Data / API boundary

- Consumes no service directly. The unread count comes from the
  `unread-count` SSE event / REST `GET /notifications/unread-count` surfaced by
  `useNotifications`; the bell just renders it.

## States

- **default** — count 0, no badge, panel closed.
- **unread** — badge with the count; `is-unread`.
- **overflow** — count above `max` renders `{max}+`.
- **open** — `is-open`, `aria-expanded=true` while the panel is shown.
- **disabled** — non-interactive.

## Non-Goals

- No fetching, polling, SSE subscription, panel state, routing, persistence,
  localization, or provider identity.
