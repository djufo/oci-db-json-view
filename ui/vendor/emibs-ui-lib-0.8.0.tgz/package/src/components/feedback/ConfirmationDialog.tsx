import { useId, type ReactNode } from "react";
import { AlertTriangle, X } from "lucide-react";
import { cn } from "../../lib";
import { Button } from "../primitives/Button";
import { Dialog } from "../primitives/overlay";

export type ConfirmationDialogTone = "danger" | "warning" | "info";
export type ConfirmationDialogPlacement = "fixed" | "contained";

export type ConfirmationDialogProps = {
  open: boolean;
  title: ReactNode;
  children?: ReactNode;
  tone?: ConfirmationDialogTone;
  icon?: ReactNode;
  cancelLabel?: ReactNode;
  confirmLabel?: ReactNode;
  busyLabel?: ReactNode;
  busy?: boolean;
  confirmDisabled?: boolean;
  placement?: ConfirmationDialogPlacement;
  className?: string;
  onCancel: () => void;
  onConfirm: () => void;
};

export function ConfirmationDialog({
  open,
  title,
  children,
  tone = "danger",
  icon,
  cancelLabel = "Cancel",
  confirmLabel = "Confirm",
  busyLabel = "Working",
  busy = false,
  confirmDisabled = false,
  placement = "fixed",
  className,
  onCancel,
  onConfirm,
}: ConfirmationDialogProps) {
  const titleId = useId();
  const bodyId = useId();
  const requestCancel = () => {
    if (!busy) onCancel();
  };
  const requestConfirm = () => {
    if (!busy && !confirmDisabled) onConfirm();
  };

  if (!open) {
    return null;
  }

  return (
    <Dialog
      open={open}
      onClose={requestCancel}
      chrome="bare"
      modal={placement === "fixed"}
      inline={placement === "contained"}
      backdropLabel="Cancel confirmation"
      backdropClassName="ui-confirmation-dialog__backdrop"
      className={cn("ui-confirmation-dialog__panel", `ui-confirmation-dialog__panel--${tone}`)}
      closeLabel="Close confirmation dialog"
      closeOnBackdrop={!busy}
      closeOnEscape={placement === "fixed" && !busy}
      layerClassName={cn("ui-confirmation-dialog", `ui-confirmation-dialog--${placement}`, className)}
      role="alertdialog"
      surfaceProps={{
        "aria-busy": busy || undefined,
        "aria-describedby": children ? bodyId : undefined,
        "aria-labelledby": titleId,
      }}
    >
        <div className="ui-confirmation-dialog__icon" aria-hidden="true">
          {icon ?? <AlertTriangle size={24} />}
        </div>
        <div className="ui-confirmation-dialog__copy">
          <h2 id={titleId}>{title}</h2>
          {children ? (
            <div className="ui-confirmation-dialog__body" id={bodyId}>
              {children}
            </div>
          ) : null}
        </div>
        <button
          aria-label="Close confirmation dialog"
          className="ui-confirmation-dialog__close"
          disabled={busy}
          onClick={requestCancel}
          type="button"
        >
          <X size={17} aria-hidden="true" />
        </button>
        <div className="ui-confirmation-dialog__actions">
          <Button disabled={busy} onClick={requestCancel} type="button" variant="secondary">
            {cancelLabel}
          </Button>
          {/*
            `disabled` and `busy` are different states (src/theme/STATES.md rule
            5): `disabled` removes interactivity and is not focusable; `busy`
            only dims and MUST stay focusable, announcing `aria-busy="true"`.
            `disabled={busy || confirmDisabled}` took the confirm button out of
            the tab order the moment it was pressed, which on an alertdialog is
            the worst possible place to lose focus — the user has just triggered
            a destructive mutation and cannot tab back to the control that
            reports how it went.

            Preventing a double submit is legitimate, but `disabled` is the wrong
            instrument for it: `requestConfirm` already refuses to re-fire while
            busy, which blocks re-entry without destroying focus. Only
            `confirmDisabled` — a caller saying the action is unavailable — may
            reach the DOM attribute. `Button.loading` supplies the rest of the
            busy state (aria-busy, still focusable, activation blocked); it also
            has to, because `Button` applies `aria-busy={loading || undefined}`
            after its prop spread and would overwrite one passed in from here.
          */}
          <Button
            disabled={confirmDisabled}
            loading={busy}
            loadingLabel={typeof busyLabel === "string" ? busyLabel : undefined}
            onClick={requestConfirm}
            type="button"
            variant={tone === "danger" ? "danger" : "primary"}
          >
            {busy ? busyLabel : confirmLabel}
          </Button>
        </div>
    </Dialog>
  );
}
