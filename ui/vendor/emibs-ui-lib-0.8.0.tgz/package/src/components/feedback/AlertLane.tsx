import { useState, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "../../lib";

/**
 * AlertLane (UIF-E3, generalized from Score v4 AlertLane). A compact row of live
 * findings rendered as dismissable chips, each coloured by severity (via the
 * emibs-theme/2 `--severity-*` tokens) and carrying an optional deep link to the
 * surface that resolves it.
 *
 * Dismissal is per-session by default (uncontrolled): a chip hidden here returns
 * on the next data snapshot if the finding is still open, so the lane never hides
 * a live problem permanently. Pass `dismissedIds` + `onDismiss` to own dismissal
 * externally. An empty (or fully dismissed) set renders a quiet "all clear" so
 * the lane's presence is never ambiguous.
 */

export type AlertSeverity = "info" | "warning" | "error" | "critical";

export type AlertLaneItem = {
  readonly id: string;
  readonly title: ReactNode;
  /** Longer text; used as the chip's title attribute when present. */
  readonly detail?: string;
  readonly severity?: AlertSeverity;
  /** Deep link to the resolving surface; renders the default arrow link. */
  readonly href?: string;
};

export type AlertLaneProps = {
  readonly alerts: readonly AlertLaneItem[];
  /** Controlled dismissal: fired with the alert id. When set, the lane does not track its own dismissals. */
  readonly onDismiss?: (id: string) => void;
  /** Controlled dismissed ids (pairs with `onDismiss`). */
  readonly dismissedIds?: readonly string[];
  /** Whether chips can be dismissed. Default true. */
  readonly dismissable?: boolean;
  /** Custom deep-link node per alert, replacing the default arrow link. */
  readonly renderLink?: (alert: AlertLaneItem) => ReactNode;
  /** Copy for the all-clear state. */
  readonly clearLabel?: ReactNode;
  readonly ariaLabel?: string;
  readonly className?: string;
};

export function AlertLane({
  alerts,
  onDismiss,
  dismissedIds,
  dismissable = true,
  renderLink,
  clearLabel = "No open findings",
  ariaLabel = "Active findings",
  className,
}: AlertLaneProps) {
  const [selfDismissed, setSelfDismissed] = useState<ReadonlySet<string>>(new Set());
  const controlled = onDismiss !== undefined || dismissedIds !== undefined;
  const dismissed = controlled ? new Set(dismissedIds ?? []) : selfDismissed;
  const visible = alerts.filter((alert) => !dismissed.has(alert.id));

  const handleDismiss = (id: string) => {
    onDismiss?.(id);
    if (!controlled) {
      setSelfDismissed((prev) => new Set([...prev, id]));
    }
  };

  if (visible.length === 0) {
    return (
      <div className={cn("ui-alert-lane", "ui-alert-lane--clear", className)} role="status">
        <span className="ui-alert-lane__chip ui-alert-lane__chip--clear">
          <i className="ui-alert-lane__dot" data-severity="clear" aria-hidden="true" />
          {clearLabel}
        </span>
      </div>
    );
  }

  return (
    <div className={cn("ui-alert-lane", className)} role="status" aria-label={ariaLabel}>
      {visible.map((alert) => {
        const severity = alert.severity ?? "info";
        return (
          <span
            className="ui-alert-lane__chip"
            data-severity={severity}
            key={alert.id}
            title={alert.detail ?? undefined}
          >
            <i className="ui-alert-lane__dot" data-severity={severity} aria-hidden="true" />
            <span className="ui-alert-lane__text">{alert.title}</span>
            {renderLink ? (
              <span className="ui-alert-lane__link">{renderLink(alert)}</span>
            ) : alert.href ? (
              <a className="ui-alert-lane__go" href={alert.href} aria-label="Open finding">
                →
              </a>
            ) : null}
            {dismissable ? (
              <button
                aria-label="Dismiss finding"
                className="ui-alert-lane__dismiss"
                onClick={() => handleDismiss(alert.id)}
                type="button"
              >
                <X size={13} aria-hidden="true" />
              </button>
            ) : null}
          </span>
        );
      })}
    </div>
  );
}
