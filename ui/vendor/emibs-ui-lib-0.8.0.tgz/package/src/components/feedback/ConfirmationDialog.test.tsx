// @vitest-environment happy-dom

import { act, createElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { ConfirmationDialog } from "./ConfirmationDialog";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

describe("ConfirmationDialog", () => {
  let container: HTMLDivElement;
  let root: Root;

  beforeEach(() => {
    container = document.createElement("div");
    document.body.append(container);
    root = createRoot(container);
  });

  afterEach(() => {
    act(() => root.unmount());
    container.remove();
    document.querySelectorAll("[data-ui-overlay-portal]").forEach((node) => node.remove());
    document.querySelectorAll("[data-confirmation-dialog-trigger]").forEach((node) => node.remove());
  });

  it("keeps its alertdialog labeling while busy", () => {
    act(() => {
      root.render(
        createElement(
          ConfirmationDialog,
          {
            busy: true,
            onCancel: vi.fn(),
            onConfirm: vi.fn(),
            open: true,
            title: "Delete attachment?",
          },
          "This cannot be undone.",
        ),
      );
    });

    const dialog = document.querySelector<HTMLElement>('[role="alertdialog"]');
    expect(dialog?.getAttribute("aria-busy")).toBe("true");
    expect(dialog?.getAttribute("aria-labelledby")).toBeTruthy();
    expect(dialog?.getAttribute("aria-describedby")).toBeTruthy();
  });

  // This test used to assert that BOTH action buttons carried the native
  // `disabled` attribute while busy — `[true, true]` — which is the defect
  // uif/issue-4684 fixed, written down as an expectation. `src/theme/STATES.md`
  // rule 5 makes `disabled` and `busy` different states: the confirm button is
  // the one performing the in-flight work, so it must stay FOCUSABLE and
  // announce `aria-busy="true"` while refusing re-entry in its handler.
  //
  // What is unchanged, and deliberately so: every path is still blocked, and the
  // cancel and close buttons — siblings locked while someone else's action is in
  // flight, not controls disabling themselves — keep their `disabled`.
  it("blocks every user dismissal and confirm path while busy", () => {
    const onCancel = vi.fn();
    const onConfirm = vi.fn();

    act(() => {
      root.render(
        createElement(ConfirmationDialog, {
          busy: true,
          onCancel,
          onConfirm,
          open: true,
          title: "Delete attachment?",
        }),
      );
    });

    const backdrop = document.querySelector<HTMLElement>("[data-ui-overlay-backdrop]");
    const close = document.querySelector<HTMLButtonElement>('[aria-label="Close confirmation dialog"]');
    const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>(".ui-confirmation-dialog__actions button"));

    act(() => {
      backdrop?.click();
      close?.click();
      buttons.forEach((button) => button.click());
      document.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Escape" }));
    });

    const [cancel, confirm] = buttons;

    expect(close?.disabled).toBe(true);
    expect(cancel.disabled).toBe(true);

    // The busy control itself stays reachable and announces its state.
    expect(confirm.disabled).toBe(false);
    expect(confirm.getAttribute("aria-busy")).toBe("true");
    confirm.focus();
    expect(document.activeElement).toBe(confirm);

    // Still blocked — by the handler guard, not by destroying focus.
    expect(onCancel).not.toHaveBeenCalled();
    expect(onConfirm).not.toHaveBeenCalled();
  });

  it("keeps the fixed-dialog focus trap and returns focus to its trigger", () => {
    const trigger = document.createElement("button");
    trigger.setAttribute("data-confirmation-dialog-trigger", "");
    trigger.textContent = "Delete attachment";
    document.body.append(trigger);
    trigger.focus();

    act(() => {
      root.render(
        createElement(ConfirmationDialog, {
          onCancel: vi.fn(),
          onConfirm: vi.fn(),
          open: true,
          title: "Delete attachment?",
        }),
      );
    });

    const dialog = document.querySelector<HTMLElement>('[role="alertdialog"]');
    const buttons = Array.from(document.querySelectorAll<HTMLButtonElement>(".ui-confirmation-dialog__actions button"));
    expect(dialog?.getAttribute("aria-modal")).toBe("true");

    act(() => {
      buttons.at(-1)?.focus();
      document.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Tab" }));
    });
    expect(document.activeElement?.getAttribute("aria-label")).toBe("Close confirmation dialog");

    act(() => root.render(null));
    expect(document.activeElement).toBe(trigger);
  });
});
