import { type ReactNode } from "react";
import { Bell, CheckCheck, Loader2, TriangleAlert } from "lucide-react";
import { cn } from "../../lib";

/**
 * Presentational shape of one inbox row. It is structurally a subset of the
 * service's `NotificationRecord`, so the `useNotifications` result drops in
 * directly, but ActivityCenter stays decoupled from the wire type.
 */
export type ActivityCenterItem = {
  id: string;
  title: ReactNode;
  body?: ReactNode;
  read: boolean;
  createdAt: string;
  link?: string;
  type?: string;
};

export type ActivityCenterStatus = "loading" | "ready" | "error";

export type ActivityCenterProps = {
  items: ActivityCenterItem[];
  /** Drives loading skeleton / error panel / list. Default `"ready"`. */
  status?: ActivityCenterStatus;
  /** Unread total shown in the header; when omitted it is derived from `items`. */
  unreadCount?: number;
  /** Error detail rendered in the error state. */
  error?: ReactNode;
  title?: ReactNode;
  /** Select a row. Rows with a `link` are anchors; selection typically marks read. */
  onItemSelect?: (item: ActivityCenterItem) => void;
  /** Show + handle the "Mark all read" action. Hidden when omitted. */
  onMarkAllRead?: () => void;
  /** Show + handle a retry control in the error state. */
  onRetry?: () => void;
  /** Show + handle a "Load older" control at the list foot. */
  onLoadMore?: () => void;
  hasMore?: boolean;
  loadingMore?: boolean;
  emptyLabel?: ReactNode;
  emptyDescription?: ReactNode;
  /** id applied to the panel root (pair with the bell's `controlsId`). */
  id?: string;
  /** Accessible label for the panel; ignored when `labelledBy` is given. */
  ariaLabel?: string;
  /** id of an external heading labelling the panel (overrides `ariaLabel`). */
  labelledBy?: string;
  /** Format an ISO timestamp for display. Defaults to a relative label. */
  formatTimestamp?: (iso: string) => string;
  className?: string;
};

/**
 * ActivityCenter — a controlled inbox panel (dropdown or drawer body) that lists
 * notifications newest-first with read/unread state, a "mark all read" action,
 * and explicit loading / error / empty states. It owns no data or transport;
 * drive it with the `useNotifications` hook and mount it inside the surface of
 * your choice.
 */
export function ActivityCenter({
  items,
  status = "ready",
  unreadCount,
  error,
  title = "Notifications",
  onItemSelect,
  onMarkAllRead,
  onRetry,
  onLoadMore,
  hasMore = false,
  loadingMore = false,
  emptyLabel = "You're all caught up",
  emptyDescription = "New notifications will appear here.",
  id,
  ariaLabel = "Notifications",
  labelledBy,
  formatTimestamp = defaultFormatTimestamp,
  className,
}: ActivityCenterProps) {
  const unread = unreadCount ?? items.filter((item) => !item.read).length;
  const headingId = labelledBy ?? (id ? `${id}-title` : undefined);

  return (
    <section
      id={id}
      className={cn("ui-activity-center", className)}
      role="group"
      aria-label={labelledBy ? undefined : ariaLabel}
      aria-labelledby={labelledBy}
    >
      <header className="ui-activity-center__header">
        <h2 className="ui-activity-center__title" id={headingId}>
          {title}
          {unread > 0 ? (
            <span className="ui-activity-center__unread-pill" aria-hidden="true">
              {unread}
            </span>
          ) : null}
        </h2>
        {onMarkAllRead ? (
          <button
            type="button"
            className="ui-activity-center__mark-all"
            onClick={onMarkAllRead}
            disabled={unread === 0 || status !== "ready"}
          >
            <CheckCheck size={15} aria-hidden="true" />
            Mark all read
          </button>
        ) : null}
      </header>

      <div className="ui-activity-center__body">
        {status === "loading" ? <ActivityCenterLoading /> : null}

        {status === "error" ? (
          <div className="ui-activity-center__state" role="alert">
            <TriangleAlert size={22} aria-hidden="true" className="ui-activity-center__state-icon" />
            <p className="ui-activity-center__state-title">Couldn't load notifications</p>
            {error ? <p className="ui-activity-center__state-detail">{error}</p> : null}
            {onRetry ? (
              <button type="button" className="ui-activity-center__retry" onClick={onRetry}>
                Try again
              </button>
            ) : null}
          </div>
        ) : null}

        {status === "ready" && items.length === 0 ? (
          <div className="ui-activity-center__state">
            <Bell size={22} aria-hidden="true" className="ui-activity-center__state-icon" />
            <p className="ui-activity-center__state-title">{emptyLabel}</p>
            {emptyDescription ? (
              <p className="ui-activity-center__state-detail">{emptyDescription}</p>
            ) : null}
          </div>
        ) : null}

        {status === "ready" && items.length > 0 ? (
          <>
            <ul className="ui-activity-center__list" aria-label={`Notifications, ${unread} unread`}>
              {items.map((item) => (
                <li key={item.id} className="ui-activity-center__row-wrap">
                  <ActivityCenterRow
                    item={item}
                    onSelect={onItemSelect}
                    formatTimestamp={formatTimestamp}
                  />
                </li>
              ))}
            </ul>
            {hasMore && onLoadMore ? (
              <button
                type="button"
                className="ui-activity-center__load-more"
                onClick={onLoadMore}
                disabled={loadingMore}
                aria-busy={loadingMore || undefined}
              >
                {loadingMore ? <Loader2 size={15} className="ui-activity-center__spinner" aria-hidden="true" /> : null}
                {loadingMore ? "Loading…" : "Load older"}
              </button>
            ) : null}
          </>
        ) : null}
      </div>
    </section>
  );
}

function ActivityCenterRow({
  item,
  onSelect,
  formatTimestamp,
}: {
  item: ActivityCenterItem;
  onSelect?: (item: ActivityCenterItem) => void;
  formatTimestamp: (iso: string) => string;
}) {
  const className = cn("ui-activity-center__row", !item.read && "is-unread");
  const inner = (
    <>
      <span
        className="ui-activity-center__dot"
        aria-hidden={item.read ? "true" : undefined}
      >
        {!item.read ? <span className="ui-activity-center__sr">Unread. </span> : null}
      </span>
      <span className="ui-activity-center__row-content">
        <span className="ui-activity-center__row-head">
          <span className="ui-activity-center__row-title">{item.title}</span>
          <time className="ui-activity-center__row-time" dateTime={item.createdAt}>
            {formatTimestamp(item.createdAt)}
          </time>
        </span>
        {item.body ? <span className="ui-activity-center__row-body">{item.body}</span> : null}
      </span>
    </>
  );

  // A row with a link is a real anchor so keyboard and assistive tech get native
  // navigation; selection (mark-read) still fires on activation. A row without a
  // link is a button that only marks read.
  if (item.link) {
    return (
      <a className={className} href={item.link} onClick={() => onSelect?.(item)}>
        {inner}
      </a>
    );
  }

  return (
    <button type="button" className={className} onClick={() => onSelect?.(item)}>
      {inner}
    </button>
  );
}

function ActivityCenterLoading() {
  return (
    <div className="ui-activity-center__loading" aria-busy="true" aria-live="polite">
      <span className="ui-activity-center__sr">Loading notifications…</span>
      {[0, 1, 2].map((row) => (
        <div key={row} className="ui-activity-center__skeleton" aria-hidden="true">
          <span className="ui-activity-center__skeleton-dot" />
          <span className="ui-activity-center__skeleton-lines">
            <span className="ui-activity-center__skeleton-line" />
            <span className="ui-activity-center__skeleton-line ui-activity-center__skeleton-line--short" />
          </span>
        </div>
      ))}
    </div>
  );
}

/** Compact relative timestamp; product apps can inject a localized formatter. */
function defaultFormatTimestamp(iso: string): string {
  const then = Date.parse(iso);
  if (Number.isNaN(then)) {
    return "";
  }
  const seconds = Math.round((Date.now() - then) / 1000);
  if (seconds < 45) {
    return "just now";
  }
  const minutes = Math.round(seconds / 60);
  if (minutes < 60) {
    return `${minutes}m ago`;
  }
  const hours = Math.round(minutes / 60);
  if (hours < 24) {
    return `${hours}h ago`;
  }
  const days = Math.round(hours / 24);
  if (days < 7) {
    return `${days}d ago`;
  }
  return new Date(then).toLocaleDateString();
}
