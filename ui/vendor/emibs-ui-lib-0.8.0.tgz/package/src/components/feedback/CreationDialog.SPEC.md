# CreationDialog

## Source Pressure

- Score `ui/src/features/board/containers/BoardContainer.tsx` contains a
  `NewIssueDialog` with responsive modal chrome, dense field grid, datalist
  controls, a boolean automation gate, multiline description, and cancel/create
  footer actions.
- Larger Score and eLitua shells, panels, details, dashboards, assets, and
  confirmation flows are already represented, so this extraction moves one level
  deeper into reusable modal creation forms.
- eLitua has comparable admin create/edit form pressure, but its current
  review-ready adoption target is already covered by `EditableFormPanel`; this
  component keeps the modal create pattern separate.

## Contract

- `CreationDialog` is controlled through `open`, `onClose`, and optional
  `onSubmit`.
- Consumers provide all field controls, draft state, validation, option loading,
  submit behavior, routing, persistence, toast handling, and localization.
- Sections render optional headings, descriptions, a responsive two-column field
  grid, freeform section content, badges, footer content, and default
  cancel/submit actions.
- `placement="fixed"` is for product modal use; `placement="contained"` is for
  catalog previews and embedded review surfaces.

## Accessibility

- The panel uses `role="dialog"`, generated title/body ids, and `aria-modal`
  for fixed placement.
- Fixed dialogs compose the shared `Dialog` overlay engine for focus trap, body
  scroll lock, top-most Escape handling, and focus return; Escape and backdrop
  close unless `submitting` is true.
- `submitting` is the dialog's busy state, which is not `disabled`
  (`src/theme/STATES.md` rule 5). While submitting, the submit button stays
  **focusable** and announces `aria-busy="true"`; re-submission is refused in
  the form's `onSubmit`, which also covers Enter pressed inside a field. Only
  `submitDisabled` takes the native `disabled` attribute.
- Required marks are visual hints only; consuming apps own native `required`
  attributes and validation messages on the supplied controls.

## Not Owned Here

- Task or record payload mapping.
- Permission checks, automation gate policy, route focus restoration, or audit
  events.
- Product-specific field schemas, option catalogs, translations, and
  submit-side effects.
