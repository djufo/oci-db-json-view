// Blast-radius model (UIF-E3, generalized from Score v4 G3 `blastRadius.ts`).
//
// Every consequential write should disclose its blast radius BEFORE it commits,
// and that disclosure must be COMPUTED from live data — never a hardcoded
// sentence. This module defines the presentation-free shape and the pure
// assembler that turns computed items into it. `BlastRadiusConfirm` renders
// whatever `BlastRadius` it is handed and embeds no counts or names of its own,
// so a confirm surface can never show a stale or fabricated impact.
//
// The library ships only the GENERIC assembler; domain builders that compute a
// specific impact (e.g. "disabling N of pool X") live in the consuming app
// beside its live data, and hand their result here.

/** Severity of a single consequence / the overall change. */
export type BlastSeverity = "info" | "warn" | "danger";

/** One itemised consequence, computed from live data by the caller. */
export type BlastImpactItem = {
  readonly label: string;
  readonly detail: string;
  readonly severity?: BlastSeverity;
};

/** A fully computed blast radius handed to `BlastRadiusConfirm`. */
export type BlastRadius = {
  /** One-line computed summary of the consequence. */
  readonly summary: string;
  /** Itemised consequences, each computed from live data. */
  readonly items: readonly BlastImpactItem[];
  /** Overall severity; drives the confirm surface accent + dialog tone. */
  readonly severity: BlastSeverity;
};

const SEVERITY_RANK: Record<BlastSeverity, number> = { info: 0, warn: 1, danger: 2 };

/** The worst severity across a set of items (`info` when empty). */
export function maxBlastSeverity(items: readonly BlastImpactItem[]): BlastSeverity {
  let worst: BlastSeverity = "info";
  for (const item of items) {
    const severity = item.severity ?? "info";
    if (SEVERITY_RANK[severity] > SEVERITY_RANK[worst]) {
      worst = severity;
    }
  }
  return worst;
}

/**
 * Assemble a `BlastRadius` from a computed summary and its items. The overall
 * severity is derived from the items so it can never disagree with what is
 * shown. This is the single generic assembler; a domain builder computes the
 * `summary`/`items` from live rows and calls this.
 */
export function blastRadius(summary: string, items: readonly BlastImpactItem[]): BlastRadius {
  return { summary, items, severity: maxBlastSeverity(items) };
}
