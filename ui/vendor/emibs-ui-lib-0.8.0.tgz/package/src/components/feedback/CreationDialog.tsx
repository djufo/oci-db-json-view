import { useId, type FormEvent, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { Button } from "../primitives/Button";
import { Dialog } from "../primitives/overlay";

export type CreationDialogPlacement = "fixed" | "contained";

export type CreationDialogBadge = {
  id: string;
  label: ReactNode;
  tone?: BadgeTone;
  icon?: ReactNode;
};

export type CreationDialogField = {
  id: string;
  label: ReactNode;
  control: ReactNode;
  hint?: ReactNode;
  required?: boolean;
  wide?: boolean;
};

export type CreationDialogSection = {
  id: string;
  title?: ReactNode;
  description?: ReactNode;
  fields?: CreationDialogField[];
  children?: ReactNode;
};

export type CreationDialogProps = {
  open: boolean;
  title: ReactNode;
  eyebrow?: ReactNode;
  description?: ReactNode;
  badges?: CreationDialogBadge[];
  sections?: CreationDialogSection[];
  children?: ReactNode;
  footer?: ReactNode;
  cancelLabel?: ReactNode;
  submitLabel?: ReactNode;
  submittingLabel?: ReactNode;
  submitting?: boolean;
  submitDisabled?: boolean;
  placement?: CreationDialogPlacement;
  className?: string;
  onClose: () => void;
  onSubmit?: (event: FormEvent<HTMLFormElement>) => void;
};

export function CreationDialog({
  open,
  title,
  eyebrow,
  description,
  badges = [],
  sections = [],
  children,
  footer,
  cancelLabel = "Cancel",
  submitLabel = "Create",
  submittingLabel = "Creating",
  submitting = false,
  submitDisabled = false,
  placement = "fixed",
  className,
  onClose,
  onSubmit,
}: CreationDialogProps) {
  const titleId = useId();
  const descriptionId = useId();
  const hasBody = Boolean(description || children);

  // `submitting` is this dialog's busy flag, and `busy` is not `disabled`
  // (src/theme/STATES.md rule 5): the submit button must stay focusable and
  // announce `aria-busy="true"` rather than leaving the tab order the moment it
  // is pressed. Re-submission is refused here instead, which also covers Enter
  // pressed inside a field — a path the button's own guard never sees.
  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    if (submitting) {
      event.preventDefault();
      return;
    }
    onSubmit?.(event);
  };

  if (!open) {
    return null;
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      chrome="bare"
      modal={placement === "fixed"}
      inline={placement === "contained"}
      backdropLabel="Close creation dialog"
      backdropClassName="ui-creation-dialog__backdrop"
      className="ui-creation-dialog__panel"
      closeLabel="Close creation dialog"
      closeOnBackdrop={!submitting}
      closeOnEscape={placement === "fixed" && !submitting}
      layerClassName={cn("ui-creation-dialog", `ui-creation-dialog--${placement}`, className)}
      role="dialog"
      surfaceProps={{
        "aria-describedby": hasBody ? descriptionId : undefined,
        "aria-labelledby": titleId,
      }}
    >
        <header className="ui-creation-dialog__header">
          <div className="ui-creation-dialog__title-block">
            {eyebrow ? <span className="ui-creation-dialog__eyebrow">{eyebrow}</span> : null}
            <h2 id={titleId}>{title}</h2>
            {description ? <p id={descriptionId}>{description}</p> : null}
          </div>
          <div className="ui-creation-dialog__header-actions">
            {badges.length > 0 ? (
              <div className="ui-creation-dialog__badges" aria-label="Creation dialog badges">
                {badges.map((badge) => (
                  <Badge key={badge.id} tone={badge.tone ?? "neutral"}>
                    {badge.icon ? <span aria-hidden="true">{badge.icon}</span> : null}
                    {badge.label}
                  </Badge>
                ))}
              </div>
            ) : null}
            <button
              aria-label="Close creation dialog"
              className="ui-creation-dialog__close"
              disabled={submitting}
              onClick={onClose}
              type="button"
            >
              <X size={17} aria-hidden="true" />
            </button>
          </div>
        </header>

        <form className="ui-creation-dialog__form" onSubmit={handleSubmit}>
          {sections.map((section) => (
            <section className="ui-creation-dialog__section" key={section.id}>
              {section.title || section.description ? (
                <header className="ui-creation-dialog__section-header">
                  {section.title ? <h3>{section.title}</h3> : null}
                  {section.description ? <p>{section.description}</p> : null}
                </header>
              ) : null}
              {section.fields && section.fields.length > 0 ? (
                <div className="ui-creation-dialog__grid">
                  {section.fields.map((field) => (
                    <label
                      className={cn("ui-creation-dialog__field", field.wide && "is-wide")}
                      key={field.id}
                    >
                      <span className="ui-creation-dialog__field-label">
                        <strong>{field.label}</strong>
                        {field.required ? <span aria-label="required">*</span> : null}
                      </span>
                      {field.control}
                      {field.hint ? <small>{field.hint}</small> : null}
                    </label>
                  ))}
                </div>
              ) : null}
              {section.children ? <div className="ui-creation-dialog__section-body">{section.children}</div> : null}
            </section>
          ))}

          {children ? (
            <div className="ui-creation-dialog__body" id={description ? undefined : descriptionId}>
              {children}
            </div>
          ) : null}

          <div className="ui-creation-dialog__actions">
            <Button disabled={submitting} onClick={onClose} type="button" variant="secondary">
              {cancelLabel}
            </Button>
            <Button
              disabled={submitDisabled}
              loading={submitting}
              loadingLabel={typeof submittingLabel === "string" ? submittingLabel : undefined}
              type="submit"
            >
              {submitting ? submittingLabel : submitLabel}
            </Button>
          </div>
        </form>

        {footer ? <footer className="ui-creation-dialog__footer">{footer}</footer> : null}
    </Dialog>
  );
}
