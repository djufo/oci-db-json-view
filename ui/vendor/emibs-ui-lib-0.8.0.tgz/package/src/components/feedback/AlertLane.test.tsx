import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { AlertLane, type AlertLaneItem } from "./AlertLane";

const ALERTS: AlertLaneItem[] = [
  { id: "a1", title: "Scheduler tick stale", severity: "critical", href: "#/runtime", detail: "no tick for 12m" },
  { id: "a2", title: "Doctor: orphan rotation", severity: "warning" },
];

describe("AlertLane", () => {
  it("renders the all-clear state for an empty set", () => {
    const html = renderToStaticMarkup(<AlertLane alerts={[]} clearLabel="All clear" />);
    expect(html).toContain("ui-alert-lane--clear");
    expect(html).toContain("All clear");
  });

  it("stamps each chip with its severity for token colouring", () => {
    const html = renderToStaticMarkup(<AlertLane alerts={ALERTS} />);
    expect(html).toContain('data-severity="critical"');
    expect(html).toContain('data-severity="warning"');
    expect(html).toContain("Scheduler tick stale");
  });

  it("renders a deep link when href is present", () => {
    const html = renderToStaticMarkup(<AlertLane alerts={[ALERTS[0]]} />);
    expect(html).toContain('href="#/runtime"');
  });

  it("respects a controlled dismissed set", () => {
    const html = renderToStaticMarkup(<AlertLane alerts={ALERTS} dismissedIds={["a1"]} onDismiss={() => undefined} />);
    expect(html).not.toContain("Scheduler tick stale");
    expect(html).toContain("Doctor: orphan rotation");
  });

  it("uses a custom deep-link slot when provided", () => {
    const html = renderToStaticMarkup(
      <AlertLane alerts={[ALERTS[1]]} renderLink={(alert) => <span data-testid="slot">go {alert.id}</span>} />,
    );
    expect(html).toContain('data-testid="slot"');
    expect(html).toContain("go a2");
  });
});
