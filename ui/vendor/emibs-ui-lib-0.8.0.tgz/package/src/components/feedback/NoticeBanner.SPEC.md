# NoticeBanner

## Purpose

`NoticeBanner` is a presentational inline status surface for persistent messages
inside pages, panels, forms, and route states.

## Contract

- Renders a tone-aware banner with optional icon, title, body, action slot, and
  dismiss control.
- Supports neutral, info, success, warning, danger, accent, and loading tones,
  plus comfortable and compact density.
- Uses `role="alert"` for warning/danger by default and `role="status"` for
  other tones; consumers may override `role` or `aria-live` when a product flow
  has stricter accessibility requirements.
- Product apps own message creation, localization, validation, auth/routing
  behavior, toast queues, persistence, timers, and analytics.
- Uses `ui-notice-banner*` CSS classes and shared token variables only.

## Source Evidence

- Score `ui/src/app-shell/AppShell.tsx`,
  `ui/src/features/board/containers/BoardContainer.tsx`,
  `ui/src/features/admin/components/AdminDashboard.tsx`, and
  `ui/src/features/projects/containers/ProjectPage.tsx` repeat inline loading,
  no-access, error, and save-state notices separate from transient toasts.
- eLitua `ui/src/pages/client/accms/AccmsPage.tsx`,
  `ui/src/pages/client/guides/GuidesPage.tsx`,
  `ui/src/pages/client/places/PlacesPage.tsx`,
  `ui/src/pages/account/user-profile/UserProfilePage.tsx`,
  `ui/src/pages/account/guide-profile/GuideProfilePage.tsx`, and
  `ui/src/pages/account/bokun/BókunPage.tsx` repeat dismissible errors,
  verification prompts, success banners, and integration status messages.

## Non-Goals

- No toast timing, message queue management, API error mapping, redirect policy,
  form validation, session refresh, or provider SDK behavior.
- No product-specific copy, localization keys, or persistence.

## Review Expectations

- Long titles, error details, and action labels wrap without overlapping on
  mobile and inside dense admin panels.
- Dismiss and action controls remain reachable and stable when the banner body
  spans multiple lines.
