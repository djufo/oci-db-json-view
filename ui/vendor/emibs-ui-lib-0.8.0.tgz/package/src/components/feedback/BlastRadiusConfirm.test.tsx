import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { BlastRadiusConfirm } from "./BlastRadiusConfirm";
import { blastRadius } from "./blastRadius";

const IMPACT = blastRadius("Disable pool score", [
  { label: "Lanes stopped", detail: "Disabling 3 of 4 lanes in pool score.", severity: "danger" },
  { label: "Affected lanes", detail: "a, b, c", severity: "warn" },
]);

// Contained placement renders inline (no portal) so it is server-renderable.
describe("BlastRadiusConfirm", () => {
  it("renders nothing when closed", () => {
    const html = renderToStaticMarkup(
      <BlastRadiusConfirm open={false} impact={IMPACT} confirmLabel="Disable pool" onCancel={() => undefined} onConfirm={() => undefined} placement="contained" />,
    );
    expect(html).toBe("");
  });

  it("renders only the computed impact items it is handed", () => {
    const html = renderToStaticMarkup(
      <BlastRadiusConfirm open impact={IMPACT} confirmLabel="Disable pool" onCancel={() => undefined} onConfirm={() => undefined} placement="contained" />,
    );
    expect(html).toContain("Disabling 3 of 4 lanes in pool score.");
    expect(html).toContain("Affected lanes");
    // Default title is the computed summary.
    expect(html).toContain("Disable pool score");
  });

  it("maps overall severity to the danger dialog tone", () => {
    const html = renderToStaticMarkup(
      <BlastRadiusConfirm open impact={IMPACT} confirmLabel="Disable pool" onCancel={() => undefined} onConfirm={() => undefined} placement="contained" />,
    );
    expect(html).toContain("ui-blast-radius--danger");
    expect(html).toContain("ui-confirmation-dialog__panel--danger");
  });

  it("surfaces a verbatim server error through the error slot", () => {
    const html = renderToStaticMarkup(
      <BlastRadiusConfirm
        open
        impact={IMPACT}
        confirmLabel="Disable pool"
        onCancel={() => undefined}
        onConfirm={() => undefined}
        error="403: model literal rejected by drift guard"
        placement="contained"
      />,
    );
    expect(html).toContain('role="alert"');
    expect(html).toContain("403: model literal rejected by drift guard");
  });

  it("uses an info tone for an all-informational impact", () => {
    const info = blastRadius("Re-band to 0", [{ label: "Already at target", detail: "2 unchanged.", severity: "info" }]);
    const html = renderToStaticMarkup(
      <BlastRadiusConfirm open impact={info} confirmLabel="Re-band" onCancel={() => undefined} onConfirm={() => undefined} placement="contained" />,
    );
    expect(html).toContain("ui-blast-radius--info");
  });
});
