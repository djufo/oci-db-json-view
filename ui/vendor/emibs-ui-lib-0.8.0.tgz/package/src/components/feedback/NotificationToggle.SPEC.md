# NotificationToggle

## Goal

Provide a controlled notification opt-in action for task updates, saved-search
alerts, digest enrollment, and similar user-owned notification preferences.

## Source Pressure

- Score `ui/src/features/board/components/TaskDetail.tsx` renders a task detail
  header action that toggles the current actor's email subscription using
  Bell/BellOff icon states and subscribed/unsubscribed labels.
- Score owns both dialog and standalone task detail surfaces, so the same
  notification action needs compact and comfortable densities without owning the
  task subscription API.

## Contract

- `NotificationToggle` is controlled by the `subscribed` prop and emits the next
  subscribed value through `onChange`.
- Default labels state the current notification outcome before the short reverse
  action: unsubscribed is "You will not be notified — Notify me on updates" and
  subscribed is "You will be notified — Stop notifications". Custom labels
  remain available for product localization and must retain that state-first,
  outcome-then-action wording.
- Labels, descriptions, status/count text, icons, density, busy, and disabled
  state are prop-driven.
- The button exposes `aria-pressed` for the selected state and `aria-busy` while
  the consuming app persists the preference.
- `busy` and `disabled` are the distinct states `src/theme/STATES.md` rule 5
  defines, and are never collapsed into one attribute. `disabled` takes the
  native `disabled` attribute: not interactive, not focusable. `busy` dims to
  `--state-busy-opacity` and **stays focusable**, announcing `aria-busy="true"`,
  so a keyboard user does not lose the control at the moment they activate it;
  re-entry is blocked in the click handler instead, so a click while busy emits
  nothing. Per rule 4, `disabled` outranks `busy` when both are set.

## Non-Goals

- No task lookup, actor lookup, email delivery, digest policy, persistence,
  permission check, toast, localization, or route behavior.

## Review Expectations

- Compact mode must fit task-detail header action rows.
- Comfortable mode must support explanatory copy and subscriber/status metadata.
