import { useId, type ReactNode } from "react";
import { X } from "lucide-react";
import { cn } from "../../lib";
import { Badge, type BadgeTone } from "../primitives/Badge";
import { Dialog } from "../primitives/overlay";

export type DialogFramePlacement = "fixed" | "contained";
export type DialogFrameSize = "sm" | "md" | "lg" | "xl";

export type DialogFrameProps = {
  open: boolean;
  title: ReactNode;
  eyebrow?: ReactNode;
  subtitle?: ReactNode;
  status?: ReactNode;
  statusTone?: BadgeTone;
  actions?: ReactNode;
  footer?: ReactNode;
  children?: ReactNode;
  placement?: DialogFramePlacement;
  size?: DialogFrameSize;
  showClose?: boolean;
  closeLabel?: string;
  closeOnBackdrop?: boolean;
  busy?: boolean;
  className?: string;
  panelClassName?: string;
  bodyClassName?: string;
  onClose: () => void;
};

export function DialogFrame({
  open,
  title,
  eyebrow,
  subtitle,
  status,
  statusTone,
  actions,
  footer,
  children,
  placement = "fixed",
  size = "lg",
  showClose = true,
  closeLabel = "Close dialog",
  closeOnBackdrop = true,
  busy = false,
  className,
  panelClassName,
  bodyClassName,
  onClose,
}: DialogFrameProps) {
  const titleId = useId();
  const subtitleId = useId();

  if (!open) {
    return null;
  }

  return (
    <Dialog
      open={open}
      onClose={onClose}
      chrome="bare"
      modal={placement === "fixed"}
      inline={placement === "contained"}
      backdropLabel={closeLabel}
      backdropClassName="ui-dialog-frame__backdrop"
      closeLabel={closeLabel}
      closeOnBackdrop={closeOnBackdrop && !busy}
      closeOnEscape={placement === "fixed" && !busy}
      layerClassName={cn("ui-dialog-frame", `ui-dialog-frame--${placement}`, className)}
      role="dialog"
      surfaceProps={{
        "aria-describedby": subtitle ? subtitleId : undefined,
        "aria-labelledby": titleId,
      }}
    >
      <section
        className={cn("ui-dialog-frame__panel", `ui-dialog-frame__panel--${size}`, panelClassName)}
        role="presentation"
      >
        <header className="ui-dialog-frame__header">
          <div className="ui-dialog-frame__title-block">
            {eyebrow ? <span className="ui-dialog-frame__eyebrow">{eyebrow}</span> : null}
            <div className="ui-dialog-frame__title-row">
              <h2 id={titleId}>{title}</h2>
              {status ? (
                statusTone ? (
                  <Badge tone={statusTone}>{status}</Badge>
                ) : (
                  <span className="ui-dialog-frame__status">{status}</span>
                )
              ) : null}
            </div>
            {subtitle ? <p id={subtitleId}>{subtitle}</p> : null}
          </div>
          {actions || showClose ? (
            <div className="ui-dialog-frame__header-actions">
              {actions}
              {showClose ? (
                <button
                  aria-label={closeLabel}
                  className="ui-dialog-frame__close"
                  disabled={busy}
                  onClick={onClose}
                  type="button"
                >
                  <X size={17} aria-hidden="true" />
                </button>
              ) : null}
            </div>
          ) : null}
        </header>

        {children ? <div className={cn("ui-dialog-frame__body", bodyClassName)}>{children}</div> : null}

        {footer ? <footer className="ui-dialog-frame__footer">{footer}</footer> : null}
      </section>
    </Dialog>
  );
}
