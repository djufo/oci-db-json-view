import { AlertTriangle, CheckCircle2, Inbox, Info, LoaderCircle } from "lucide-react";
import { useId, type ReactNode } from "react";
import { cn } from "../../lib/cn";

export type DataStatePanelTone = "loading" | "empty" | "info" | "success" | "warning" | "danger";
export type DataStatePanelDensity = "comfortable" | "compact";
export type DataStatePanelAlign = "center" | "start";

export type DataStatePanelProps = {
  title: ReactNode;
  eyebrow?: ReactNode;
  description?: ReactNode;
  tone?: DataStatePanelTone;
  icon?: ReactNode;
  actions?: ReactNode;
  footer?: ReactNode;
  density?: DataStatePanelDensity;
  align?: DataStatePanelAlign;
  className?: string;
  children?: ReactNode;
  role?: "status" | "alert";
  live?: "off" | "polite" | "assertive";
};

export function DataStatePanel({
  title,
  eyebrow,
  description,
  tone = "info",
  icon,
  actions,
  footer,
  density = "comfortable",
  align = "center",
  className,
  children,
  role,
  live,
}: DataStatePanelProps) {
  const titleId = useId();
  const bodyId = useId();
  const hasBody = Boolean(description || children);
  const loadingBody = tone === "loading" && !description && Boolean(children);
  const semanticRole = role ?? (tone === "danger" || tone === "warning" ? "alert" : "status");
  const liveMode = live ?? (semanticRole === "alert" ? "assertive" : "polite");

  return (
    <section
      aria-describedby={hasBody && !loadingBody ? bodyId : undefined}
      aria-labelledby={titleId}
      aria-live={liveMode}
      aria-busy={tone === "loading" ? true : undefined}
      className={cn(
        "ui-data-state",
        `ui-data-state--${tone}`,
        `ui-data-state--${density}`,
        `ui-data-state--${align}`,
        className
      )}
      role={semanticRole}
    >
      <div className="ui-data-state__icon" aria-hidden="true">
        {icon ?? <DataStatePanelIcon tone={tone} />}
      </div>
      <header className="ui-data-state__header">
        {eyebrow ? <span className="ui-data-state__eyebrow">{eyebrow}</span> : null}
        <h2 id={titleId}>{title}</h2>
        {description ? <p id={bodyId}>{description}</p> : null}
      </header>
      {children ? (
        <div
          aria-hidden={loadingBody ? true : undefined}
          className="ui-data-state__body"
          id={description ? undefined : bodyId}
        >
          {children}
        </div>
      ) : null}
      {actions ? <div className="ui-data-state__actions">{actions}</div> : null}
      {footer ? <footer className="ui-data-state__footer">{footer}</footer> : null}
    </section>
  );
}

function DataStatePanelIcon({ tone }: { tone: DataStatePanelTone }) {
  if (tone === "loading") {
    return <LoaderCircle size={26} />;
  }
  if (tone === "success") {
    return <CheckCircle2 size={26} />;
  }
  if (tone === "warning" || tone === "danger") {
    return <AlertTriangle size={26} />;
  }
  if (tone === "empty") {
    return <Inbox size={26} />;
  }
  return <Info size={26} />;
}
