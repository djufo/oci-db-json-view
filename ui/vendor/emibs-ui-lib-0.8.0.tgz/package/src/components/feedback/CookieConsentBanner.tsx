import { useId, type ReactNode } from "react";
import { Cookie } from "lucide-react";
import { cn } from "../../lib";

export type CookieConsentCategory = {
  id: string;
  label: ReactNode;
  description: ReactNode;
  checked: boolean;
  locked?: boolean;
  onChange?: (checked: boolean) => void;
};

export type CookieConsentTone = "surface" | "inverse";

export type CookieConsentBannerProps = {
  title: ReactNode;
  description: ReactNode;
  categories?: CookieConsentCategory[];
  preferencesOpen?: boolean;
  preferencesTitle?: ReactNode;
  preferencesDescription?: ReactNode;
  preferencesLabel?: string;
  icon?: ReactNode;
  learnMore?: ReactNode;
  manageLabel?: ReactNode;
  rejectLabel?: ReactNode;
  acceptAllLabel?: ReactNode;
  cancelLabel?: ReactNode;
  saveLabel?: ReactNode;
  showManageAction?: boolean;
  showRejectAction?: boolean;
  showAcceptAllAction?: boolean;
  dock?: "fixed" | "contained";
  tone?: CookieConsentTone;
  onPreferencesOpenChange?: (open: boolean) => void;
  onAcceptAll?: () => void;
  onRejectNonEssential?: () => void;
  onSavePreferences?: () => void;
  className?: string;
};

export function CookieConsentBanner({
  title,
  description,
  categories = [],
  preferencesOpen = false,
  preferencesTitle = "Cookie preferences",
  preferencesDescription = "Choose which optional categories the consuming app should enable.",
  preferencesLabel = "Cookie preferences",
  icon,
  learnMore,
  manageLabel = "Manage preferences",
  rejectLabel = "Reject non-essential",
  acceptAllLabel = "Accept all",
  cancelLabel = "Cancel",
  saveLabel = "Save preferences",
  showManageAction,
  showRejectAction = true,
  showAcceptAllAction = true,
  dock = "fixed",
  tone = "surface",
  onPreferencesOpenChange,
  onAcceptAll,
  onRejectNonEssential,
  onSavePreferences,
  className,
}: CookieConsentBannerProps) {
  const titleId = useId();
  const preferencesId = useId();
  const hasCategories = categories.length > 0;
  const canManagePreferences = showManageAction ?? (hasCategories || Boolean(onPreferencesOpenChange));
  const showPreferencesPanel = preferencesOpen && canManagePreferences && hasCategories;

  return (
    <section
      className={cn("ui-cookie-consent", `ui-cookie-consent--${dock}`, `ui-cookie-consent--tone-${tone}`, className)}
      role="dialog"
      aria-labelledby={titleId}
      aria-modal="false"
    >
      {showPreferencesPanel ? (
        <div className="ui-cookie-consent__preferences" id={preferencesId} role="region" aria-label={preferencesLabel}>
          <div className="ui-cookie-consent__preferences-header">
            <h3>{preferencesTitle}</h3>
            {preferencesDescription ? <p>{preferencesDescription}</p> : null}
          </div>
          <div className="ui-cookie-consent__preference-list">
            {categories.map((category) => (
              <CookieConsentPreferenceRow key={category.id} category={category} />
            ))}
          </div>
          <div className="ui-cookie-consent__preferences-actions">
            <button
              type="button"
              className="ui-cookie-consent__button ui-cookie-consent__button--ghost"
              onClick={() => onPreferencesOpenChange?.(false)}
            >
              {cancelLabel}
            </button>
            <button type="button" className="ui-cookie-consent__button ui-cookie-consent__button--primary" onClick={onSavePreferences}>
              {saveLabel}
            </button>
          </div>
        </div>
      ) : null}

      <div className="ui-cookie-consent__banner">
        <div className="ui-cookie-consent__copy">
          <span className="ui-cookie-consent__icon" aria-hidden="true">
            {icon ?? <Cookie size={22} />}
          </span>
          <div>
            <h2 id={titleId}>{title}</h2>
            <p>
              {description}
              {learnMore ? <> {learnMore}</> : null}
            </p>
          </div>
        </div>
        <div className="ui-cookie-consent__actions">
          {canManagePreferences ? (
            <button
              type="button"
              className="ui-cookie-consent__button ui-cookie-consent__button--ghost"
              aria-expanded={preferencesOpen}
              aria-controls={hasCategories ? preferencesId : undefined}
              onClick={() => onPreferencesOpenChange?.(!preferencesOpen)}
            >
              {manageLabel}
            </button>
          ) : null}
          {showRejectAction ? (
            <button type="button" className="ui-cookie-consent__button ui-cookie-consent__button--outline" onClick={onRejectNonEssential}>
              {rejectLabel}
            </button>
          ) : null}
          {showAcceptAllAction ? (
            <button type="button" className="ui-cookie-consent__button ui-cookie-consent__button--primary" onClick={onAcceptAll}>
              {acceptAllLabel}
            </button>
          ) : null}
        </div>
      </div>
    </section>
  );
}

export function CookieConsentPreferenceRow({ category }: { category: CookieConsentCategory }) {
  const inputId = useId();

  return (
    <label className={cn("ui-cookie-consent__preference-row", category.locked && "is-locked")} htmlFor={inputId}>
      <span className="ui-cookie-consent__preference-copy">
        <strong>{category.label}</strong>
        <small>{category.description}</small>
      </span>
      <span className="ui-cookie-consent__toggle">
        <input
          id={inputId}
          type="checkbox"
          checked={category.checked}
          disabled={category.locked}
          onChange={(event) => category.onChange?.(event.target.checked)}
        />
        <span className="ui-cookie-consent__toggle-track">
          <span className="ui-cookie-consent__toggle-thumb" />
        </span>
      </span>
    </label>
  );
}
