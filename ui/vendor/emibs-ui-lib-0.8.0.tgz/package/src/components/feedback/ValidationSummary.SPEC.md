# ValidationSummary

## Purpose

`ValidationSummary` is a presentational form-feedback surface for grouped
validation issues and success/ready states before or after submit.

## Source Evidence

- eLitua `ui/src/pages/account/bokun/BókunPage.tsx` and
  `ui/src/pages/account/guide-profile/GuideProfilePage.tsx` repeat
  form-level success/error rows above editable profile and integration forms.
- eLitua auth forms render password and required-field feedback near form
  controls while keeping password analysis and auth service calls local.
- Score `ui/src/features/settings/containers/SettingsContainer.tsx`,
  `ui/src/features/board/containers/BoardContainer.tsx`, and admin editor
  surfaces keep JSON/form validation, required fields, and datalist-backed
  routing inputs local.
- Existing catalog coverage was checked first: `NoticeBanner` owns general
  page notices and `CreationDialog`/`EditableFormPanel` own form layout slots,
  but no shared component owns a navigable list of field validation issues.

## Contract

- Renders a title, optional description, action, footer, and ordered list of
  validation items.
- Items support label, message, tone, direct `href`, or `controlId` anchor
  linkage so consuming apps can route focus without moving validation logic
  into the shared component.
- Supports danger, warning, info, and success tones plus compact and comfortable
  densities.

## Non-Goals

- No validation schema, form state, field focus management, submit behavior, API
  error mapping, translation lookup, timers, or toast delivery.
