# CookieConsentBanner

## Source pressure

- eLitua has a GDPR/ePrivacy cookie-consent surface in
  `/engineering/projects/elitua/ui/src/features/cookieConsent/`.
- The larger public portal, legal page, profile, editorial, map, payment,
  integration, auth, and form shells are already represented in the catalog, so
  this extraction moves down to the next reusable compliance control.

## Contract

- `CookieConsentBanner` is presentational and controlled by props.
- Consuming apps own persistence, consent versioning, analytics/marketing SDK
  activation, route links, localization, and re-opening preferences from account
  or privacy pages.
- `categories` render controlled toggle rows; locked rows are disabled and stay
  visually distinct.
- `showManageAction`, `showRejectAction`, and `showAcceptAllAction` let apps
  present either a full managed-preferences flow or a simpler accept-all /
  essential-only banner.
- `tone="inverse"` captures eLitua's compact dark cookie notice while preserving
  the same controlled action contract.
- `dock="fixed"` supports product use at the viewport bottom;
  `dock="contained"` supports catalog and embedded review surfaces.

## Accessibility

- The banner uses `role="dialog"`, an explicit title id, and `aria-modal=false`.
- The preferences panel uses a labelled `role="region"`.
- The manage button reflects preference-panel state with `aria-expanded` and
  `aria-controls`.
- When the manage action is hidden for simple banners, the remaining action
  buttons keep normal button semantics and the dialog title still labels the
  banner.
- Toggle inputs stay native checkboxes for keyboard and assistive-technology
  behavior.

## Not Owned Here

- Cookie storage keys and schema.
- Consent decision enums.
- Server-side consent signalling.
- Consent re-prompting on policy changes.
- Jurisdiction-specific legal text.
