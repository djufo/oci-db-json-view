# AlertLane

## Purpose

`AlertLane` is a compact row of live findings — sentinel / doctor / validation
alerts — rendered as severity-coloured, dismissable chips, each with an optional
deep link to the surface that resolves it. An empty set renders a quiet
all-clear so the lane is never ambiguous.

## Source Evidence

- Score `requirements/v4/ui` (SPEC V4-1): the shell's alert lane shows
  sentinel/doctor findings as dismissable chips with deep links; dismissal is
  per-session, so a finding returns on the next snapshot if still open — the lane
  never hides a live problem permanently.
- Score's v4 `AlertLane.tsx` reads `/api/status` findings and dismisses locally.
  This library version keeps the per-session default but adds a controlled
  dismissal contract and a deep-link slot.

## Contract

- `alerts: AlertLaneItem[]` (`{ id, title, detail?, severity?, href? }`).
  Severity (`info`/`warning`/`error`/`critical`) colours the dot and chip edge
  through the emibs-theme/2 `--severity-*` tokens.
- Dismissal is uncontrolled by default (per-session hide). Pass `dismissedIds` +
  `onDismiss` to own it externally; `dismissable={false}` removes the control.
- Deep link: `href` renders the default arrow link, or `renderLink(alert)`
  supplies a custom node (a routed `<Link>`, a button, etc.).
- Empty or fully-dismissed set renders the all-clear chip with `clearLabel`.

## Boundaries

- No fetching, polling, or finding computation; it renders the alerts it is
  handed. Re-surfacing on the next snapshot is the app's data cycle, not a timer
  here.
- Not a toast/notification system (`ToastStack`) and not a full incident panel;
  it is a one-line lane of current findings.

## Review Checks

- Each chip carries `data-severity` so colour is token-driven, never inline hex.
- Dismiss is keyboard reachable and labelled.
- The all-clear state renders whenever nothing is visible, controlled or not.
