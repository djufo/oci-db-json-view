# DataStatePanel

## Purpose

`DataStatePanel` is a generic, non-auth route/data state shell for loading,
empty, not-found, success, warning, and error outcomes. It fills the gap between
auth-specific status cards, inline notice banners, and empty-only placeholders
without owning a card/panel surface.

## Source Evidence

- Score `ui/src/features/settings/containers/SettingsContainer.tsx` renders a
  loading card before runtime settings are available.
- Score `ui/src/features/board/components/TaskDetail.tsx` repeats loading copy
  while task detail data resolves.
- eLitua `ui/src/pages/client/guides/GuidePublicProfilePage/GuideProfileState`
  renders loading, not-found, and action states for public profile routes.
- eLitua admin/list pages repeat simple loading/error data states before
  resource lists or diagnostics are ready.

## Contract

- Accepts title, optional eyebrow, description/body, action slot, footer slot,
  tone, icon override, density, and alignment props.
- Uses status semantics for loading/empty/info/success by default and alert
  semantics for warning/danger. Loading tone also marks the region `aria-busy`.
- Renders default tone icons, including an animated loading icon that is
  suppressed by reduced-motion media queries.
- Supports comfortable centered route states and compact inline panel states.
- Uses only `ui-data-state*` CSS classes and shared token variables for the
  shared content layout; catalog/page demos own the outer surface when one is
  desired.
- `EmptyState` and `LoadingState` are typed presets, not competing state shells;
  loading geometry composes decorative `Skeleton` elements under this one
  status announcement, and skeleton-only bodies remain hidden from assistive
  technology.

## Non-Goals

- No data fetching, retry policy, route parsing, auth checks, localization,
  redirect timers, toast delivery, or product-specific copy.
- Does not replace `AuthStatusPanel` for account/OAuth/session boot flows.
- Does not replace `NoticeBanner` for lightweight inline alerts inside an
  already-rendered form or page.

## Review Expectations

- Long error details and action labels wrap without overlap on mobile.
- Compact density fits inside existing panels without increasing surrounding
  layout unexpectedly.
- Loading, empty, warning, and danger tones remain visually distinct while using
  the same structure.
