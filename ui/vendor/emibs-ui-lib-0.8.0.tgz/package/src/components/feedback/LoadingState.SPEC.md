# LoadingState

`LoadingState` is the typed loading preset for `DataStatePanel`. Decorative
`Skeleton` geometry composes inside one containing status announcement; it does
not expose one announcement per placeholder. The shared state owner carries the
`aria-busy` loading semantics, repeated skeletons stay hidden from assistive
technology, reduced-motion preferences suppress the animated loading icon, and
the preset itself adds no outer surface chrome. Fetching, retries and timing
remain consumer-owned.
