# ToastStack

## Purpose

`ToastStack` is a presentational notification surface for transient product
messages: success confirmations, validation warnings, operational errors, and
loading notices.

## Contract

- Accepts a controlled list of toast items with title, description, tone, meta,
  action, optional icon, and optional dismiss callback.
- Supports `contained`, `top-right`, and `bottom-right` placements so product
  apps can review both embedded and viewport-mounted notification stacks.
- Renders default tone icons when no icon is supplied.
- Leaves queue creation, dedupe, timers, persistence, side effects, route
  actions, toast libraries, localization, telemetry, and error mapping in the
  consuming app.
- Uses `ui-toast-stack*` and `ui-toast*` CSS classes and shared token variables
  only.

## Source Evidence

- Score `ui/src/design-system/Toast.tsx` wraps `sonner` and consumes a deduped
  `ToastMessage[]` queue from `ui/src/app-shell/AppShell.tsx`.
- Score feature containers call a shared `onToast(message)` callback for board,
  settings, project, profile, agent, and Maestro-chat feedback.
- eLitua currently uses inline status/error messages across auth and admin
  pages, so a future adoption should evaluate whether route-level toasts are
  appropriate before replacing those local messages.

## Non-Goals

- No global portal, no `sonner` dependency, no timers, no auto-dismiss, no
  promise handling, no notification store, and no adoption into Score or eLitua
  in this extraction.
