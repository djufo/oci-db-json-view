# AlertDialogFrame

## Purpose

`AlertDialogFrame` is a low-level presentational alert-dialog shell extracted
from Score's local shadcn/Radix alert-dialog wrapper. It captures the visual
slots Score already repeats for alert-dialog content: compact/default sizing,
optional media, title, description/body copy, and caller-owned footer actions.

Use `ConfirmationDialog` when the interaction is the standard cancel/confirm
destructive flow. Use `AlertDialogFrame` when the product needs alert-dialog
semantics with custom trigger, action, cancel, focus, routing, or workflow
behavior supplied by the consuming app.

## Contract

- Controlled by `open` and `onClose`.
- Renders `role="alertdialog"` with generated title and description ids.
- Supports `fixed` product placement and `contained` catalog/review placement.
- Provides `default` and `sm` width presets to match Score's current alert
  dialog content sizes.
- Provides media, description, body, close, backdrop-close, and footer slots.
- Handles Escape close in fixed placement when not `busy`.
- Does not create action buttons; products supply cancel/action controls in the
  footer slot so their semantics, variants, and workflow remain local.

## Product Ownership

`AlertDialogFrame` composes the shared `Dialog` overlay engine for fixed and
contained placements, so it inherits focus trapping, restoration, body scroll
lock, stacking, Escape handling, and backdrop dismissal while the consuming
app owns trigger composition, mutations, analytics, localization, and
notifications.

## Accessibility Notes

- The `title` prop is required and wired through `aria-labelledby`.
- `description` is wired through `aria-describedby`; if no description is
  provided, the body slot receives the description id.
- `showClose` defaults to false so alert dialogs can force an explicit
  cancel/action choice. Enable it only when the product flow has a clear close
  path.
- `closeOnBackdrop` defaults to false for alert-dialog safety. Products can opt
  into backdrop close for lower-risk informational alerts.
