# BlastRadiusConfirm

## Purpose

`BlastRadiusConfirm` is the pre-commit disclosure surface for a consequential
write: it shows the COMPUTED blast radius of an action before it runs, then
offers confirm / cancel. It renders only the impact model it is handed, so a
confirm dialog can never show a stale or fabricated consequence.

## Source Evidence

- Score `requirements/v4/ui` (SPEC G3): every admin write shows its blast radius
  BEFORE commit, and the content is computed from live data, never hardcoded;
  403/409 are surfaced verbatim; the server owns policy. The canonical case is
  the fleet-disable incident — "disabling N of pool X" with N and X read live.
- Score's v4 `BlastRadiusConfirm.tsx` renders a bespoke panel. This library
  version composes the existing `ConfirmationDialog` instead of adding a third
  dialog frame.

## Contract

- `impact: BlastRadius` (`{ summary, items[], severity }`) is computed by the
  caller via the pure `blastRadius()` assembler in `blastRadius.ts` and rendered
  verbatim; this component embeds no counts or entity names of its own.
- Composes `ConfirmationDialog`: the impact `severity` maps to the dialog tone
  (`info`/`warn`/`danger` → `info`/`warning`/`danger`), which drives the accent
  and the confirm button variant. No new overlay / focus-trap / action code.
- `title` defaults to `impact.summary`; the body lists the computed items, each
  tagged with its own severity for the token-coloured left rule.
- `error` is a slot for a verbatim server body (e.g. a 403/409), rendered with
  `role="alert"` in mono.
- `pending` passes through to the one `ConfirmationDialog` busy state while a
  write is in flight: the live caller-computed impact remains visible, while
  Escape, backdrop, close, cancel, and confirm are all locked.
- `placement="contained"` renders inline (no portal) for review surfaces.

## Boundaries

- No policy, no write, no fetch, no impact COMPUTATION: the domain builder that
  turns live rows into a `BlastRadius` (pool-disable, re-band, …) lives in the
  consuming app beside its data. Only the generic `blastRadius()` assembler and
  `maxBlastSeverity()` ship here.
- Does not own the overlay; that is `ConfirmationDialog` / `Dialog`.

## Review Checks

- Nothing renders when `open` is false.
- The overall dialog tone equals `impact.severity` and cannot disagree with the
  items (severity is derived from them by the assembler).
- A server error shows verbatim through the alert slot without being reworded.
