# ConfirmationDialog

## Source pressure

- Score uses a local `ConfirmDialog` for destructive task, attachment, agent,
  and movement confirmations.
- eLitua still has admin deletion flows using browser `confirm()` and payment
  card removal flows without a shared confirmation surface.
- Larger layout and page-shell extractions are already represented in the
  catalog, so this unit moves into the next reusable feedback/control pattern.

## Contract

- `ConfirmationDialog` is a controlled presentational component.
- Consumers own the state that opens the dialog, the mutation or transition
  performed on confirm, optimistic updates, toasts, routing, and audit events.
- `tone` changes visual emphasis only; it does not encode authorization or
  destructive-policy behavior.
- `placement="fixed"` is for product modal use; `placement="contained"` is for
  catalog previews and embedded review surfaces.
- `busy` marks the `alertdialog` `aria-busy="true"` and blocks every user path:
  Escape, backdrop, close, cancel, and confirm. The consuming app owns the
  mutation and clears `busy` when it completes.
- Blocking is not the same as disabling. Per `src/theme/STATES.md` rule 5,
  `busy` and `disabled` are different states: the confirm button stays
  **focusable** while busy and announces `aria-busy="true"`, and its
  double-submission guard lives in the confirm handler, not in the `disabled`
  attribute. Only `confirmDisabled` — the caller declaring the action
  unavailable — takes the native `disabled` attribute.

## Accessibility

- The panel uses `role="alertdialog"`, a generated title id, optional body id,
  and `aria-modal=true` for fixed product use.
- Fixed dialogs compose the shared `Dialog` overlay engine for focus trap, body
  scroll lock, top-most Escape handling, and focus return through `onCancel`.
- The backdrop, close button, cancel button, and Escape all request
  `onCancel` only when not busy; the confirm handler is likewise guarded while
  busy (or `confirmDisabled`).
- Consumers remain responsible for route-level focus policy beyond the trigger
  focus returned by the overlay engine.

## Not Owned Here

- Delete, move, revoke, or disconnect mutations.
- Permission checks and release gates.
- Undo behavior.
- Toast delivery and error wording.
- Product-specific confirmation copy.
