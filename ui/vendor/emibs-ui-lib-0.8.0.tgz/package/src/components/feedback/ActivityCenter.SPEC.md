# ActivityCenter

## Purpose

`ActivityCenter` is the notifications inbox body — the content of the dropdown
or drawer that a `NotificationBell` opens. It lists notifications newest-first
with read/unread state, a "mark all read" action, per-item selection, and
explicit loading / error / empty states. It is presentational and controlled;
the `useNotifications` hook (`src/lib/notifications`) drives it against the
notifications service, and any app supplies its own scope, so no provider
identity is baked in (issue-3752 · S3).

It is **flat by design** (ui-density, SK): it renders no outer surface — no
border, background, shadow, radius, fixed width, or outer padding. The consuming
app mounts it inside its own popover / dropdown / drawer and owns that surface,
its height bound, and the overlay semantics (open/close, focus trap, `Esc`,
`aria-modal`). The `--fill` modifier makes it stretch inside a flex surface.

## Contract

- Accepts a controlled `items: ActivityCenterItem[]` (a structural subset of the
  service's `NotificationRecord`), already ordered newest-first.
- `status` selects the surface: `loading` (skeleton rows), `error` (alert +
  optional `onRetry`), or `ready` (list, or the empty state when `items` is
  empty).
- Each row shows title, optional body, a relative timestamp (`formatTimestamp`
  is injectable for localization), and an unread marker. A row with a `link`
  renders as a native `<a href>` so keyboard and assistive tech get real
  navigation; a row without one renders as a `<button>`. Both fire
  `onItemSelect(item)`, which the consumer uses to mark the item read.
- `onMarkAllRead` renders the header action (disabled at zero unread / off the
  ready state); `unreadCount` overrides the header count, otherwise it is
  derived from `items`.
- `onLoadMore` + `hasMore` + `loadingMore` render an optional "Load older"
  control for cursor pagination.
- Accessibility: the panel is a labelled `role="group"` (via `ariaLabel` or an
  external `labelledBy`) — it does NOT claim `role="dialog"`, because the overlay
  and its focus/keyboard contract belong to the consumer. Rows are natively
  focusable (anchor/button); the list is a labelled `role=list`; the error state
  is `role="alert"`; the loading state is `aria-busy` + `aria-live="polite"` with
  a visually-hidden "Loading notifications…" line; the unread marker carries a
  visually-hidden "Unread" prefix.
- Uses `ui-activity-center*` classes and shared token variables only.

## Data / API boundary (consumed via `useNotifications`)

- REST `GET /notifications?appKey=&recipientId=&unreadOnly=&cursor=&limit=`
  (newest-first, opaque cursor) → initial list + `loadMore`.
- REST `POST /notifications/{id}/read` and `POST /notifications/read-all` →
  `onItemSelect` / `onMarkAllRead` (optimistic, reverted on failure).
- REST `GET /notifications/unread-count` → header/badge count.
- SSE `GET /notifications/stream` `event: notification` prepends live rows;
  `event: unread-count` sets the authoritative total; reconnect resumes from the
  last event `id` via `Last-Event-ID`.

## States

- **loading** — three skeleton rows while the initial REST load runs.
- **ready / list** — notifications newest-first; unread rows accented.
- **ready / empty** — friendly "all caught up" state.
- **error** — load failure with an optional retry.
- **paginating** — "Load older" busy while the next page loads.

## Non-Goals

- No fetching, SSE subscription, reconnect, optimistic bookkeeping, routing,
  persistence, portal/overlay positioning, localization, or provider identity —
  those live in `useNotifications` or the consuming app (eLitua wiring is S4).
