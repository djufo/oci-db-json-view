/** @type {import("dependency-cruiser").IConfiguration} */
module.exports = {
  forbidden: [
    // --- Direct layer boundaries (fast, precise error messages) ---
    {
      name: "core-must-not-import-components",
      comment:
        "Core is the lowest layer and must stay presentation-free: no direct " +
        "import of any component. See ARCHITECTURE.md (issue-584).",
      severity: "error",
      from: { path: "^src/core/" },
      to: { path: "^src/components/" },
    },
    {
      name: "primitives-must-not-import-core",
      comment:
        "Primitives are presentation building blocks and must not depend on " +
        "core orchestration/config directly. See ARCHITECTURE.md (issue-584).",
      severity: "error",
      from: { path: "^src/components/primitives/" },
      to: { path: "^src/core/" },
    },
    {
      name: "primitives-must-not-import-data-components",
      comment:
        "Primitives must not depend upward on data components. " +
        "See ARCHITECTURE.md (issue-584).",
      severity: "error",
      from: { path: "^src/components/primitives/" },
      to: { path: "^src/components/data/" },
    },
    {
      name: "shared-components-must-not-import-section-card",
      comment:
        "SectionCard is the page-owned depth-one surface. Shared auth, data, " +
        "feedback, and forms components stay flat and cannot render it.",
      severity: "error",
      from: { path: "^src/(components/(auth|data|feedback)/|forms/)" },
      to: { path: "^src/components/layout/SectionCard\\.tsx$" },
    },
    {
      name: "catalog-and-explorer-are-demo-only",
      comment:
        "catalog/explorer are demo & review surfaces: they consume every " +
        "layer and must be consumed by none. See ARCHITECTURE.md (issue-584).",
      severity: "error",
      from: { pathNot: "^src/(catalog|explorer)/" },
      to: { path: "^src/(catalog|explorer)/" },
    },

    // --- Barrel-aware boundaries (issue-1262) ---
    // src/lib/index.ts is the PUBLIC entry barrel; it re-exports core,
    // components and forms. A lower layer that imports the barrel (or any
    // module that transitively reaches a higher layer through it) bypasses the
    // direct rules above. `reachable` follows the whole dependency graph,
    // treating the barrel's re-exports as transparent, so a core file that
    // imports `../lib` (which re-exports components) is caught.
    {
      name: "core-must-not-reach-presentation",
      comment:
        "Core must not reach ANY higher layer, including transitively via the " +
        "src/lib barrel or a re-export chain. Closes the barrel bypass where " +
        "core imports `../lib/<Component>`. See ARCHITECTURE.md (issue-584).",
      severity: "error",
      from: { path: "^src/core/" },
      to: {
        path: "^src/(components|forms|catalog|explorer)/",
        reachable: true,
      },
    },
    {
      name: "primitives-must-not-reach-core",
      comment:
        "Primitives must not reach core, including transitively via the " +
        "src/lib barrel. Closes the barrel bypass where a primitive imports " +
        "`../../lib` to pull core symbols. Primitives consume the `cn` leaf " +
        "(src/lib/cn) directly, never the layer-mixing barrel. " +
        "See ARCHITECTURE.md (issue-584).",
      severity: "error",
      from: { path: "^src/components/primitives/" },
      to: { path: "^src/core/", reachable: true },
    },
    {
      name: "primitives-must-not-reach-data-components",
      comment:
        "Primitives must not reach data components, including transitively via " +
        "the src/lib barrel. See ARCHITECTURE.md (issue-584).",
      severity: "error",
      from: { path: "^src/components/primitives/" },
      to: { path: "^src/components/data/", reachable: true },
    },
  ],
  options: {
    // Include TypeScript-only dependencies so `import type` cannot bypass layer
    // boundaries; primitives must not depend on core even for erased types.
    tsPreCompilationDeps: true,
    exclude: {
      path: "^(node_modules|dist)/",
    },
    doNotFollow: {
      path: "^node_modules/",
    },
    tsConfig: {
      fileName: "tsconfig.json",
    },
    enhancedResolveOptions: {
      exportsFields: ["exports"],
      conditionNames: ["import", "require", "node", "default", "types"],
      extensions: [".ts", ".tsx", ".js", ".jsx", ".mjs"],
    },
  },
};
