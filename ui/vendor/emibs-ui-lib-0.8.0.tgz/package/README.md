# emibs-ui-lib

Hostable EMIBS UI framework demo and component library. This package lives
inside the `emibs` workspace umbrella at `packages/emibs-ui-lib`.

## Development

```sh
npm install
npm run dev
npm run build
```

## Architecture

Layer boundaries, the extraction test, and worked examples are documented in
[ARCHITECTURE.md](ARCHITECTURE.md).

## Importing

The package is unbuilt and `private`: it has no `main`, and consumers inside the
monorepo import its TypeScript source directly. The `exports` map in
`package.json` is the whole public surface, enumerated one entry per module, and
these are the only shapes that resolve:

```tsx
import { AuditTimeline } from "emibs-ui-lib/components/data/AuditTimeline"; // a component, at its own module
import { Dialog } from "emibs-ui-lib/components/primitives/overlay";        // the overlay engine
import { AutoForm } from "emibs-ui-lib/forms";                             // forms aggregate
import { zodToSpec } from "emibs-ui-lib/core";                             // headless engine aggregate
import { ThemeScope } from "emibs-ui-lib/theme";                           // theme aggregate
import { useNotifications } from "emibs-ui-lib";                           // barrel — cross-cutting hooks
import "emibs-ui-lib/styles.css";                                          // the stylesheet
```

A component that owns a module file is imported from that module. The bare
barrel is for symbols with no owning component module. `emibs-ui-lib/src/**` is
not public and no longer resolves. `npm run check:exports` (wired into `build`)
fails when the map and the catalog's documented import paths disagree.

## Address fields

[AddressField](src/components/data/AddressField.SPEC.md) and
[GeoCoordinatePicker](src/components/data/GeoCoordinatePicker.SPEC.md) provide
controlled address and coordinate editing. Pass a provider-neutral
`AddressMapAdapter` to show/pick a point and optionally geocode; omitting it keeps
manual coordinates available. Ownership hints come through `canEdit` and
`readOnly`; authorization and persistence stay in the consumer.

## Theming

Themes are ordered CSS custom-property token maps (`emibs-theme/2`). Use
`ThemeScope` to apply a theme to any subtree, and `DensityScope` to set the
global comfortable/compact density. The package ships neutral, Score, and eLitua
light/dark reference themes through the theme catalog:

```tsx
import { ThemeScope, DensityScope, scoreDarkTheme } from "emibs-ui-lib/theme";

<ThemeScope theme={scoreDarkTheme}>
  <DensityScope density="compact">
    <YourComponent />
  </DensityScope>
</ThemeScope>;
```

`emibs-theme/2` is a strict superset of `emibs-theme/1`: it adds semantic
families (priority bands, delivery classes, capacity states incl. a distinct
`unknown`, severity, freshness), a system-wide interaction-state model
(`src/theme/STATES.md`), and the density scale. A `/1` theme JSON still imports —
it upgrades losslessly, deriving the new tokens from existing ones. See
the current [framework contract](SPEC.md) and
[interaction-state contract](src/theme/STATES.md).

## Releasing

`npm run release` verifies the build, packs the tarball, copies it to
`/engineering/dist`, and prints the consumer refresh steps. Consumers pin an
exact version.

## Deployment

```sh
docker compose up -d --build
```

From this package directory, the container publishes `127.0.0.1:8283`, mapped by Caddy to
`https://ui-lib.ayc.io`. The build context is the repository root (the image
includes a small Go server from `bff/`); `docker compose` handles that, and a
hand-run `docker build` must use `-f packages/emibs-ui-lib/Dockerfile .` from the
repo root.

`emibs-deploy-agent` rebuilds this stack from `origin/score-work` every five
minutes, so merges reach `ui-lib.ayc.io` unattended.

`bff/` also carries the catalogue's authentication gate. It is always **on**:
the process refuses to start without a complete `auth` group, so anonymous
callers get `401` for the shell and every asset. See
[`bff/README.md`](bff/README.md) for the gate, its required configuration, and
why there is no ungated mode.
