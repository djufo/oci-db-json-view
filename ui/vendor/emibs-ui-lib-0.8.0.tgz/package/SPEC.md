# emibs-ui-lib Spec

## Goal

Provide a fast review surface for EMIBS UI components before they reach product
apps. The first catalog extracts patterns from Score and eLitua, then normalizes
them into reusable shadcn-style React components with EMIBS theme tokens.

## Component Contract

- Components are React + TypeScript and export from `src/components/**`.
- Components accept data and event props; they do not fetch data.
- Each component must be represented in the catalog registry with a demo.
- Styling uses shared CSS tokens from `src/styles.css`.
- Catalog registry entries may optionally define a `playground` schema with
  declared controls, a `renderWith(props)` preview renderer, and a
  `toSnippet(props)` JSX builder. Omitted playground schemas render an empty
  inspect-tab note rather than blocking catalog adoption.
- The UIF-E2 material-parity primitive set (`Button`, `Tooltip`, `Menu`,
  `Breadcrumb`, `Slider`, `Skeleton`, `Toolbar`, `TablePrimitive`, the `Chip`
  taxonomy, `Meter`, `SignalDot`, `FreshnessBadge`, and `KeyboardHint`) is an
  explicit complete slice: every entry has a co-located spec, visible isolated
  demo, live playground, catalog variants that serve as its states matrix,
  usage and prop documentation, and an accessibility contract.
- The UIF-E4 composite set has one canonical public owner for tables, page
  sections, label/value facts, async states, and confirmations. Its ownership
  and replacement matrix is defined in `ARCHITECTURE.md` under Canonical
  Composite Ownership.

## Catalog Registry

- The catalog registry lives in `src/catalog/`: `types.ts` (entry and metadata
  types), `metadata.ts` (per-component metadata for every catalogued
  component), `groups.ts` (switchable grouping axes plus shared search
  matching), `specs.ts` (raw import glob over co-located `.SPEC.md` files),
  and `registry.tsx` (metadata joined with `render()` demo functions).
- A registry entry pairs component metadata (id, name, category, source apps,
  patterns, lifecycle status) with an isolated `render()` demo, plus optional
  variants, explicit state previews, usage snippets, prop docs, and a
  playground schema. Each state preview has a stable id, human label, optional
  description, and isolated renderer; ordinary variants never count as states.
  Sidebar navigation, gallery, facets, coverage, and inspect pages all derive
  from this one registry.
- Registry assembly resolves and stores canonical `hasDemo` and `specContent`
  values. A wired demo advances a `catalogued` entry to `demo-migrated`, but
  manually declared `active` or `adopted` lifecycle states are preserved.
- Lifecycle order is `catalogued` → `demo-migrated` → `active` → `adopted`.
  `active` and later entries must have non-empty resolved SPEC content, a real
  isolated demo, and at least one explicit state preview. The shared coverage
  check enforces this gate during every package build.
- Component specs are co-located `.SPEC.md` files next to their source
  (`src/components/**`, `src/forms/**`, `src/compositions/**` and
  `src/core/**`), loaded via `import.meta.glob` raw imports (`specs.ts` carries
  the `vite/client` types reference this needs), keyed by their `src`-relative
  path suffix, and rendered in the inspect Spec tab. The last two roots were
  added in uif/issue-4675: before it, a spec written beside a source file in
  either directory could not be loaded at all, so the coverage figure was silent
  about them by construction rather than by measurement.
- Registration completeness is a separate gate from facet completeness.
  `scripts/check-catalog-registration.mjs` walks the export closure of the
  public entry barrel `src/lib/index.ts` (the surface ARCHITECTURE.md
  designates, and the one the dependency-cruiser barrel rules are written
  against), decides syntactically which exported names are components — a
  PascalCase value whose declaration contains JSX, as opposed to a type, a
  hook/utility, a constant or a class — and compares them against
  `componentMeta`. A component whose declaring file carries no catalog entry
  fails the build; one co-located with a catalogued entry, such as `CardHeader`
  beside `Card`, is reported as a review note because the parent entry
  documents the compound. The pre-existing gap is held flat by
  `scripts/baselines/catalog-registration.json`, each entry carrying a written
  justification; the gate exists so that gap cannot grow.

## Theme Architecture

- A theme is an ordered CSS custom-property token map plus metadata (`id`,
  `label`, and `colorScheme`).
- `ThemeScope` applies a theme to any React subtree by writing the ordered token
  map as inline CSS custom properties on a wrapper element.
- Neutral, Score, and eLitua reference themes live in `src/theme/tokens.ts`;
  each has light and dark variants and mirrors the default `:root` token
  vocabulary used by catalog components.
- The `emibs-theme/2` vocabulary is grouped for editing and review into color,
  semantic, interaction-state, space, density, radius, and type categories
  while preserving the same ordered CSS-custom-property token map shape.
- **Rounding limits (owner rule, 2026-07-26):** the full/pill radius token is
  reserved for single-line atomic controls whose content can never wrap
  (chips, badges, single-line inputs, steppers, buttons). Any CONTAINER
  holding multiple or wrappable elements — panels, cards, option groups,
  segmented rows — takes the card radius, never the pill. Atomic controls
  keep their standard pill radius even when nested inside a card container,
  so identical controls look identical everywhere. Litmus test: if an
  element's height can change with content, it must not use the pill radius.
  Components in this catalog MUST follow this when picking radius tokens; the
  shared-pattern home is `/engineering/specs/patterns/frontend-styling.md`
  (radius bullet).
- Product apps can define additional app-specific themes by reusing the same
  token names and passing the theme object to `ThemeScope`.
- The built-in theme catalog (`themes` in `src/theme/tokens.ts`) groups themes
  into families by id prefix; each family ships a light and a dark variant
  sharing a family base id (`<family>-light` / `<family>-dark`). The Explorer
  theme picker renders families through its prefix-to-family-label mapping
  (`themeFamilyLabel` / `groupedThemes` in `src/explorer/CatalogExplorer.tsx`).
- Adding a theme: define `xxxLightTheme` / `xxxDarkTheme` in
  `src/theme/tokens.ts` (the shared color tokens plus
  `...foundationalTokens`, typed `as const satisfies EmibsTheme`), export
  them from `src/theme/index.ts`, append them to the `themes` catalog, and
  register the id prefix and family name in the Explorer's family grouping.
  `npm run build` typechecks the token map shape.
- Contrast conventions: body text stays AA (at least 4.5:1) against `--bg`
  and `--surface`. In light themes `--accent-strong` carries white text; in
  dark themes `--accent-strong` is lighter than `--accent` and pairs with
  dark text.

## Theme Studio

- Catalog Explorer exposes Theme Studio at `#/studio`; it uses the active
  explorer theme plus a hash-backed preview set selection.
- Theme Studio edits token drafts in local UI state only, validates color,
  length, and font-family values, and applies valid drafts to preview canvases
  through `ThemeScope` inline CSS custom properties.
- Theme Studio v2 exposes every definition in the complete `emibs-theme/2`
  vocabulary, including semantic, interaction-state, and density tokens. The
  editor and saved custom themes use the same ordered full-token snapshot; no
  parallel serializer or partial editable subset is maintained.
- Reset controls restore drafted tokens to the active or selected custom theme
  defaults.
- Theme Studio can save the valid draft overlay as a named custom `EmibsTheme`
  in versioned, namespaced `localStorage`; saved custom themes and a valid saved
  selection survive reload, and can be selected inside Studio, forked, reset
  back to the active built-in theme, or deleted. Corrupt persisted data is
  ignored and falls back to built-in themes.
- A saved custom theme is only ever deleted by the user deleting it. Every write
  carries the version of the store it was derived from and is refused if that is
  no longer the stored value, so a save from a page whose snapshot another tab
  has moved past cannot delete what the page never saw — and cannot report
  success while doing it. Theme Studio recovers from that refusal by re-reading
  and re-applying the action (add this theme, remove this id) to what is actually
  stored, and it follows the `storage` event so the refusal is rarely reached at
  all. The event narrows the window; the version check is what closes it.
- Export flows remain part of the foundations token reference rather than the
  Studio authoring surface.

## Theme Export

- `ThemeExportPanel` provides presentational theme export review controls:
  controlled format choices, copy/download/custom action descriptors, scope
  badges, and optional output preview.
- Consuming apps own token serialization, CSS selector construction, reading
  product theme scopes, clipboard writes, browser downloads, persistence,
  routes, permissions, analytics, and toasts.

## Composition Framework

- Full-page app mockups are catalog entries with `MockupMeta` metadata plus a
  `render()` function, matching the component registry pattern.
- `CompositionFrame` defines a CSS grid layout from named slot areas and renders
  each slot through a `CompositionSlot`.
- Mockup entries list their source apps, patterns, component ids, and slot names
  so the catalog can inspect whole-screen compositions separately from atomic
  components.
- Mockup inspect pages frame each composition in selectable fluid, desktop,
  tablet, and mobile viewport shells. The frame constrains width and scrolls the
  app surface internally so responsive slot behavior can be reviewed without
  changing the product-owned mockup fixtures.
- The Score work board mockup uses stable id `score-work-board`, renders static
  `/work`-style toolbar filters, queue metrics, and created/ready/processing/review
  workflow lanes, and keeps the legacy `score-operations-board` hash as a
  compatibility alias only.
- The Score operations dashboard mockup uses stable id
  `score-operations-dashboard`, renders static operational fixtures for queue
  pressure, recent work, agent/subscription capacity, scheduler run state, and
  release/QA gates, and keeps live polling, permissions, promotion policy,
  routing, and API mapping product-owned.
- The Score record detail mockup uses stable id `score-record-detail`, renders
  static task/project/agent detail fixtures for record headers, planning fields,
  relations, review notes, branch and document metadata, attachments, markdown
  evidence, and workflow actions, and keeps permissions, patch payloads, route
  state, signed attachment URLs, toasts, and workflow legality product-owned.
- The Score mockup generator mockup uses stable id `score-mockup-generator`,
  renders static prompt transcript, generation brief, component plan, generated
  full-screen preview, and output trace evidence for AI-assisted app mockup
  review, and keeps model calls, persistence, product routing, booking,
  workflow writes, and adoption decisions product-owned.
- The Catalog Explorer exposes mockups under `#/mockups` and `#/m/<id>` with the
  same theme and viewport controls used by component previews.

## Catalog Explorer Filtering

- Component search and facets derive from the registry and theme catalog, then
  drive one live result set for sidebar navigation and the gallery.
- Sidebar search also matches theme names/ids and live top-level Explorer pages,
  so one field can narrow component links, switch themes, or jump to pages.
- Facets cover category, source app, pattern, lifecycle status, spec presence,
  and compatible theme. Different facets are combined together; each facet can
  match selected values with either OR or AND semantics.
- The Explorer exposes a registry coverage dashboard at `#/coverage`, deriving
  one row per component entry plus summary totals for demo migration, variants,
  usage snippets, prop docs, explicit states, and resolved specs. The dashboard
  sorts least-complete entries first and links each row back to its inspect
  route. Its pure coverage calculation is shared with the build-time report,
  which prints a concise summary and fails on lifecycle-gate violations.
- Both the dashboard and the build-time summary state their denominator rather
  than printing a bare percentage. The figure is `registered entries x 6
  facets`: it measures the registry against itself, so a component that is
  exported but never catalogued is not counted as incomplete — it is not
  counted at all, and leaving it out makes the percentage higher. The bound on
  what sits outside that denominator is the registration gate above, not the
  percentage.
- The Explorer owns one hash-persisted active theme picker for gallery, component
  previews, variants, and composition mockups; per-surface theme previews derive
  from that active theme instead of owning separate picker state.
- The Explorer owns one hash-persisted `comfortable` / `compact` density value.
  One top-level `DensityScope` applies it to all Explorer chrome and preview
  descendants; density hash updates preserve route, theme, compare, search, and
  facet parameters. The toolbar switch states the current density first and the
  next action, with synchronized pressed semantics.
- The Explorer toolbar exposes a Light/Dark/System color-mode control,
  persisted in `localStorage` under `emibs-ui-lib:theme-mode`. The mode
  resolves the active theme within its family (`<family>-light` /
  `<family>-dark`); System follows `prefers-color-scheme` live.

## Catalog Explorer Navigation

- Desktop view keeps the persistent grouped rail for search, axis switching,
  facets, component links, theme choices, live page links, coverage, mockups,
  and legacy access.
- Explorer chrome, gallery cards, preview canvases, modal overlays, and mobile
  navigation use the shared theme token vocabulary for colors, borders, radii,
  muted text, and shadows; the Explorer must not maintain a separate one-off
  palette for light/dark parity.
- Narrow view uses a sticky compact header with an icon menu button that opens
  the same navigation rail as a modal drawer; selecting a route, pressing Escape,
  or clicking the backdrop closes it.
- Catalog Explorer mounts its command palette through a lazy `CatalogCommandPalette`
  chunk. The global shortcut is Cmd-K on Mac and Ctrl-K elsewhere; opening
  focuses the search input, Escape or backdrop click closes it, focus is trapped
  while open and restored on close, and ArrowUp/ArrowDown/Enter operate the
  highlighted result with wrapping.
- The shared `matches(meta, query)` helper tokenizes free text and fuzzy-matches
  registry names, ids, categories, source apps, and patterns for both gallery
  search and command-palette component results.
- The lazy command palette groups Components, Themes, Pages, and Mockups. It
  reuses `matches(meta, query)` for component/mockup metadata, caps visible
  component and mockup rows, navigates selections through the existing
  `#/c/<id>` and `#/m/<id>` hash routes, and applies selected themes through
  the active-theme hash parameter.
- Gallery groups render component cards with clipped, inert live preview
  thumbnails for migrated registry demos plus a dedicated inspect link, so
  grouped browsing stays visual without stealing focus or nesting interactive
  controls in navigation anchors.
- Gallery cards and component inspect pages expose a URL-backed compare tray for
  migrated demos. The compact `compare=<ids>` hash param is de-duplicated,
  ignores unknown or unmigrated ids, survives refresh/share and route changes,
  and supports pin, unpin, remove-one, and clear-all controls while leaving the
  future side-by-side compare canvas outside this slice.
- Component inspect pages expose Preview, Playground, Variants, States, Usage,
  Props, Audit, and Spec tabs. States renders the dedicated registry state
  previews in a token-styled flat grid and gives entries without state metadata
  a useful empty state. Playground uses declared control kinds for its control
  rail, renders through the same ThemeScope and responsive width canvas as
  Preview, and keeps the live JSX snippet copyable while product-specific
  integration code remains outside the catalog.

## Initial Iterations

1. Score primitives and admin controls: buttons, badges, cards, status strip,
   action bars, dense table states.
2. eLitua layout and entity browsing: app shell, sidebar, page header, entity
   cards, pager.
3. Score board controls: kanban board, task cards, filters, priority/status
   indicators.
4. eLitua explorer workspace: fixed-height map/table/card browser shell,
   persistent control rail, view switcher, loading/error states, and detail slot.
5. Score workspace shell: authenticated operator topbar, route-backed view tabs,
   status/identity/action slots, and dense page content panels.
6. eLitua portal header: public brand/search/navigation chrome with compact
   social, utility, identity, and mobile menu affordances.
7. eLitua mobile navigation: fixed bottom mobile nav, More action, controlled
   full-menu bottom sheet, grouped links, close action, and footer control slot.
8. eLitua desktop portal footer: brand, centered legal/navigation links,
   trailing copyright, optional action slot, and desktop-only visibility when
   paired with mobile navigation.
9. Score and eLitua record detail panel: title/action chrome, metadata badges,
   dense field grid, section stack, compact explorer-card density, comfortable
   task/project detail density, and optional close/footer slots.
10. eLitua portal landing page: image-led public home hero, proof metrics,
    intent route cards, featured destination grid, planner/CTA rail, chips, and
    quote band.
11. eLitua map viewport: stable map canvas chrome, loading/error states, stat
    overlay, transient title overlay, map action controls, static review
    markers, and selected-record info panel slot.
12. Score command console: prompt-driven operator workspace with session rail,
    terminal transcript, queued-work links, working state, and composer controls.
13. Score and eLitua auth access panel: centered auth card shell, provider
    actions, local credential fields, session-refresh message states,
    registration field rows, password-strength meter, divider, and footer slot.
14. Score and eLitua editable form panel: autosave/action header, status badges,
    grouped dense fields, JSON text areas, geocode action strip, selectable
    result rows, checklist editor, compact/comfortable density, and footer slot.
15. eLitua editorial article page: backlink/category header, author/meta row,
    image hero, mobile and sticky desktop table of contents, structured article
    body sections, inline CTA, optional paywall prompt, tags, share actions,
    author bio, and related article cards.
16. eLitua payment account panel: checkout slot, account summary metrics, saved
    payment methods, customer payment ledger, provider payout ledger, status
    badges, empty states, and product-owned payment/action slots.
17. eLitua editorial listing page: content hub heading, category tabs, featured
    article, card grid, empty state, newsletter CTA, and product-owned filtering
    or subscription behavior.
18. eLitua public profile page: identity hero, avatar, verification/license
    badges, contact actions, profile stats, languages/coverage tags,
    credentials, optional booking/action aside, and product-owned route/query
    behavior.
19. eLitua integration setup page: provider logo/header, connection status,
    credential/configuration sections, sync toggles, integration metrics,
    alert states, test/save/disconnect actions, and product-owned credential
    storage, provider calls, validation, translation, and route behavior.
20. eLitua legal document page: public policy/terms shell with legal eyebrow,
    revision metadata, authority summary callout, structured numbered clauses,
    nested lists, inline links, contact/related-document actions, and
    product-owned legal copy, consent capture, translations, routing, analytics,
    version history, and export/print behavior.
21. eLitua cookie consent banner: GDPR/ePrivacy consent prompt with fixed or
    contained dock modes, title/copy/link slots, managed preference panel,
    controlled category toggles, locked essential category, accept/reject/save
    actions, responsive stacking, and product-owned persistence, legal copy,
    SDK activation, consent versioning, routing, and localization.
22. Score activity dashboard: operator activity surface with status/action
    chrome, actionable queue counts, orchestration metrics, transient alert
    state, recent-work feed rows, task type/status/project/time metadata, and
    product-owned polling, API mapping, live-sync state, routing, and relative
    time formatting.
23. eLitua account sessions panel: account-security surface with status/action
    chrome, loading/error/empty states, current-session marker, device/session
    rows, per-session revoke slots, bulk action slot, and product-owned auth
    services, user-agent parsing, date formatting, localization, confirmations,
    toast handling, and session invalidation semantics.
24. Score and eLitua actor access matrix: admin access-management surface with
    actor identity rows, interface labels, status badges, role selectors, direct
    grant checkboxes, saving/loading/empty/error states, selected-context
    chrome, and product-owned RBAC policy, persistence, routing, audit events,
    and localization.
25. Score agent management panel: operator agent-administration surface with
    metrics, agent identity rows, runner assignment controls, enablement gates,
    capacity/availability state, release-grant chips, runner responsibility
    rows, assigned-agent chips, loading/error/empty states, and product-owned
    worker policy, API persistence, provider login, routing, confirmation,
    date/percentage formatting, and create/delete flows.
26. Score and eLitua resource index panel: admin resource collection surface
    with selected list rows, metadata badges, descriptions, open links,
    optional order controls, empty state, and product-owned routing, persistence,
    project priority policy, entity loading, filtering, RBAC, and mutation
    behavior.
27. Score and eLitua account profile panel: authenticated account profile
    surface with identity header, avatar/initials, verification and save
    notices, profile metrics, account/preference/provider sections, security
    links, and product-owned auth state, profile persistence, verification
    delivery, password/session routing, validation, localization, and toast
    behavior.
28. eLitua portal information page: public About/mission page shell with
    identity hero, landscape banner, proof metrics, explanatory sections,
    business bullet list, mission callout, founder card, and product-owned
    copy, localization, routing, media policy, external links, analytics, CMS,
    and contact behavior.
29. eLitua portal shell: app-level public layout shell with header slot,
    centered/full content modes, controlled full-menu sidebar, desktop footer
    slot, mobile navigation slot, and product-owned routing, menu registry,
    translations, auth state, theme controls, mobile sheet state, and route
    guards.
30. Score and eLitua confirmation dialog: controlled alert dialog for destructive
    or high-impact actions with icon media, title/body copy, cancel/confirm
    actions, busy state, fixed and contained placements, and product-owned
    mutations, permissions, audit events, toast delivery, route focus
    restoration, translations, and error handling.
31. Score and eLitua media asset panel: media/attachment management surface with
    asset stats, upload/dropzone chrome, image/file cards, metadata badges,
    loading/error/empty states, selected asset detail, and product-owned
    authenticated URLs, file upload transport, validation, delete confirmations,
    GraphQL/DataProxy persistence, task attachment rules, profile-picture
    linking, routing, localization, and toast/error handling.
32. eLitua segmented control: controlled single-choice utility control with
    icon/label options, compact and comfortable density, language/theme/view
    switching demos, and product-owned i18n, theme provider, route state,
    persistence, analytics, and entity dispatch behavior.
33. Score and eLitua account menu: controlled avatar-triggered account dropdown
    with identity summary, role badge, grouped account/provider links,
    guest sign-in/register actions, danger sign-out affordance, and
    product-owned auth context, routing, role filtering, outside-click handling,
    logout/session invalidation, translations, and analytics.
34. Score agent profile panel: operator detail surface with identity header,
    capacity metrics, editable configuration fields, release-grant visibility,
    operational metadata, loading/error states, action slots, and product-owned
    API persistence, delete confirmations, routing, provider login, token
    handling, date/percentage formatting, RBAC, and toast behavior.
35. Score and eLitua operational diagnostic panel: admin diagnostic surface with
    status/action chrome, metric tiles, loading/error states, optional embedded
    tool iframe, key/value result rows, JSON/text payload output, and
    product-owned auth, polling, diagnostic APIs, iframe source/proxying,
    localization, redaction, query execution, and result interpretation.
36. Score markdown document panel: document-review surface with status/action
    chrome, metadata rows, badges, loading/error/empty states, sanitized
    markdown body rendering, browser markdown download helper, parser/sanitizer
    injection points, and product-owned task loading, attachment fetching,
    permissions, generated-document rules, filenames, routing, uploads, workflow
    actions, and toast behavior.
37. Score creation dialog: controlled modal create surface with title/description
    chrome, badges, responsive dense field sections, datalist-ready controls,
    automation-gate checkbox slot, description field, cancel/create actions,
    fixed and contained placements, and product-owned draft state, validation,
    task payload mapping, API persistence, routing, focus restoration, toast
    handling, translations, permissions, and audit events.
38. Score and eLitua auth status panel: centered account-flow status surface
    with loading/success/info/warning/danger tones, default or supplied icon,
    title/subtitle, detail body, action/footer slots, portal/operator variants,
    and product-owned OAuth exchange, verification resend, route guard,
    redirect, session refresh, access grant policy, localization, analytics,
    and toast behavior.
39. Score toast stack: controlled transient notification surface with
    contained/top-right/bottom-right placements, success/info/warning/danger/
    loading tones, default or supplied icons, title/description/meta/action/
    dismiss affordances, and product-owned queues, dedupe, timers, toast-library
    integration, route actions, localization, telemetry, and error mapping.
40. Score project settings panel: runtime Settings route surface with admin
    settings chrome, config JSON editor slot, public-config metadata, status
    summary digest controls, summary log, notices, settings metrics, and
    product-owned persistence, JSON validation, settings seeding, public
    endpoint exposure, RBAC, mail delivery, audit events, and toast behavior.
41. Score work item planning panel: task-detail edit and triage surface with
    work item metadata fields, project/epic routing controls, automation
    eligibility, triage enrichment fields, controlled save/cancel/triage
    actions, and product-owned task DTO mapping, workflow legality,
    permissions, project movement confirmation, route state, persistence,
    toasts, and audit behavior.
42. Score work item trace panel: task-detail relationship and review-note
    surface with relation groups, dependency/related links, reviewer decisions,
    note metadata, loading/error/empty states, optional action slots, and
    product-owned task DTO mapping, route links, review creation, workflow
    semantics, permissions, subscriptions, notifications, relative-time
    formatting, toasts, and audit behavior.
43. eLitua mode control panel: compact admin control surface with controlled
    mode selector, optional refresh/action slot, automation toggles,
    disabled/loading feedback, messages, error state, and product-owned RxJS
    dispatch, entity refresh policy, translations, map/geocoding behavior, and
    route state.
44. Score work board toolbar: operator board header and action/filter strip with
    title/status chrome, responsive filter reveal, controlled search, project
    and epic selectors, workflow action slots, error state, and product-owned
    route synchronization, search parsing, task creation, claiming, permissions,
    API refresh, and toast behavior.
45. eLitua paged data table: dense entity table workspace with sortable headers,
    selected rows, loading/empty/error states, pagination summary/control
    chrome, and product-owned data fetching, sorting, pagination calculation,
    row mutation, route state, translations, and persistence.
46. Score scheduler control panel: mapped-job operator surface with enablement
    toggles, command visibility, schedule/runner/workflow metadata, log/lock
    paths, tags, loading/empty/error states, and product-owned scheduler catalog
    validation, API persistence, host execution policy, audit behavior, routing,
    toasts, date formatting, and localization.
47. eLitua entity filter panel: vertical search/filter control surface with
    title/action chrome, controlled text/select filters, clear/refresh actions,
    filtered/total count summary, loading/disabled states, optional stats, and
    product-owned RxJS dispatch, filter schema, result derivation, route/query
    synchronization, translations, map integration, and persistence.
48. eLitua navigation menu: grouped and flat navigation surface for portal
    sidebars, header rows, and mobile sheets with icons, labels, descriptions,
    badges, active/disabled/external states, horizontal/vertical/grid layouts,
    and product-owned menu registries, React Router integration, role filtering,
    translations, active-route derivation, analytics, and close-on-navigation
    behavior.
49. Score and eLitua admin record editor panel: full-page admin edit shell with
    back action, title/status chrome, metadata badges, notices, loading/missing
    states, body/form slot, footer action slot, and product-owned routing,
    entity fields, validation, uploads, delete confirmations, persistence,
    autosave policy, localization, and toast behavior.
50. eLitua relationship picker panel: controlled many-to-many association
    selector with title/status chrome, selected/available counts, optional
    select-all and clear actions, loading/error/empty states, checkbox rows,
    metadata badges, related-record links, and product-owned entity loading,
    relationship persistence, route generation, authorization, localization,
    save/cancel behavior, and toast delivery.
51. Score and eLitua admin home panel: role/admin landing surface with
    title/status/action chrome, metric cards, notice rows, navigation cards,
    loading/error/empty states, optional detail sections, and product-owned auth,
    route registry, RBAC, counts, refresh behavior, localization, persistence,
    and toast/error handling.
52. Score idea backlog panel: project-admin related-idea surface with
    title/status/action chrome, selected-context copy, idea rows, status chips,
    created/source metadata, loading/error/no-context/empty states, and
    product-owned project selection, idea API mapping, routing, RBAC,
    localization, creation/editing flows, timestamp formatting, and toast
    delivery.
53. Score and eLitua tag input: controlled chip-entry field with labeled input,
    datalist suggestions, Enter/comma commit, selected tag chips, per-tag remove
    actions, disabled/empty states, and product-owned deduplication, validation,
    catalogs, task relation semantics, profile persistence, routing,
    localization, and toast delivery.
54. Score and eLitua icon button: labeled icon-only utility control with
    neutral/ghost/danger/active tones, fixed square sizing, optional title
    tooltip, disabled state, decorative icon semantics, and product-owned
    routing, confirmation, mutation, analytics, menu state, translations, and
    toast behavior.
55. eLitua entity card grid panel: current-page card browsing surface with
    title/status/action chrome, toolbar and pagination slots, selected cards,
    media/icon placeholders, badges, metadata rows, footer/action slots,
    loading/error/empty states, compact/comfortable density, and product-owned
    RxJS state, filtering, pagination math, map sync, routing, translations,
    media policy, analytics, and entity dispatch behavior.
56. Score and eLitua notice banner: inline persistent status/alert surface with
    tone-aware icon, title/body copy, action slot, optional dismiss control,
    compact/comfortable density, accessible alert/status semantics, and
    product-owned message creation, localization, API error mapping, auth
    redirects, timers, toast queues, persistence, and analytics.
57. eLitua content tabs: controlled local tab strip with optional page-section
    header, tab icons/descriptions/badges/meta, contained and underline
    variants, compact and comfortable density, panel slot, keyboard focus
    movement, and product-owned routing, filtering, payment ledgers, article
    categories, analytics, localization, and panel content.
58. eLitua map control panel: controlled map command surface with optional
    title/status chrome, zoom/reset/layer action descriptors, compact and
    comfortable density, wrapping or stacked action layout, visible/null state,
    stat badges, accessible toolbar semantics, and product-owned Google Maps
    dispatch, clustering, map settings, selected entity behavior, translations,
    route/query state, analytics, and sidebar composition.
59. Score workflow command bar: controlled work-item transition command surface
    with current-state/status chrome, next/back/neutral command descriptors,
    destination labels, disabled/busy states, compact task-card density,
    comfortable detail density, release-gate copy, and product-owned workflow
    graph, permissions, transition DTOs, persistence, audit events, toasts,
    routing, subscriptions, and destructive confirmations.
60. eLitua map info card: compact selected-marker information surface with
    inline and overlay placement, title/subtitle chrome, close action, status
    badges, key/value rows, action/footer slots, and product-owned map engine,
    clustering, marker lifecycle, selected-entity state, navigation,
    localization, geocoding, and persistence.
61. eLitua password reveal button: controlled show/hide action for password
    fields with eye/eye-off icon state, accessible labels, pressed state,
    disabled state, and product-owned input type, auth validation, password
    strength, form state, routing, and service calls.
62. Score notification toggle: controlled Bell/BellOff preference action with
    subscribed/unsubscribed labels, optional explanatory copy, status/count
    metadata, compact/detail densities, disabled and busy states, and
    product-owned task subscription APIs, actor identity, email delivery,
    digest policy, permissions, localization, toasts, and route behavior.
63. Score scheduler edit dialog: controlled scheduler settings dialog with
    enabled state, cron-like pattern field, optional first-start datetime,
    status badge, metadata rows, error state, save/cancel actions, fixed and
    contained placements, and product-owned scheduler catalog validation,
    persistence, cron semantics, date conversion, permissions, audit events,
    host execution policy, toasts, and localization.
64. Score session refresh dialog: controlled re-authentication overlay with
    fixed and contained placements, backdrop, dismiss affordances, shared auth
    card composition, provider action or SDK-rendered provider slots,
    credential form slot, message/footer areas, Escape close behavior, and
    product-owned unauthorized detection, token exchange, OAuth SDK loading,
    actor refresh, route/draft preservation, toasts, validation, and
    localization.
65. Score checklist editor panel: controlled definition-of-done editor with
    add/remove controls, editable checklist text rows, optional checked state,
    row metadata, empty state, compact/comfortable density, read-only mode, and
    product-owned project checklist persistence, autosave, validation, ordering,
    permissions, routing, task generation, localization, and toast behavior.
66. Score process run history panel: controlled timeline for recent host-side
    process/scheduler runs with running/succeeded/failed exit-code state,
    started/ended/duration metadata, command blocks, optional output excerpts,
    loading/error/empty states, compact/comfortable density, and product-owned
    process execution, log retention, command authorization, output redaction,
    date formatting, audit behavior, persistence, routing, and toasts.
67. Score and eLitua file upload control: native file-input affordance with
    button and dashed dropzone presentation, icon/copy/meta slots, accept and
    selected-file labels, disabled/busy states, multiple-file support, optional
    reset-after-select behavior, and product-owned upload transport, file
    validation, signed URLs, moderation policy, profile/task persistence,
    localization, and toast behavior.
68. Score work item card: controlled board-card shell with title/open
    affordance, item id, metadata badges, parent-epic link, compact facts,
    secondary open link, action/footer slots, selected/disabled states, and
    product-owned task DTO mapping, route ownership, actor labels, workflow
    command filtering, transition dispatch, persistence, notifications, and
    toast behavior.
69. Score and eLitua switch control: controlled binary setting row with label,
    description, status metadata, native switch checkbox semantics, compact and
    comfortable density, framed and plain variants, disabled/read-only states,
    and product-owned setting persistence, scheduler guard semantics, consent
    policy, auth, localization, toasts, analytics, and audit behavior.
70. eLitua brand image link: responsive linked brand image with accessible link
    label, desktop and optional mobile image sources, `srcSet`/`sizes`,
    explicit dimensions, async decoding, optional text lockup, and
    product-owned asset path resolution, route adapters, brand policy, image
    hosting, analytics, and theme selection.
71. eLitua info chip list: presentational read-only chip groups for guide
    profile languages, route tags, credentials, and compact metadata with
    optional icons, tone variants, link/click affordances, compact/comfortable
    densities, empty fallback, and product-owned item derivation, routing,
    GraphQL loading, translations, analytics, profile composition, and
    persistence.
72. Score and eLitua metric grid: reusable label/value/detail metric tiles for
    operational dashboards, integration status, profile/account summaries, and
    admin panels with icons, tone variants, compact/comfortable densities,
    empty state, auto or fixed column counts, and product-owned fetching,
    formatting, thresholds, polling, routing, localization, analytics, and
    persistence.
73. Score and eLitua data state panel: generic non-auth route/data state shell
    for loading, empty, not-found, success, warning, and error outcomes with
    tone-aware icon, title, optional body/action/footer slots, compact and
    comfortable densities, and product-owned fetching, retry policy, routing,
    localization, redirects, toasts, permissions, and error mapping.
74. eLitua contact link list: standalone phone, email, website, and support
    contact action list with icons, labels, href/click actions, external-link
    handling, disabled and empty states, pill/plain variants, compact and
    comfortable densities, and product-owned contact derivation, URL
    normalization, visibility policy, routing adapters, localization,
    analytics, and record loading.
75. Score and eLitua validation summary: form-level validation summary with
    title, description, action, footer, field-linked issue rows, success/empty
    state, compact and comfortable densities, and product-owned validation
    schemas, focus routing, submit handling, API mapping, localization, toasts,
    and persistence.
76. Score and eLitua action group: neutral responsive action-row layout for
    toolbar, dialog, form footer, and compact card command slots with alignment,
    gap, orientation, mobile stacking, and product-owned command behavior,
    routing, permissions, validation, localization, persistence, and analytics.
77. Score and eLitua search field: controlled icon-led search input with
    visible or hidden label, optional description, clear action, trailing
    utility slot, result metadata, compact/comfortable density, toolbar/default
    variants, and product-owned query parsing, routing, image search, filtering,
    debouncing, localization, analytics, and persistence.
78. Score and eLitua icon input field: neutral labeled input control with
    optional leading icon, trailing action, hint/error text, hidden-label mode,
    compact/comfortable density, disabled state, and product-owned validation,
    masking, secret reveal state, submit behavior, routing, localization,
    analytics, and persistence.
79. eLitua theme mode toggle: controlled icon theme action for public header,
    account menu, toolbar, and settings chrome with light/dark/system modes,
    compact and comfortable density, optional label, ghost/button variants,
    accessible action labels, stable sizing, and product-owned theme context,
    persistence, localization, media-query detection, analytics, and placement.
80. Score and eLitua combobox field: controlled single-value datalist selector
    with visible/hidden label, generated suggestion options, optional icon,
    clear/action slots, hint/error/meta text, compact and comfortable density,
    disabled state, and product-owned option loading, normalization,
    validation, routing, localization, persistence, analytics, task relation
    semantics, and profile mutation behavior.
81. Score and eLitua checkbox control: controlled non-switch checkbox row for
    selection, automation gates, direct grants, form flags, and verified record
    rows with label/description/status slots, compact and comfortable density,
    framed/plain variants, indeterminate state, and product-owned selection
    math, persistence, permissions, validation, localization, toasts, analytics,
    and routing.
82. Composition framework: full-page mockup registry, named grid slots,
    component-id metadata, stable Score work board and eLitua sample
    compositions, and Catalog Explorer mockup gallery/inspect routes.
83. eLitua map marker pin: presentational map marker glyphs for pin, dot, and
    cluster states with selected/tone variants, caller-supplied icons, optional
    visible labels, and product-owned Google Maps marker lifecycle, clustering,
    z-index, click handling, coordinate dispatch, route/query state, and
    localization.
84. Score and eLitua description list: reusable label/value details for guide
    credentials, record metadata, task facts, and diagnostics with optional
    icons, links, tones, compact/comfortable density, plain/card variants,
    responsive columns, and product-owned DTO mapping, date formatting, route
    generation, permissions, localization, and persistence.
85. Score and eLitua identity avatar: standalone image/initials/icon avatar
    primitive for account triggers, profile heroes, agent identity chrome, and
    editorial bylines with size, shape, tone, and status-dot variants while
    product-owned profile data, image URLs, verification semantics, role labels,
    routing, auth state, and uploads stay local.
86. Score and eLitua status indicator: standalone status-dot primitive with
    label, optional detail, icon, action slot, tone variants, inline/bar/pill
    densities, and product-owned runtime health calculations, provider
    connection tests, profile verification semantics, polling, routing,
    persistence, and localization.
87. Score and eLitua payload block: reusable preformatted JSON/text/log payload
    surface with title, description, label/language, status badge, metadata
    rows, action slot, copy callback, compact/comfortable density,
    panel/plain variants, scroll/wrap modes, and product-owned fetching,
    parsing, redaction, clipboard persistence, routing, retention, audit
    behavior, and localization.
88. Score and eLitua section panel: reusable titled section chrome with icon,
    eyebrow, description, badges, action slot, body slot, footer slot,
    compact/comfortable density, card/plain/subtle variants, and product-owned
    field layouts, validation, persistence, routing, permissions,
    translations, and API behavior.
89. Score work board active filters: WorkBoardToolbar support for counted
    project/epic/search filter options, removable active filter chips, optional
    reset action slot, responsive wrapping/truncation, and product-owned route
    synchronization, count derivation, search parsing, permissions, task
    creation, claim dispatch, refresh, toasts, and reset semantics.
90. Score component review panel: one-component inspection surface with
    metadata, controlled preview variants, canvas width controls, review tabs,
    variant cards, and product-owned registry loading, search, routes, markdown
    parsing, package discovery, persistence, analytics, and adoption workflow.
91. Score KanbanBoard lane shell: controlled workflow board lanes with
    horizontal/single/wrapped layouts, lane counts, descriptions, action/footer
    slots, empty states, custom task render slots, stable minimum column widths,
    and product-owned task fetching, route synchronization, workflow commands,
    move dispatch, drag/drop policy, permissions, persistence, toasts, and
    analytics.
92. Score theme audit panel: presentational token-coverage and hardcoded-value
    review surface with metric badges, grouped token lists, gap rows, no-gap
    states, notes, action slot, and product-owned token scanning, CSS parsing,
    theme vocabulary, coverage math, registry loading, routing, persistence,
    analytics, and adoption workflow.
93. Score facet filter panel: presentational counted-facet filtering surface
    with grouped options, active filter chips, optional Any/All match controls,
    reset action, and product-owned registry loading, count derivation, search
    parsing, URL synchronization, saved filters, analytics, and persistence.
94. Score preview matrix panel: presentational fixture comparison matrix with
    item/variant rows, arbitrary comparison columns, caller-supplied preview
    cells, status badges, empty/missing states, and product-owned registry
    loading, theme definitions, coverage math, route state, generated previews,
    analytics, permissions, and adoption workflow.
95. Score theme lab panel: controlled theme proposal review surface with
    prompt and iteration text areas, generate/apply action descriptors,
    proposal summary, model/status badges, swatch groups, empty/busy states,
    and product-owned model API calls, prompt validation, previous-proposal
    payloads, preview application, persistence, token vocabulary, routes,
    analytics, permissions, save/export flows, and toast behavior.
96. Score discovery cloud panel: controlled linked-cloud surface for catalog
    pattern and keyword discovery with grouped cloud items, counts, active and
    disabled states, compact density, href/button/inert rendering, and
    product-owned keyword extraction, count derivation, route synchronization,
    search matching, analytics, and persistence.
97. Score compare tray panel: controlled pinned-card comparison surface with a
    current-item pin action, count badge, removable preview cards, badge/meta
    rows, empty and compact states, and product-owned compare-id URL state,
    registry loading, preview fixture generation, selected-current detection,
    analytics, permissions, localization, and adoption workflow.
98. Score theme preview canvas: controlled current/generated/compare theme
    fixture canvas with dashed scrollable shell, multi-surface theme grids,
    labeled surface headers, badge/icon slots, caller-supplied token styles,
    constrained fixture width, render-function fixture slots, and product-owned
    theme generation, token validation, registry loading, selected variant
    state, routes, analytics, permissions, persistence, and adoption workflow.
99. Score work item relation editor panel: controlled task-relation edit
    surface with dependency/blocker/related relation tag fields, shared
    status/title chrome, action row, loading/error states, and product-owned
    task DTO mapping, issue-id normalization, hash-route parsing, duplicate/self
    link prevention, dirty-state calculation, permissions, API persistence,
    toasts, and localization.
100. eLitua simple cookie banner: controlled accept-all / essential-only cookie
     notice variant with optional manage/reject/accept action visibility,
     inverse dark tone, privacy-link slot, responsive bottom-docked layout, and
     product-owned consent persistence, legal copy, i18n, route handling,
     consent versioning, SDK activation, and analytics behavior.
101. Score project profile panel: presentational project-detail surface with
     project identity, status badges, route/action slots, metadata fields,
     description, definition-of-done checklist rows, loading/empty/error
     states, attachment slot, and product-owned route parsing, API mapping,
     attachment mutations, confirmations, permissions, date formatting, toasts,
     and repository URL handling.
102. Score and eLitua collapsible disclosure: controlled or uncontrolled
     disclosure primitive with title, count, action slot, compact/comfortable
     densities, aria-expanded/aria-controls wiring, and product-owned filter
     derivation, preference persistence, route synchronization, legal copy,
     analytics, validation, and row semantics.
103. Score project directory panel: presentational project-directory route
     surface with title/status/action chrome, loading/error/empty states,
     responsive project cards, key labels, descriptions, metadata badges,
     link/callback/read-only item rendering, and product-owned project loading,
     access filtering, sorting, route construction, toast behavior, and
     eventual Score adoption.
104. Score subscription capacity panel: presentational provider-subscription
     capacity route surface with summary metrics, account identity/status rows,
     capacity and reset summaries, bound-agent badges, reporter diagnostics,
     payload disclosure, loading/error/empty states, and product-owned
     subscription/agent APIs, capacity parsing, threshold policy, route
     construction, persistence, RBAC, polling, toasts, and localization.
105. Score accessibility audit panel: presentational component-preview audit
     surface with manual notes, idle/running/pass/issues/unavailable states,
     pass and violation summaries, severity chips, rule ids, docs links,
     affected selectors, optional preview canvas, and product-owned axe-core
     execution, selected preview state, routing, persistence, analytics,
     adoption workflow, and localization.
106. Score and eLitua payload disclosure: `PayloadBlock` support for controlled
     or uncontrolled collapsed payload bodies, keyboard-operable disclosure
     headers, and table/sidebar-safe compact plain rendering while product apps
     keep payload fetching, parsing, redaction, retention, clipboard behavior,
     routing, localization, and audit policy local.
107. Score component playground panel: presentational catalog playground
     surface with a labelled control rail, reset/copy commands, live preview
     stage, canvas/status badge, JSX snippet block, boolean/select/number/text
     control support, and product-owned registry schemas, routes, theme preview
     modes, responsive canvas state, fixture rendering, clipboard writes,
     analytics, permissions, toasts, and adoption workflow.
108. Score nudger schedule editor fields: `ScheduleEditorDialog` support for
     controlled secondary checks and configurable text/select/textarea fields
     covering scheduler nudger id, name, description, assigned agent, project,
     workflow, prompt, suspended state, schedule pattern, and first-start time
     while product apps keep option loading, DTO mapping, cron validation, date
     conversion, host execution policy, persistence, permissions, audit events,
     confirmations, and toasts local.
109. eLitua selectable editable-form result rows: `EditableFormResultList`
     support for selectable lookup/geocoding candidates with `onSelect`,
     selected and disabled states, focus styling, and trailing action slots
     while product apps keep candidate loading, map pin mutation, coordinate
     persistence, validation, translations, debounce, and toast behavior local.
110. Score component catalog panel: presentational catalog browsing shell with
     title/status/action chrome, searchable component navigation, item metadata
     and badges, optional sidebar/sidebar-footer slots, empty list handling,
     compact density, and product-owned registry loading, route/hash state,
     preview rendering, facet derivation, theme controls, analytics,
     permissions, toasts, and adoption workflow.
111. Score and eLitua field control primitive: labeled field wrapper with
     optional meta, required marker, hint, error, hidden-label, disabled state,
     native input/select/textarea helpers, and product-owned values,
     validation, option catalogs, persistence, routing, localization,
     submission, and analytics.
112. eLitua booking widget panel: presentational public guide/product booking
     section with provider identity, availability status, booking detail rows,
     consent notice, fallback messaging, action/footer slots, and an opaque
     third-party widget slot while eLitua keeps Bókun script loading, widget id
     mapping, cookie-consent gating, analytics events, checkout handoff,
     availability data, routing, translations, and provider policy local.
113. Score workspace page frame: route-content frame with default, board,
     operational, full-width, and standalone object layouts, constrained widths,
     object-route overflow, responsive padding, and product-owned route mapping,
     boot state, feature selection, close/back behavior, and toasts.
114. Score and eLitua command palette: controlled grouped quick-jump overlay
     with search input, fixed and contained placements, active/disabled command
     rows, metadata, group empty states, global no-match messaging, shortcut
     hint, Escape/backdrop/close handling, and product-owned shortcut binding,
     fuzzy matching, menu registries, routing, theme application, analytics,
     localization, persistence, and command execution.
115. Score dialog frame: controlled generic modal frame with fixed and
     contained placements, labelled header, optional eyebrow/status/actions,
     close affordances, scrollable body, footer slot, size presets, and
     product-owned route parsing, data loading, focus policy, validation,
     mutations, permissions, analytics, localization, and toasts.
116. eLitua table of contents nav: presentational article/document section
     navigation with caller-supplied h2/h3 links, active current-location state,
     optional row meta, disabled rows, card/plain variants, compact density,
     and product-owned heading extraction, slug generation, observers, routing,
     analytics, localization, CMS data, and adoption workflow.
117. Score and eLitua filter drawer panel: presentational filter shell with
     inline and controlled drawer modes, title/description chrome, summary and
     state badges, header/footer action slots, independently scrolling body,
     compact/comfortable density, and product-owned query parsing, route
     synchronization, filter schemas, result counts, persistence, permissions,
     translations, map synchronization, and toasts.
118. Score file preview panel: presentational single-file attachment preview
     surface with markdown preview composition, metadata rows, badges,
     built-in/overridden download action, loading/error/empty states, and
     unsupported-file fallback messaging while product apps keep attachment
     fetching, signed URLs, MIME detection, delete/open commands, permissions,
     route links, localization, and toasts local.
119. eLitua loading spinner: standalone indeterminate loading primitive with
     inline and centered variants, shared tone vocabulary, visible or hidden
     accessible labels, stable size presets, and reduced-motion handling while
     product apps keep async state, route guards, map SDK loading policy,
     retries, timeouts, localization, and data fetching local.
120. Score file action list panel: row-based project attachment list with kind
     icons, filename/content type, metadata, badges, loading/error/empty states,
     header action slots, and controlled per-file action menus while Score keeps
     attachment fetching, signed URLs, upload validation, browser directory
     downloads, copy/move persistence, delete confirmations, permissions,
     route ownership, localization, and toasts local.
121. Score resource transfer dialog: controlled copy/move target-selection
     dialog with selected resource summary, move checkbox, destination rows,
     empty/error state, disabled targets, busy/confirm-disabled state, and
     footer actions while Score keeps attachment IDs, target project loading,
     permission filtering, signed URLs, browser picker behavior, copy/move API
     calls, confirmations, route ownership, localization, and toasts local.
122. Score and eLitua select control: controlled native select primitive with
     label/status row, placeholder, leading icon, compact/comfortable density,
     hint/error/meta text, selected-option detail, loading/disabled state, and
     accessible descriptions while product apps keep option loading,
     permissions, validation, route/query state, localization, persistence,
     analytics, and Radix/custom dropdown migration policy local.
123. Score and eLitua temporal input control: controlled native date, time, and
     datetime-local primitive with label/status row, leading icon,
     compact/comfortable density, hint/error/meta text, disabled/read-only and
     accessible invalid states while product apps keep timezone conversion,
     formatting, validation policy, route/query state, GraphQL/API mutations,
     localization, persistence, analytics, and scheduler/profile semantics
     local.
124. Score and eLitua number input control: controlled native number primitive
     with label/status row, leading icon, prefix/suffix units,
     compact/comfortable density, hint/error/meta text, disabled/read-only and
     accessible invalid states while product apps keep parsing, precision,
     rounding, validation policy, coordinate/currency/unit semantics, route
     state, GraphQL/API mutations, localization, persistence, and analytics
     local.
125. Score and eLitua textarea control: controlled native multiline text
     primitive with label/status row, leading icon, compact/comfortable density,
     hint/error/meta/counter text, resize modes, disabled/read-only and
     accessible invalid states while product apps keep trimming, validation,
     markdown/JSON parsing, prompt policy, autosave, route state, GraphQL/API
     mutations, localization, persistence, and analytics local.
126. Score and eLitua text input control: controlled native single-line
     text/email/url/tel/password/search primitive with label/status row,
     leading icon, prefix/suffix/action slots, compact/comfortable density,
     hint/error/meta/counter text, disabled/read-only and accessible invalid
     states while product apps keep validation, masking, password reveal,
     normalization, route state, GraphQL/API mutations, localization,
     persistence, credential policy, and analytics local.
127. eLitua controlled pager: controlled pagination chrome with optional
     first/last controls, previous/next buttons, boundary-disabled states,
     full and compact result summaries, accessible labels, and product-owned
     pagination math, page-size state, selected-record synchronization,
     sorting/filtering, route updates, localization, persistence, analytics,
     and data fetching.
128. Score file preview dialog: controlled popup file viewer with rendered
     Markdown `View`, raw `Src`, header download/open actions, long filename
     handling, mobile dialog layout, and product-owned attachment APIs, signed
     URLs, MIME policy, route state, permission checks, Markdown fetching,
     localization, analytics, toasts, and adoption workflow.
129. Score theme export panel: controlled theme-token export controls with
     format selection, copy/download/custom action descriptors, export-scope
     badges, optional serialized output preview, and product-owned token
     serialization, CSS scope reading, browser clipboard/download behavior,
     route state, permissions, analytics, toasts, and adoption workflow.
130. eLitua newsletter signup panel: controlled editorial signup CTA with icon,
     title, description, email input, submit action, busy/disabled/error states,
     success message, footer/action slots, compact/comfortable density, and
     product-owned newsletter provider calls, opt-in policy, localization,
     persistence, analytics, anti-spam handling, and toasts.
131. eLitua geocoding control panel: presentational admin GeoForm geocoding
     control surface with controlled coordinate source actions, search query
     row, selected coordinate summary, loading/error states, candidate rows,
     compact/comfortable density, and product-owned Google Maps calls, debounce
     timing, coordinate parsing, map pin dispatch, selected entity state,
     translations, persistence, validation, and toasts.
137. Score design idea board panel: presentational Catalog Explorer
     mockup-porting review board with summary metrics, lane columns, idea cards,
     source links, target/priority badges, owner-boundary notes, blockers,
     compact/comfortable density, empty lane states, and product-owned mockup
     routes, adoption workflow, persistence, analytics, task creation, and
     permissions.
138. UIF-E2 material-parity primitives: the complete slice listed in the
     Component Contract uses the shared E1 theme/state/density vocabulary and
     remains flat. `Button` includes primary/danger/ghost/quiet emphasis while
     preserving secondary compatibility; `Menu` owns dropdown keyboard/focus
     semantics; `TablePrimitive` owns native table, sticky header, internal
     scroll, and controlled selection semantics without replacing app-level
     `DataTable`; the one `Chip` renderer backs Status/Band/Class/Model
     taxonomies; unknown `Meter` values are always neutral-striped and never
     full/OK (B31); `FreshnessBadge` mirrors Score `timing.ts` age buckets and
     requires consumers to opt into any stale threshold explicitly; stateful
     controls keep current-state-first/next-action labels synchronized.
139. UIF-E4 composite consolidation:
     - **E4.1 DataTable:** `DataTable` MUST compose `TablePrimitive` and MUST
       NOT render native table markup itself. It provides controlled or
       uncontrolled sort, pagination, and selection through the existing
       headless engine; composes `Toolbar` for caller-supplied search/filter,
       export, and bulk-action controls; and delegates loading, empty, and error
       rendering to `DataStatePanel`. Export serialization, filter schemas,
       server pagination, fetching, routes, and persistence remain caller-owned.
     - **E4.2 SectionCard:** `SectionCard` is the explicit page-owned depth-one
       surface aligned with the v4 section header/body/footer contract. It is
       allowed only at a page or page-layout boundary, uses token spacing, and
       owns no outer margin. Shared child components remain flat and MUST NOT
       render a `SectionCard` internally.
     - **E4.3 Field rows:** `DescriptionList` MUST render every visible fact
       through one flat `FieldRow` implementation. The list parent owns columns
       and gap; `FieldRow` owns no card, padding, margin, border, or shadow. The
       card-item variant is retired. This `FieldRow` is the read-only fact
       renderer exposed by `#/c/description-list`; `AuthFieldRow` and
       `.ui-auth-field-row` are editable auth-input layout and MUST NOT be used
       as consolidation evidence. Editable inputs continue to use `Field`.
     - **E4.4 Data states:** `EmptyState` and `LoadingState` are typed
       `DataStatePanel` presets with no separate CSS or semantics. Loading
       placeholders compose `Skeleton`, expose one containing busy/status
       announcement, respect reduced motion, and do not announce every
       decorative skeleton.
     - **E4.5 Confirmation:** `ConfirmationDialog` remains the only generic
       confirm overlay and action frame. `BlastRadiusConfirm` MUST compose it
       and render caller-computed live impact. Fixed dialogs trap and restore
       focus; busy state locks every dismissal path; destructive emphasis is
       visual only and never substitutes for authorization. The source gate
       MUST reject browser-global `window.confirm` and unqualified
       `confirm(...)` calls without rejecting domain methods named `confirm`;
       fixture tests prove both rejected and allowed forms.
     - **E4.6 Stateful labels:** table sort and selection controls MUST keep a
       synchronized accessible name/tooltip that states the current state
       before the resulting action or next state.
     - **E4.7 Finality:** the final consolidation gate MUST delete the legacy
       `DataTable`, `DataTableView`, `PagedDataTable`, `SectionPanel`, retired
       card-row styles, old catalog ids, and their internal call sites. The
       build MUST include fitness checks proving one table composite, the
       explicit `SectionCard` import boundary, no retired symbols/classes, and
       no native confirm calls.
     - **E4.8 Catalog evidence:** catalog search and direct navigation MUST
       expose the prerequisite E2 `Skeleton` at `#/c/skeleton` and the canonical
       read-only row through `DescriptionList` at `#/c/description-list`.
       Verification MUST use a built artifact containing the candidate head or
       an integrated descendant; an older deployed bundle is not acceptance
       evidence. The Skeleton entry remains the one E2 primitive and E4 loading
       presets compose it rather than registering a second skeleton surface.

## Deployment

- Local endpoint: `127.0.0.1:8283`
- Public endpoint: `ui-lib.ayc.io`
