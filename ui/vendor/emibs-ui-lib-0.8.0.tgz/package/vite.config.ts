import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { defineConfig, type UserConfig } from "vite";

/** Vitest options carried on the shared vite config. */
type VitestOptions = {
  setupFiles: string[];
};

// `defineConfig` is imported from "vite", not "vitest/config": vitest 2 ships
// its own nested copy of vite, so importing its `defineConfig` gives the plugin
// array a second, incompatible vite type identity and `tsc` rejects the
// otherwise-valid `plugins` value. Vitest 2 also dropped the `declare module
// "vite"` augmentation that used to add `test` to vite's `UserConfig`, so the
// key is typed locally and passed as a variable — an object literal would trip
// TypeScript's excess-property check. Vitest reads `test` from the config at
// runtime regardless of which `defineConfig` wrapped it.
const config: UserConfig & { test: VitestOptions } = {
  plugins: [react(), tailwindcss()],
  test: {
    // Runs before every test module is evaluated, in whatever environment that
    // file declared. It repairs the `happy-dom` defect that silently disables
    // DOMPurify — without it, sanitizer assertions in this package are
    // meaningless, because raw `DOMPurify.sanitize()` returns markup with
    // `<script>` and `onerror` still in it. The file documents exactly what is
    // repaired, what is NOT (happy-dom's `NodeIterator` desync), and the
    // one-hostile-payload-per-render rule that follows from it. Read it before
    // writing any test that asserts sanitizer behavior.
    setupFiles: ["./tests/setup/happyDomSanitizerEnv.ts"],
  },
};

export default defineConfig(config);
