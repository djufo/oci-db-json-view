import { describe, expect, it } from "vitest";
import {
  allowedSectionCardImporters,
  findRetiredCatalogIds,
  findRetiredTokens,
  retired,
  retiredCatalogIds,
} from "./check-composite-finality.mjs";

describe("SectionCard allow-list", () => {
  // The allow-list is the whole of the "SectionCard is composed by pages and
  // layouts, and by nothing else" rule, and until this test existed it could be
  // widened by adding one line, with every check in the repo still green. That
  // makes a rule that is enforced indistinguishable from one that is not.
  //
  // Pinning the exact membership does not forbid widening it — it makes
  // widening a deliberate, visible act: the guard and this list have to be
  // changed together, and the second change is the one a reviewer sees.
  it("pins the exact membership, so widening it cannot pass unnoticed", () => {
    expect([...allowedSectionCardImporters].sort()).toEqual([
      "catalog/registry/demoComponents/catalogTooling.tsx",
      "catalog/registry/demoComponents/feedback.tsx",
      "catalog/registry/demoComponents/layout.tsx",
      "catalog/registry/demoComponents/theming.tsx",
      "catalog/registry/demos.tsx",
      "catalog/registry/states/layout.tsx",
      "catalog/registry/variants/layout.tsx",
      "components/canonicalComposites.test.tsx",
      "components/layout/SectionCard.test.tsx",
    ]);
  });

  it("admits only catalog registry entries, the composite tests and SectionCard's own test", () => {
    // The shape of the rule, stated separately from the literal list: nothing
    // in the shared component directories or in forms/ may appear here, because
    // those are exactly the files the flat-component rule below forbids.
    for (const file of allowedSectionCardImporters) {
      expect(file, `${file} is not a page/layout composition site`).toMatch(
        /^(?:catalog\/registry\/|components\/canonicalComposites\.test\.tsx$|components\/layout\/SectionCard\.test\.tsx$)/,
      );
    }
  });
});

describe("composite finality retirement lists", () => {
  it("registers the FilterBar retirement across all three lists", () => {
    expect(retired).toContain("FilterBar");
    expect(retired).toContain("ui-filter-bar");
    expect(retiredCatalogIds).toContain("filter-bar");
  });
});

describe("retired symbol matching", () => {
  it("catches a retired component identifier however it is written", () => {
    expect(findRetiredTokens("import { FilterBar } from './FilterBar';")).toEqual(["FilterBar"]);
    expect(findRetiredTokens("<FilterBar density=\"compact\" />")).toEqual(["FilterBar"]);
    // The exact regression that escaped the guard: a stale state-preview title.
    expect(findRetiredTokens('{ id: "stale", title: "FilterBar" }')).toEqual(["FilterBar"]);
  });

  it("catches the retired CSS class in a stylesheet block and its BEM parts", () => {
    expect(findRetiredTokens(".ui-filter-bar {\n  display: flex;\n}")).toEqual(["ui-filter-bar"]);
    expect(findRetiredTokens(".ui-filter-bar__actions {}")).toEqual(["ui-filter-bar"]);
    expect(findRetiredTokens(".ui-filter-bar--compact {}")).toEqual(["ui-filter-bar"]);
    expect(findRetiredTokens('<div className="ui-filter-bar">')).toEqual(["ui-filter-bar"]);
  });

  it("leaves the live FilterDrawerPanel and ui-filter-drawer untouched", () => {
    const live = [
      'import { FilterDrawerPanel } from "../../../components/data/FilterDrawerPanel";',
      "export type FilterDrawerPanelProps = { mode?: FilterDrawerPanelMode };",
      "<FilterDrawerPanel mode=\"drawer\" title=\"Board filters\" />",
      ".ui-filter-drawer__panel--compact .ui-filter-drawer__body { gap: 0; }",
      ".filter-drawer-demo-stage .ui-filter-drawer__mount { inset: 0; }",
    ].join("\n");

    expect(findRetiredTokens(live)).toEqual([]);
    expect(findRetiredCatalogIds(live)).toEqual([]);
  });

  it("does not fire on a longer word that merely starts with a retired name", () => {
    expect(findRetiredTokens("const FilterBarrier = 1;")).toEqual([]);
    expect(findRetiredTokens(".ui-filter-barcode { width: 1px; }")).toEqual([]);
    expect(findRetiredTokens("const ProductSectionPanelHost = 1;")).toEqual([]);
  });

  it("still fires on derivatives of a retired name", () => {
    expect(findRetiredTokens("export type FilterBarProps = {};")).toEqual(["FilterBar"]);
    expect(findRetiredTokens(".ui-empty-state {}")).toEqual(["ui-empty"]);
  });
});

describe("retired catalog id matching", () => {
  it("catches the retired id in every catalog reference shape", () => {
    expect(findRetiredCatalogIds('{ id: "filter-bar", name: "Filters" }')).toEqual(["filter-bar"]);
    expect(findRetiredCatalogIds('<section id="filter-bar">')).toEqual(["filter-bar"]);
    expect(findRetiredCatalogIds('{ href: "#filter-bar" }')).toEqual(["filter-bar"]);
    expect(findRetiredCatalogIds('{ id: "filter-bar-legacy" }')).toEqual(["filter-bar"]);
  });

  it("does not fire on live ids or on unrelated words", () => {
    expect(findRetiredCatalogIds('{ id: "filter-drawer-panel" }')).toEqual([]);
    expect(findRetiredCatalogIds('{ id: "filter-barcode" }')).toEqual([]);
    expect(findRetiredCatalogIds('// the filter-bar component was retired')).toEqual([]);
  });
});
