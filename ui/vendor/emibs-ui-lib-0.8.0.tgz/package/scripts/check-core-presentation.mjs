import { readdirSync, readFileSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath } from "node:url";

// Core (src/core) is presentation-free: hooks and pure functions are allowed,
// but JSX, element construction, DOM rendering, and icon/presentation imports
// are not. dependency-cruiser guards MODULE boundaries; this guard catches
// presentation that lives inside an otherwise-allowed React dependency (e.g. a
// `.ts` core file calling `React.createElement` or importing an icon set),
// which a `.tsx`-only or import-graph check would miss (issue-584 / issue-1262).

const packageRoot = fileURLToPath(new URL("..", import.meta.url));
const coreRoot = join(packageRoot, "src/core");
const violations = [];

// Presentation signals forbidden anywhere in core source (.ts and .tsx).
const forbiddenPatterns = [
  {
    // React.createElement(...) or a bare createElement(...) call — JSX by hand.
    test: /\bcreateElement\s*\(/,
    reason: "uses createElement (build UI outside core)",
  },
  {
    // The JSX runtime factories emitted for .tsx — importing them by hand.
    test: /from\s+['"]react\/jsx-(dev-)?runtime['"]/,
    reason: "imports the react JSX runtime (presentation)",
  },
  {
    // Rendering into the DOM belongs to a presentation layer, not core.
    test: /from\s+['"]react-dom(\/[^'"]*)?['"]/,
    reason: "imports react-dom (DOM rendering)",
  },
  {
    // Icon sets are presentation.
    test: /from\s+['"]lucide-react['"]/,
    reason: "imports lucide-react (icons / presentation)",
  },
];

function walk(directory) {
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) {
      walk(path);
      continue;
    }
    if (!entry.isFile()) {
      continue;
    }
    const relPath = relative(packageRoot, path);
    // No JSX file may live in core at all.
    if (entry.name.endsWith(".tsx")) {
      violations.push(`${relPath}: is a .tsx file (JSX belongs outside core)`);
      continue;
    }
    if (!entry.name.endsWith(".ts")) {
      continue;
    }
    const source = readFileSync(path, "utf8");
    for (const { test, reason } of forbiddenPatterns) {
      if (test.test(source)) {
        violations.push(`${relPath}: ${reason}`);
      }
    }
  }
}

walk(coreRoot);

if (violations.length > 0) {
  console.error(
    "Core must remain presentation-free (issue-584). Fix these violations:",
  );
  for (const violation of violations) {
    console.error(`- ${violation}`);
  }
  process.exit(1);
}

console.log("check-core-presentation: src/core is presentation-free.");
