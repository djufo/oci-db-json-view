import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { importsBinding } from "./check-import-source.mjs";

const fixturePath = (name) =>
  fileURLToPath(new URL(`./fixtures/import-source-gate/${name}`, import.meta.url));

const importsSectionCard = (name) =>
  importsBinding(fixturePath(name), readFileSync(fixturePath(name), "utf8"), "SectionCard");

describe("import source gate", () => {
  it("detects real import declarations that bind the name", () => {
    expect(importsSectionCard("named-import.tsx")).toBe(true);
    expect(importsSectionCard("default-import.tsx")).toBe(true);
    expect(importsSectionCard("namespace-import.ts")).toBe(true);
  });

  it("detects aliased named imports on either side of the alias", () => {
    expect(importsSectionCard("aliased-import.tsx")).toBe(true);
    expect(importsSectionCard("aliased-to-name.tsx")).toBe(true);
  });

  it("ignores type-only imports, which carry no runtime composition dependency", () => {
    expect(importsSectionCard("type-only-import.ts")).toBe(false);
    expect(importsSectionCard("inline-type-import.ts")).toBe(false);
  });

  it("ignores usage-snippet template literals that document an import", () => {
    expect(importsSectionCard("usage-snippet.ts")).toBe(false);
    expect(importsSectionCard("unterminated-preceding-import.ts")).toBe(false);
  });

  it("ignores single- and double-quoted strings that spell out an import", () => {
    expect(importsSectionCard("quoted-strings.ts")).toBe(false);
  });

  it("ignores comments mentioning the name", () => {
    expect(importsSectionCard("comment.tsx")).toBe(false);
  });

  it("ignores identifiers, property names, JSX attributes, and JSX text", () => {
    expect(importsSectionCard("incidental-mentions.tsx")).toBe(false);
  });

  it("ignores files importing something else and side-effect-only imports", () => {
    expect(importsSectionCard("other-import.tsx")).toBe(false);
    expect(importsSectionCard("bare-import.ts")).toBe(false);
  });

  it("resolves other binding names independently", () => {
    const path = fixturePath("other-import.tsx");
    const source = readFileSync(path, "utf8");
    expect(importsBinding(path, source, "PageHeader")).toBe(true);
    expect(importsBinding(path, source, "StatusStrip")).toBe(true);
    expect(importsBinding(path, source, "SectionCard")).toBe(false);
  });
});
