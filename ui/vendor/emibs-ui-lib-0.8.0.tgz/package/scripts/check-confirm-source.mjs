import ts from "typescript";

function scriptKind(file) {
  return file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
}

function isBrowserGlobal(node) {
  return ts.isIdentifier(node) && (node.text === "window" || node.text === "globalThis");
}

function isConfirmPropertyAccess(node) {
  if (ts.isPropertyAccessExpression(node)) {
    return node.name.text === "confirm" && isBrowserGlobal(node.expression);
  }
  return ts.isElementAccessExpression(node)
    && isBrowserGlobal(node.expression)
    && ts.isStringLiteral(node.argumentExpression)
    && node.argumentExpression.text === "confirm";
}

/**
 * Finds browser-native confirmation calls without mistaking domain methods
 * such as `workflow.confirm()` or `this.confirm()` for browser globals.
 */
export function findNativeConfirmCalls(file, source) {
  const sourceFile = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, scriptKind(file));
  const failures = [];

  const visit = (node) => {
    if (ts.isCallExpression(node)) {
      if (ts.isIdentifier(node.expression) && node.expression.text === "confirm") {
        failures.push("unqualified confirm(...) is forbidden");
      } else if (isConfirmPropertyAccess(node.expression)) {
        failures.push("browser-native window.confirm is forbidden");
      }
    }
    ts.forEachChild(node, visit);
  };

  visit(sourceFile);
  return failures;
}
