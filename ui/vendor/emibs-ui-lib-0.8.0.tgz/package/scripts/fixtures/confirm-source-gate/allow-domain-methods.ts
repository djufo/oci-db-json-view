class ApprovalWorkflow {
  confirm() {
    return "approved";
  }

  commit() {
    return this.confirm();
  }
}

const workflow = new ApprovalWorkflow();
workflow.confirm();
