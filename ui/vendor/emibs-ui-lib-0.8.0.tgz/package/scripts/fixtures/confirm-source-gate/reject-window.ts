window.confirm("Delete this attachment?");
