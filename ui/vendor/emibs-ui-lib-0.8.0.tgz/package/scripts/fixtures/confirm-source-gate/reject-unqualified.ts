confirm("Delete this attachment?");
