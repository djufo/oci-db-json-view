confirm("Delete this attachment?");
