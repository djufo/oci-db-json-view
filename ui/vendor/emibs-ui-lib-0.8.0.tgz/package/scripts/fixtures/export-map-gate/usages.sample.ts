import type { UsageSnippet } from "../types";

// Shaped exactly like src/catalog/registry/usages/*.ts: an `import` field
// holding documentation TEXT, alongside the module's own real imports (above)
// which are NOT documentation and must not be collected.
export const sampleUsages: Record<string, UsageSnippet> = {
  "audit-timeline": {
    import: `import { AuditTimeline } from "emibs-ui-lib/components/data/AuditTimeline";`,
    snippet: `<AuditTimeline entries={entries} />`,
  },
  "auto-form": {
    import: `import { AutoForm } from "emibs-ui-lib/forms";\nimport { zodToSpec } from "emibs-ui-lib/core";`,
    snippet: `<AutoForm spec={spec} />`,
  },
  "identity-avatar": {
    import: `import { Bot } from "lucide-react";\nimport { IdentityAvatar } from "emibs-ui-lib/components/primitives/IdentityAvatar";`,
    snippet: `<IdentityAvatar icon={<Bot />} />`,
  },
  "activity-center": {
    import: `import { ActivityCenter } from "emibs-ui-lib/components/feedback/ActivityCenter";\nimport { useNotifications } from "emibs-ui-lib";`,
    snippet: `<ActivityCenter items={items} />`,
  },
  "not-a-doc": {
    // A snippet that merely MENTIONS an import inside prose or JSX text is not
    // an import declaration and carries no documented specifier.
    import: `// see the barrel: import { Thing } from "emibs-ui-lib/components/data/Ghost"`,
    snippet: `<pre>import { Thing } from "emibs-ui-lib/components/data/Ghost";</pre>`,
  },
};
