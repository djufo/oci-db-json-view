// Run in a REAL `node` child process (see check-export-map.test.mjs), never
// through vitest's own module transform: Vite's SSR runner replaces
// `import.meta` with a stub that has no `.resolve`, so `resolveAndVerify`
// cannot be exercised against genuine self-reference resolution in-process.
// Spawning a plain `node` process is what makes the directory/missing/
// symlink negative tests prove something about actual Node behavior rather
// than about a test-only stand-in.
//
// This file lives inside the fixture package on purpose: Node's self-
// reference resolution (see check-export-map.mjs's header note) resolves a
// bare package-name specifier against the NEAREST ANCESTOR package.json to
// the module calling `import.meta.resolve` — here, resolution-fixture/
// package.json — the same way `check-export-map.mjs` resolving
// "emibs-ui-lib/..." resolves against the real package's own manifest.
import { resolveAndVerify } from "../../../check-export-map.mjs";

const specifier = process.argv[2];
const result = resolveAndVerify((s) => import.meta.resolve(s), specifier);
process.stdout.write(JSON.stringify(result));
