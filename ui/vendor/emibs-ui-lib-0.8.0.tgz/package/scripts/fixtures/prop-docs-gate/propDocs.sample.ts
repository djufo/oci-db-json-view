import type { PropDocRow } from "../../../src/catalog/registry/types";

export const samplePropDocs: Record<string, PropDocRow[]> = {
  "simple-card": [
    { name: "title", type: "ReactNode", required: true, description: "Heading." },
    { name: "badges", type: "string[]", description: "Status chips." },
    { name: "onClose / closeLabel", type: "() => void / string", description: "Dismiss affordance." },
    { name: "SimpleCardRow.href / external", type: "string / boolean", description: "Row link target." },
    { name: "close", type: "() => void", description: "WRONG: no such top-level prop." },
  ],
};
