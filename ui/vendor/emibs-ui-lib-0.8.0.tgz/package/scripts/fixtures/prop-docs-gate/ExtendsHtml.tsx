import { type ButtonHTMLAttributes } from "react";

export type ExtendsHtmlProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  loading?: boolean;
};

export function ExtendsHtml(props: ExtendsHtmlProps) {
  return null;
}
