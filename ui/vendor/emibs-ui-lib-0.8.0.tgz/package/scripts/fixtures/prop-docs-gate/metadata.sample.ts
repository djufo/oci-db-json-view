import type { ComponentMeta } from "../../../src/catalog/types";

export const componentMeta: ComponentMeta[] = [
  { id: "simple-card", name: "SimpleCard", category: "data", sourceApp: ["Score"], patterns: ["Data, panels & boards"], specPath: "./SimpleCard.SPEC.md", hasSpec: true, status: "active" },
  { id: "extends-html", name: "ExtendsHtml", category: "primitives", sourceApp: ["Score"], patterns: ["Primitives & controls"], specPath: "./ExtendsHtml.SPEC.md", hasSpec: true, status: "active" },
  { id: "no-source", name: "NoSource", category: "data", sourceApp: ["Score"], patterns: ["Data, panels & boards"], specPath: "./NoSource.SPEC.md", hasSpec: true, status: "active" },
  { id: "no-docs", name: "NoDocs", category: "data", sourceApp: ["Score"], patterns: ["Data, panels & boards"], specPath: null, hasSpec: false, status: "catalogued" },
];
