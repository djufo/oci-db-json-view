# SimpleCard

## Contract

- Renders `title`, `badges`, `actions`, and `onClose`/`closeLabel` props.
- Rows carry `href` and `external`.
- Uses the `resolveWidgetTarget` helper internally (not a prop).
