// Hooks and utilities: excluded by naming convention, never by baseline entry.
export function usePanelState() {
  return { open: false };
}

export const formatPanelTitle = (title: string) => title.trim();
