import type { ComponentMeta } from "./types";

export const componentMeta: ComponentMeta[] = [
  { id: "panel", name: "Panel", category: "layout", specPath: "./Panel.SPEC.md", hasSpec: true, status: "active" },
];
