// Fixture public barrel for check-catalog-registration.mjs. Exercises every
// re-export form the real src/lib/index.ts uses: a star re-export, a named
// re-export with an alias, a type-only re-export, a star re-export of a
// directory reached through its own index, and a locally declared export.

export * from "./Panel";
export { InnerBadge as PanelBadge } from "./Panel";
export type { PanelProps } from "./Panel";
export * from "./nested";
export * from "./utils";

export const BARREL_VERSION = 2;
