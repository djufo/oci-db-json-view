import * as SectionCard from "emibs-ui-lib/components/layout/SectionCard";

export const title = SectionCard.displayName;
