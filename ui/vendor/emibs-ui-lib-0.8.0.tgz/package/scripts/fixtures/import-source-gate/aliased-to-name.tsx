import { LegacySectionPanel as SectionCard } from "emibs-ui-lib/components/layout/SectionCard";

export function Panel() {
  return <SectionCard title="Overview">body</SectionCard>;
}
