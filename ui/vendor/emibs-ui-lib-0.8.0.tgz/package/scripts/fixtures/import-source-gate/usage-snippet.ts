import type { UsageSnippet } from "../types";

export const layoutUsages: Record<string, UsageSnippet> = {
  "section-card": {
    import: `import { SectionCard } from "emibs-ui-lib";`,
    snippet: `<SectionCard title="Overview" description="Review shared route chrome.">body</SectionCard>`,
    variants: [
      { label: "aliased", snippet: `import { SectionCard as Card } from "emibs-ui-lib";` },
      { label: "default", snippet: `import SectionCard from "emibs-ui-lib/components/layout/SectionCard";` },
      { label: "namespace", snippet: `import * as SectionCard from "emibs-ui-lib";` },
    ],
  },
};
