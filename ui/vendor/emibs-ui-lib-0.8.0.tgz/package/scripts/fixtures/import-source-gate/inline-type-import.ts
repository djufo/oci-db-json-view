import { type SectionCard, formatSectionTitle } from "emibs-ui-lib/components/layout/SectionCard";

export type SectionCardLike = typeof SectionCard;
export const title = formatSectionTitle("Overview");
