import type { UsageSnippet } from "../types"

export const usages: Record<string, UsageSnippet> = {
  "section-card": { import: `import { SectionCard } from "emibs-ui-lib";`, snippet: `<SectionCard />` },
};
