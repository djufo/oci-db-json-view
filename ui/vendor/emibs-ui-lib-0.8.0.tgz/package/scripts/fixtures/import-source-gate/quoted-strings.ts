export const singleQuoted = 'import { SectionCard } from "emibs-ui-lib";';
export const doubleQuoted = "import { SectionCard } from 'emibs-ui-lib';";
export const concatenated = "import { " + "SectionCard" + " } from 'emibs-ui-lib';";
