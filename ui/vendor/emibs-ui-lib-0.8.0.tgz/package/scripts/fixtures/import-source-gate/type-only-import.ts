import type { SectionCard } from "emibs-ui-lib/components/layout/SectionCard";

export type SectionCardLike = typeof SectionCard;
