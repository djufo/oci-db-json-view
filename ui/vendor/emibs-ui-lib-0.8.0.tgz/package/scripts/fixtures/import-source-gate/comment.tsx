// Pages compose with `import { SectionCard } from "emibs-ui-lib";` — shared
// components must not.
/**
 * See SectionCard for the canonical section chrome.
 * import { SectionCard } from "emibs-ui-lib";
 */
import { Badge } from "emibs-ui-lib/components/feedback/Badge";

export function Panel() {
  return <Badge tone="info">ready</Badge>;
}
