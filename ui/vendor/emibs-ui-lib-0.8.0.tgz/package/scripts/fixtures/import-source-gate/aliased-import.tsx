import { SectionCard as Card } from "emibs-ui-lib/components/layout/SectionCard";

export function Panel() {
  return <Card title="Overview">body</Card>;
}
