import "emibs-ui-lib/components/layout/SectionCard.css";

export const note = "side-effect import only";
