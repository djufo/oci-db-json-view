import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { findColorViolations, isColorValuedProperty, isThemeTokenScope } from "./check-theme-tokens.mjs";
import { parseCss } from "./css-source.mjs";
import { applyBaseline, serializeBaseline, violationKey } from "./guard-baseline.mjs";

const fixture = (name) => readFileSync(new URL(`./fixtures/theme-token-gate/${name}`, import.meta.url), "utf8");
const run = (name) => findColorViolations(`fixtures/${name}`, fixture(name));
const values = (violations) => violations.map((violation) => violation.value);
const shape = (violations) =>
  violations.map((violation) => `${violation.selector} | ${violation.property}: ${violation.value}`);

describe("theme token gate — clean source", () => {
  it("passes a stylesheet that routes every colour through a token", () => {
    const { hard, soft } = run("clean.css");
    expect(hard).toEqual([]);
    expect(soft).toEqual([]);
  });
});

describe("theme token gate — violation classes", () => {
  it("flags every hex form, including two literals in one declaration", () => {
    const { hard, soft } = run("hex-colors.css");
    expect(values(hard)).toEqual(["#fff", "#1c2530", "#d9e0ea", "#1c25308a", "#abcd", "#ffffff", "#000000"]);
    expect(hard.every((violation) => violation.kind === "hex")).toBe(true);
    expect(soft).toEqual([]);
  });

  it("flags rgb() / rgba() / hsl() / hsla() literals in both syntaxes", () => {
    const { hard } = run("color-functions.css");
    expect(shape(hard)).toEqual([
      ".ui-fn__rgb | color: rgb(28, 37, 48)",
      ".ui-fn__rgba | background: rgba(28, 37, 48, 0.5)",
      ".ui-fn__space | border-color: rgb(255 255 255 / 0.24)",
      ".ui-fn__hsl | background: hsl(210 40% 96%)",
      ".ui-fn__hsla | box-shadow: hsla(210, 40%, 20%, 0.2)",
    ]);
  });

  it("flags every modern colour function, not just rgb() and hsl()", () => {
    const { hard } = run("modern-color-functions.css");
    expect(shape(hard)).toEqual([
      ".ui-modern__oklch | color: oklch(0.54 0.17 250)",
      ".ui-modern__oklab | background: oklab(0.72 -0.1 0.11)",
      ".ui-modern__lab | border-color: lab(52% 40 59)",
      ".ui-modern__lch | background: lch(52% 72 40)",
      ".ui-modern__hwb | color: hwb(194 0% 0% / 0.5)",
      ".ui-modern__color-fn | background: color(display-p3 1 0.5 0)",
      ".ui-modern__cmyk | color: device-cmyk(0 81% 81% 30%)",
      // A literal inside a color-mix() is still a literal (hex is scanned
      // before the functions, so it is listed first).
      ".ui-modern__mix-literal | background: #ffffff",
      ".ui-modern__mix-literal | background: oklch(0.54 0.17 250)",
    ]);
  });

  it("does not read color-mix() over tokens, or a colour-space word in a token NAME, as a literal", () => {
    const { hard, soft } = run("modern-color-functions.css");
    expect(shape(hard)).not.toContain(
      ".ui-modern__mix | background: color-mix(in oklab, var(--text) 6%, transparent)",
    );
    expect(shape([...hard, ...soft]).filter((entry) => entry.startsWith(".ui-modern__token"))).toEqual([]);
  });

  it("flags named colours in a colour-valued property", () => {
    const { hard } = run("named-colors.css");
    expect(shape(hard)).toEqual([
      ".ui-named__text | color: white",
      ".ui-named__border | border: tomato",
      ".ui-named__mix | background: black",
    ]);
  });

  it("finds violations nested inside at-rules and reports the full selector path", () => {
    const { hard } = run("nested-blocks.css");
    expect(shape(hard)).toEqual([
      "@media (max-width: 640px) .ui-nested__panel | background: #eef2f6",
      "@supports (color: color-mix(in oklab, red, blue)) .ui-nested__panel | border-color: rgb(185 196 209)",
      ".ui-nested__panel:hover | background: #eef2f6",
    ]);
  });

  it("reports the line each violation sits on", () => {
    const { hard } = run("hex-colors.css");
    expect(hard[0].line).toBe(4);
    expect(hard[0].file).toBe("fixtures/hex-colors.css");
  });
});

describe("theme token gate — exclusions", () => {
  it("never reports a --token definition written in a THEME SCOPE", () => {
    const { hard, soft } = run("token-definitions.css");
    expect(hard).toEqual([]);
    expect(soft).toEqual([]);
  });

  it("knows which selectors are a theme scope and which are a component rule", () => {
    const scope = (selector) => {
      const block = parseCss(`${selector} { --x: #fff; }`).blocks.find((b) => b.declarations.length > 0);
      return isThemeTokenScope(block);
    };
    // The element a whole token set is written onto.
    expect(scope(":root")).toBe(true);
    expect(scope("html")).toBe(true);
    expect(scope(":host")).toBe(true);
    expect(scope(':root[data-theme="dark"]')).toBe(true);
    expect(scope("html.dark")).toBe(true);
    // ThemeScope's own attribute (src/theme/ThemeScope.tsx).
    expect(scope('[data-color-scheme="dark"]')).toBe(true);
    // Component rules — including ones merely QUALIFIED by the root.
    expect(scope(".ui-status-indicator--info")).toBe(false);
    expect(scope("html .ui-card")).toBe(false);
    expect(scope('[data-density="compact"]')).toBe(false);
    // One component selector in the list is enough to disqualify the block.
    expect(scope(":root, .ui-card")).toBe(false);
  });
});

describe("theme token gate — a component-local custom property is not a theme token", () => {
  // The exemption for `--token: <colour>` was written as "the property starts
  // with `--`", which exempted a custom property declared in ANY rule. Ten
  // frozen pastels shipped through it on `.ui-status-indicator--*`.
  const { hard, soft } = run("component-local-tokens.css");

  it("flags a colour literal in a custom property declared on a component rule", () => {
    expect(shape(hard)).toEqual([
      ".ui-status-indicator--info | --ui-status-indicator-bg: #eff6ff",
      ".ui-status-indicator--info | --ui-status-indicator-border: rgb(191 219 254)",
      ".ui-status-indicator--success | --ui-status-indicator-bg: oklch(0.96 0.03 150)",
      ".ui-card | --card-border: tomato",
    ]);
  });

  it("leaves a component-local alias that routes through a token alone", () => {
    expect(shape(hard)).not.toContain(".ui-button | --ui-button-surface: var(--accent)");
  });

  it("reads a named colour only where the custom property's NAME is colour-valued", () => {
    expect(isColorValuedProperty("--card-border")).toBe(true);
    expect(isColorValuedProperty("--ui-status-indicator-bg")).toBe(true);
    expect(isColorValuedProperty("--card-animation")).toBe(false);
    expect(isColorValuedProperty("--space-6")).toBe(false);
    expect(shape(hard)).not.toContain(".ui-card | --card-animation: linen");
  });

  it("still treats a var() fallback inside one as the softer category", () => {
    expect(shape(soft)).toEqual([".ui-panel | --panel-ring: #4f46e5"]);
  });

  it("never reports transparent / currentColor / inherit / initial / unset / none", () => {
    const { hard, soft } = run("keyword-exclusions.css");
    expect(hard).toEqual([]);
    expect(soft).toEqual([]);
  });

  it("never reads a url() reference, a quoted string or a comment as a colour", () => {
    // Covered by keyword-exclusions.css above; asserted separately so a
    // regression names the reason. `fill: url(#brand-gradient)` is an SVG
    // reference, not a hex colour.
    const { hard } = findColorViolations(
      "inline.css",
      `.a { fill: url(#brand-gradient); content: "#ffffff white"; }\n/* #ff0000 tomato */\n.b { color: var(--text); }`,
    );
    expect(hard).toEqual([]);
  });

  it("never reads a colour word inside a token NAME as a colour", () => {
    const { hard } = findColorViolations("inline.css", `.a { color: var(--status-red); background: var(--paper-white); }`);
    expect(hard).toEqual([]);
  });

  it("does not flag a named colour outside a colour-valued property", () => {
    expect(isColorValuedProperty("color")).toBe(true);
    expect(isColorValuedProperty("border-inline-start-color")).toBe(true);
    expect(isColorValuedProperty("box-shadow")).toBe(true);
    expect(isColorValuedProperty("animation-name")).toBe(false);
    expect(isColorValuedProperty("font-family")).toBe(false);
    const { hard } = findColorViolations("inline.css", `.a { animation-name: tan; font-family: plum, sans-serif; }`);
    expect(hard).toEqual([]);
  });
});

describe("theme token gate — var() fallbacks are a separate, softer category", () => {
  it("reports fallback colours as warnings and never as hard violations", () => {
    const { hard, soft } = run("var-fallbacks.css");
    expect(hard).toEqual([]);
    expect(shape(soft)).toEqual([
      ".ui-fallback__hex | color: #0f766e",
      ".ui-fallback__function | border-color: rgb(217 224 234)",
      ".ui-fallback__named | background: white",
      ".ui-fallback__nested | background: #ffffff",
    ]);
    expect(soft.every((violation) => violation.kind.startsWith("var() fallback"))).toBe(true);
  });

  it("does not treat a token or a length fallback as a colour", () => {
    const { soft } = findColorViolations(
      "inline.css",
      `.a { color: var(--capacity-ok, var(--success)); gap: var(--density-gap, 8px); }`,
    );
    expect(soft).toEqual([]);
  });
});

describe("theme token gate — baseline", () => {
  const source = `.ui-a { color: #fff; }\n.ui-b { background: #000000; }\n`;

  it("keys entries by selector + property + value, not by line number", () => {
    const before = findColorViolations("s.css", source).hard;
    const shifted = findColorViolations("s.css", `\n\n/* an unrelated edit above */\n${source}`).hard;
    expect(shifted[0].line).not.toBe(before[0].line);
    expect(shifted.map(violationKey)).toEqual(before.map(violationKey));
  });

  it("suppresses only the violations it records", () => {
    const baseline = serializeBaseline("check-theme-tokens", findColorViolations("s.css", source).hard);
    expect(baseline.total).toBe(2);

    const unchanged = applyBaseline(findColorViolations("s.css", source).hard, baseline);
    expect(unchanged.fresh).toEqual([]);
    expect(unchanged.suppressed).toHaveLength(2);

    const withNewOne = applyBaseline(
      findColorViolations("s.css", `${source}.ui-c { color: #123456; }\n`).hard,
      baseline,
    );
    expect(values(withNewOne.fresh)).toEqual(["#123456"]);
  });

  it("still fails when a baselined violation is duplicated", () => {
    const baseline = serializeBaseline("check-theme-tokens", findColorViolations("s.css", source).hard);
    const duplicated = findColorViolations("s.css", `${source}.ui-a { color: #fff; }\n`).hard;
    expect(values(applyBaseline(duplicated, baseline).fresh)).toEqual(["#fff"]);
  });
});
