import { readFileSync } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  EXEMPTION_CATEGORIES,
  PUBLIC_ENTRY,
  classifyExport,
  collectModuleExports,
  diffRegistration,
  resolveModulePath,
} from "./check-catalog-registration.mjs";
import { extractComponentMeta } from "./check-prop-docs.mjs";
import {
  applyBaseline,
  inadequateReasons,
  loadBaseline,
  reasonProblem,
  serializeBaseline,
  violationKey,
} from "./guard-baseline.mjs";

const packageRoot = fileURLToPath(new URL("..", import.meta.url));
const gate = (name) => fileURLToPath(new URL(`./fixtures/catalog-registration-gate/${name}`, import.meta.url));

const barrelExports = () => collectModuleExports(gate("index.ts"));

describe("catalog registration gate — module resolution", () => {
  it("resolves a relative specifier to .tsx, .ts, or the directory's index", () => {
    expect(resolveModulePath(gate("index.ts"), "./Panel")).toBe(gate("Panel.tsx"));
    expect(resolveModulePath(gate("index.ts"), "./utils")).toBe(gate("utils.ts"));
    expect(resolveModulePath(gate("index.ts"), "./nested")).toBe(gate("nested/index.ts"));
  });

  it("returns null for a package import and for a specifier that resolves to nothing", () => {
    expect(resolveModulePath(gate("index.ts"), "react")).toBeNull();
    expect(resolveModulePath(gate("index.ts"), "./NoSuchModule")).toBeNull();
  });
});

describe("catalog registration gate — walking the export closure", () => {
  it("follows star re-exports, named re-exports, aliases, and nested barrels", () => {
    const names = [...barrelExports().keys()].sort();
    expect(names).toEqual(
      [
        "BARREL_VERSION",
        "InnerBadge",
        "Panel",
        "PanelBadge",
        "PanelChrome",
        "PanelError",
        "PanelFallback",
        "PANEL_LIMIT",
        "PanelProps",
        "PanelRow",
        "Uncatalogued",
        "formatPanelTitle",
        "usePanelState",
      ].sort(),
    );
  });

  it("resolves a re-exported name to the file that declares it, not the barrel", () => {
    const found = barrelExports();
    expect(found.get("Panel").file).toBe(gate("Panel.tsx"));
    expect(found.get("Uncatalogued").file).toBe(gate("nested/Uncatalogued.tsx"));
    // An alias keeps the declaration it points at, under its exported name.
    expect(found.get("PanelBadge").file).toBe(gate("Panel.tsx"));
    expect(found.get("PanelBadge").name).toBe("PanelBadge");
  });

  it("marks type aliases, interfaces, and `export type` re-exports as types", () => {
    const found = barrelExports();
    expect(found.get("PanelProps").isType).toBe(true);
    expect(found.get("PanelRow").isType).toBe(true);
    expect(found.get("Panel").isType).toBe(false);
  });

  it("reports a line number pointing at the declaration", () => {
    expect(barrelExports().get("Panel").line).toBeGreaterThan(0);
  });
});

describe("catalog registration gate — 'does this render'", () => {
  it("sees JSX inside a function body and inside a call expression wrapper", () => {
    const found = barrelExports();
    expect(found.get("Panel").rendersJsx).toBe(true);
    expect(found.get("PanelChrome").rendersJsx).toBe(true); // memo(() => <div/>)
  });

  it("does not see JSX in a constant, a class, or a plain utility", () => {
    const found = barrelExports();
    expect(found.get("PANEL_LIMIT").rendersJsx).toBe(false);
    expect(found.get("PanelError").rendersJsx).toBe(false);
    expect(found.get("formatPanelTitle").rendersJsx).toBe(false);
  });

  it("is a whole-subtree question, so a component that returns null first still counts", () => {
    expect(barrelExports().get("PanelFallback").rendersJsx).toBe(true);
  });
});

describe("catalog registration gate — classifying an export", () => {
  const record = (name, extra = {}) => ({ name, isType: false, rendersJsx: false, file: "f.tsx", line: 1, ...extra });

  it("excludes types, hooks/utilities, constants and classes by their shape", () => {
    expect(classifyExport(record("PanelProps", { isType: true }))).toBe("type");
    expect(classifyExport(record("usePanelState"))).toBe("hook-or-utility");
    expect(classifyExport(record("formatPanelTitle"))).toBe("hook-or-utility");
    expect(classifyExport(record("PANEL_LIMIT"))).toBe("constant-or-class");
    expect(classifyExport(record("PanelError"))).toBe("constant-or-class");
  });

  it("counts a PascalCase value that renders as a component", () => {
    expect(classifyExport(record("Panel", { rendersJsx: true }))).toBe("component");
  });

  it("does not let a SCREAMING_SNAKE constant become a component even if it holds JSX", () => {
    expect(classifyExport(record("DEFAULT_EMPTY_STATE", { rendersJsx: true }))).toBe("constant-or-class");
  });
});

describe("catalog registration gate — diffing against componentMeta", () => {
  const catalog = () => {
    const entries = extractComponentMeta(gate("metadata.sample.ts"), readFileSync(gate("metadata.sample.ts"), "utf8"));
    return {
      names: new Set(entries.map((entry) => entry.name)),
      sourceFiles: new Set([gate("Panel.tsx")]),
    };
  };

  it("fails on a component whose declaring file has no catalog entry at all", () => {
    const { names, sourceFiles } = catalog();
    const { hard } = diffRegistration([...barrelExports().values()], names, sourceFiles);
    expect(hard.map((record) => record.name)).toEqual(["Uncatalogued"]);
  });

  it("reports a component co-located with a catalogued entry as a review note, not a failure", () => {
    const { names, sourceFiles } = catalog();
    const { soft } = diffRegistration([...barrelExports().values()], names, sourceFiles);
    expect(soft.map((record) => record.name).sort()).toEqual(["InnerBadge", "PanelBadge", "PanelChrome", "PanelFallback"]);
  });

  it("counts every export by kind, so the excluded ones are reported and not dropped", () => {
    const { names, sourceFiles } = catalog();
    const { counts } = diffRegistration([...barrelExports().values()], names, sourceFiles);
    expect(counts.total).toBe(13);
    expect(counts.type).toBe(2); // PanelProps, PanelRow
    expect(counts["hook-or-utility"]).toBe(2); // usePanelState, formatPanelTitle
    expect(counts["constant-or-class"]).toBe(3); // PANEL_LIMIT, BARREL_VERSION, PanelError
    expect(counts.component).toBe(6); // Panel, InnerBadge, PanelBadge, PanelChrome, PanelFallback, Uncatalogued
    expect(counts.registered).toBe(1); // Panel
    expect(counts.type + counts["hook-or-utility"] + counts["constant-or-class"] + counts.component).toBe(counts.total);
  });
});

describe("catalog registration gate — baseline accounting", () => {
  const violation = (file, name) => ({
    file,
    line: 1,
    selector: name,
    property: "catalog-registration",
    value: name,
  });

  it("suppresses only the exact exports it recorded", () => {
    const found = [violation("src/theme/ThemeScope.tsx", "ThemeScope")];
    const baseline = serializeBaseline("check-catalog-registration", found);
    expect(applyBaseline(found, baseline).fresh).toEqual([]);

    const withNewOne = applyBaseline([...found, violation("src/new/Widget.tsx", "Widget")], baseline);
    expect(withNewOne.fresh.map((entry) => entry.value)).toEqual(["Widget"]);
  });

  it("keys a violation by file + export name, not by line number", () => {
    const a = { ...violation("f.tsx", "X"), line: 3 };
    const b = { ...violation("f.tsx", "X"), line: 400 };
    expect(violationKey(a)).toBe(violationKey(b));
  });

  it("requires a baseline reason to name the declared 'pre-existing' exemption", () => {
    expect(reasonProblem("", { categories: EXEMPTION_CATEGORIES })).toBe("no reason recorded");
    expect(
      reasonProblem("This one is fine and we all agreed about it in a meeting last week.", {
        categories: EXEMPTION_CATEGORIES,
      }),
    ).toMatch(/names no declared exemption category/);
    expect(
      reasonProblem(
        "Pre-existing gap present when this gate was added in uif/issue-4675: ThemeScope is exported from "
          + "src/lib/index.ts with no componentMeta entry, and cataloguing it is a theme-slice follow-up.",
        { categories: EXEMPTION_CATEGORIES },
      ),
    ).toBeNull();
  });

  it("holds the recorded gap with an accountable justification for every entry", () => {
    const baseline = loadBaseline(join(packageRoot, "scripts/baselines/catalog-registration.json"));
    expect(baseline).not.toBeNull();
    expect(inadequateReasons(baseline, { categories: EXEMPTION_CATEGORIES })).toEqual([]);
  });
});

describe("catalog registration gate — the real package surface", () => {
  it("walks the barrel ARCHITECTURE.md designates as the public entry", () => {
    expect(PUBLIC_ENTRY).toBe("lib/index.ts");
    const found = collectModuleExports(join(packageRoot, "src", PUBLIC_ENTRY));
    // Spot-checks across each re-export style the barrel uses, so a regression
    // in closure-walking shows up as a missing name rather than as a quietly
    // shrinking checked surface.
    expect(found.has("DataTable")).toBe(true); // `export *` from a component module
    expect(found.has("Dialog")).toBe(true); // named export from the overlay barrel
    expect(found.has("useForm")).toBe(true); // reached through `export * from "../core"`
    expect(found.has("CompositionFrame")).toBe(true); // reached through "../compositions"
    expect(found.get("DialogProps").isType).toBe(true); // `export type { ... }`
    expect(found.size).toBeGreaterThan(500);
  });
});
