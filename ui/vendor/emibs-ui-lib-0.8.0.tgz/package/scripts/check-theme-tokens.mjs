import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import {
  maskStringsAndUrls,
  matchingParen,
  parseCss,
  readCssSources,
  splitArguments,
} from "./css-source.mjs";
import {
  applyBaseline,
  baselineIntegrityReport,
  baselineLabel,
  formatViolations,
  loadBaseline,
  parseGuardArgs,
  serializeBaseline,
  topOffenders,
  writeBaseline,
} from "./guard-baseline.mjs";

// Dark mode in this library is delivered ONLY by swapping CSS custom
// properties: src/theme/derive.ts derives a dark token set from a light one and
// ThemeScope writes it onto the root. There is deliberately no
// `prefers-color-scheme`, no `[data-theme]` and no `.dark` selector anywhere in
// the stylesheet. A colour written literally into a rule therefore cannot
// change with the theme — it is frozen across every one of the packaged light
// AND dark themes, which is a dark-mode break, not a style nit.
//
// So: colour values belong on the right-hand side of a `--token:` definition
// (or inside src/theme/tokens.ts). Everywhere else, route through var(--token).

// Colour keywords that are theme-safe by definition: they either paint nothing
// or resolve from the cascade, so they follow the theme rather than freezing it.
const ALLOWED_COLOR_KEYWORDS = new Set([
  "transparent",
  "currentcolor",
  "inherit",
  "initial",
  "unset",
  "revert",
  "revert-layer",
  "none",
]);

// The CSS named colours (CSS Color 4 "named-color" production). System colours
// (canvas, buttonface, field, …) are intentionally NOT in this list: they are
// UA-themed rather than frozen, and several of them are ordinary English words
// that would misfire inside shorthand values.
const NAMED_COLORS = new Set(
  `aliceblue antiquewhite aqua aquamarine azure beige bisque black blanchedalmond blue blueviolet brown
   burlywood cadetblue chartreuse chocolate coral cornflowerblue cornsilk crimson cyan darkblue darkcyan
   darkgoldenrod darkgray darkgreen darkgrey darkkhaki darkmagenta darkolivegreen darkorange darkorchid
   darkred darksalmon darkseagreen darkslateblue darkslategray darkslategrey darkturquoise darkviolet
   deeppink deepskyblue dimgray dimgrey dodgerblue firebrick floralwhite forestgreen fuchsia gainsboro
   ghostwhite gold goldenrod gray green greenyellow grey honeydew hotpink indianred indigo ivory khaki
   lavender lavenderblush lawngreen lemonchiffon lightblue lightcoral lightcyan lightgoldenrodyellow
   lightgray lightgreen lightgrey lightpink lightsalmon lightseagreen lightskyblue lightslategray
   lightslategrey lightsteelblue lightyellow lime limegreen linen magenta maroon mediumaquamarine
   mediumblue mediumorchid mediumpurple mediumseagreen mediumslateblue mediumspringgreen mediumturquoise
   mediumvioletred midnightblue mintcream mistyrose moccasin navajowhite navy oldlace olive olivedrab
   orange orangered orchid palegoldenrod palegreen paleturquoise palevioletred papayawhip peachpuff peru
   pink plum powderblue purple rebeccapurple red rosybrown royalblue saddlebrown salmon sandybrown
   seagreen seashell sienna silver skyblue slateblue slategray slategrey snow springgreen steelblue tan
   teal thistle tomato turquoise violet wheat white whitesmoke yellow yellowgreen`
    .split(/\s+/)
    .filter(Boolean),
);

// Properties whose value can be a bare colour keyword. Hex and rgb()/hsl()
// literals are flagged in ANY property (they are unambiguously colours); named
// colours are only flagged here, because words like `linen` or `tan` are only
// colours in a colour slot. Anything ending in `-color` qualifies, which covers
// the whole `border-*-color` family including the logical properties.
const COLOR_VALUED_PROPERTIES = new Set([
  "color",
  "background",
  "background-color",
  "border",
  "border-top",
  "border-right",
  "border-bottom",
  "border-left",
  "border-block",
  "border-block-start",
  "border-block-end",
  "border-inline",
  "border-inline-start",
  "border-inline-end",
  "outline",
  "outline-color",
  "box-shadow",
  "text-shadow",
  "fill",
  "stroke",
  "text-decoration",
  "text-decoration-color",
  "caret-color",
  "accent-color",
  "column-rule",
  "column-rule-color",
]);

// A custom property is untyped, so there is no property list that says whether
// its value is a colour. These name shapes do: `--ui-status-indicator-bg`,
// `--card-border`, `--chart-series-fill`. Used ONLY to decide whether a bare
// named colour (`tan`, `linen`) counts inside a custom property — hex and the
// colour functions are unambiguous and are flagged in any custom property.
const COLOR_VALUED_CUSTOM_PROPERTY =
  /(?:^|-)(?:color|colour|bg|background|border|fill|stroke|shadow|ink|tint|shade|surface|accent|text|ring|outline|gradient)(?:-|$)/;

export function isColorValuedProperty(property) {
  const name = property.toLowerCase();
  if (name.startsWith("--")) return COLOR_VALUED_CUSTOM_PROPERTY.test(name.slice(2));
  return COLOR_VALUED_PROPERTIES.has(name) || name.endsWith("-color");
}

// ---------------------------------------------------------------------------
// Where a colour LITERAL is legitimate.
//
// The exemption for `--token: <colour>` exists because a theme's token
// definitions are the one place a real colour value belongs. It was written as
// "the property starts with `--`", which exempts a custom property declared in
// ANY rule — and a custom property declared on a component rule is not a theme
// token, it is a hardcoded colour with an extra hop. Proven live: the six
// `.ui-status-indicator--*` variant rules shipped ten frozen pastels
// (`--ui-status-indicator-bg: #eff6ff`, …) straight through this guard, none of
// which move when the theme does.
//
// The rule, stated deliberately: **a colour literal may only be written where
// the theme layer itself is defined — a document-root scope (`:root`, `html`,
// `:host`), optionally qualified (`:root[data-theme="dark"]`, `html.dark`) and
// optionally wrapped in an at-rule.** That is exactly the set of selectors that
// can carry a whole token set, and exactly where src/theme/derive.ts + ThemeScope
// write one. Everywhere else — including a component-local custom property —
// the value must come from `var(--token)`.
//
// A component-local custom property is still a useful pattern (see
// `--ui-button-surface` in materialControls.css); it just has to hold a token
// reference or a theme-safe keyword rather than a frozen literal.
// ---------------------------------------------------------------------------

// The pieces a theme-scope selector may be built from. `data-color-scheme` is
// the attribute ThemeScope itself stamps on the element it writes the token set
// onto (src/theme/ThemeScope.tsx), so a `[data-color-scheme="dark"]` block is a
// token definition site every bit as much as `:root` is.
const THEME_SCOPE_MARKER = /^(?::root|:host(?:\([^)]*\))?|html|\[data-(?:theme|color-scheme)(?:[~|^$*]?=[^\]]*)?\])$/;
// Allowed alongside a marker, never on their own: a theme class or attribute
// that narrows WHICH theme, e.g. `:root.theme-score`, `html[data-density]`.
const THEME_SCOPE_QUALIFIER = /^(?:\.[\w-]+|\[[^\]]*\])$/;

/** Split one compound selector into its simple pieces (`:root[data-theme="x"].y`). */
function compoundPieces(compound) {
  return compound.match(/(?::[\w-]+(?:\([^)]*\))?|\[[^\]]*\]|\.[\w-]+|#[\w-]+|[\w-]+)/g) ?? [];
}

/**
 * True when every selector of the block is a THEME SCOPE — the element a whole
 * token set is written onto — rather than a component rule. It must be a single
 * compound (no descendant/child combinator: `html .ui-card` is a component rule
 * that merely happens to be qualified by `html`), it must carry at least one
 * root/theme marker, and everything else in it must be a qualifier that narrows
 * which theme rather than which component.
 *
 * An at-rule wrapper (`@media (prefers-contrast: more) { :root { … } }`) is
 * fine: `block.selectors` is the block's OWN prelude and an at-rule block has
 * none, so an at-rule never qualifies by itself.
 */
export function isThemeTokenScope(block) {
  if (!block || !Array.isArray(block.selectors) || block.selectors.length === 0) return false;
  return block.selectors.every((selector) => {
    if (/[\s>+~]/.test(selector.replace(/\([^)]*\)/g, "").replace(/\[[^\]]*\]/g, ""))) return false;
    const pieces = compoundPieces(selector);
    if (pieces.length === 0) return false;
    let markers = 0;
    for (const piece of pieces) {
      if (THEME_SCOPE_MARKER.test(piece)) {
        markers += 1;
        continue;
      }
      // A state pseudo-class on the root is not a component; anything else is.
      if (/^:[\w-]/.test(piece) || THEME_SCOPE_QUALIFIER.test(piece)) continue;
      return false;
    }
    return markers > 0;
  });
}

// `#rgb` / `#rgba` / `#rrggbb` / `#rrggbbaa`, longest-first so `#abcde` (an
// invalid length) matches nothing at all rather than matching a prefix.
const HEX_COLOR = /#(?:[0-9a-fA-F]{8}|[0-9a-fA-F]{6}|[0-9a-fA-F]{4}|[0-9a-fA-F]{3})\b/g;
// A `-` is a regex word boundary, so plain `\b` would find "red" inside
// `var(--status-red)`. These boundaries treat `-` and `_` as word characters.
// Every colour FUNCTION in CSS Color 4/5, not just the two families that
// existed when this guard was written. This package depends on Tailwind 4,
// whose default palette is authored in `oklch()`, and oklch literals already
// appear elsewhere in the tree (catalog demos, theme tests) — so oklch is the
// single most likely form the next frozen colour takes, and `oklch(0.54 0.17 250)`
// used to sail straight through.
//
// `color-mix()` is deliberately NOT in this list. A mix is a *derivation*: the
// library's own tokens are built from `color-mix(in oklab, var(--text) 6%,
// transparent)`, which follows the theme by construction. A mix of LITERALS is
// still caught, because the literals inside it match the patterns here.
const COLOR_FUNCTION = /(?<![\w-])(rgba?|hsla?|hwb|lab|lch|oklab|oklch|color|device-cmyk)\s*\(/gi;
const WORD = /(?<![\w-])([a-zA-Z]+)(?![\w-])/g;

function blankRange(chars, start, end) {
  for (let i = start; i < end && i < chars.length; i += 1) chars[i] = " ";
}

/**
 * Pull every `var(--token, <fallback>)` fallback out of a value.
 *
 * A fallback is a softer category than a bare literal: the token normally wins,
 * so the hardcoded colour only surfaces when the token is missing. It is still
 * a frozen colour on that path, so it is reported — as a warning, under its own
 * heading, and only fatal under `--strict`.
 *
 * Returns the fallback texts plus the value with those spans blanked out, so
 * the hard scan cannot double-count them.
 */
export function extractVarFallbacks(value) {
  const chars = value.split("");
  const fallbacks = [];
  const pattern = /(?<![\w-])var\s*\(/gi;
  let match;
  while ((match = pattern.exec(value)) !== null) {
    const open = value.indexOf("(", match.index);
    const close = matchingParen(value, open);
    const args = splitArguments(value.slice(open + 1, close));
    if (args.length > 1) {
      const fallbackStart = open + 1 + args[0].length + 1;
      fallbacks.push({ text: value.slice(fallbackStart, close), start: fallbackStart });
    }
    // Blank the token NAME as well: `var(--status-red)` must not read as `red`.
    blankRange(chars, match.index, close + 1);
  }
  return { fallbacks, masked: chars.join("") };
}

/** Every colour literal in one already-masked chunk of a declaration value. */
function scanColorLiterals(text, property) {
  const found = [];

  HEX_COLOR.lastIndex = 0;
  let match;
  while ((match = HEX_COLOR.exec(text)) !== null) {
    found.push({ value: match[0], kind: "hex" });
  }

  COLOR_FUNCTION.lastIndex = 0;
  while ((match = COLOR_FUNCTION.exec(text)) !== null) {
    const open = text.indexOf("(", match.index);
    const close = matchingParen(text, open);
    found.push({
      value: text.slice(match.index, close + 1).replace(/\s+/g, " "),
      kind: `${match[1].toLowerCase()}()`,
    });
  }

  if (isColorValuedProperty(property)) {
    WORD.lastIndex = 0;
    while ((match = WORD.exec(text)) !== null) {
      const word = match[1].toLowerCase();
      if (ALLOWED_COLOR_KEYWORDS.has(word)) continue;
      if (!NAMED_COLORS.has(word)) continue;
      found.push({ value: match[1], kind: "named colour" });
    }
  }

  return found;
}

/**
 * Find hardcoded colours in one stylesheet.
 *
 * `hard` = a literal colour that always applies (build-failing).
 * `soft`  = a literal colour used only as a `var(--token, …)` fallback.
 *
 * A custom property declaration (`--token: #fff`) is skipped only when it sits
 * in a theme token scope (`:root`/`:host`/`html`) — see `isThemeTokenScope`.
 * A custom property declared on a component rule is a hardcoded colour with one
 * extra hop, and is reported like any other.
 */
export function findColorViolations(file, source) {
  const { declarations } = parseCss(source, file);
  const hard = [];
  const soft = [];

  for (const declaration of declarations) {
    if (declaration.property.startsWith("--") && isThemeTokenScope(declaration.block)) continue;

    const masked = maskStringsAndUrls(declaration.value);
    const { fallbacks, masked: withoutVars } = extractVarFallbacks(masked);

    for (const literal of scanColorLiterals(withoutVars, declaration.property)) {
      hard.push({
        file,
        line: declaration.line,
        selector: declaration.selector,
        property: declaration.property,
        value: literal.value,
        kind: literal.kind,
        declaration: declaration.value,
      });
    }

    for (const fallback of fallbacks) {
      // A nested `var()` inside the fallback is masked the same way, so
      // `var(--a, var(--b, #fff))` reports `#fff` exactly once.
      const { masked: fallbackText } = extractVarFallbacks(fallback.text);
      for (const literal of scanColorLiterals(fallbackText, declaration.property)) {
        soft.push({
          file,
          line: declaration.line,
          selector: declaration.selector,
          property: declaration.property,
          value: literal.value,
          kind: `var() fallback (${literal.kind})`,
          declaration: declaration.value,
        });
      }
    }
  }

  return { hard, soft };
}

export function collectColorViolations(sources) {
  const hard = [];
  const soft = [];
  for (const { file, source } of sources) {
    const result = findColorViolations(file, source);
    hard.push(...result.hard);
    soft.push(...result.soft);
  }
  return { hard, soft };
}

/**
 * The only exemptions this guard grants, and the claim a baseline reason has to
 * make to invoke one. A literal colour is acceptable ONLY when it is not a theme
 * colour at all — an identity mark, a national flag, a depiction whose meaning
 * IS the hue (green land / blue water) — because such a value would be wrong,
 * not merely unthemed, if it followed the palette. Every reason must say so in
 * those terms, so "it looked better" cannot pass as a justification and a new
 * category cannot be invented without it showing up in review.
 */
export const EXEMPTION_CATEGORIES = [
  { label: "not a theme colour (identity / flag / depiction constant)", pattern: /not\s+(?:a\s+)?theme|not\s+a\s+theme\s+colou?r/i },
];

function main() {
  const packageRoot = fileURLToPath(new URL("..", import.meta.url));
  const defaultBaseline = join(packageRoot, "scripts/baselines/theme-tokens.json");
  const options = parseGuardArgs(process.argv.slice(2), { defaultBaseline });
  const label = baselineLabel(packageRoot, options.baseline);

  const sources = readCssSources(join(packageRoot, "src"), packageRoot);
  const { hard, soft } = collectColorViolations(sources);

  if (options.updateBaseline) {
    const tracked = options.strict ? [...hard, ...soft] : hard;
    // Read before overwriting: the written justifications in `reasons` belong
    // to the exceptions, not to this run, and must survive a regeneration.
    const previous = loadBaseline(options.baseline);
    writeBaseline(options.baseline, serializeBaseline("check-theme-tokens", tracked, { previous }));
    console.log(
      `check-theme-tokens: wrote baseline of ${tracked.length} violation(s) to ${label}` +
        `\n  (${hard.length} hardcoded colour(s), ${soft.length} var() fallback warning(s))`,
    );
    return 0;
  }

  const baseline = loadBaseline(options.baseline);
  // A build FAILURE, not a nudge. An unjustified or stale baseline entry is a
  // standing pre-authorisation for a violation, and the only thing that used to
  // object was a `npm test` assertion that the `build` chain never runs.
  const integrity = baselineIntegrityReport(baseline, [...hard, ...soft], {
    label,
    categories: EXEMPTION_CATEGORIES,
  });
  if (integrity) {
    console.error(integrity);
    console.error("\ncheck-theme-tokens: baseline is not accountable (see above).");
    return 1;
  }
  const hardResult = applyBaseline(hard, baseline);
  const softResult = options.strict ? applyBaseline(soft, baseline) : { fresh: soft, suppressed: [] };

  if (soft.length > 0) {
    console.warn(
      `check-theme-tokens: ${soft.length} hardcoded colour(s) used as a var(--token, fallback).` +
        `${options.strict ? "" : " These do not fail the build; run with --strict to enforce them."}`,
    );
    if (!options.strict) console.warn(formatViolations(soft, { indent: "  " }));
  }

  const failing = options.strict ? [...hardResult.fresh, ...softResult.fresh] : hardResult.fresh;

  if (failing.length > 0) {
    console.error(
      "\nHardcoded colours freeze across themes — dark mode is delivered only by swapping\n" +
        "CSS custom properties (src/theme/derive.ts), so a literal colour never changes.\n" +
        "Route these through a theme token from src/theme/tokens.ts:\n",
    );
    console.error(formatViolations(failing));
    console.error(`\n${failing.length} hardcoded colour violation(s).`);
    if (baseline) {
      console.error(`${hardResult.suppressed.length} further violation(s) suppressed by ${label}.`);
    }
    console.error("Top offending selectors:");
    for (const { selector, count } of topOffenders(failing)) {
      console.error(`  ${count}x ${selector}`);
    }
    return 1;
  }

  const suppressed = hardResult.suppressed.length + softResult.suppressed.length;
  console.log(
    `check-theme-tokens: no new hardcoded colours` +
      (suppressed > 0 ? ` (${suppressed} known violation(s) held by the baseline).` : "."),
  );
  return 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main());
}
