#!/usr/bin/env node
// Scripted release for emibs-ui-lib (issue-2181, replaces tarball-overwrite).
//
// Packs the package with `npm pack`, copies the versioned tarball to
// /engineering/dist (the shared consumer drop), and prints the exact consumer
// refresh steps per score/ui/vendor/README.md. It intentionally does NOT
// re-vendor into score/elitua — that is the E6/E7 adoption work, gated on owner
// review — it only produces the artifact and tells you how to consume it.

import { execFileSync } from "node:child_process";
import { copyFileSync, mkdirSync, readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const packageRoot = fileURLToPath(new URL("..", import.meta.url));
const pkg = JSON.parse(readFileSync(join(packageRoot, "package.json"), "utf8"));
const tarball = `${pkg.name}-${pkg.version}.tgz`;
const distDir = "/engineering/dist";

function run(command, args, options = {}) {
  const output = execFileSync(command, args, { cwd: packageRoot, stdio: "pipe", encoding: "utf8", ...options });
  // With stdio: "inherit" nothing is captured (output is null) — that is fine.
  return typeof output === "string" ? output.trim() : "";
}

console.log(`emibs-ui-lib release — ${pkg.name}@${pkg.version}`);

// Score imports emibs-ui-lib by TS source path (not a compiled dist/), so a
// plain `npm pack` (no build) is the contract. Verify the build is green first
// so a broken package never ships.
console.log("• verifying build (check:architecture + tsc + vite)…");
run("npm", ["run", "build"], { stdio: "inherit" });

console.log("• packing…");
run("npm", ["pack"]);

mkdirSync(distDir, { recursive: true });
const dest = join(distDir, tarball);
copyFileSync(join(packageRoot, tarball), dest);
console.log(`• copied ${tarball} → ${dest}`);

console.log(
  [
    "",
    "Release artifact ready. To refresh a consumer (do NOT run as part of E1):",
    "",
    "  Score (score/ui/vendor):",
    `    cp ${dest} /engineering/projects/score/ui/vendor/${tarball}`,
    "    # update score/ui/package.json to depend on the new version, then:",
    "    cd /engineering/projects/score/ui && npm install   # refreshes lockfile integrity",
    "",
    "  eLitua: same pattern against its vendor dir once the E7 gate is open.",
    "",
    `Pin consumers to the exact version: "${pkg.name}": "${pkg.version}".`,
    "See CHANGELOG.md for what changed.",
  ].join("\n"),
);
