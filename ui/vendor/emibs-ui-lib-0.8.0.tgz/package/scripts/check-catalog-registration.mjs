import { existsSync, readFileSync } from "node:fs";
import { dirname, join, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import ts from "typescript";
import { extractComponentMeta } from "./check-prop-docs.mjs";
import {
  applyBaseline,
  baselineIntegrityReport,
  baselineLabel,
  formatViolations,
  loadBaseline,
  parseGuardArgs,
  serializeBaseline,
  topOffenders,
  writeBaseline,
} from "./guard-baseline.mjs";

// The catalog reports "169 entries, 1014/1014 checks (100%)". That number is
// computed over `componentMeta` — a hand-maintained list — and says nothing
// whatsoever about anything NOT on the list. Nothing in the build compared the
// list against what the package actually exports, so a component could ship on
// the public surface and never appear in the figure at all (uif/issue-4675).
//
// This guard is that comparison: it walks the export closure of the public
// entry barrel, decides which exported names are React components, and reports
// the ones `componentMeta` does not name.
//
// Scope, stated honestly:
//
//  1. "PUBLIC" MEANS `src/lib/index.ts` AND NOTHING ELSE.
//     ARCHITECTURE.md ("Barrel-aware rules") already designates that file as
//     "the PUBLIC entry barrel", and the layering guard in
//     .dependency-cruiser.cjs is written against that designation — the whole
//     `reachable` rule set exists because the barrel re-exports higher layers
//     on a consumer's behalf. So the package already HAS a stated public
//     surface, and this guard adopts it rather than minting a second one.
//     The alternatives were considered and rejected:
//       - "every exported symbol in src/**" is not a contract, it is an
//         implementation detail; a component exported so a sibling module can
//         import it has made no promise to anyone outside the package.
//       - the sub-barrels (`src/compositions/index.ts`, `src/forms/index.ts`,
//         `src/core/index.ts`, `src/theme/index.ts`) are not a separate
//         surface: `src/lib/index.ts` re-exports each of them, so walking the
//         closure from the entry barrel already contains every one. Naming
//         them separately would double-count, not widen.
//     Note this is a surface the guard reads, never one it defines: the
//     closure is recomputed from the barrel on every run, so adding a
//     `export * from "../components/x"` line widens the checked set
//     automatically.
//
//  2. NOT EVERY EXPORT IS A CATALOG ENTRY, AND THE DIFFERENCE IS STRUCTURAL.
//     Three kinds of export are excluded by what they ARE, not by being
//     written down in the baseline:
//       - type-only exports (`export type { ... }`, or a name whose
//         declaration is an interface/type alias). A type has no demo, no
//         variants and no states; the six coverage facets are meaningless for
//         it. ~370 of the barrel's ~658 exports are these.
//       - names that are not PascalCase — `useForm`, `cn`, `errorSummaryItems`,
//         `resolveControlRenderer`. Hooks and utilities, by the package's own
//         naming convention, which React itself enforces (a lowercase tag is
//         not a component call).
//       - PascalCase values whose declaration contains no JSX anywhere:
//         `FIELD_TYPES`, `THEME_JSON_FORMAT`, `FormSubmissionError`. Constants
//         and classes, not components.
//     What survives all three is an exported thing that renders — which is
//     exactly what the catalog is a catalog OF. That is the point of doing
//     this on the TypeScript AST instead of a regex over the barrel: "does
//     this declaration return markup" is a syntactic question with a real
//     answer, whereas "does this identifier look like a component" is a guess.
//
//  3. A COMPOUND'S PARTS ARE A SOFTER SIGNAL THAN AN UNCATALOGUED FILE.
//     `CardHeader`/`CardBody`/`CardTitle` are exported from `Card.tsx`, and
//     `card` IS a catalog entry whose SPEC and facets document the compound
//     including its parts. Calling those "invisible to the coverage figure" is
//     not true — they are documented under their parent. What is genuinely
//     invisible is a component whose declaring file has NO catalog entry at
//     all: nothing anywhere describes it.
//     So the two are separated: a component in a file with no entry is a build
//     failure (held by the baseline until burned down), and a component
//     co-located with a catalogued entry is reported as a review note,
//     enforceable with `--strict`. This mirrors the hard/soft split
//     check-prop-docs.mjs already uses, for the same reason: a gate that fails
//     the build on a defensible case is a gate people delete.
//
//  4. WHAT THIS CANNOT SEE. It matches an exported name against
//     `componentMeta[].name` exactly. A catalogued component renamed in source
//     but not in metadata reads as uncatalogued, which is the correct alarm.
//     A metadata entry naming a component that no longer exists is NOT
//     detected here — that is the reverse direction, and the coverage gate
//     plus check-prop-docs already fail on an entry whose source or facets are
//     missing. It also follows only static `export` syntax; a re-export built
//     at runtime would be missed, and the package has none.

/** The package's public entry barrel — see note (1) above. */
export const PUBLIC_ENTRY = "lib/index.ts";

const MODULE_EXTENSIONS = [".tsx", ".ts"];

/** Resolve a relative import specifier the way the bundler does. */
export function resolveModulePath(fromFile, specifier) {
  if (!specifier.startsWith(".")) return null; // a package import: not our source
  const base = join(dirname(fromFile), specifier);
  const candidates = [
    ...MODULE_EXTENSIONS.map((ext) => `${base}${ext}`),
    ...MODULE_EXTENSIONS.map((ext) => join(base, `index${ext}`)),
  ];
  return candidates.find((candidate) => existsSync(candidate)) ?? null;
}

function parseSource(file, source) {
  return ts.createSourceFile(
    file,
    source,
    ts.ScriptTarget.Latest,
    true,
    file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
  );
}

/**
 * Whether a declaration node contains JSX anywhere inside it — the syntactic
 * test for "this renders". Deliberately the whole subtree rather than just a
 * return statement, so `forwardRef((props, ref) => <div/>)`, `memo(...)`, and a
 * function with several conditional returns all answer yes.
 */
export function declarationRendersJsx(node) {
  let found = false;
  const visit = (child) => {
    if (found) return;
    if (ts.isJsxElement(child) || ts.isJsxSelfClosingElement(child) || ts.isJsxFragment(child)) {
      found = true;
      return;
    }
    ts.forEachChild(child, visit);
  };
  visit(node);
  return found;
}

function topLevelDeclarations(sf) {
  const byName = new Map();
  const add = (name, node, isType) => byName.set(name, { node, isType });
  for (const statement of sf.statements) {
    if (ts.isVariableStatement(statement)) {
      for (const declaration of statement.declarationList.declarations) {
        if (ts.isIdentifier(declaration.name)) add(declaration.name.text, declaration, false);
      }
    } else if (ts.isFunctionDeclaration(statement) && statement.name) {
      add(statement.name.text, statement, false);
    } else if (ts.isClassDeclaration(statement) && statement.name) {
      add(statement.name.text, statement, false);
    } else if (ts.isEnumDeclaration(statement)) {
      add(statement.name.text, statement, false);
    } else if (ts.isTypeAliasDeclaration(statement) || ts.isInterfaceDeclaration(statement)) {
      add(statement.name.text, statement, true);
    }
  }
  return byName;
}

function hasExportModifier(statement) {
  return Boolean(statement.modifiers?.some((modifier) => modifier.kind === ts.SyntaxKind.ExportKeyword));
}

/**
 * Every name a module exports, resolved to the file and declaration it
 * originates in, following `export *` and `export { x } from` chains.
 *
 * Returns a `Map<exportedName, { name, file, line, isType, rendersJsx }>`.
 * `visiting` guards against an import cycle; a module already on the stack
 * contributes nothing rather than recursing forever.
 */
export function collectModuleExports(file, visiting = new Set()) {
  const found = new Map();
  if (!file || visiting.has(file)) return found;
  visiting.add(file);

  const sf = parseSource(file, readFileSync(file, "utf8"));
  const locals = topLevelDeclarations(sf);

  const recordLocal = (exportedName, localName, forcedType) => {
    const declaration = locals.get(localName);
    if (!declaration) {
      // Exported without a declaration in this file (an imported binding
      // re-exported through a local alias). Nothing syntactic to read, so it
      // is recorded as a non-rendering value rather than guessed at.
      found.set(exportedName, { name: exportedName, file, line: 1, isType: Boolean(forcedType), rendersJsx: false });
      return;
    }
    found.set(exportedName, {
      name: exportedName,
      file,
      line: sf.getLineAndCharacterOfPosition(declaration.node.getStart(sf)).line + 1,
      isType: Boolean(forcedType) || declaration.isType,
      rendersJsx: declarationRendersJsx(declaration.node),
    });
  };

  for (const statement of sf.statements) {
    if (ts.isExportDeclaration(statement)) {
      const specifier =
        statement.moduleSpecifier && ts.isStringLiteral(statement.moduleSpecifier)
          ? statement.moduleSpecifier.text
          : null;

      if (!statement.exportClause) {
        // `export * from "./x"` — every name x exports, transparently.
        if (!specifier) continue;
        const target = resolveModulePath(file, specifier);
        if (!target) continue;
        for (const [name, record] of collectModuleExports(target, visiting)) found.set(name, record);
        continue;
      }
      if (!ts.isNamedExports(statement.exportClause)) continue;

      // `export { A, B as C } from "./x"` / `export { A }`.
      const fromModule = specifier
        ? collectModuleExports(resolveModulePath(file, specifier), new Set(visiting))
        : null;
      for (const element of statement.exportClause.elements) {
        const localName = (element.propertyName ?? element.name).text;
        const exportedName = element.name.text;
        const typeOnly = statement.isTypeOnly || element.isTypeOnly;
        if (fromModule) {
          const record = fromModule.get(localName);
          found.set(
            exportedName,
            record
              ? { ...record, name: exportedName, isType: typeOnly || record.isType }
              : { name: exportedName, file, line: 1, isType: typeOnly, rendersJsx: false },
          );
        } else {
          recordLocal(exportedName, localName, typeOnly);
        }
      }
      continue;
    }

    if (!hasExportModifier(statement)) continue;
    if (ts.isVariableStatement(statement)) {
      for (const declaration of statement.declarationList.declarations) {
        if (ts.isIdentifier(declaration.name)) recordLocal(declaration.name.text, declaration.name.text, false);
      }
    } else if (
      (ts.isFunctionDeclaration(statement) || ts.isClassDeclaration(statement) || ts.isEnumDeclaration(statement))
      && statement.name
    ) {
      recordLocal(statement.name.text, statement.name.text, false);
    } else if (ts.isTypeAliasDeclaration(statement) || ts.isInterfaceDeclaration(statement)) {
      recordLocal(statement.name.text, statement.name.text, true);
    }
  }

  visiting.delete(file);
  return found;
}

const PASCAL_CASE = /^[A-Z][A-Za-z0-9]*$/;
// SCREAMING_SNAKE_CASE — `FIELD_TYPES`, `THEME_JSON_FORMAT`. Uppercase-initial
// like a component, but by universal convention a constant. Classified before
// the PascalCase test so it is reported as a constant rather than lumped in
// with the hooks and utilities.
const SCREAMING_SNAKE_CASE = /^[A-Z][A-Z0-9_]*$/;

/**
 * What kind of thing an exported name is — see note (2). Only `"component"`
 * is a candidate catalog entry; the other three are excluded by their shape,
 * never by a baseline entry.
 */
export function classifyExport(record) {
  if (record.isType) return "type";
  if (SCREAMING_SNAKE_CASE.test(record.name)) return "constant-or-class";
  if (!PASCAL_CASE.test(record.name)) return "hook-or-utility";
  if (!record.rendersJsx) return "constant-or-class";
  return "component";
}

/**
 * Split the exported components into the ones nothing describes and the ones a
 * catalogued parent describes — see note (3).
 *
 * `catalogNames` is every `componentMeta[].name`; `catalogSourceFiles` is the
 * set of source files those entries' specPaths point at.
 */
export function diffRegistration(exportRecords, catalogNames, catalogSourceFiles) {
  const hard = [];
  const soft = [];
  const counts = { total: 0, type: 0, "hook-or-utility": 0, "constant-or-class": 0, component: 0, registered: 0 };
  for (const record of exportRecords) {
    counts.total += 1;
    const kind = classifyExport(record);
    counts[kind] += 1;
    if (kind !== "component") continue;
    if (catalogNames.has(record.name)) {
      counts.registered += 1;
      continue;
    }
    (catalogSourceFiles.has(record.file) ? soft : hard).push(record);
  }
  return { hard, soft, counts };
}

function readCatalog(srcRoot) {
  const metaFile = join(srcRoot, "catalog/metadata.ts");
  const entries = extractComponentMeta(metaFile, readFileSync(metaFile, "utf8"));
  const names = new Set(entries.map((entry) => entry.name));
  const sourceFiles = new Set();
  for (const entry of entries) {
    if (!entry.specPath) continue;
    const stem = entry.specPath.replace(/^\.\//, "").replace(/\.SPEC\.md$/, "");
    for (const ext of MODULE_EXTENSIONS) {
      const candidate = join(srcRoot, `${stem}${ext}`);
      if (existsSync(candidate)) sourceFiles.add(candidate);
    }
  }
  return { entries, names, sourceFiles };
}

function buildViolation(packageRoot, record, note) {
  return {
    file: relative(packageRoot, record.file).split("\\").join("/"),
    line: record.line,
    selector: record.name,
    property: "catalog-registration",
    value: record.name,
    note,
  };
}

function main() {
  const packageRoot = fileURLToPath(new URL("..", import.meta.url));
  const srcRoot = join(packageRoot, "src");
  const defaultBaseline = join(packageRoot, "scripts/baselines/catalog-registration.json");
  const options = parseGuardArgs(process.argv.slice(2), { defaultBaseline });
  const label = baselineLabel(packageRoot, options.baseline);

  const entryFile = join(srcRoot, PUBLIC_ENTRY);
  const exported = [...collectModuleExports(entryFile).values()];
  const catalog = readCatalog(srcRoot);
  const { hard: hardRecords, soft: softRecords, counts } = diffRegistration(
    exported,
    catalog.names,
    catalog.sourceFiles,
  );

  const hard = hardRecords.map((record) =>
    buildViolation(
      packageRoot,
      record,
      `exported from src/${PUBLIC_ENTRY} and renders, but no componentMeta entry names it `
        + "and its source file carries no catalog entry either — it is invisible to the coverage figure",
    ),
  );
  const soft = softRecords.map((record) =>
    buildViolation(
      packageRoot,
      record,
      "exported and renders, with no componentMeta entry of its own; its source file IS catalogued, "
        + "so it is presumably a part of that compound entry — confirm the parent's SPEC covers it",
    ),
  );

  if (options.updateBaseline) {
    const previous = loadBaseline(options.baseline);
    writeBaseline(options.baseline, serializeBaseline("check-catalog-registration", hard, { previous }));
    console.log(
      `check-catalog-registration: wrote baseline of ${hard.length} violation(s) to ${label}\n`
        + `  (${counts.total} public export(s): ${counts.type} type(s), ${counts["hook-or-utility"]} hook(s)/utility(ies), `
        + `${counts["constant-or-class"]} constant(s)/class(es), ${counts.component} component(s) of which `
        + `${counts.registered} are catalogued)`,
    );
    return 0;
  }

  const baseline = loadBaseline(options.baseline);
  const allForIntegrity = options.strict ? [...hard, ...soft] : hard;
  const integrity = baselineIntegrityReport(baseline, allForIntegrity, { label, categories: EXEMPTION_CATEGORIES });
  if (integrity) {
    console.error(integrity);
    console.error("\ncheck-catalog-registration: baseline is not accountable (see above).");
    return 1;
  }

  const hardResult = applyBaseline(hard, baseline);
  const softResult = options.strict ? applyBaseline(soft, baseline) : { fresh: soft, suppressed: [] };

  if (soft.length > 0) {
    console.warn(
      `check-catalog-registration: ${soft.length} exported component(s) have no catalog entry of their own but sit in\n`
        + "  a file that does — compound parts documented under their parent"
        + (options.strict ? "." : ", run with --strict to enforce them.\n"),
    );
    if (!options.strict) console.warn(formatViolations(soft, { indent: "  " }));
  }

  const failing = options.strict ? [...hardResult.fresh, ...softResult.fresh] : hardResult.fresh;

  if (failing.length > 0) {
    console.error(
      `\nA component is exported from src/${PUBLIC_ENTRY} but appears nowhere in src/catalog/metadata.ts.\n`
        + "The catalog's coverage percentage is computed over componentMeta only, so an uncatalogued export is\n"
        + "not counted as incomplete — it is not counted at all. Either add a componentMeta entry (at\n"
        + "`status: \"catalogued\"` while its facets are still being written), or, if the symbol is not part of\n"
        + "the package contract, stop exporting it from the barrel. Baselining it is the third option and needs\n"
        + "an argument, not a note.\n",
    );
    console.error(formatViolations(failing));
    console.error(`\n${failing.length} unregistered public component(s).`);
    if (baseline) {
      console.error(`${hardResult.suppressed.length} further violation(s) suppressed by ${label}.`);
    }
    console.error("Top offending components:");
    for (const { selector, count } of topOffenders(failing)) {
      console.error(`  ${count}x ${selector}`);
    }
    return 1;
  }

  const suppressed = hardResult.suppressed.length + softResult.suppressed.length;
  console.log(
    `check-catalog-registration: no new uncatalogued public component(s) `
      + `(${counts.total} export(s) from src/${PUBLIC_ENTRY}: ${counts.component} component(s), `
      + `${counts.registered} catalogued; ${counts.type} type(s), ${counts["hook-or-utility"]} hook(s)/utility(ies) and `
      + `${counts["constant-or-class"]} constant(s)/class(es) are not catalog entries by kind)`
      + (suppressed > 0 ? `; ${suppressed} known gap(s) held by the baseline.` : ".")
      + (soft.length > 0 && !options.strict ? ` ${soft.length} compound part(s) listed above for review.` : ""),
  );
  // Said out loud so the checked surface is never mistaken for the whole
  // library: the barrel is NARROWER than the catalog. Most catalogued
  // components are demo/review surface reached through the Catalog Explorer,
  // not exports a consumer can import. This guard answers "is everything
  // EXPORTED catalogued", never "is everything catalogued exported".
  console.log(
    `  Surface checked: ${counts.component} of ${catalog.names.size} catalogued component name(s) are reachable `
      + `from the public barrel; the rest are catalogued but not exported, which this guard does not police.`,
  );
  return 0;
}

/**
 * The only exemption this guard grants a baseline entry: the component was
 * ALREADY exported and uncatalogued when the gate was added (uif/issue-4675),
 * so the gate is holding a pre-existing gap flat rather than failing a build
 * nobody made worse. A newly exported component cannot claim it — "pre-existing"
 * is a fact about a date, and a reviewer can check it in the log.
 */
export const EXEMPTION_CATEGORIES = [
  {
    label: "pre-existing uncatalogued public export found when this gate was added (uif/issue-4675)",
    pattern: /pre-existing/i,
  },
];

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main());
}
