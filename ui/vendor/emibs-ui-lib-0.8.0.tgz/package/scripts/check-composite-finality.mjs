import { readFileSync, readdirSync } from "node:fs";
import { join, relative } from "node:path";
import { pathToFileURL } from "node:url";
import { findNativeConfirmCalls } from "./check-confirm-source.mjs";
import { importsBinding } from "./check-import-source.mjs";

const root = join(process.cwd(), "src");
/**
 * The complete set of files allowed to import SectionCard.
 *
 * This list IS the rule — "one owner per E4 concept" means SectionCard is
 * composed by pages and layouts and by nothing else — and it was the softest
 * thing in the guard: adding a line here widened the rule with nothing going
 * red anywhere, which is indistinguishable from the rule not existing. Its
 * membership is pinned by check-composite-finality.test.mjs, so a widening has
 * to be made twice, on purpose, and shows up in review as what it is.
 *
 * Exported for that test.
 */
export const allowedSectionCardImporters = new Set([
  "catalog/registry/demoComponents/catalogTooling.tsx",
  "catalog/registry/demoComponents/feedback.tsx",
  "catalog/registry/demoComponents/layout.tsx",
  "catalog/registry/demoComponents/theming.tsx",
  "catalog/registry/demos.tsx",
  "catalog/registry/states/layout.tsx",
  "catalog/registry/variants/layout.tsx",
  "components/canonicalComposites.test.tsx",
  "components/layout/SectionCard.test.tsx",
]);
const flatComponentDirectories = ["components/auth/", "components/data/", "components/feedback/", "forms/"];
export const retired = [
  "DataTableView",
  "PagedDataTable",
  "SectionPanel",
  "FilterBar",
  "ui-paged-table",
  "ui-empty",
  "ui-filter-bar",
  "ui-description-list--cards",
  "ui-description-list--plain",
];
export const retiredCatalogIds = ["paged-data-table", "filter-bar"];
const retiredDataTableApi = [
  "StaticDataTableColumn",
  "ControlledDataTableColumn",
  "legacyOnSort",
  "legacySortDirection",
  "externalPagination",
  "selectedRowId",
  "onRowSelect",
];

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/**
 * Word-accurate match for a retired identifier or CSS class.
 *
 * A plain `source.includes(token)` flags any longer name that merely *contains*
 * the retired one: retiring `FilterBar` would report a live `FilterBarrier`,
 * and retiring `SectionPanel` would report a live `ProductSectionPanel`. So the
 * token must sit on its own word boundaries:
 *
 * - leading `(?<![A-Za-z0-9])` — `FilterBar` does not match `MyFilterBar`, and
 *   `ui-filter-bar` does not match `xui-filter-bar`; `.ui-filter-bar` and
 *   `<FilterBar />` still match, because `.` and `<` are not word characters.
 * - trailing `(?![a-z0-9])` — the token may not continue into the *same* word,
 *   so `FilterBar` misses `FilterBarrier` and `ui-filter-bar` misses
 *   `ui-filter-barcode`. A following uppercase letter starts a new camelCase
 *   part and a following `-`/`_` starts a new CSS part, so derivatives of the
 *   retired name are still caught: `FilterBarProps`, `ui-filter-bar__title`,
 *   `ui-filter-bar--compact`, and (as before) `ui-empty-state`.
 *
 * The rule is strictly narrower than substring matching, so it can only remove
 * false positives — it never lets through anything the old check caught as a
 * whole word.
 */
export function retiredTokenPattern(token) {
  return new RegExp(`(?<![A-Za-z0-9])${escapeRegExp(token)}(?![a-z0-9])`);
}

/** Retired symbols/classes referenced anywhere in `source`. */
export function findRetiredTokens(source, tokens = retired) {
  return tokens.filter((token) => retiredTokenPattern(token).test(source));
}

/**
 * Retired catalog ids referenced as an actual catalog id — `id="…"`, `id: "…"`
 * or `href: "#…"` — rather than as incidental prose. The trailing
 * `(?:["']|\b)` lets a retired id be caught in a longer *hyphenated* id
 * (`id="filter-bar-legacy"`) without matching a different word
 * (`id="filter-barcode"`).
 */
export function findRetiredCatalogIds(source, ids = retiredCatalogIds) {
  return ids.filter((id) => {
    const escaped = escapeRegExp(id);
    const catalogReference = new RegExp(
      `(?:\\bid\\s*=\\s*["']|\\bid\\s*:\\s*["']|\\bhref\\s*:\\s*["']#)${escaped}(?:["']|\\b)`,
    );
    return catalogReference.test(source);
  });
}

function files(directory) {
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? files(path) : [path];
  });
}

function main() {
  const failures = [];
  for (const path of files(root)) {
    if (!/\.(?:ts|tsx|css)$/.test(path)) continue;
    const source = readFileSync(path, "utf8");
    // Normalise to POSIX separators: the allow-lists below are written with
    // "/", and on Windows `relative()` returns "\\"-separated paths.
    const file = relative(root, path).split(/[\\/]/).join("/");
    for (const symbol of findRetiredTokens(source)) {
      failures.push(`${file}: retired ${symbol}`);
    }
    for (const id of findRetiredCatalogIds(source)) {
      failures.push(`${file}: retired catalog id ${id}`);
    }
    if (file === "components/data/DataTable.tsx") {
      for (const symbol of retiredDataTableApi) {
        if (new RegExp(`\\b${symbol}\\b`).test(source)) failures.push(`${file}: retired DataTable API ${symbol}`);
      }
      for (const prop of ["rows", "title", "description", "actions", "toolbar"]) {
        if (new RegExp(`\\b${prop}\\?:`).test(source)) failures.push(`${file}: retired DataTable prop ${prop}`);
      }
    }
    const importsSectionCard = importsBinding(path, source, "SectionCard");
    if (importsSectionCard && !allowedSectionCardImporters.has(file)) {
      failures.push(`${file}: SectionCard import is outside the page/layout allow-list`);
    }
    if (flatComponentDirectories.some((directory) => file.startsWith(directory)) && importsSectionCard) {
      failures.push(`${file}: shared components must remain flat and cannot import SectionCard`);
    }
    for (const failure of findNativeConfirmCalls(path, source)) {
      failures.push(`${file}: ${failure}`);
    }
  }

  if (failures.length) {
    console.error(`Composite finality failed:\n${failures.map((failure) => `- ${failure}`).join("\n")}`);
    return 1;
  }

  console.log("Composite finality: one owner per E4 concept; retired paths absent.");
  return 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main());
}
