import { existsSync, readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import ts from "typescript";
import {
  applyBaseline,
  baselineIntegrityReport,
  baselineLabel,
  formatViolations,
  loadBaseline,
  parseGuardArgs,
  serializeBaseline,
  topOffenders,
  writeBaseline,
} from "./guard-baseline.mjs";

// The catalog documented deep import paths — `emibs-ui-lib/components/data/
// AuditTimeline` and 140-odd siblings — for the large majority of its usage
// snippets, while package.json declared no `exports` map at all. Nothing in the
// build compared the two, so every one of those documented specifiers was
// aspirational: a consumer copying a snippet out of the catalog got
// ERR_PACKAGE_PATH_NOT_EXPORTED, or (worse, before the map existed) reached
// around the public surface into `src/` and coupled itself to the file layout.
// uif/issue-4676 added the map. This guard is what keeps the map and the
// catalog from drifting apart again — the same failure mode the prop-docs gate
// was added for one ticket earlier, in a different column of the same table.
//
// Three directions are checked, because drift has three shapes:
//
//  1. DOCUMENTED -> MAP. Every import specifier written into a usage snippet
//     that names this package must resolve against the exports map, and the
//     subpath it resolves to must exist on disk. This is the direction that
//     fails when somebody documents a component before exporting it, or
//     documents a path that was never real. It is the direction the ticket
//     asked for.
//
//  2. MAP -> DISK. Every target in the map must resolve, through Node's own
//     resolver, to a regular file. A map entry pointing at a deleted or
//     renamed module — or at a directory — is dead public API: it reads as a
//     promise, and it breaks at the consumer rather than here.
//
//  3. MAP -> DOCUMENTED. Every `./components/**` subpath in the map must be
//     documented by at least one usage snippet. This is the direction that
//     enforces the wildcard-versus-explicit decision recorded below: an
//     enumerated public surface is only worth its verbosity if every entry in
//     it is a deliberate, documented promise. Without this check the map grows
//     entries nobody documents, which is precisely the undocumented surface
//     this package has spent the last day discovering rots.
//
// A `*` subpath pattern is a hard failure, not a resolution case to support.
// The choice between `"./components/*": "./src/components/*.tsx"` and an
// explicit entry per component is the whole design decision of this ticket,
// and it went to explicit:
//
//   - A pattern makes the public surface UNENUMERABLE. It is not a list, it is
//     whatever files happen to sit under src/components — so neither this guard
//     nor a reviewer can compare "what the package promises" against "what the
//     catalog documents". Every other gate in this directory rests on the
//     premise that the documented surface is a finite thing you can iterate.
//   - A pattern publishes by accident. Landing src/components/data/Foo.tsx
//     would silently make `emibs-ui-lib/components/data/Foo` public API with no
//     decision taken, no spec, no prop docs and no catalog entry — and, being
//     public, it could not later be removed without a breaking change.
//   - A pattern cannot express the surface anyway. `components/primitives/
//     overlay` is a directory whose index.ts exports the engine but NOT the
//     stacking/focus-trap internals beside it (see src/lib/index.ts); a
//     `./components/*` -> `./src/components/*.tsx` pattern misses it, and a
//     second pattern to cover it reintroduces the subtlety of longest-static-
//     prefix precedence for no gain.
//
// The cost of explicit entries is one line in package.json per component, paid
// once, by the person adding the component — which is exactly when the decision
// to make it public should be taken.
//
// RESOLUTION, NOT EXISTENCE (cross-provider review of #501, uif/issue-4676).
// Directions (1) and (2) used to check `existsSync(target)`. `existsSync`
// returns true for a directory, so a map entry pointing at a directory —
// `"./components/data/Foo": "./src/components/data"` instead of
// `.../Foo.tsx` — passed the gate while being genuinely non-resolvable: a
// consumer importing it gets `ERR_UNSUPPORTED_DIR_IMPORT` or
// `ERR_PACKAGE_PATH_NOT_EXPORTED`, not a working module. That defeated the
// gate's whole purpose, which is to guarantee every documented specifier
// resolves, not merely that something sits at that path.
//
// The fix has two parts, and both matter:
//
//   - REAL RESOLUTION. `resolveAndVerify` below is handed `import.meta.resolve`
//     itself (bound to this module) rather than re-deriving a path by hand, so
//     the gate exercises the exact mechanism a consumer's `import
//     "emibs-ui-lib/components/..."` uses — Node's self-referencing-package
//     resolution (https://nodejs.org/api/packages.html#self-referencing-a-package-using-its-name),
//     which resolves this package's own name against the nearest ancestor
//     package.json, i.e. this package's own manifest. That is strictly
//     stronger than replaying `resolveTarget`'s hand-rolled condition-priority
//     list by hand: it also catches anything Node's actual algorithm rejects
//     that a hand-rolled walk would not (malformed targets, invalid subpath
//     syntax, self-reference name mismatches).
//
//   - RESIDUAL GAP: Node's resolver is deliberately filesystem-blind. Proven
//     directly (see check-export-map.test.mjs): `import.meta.resolve` on a
//     specifier mapped to a directory, or to a path that does not exist at
//     all, SUCCEEDS and returns a URL — resolution only computes where a
//     specifier points, it does not check what is there. The `ERR_UNSUPPORTED_
//     DIR_IMPORT` a consumer actually hits is raised later, at load time, not
//     at resolve time. So real resolution alone does not close this defect;
//     `verifyResolvedUrl` follows every resolved URL with `statSync` and
//     requires `isFile()`, which is the check that actually rejects a
//     directory (`isDirectory()`), a dir-symlink (`statSync` follows
//     symlinks, so it reports the target's real type), or a dangling path
//     (`statSync` throws `ENOENT`).
//
//   A further gap remains and is accepted rather than closed: this script
//   cannot dynamically `import()` the 165 real targets to prove they load
//   without a syntax error, because they are `.tsx`/`.ts` source in an
//   unbuilt package and plain Node has no JSX-capable loader wired into this
//   script. "Resolves to an existing regular file" is the strongest signal
//   available at this layer; full module evaluation is left to the consuming
//   apps' own bundlers and to this repo's typecheck, not to this gate.
//
// CONDITIONAL MAPS. `resolveTarget` below walks a condition object
// (`{ types, import, default, … }`) but only far enough to report a single
// display value for a violation message — it is NOT used for the pass/fail
// resolution check any more (that is real `import.meta.resolve`, which
// evaluates conditions correctly). Even so, a condition-object entry is
// rejected outright by `conditionalSubpaths` below, for the same reason a `*`
// pattern is rejected: this package's map is a hand-enumerated, one-target-
// per-subpath surface by design (see above), and a map that CAN carry
// per-environment targets reopens exactly the ambiguity — "which target did
// the reviewer check?" — this ticket exists to close. Every one of today's
// 165 entries is a bare string, so this is a currently-inert guard against a
// shape nobody has used yet, same as the `*` check was when it was written.

const PACKAGE_NAME = "emibs-ui-lib";
const USAGES_DIR = "src/catalog/registry/usages";

/**
 * Subpaths that are public on purpose without a usage snippet naming them, and
 * are therefore exempt from direction (3). Each is an aggregate root or a
 * package asset rather than a component module, so no single catalog entry owns
 * it; the note records what does.
 */
export const NON_COMPONENT_SUBPATHS = new Map([
  [".", "the barrel (src/lib/index.ts); documented by the usage snippets that import cross-cutting hooks from it"],
  ["./core", "headless engine aggregate; documented by src/forms/AutoForm.SPEC.md and the auto-form usage snippet"],
  ["./forms", "forms aggregate; documented by src/forms/*.SPEC.md and eight usage snippets"],
  ["./theme", "theme aggregate; emitted verbatim into user-facing output by themeToTsModule (src/theme/tokens.ts)"],
  ["./styles.css", "the package stylesheet; imported for its side effect by emibs-svc-auth/ui and emibs-files-ui"],
  ["./package.json", "conventionally exported so tooling can read the manifest"],
]);

function scriptKind(file) {
  return file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
}

function parseSource(file, source) {
  return ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, scriptKind(file));
}

/**
 * Module specifiers named by the `import` field of every usage snippet in one
 * usages/*.ts module, as `{ specifier, entryId, line }`.
 *
 * The snippet is documentation TEXT held in a string literal, so it is parsed
 * as TypeScript in its own right rather than pattern-matched: a snippet
 * legitimately contains several import statements ("import { AutoForm } from
 * …\nimport { zodToSpec } from …"), and a regex over the outer file would also
 * pick up the module's own real imports, which are not documentation at all.
 */
export function extractDocumentedSpecifiers(file, source) {
  const sf = parseSource(file, source);
  const found = [];

  const entryIdOf = (node) => {
    // node is the `import:` PropertyAssignment; its object literal is the value
    // of a `"<entry-id>": { … }` property on the usages record.
    const owner = node.parent?.parent;
    if (owner && ts.isPropertyAssignment(owner)) {
      return owner.name.getText(sf).replace(/^["']|["']$/g, "");
    }
    return "(unknown entry)";
  };

  const visit = (node) => {
    if (
      ts.isPropertyAssignment(node)
      && node.name.getText(sf).replace(/^["']|["']$/g, "") === "import"
      && ts.isStringLiteralLike(node.initializer)
    ) {
      const entryId = entryIdOf(node);
      const line = sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1;
      const snippet = ts.createSourceFile(
        "usage-snippet.ts",
        node.initializer.text,
        ts.ScriptTarget.Latest,
        true,
        ts.ScriptKind.TS,
      );
      for (const statement of snippet.statements) {
        if (ts.isImportDeclaration(statement) && ts.isStringLiteralLike(statement.moduleSpecifier)) {
          found.push({ specifier: statement.moduleSpecifier.text, entryId, line });
        }
      }
    }
    ts.forEachChild(node, visit);
  };

  visit(sf);
  return found;
}

/** True for a specifier that names THIS package (the only ones this gate owns). */
export function isOwnPackage(specifier) {
  return specifier === PACKAGE_NAME || specifier.startsWith(`${PACKAGE_NAME}/`);
}

/** `emibs-ui-lib/components/data/AuditTimeline` -> `./components/data/AuditTimeline`. */
export function toSubpath(specifier) {
  return specifier === PACKAGE_NAME ? "." : `./${specifier.slice(PACKAGE_NAME.length + 1)}`;
}

/** Inverse of `toSubpath`: `./components/data/AuditTimeline` -> `emibs-ui-lib/components/data/AuditTimeline`. */
export function toSpecifier(subpath) {
  return subpath === "." ? PACKAGE_NAME : `${PACKAGE_NAME}/${subpath.slice(2)}`;
}

/**
 * The file an exports-map value points at, following condition objects
 * ("types"/"import"/"default") the way a bundler would, or `null` when the
 * value resolves to nothing (an explicit `null` block, or an object with no
 * usable condition).
 *
 * Conditions are not used by the map today — every target is a plain string,
 * because the package is unbuilt and one TypeScript source file serves as both
 * the implementation and its own declarations. The traversal exists so that
 * adding a condition later does not silently blind this guard.
 */
export function resolveTarget(value) {
  if (value === null || value === undefined) return null;
  if (typeof value === "string") return value;
  if (Array.isArray(value)) {
    for (const candidate of value) {
      const resolved = resolveTarget(candidate);
      if (resolved) return resolved;
    }
    return null;
  }
  if (typeof value !== "object") return null;
  for (const condition of ["types", "import", "module", "default", "require"]) {
    if (condition in value) {
      const resolved = resolveTarget(value[condition]);
      if (resolved) return resolved;
    }
  }
  return null;
}

/**
 * Look one subpath up in the map. Exact-match only, deliberately: the map
 * declares no `*` patterns, and `patternSubpaths` below fails the build if one
 * appears, so there is no pattern-precedence case to get subtly wrong here.
 */
export function lookupSubpath(exportsMap, subpath) {
  if (!exportsMap || typeof exportsMap !== "object") return undefined;
  return Object.prototype.hasOwnProperty.call(exportsMap, subpath) ? exportsMap[subpath] : undefined;
}

/** Subpath keys carrying a `*` pattern — see the header note on why these fail. */
export function patternSubpaths(exportsMap) {
  if (!exportsMap || typeof exportsMap !== "object") return [];
  return Object.keys(exportsMap).filter((key) => key.includes("*"));
}

/**
 * Subpath keys whose value is a condition object/array rather than a bare
 * string — see the header note ("CONDITIONAL MAPS") on why these are a hard
 * failure rather than a partially-supported shape.
 */
export function conditionalSubpaths(exportsMap) {
  if (!exportsMap || typeof exportsMap !== "object") return [];
  return Object.keys(exportsMap).filter((key) => typeof exportsMap[key] !== "string");
}

/**
 * Follow a resolved module URL to a filesystem verdict: it must name an
 * existing REGULAR FILE. `import.meta.resolve` (the `resolve` a caller passes
 * to `resolveAndVerify`) will happily hand back a URL pointing at a
 * directory, a dangling path, or a dir-symlink — Node's resolver does not
 * touch the filesystem — so this is the check that actually catches those.
 * `statSync` (not `lstatSync`) is deliberate: it follows a symlink to report
 * what the link ultimately points at, which is what a consumer would load.
 */
export function verifyResolvedUrl(url) {
  let path;
  try {
    path = fileURLToPath(url);
  } catch {
    return { ok: false, reason: `resolves to a non-file URL (${url}), which cannot be loaded as a module` };
  }
  let stat;
  try {
    stat = statSync(path);
  } catch {
    return { ok: false, reason: `resolves to ${path}, which does not exist` };
  }
  if (!stat.isFile()) {
    const kind = stat.isDirectory() ? "a directory" : "not a regular file";
    return { ok: false, reason: `resolves to ${path}, which is ${kind} — not something a consumer can import` };
  }
  return { ok: true, path };
}

/**
 * Resolve `specifier` with a caller-supplied resolver — production code
 * passes `import.meta.resolve` bound to this module (see the header note on
 * self-referencing-package resolution); tests pass one bound to a throwaway
 * fixture package instead, so the directory/missing/symlink cases can be
 * proven without mutating this package's own manifest — then require the
 * result to be an existing regular file.
 */
export function resolveAndVerify(resolve, specifier) {
  let url;
  try {
    url = resolve(specifier);
  } catch (error) {
    return { ok: false, reason: `does not resolve (${error.code ?? error.constructor.name}: ${error.message})` };
  }
  return verifyResolvedUrl(url);
}

function listUsageFiles(directory) {
  if (!existsSync(directory)) return [];
  return readdirSync(directory)
    .filter((name) => name.endsWith(".ts") && name !== "index.ts" && !name.endsWith(".test.ts"))
    .sort()
    .map((name) => join(directory, name));
}

function violation({ file, line, selector, property, value, note }) {
  return { file, line, selector, property, value, note };
}

function main() {
  const packageRoot = fileURLToPath(new URL("..", import.meta.url));
  const defaultBaseline = join(packageRoot, "scripts/baselines/export-map.json");
  const options = parseGuardArgs(process.argv.slice(2), { defaultBaseline });
  const label = baselineLabel(packageRoot, options.baseline);

  const manifestPath = join(packageRoot, "package.json");
  const manifest = JSON.parse(readFileSync(manifestPath, "utf8"));
  const exportsMap = manifest.exports;

  if (!exportsMap || typeof exportsMap !== "object" || Array.isArray(exportsMap)) {
    console.error(
      "\ncheck-export-map: package.json declares no `exports` map.\n"
        + "The catalog documents deep import paths for most of its usage snippets; without a map\n"
        + "none of them resolve for a consumer, and every documented path is aspirational.\n",
    );
    return 1;
  }

  const patterns = patternSubpaths(exportsMap);
  if (patterns.length > 0) {
    console.error(
      `\ncheck-export-map: the exports map declares ${patterns.length} wildcard subpath(s): `
        + `${patterns.join(", ")}.\n\n`
        + "This package enumerates its public surface on purpose (uif/issue-4676). A `*` pattern makes\n"
        + "the surface whatever files happen to exist, so neither this guard nor a reviewer can compare\n"
        + "what the package promises against what the catalog documents, and every new file under the\n"
        + "matched directory becomes public API with no decision taken. Add one explicit entry per\n"
        + "module instead — the line in package.json is the decision.\n",
    );
    return 1;
  }

  const conditional = conditionalSubpaths(exportsMap);
  if (conditional.length > 0) {
    console.error(
      `\ncheck-export-map: the exports map declares ${conditional.length} conditional (non-string) `
        + `subpath(s): ${conditional.join(", ")}.\n\n`
        + "Conditional export targets are not supported by this gate. Every entry today is a bare string,\n"
        + "and a validator that only checks one branch of a condition object (as this gate briefly did) is\n"
        + "worse than one that refuses the shape outright: it would report a subpath as verified when only\n"
        + "one of its several possible targets was ever checked. Map this subpath to a single string target\n"
        + "instead — the same explicit-over-implicit call this package already makes for `*` patterns.\n",
    );
    return 1;
  }

  // Node's own resolver, bound to this module so a bare specifier resolves
  // via self-reference against THIS package's manifest — the same mechanism
  // a consumer's `import "emibs-ui-lib/..."` uses. See the header note.
  const resolveOwn = (specifier) => import.meta.resolve(specifier);

  const usagesDir = join(packageRoot, USAGES_DIR);
  const documented = new Map(); // subpath -> [{ entryId, line, file }]
  let snippetImports = 0;
  let foreignImports = 0;

  for (const file of listUsageFiles(usagesDir)) {
    const rel = relative(packageRoot, file);
    for (const { specifier, entryId, line } of extractDocumentedSpecifiers(file, readFileSync(file, "utf8"))) {
      snippetImports += 1;
      if (!isOwnPackage(specifier)) {
        // `lucide-react` and friends: real, resolvable, and none of this gate's business.
        foreignImports += 1;
        continue;
      }
      const subpath = toSubpath(specifier);
      if (!documented.has(subpath)) documented.set(subpath, []);
      documented.get(subpath).push({ entryId, line, file: rel, specifier });
    }
  }

  const violations = [];

  // (1) DOCUMENTED -> MAP.
  for (const [subpath, sites] of documented) {
    const entry = lookupSubpath(exportsMap, subpath);
    const site = sites[0];
    if (entry === undefined) {
      violations.push(violation({
        file: site.file,
        line: site.line,
        selector: site.entryId,
        property: "undocumented-export",
        value: site.specifier,
        note: `usage snippet imports "${site.specifier}", but package.json exports no "${subpath}" subpath — `
          + "a consumer copying this snippet gets ERR_PACKAGE_PATH_NOT_EXPORTED",
      }));
      continue;
    }
    const result = resolveAndVerify(resolveOwn, site.specifier);
    if (!result.ok) {
      violations.push(violation({
        file: site.file,
        line: site.line,
        selector: site.entryId,
        property: "unresolvable-target",
        value: site.specifier,
        note: `usage snippet imports "${site.specifier}", but it ${result.reason} — a consumer resolving `
          + "this specifier the same way Node does hits the same failure",
      }));
    }
  }

  // (2) MAP -> DISK.
  const manifestRel = relative(packageRoot, manifestPath);
  for (const subpath of Object.keys(exportsMap)) {
    const result = resolveAndVerify(resolveOwn, toSpecifier(subpath));
    if (!result.ok) {
      violations.push(violation({
        file: manifestRel,
        line: 0,
        selector: subpath,
        property: "dead-export",
        value: resolveTarget(exportsMap[subpath]) ?? "(unresolvable)",
        note: `exports entry "${subpath}" ${result.reason} — dead public API`,
      }));
    }
  }

  // (3) MAP -> DOCUMENTED.
  for (const subpath of Object.keys(exportsMap)) {
    if (NON_COMPONENT_SUBPATHS.has(subpath)) continue;
    if (documented.has(subpath)) continue;
    violations.push(violation({
      file: manifestRel,
      line: 0,
      selector: subpath,
      property: "undocumented-surface",
      value: resolveTarget(exportsMap[subpath]) ?? "(unresolvable)",
      note: `exports entry "${subpath}" is public API that no usage snippet documents — either document it in `
        + `${USAGES_DIR}/ or drop the entry; an enumerated surface is only worth its verbosity if every entry `
        + "is a deliberate, documented promise",
    }));
  }

  const componentSubpaths = Object.keys(exportsMap).filter((key) => !NON_COMPONENT_SUBPATHS.has(key)).length;

  if (options.updateBaseline) {
    const previous = loadBaseline(options.baseline);
    writeBaseline(options.baseline, serializeBaseline("check-export-map", violations, { previous }));
    console.log(`check-export-map: wrote baseline of ${violations.length} violation(s) to ${label}`);
    return 0;
  }

  const baseline = loadBaseline(options.baseline);
  const integrity = baselineIntegrityReport(baseline, violations, { label, categories: EXEMPTION_CATEGORIES });
  if (integrity) {
    console.error(integrity);
    console.error("\ncheck-export-map: baseline is not accountable (see above).");
    return 1;
  }

  const { fresh, suppressed } = applyBaseline(violations, baseline);

  if (fresh.length > 0) {
    console.error(
      "\nThe exports map and the documented import paths disagree.\n"
        + "Either the catalog documents a specifier the package does not export (add the entry to\n"
        + "package.json `exports`), or the package exports a subpath nothing documents (document it in\n"
        + `${USAGES_DIR}/, or drop it). A documented path that does not resolve is not documentation;\n`
        + "it is a promise the package breaks at the consumer.\n",
    );
    console.error(formatViolations(fresh));
    console.error(`\n${fresh.length} exports-map violation(s).`);
    if (baseline) console.error(`${suppressed.length} further violation(s) suppressed by ${label}.`);
    console.error("Top offending subpaths/entries:");
    for (const { selector, count } of topOffenders(fresh)) console.error(`  ${count}x ${selector}`);
    return 1;
  }

  console.log(
    `check-export-map: ${documented.size} documented specifier shape(s) across ${snippetImports - foreignImports} `
      + `snippet import(s) all resolve; ${componentSubpaths} component subpath(s) + ${NON_COMPONENT_SUBPATHS.size} `
      + `declared root(s) all documented and present on disk`
      + (suppressed.length > 0 ? `; ${suppressed.length} known violation(s) held by the baseline.` : "."),
  );
  return 0;
}

/**
 * The only exemption this guard grants a baseline entry.
 *
 * A path documented before the module exists is a real, temporary state during
 * a component's first landing — the catalog entry and the component can arrive
 * in either order. Nothing else belongs in a baseline here: an exports entry
 * pointing at a deleted file, or public API nobody documents, is the defect
 * this gate exists to name, and shelving it reproduces exactly the drift that
 * made every documented deep path aspirational in the first place.
 */
export const EXEMPTION_CATEGORIES = [
  {
    label: "a component landing in stages, where the catalog entry precedes the module it documents",
    pattern: /landing in stages|not yet (?:added|created|landed)|precedes the module/i,
  },
];

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main());
}
