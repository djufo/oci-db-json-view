import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  EXEMPTION_CATEGORIES,
  UNRESOLVABLE,
  collectFileTypeMemberNames,
  diffPropDocRows,
  extractComponentMeta,
  extractPropDocEntries,
  findBacktickIdentifiers,
  findPropsMembers,
  findSpecBacktickDrift,
  isNestedTypeDoc,
  splitDocumentedNames,
} from "./check-prop-docs.mjs";
import { applyBaseline, reasonProblem, serializeBaseline, violationKey } from "./guard-baseline.mjs";

const fixturePath = (name) => fileURLToPath(new URL(`./fixtures/prop-docs-gate/${name}`, import.meta.url));
const fixture = (name) => readFileSync(fixturePath(name), "utf8");

describe("prop docs gate — reading componentMeta", () => {
  it("extracts id, name, and specPath from a componentMeta array literal", () => {
    const entries = extractComponentMeta(fixturePath("metadata.sample.ts"), fixture("metadata.sample.ts"));
    expect(entries).toEqual([
      { id: "simple-card", name: "SimpleCard", specPath: "./SimpleCard.SPEC.md" },
      { id: "extends-html", name: "ExtendsHtml", specPath: "./ExtendsHtml.SPEC.md" },
      { id: "no-source", name: "NoSource", specPath: "./NoSource.SPEC.md" },
      { id: "no-docs", name: "NoDocs", specPath: null },
    ]);
  });
});

describe("prop docs gate — reading propDocs rows", () => {
  it("extracts every row's name and line for each component id, verbatim", () => {
    const byId = extractPropDocEntries(fixturePath("propDocs.sample.ts"), fixture("propDocs.sample.ts"));
    expect(Object.keys(byId)).toEqual(["simple-card"]);
    expect(byId["simple-card"].map((row) => row.name)).toEqual([
      "title",
      "badges",
      "onClose / closeLabel",
      "SimpleCardRow.href / external",
      "close",
    ]);
    expect(byId["simple-card"][0].line).toBeGreaterThan(0);
  });
});

describe("prop docs gate — reading a component's Props type", () => {
  it("reads every top-level member of a plain object-literal Props type", () => {
    const members = findPropsMembers(fixturePath("SimpleCard.tsx"), fixture("SimpleCard.tsx"), "SimpleCardProps");
    expect([...members].sort()).toEqual(
      ["actions", "badges", "className", "closeLabel", "onClose", "title"].sort(),
    );
  });

  it("returns null when the named type does not exist in the file", () => {
    expect(findPropsMembers(fixturePath("SimpleCard.tsx"), fixture("SimpleCard.tsx"), "NoSuchProps")).toBeNull();
  });

  it("returns UNRESOLVABLE for a Props type that extends a generic/imported type", () => {
    const result = findPropsMembers(fixturePath("ExtendsHtml.tsx"), fixture("ExtendsHtml.tsx"), "ExtendsHtmlProps");
    expect(result).toBe(UNRESOLVABLE);
  });
});

describe("prop docs gate — whole-file type vocabulary", () => {
  it("collects member names from every interface/type literal in the file, not just the Props type", () => {
    const names = collectFileTypeMemberNames(fixturePath("SimpleCard.tsx"), fixture("SimpleCard.tsx"));
    // Own Props members...
    expect(names.has("title")).toBe(true);
    expect(names.has("onClose")).toBe(true);
    // ...and the nested SimpleCardRow's fields.
    expect(names.has("href")).toBe(true);
    expect(names.has("external")).toBe(true);
    // Not real fields anywhere in the file.
    expect(names.has("close")).toBe(false);
  });
});

describe("prop docs gate — splitting a propDocs row name into candidates", () => {
  it("splits a combined name on '/' into individual identifiers", () => {
    expect(splitDocumentedNames("onClose / closeLabel")).toEqual(["onClose", "closeLabel"]);
  });

  it("recognises a dotted nested-type reference and treats the whole row as non-top-level", () => {
    expect(isNestedTypeDoc("SimpleCardRow.href / external")).toBe(true);
    expect(splitDocumentedNames("SimpleCardRow.href / external")).toEqual([]);
    // A lowercase compound path is the same shape: "overrides.controls".
    expect(splitDocumentedNames("overrides.renderField / renderSection")).toEqual([]);
  });

  it("drops rest markers, wildcards, and prose phrases rather than guessing", () => {
    expect(splitDocumentedNames("...props")).toEqual([]);
    expect(splitDocumentedNames("loading / *State")).toEqual(["loading"]);
    expect(splitDocumentedNames("ariaLabel / control labels")).toEqual(["ariaLabel"]);
  });
});

describe("prop docs gate — diffing propDocs rows against the Props type", () => {
  const componentFile = fixturePath("SimpleCard.tsx");
  const componentSource = fixture("SimpleCard.tsx");
  const propMembers = findPropsMembers(componentFile, componentSource, "SimpleCardProps");
  const fileTypeMembers = collectFileTypeMemberNames(componentFile, componentSource);

  it("passes every row that names a real top-level prop", () => {
    const rows = [
      { name: "title", line: 1 },
      { name: "onClose / closeLabel", line: 2 },
    ];
    const result = diffPropDocRows(rows, propMembers, fileTypeMembers);
    expect(result).toEqual({ hard: [], soft: [], skipped: false });
  });

  it("skips a dotted nested-type row entirely, never flagging it as hard OR soft", () => {
    const rows = [{ name: "SimpleCardRow.href / external", line: 3 }];
    expect(diffPropDocRows(rows, propMembers, fileTypeMembers)).toEqual({ hard: [], soft: [], skipped: false });
  });

  it("hard-fails a documented name that matches nothing anywhere in the file", () => {
    const rows = [{ name: "close", line: 4 }];
    const result = diffPropDocRows(rows, propMembers, fileTypeMembers);
    expect(result.hard).toEqual([{ candidate: "close", raw: "close", line: 4 }]);
    expect(result.soft).toEqual([]);
  });

  it("soft-flags an unprefixed name that IS a field of another type in the file", () => {
    // "href" is not a top-level SimpleCardProps member, but it IS a field of
    // the nested SimpleCardRow type declared in the same file — a plausible
    // shorthand rather than a name invented from nowhere.
    const rows = [{ name: "href", line: 5 }];
    const result = diffPropDocRows(rows, propMembers, fileTypeMembers);
    expect(result.hard).toEqual([]);
    expect(result.soft).toEqual([{ candidate: "href", raw: "href", line: 5 }]);
  });

  it("is skipped (neither hard nor soft) when the Props type is unresolvable", () => {
    const result = diffPropDocRows([{ name: "anything", line: 1 }], UNRESOLVABLE, new Set());
    expect(result).toEqual({ hard: [], soft: [], skipped: true });
  });
});

describe("prop docs gate — SPEC.md backtick scan", () => {
  it("extracts only backticked camelCase identifiers, ignoring plain words and hooks", () => {
    const found = findBacktickIdentifiers(
      "Renders `title`, `onClose`/`closeLabel`. Pairs with `useNotifications`. See `href`.",
    );
    expect(found.map((f) => f.name)).toEqual(["onClose", "closeLabel"]);
  });

  it("flags a backticked identifier absent from the known prop/field vocabulary", () => {
    const known = new Set(["title", "badges", "onClose", "closeLabel", "href", "external"]);
    const drift = findSpecBacktickDrift(fixture("SimpleCard.SPEC.md"), known);
    expect(drift.map((d) => d.name)).toEqual(["resolveWidgetTarget"]);
  });

  it("flags nothing once every backticked identifier is in the known vocabulary", () => {
    const known = new Set(["onClose", "closeLabel", "resolveWidgetTarget"]);
    expect(findSpecBacktickDrift(fixture("SimpleCard.SPEC.md"), known)).toEqual([]);
  });
});

describe("prop docs gate — baseline accounting", () => {
  it("suppresses only the exact component/prop pairs it recorded", () => {
    const violation = (id, name) => ({
      file: "src/catalog/registry/propDocs/data.ts",
      line: 1,
      selector: id,
      property: "propDocs",
      value: name,
    });
    const found = [violation("form-builder", "onExport"), violation("form-builder", "availableFieldTypes")];
    const baseline = serializeBaseline("check-prop-docs", found);
    expect(baseline.total).toBe(2);

    const unchanged = applyBaseline(found, baseline);
    expect(unchanged.fresh).toEqual([]);
    expect(unchanged.suppressed).toHaveLength(2);

    const withNewOne = applyBaseline([...found, violation("workflow-map-panel", "empty")], baseline);
    expect(withNewOne.fresh.map((v) => v.value)).toEqual(["empty"]);
  });

  it("keys a violation by component + prop, not by line number", () => {
    const a = { file: "f.ts", line: 10, selector: "x", property: "propDocs", value: "y" };
    const b = { file: "f.ts", line: 999, selector: "x", property: "propDocs", value: "y" };
    expect(violationKey(a)).toBe(violationKey(b));
  });

  it("requires a baseline reason to name the declared 'pre-existing' exemption", () => {
    expect(reasonProblem("", { categories: EXEMPTION_CATEGORIES })).toBe("no reason recorded");
    expect(
      reasonProblem("It looked fine to me when I skimmed it quickly one afternoon.", { categories: EXEMPTION_CATEGORIES }),
    ).toMatch(/names no declared exemption category/);
    expect(
      reasonProblem(
        "Pre-existing drift found by this gate, not one of the five uif/issue-4674 fixed directly; tracked for follow-up.",
        { categories: EXEMPTION_CATEGORIES },
      ),
    ).toBeNull();
  });
});
