import ts from "typescript";

function scriptKind(file) {
  return file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
}

function bindsName(importClause, name) {
  // `import SectionCard from "..."`
  if (importClause.name && importClause.name.text === name) return true;

  const bindings = importClause.namedBindings;
  if (!bindings) return false;

  // `import * as SectionCard from "..."`
  if (ts.isNamespaceImport(bindings)) return bindings.name.text === name;

  // `import { SectionCard }`, `import { SectionCard as Card }`, `import { Card as SectionCard }`.
  // An alias on either side still pulls the module in, so both names count. Inline type
  // specifiers (`import { type SectionCard }`) are erased at build time and do not.
  return bindings.elements.some(
    (element) =>
      !element.isTypeOnly
      && (element.name.text === name || element.propertyName?.text === name),
  );
}

/**
 * Reports whether the source contains a real `import` declaration that binds `name`,
 * without mistaking documentation text — usage snippets such as
 * `` import: `import { SectionCard } from "emibs-ui-lib";` `` , other string literals,
 * comments, JSX text, identifiers, or property names — for a module dependency.
 *
 * Type-only imports (`import type { SectionCard }` and `import { type SectionCard }`)
 * are deliberately NOT counted: they are erased at build time and create no runtime
 * composition dependency, which is the thing composite-finality gates.
 */
export function importsBinding(file, source, name) {
  // Any import that binds `name` must mention it textually; this keeps non-TypeScript
  // inputs (such as CSS) from being parsed at all.
  if (!source.includes(name)) return false;

  const sourceFile = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, scriptKind(file));
  let found = false;

  const visit = (node) => {
    if (found) return;
    if (
      ts.isImportDeclaration(node)
      && node.importClause
      && !node.importClause.isTypeOnly
      && bindsName(node.importClause, name)
    ) {
      found = true;
      return;
    }
    ts.forEachChild(node, visit);
  };

  visit(sourceFile);
  return found;
}
