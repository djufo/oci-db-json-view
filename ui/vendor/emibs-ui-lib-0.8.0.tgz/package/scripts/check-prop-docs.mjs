import { readdirSync, readFileSync, existsSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import ts from "typescript";
import {
  applyBaseline,
  baselineIntegrityReport,
  baselineLabel,
  formatViolations,
  loadBaseline,
  parseGuardArgs,
  serializeBaseline,
  topOffenders,
  writeBaseline,
} from "./guard-baseline.mjs";

// Five .SPEC.md files shipped a documented prop the component does not have —
// `close` on MapInfoCard, `empty` on MediaAssetPanel, a promised `loading`
// state on ModeControlPanel, five props missing from KanbanBoard's Contract,
// and a hardcoded `aria-haspopup="dialog"` on NotificationBell that is really
// a `"menu"` default — with nothing in the build catching any of it
// (uif/issue-4674). This guard is the catch: it reads the component's own
// Props TYPE from source and compares it against the propDocs entry for that
// component id, which is structured data rather than prose.
//
// Scope, stated honestly:
//
//  1. Only the propDocs table is compared against source — not .SPEC.md prose.
//     Parsing prose reliably is not tractable (the five bugs this ticket fixed
//     were phrases like "loading/status feedback" and "badge, row, action, and
//     close props" with no consistent shape to match against). propDocs is
//     hand-authored structured data with one job — name a real prop — so a
//     name that is not in the Props type is unambiguously wrong. This alone
//     would have caught four of the five (KanbanBoard's missing `getTaskKey`,
//     via the corresponding propDocs gap); the fifth (MapInfoCard's `close`)
//     lived only in prose that was never near a propDocs row, which is exactly
//     the class of error this guard cannot see and does not pretend to.
//  2. A Props type that cannot be read PURELY SYNTACTICALLY is skipped, not
//     guessed at. `ButtonProps = ButtonHTMLAttributes<...> & VariantProps<...>
//     & {...}` needs a real type checker to enumerate every inherited member;
//     without one, treating only the literal `{...}` tail as "the whole prop
//     surface" manufactures false positives for every inherited prop a
//     propDocs row happens to name (disabled, children, size, ...). Such
//     components are counted as "skipped" and reported, never silently
//     dropped.
//  3. A documented name that names a field of some OTHER type declared in the
//     same file (`MapInfoCardRow.href`, or an unprefixed shorthand such as
//     `href` alone when a nested item type in the file also has `href`) is a
//     softer signal than one that matches nothing in the file at all: the
//     first is at worst an imprecise label, the second cannot be explained by
//     any type in the file. Only the second is a build failure; the first is
//     reported as a review note (never enforced, matching the touch-target and
//     theme-token guards' non-blocking "review" bucket).
//  4. A cheap secondary signal: a backticked camelCase identifier inside a
//     SPEC.md that names neither a prop nor a field of any type in that
//     component's own file, AND appears nowhere in the whole package's known
//     prop/field vocabulary (so a legitimate cross-reference to another
//     component's real prop is not flagged). This is prose-adjacent and
//     deliberately conservative — hook names (`useNotifications`) are
//     excluded by convention — so it is folded into the same non-blocking
//     review bucket as (3), never a build failure. A prose parser that FAILS
//     the build is exactly the noise generator this ticket warned against.

const CATEGORY_FOLDERS = [
  { dir: "components", glob: "components" },
  { dir: "forms", glob: "forms" },
];

function scriptKind(file) {
  return file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
}

function parseSource(file, source) {
  return ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, scriptKind(file));
}

function propertyKeyText(sf, name) {
  return name.getText(sf).replace(/^["']|["']$/g, "");
}

function lineOf(sf, node) {
  return sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1;
}

/** `componentMeta` entries from src/catalog/metadata.ts: { id, name, specPath }. */
export function extractComponentMeta(file, source) {
  const sf = parseSource(file, source);
  const entries = [];
  const visit = (node) => {
    if (
      ts.isVariableDeclaration(node)
      && node.name.getText(sf) === "componentMeta"
      && node.initializer
      && ts.isArrayLiteralExpression(node.initializer)
    ) {
      for (const element of node.initializer.elements) {
        if (!ts.isObjectLiteralExpression(element)) continue;
        const entry = { id: null, name: null, specPath: null };
        for (const prop of element.properties) {
          if (!ts.isPropertyAssignment(prop)) continue;
          const key = propertyKeyText(sf, prop.name);
          if (key !== "id" && key !== "name" && key !== "specPath") continue;
          if (ts.isStringLiteral(prop.initializer)) entry[key] = prop.initializer.text;
          else if (prop.initializer.kind === ts.SyntaxKind.NullKeyword) entry[key] = null;
        }
        if (entry.id && entry.name) entries.push(entry);
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  return entries;
}

/** `{ "<id>": [{ name: "...", ... }, ...] }` rows out of one propDocs/*.ts module. */
export function extractPropDocEntries(file, source) {
  const sf = parseSource(file, source);
  const byId = {};
  const visit = (node) => {
    if (
      ts.isPropertyAssignment(node)
      && ts.isObjectLiteralExpression(node.parent)
      && ts.isVariableDeclaration(node.parent.parent)
      && /PropDocs$/.test(node.parent.parent.name.getText(sf))
      && ts.isArrayLiteralExpression(node.initializer)
    ) {
      const id = propertyKeyText(sf, node.name);
      const rows = [];
      for (const element of node.initializer.elements) {
        if (!ts.isObjectLiteralExpression(element)) continue;
        let name = null;
        for (const prop of element.properties) {
          if (!ts.isPropertyAssignment(prop)) continue;
          if (propertyKeyText(sf, prop.name) === "name" && ts.isStringLiteral(prop.initializer)) {
            name = prop.initializer.text;
          }
        }
        if (name) rows.push({ name, line: lineOf(sf, element) });
      }
      byId[id] = rows;
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  return byId;
}

/** Marks a Props type shape this guard cannot enumerate purely syntactically. */
export const UNRESOLVABLE = Symbol("unresolvable-props-type");

/**
 * Top-level member names of the named type alias/interface in `source`, or
 * `UNRESOLVABLE` when the shape needs real type information (it extends a
 * generic/imported type such as `ButtonHTMLAttributes<...>`, `Omit<...>`, or
 * another interface), or `null` when no such declaration exists in the file.
 */
export function findPropsMembers(file, source, typeName) {
  const sf = parseSource(file, source);
  let result = null;

  const memberNames = (members) => {
    const names = new Set();
    for (const member of members) {
      if ((ts.isPropertySignature(member) || ts.isMethodSignature(member)) && member.name) {
        names.add(propertyKeyText(sf, member.name));
      } else {
        return UNRESOLVABLE; // index/call signature, spread, etc. — not enumerable by name
      }
    }
    return names;
  };

  const walkType = (typeNode) => {
    if (!typeNode) return UNRESOLVABLE;
    if (ts.isTypeLiteralNode(typeNode)) return memberNames(typeNode.members);
    if (ts.isParenthesizedTypeNode(typeNode)) return walkType(typeNode.type);
    if (ts.isIntersectionTypeNode(typeNode) || ts.isUnionTypeNode(typeNode)) {
      const names = new Set();
      for (const part of typeNode.types) {
        const partNames = walkType(part);
        if (partNames === UNRESOLVABLE) return UNRESOLVABLE;
        for (const name of partNames) names.add(name);
      }
      return names;
    }
    // A generic/imported type reference (`Omit<...>`, `HTMLAttributes<...>`,
    // another named alias, a mapped type, ...) is opaque without a checker.
    return UNRESOLVABLE;
  };

  const visit = (node) => {
    if (result) return;
    if (ts.isTypeAliasDeclaration(node) && node.name.text === typeName) {
      result = walkType(node.type);
    } else if (ts.isInterfaceDeclaration(node) && node.name.text === typeName) {
      result = node.heritageClauses && node.heritageClauses.length > 0
        ? UNRESOLVABLE
        : memberNames(node.members);
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  return result;
}

/**
 * Every property/method name declared on ANY interface or type-literal in the
 * file — not just the Props type. Used as the softer "is this name a field of
 * some nested type in this file" signal (bucket (3) in the header comment),
 * and to seed the SPEC backtick scan's per-file vocabulary. Deliberately not
 * gated by resolvability: an unprefixed reference to a nested field is worth
 * noting even when the file also has an unrelated unresolvable Props type.
 */
export function collectFileTypeMemberNames(file, source) {
  const sf = parseSource(file, source);
  const names = new Set();
  const visit = (node) => {
    if (ts.isTypeLiteralNode(node)) {
      for (const member of node.members) {
        if ((ts.isPropertySignature(member) || ts.isMethodSignature(member)) && member.name) {
          names.add(propertyKeyText(sf, member.name));
        }
      }
    } else if (ts.isInterfaceDeclaration(node)) {
      for (const member of node.members) {
        if ((ts.isPropertySignature(member) || ts.isMethodSignature(member)) && member.name) {
          names.add(propertyKeyText(sf, member.name));
        }
      }
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  return names;
}

const VALID_IDENTIFIER = /^[A-Za-z_$][A-Za-z0-9_$]*$/;

/**
 * True once ANY "/"-joined segment of a propDocs `name` carries a dotted path
 * ("MapInfoCardRow.href / external", "overrides.renderField / renderSection").
 * The dot marks the WHOLE row as documenting fields of a nested type/object;
 * the un-dotted siblings ("external", "renderSection") are shorthand for the
 * same nested group, not standalone top-level props, so the row names no
 * top-level prop at all once any part of it is dotted.
 */
export function isNestedTypeDoc(raw) {
  return raw.split("/").some((part) => part.includes("."));
}

/**
 * Individual top-level prop-name CANDIDATES named by one propDocs row. Several
 * related props are combined with " / " ("collapsible / defaultCollapsed").
 * Anything that is not a bare identifier once split — a dotted nested-type
 * reference, a rest marker ("...props"), a wildcard ("*State"), a prose phrase
 * ("control labels") — makes no specific claim about a single top-level prop,
 * so it is left out rather than guessed at.
 */
export function splitDocumentedNames(raw) {
  if (isNestedTypeDoc(raw)) return [];
  return raw.split("/").map((part) => part.trim()).filter((part) => VALID_IDENTIFIER.test(part));
}

/**
 * Compare one component's propDocs rows against its Props type.
 *
 * `propMembers` is the result of `findPropsMembers` (a Set, `UNRESOLVABLE`, or
 * `null`). `fileTypeMembers` is the whole-file vocabulary from
 * `collectFileTypeMemberNames`, used only to soften an unmatched name that
 * turns out to be a field of some other type in the file.
 *
 * Returns `{ hard, soft, skipped }`. `skipped` is true when `propMembers`
 * cannot answer the question at all (unresolvable or not found) — the caller
 * counts this separately and it produces no violations either way.
 */
export function diffPropDocRows(docRows, propMembers, fileTypeMembers) {
  const hard = [];
  const soft = [];
  if (!propMembers || propMembers === UNRESOLVABLE) {
    return { hard, soft, skipped: true };
  }
  for (const row of docRows) {
    for (const candidate of splitDocumentedNames(row.name)) {
      if (propMembers.has(candidate)) continue;
      const entry = { candidate, raw: row.name, line: row.line };
      if (fileTypeMembers && fileTypeMembers.has(candidate)) soft.push(entry);
      else hard.push(entry);
    }
  }
  return { hard, soft, skipped: false };
}

// A backticked identifier that reads as a hook, not a prop — never flagged.
const HOOK_LIKE = /^use[A-Z]/;
// camelCase only: a bare lowercase word ("empty", "loading") is exactly the
// shape of ordinary prose and is excluded here on purpose — that class of
// error is what the propDocs comparison above exists to catch instead.
const CAMEL_CASE_IDENTIFIER = /^[a-z][a-zA-Z0-9]*$/;
const HAS_INTERNAL_UPPERCASE = /[a-z][A-Z]/;

/** Backticked camelCase identifiers in `markdown`, with their line numbers. */
export function findBacktickIdentifiers(markdown) {
  const found = [];
  const lines = markdown.split("\n");
  const pattern = /`([^`]+)`/g;
  lines.forEach((lineText, index) => {
    let match;
    pattern.lastIndex = 0;
    while ((match = pattern.exec(lineText)) !== null) {
      const token = match[1];
      if (!CAMEL_CASE_IDENTIFIER.test(token)) continue;
      if (!HAS_INTERNAL_UPPERCASE.test(token)) continue;
      if (HOOK_LIKE.test(token)) continue;
      found.push({ name: token, line: index + 1 });
    }
  });
  return found;
}

/** Backticked identifiers in a SPEC.md that match nothing in `knownIdentifiers`. */
export function findSpecBacktickDrift(markdown, knownIdentifiers) {
  return findBacktickIdentifiers(markdown).filter((candidate) => !knownIdentifiers.has(candidate.name));
}

function componentSourceCandidates(srcRoot, specPath) {
  const relPath = specPath.replace(/^\.\//, "").replace(/\.SPEC\.md$/, "");
  return [join(srcRoot, `${relPath}.tsx`), join(srcRoot, `${relPath}.ts`)];
}

function listFiles(directory) {
  if (!existsSync(directory)) return [];
  return readdirSync(directory, { withFileTypes: true }).flatMap((entry) => {
    const path = join(directory, entry.name);
    return entry.isDirectory() ? listFiles(path) : [path];
  });
}

function buildViolation({ file, id, kind, candidate, line, note }) {
  return { file, line, selector: id, property: kind, value: candidate.name ?? candidate.candidate, note };
}

function main() {
  const packageRoot = fileURLToPath(new URL("..", import.meta.url));
  const srcRoot = join(packageRoot, "src");
  const defaultBaseline = join(packageRoot, "scripts/baselines/prop-docs.json");
  const options = parseGuardArgs(process.argv.slice(2), { defaultBaseline });
  const label = baselineLabel(packageRoot, options.baseline);

  const metaFile = join(srcRoot, "catalog/metadata.ts");
  const components = extractComponentMeta(metaFile, readFileSync(metaFile, "utf8"));

  const propDocsDir = join(srcRoot, "catalog/registry/propDocs");
  let docsById = {};
  for (const entry of readdirSync(propDocsDir)) {
    if (entry === "index.ts" || !entry.endsWith(".ts")) continue;
    const file = join(propDocsDir, entry);
    Object.assign(docsById, extractPropDocEntries(file, readFileSync(file, "utf8")));
  }
  const propDocsFileRel = relative(packageRoot, propDocsDir);

  // Whole-package prop/field vocabulary, for the backtick scan's cross-component
  // exemption: a SPEC.md legitimately naming another component's real prop must
  // not be flagged just because it is not on ITS OWN type.
  const globalVocabulary = new Set();
  for (const { dir } of CATEGORY_FOLDERS) {
    for (const file of listFiles(join(srcRoot, dir))) {
      if (!/\.tsx?$/.test(file) || file.endsWith(".test.ts") || file.endsWith(".test.tsx")) continue;
      const source = readFileSync(file, "utf8");
      for (const name of collectFileTypeMemberNames(file, source)) globalVocabulary.add(name);
    }
  }

  const hard = [];
  const soft = [];
  let scanned = 0;
  let skippedNoDocs = 0;
  let skippedNoSpecPath = 0;
  let skippedUnresolvable = 0;
  let skippedNoSource = 0;

  for (const entry of components) {
    const docRows = docsById[entry.id];
    if (!docRows || docRows.length === 0) { skippedNoDocs += 1; continue; }
    if (!entry.specPath) { skippedNoSpecPath += 1; continue; }

    const [tsxPath, tsPath] = componentSourceCandidates(srcRoot, entry.specPath);
    const componentFile = existsSync(tsxPath) ? tsxPath : existsSync(tsPath) ? tsPath : null;
    if (!componentFile) { skippedNoSource += 1; continue; }
    const componentSource = readFileSync(componentFile, "utf8");
    const componentRel = relative(packageRoot, componentFile);

    const propMembers = findPropsMembers(componentFile, componentSource, `${entry.name}Props`);
    const fileTypeMembers = collectFileTypeMemberNames(componentFile, componentSource);
    const { hard: hardRows, soft: softRows, skipped } = diffPropDocRows(docRows, propMembers, fileTypeMembers);
    if (skipped) { skippedUnresolvable += 1; continue; }
    scanned += 1;

    for (const row of hardRows) {
      hard.push(buildViolation({
        file: propDocsFileRel,
        id: entry.id,
        kind: "propDocs",
        candidate: row,
        line: row.line,
        note: `propDocs names "${row.raw}"; ${componentRel} has no "${row.candidate}" prop`,
      }));
    }
    for (const row of softRows) {
      soft.push(buildViolation({
        file: propDocsFileRel,
        id: entry.id,
        kind: "propDocs",
        candidate: row,
        line: row.line,
        note: `propDocs names "${row.raw}"; "${row.candidate}" is not a top-level prop of ${entry.name}Props, `
          + `but is a field of another type declared in ${componentRel} — check whether the row needs a Type.field prefix`,
      }));
    }

    // SPEC backtick scan (bucket 4) — only where we have a spec to read.
    const specRelPath = entry.specPath.replace(/^\.\//, "");
    const specFile = join(srcRoot, specRelPath);
    if (!existsSync(specFile)) continue;
    const knownForFile = propMembers && propMembers !== UNRESOLVABLE
      ? new Set([...propMembers, ...fileTypeMembers, ...globalVocabulary])
      : new Set([...fileTypeMembers, ...globalVocabulary]);
    const specDrift = findSpecBacktickDrift(readFileSync(specFile, "utf8"), knownForFile);
    for (const candidate of specDrift) {
      soft.push(buildViolation({
        file: relative(packageRoot, specFile),
        id: entry.id,
        kind: "spec-backtick",
        candidate,
        line: candidate.line,
        note: `backticked \`${candidate.name}\` matches no prop or type field anywhere in the package`,
      }));
    }
  }

  const skipped = skippedNoDocs + skippedNoSpecPath + skippedUnresolvable + skippedNoSource;

  if (options.updateBaseline) {
    const previous = loadBaseline(options.baseline);
    writeBaseline(options.baseline, serializeBaseline("check-prop-docs", hard, { previous }));
    console.log(
      `check-prop-docs: wrote baseline of ${hard.length} violation(s) to ${label}\n`
        + `  (${scanned} component(s) checked, ${skipped} skipped: ${skippedNoDocs} with no propDocs, `
        + `${skippedNoSpecPath} with no .SPEC.md path, ${skippedUnresolvable} with an unresolvable Props type, `
        + `${skippedNoSource} with no resolvable source file)`,
    );
    return 0;
  }

  const baseline = loadBaseline(options.baseline);
  const allForIntegrity = options.strict ? [...hard, ...soft] : hard;
  const integrity = baselineIntegrityReport(baseline, allForIntegrity, { label, categories: EXEMPTION_CATEGORIES });
  if (integrity) {
    console.error(integrity);
    console.error("\ncheck-prop-docs: baseline is not accountable (see above).");
    return 1;
  }

  const hardResult = applyBaseline(hard, baseline);
  const softResult = options.strict ? applyBaseline(soft, baseline) : { fresh: soft, suppressed: [] };

  if (soft.length > 0) {
    console.warn(
      `check-prop-docs: ${soft.length} propDocs/SPEC name(s) could not be matched to a prop with full confidence.\n`
        + `  These are NOT build failures — each is a name that matches some OTHER type's field in the file, or a\n`
        + `  backticked identifier found nowhere in the package's prop/field vocabulary` + (options.strict ? "." : ", ")
        + (options.strict ? "" : "run with --strict to enforce them.\n"),
    );
    if (!options.strict) console.warn(formatViolations(soft, { indent: "  " }));
  }

  const failing = options.strict ? [...hardResult.fresh, ...softResult.fresh] : hardResult.fresh;

  if (failing.length > 0) {
    console.error(
      "\nA propDocs row (or a backticked SPEC identifier) names a prop the component does not have.\n"
        + "Either the doc is stale — fix propDocs/the SPEC to match src/components/**/*.tsx — or, if the\n"
        + "component itself is missing a prop it should have, that is a code defect, not a doc one: say so\n"
        + "rather than silently baselining it.\n",
    );
    console.error(formatViolations(failing));
    console.error(`\n${failing.length} propDocs violation(s).`);
    if (baseline) {
      console.error(`${hardResult.suppressed.length} further violation(s) suppressed by ${label}.`);
    }
    console.error("Top offending components:");
    for (const { selector, count } of topOffenders(failing)) {
      console.error(`  ${count}x ${selector}`);
    }
    return 1;
  }

  const suppressed = hardResult.suppressed.length + softResult.suppressed.length;
  console.log(
    `check-prop-docs: no new propDocs drift (${scanned} component(s) checked, ${skipped} skipped for lack of a `
      + `resolvable Props type or source file)` + (suppressed > 0 ? `; ${suppressed} known violation(s) held by the baseline.` : ".")
      + (soft.length > 0 && !options.strict ? ` ${soft.length} name(s) listed above for review.` : ""),
  );
  return 0;
}

/**
 * The only exemption this guard grants a baseline entry: it is PRE-EXISTING
 * drift the new gate uncovered across the package, not one of the five SPEC
 * defects uif/issue-4674 fixed directly. Naming this category is what stops
 * the five from being quietly baselined instead of corrected — a reason has
 * to say "pre-existing", which none of the five's own fixes are.
 */
export const EXEMPTION_CATEGORIES = [
  {
    label: "pre-existing propDocs drift found by this gate, not one of the five uif/issue-4674 fixed directly",
    pattern: /pre-existing/i,
  },
];

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main());
}
