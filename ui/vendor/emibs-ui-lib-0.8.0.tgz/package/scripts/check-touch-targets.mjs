import { join } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { matchingParen, parseCss, readCssSources, splitArguments, splitSelectorList } from "./css-source.mjs";
import {
  applyBaseline,
  baselineIntegrityReport,
  baselineLabel,
  formatViolations,
  loadBaseline,
  parseGuardArgs,
  serializeBaseline,
  topOffenders,
  writeBaseline,
} from "./guard-baseline.mjs";

// `--control-min-height: 44px` is already declared by every packaged theme
// (src/theme/tokens.ts, foundationalTokens) — it is the library's own stated
// minimum interactive target — yet the whole stylesheet uses it exactly once.
// Everywhere else, controls are sized with hardcoded px values, most of them
// below 44. This guard finds those.
//
// Deliberately conservative: a false positive here is busywork for whoever
// burns the backlog down, so a selector only fails the build when it is
// unambiguously an interactive control. Anything suggestive but not certain is
// listed separately as "review" and never fails.

// Every property that can pin a control's box small enough to miss the target,
// in BOTH the physical and the logical axis vocabulary.
//
// The guard used to read four physical properties only, which meant it could
// not see `src/components/primitives/materialControls.css` at all — the
// stylesheet that sizes the entire Button/Menu/Breadcrumb/Tooltip family with
// `min-block-size`. A whole primitive family was outside the a11y gate while
// the contract claimed to govern it (TOUCH-TARGETS rule 2).
//
// `max-*` counts too: a cap below the floor is as small as a floor below it.
const SIZE_PROPERTIES = new Set([
  "height",
  "width",
  "min-height",
  "min-width",
  "max-height",
  "max-width",
  "block-size",
  "inline-size",
  "min-block-size",
  "min-inline-size",
  "max-block-size",
  "max-inline-size",
]);
const MINIMUM_TARGET_PX = 44;
// WCAG 2.2 SC 2.5.8. Below this a control is a defect in every density; see
// TOUCH-TARGETS.md rule 1.
const ABSOLUTE_FLOOR_PX = 24;
// `rem` resolves against the root font size, which this library never changes
// (no `html { font-size }` anywhere), so the CSS initial 16px is the real value.
// `em` resolves against the element's own font-size, which a static guard cannot
// know; 16px is the inherited default and the OPTIMISTIC reading, so an `em`
// value the guard passes may still be too small — never the other way round.
const ROOT_FONT_SIZE_PX = 16;

// Interactive HTML elements, matched as bare type selectors.
const INTERACTIVE_ELEMENTS = new Set(["button", "input", "select", "textarea", "a", "summary"]);

// ARIA roles that make an element a control regardless of its tag.
const INTERACTIVE_ROLES = new Set([
  "button",
  "checkbox",
  "combobox",
  "link",
  "menuitem",
  "menuitemcheckbox",
  "menuitemradio",
  "option",
  "radio",
  "searchbox",
  "slider",
  "spinbutton",
  "switch",
  "tab",
  "textbox",
  "treeitem",
]);

// BEM element names (the `__name` part) that always denote a control. Grounded
// in the real vocabulary of src/styles.css + src/explorer/explorer.css rather
// than guessed: every one of these appears on a rule that also carries
// `cursor: pointer` and/or `border`/`background` button styling.
const CONTROL_ELEMENT_NAMES = new Set([
  "action",
  "apply",
  "back",
  "button",
  "cancel",
  "clear",
  "close",
  "collapse",
  "copy",
  "delete",
  "dismiss",
  "edit",
  "expand",
  "input",
  "item-link",
  "launcher",
  "link",
  "nav-link",
  "next",
  "prev",
  "previous",
  "remove",
  "reset",
  "retry",
  "reveal",
  "share",
  "submit",
  "tab",
  "textarea",
  "toggle",
  "trigger",
]);

// Block-level class names (no `__`) whose trailing word marks them a control,
// e.g. `.ui-icon-button`, `.ui-theme-mode-toggle`, `.ui-notification-bell`,
// `.ui-password-reveal-button`, `.xpl-toolbar-link`, `.xpl-compare-open`.
const CONTROL_BLOCK_SUFFIXES = new Set([
  "bell",
  "button",
  "clear",
  "close",
  "launcher",
  "link",
  "open",
  "tab",
  "toggle",
  "trigger",
]);

// Suggestive but not conclusive — clickable in some compositions and inert in
// others. These go to the review list, unless the same element is proved
// clickable elsewhere in the stylesheet (see `cursor: pointer` evidence below).
const AMBIGUOUS_ELEMENT_NAMES = new Set([
  "box",
  "cell",
  "chip",
  "control",
  "entry",
  "field",
  "item",
  "mode",
  "option",
  "row",
  "search",
  "switch",
  "tag",
  "target",
]);

// Non-interactive decoration. Matched against the LAST hyphen-separated word of
// the BEM element name, so `__tab-badge` is a badge (not a tab) and
// `__toggle-track` is a track (not a toggle) — those two would otherwise be the
// guard's most obvious false positives.
//
// This vocabulary is the SANCTIONED way to retire a rule-7 name (TOUCH-TARGETS
// rule 7: "Non-interactive decoration stays small"), and it is deliberately
// preferred over a per-entry baseline for those: a baseline entry is a recorded
// EXCEPTION to the contract, and a status dot or a count pill is not an
// exception — it was never a target in the first place. Baselining decoration
// would file it under one of the three exemption categories and quietly claim a
// tradeoff nobody made.
//
// Adding a word here is safe by construction, because the decoration check runs
// LAST: `cursor: pointer` on the rule, a known control name, an interactive tag
// and an interactive ARIA role all outrank it (see `classifyCompound`), and a
// decoration name that is proved clickable by some other rule still surfaces as
// `review` rather than silence. A word must still be justified by reading the
// markup of every selector it retires — the list below records that reading for
// the words added by uif/issue-4796, each verified in the component that
// renders it:
//
//   chrome      .xpl-mockup-frame__chrome            <div aria-hidden> title bar
//   cluster     .ui-map-marker-pin__cluster          <span aria-hidden> count bubble
//   count       .ui-facet-filter__count,             <span>{count}</span>
//               .ui-discovery-cloud__item-count      (rule 7 names "count pills")
//   device      .ui-account-sessions__device         <span aria-hidden> device icon
//   error       .ui-*__error (7 panels)              <div role="alert"> message band
//   eyebrow     .ui-editorial-listing__eyebrow,      <span> kicker text
//               .ui-public-profile__eyebrow
//   handle      .ui-mobile-sheet__handle             <div aria-hidden> drag handle
//                                                    (rule 7 names "drag handles")
//   index       .ui-workflow-map__stage-index        <span aria-hidden>{index}
//   key         .ui-keyboard-hint__key, .ui-kbd__key <span aria-hidden> inside <kbd>
//   kind        .ui-file-action-list__kind           <span aria-hidden> type icon
//   leading     .ui-page-header__leading,            <div> slot that HOLDS a
//               .ui-resource-index__leading,         consumer icon/avatar; the slot
//               .ui-relationship-picker__leading     itself has no handler
//   pill        .xpl-coverage-pill,                  <span> status/count pill
//               .ui-activity-center__unread-pill     (rule 7 names "count pills")
//   prompt      .ui-command-console__input-prompt    <span aria-hidden> "›" glyph
//   radius      .xpl-found__radius                   <span aria-hidden> shape preview
//   required    .ui-field__required                  <span> required/optional marker
//   requirement .ui-form-requirement                 same element, block-level class
//   signal      .ui-status-strip__signal             <div> wrapping a signal dot
//                                                    (rule 7 names "signal dots")
//   status      .ui-identity-avatar__status          <span aria-hidden> presence dot
//
// `handle` and `pill` MOVED here from AMBIGUOUS_ELEMENT_NAMES: rule 7 names
// drag handles and count pills as decoration outright, so "ambiguous" was
// understating what the contract already decides. A clickable pill is still
// caught — by `cursor: pointer`, not by its name.
const DECORATION_WORDS = new Set([
  "arrow",
  "avatar",
  "backdrop",
  "badge",
  "bar",
  "bars",
  "canvas",
  "caret",
  "chevron",
  "chrome",
  "cluster",
  "count",
  "decoration",
  "device",
  "divider",
  "dot",
  "error",
  "eyebrow",
  "flag",
  "glyph",
  "graphic",
  "handle",
  "icon",
  "illustration",
  "image",
  "img",
  "index",
  "indicator",
  "key",
  "kind",
  "leading",
  "line",
  "logo",
  "mark",
  "marker",
  "media",
  "meter",
  "pill",
  "pin",
  "preview",
  "progress",
  "prompt",
  "radius",
  "rail",
  "required",
  "requirement",
  "ring",
  "rule",
  "separator",
  "signal",
  "skeleton",
  "spinner",
  "sr",
  "stage",
  "status",
  "swatch",
  "thumb",
  "thumbnail",
  "tick",
  "track",
  "visual",
]);

// ---------------------------------------------------------------------------
// Sizing through the theme (TOUCH-TARGETS rules 2 and 3).
//
// `--control-min-height` IS the 44px standard, so a declaration that references
// it is compliant by construction.
//
// A `--density-*` token is a different claim: it says "this control is
// deliberately dense", which is a legitimate tier (rule 3) but NOT compliance
// with the standard, and it is still bound by the 24px floor (rule 1). The old
// check conflated the two, and did it per BLOCK rather than per DECLARATION, so
// a single `padding: var(--density-padding-x)` exempted every hardcoded size in
// the same rule:
//
//     .probe { padding: var(--density-padding-x); min-height: 20px }  /* passed */
//
// Worse, `--density-control-height` is written ONLY as an inline style by
// src/theme/DensityScope.tsx and is defined in no stylesheet, so
// `min-height: var(--density-control-height)` outside a <DensityScope> resolves
// to nothing at all — no floor whatsoever — while still buying the exemption.
// Those go to review now rather than passing silently.
// ---------------------------------------------------------------------------
const CONTROL_HEIGHT_TOKEN = /var\(\s*--control-min-height[\s,)]/;
const DENSITY_TOKEN = /var\(\s*--density-/;

// Length tokens the guard resolves without reading a stylesheet: the density
// scale (src/theme/tokens.ts `densityTokens`) plus the standard itself. These
// are foundational tokens — a curated theme overrides colours, not the scale —
// so their values are the same in every packaged theme.
export const THEME_LENGTH_TOKENS = {
  "--control-min-height": 44,
  "--density-control-height-comfortable": 44,
  "--density-control-height-compact": 32,
  "--density-row-height-comfortable": 40,
  "--density-row-height-compact": 30,
};

/**
 * Every `--token: <length>` the stylesheets define at a document-root scope,
 * merged over the built-in table above. This is what makes
 * `calc(var(--space-6) + var(--space-2))` a number the guard can judge: the
 * `:root` block in src/styles.css declares `--space-6: 32px`.
 */
export function collectLengthTokens(sources) {
  const tokens = { ...THEME_LENGTH_TOKENS };
  for (const { file, source } of sources) {
    for (const block of parseCss(source, file).blocks) {
      if (!block.selectors.some((selector) => /^(?::root|:host(?:\([^)]*\))?|html)(?:\.[\w-]+)*$/.test(selector))) {
        continue;
      }
      for (const declaration of block.declarations) {
        if (!declaration.property.startsWith("--")) continue;
        const px = resolveLengthPx(declaration.value, {});
        if (typeof px === "number") tokens[declaration.property] = px;
      }
    }
  }
  return tokens;
}

/** Numeric value of a `<number><unit>` term, or `null` when it is not a length. */
function unitLength(term) {
  const match = /^([+-]?(?:\d+\.?\d*|\.\d+))(px|rem|em|)$/i.exec(term);
  if (!match) return null;
  const number = Number(match[1]);
  const unit = match[2].toLowerCase();
  if (unit === "") return number === 0 ? 0 : null; // a bare number is only a length at 0
  if (unit === "px") return number;
  return number * ROOT_FONT_SIZE_PX; // rem and em, see ROOT_FONT_SIZE_PX
}

/**
 * Resolve a CSS length expression to CSS px.
 *
 * Returns a number when the value is statically resolvable, the string
 * `"unresolved"` when it IS a size expression the guard cannot pin down (an
 * unknown token, a viewport unit, arithmetic it does not model) — which is a
 * review case, not a pass — and `null` when the value is not a fixed length at
 * all (`auto`, `100%`, `max-content`, `inherit`), which is genuinely nothing
 * for this guard to measure.
 *
 * `clamp(a, b, c)` resolves to `a` and `min(…)` to its smallest term: for a
 * floor check the only honest reading is the smallest value the expression can
 * produce. `max(…)` resolves to its largest, for the same reason.
 */
export function resolveLengthPx(value, tokens = THEME_LENGTH_TOKENS) {
  const text = value.replace(/\s*!important\s*$/i, "").trim();
  if (text === "") return null;
  // Not a length: keyword sizes and host-relative percentages have no fixed
  // value, and a control legitimately sized `100%` of a sized host is not a
  // hardcoded number. Documented as out of scope rather than silently passing.
  if (/^(?:auto|none|inherit|initial|unset|revert|revert-layer|fit-content|max-content|min-content|stretch)$/i.test(text)) {
    return null;
  }
  const resolved = resolveTerm(text, tokens, 0);
  if (typeof resolved === "number") return resolved;
  if (resolved === NOT_A_LENGTH) return null;
  // Host- or viewport-relative and therefore not a declared fixed size — the
  // same category as a bare `100%`, and out of this guard's scope for the same
  // reason: `min(100%, 1120px)` and `calc(100vh - 24px)` describe a layout box
  // against its container, not a control against the target standard. Recorded
  // as a documented limit in TOUCH-TARGETS.md rather than pretended away.
  // Checked only AFTER resolution, so `clamp(20px, 5vw, 60px)` still yields its
  // statically-known 20px floor.
  if (RELATIVE_UNIT.test(text)) return null;
  return "unresolved";
}

// A percentage or any viewport-/container-/font-relative unit.
const RELATIVE_UNIT = /[\d.]\s*(?:%|[dsl]?v(?:w|h|i|b|min|max)|ch|ex|cq[a-z]+)(?![\w-])/i;

const NOT_A_LENGTH = Symbol("not-a-length");

function resolveTerm(text, tokens, depth) {
  const term = text.trim();
  if (term === "" || depth > 12) return "unresolved";

  // A unitless `0` is the CSS initial value written out; it is not a size
  // somebody chose. `min-width: 0` in particular is the flex/grid overflow
  // idiom, appearing hundreds of times, and it REMOVES a minimum rather than
  // imposing one.
  if (/^[+-]?0+(?:\.0+)?$/.test(term)) return NOT_A_LENGTH;

  const direct = unitLength(term);
  if (direct !== null) return direct;

  const functionMatch = /^([\w-]+)\s*\(/.exec(term);
  if (functionMatch && matchingParen(term, term.indexOf("(")) === term.length - 1) {
    const name = functionMatch[1].toLowerCase();
    const inner = term.slice(term.indexOf("(") + 1, -1);
    if (name === "var") return resolveVar(inner, tokens, depth);
    if (name === "calc") return evaluateCalc(inner, tokens, depth);
    // These resolve to the LOWER BOUND of what the expression can produce —
    // the only reading a floor check may use.
    if (name === "clamp" || name === "min" || name === "max") {
      const parts = splitArguments(inner).map((part) => resolveTerm(part, tokens, depth + 1));
      // clamp(min, preferred, max) is guaranteed to be at least its first
      // argument, whatever the other two are (`5vw` and friends included).
      if (name === "clamp") return typeof parts[0] === "number" ? parts[0] : "unresolved";
      // max() is at least its largest resolvable term; an unresolvable term can
      // only push it higher.
      if (name === "max") {
        const known = parts.filter((part) => typeof part === "number");
        return known.length > 0 ? Math.max(...known) : "unresolved";
      }
      // min() needs every term: an unresolvable one could be the smallest.
      if (parts.some((part) => typeof part !== "number")) return "unresolved";
      return Math.min(...parts);
    }
    return "unresolved";
  }

  // Anything else that still looks like a size expression (a bare unknown unit,
  // `1lh`, a nested space-separated shorthand) is unresolved, not absent.
  if (/\d/.test(term) || term.includes("var(")) return "unresolved";
  return NOT_A_LENGTH;
}

function resolveVar(inner, tokens, depth) {
  const args = splitArguments(inner);
  const name = args[0].trim();
  if (Object.prototype.hasOwnProperty.call(tokens, name)) return tokens[name];
  if (args.length > 1) {
    const fallback = resolveTerm(args.slice(1).join(",").trim(), tokens, depth + 1);
    // A fallback IS the value whenever the token is undefined, which for
    // `--density-control-height` (inline-style only) is every context outside a
    // <DensityScope>. So the fallback is the number to judge.
    if (fallback !== NOT_A_LENGTH) return fallback;
  }
  return "unresolved";
}

/** `calc()` over `+ - * /` with resolvable operands; anything else is unresolved. */
function evaluateCalc(expression, tokens, depth) {
  const tokensOut = [];
  let i = 0;
  while (i < expression.length) {
    const char = expression[i];
    if (/\s/.test(char)) {
      i += 1;
      continue;
    }
    if (char === "(") {
      const close = matchingParen(expression, i);
      const value = evaluateCalc(expression.slice(i + 1, close), tokens, depth + 1);
      if (value === "unresolved" || value === NOT_A_LENGTH) return "unresolved";
      tokensOut.push(value);
      i = close + 1;
      continue;
    }
    if ("+-*/".includes(char)) {
      // A leading sign belongs to the number, not to the expression.
      const previous = tokensOut[tokensOut.length - 1];
      if ((char === "+" || char === "-") && (tokensOut.length === 0 || typeof previous === "string")) {
        // fall through to the term reader below
      } else {
        tokensOut.push(char);
        i += 1;
        continue;
      }
    }
    // Read one term: up to the next top-level operator surrounded by space, or
    // the end. CSS requires whitespace around + and -, so this is well defined.
    let j = i;
    let depthParen = 0;
    while (j < expression.length) {
      const c = expression[j];
      if (c === "(") depthParen += 1;
      else if (c === ")") depthParen -= 1;
      else if (depthParen === 0 && /\s/.test(c)) break;
      else if (depthParen === 0 && (c === "*" || c === "/") && j > i) break;
      j += 1;
    }
    const raw = expression.slice(i, j);
    // Inside calc(), a bare number is a valid multiplier (`calc(var(--space-6) * 8)`).
    const value = /^[+-]?(?:\d+\.?\d*|\.\d+)$/.test(raw.trim())
      ? Number(raw.trim())
      : resolveTerm(raw, tokens, depth + 1);
    if (typeof value !== "number") return "unresolved";
    tokensOut.push(value);
    i = j;
  }

  if (tokensOut.length === 0) return "unresolved";
  // Two passes: * and / first, then + and -.
  const multiplied = [tokensOut[0]];
  for (let k = 1; k < tokensOut.length; k += 2) {
    const operator = tokensOut[k];
    const operand = tokensOut[k + 1];
    if (typeof operand !== "number" || typeof operator !== "string") return "unresolved";
    if (operator === "*") multiplied.push(multiplied.pop() * operand);
    else if (operator === "/") multiplied.push(multiplied.pop() / operand);
    else multiplied.push(operator, operand);
  }
  let total = multiplied[0];
  if (typeof total !== "number") return "unresolved";
  for (let k = 1; k < multiplied.length; k += 2) {
    const operator = multiplied[k];
    const operand = multiplied[k + 1];
    if (typeof operand !== "number") return "unresolved";
    if (operator === "+") total += operand;
    else if (operator === "-") total -= operand;
    else return "unresolved";
  }
  return Number.isFinite(total) ? total : "unresolved";
}

/** Split a complex selector into compounds, ignoring combinators inside `(`/`[`. */
export function lastCompound(selector) {
  let depth = 0;
  let current = "";
  let last = "";
  for (const char of selector) {
    if (char === "(" || char === "[") depth += 1;
    if (char === ")" || char === "]") depth = Math.max(0, depth - 1);
    if (depth === 0 && /[\s>+~]/.test(char)) {
      if (current.trim()) last = current.trim();
      current = "";
      continue;
    }
    current += char;
  }
  return (current.trim() || last).trim();
}

/** Break a compound into the parts the interactivity rules care about. */
export function describeCompound(compound) {
  const classes = [...compound.matchAll(/\.((?:[\w-]|\\.)+)/g)].map((match) => match[1]);
  const attributes = [...compound.matchAll(/\[([^\]]*)\]/g)].map((match) => match[1]);
  const pseudoElement = /::[\w-]+/.test(compound);
  const element = (/^([a-zA-Z][\w-]*)/.exec(compound)?.[1] ?? "").toLowerCase();
  const roles = attributes
    .map((attribute) => /^role\s*[~|^$*]?=\s*["']?([\w-]+)/.exec(attribute)?.[1])
    .filter(Boolean)
    .map((role) => role.toLowerCase());
  const inputTypes = attributes
    .map((attribute) => /^type\s*[~|^$*]?=\s*["']?([\w-]+)/.exec(attribute)?.[1])
    .filter(Boolean)
    .map((type) => type.toLowerCase());
  // State/utility classes describe a variant, not the thing itself.
  const structural = classes.filter((name) => !/^(?:is|has)-/.test(name));
  const base = structural.find((name) => name.includes("__")) ?? structural[0] ?? "";
  return { compound, classes, structural, base, element, roles, inputTypes, pseudoElement };
}

/**
 * Stable identity of "the element this rule sizes", so evidence found on one
 * rule (`.ui-account-menu__item { cursor: pointer }`) can be applied to another
 * rule for the same element (`.ui-account-menu--compact .ui-account-menu__item
 * { min-height: 38px }`). Only class-based selectors get a signature: a bare
 * `span` or `div` is not one element, and treating it as one would let a single
 * clickable span mark every span in the stylesheet interactive.
 */
export function elementSignature(compound) {
  const { base } = describeCompound(compound);
  if (!base) return "";
  // Drop the BEM modifier so `--compact` variants share their block's identity.
  return base.replace(/--[\w-]+$/, "");
}

/** The `__name` of a BEM class, or "" for a block-level class. */
function bemElementName(base) {
  const index = base.indexOf("__");
  if (index < 0) return "";
  return base.slice(index + 2).replace(/--[\w-]+$/, "");
}

function lastWord(name) {
  const parts = name.split("-").filter(Boolean);
  return parts[parts.length - 1] ?? "";
}

/**
 * The visually-hidden pattern: a 1x1 clipped/transparent box that exists only
 * for assistive tech. It is 1px BY DESIGN — enlarging it would put a real
 * clickable box on screen, so it must never be flagged.
 */
export function isVisuallyHidden(block) {
  const values = new Map();
  for (const declaration of block.declarations) values.set(declaration.property, declaration.value.toLowerCase());
  const position = values.get("position");
  if (position !== "absolute" && position !== "fixed") return false;
  if (values.has("clip") || values.has("clip-path")) return true;
  if (values.get("opacity") === "0") return true;
  if (values.get("pointer-events") === "none") return true;
  // The off-screen variant, e.g. `left: -10000px`.
  for (const side of ["left", "right", "top", "bottom"]) {
    const offset = values.get(side);
    if (offset && /^-\d{4,}px$/.test(offset)) return true;
  }
  return false;
}

/**
 * Native checkbox/radio glyphs. `input[type=checkbox] { width: 16px }` is the
 * browser's own control size, and the accessible target is normally the
 * wrapping label — enlarging the box is rarely the right fix, so this is a
 * judgement call for a human, not a build failure.
 */
function isNativeCheckOrRadio(parts, block) {
  if (parts.inputTypes.some((type) => type === "checkbox" || type === "radio")) return true;
  return block.declarations.some((declaration) => declaration.property === "accent-color");
}

/** Does THIS rule declare `cursor: pointer`? The strongest evidence there is. */
function declaresPointer(block) {
  return block.declarations.some(
    (declaration) => declaration.property === "cursor" && declaration.value.toLowerCase() === "pointer",
  );
}

/**
 * `hard` | `review` | `null`, plus why. Evaluated on ONE compound selector.
 *
 * ORDER MATTERS, and it used to be wrong in two ways:
 *
 *   1. The decoration check ran FIRST, ahead of the control-name check and
 *      ahead of the `cursor: pointer` evidence. So renaming `__close` to
 *      `__close-icon` retired a control from the guard entirely — even with
 *      `cursor: pointer` declared on the very same rule. A name is a guess;
 *      `cursor: pointer` on the rule is the stylesheet stating the element is
 *      clickable, and a guess must never outrank a statement.
 *   2. An unrecognised name fell out of the bottom as `null` — SILENCE. The
 *      review bucket exists precisely so the guard can say "I don't know"; a
 *      silent default meant every name outside the three hand-written lists
 *      disappeared, and the lists were built from today's vocabulary. Unknown
 *      now means review.
 *
 * Evidence found on ANOTHER rule for the same element (`proved`) is weaker than
 * evidence on this one, so it still loses to a decoration name — that is the
 * `.ui-card__pin` case, and it stays a review rather than a failure.
 */
function classifyCompound(compound, block, clickable) {
  const parts = describeCompound(compound);

  // A pseudo-element is generated decoration (a checkmark, a rule, a dot); it
  // is never the hit target itself.
  if (parts.pseudoElement) return null;

  const signature = elementSignature(compound);
  const proved = signature !== "" && clickable.has(signature);
  const pointerHere = declaresPointer(block);
  const bem = bemElementName(parts.base);
  // Block-level class: judge the block name with its modifier removed, so a
  // state variant such as `.ui-drawer--open` is not read as an "open" button.
  const blockName = parts.base.replace(/--[\w-]+$/, "");
  // The name this rule is judged by. The decoration and ambiguity vocabularies
  // used to be consulted for BEM element names only, which left every
  // block-level name (`.ui-signal-dot`, `.ui-skeleton`, `.ui-meter`) outside
  // them — harmless while unknown names were silent, but nonsense once unknown
  // means review. They are read the same way on both: by the LAST hyphenated
  // word, so `.ui-tab-badge` is a badge and `.ui-toggle-track` is a track.
  const judgedName = bem !== "" ? bem : blockName;
  const decorative = judgedName !== "" && DECORATION_WORDS.has(lastWord(judgedName));

  // Native checkbox/radio first: `input` is an interactive element, but rule 5
  // of the contract says the glyph keeps its size and the label carries the
  // target, so this is a human call whatever else matches.
  if (isNativeCheckOrRadio(parts, block)) {
    return { verdict: "review", note: "native checkbox/radio glyph; the label is usually the target" };
  }

  // --- positive evidence, in descending strength ---------------------------
  if (bem !== "" && CONTROL_ELEMENT_NAMES.has(bem)) return { verdict: "hard", note: `__${bem}` };
  if (bem === "" && blockName && CONTROL_BLOCK_SUFFIXES.has(lastWord(blockName))) {
    return { verdict: "hard", note: `.${blockName}` };
  }
  if (pointerHere) return { verdict: "hard", note: "cursor: pointer on this rule" };
  if (INTERACTIVE_ELEMENTS.has(parts.element)) return { verdict: "hard", note: `<${parts.element}>` };
  if (parts.roles.some((role) => INTERACTIVE_ROLES.has(role))) {
    return { verdict: "hard", note: `[role="${parts.roles[0]}"]` };
  }

  // --- names, which only decide what is left --------------------------------
  if (decorative) {
    // Decoration that is proved clickable by some OTHER rule is worth a human
    // look (e.g. `.ui-card__pin` really may be a pin BUTTON), but never a build
    // failure — the overwhelming majority of these are icons and dots inside an
    // already-sized control.
    return proved ? { verdict: "review", note: `${judgedName}: decoration, but styled clickable elsewhere` } : null;
  }
  if (proved) return { verdict: "hard", note: "styled with cursor: pointer elsewhere" };
  if (judgedName !== "" && AMBIGUOUS_ELEMENT_NAMES.has(lastWord(judgedName))) {
    return { verdict: "review", note: `${judgedName}: clickable only in some compositions` };
  }

  // Unknown, but named. Not silence: the guard's vocabulary lists were written
  // from the stylesheet as it stood, and a name they do not contain is a name
  // nobody has classified — which is the definition of the review bucket.
  //
  // A selector with no structural class at all (a bare `span`, `div`, `li`) is
  // the one exception: there is no identity to classify, and reporting every
  // sized bare element would drown the bucket it is meant to keep readable.
  if (parts.base !== "") {
    return { verdict: "review", note: `${parts.base}: unclassified name — decide whether this is a control` };
  }
  return null;
}

const RANK = { hard: 2, review: 1 };

/** The strongest verdict across a selector list (`.a, .b` shares one rule). */
export function classifySelector(prelude, block, clickable) {
  let best = null;
  for (const selector of splitSelectorList(prelude)) {
    const result = classifyCompound(lastCompound(selector), block, clickable);
    if (!result) continue;
    if (!best || RANK[result.verdict] > RANK[best.verdict]) best = result;
  }
  return best;
}

/**
 * Every element the stylesheet itself styles as clickable. This is the
 * grounding signal: rather than guessing which BEM names are buttons, ask the
 * stylesheet which elements it gives `cursor: pointer`.
 */
export function collectClickableElements(sources) {
  const clickable = new Set();
  for (const { file, source } of sources) {
    for (const block of parseCss(source, file).blocks) {
      const pointer = block.declarations.some(
        (declaration) => declaration.property === "cursor" && declaration.value.toLowerCase() === "pointer",
      );
      if (!pointer) continue;
      for (const selector of block.selectors) {
        const signature = elementSignature(lastCompound(selector));
        if (signature) clickable.add(signature);
      }
    }
  }
  return clickable;
}

/**
 * What ONE size declaration says about the control's size, judged on its own —
 * never on its neighbours in the same block.
 *
 * Returns `null` when the declaration is fine or is nothing to measure, or
 * `{ verdict, px, note }` where `verdict` is `"hard"` (a real undersize, subject
 * to the selector still proving the element interactive) or `"review"`.
 */
export function judgeSizeDeclaration(declaration, tokens) {
  const value = declaration.value;

  // Rule 2: `var(--control-min-height)` IS the standard. Nothing to judge.
  if (CONTROL_HEIGHT_TOKEN.test(value)) return null;

  const resolved = resolveLengthPx(value, tokens);
  if (resolved === null) return null; // `auto`, `100%`, `max-content`: no fixed size
  // `min-height: 0` declares NO floor rather than a small one — it is how a
  // flex/grid child is allowed to shrink. Not a size decision to police.
  if (resolved === 0 && declaration.property.startsWith("min-")) return null;

  const density = DENSITY_TOKEN.test(value);

  if (resolved === "unresolved") {
    // A size expression the guard cannot pin down. It is NOT compliant, it is
    // unknown — and unknown belongs in review, never in silence.
    return {
      verdict: "review",
      px: null,
      note: density
        ? "sized by an undefined --density-* token: outside a <DensityScope> this resolves to nothing, so there is no floor at all"
        : "size expression the guard cannot resolve statically — check it by hand",
    };
  }

  // Rule 1 outranks everything, density included.
  if (resolved < ABSOLUTE_FLOOR_PX) {
    return {
      verdict: "hard",
      px: resolved,
      note: density
        ? `density token resolves to ${resolved}px, below the ${ABSOLUTE_FLOOR_PX}px floor`
        : null,
    };
  }

  // Rule 3: a density token between the floor and the standard is an accepted
  // dense tier. Accepted — but recorded as DENSE, not as "meets the standard":
  // `--density-control-height-compact` is 32px, and the old block-level
  // exemption was quietly blessing it as compliant with a 44px contract.
  if (density) return null;

  if (resolved < MINIMUM_TARGET_PX) return { verdict: "hard", px: resolved, note: null };
  return null;
}

export function findTouchTargetViolations(file, source, clickable, tokens = THEME_LENGTH_TOKENS) {
  const { declarations } = parseCss(source, file);
  const hard = [];
  const review = [];

  for (const declaration of declarations) {
    if (!SIZE_PROPERTIES.has(declaration.property)) continue;

    const block = declaration.block;
    // An animation frame is not a control's resting size.
    if (block.atRuleNames.includes("keyframes") || block.atRuleNames.includes("-webkit-keyframes")) continue;
    if (isVisuallyHidden(block)) continue;

    const size = judgeSizeDeclaration(declaration, tokens);
    if (!size) continue;

    const result = classifySelector(block.prelude, block, clickable);
    if (!result) continue;

    // The weaker of the two verdicts wins: an unresolvable size on a proven
    // control is still only "somebody look at this", and an ambiguous selector
    // never becomes a build failure however small the number is.
    const verdict = size.verdict === "hard" && result.verdict === "hard" ? "hard" : "review";
    const note = size.note ? `${result.note}; ${size.note}` : result.note;

    const violation = {
      file,
      line: declaration.line,
      selector: declaration.selector,
      property: declaration.property,
      value: declaration.value,
      px: size.px,
      note,
    };
    (verdict === "hard" ? hard : review).push(violation);
  }

  return { hard, review };
}

export function collectTouchTargetViolations(sources) {
  const clickable = collectClickableElements(sources);
  const tokens = collectLengthTokens(sources);
  const hard = [];
  const review = [];
  for (const { file, source } of sources) {
    const result = findTouchTargetViolations(file, source, clickable, tokens);
    hard.push(...result.hard);
    review.push(...result.review);
  }
  return { hard, review, clickable, tokens };
}

/**
 * The three exemptions this guard grants, exactly as TOUCH-TARGETS.md names
 * them. A baseline reason must claim one of them in so many words — that is
 * what turns "somebody typed 31 characters" into "somebody stated which
 * declared exemption applies", and it makes inventing a fourth category
 * visible in review instead of invisible in a JSON file.
 */
export const EXEMPTION_CATEGORIES = [
  { label: "declared dense variant (rule 3)", pattern: /declared\s+dense|dense\s+variant|dense\s+tier/i },
  { label: "nested host-bounded affordance (rule 6)", pattern: /host-bounded|nested\s+host|bounded\s+by\s+(?:its|the)\s+host/i },
  { label: "guard artifact (the rule does not size the control the guard matched)", pattern: /guard\s+artifact/i },
];

/**
 * The ONE thing a baseline entry below the absolute floor may be.
 *
 * Rule 1 says anything under 24px is a defect, fixed unconditionally, with no
 * baseline entry — and rule 1 outranks every other rule. Rule 5 is not an
 * exception to that, because the 16-18px thing it protects is not the target:
 * the target is the wrapping <label>, and the glyph is what the guard matched
 * INSTEAD of the target. So the only honest sub-floor entry is one that says so
 * — it must claim the guard-artifact category AND identify the element as a
 * checkbox/radio glyph under rule 5.
 *
 * Without this, "no baseline entry is below the floor" is a claim somebody
 * makes in a PR description once. With it, it is a build failure.
 */
const GLYPH_EXEMPTION = {
  label: 'a checkbox/radio glyph under rule 5 ("rule 5" plus glyph/checkbox/radio)',
  matches: (text) => /rule\s*5/i.test(text) && /glyph|checkbox|radio/i.test(text),
};

/** `{ property, value }` of a baseline key, or null when it is not shaped like one. */
export function parseBaselineKey(key) {
  const parts = key.split(" :: ");
  if (parts.length < 4) return null;
  return { property: parts[parts.length - 2], value: parts[parts.length - 1] };
}

/**
 * Baseline entries that record a size below the absolute floor without claiming
 * the one exemption that may sit there, rendered as a failure report — or null
 * when every sub-floor entry is accounted for.
 */
export function subFloorBaselineReport(baseline, tokens, { label = "(none)" } = {}) {
  if (!baseline || !baseline.entries) return null;
  const reasons = baseline.reasons ?? {};
  const offenders = [];
  for (const key of Object.keys(baseline.entries).sort()) {
    const parsed = parseBaselineKey(key);
    if (!parsed || !SIZE_PROPERTIES.has(parsed.property)) continue;
    const px = resolveLengthPx(parsed.value, tokens);
    if (typeof px !== "number" || px >= ABSOLUTE_FLOOR_PX) continue;
    if (px === 0 && parsed.property.startsWith("min-")) continue;
    const reason = reasons[key];
    if (typeof reason === "string" && GLYPH_EXEMPTION.matches(reason)) continue;
    offenders.push({ key, px });
  }
  if (offenders.length === 0) return null;
  const lines = [
    `\n${offenders.length} baseline entry/entries in ${label} record a size below the ` +
      `${ABSOLUTE_FLOOR_PX}px floor.\nTOUCH-TARGETS rule 1 is absolute: below the floor is a defect, fixed in source, ` +
      "never baselined.\nThe one thing that may sit here is " +
      `${GLYPH_EXEMPTION.label} — the guard matched the\nglyph instead of the wrapping <label> that carries the ` +
      "target — and these do not say so:\n",
  ];
  for (const { key, px } of offenders) lines.push(`  - ${key}\n      resolves to ${px}px`);
  return lines.join("\n");
}

function main() {
  const packageRoot = fileURLToPath(new URL("..", import.meta.url));
  const defaultBaseline = join(packageRoot, "scripts/baselines/touch-targets.json");
  const options = parseGuardArgs(process.argv.slice(2), { defaultBaseline });
  const label = baselineLabel(packageRoot, options.baseline);

  const sources = readCssSources(join(packageRoot, "src"), packageRoot);
  const { hard, review, tokens } = collectTouchTargetViolations(sources);

  if (options.updateBaseline) {
    const tracked = options.strict ? [...hard, ...review] : hard;
    // Read before overwriting: the written justifications in `reasons` belong
    // to the exceptions, not to this run, and must survive a regeneration.
    const previous = loadBaseline(options.baseline);
    writeBaseline(options.baseline, serializeBaseline("check-touch-targets", tracked, { previous }));
    console.log(
      `check-touch-targets: wrote baseline of ${tracked.length} violation(s) to ${label}` +
        `\n  (${hard.length} undersized control(s), ${review.length} ambiguous selector(s) for review)`,
    );
    return 0;
  }

  const baseline = loadBaseline(options.baseline);
  // A build FAILURE, not a nudge. Each entry must stay distinguishable from a
  // defect somebody shelved, and a key nothing matches any more is a standing
  // pre-authorisation for that violation to come back.
  const integrity = baselineIntegrityReport(baseline, [...hard, ...review], {
    label,
    categories: EXEMPTION_CATEGORIES,
  });
  if (integrity) {
    console.error(integrity);
    console.error("\ncheck-touch-targets: baseline is not accountable (see above).");
    return 1;
  }
  // Rule 1 outranks the baseline itself: a recorded exception may be a dense
  // tradeoff or a geometric bound, but it may never be a control under 24px.
  const subFloor = subFloorBaselineReport(baseline, tokens, { label });
  if (subFloor) {
    console.error(subFloor);
    console.error(`\ncheck-touch-targets: the ${ABSOLUTE_FLOOR_PX}px floor is not baselineable (see above).`);
    return 1;
  }
  const hardResult = applyBaseline(hard, baseline);
  const reviewResult = options.strict ? applyBaseline(review, baseline) : { fresh: review, suppressed: [] };

  if (review.length > 0) {
    console.warn(
      `check-touch-targets: ${review.length} selector(s) size an element below ${MINIMUM_TARGET_PX}px but are\n` +
        "  ambiguous — they are only interactive in some compositions. These are NOT build failures;\n" +
        "  decide each one by hand" +
        `${options.strict ? " (--strict is enforcing them here)." : ", or run with --strict to enforce them."}`,
    );
    if (!options.strict) console.warn(formatViolations(review, { indent: "  ", limit: 60 }));
  }

  const failing = options.strict ? [...hardResult.fresh, ...reviewResult.fresh] : hardResult.fresh;

  if (failing.length > 0) {
    console.error(
      `\nInteractive controls must be at least ${MINIMUM_TARGET_PX}px — the size the theme itself\n` +
        "declares as --control-min-height (src/theme/tokens.ts). Use var(--control-min-height),\n" +
        "or a --density-* token where a deliberately compact context is intended. A --density-*\n" +
        `token is a DENSE tier, not compliance with the standard, and never excuses the\n` +
        `${ABSOLUTE_FLOOR_PX}px floor (TOUCH-TARGETS.md rule 1):\n`,
    );
    console.error(formatViolations(failing));
    console.error(`\n${failing.length} undersized interactive control(s).`);
    if (baseline) {
      console.error(`${hardResult.suppressed.length} further violation(s) suppressed by ${label}.`);
    }
    console.error("Top offending selectors:");
    for (const { selector, count } of topOffenders(failing)) {
      console.error(`  ${count}x ${selector}`);
    }
    return 1;
  }

  const suppressed = hardResult.suppressed.length + reviewResult.suppressed.length;
  console.log(
    "check-touch-targets: no new undersized interactive controls" +
      (suppressed > 0 ? ` (${suppressed} known violation(s) held by the baseline).` : ".") +
      (review.length > 0 && !options.strict ? ` ${review.length} ambiguous selector(s) listed above for review.` : ""),
  );
  return 0;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main());
}
