import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import ts from "typescript";
import {
  applyBaseline,
  baselineIntegrityReport,
  baselineLabel,
  formatViolations,
  loadBaseline,
  parseGuardArgs,
  serializeBaseline,
  topOffenders,
  writeBaseline,
} from "./guard-baseline.mjs";

// ---------------------------------------------------------------------------
// `src/theme/STATES.md` rule 5 makes `disabled` and `busy` DIFFERENT states:
//
//   - `disabled` removes interactivity — `pointer-events: none`, NOT focusable.
//   - `busy` signals in-flight work — the control dims through
//     `--state-busy-opacity` but STAYS FOCUSABLE and announces `aria-busy`.
//
// Eight components collapsed them into `disabled={x || busy}`, which takes the
// control the user just activated out of the tab order at the exact moment it
// starts reporting on itself. Every one was caught by human review, none by the
// build (uif/issue-4673, then uif/issue-4684). This guard is the catch.
//
// ---------------------------------------------------------------------------
// WHAT THIS CAN AND CANNOT SEE — read before extending it.
//
// The rule as written ("a control must not remove its own interactivity because
// it is busy") is not decidable syntactically, because the hard part is not
// spotting `busy` inside a `disabled` expression. It is knowing WHOSE busy it
// is. Two constructs are textually identical and only one is a defect:
//
//     <Button disabled={busy} …>Cancel</Button>        ← legitimate
//     <Button disabled={busy} …>{busy ? "…" : "Save"}</Button>   ← the defect
//
// Disabling a SIBLING while another action is in flight — cancel and close
// buttons during a destructive confirm — is a deliberate product decision and
// must keep working. A guard that flagged every `busy` in a `disabled` would
// bury the real defect under legitimate cases, and a noisy gate gets disabled.
//
// So this guard does not try to answer the general question. It answers a
// narrower one with no false positives: does this element assert, from ONE
// flag, that it is BOTH busy AND disabled? It fires only when the element
// IDENTIFIES ITSELF as the busy control, through one of two signals:
//
//   A. The same flag drives `disabled` and `aria-busy` (or `loading`) on the
//      same element. This needs no semantics at all: rule 5 makes the two
//      states mutually exclusive, so one flag claiming both is a contradiction
//      by construction, whatever the flag means.
//
//   B. The element's own children swap on the same flag that appears in its
//      `disabled` — `{busy ? busyLabel : label}`. A control that renames itself
//      to "Working…" is the control doing the work, not a bystander.
//
// Signals A and B together catch all eight known occurrences and flag nothing
// else in the package.
//
// What it MISSES, stated plainly, because a gate that hides its blind spots is
// worse than no gate:
//
//   - Form fields locked during their own form's submit — the email input in
//     NewsletterSignupPanel, the destination radios in ResourceTransferDialog.
//     They carry neither `aria-busy` nor a busy-dependent label, so nothing
//     distinguishes them from a control disabled for an unrelated reason. Both
//     were real defects and both were fixed by hand in uif/issue-4684; a future
//     one would have to be caught by review again.
//   - A busy flag reaching `disabled` through a function call, a prop spread,
//     or a `useMemo`. Alias resolution below follows plain local `const`s only.
//   - Anything outside a JSX attribute — a `useEffect` that calls `.blur()`, or
//     CSS that sets `pointer-events: none` from a busy class.
//
// It is a high-precision, deliberately incomplete check: it makes the exact
// shape that recurred eight times impossible to reintroduce silently, and
// claims nothing beyond that.
// ---------------------------------------------------------------------------

const PACKAGE_ROOT = fileURLToPath(new URL("..", import.meta.url));
const SRC_ROOT = join(PACKAGE_ROOT, "src");
const DEFAULT_BASELINE = join(PACKAGE_ROOT, "scripts", "baselines", "busy-state.json");

/**
 * Names that denote "an action is in flight". Matched against the LAST segment
 * of an identifier or property access, so `busy`, `command.busy` and
 * `action.isLoading` all count.
 *
 * `disabled`-ish names are deliberately absent: `disabled={a.disabled || …}` is
 * the correct half of the expression and must not make the element suspicious.
 */
const BUSY_NAMES = /^(?:busy|isBusy|loading|isLoading|pending|isPending|submitting|isSubmitting|saving|isSaving|inFlight|isInFlight)$/;

/** Attributes that declare "this element is the one that is busy". */
const BUSY_DECLARING_ATTRIBUTES = new Set(["aria-busy", "loading"]);

function scriptKind(file) {
  return file.endsWith(".tsx") ? ts.ScriptKind.TSX : ts.ScriptKind.TS;
}

function parseSource(file, source) {
  return ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, scriptKind(file));
}

function lineOf(sf, node) {
  return sf.getLineAndCharacterOfPosition(node.getStart(sf)).line + 1;
}

export function listSourceFiles(root) {
  const files = [];
  const walk = (dir) => {
    for (const entry of readdirSync(dir).sort()) {
      const full = join(dir, entry);
      if (statSync(full).isDirectory()) {
        walk(full);
        continue;
      }
      if (!full.endsWith(".tsx")) continue;
      if (/\.(?:test|spec)\.tsx$/.test(full)) continue;
      files.push(full);
    }
  };
  walk(root);
  return files;
}

/**
 * Plain `const x = <expr>` initializers in the file, by name.
 *
 * Both `NewsletterSignupPanel` and `ResourceTransferDialog` hid the conflation
 * behind exactly this — `const submitDisabled = disabled || busy || submitted`
 * — so a guard that only looked at the literal `disabled={…}` text would have
 * missed two of the seven. Only single-assignment `const`s with an initializer
 * are followed, and only by name: this is a textual convenience, not scope
 * analysis, and a shadowed name is resolved conservatively (see `resolveText`).
 */
export function collectConstInitializers(sf) {
  const byName = new Map();
  const seenTwice = new Set();
  const visit = (node) => {
    if (
      ts.isVariableDeclaration(node)
      && ts.isIdentifier(node.name)
      && node.initializer
      && ts.isVariableDeclarationList(node.parent)
      && (node.parent.flags & ts.NodeFlags.Const) !== 0
    ) {
      const name = node.name.text;
      if (byName.has(name)) seenTwice.add(name);
      else byName.set(name, node.initializer.getText(sf));
    }
    ts.forEachChild(node, visit);
  };
  visit(sf);
  // A name declared twice in one file cannot be resolved by name alone; drop it
  // rather than guess, which keeps false positives out.
  for (const name of seenTwice) byName.delete(name);
  return byName;
}

/**
 * Expression text with local `const` aliases inlined, to a bounded depth.
 * Bounded because these are textual substitutions, and a cyclic or deeply
 * chained alias would otherwise loop; three levels covers every real case here.
 */
export function resolveText(text, consts, depth = 3) {
  if (depth <= 0) return text;
  let resolved = text;
  for (const [name, initializer] of consts) {
    const reference = new RegExp(`(?<![.\\w$])${name}(?![\\w$])`);
    if (!reference.test(resolved)) continue;
    resolved = resolved.replace(new RegExp(`(?<![.\\w$])${name}(?![\\w$])`, "g"), `(${initializer})`);
    return resolveText(resolved, consts, depth - 1);
  }
  return resolved;
}

/** Busy-ish identifiers/property accesses appearing anywhere in an expression. */
export function busyFlagsIn(node, sf) {
  const flags = new Set();
  const visit = (child) => {
    if (ts.isPropertyAccessExpression(child) && BUSY_NAMES.test(child.name.text)) {
      flags.add(child.getText(sf));
      return;
    }
    if (ts.isIdentifier(child) && BUSY_NAMES.test(child.text)) {
      flags.add(child.text);
      return;
    }
    ts.forEachChild(child, visit);
  };
  visit(node);
  return [...flags];
}

/** Busy-ish names in a raw expression string, for alias-resolved text. */
function busyFlagsInText(text) {
  const found = new Set();
  for (const match of text.matchAll(/(?:[\w$]+(?:\.[\w$]+)*\.)?([\w$]+)/g)) {
    if (BUSY_NAMES.test(match[1])) found.add(match[0]);
  }
  return [...found];
}

function attributeName(attribute, sf) {
  return ts.isJsxAttribute(attribute) ? attribute.name.getText(sf) : null;
}

/** The nearest enclosing named function/component, for a stable violation key. */
function enclosingName(node, sf) {
  let current = node.parent;
  while (current) {
    if (ts.isFunctionDeclaration(current) && current.name) return current.name.text;
    if (
      (ts.isArrowFunction(current) || ts.isFunctionExpression(current))
      && ts.isVariableDeclaration(current.parent)
      && ts.isIdentifier(current.parent.name)
    ) {
      return current.parent.name.text;
    }
    current = current.parent;
  }
  return "(module)";
}

/**
 * Conflations in one file. A violation is an element whose `disabled`
 * expression contains a busy flag AND which identifies itself as the busy
 * control through signal A (an `aria-busy`/`loading` attribute driven by the
 * same flag) or signal B (children that switch on the same flag).
 */
export function findConflations(file, source, { relPath = file } = {}) {
  const sf = parseSource(file, source);
  const consts = collectConstInitializers(sf);
  const violations = [];

  const visit = (node) => {
    const opening = ts.isJsxOpeningElement(node) || ts.isJsxSelfClosingElement(node) ? node : null;
    if (opening) {
      const tag = opening.tagName.getText(sf);
      const attributes = opening.attributes.properties;

      const disabledAttribute = attributes.find(
        (attribute) => attributeName(attribute, sf) === "disabled" && attribute.initializer,
      );

      if (disabledAttribute && ts.isJsxExpression(disabledAttribute.initializer) && disabledAttribute.initializer.expression) {
        const expression = disabledAttribute.initializer.expression;
        const directFlags = busyFlagsIn(expression, sf);
        const resolvedFlags = busyFlagsInText(resolveText(expression.getText(sf), consts));
        const flags = [...new Set([...directFlags, ...resolvedFlags])];

        if (flags.length > 0) {
          // Signal A — the same flag also declares the element busy.
          const declaring = attributes.filter((attribute) => {
            const name = attributeName(attribute, sf);
            return name && BUSY_DECLARING_ATTRIBUTES.has(name) && attribute.initializer;
          });
          const signalA = declaring.some((attribute) => {
            const text = attribute.initializer.getText(sf);
            return flags.some((flag) => text.includes(flag));
          });

          // Signal B — the element's own children switch on the same flag.
          let signalB = false;
          const element = ts.isJsxOpeningElement(opening) ? opening.parent : null;
          if (element && ts.isJsxElement(element)) {
            for (const child of element.children) {
              if (!ts.isJsxExpression(child) || !child.expression) continue;
              if (!ts.isConditionalExpression(child.expression)) continue;
              const condition = child.expression.condition.getText(sf);
              if (flags.some((flag) => condition.includes(flag))) {
                signalB = true;
                break;
              }
            }
          }

          if (signalA || signalB) {
            const flag = flags.sort()[0];
            violations.push({
              file: relPath,
              selector: `${enclosingName(opening, sf)} > ${tag}`,
              property: "disabled",
              value: flag,
              line: lineOf(sf, disabledAttribute),
              note: signalA
                ? `\`disabled\` and \`${
                  declaring.map((attribute) => attributeName(attribute, sf)).join("/")
                }\` are both driven by \`${flag}\` — rule 5 makes those different states, so one flag cannot set both`
                : `\`disabled\` contains \`${flag}\`, and this element's own children switch on \`${flag}\` — it is the busy control, so \`busy\` must not reach \`disabled\``,
            });
          }
        }
      }
    }
    ts.forEachChild(node, visit);
  };

  visit(sf);
  return violations;
}

export function main(argv = process.argv.slice(2)) {
  const options = parseGuardArgs(argv, { defaultBaseline: DEFAULT_BASELINE });
  const label = baselineLabel(PACKAGE_ROOT, options.baseline);

  const violations = [];
  let scanned = 0;
  for (const file of listSourceFiles(SRC_ROOT)) {
    scanned += 1;
    const relPath = relative(PACKAGE_ROOT, file).split(/[\\/]/).join("/");
    violations.push(...findConflations(file, readFileSync(file, "utf8"), { relPath }));
  }

  if (options.updateBaseline) {
    const previous = loadBaseline(options.baseline);
    writeBaseline(options.baseline, serializeBaseline("check-busy-state", violations, { previous }));
    console.log(
      `check-busy-state: wrote baseline of ${violations.length} violation(s) to ${label} (${scanned} file(s) scanned)`,
    );
    return 0;
  }

  const baseline = loadBaseline(options.baseline);
  const integrity = baselineIntegrityReport(baseline, violations, { label, categories: EXEMPTION_CATEGORIES });
  if (integrity) {
    console.error(integrity);
    console.error("\ncheck-busy-state: baseline is not accountable (see above).");
    return 1;
  }

  const { fresh, suppressed } = applyBaseline(violations, baseline);

  if (fresh.length > 0) {
    console.error(
      "\nA control removes its own interactivity because it is busy.\n\n"
        + "src/theme/STATES.md rule 5 makes `disabled` and `busy` DIFFERENT states:\n"
        + "  - `disabled` removes interactivity — pointer-events: none, NOT focusable.\n"
        + "  - `busy` dims the control but it STAYS FOCUSABLE and announces aria-busy=\"true\".\n\n"
        + "`disabled={x || busy}` collapses them, so the control leaves the tab order at the\n"
        + "moment the user activates it and a keyboard user cannot get back to read the result.\n\n"
        + "Fix: keep `busy` out of `disabled` entirely. Pass it to `Button.loading`, which sets\n"
        + "aria-busy, leaves the button focusable, and blocks activation in its own handler; on a\n"
        + "raw element, set aria-busy and guard re-entry in the click/submit handler instead.\n"
        + "Preventing a double submit is legitimate — `disabled` is just the wrong instrument,\n"
        + "because it destroys focus. See src/components/feedback/NotificationToggle.tsx.\n\n"
        + "Disabling a SIBLING control while another action is in flight is NOT this defect and\n"
        + "is not reported here.\n",
    );
    console.error(formatViolations(fresh));
    console.error(`\n${fresh.length} busy/disabled conflation(s).`);
    if (baseline) console.error(`${suppressed.length} further violation(s) suppressed by ${label}.`);
    console.error("Top offending components:");
    for (const { selector, count } of topOffenders(fresh)) console.error(`  ${count}x ${selector}`);
    return 1;
  }

  console.log(
    `check-busy-state: no control disables itself while busy (${scanned} file(s) scanned)`
      + (suppressed.length > 0 ? `; ${suppressed.length} known violation(s) held by ${label}.` : "."),
  );
  return 0;
}

/**
 * The only exemption this guard grants: a conflation that predates the gate and
 * is being burned down separately, rather than one of the eight uif/issue-4684
 * and uif/issue-4673 fixed directly. Naming the category is what stops a fresh
 * defect being quietly baselined instead of corrected.
 */
export const EXEMPTION_CATEGORIES = [
  {
    label: "pre-existing busy/disabled conflation found by this gate, not one of the eight fixed directly",
    pattern: /pre-existing/i,
  },
];

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  process.exit(main());
}
