import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import {
  conditionalSubpaths,
  extractDocumentedSpecifiers,
  isOwnPackage,
  lookupSubpath,
  NON_COMPONENT_SUBPATHS,
  patternSubpaths,
  resolveTarget,
  toSpecifier,
  toSubpath,
  verifyResolvedUrl,
} from "./check-export-map.mjs";

const fixturePath = (name) =>
  fileURLToPath(new URL(`./fixtures/export-map-gate/${name}`, import.meta.url));

// A throwaway package (its own package.json + exports map) used to exercise
// REAL Node self-reference resolution against a directory target, a missing
// target, and a dir-symlink target — without mutating this package's own
// manifest. `resolve-in-real-node.mjs` runs in an actual `node` child
// process, never through vitest's own SSR transform: Vite replaces
// `import.meta` with a stub lacking `.resolve`, so `resolveAndVerify` cannot
// be driven with genuine self-reference resolution in-process. That runner
// script lives inside the fixture package on purpose — Node resolves a
// self-reference against the nearest ANCESTOR package.json to the module
// calling `import.meta.resolve`, so it resolves against `resolution-fixture/
// package.json`, exactly the way `check-export-map.mjs` resolving
// `emibs-ui-lib/...` resolves against this real package's own manifest.
const resolutionRunner = fixturePath("resolution-fixture/resolve-in-real-node.mjs");
const FIXTURE_PKG = "export-map-gate-resolution-fixture";

/** Runs resolve-in-real-node.mjs in a real Node process and parses its JSON result. */
function resolveInRealNode(specifier) {
  const stdout = execFileSync(process.execPath, [resolutionRunner, specifier], { encoding: "utf8" });
  return JSON.parse(stdout);
}

const documentedIn = (name) =>
  extractDocumentedSpecifiers(fixturePath(name), readFileSync(fixturePath(name), "utf8"));

const manifest = JSON.parse(
  readFileSync(fileURLToPath(new URL("../package.json", import.meta.url)), "utf8"),
);

describe("export map gate — reading what the catalog documents", () => {
  it("collects every import declaration inside a usage snippet, including multi-import snippets", () => {
    const specifiers = documentedIn("usages.sample.ts").map((found) => found.specifier);
    expect(specifiers).toContain("emibs-ui-lib/components/data/AuditTimeline");
    expect(specifiers).toContain("emibs-ui-lib/forms");
    expect(specifiers).toContain("emibs-ui-lib/core");
    expect(specifiers).toContain("emibs-ui-lib/components/feedback/ActivityCenter");
    expect(specifiers).toContain("emibs-ui-lib");
  });

  it("keeps third-party specifiers, so the caller can decide they are not its business", () => {
    expect(documentedIn("usages.sample.ts").map((f) => f.specifier)).toContain("lucide-react");
    expect(isOwnPackage("lucide-react")).toBe(false);
    expect(isOwnPackage("emibs-ui-lib")).toBe(true);
    expect(isOwnPackage("emibs-ui-lib/forms")).toBe(true);
    // A package whose name merely starts with ours is a different package.
    expect(isOwnPackage("emibs-ui-lib-extras/forms")).toBe(false);
  });

  it("ignores the module's own real imports, which are code and not documentation", () => {
    expect(documentedIn("usages.sample.ts").map((f) => f.specifier)).not.toContain("../types");
  });

  it("ignores an import spelled out in a comment or in JSX text", () => {
    const specifiers = documentedIn("usages.sample.ts").map((found) => found.specifier);
    expect(specifiers).not.toContain("emibs-ui-lib/components/data/Ghost");
  });

  it("attributes each documented specifier to the catalog entry that documents it", () => {
    const auditTimeline = documentedIn("usages.sample.ts")
      .find((found) => found.specifier === "emibs-ui-lib/components/data/AuditTimeline");
    expect(auditTimeline.entryId).toBe("audit-timeline");
    expect(auditTimeline.line).toBeGreaterThan(0);
  });
});

describe("export map gate — subpaths", () => {
  it("maps a specifier onto the exports subpath it must resolve against", () => {
    expect(toSubpath("emibs-ui-lib")).toBe(".");
    expect(toSubpath("emibs-ui-lib/forms")).toBe("./forms");
    expect(toSubpath("emibs-ui-lib/components/data/AuditTimeline"))
      .toBe("./components/data/AuditTimeline");
  });

  it("looks a subpath up by exact key, and reports a missing one as undefined", () => {
    const map = { ".": "./src/lib/index.ts", "./forms": "./src/forms/index.ts" };
    expect(lookupSubpath(map, "./forms")).toBe("./src/forms/index.ts");
    expect(lookupSubpath(map, "./ghost")).toBeUndefined();
    // Inherited object members are not exports entries.
    expect(lookupSubpath(map, "toString")).toBeUndefined();
  });

  it("follows condition objects the way a bundler would", () => {
    expect(resolveTarget("./src/a.tsx")).toBe("./src/a.tsx");
    expect(resolveTarget({ types: "./src/a.tsx", default: "./dist/a.js" })).toBe("./src/a.tsx");
    expect(resolveTarget({ default: "./dist/a.js" })).toBe("./dist/a.js");
    expect(resolveTarget(["./src/a.tsx", "./src/b.tsx"])).toBe("./src/a.tsx");
    expect(resolveTarget(null)).toBeNull();
    expect(resolveTarget({ node: "./src/a.tsx" })).toBeNull();
  });

  it("spots a wildcard subpath, which this package refuses on purpose", () => {
    expect(patternSubpaths({ "./components/*": "./src/components/*.tsx" }))
      .toEqual(["./components/*"]);
    expect(patternSubpaths({ "./forms": "./src/forms/index.ts" })).toEqual([]);
  });
});

describe("export map gate — real resolution requires an existing regular file", () => {
  it("passes a target that resolves to a real regular file", () => {
    expect(resolveInRealNode(`${FIXTURE_PKG}/file`)).toEqual({
      ok: true,
      path: expect.stringMatching(/target\.mjs$/),
    });
  });

  it("fails a target that resolves to a directory — the defect this gate exists to close", () => {
    // Node's own resolver does not check the filesystem: it happily resolves
    // this specifier to a directory URL (proven directly here, so the claim
    // in the header comment stays checked rather than merely asserted).
    // `resolveAndVerify`'s `statSync`/`isFile` check is what turns that into
    // a failure.
    const result = resolveInRealNode(`${FIXTURE_PKG}/dir`);
    expect(result.ok).toBe(false);
    expect(result.reason).toMatch(/directory/);
  });

  it("fails a target that does not exist at all", () => {
    const result = resolveInRealNode(`${FIXTURE_PKG}/missing`);
    expect(result.ok).toBe(false);
    expect(result.reason).toMatch(/does not exist/);
  });

  it("fails a target that is a symlink to a directory", () => {
    // statSync (not lstatSync) follows the link, so a dir-symlink target is
    // caught the same way a direct directory target is.
    const result = resolveInRealNode(`${FIXTURE_PKG}/dir-symlink`);
    expect(result.ok).toBe(false);
    expect(result.reason).toMatch(/directory/);
  });

  it("fails a specifier the exports map does not recognize, same as a consumer would see", () => {
    const result = resolveInRealNode(`${FIXTURE_PKG}/ghost`);
    expect(result.ok).toBe(false);
    expect(result.reason).toMatch(/does not resolve/);
  });

  it("verifyResolvedUrl rejects a non-file:// URL outright", () => {
    const result = verifyResolvedUrl("https://example.com/module.mjs");
    expect(result.ok).toBe(false);
  });

  it("toSpecifier inverts toSubpath", () => {
    expect(toSubpath(toSpecifier("./forms"))).toBe("./forms");
    expect(toSubpath(toSpecifier("."))).toBe(".");
  });
});

describe("export map gate — conditional (non-string) targets are rejected outright", () => {
  it("flags a subpath whose value is a condition object", () => {
    expect(conditionalSubpaths({
      "./forms": "./src/forms/index.ts",
      "./core": { types: "./src/core/index.ts", default: "./src/core/index.ts" },
    })).toEqual(["./core"]);
  });

  it("flags a subpath whose value is a condition array", () => {
    expect(conditionalSubpaths({ "./forms": ["./a.ts", "./b.ts"] })).toEqual(["./forms"]);
  });

  it("finds nothing wrong with today's map: every real entry is a bare string", () => {
    expect(conditionalSubpaths(manifest.exports)).toEqual([]);
  });
});

describe("export map gate — the real manifest", () => {
  it("declares an exports map", () => {
    expect(manifest.exports).toBeTypeOf("object");
  });

  it("stays private: this ticket made documented paths resolve inside the monorepo, not publish", () => {
    expect(manifest.private).toBe(true);
  });

  it("enumerates its public surface rather than pattern-matching it", () => {
    expect(patternSubpaths(manifest.exports)).toEqual([]);
  });

  it("points every entry at a source file, because the package is unbuilt and has no main", () => {
    expect(manifest.main).toBeUndefined();
    for (const [subpath, entry] of Object.entries(manifest.exports)) {
      if (subpath === "./package.json") continue;
      expect(resolveTarget(entry), subpath).toMatch(/^\.\/src\//);
    }
  });

  it("runs the gate as part of the build", () => {
    expect(manifest.scripts.build).toContain("npm run check:exports");
    expect(manifest.scripts["check:exports"]).toBe("node scripts/check-export-map.mjs");
  });

  it("exempts only aggregate roots and package assets from needing a usage snippet", () => {
    for (const subpath of NON_COMPONENT_SUBPATHS.keys()) {
      expect(Object.keys(manifest.exports), subpath).toContain(subpath);
      expect(subpath.startsWith("./components/")).toBe(false);
    }
  });

  // The exempt-root list proves no documentation relationship for the six
  // roots it names (cross-provider review of #501) — that is exactly why it
  // must not be able to grow silently. Pinning the exact set means adding a
  // seventh exemption requires editing this assertion, the same "one line is
  // the decision" bar the file already holds explicit exports entries to.
  it("pins the exempt-root list to an explicit set — a silent addition is the same hole as `*`", () => {
    expect([...NON_COMPONENT_SUBPATHS.keys()].sort()).toEqual(
      [".", "./core", "./forms", "./theme", "./styles.css", "./package.json"].sort(),
    );
  });

  it("records a real, non-trivial reason for every exemption", () => {
    for (const [subpath, reason] of NON_COMPONENT_SUBPATHS) {
      expect(typeof reason, subpath).toBe("string");
      expect(reason.length, subpath).toBeGreaterThan(15);
    }
  });
});
