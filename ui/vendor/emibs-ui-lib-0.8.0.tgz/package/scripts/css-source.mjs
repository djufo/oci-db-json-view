import { readdirSync, readFileSync } from "node:fs";
import { join, relative, sep } from "node:path";

// Shared CSS reader for the stylesheet guards (check-theme-tokens,
// check-touch-targets). Hand-rolled rather than pulled from a parser package:
// the guards only need declarations plus the selector block they sit in, the
// package has no CSS parser dependency, and the build guards must keep running
// with `node scripts/*.mjs` alone (see check-composite-finality.mjs).
//
// The scanner is deliberately tolerant: comments and strings are skipped,
// at-rules nest like blocks, and a final declaration without a trailing `;` is
// still emitted. It is NOT a spec-complete parser and does not need to be — it
// never rewrites CSS, it only reports on it.

/** Every `.css` file under `root`, in a stable (sorted) order. */
export function findCssFiles(root) {
  const found = [];
  const walk = (directory) => {
    const entries = readdirSync(directory, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
    for (const entry of entries) {
      const path = join(directory, entry.name);
      if (entry.isDirectory()) {
        walk(path);
        continue;
      }
      if (entry.isFile() && entry.name.endsWith(".css")) found.push(path);
    }
  };
  walk(root);
  return found;
}

/** Repo-relative path with forward slashes, so reports are stable across platforms. */
export function displayPath(packageRoot, path) {
  return relative(packageRoot, path).split(sep).join("/");
}

export function readCssSources(root, packageRoot) {
  return findCssFiles(root).map((path) => ({
    path,
    file: displayPath(packageRoot, path),
    source: readFileSync(path, "utf8"),
  }));
}

// Index of the `:` that separates property from value, ignoring any `:` inside
// parentheses (`url(a:b)`) or quotes (`content: "a:b"`). Returns -1 when the
// text is not a declaration at all.
function declarationSplitIndex(text) {
  let depth = 0;
  let quote = "";
  for (let i = 0; i < text.length; i += 1) {
    const char = text[i];
    if (quote) {
      if (char === "\\") i += 1;
      else if (char === quote) quote = "";
      continue;
    }
    if (char === '"' || char === "'") quote = char;
    else if (char === "(") depth += 1;
    else if (char === ")") depth = Math.max(0, depth - 1);
    else if (char === ":" && depth === 0) return i;
  }
  return -1;
}

/** Split a selector prelude on top-level commas: `.a, .b:is(.c, .d)` -> 2 entries. */
export function splitSelectorList(prelude) {
  const parts = [];
  let depth = 0;
  let quote = "";
  let current = "";
  for (let i = 0; i < prelude.length; i += 1) {
    const char = prelude[i];
    if (quote) {
      current += char;
      if (char === "\\") {
        current += prelude[i + 1] ?? "";
        i += 1;
      } else if (char === quote) quote = "";
      continue;
    }
    if (char === '"' || char === "'") {
      quote = char;
      current += char;
    } else if (char === "(" || char === "[") {
      depth += 1;
      current += char;
    } else if (char === ")" || char === "]") {
      depth = Math.max(0, depth - 1);
      current += char;
    } else if (char === "," && depth === 0) {
      parts.push(current.trim());
      current = "";
    } else {
      current += char;
    }
  }
  if (current.trim()) parts.push(current.trim());
  return parts.filter(Boolean);
}

/** Collapse runs of whitespace so selectors and values compare/report stably. */
export function normalizeWhitespace(text) {
  return text.replace(/\s+/g, " ").trim();
}

/**
 * Parse a stylesheet into declarations, each carrying the block it sits in.
 *
 * Returns `{ blocks, declarations }`. A block records its own prelude, the
 * ancestor preludes (`path`), whether any ancestor is an at-rule, and every
 * declaration inside it — the guards need block-level context to recognise
 * patterns such as the visually-hidden input (`position: absolute` +
 * `opacity: 0`) that only make sense when the whole rule is visible.
 */
export function parseCss(source, file = "") {
  const blocks = [];
  const declarations = [];

  const makeBlock = (prelude, parent) => {
    const isAtRule = prelude.startsWith("@");
    const atName = isAtRule ? (/^@([\w-]+)/.exec(prelude)?.[1] ?? "").toLowerCase() : "";
    const path = parent ? [...parent.path, prelude] : [prelude];
    const block = {
      id: blocks.length,
      file,
      prelude,
      isAtRule,
      atName,
      path,
      selector: normalizeWhitespace(path.join(" ")),
      selectors: isAtRule ? [] : splitSelectorList(prelude),
      atRuleNames: parent ? [...parent.atRuleNames, ...(isAtRule ? [atName] : [])] : isAtRule ? [atName] : [],
      declarations: [],
    };
    blocks.push(block);
    return block;
  };

  const rootBlock = makeBlock("", null);
  rootBlock.selector = "(top level)";
  rootBlock.path = [];
  rootBlock.selectors = [];

  const stack = [rootBlock];
  let buffer = "";
  let bufferLine = 0;
  let line = 1;

  const startBuffer = () => {
    if (buffer.trim() === "") bufferLine = line;
  };

  const flushDeclaration = () => {
    const text = normalizeWhitespace(buffer);
    buffer = "";
    if (!text || text.startsWith("@")) return;
    const split = declarationSplitIndex(text);
    if (split < 0) return;
    const property = text.slice(0, split).trim();
    const value = text.slice(split + 1).trim();
    if (!property || !value) return;
    const block = stack[stack.length - 1];
    const declaration = {
      file,
      property: property.toLowerCase(),
      rawProperty: property,
      value,
      line: bufferLine || line,
      block,
      selector: block.selector,
    };
    block.declarations.push(declaration);
    declarations.push(declaration);
  };

  for (let i = 0; i < source.length; i += 1) {
    const char = source[i];

    if (char === "\n") {
      line += 1;
      buffer += char;
      continue;
    }

    // Comment — consumed whole, newlines still counted.
    if (char === "/" && source[i + 1] === "*") {
      i += 2;
      while (i < source.length && !(source[i] === "*" && source[i + 1] === "/")) {
        if (source[i] === "\n") line += 1;
        i += 1;
      }
      i += 1;
      continue;
    }

    // String — copied verbatim so `content: "…"` stays intact.
    if (char === '"' || char === "'") {
      startBuffer();
      const quote = char;
      buffer += char;
      i += 1;
      while (i < source.length && source[i] !== quote) {
        if (source[i] === "\n") line += 1;
        if (source[i] === "\\") {
          buffer += source[i];
          i += 1;
        }
        buffer += source[i] ?? "";
        i += 1;
      }
      buffer += quote;
      continue;
    }

    if (char === "{") {
      const prelude = normalizeWhitespace(buffer);
      buffer = "";
      // Every `{` opens a frame, known at-rule or not, so brace depth stays right.
      const parent = stack[stack.length - 1];
      stack.push(makeBlock(prelude, parent === rootBlock ? null : parent));
      continue;
    }

    if (char === "}") {
      flushDeclaration();
      if (stack.length > 1) stack.pop();
      continue;
    }

    if (char === ";") {
      flushDeclaration();
      continue;
    }

    if (!/\s/.test(char)) startBuffer();
    buffer += char;
  }

  flushDeclaration();
  return { blocks, declarations };
}

/**
 * Mask out spans that must never be scanned for colours or sizes — quoted
 * strings and `url(...)` payloads (an SVG reference such as `fill: url(#grad)`
 * is not a hex colour). Masked spans become spaces so every index in the
 * returned string still lines up with the original value.
 */
export function maskStringsAndUrls(value) {
  const out = value.split("");
  const blank = (start, end) => {
    for (let i = start; i < end && i < out.length; i += 1) {
      if (out[i] !== "\n") out[i] = " ";
    }
  };

  for (let i = 0; i < value.length; i += 1) {
    const char = value[i];
    if (char === '"' || char === "'") {
      const start = i;
      i += 1;
      while (i < value.length && value[i] !== char) {
        if (value[i] === "\\") i += 1;
        i += 1;
      }
      blank(start, Math.min(i + 1, value.length));
      continue;
    }
    if (/[uU]/.test(char) && /^url\s*\(/i.test(value.slice(i))) {
      const open = value.indexOf("(", i);
      const end = matchingParen(value, open);
      blank(i, end + 1);
      i = end;
    }
  }
  return out.join("");
}

/** Index of the `)` that closes the `(` at `open`; the end of the string if unbalanced. */
export function matchingParen(value, open) {
  let depth = 0;
  for (let i = open; i < value.length; i += 1) {
    if (value[i] === "(") depth += 1;
    else if (value[i] === ")") {
      depth -= 1;
      if (depth === 0) return i;
    }
  }
  return value.length - 1;
}

/** Split function arguments on top-level commas. */
export function splitArguments(text) {
  const parts = [];
  let depth = 0;
  let current = "";
  for (const char of text) {
    if (char === "(") depth += 1;
    if (char === ")") depth -= 1;
    if (char === "," && depth === 0) {
      parts.push(current);
      current = "";
      continue;
    }
    current += char;
  }
  parts.push(current);
  return parts;
}
