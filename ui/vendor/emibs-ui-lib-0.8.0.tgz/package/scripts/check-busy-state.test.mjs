import ts from "typescript";
import { describe, expect, it } from "vitest";
import { busyFlagsIn, collectConstInitializers, findConflations, resolveText } from "./check-busy-state.mjs";

function parse(source) {
  return ts.createSourceFile("x.tsx", source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
}

/**
 * The guard's whole value is the line it draws between two textually similar
 * constructs — a control that disables ITSELF because it is busy (the defect
 * that recurred nine times) and a control disabled while a SIBLING action is in
 * flight (legitimate, and must keep working). These tests pin that line from
 * both sides: a gate that stopped catching the defect and a gate that started
 * flagging the legitimate case would both pass if only one side were tested.
 */

function scan(source) {
  return findConflations("Sample.tsx", source, { relPath: "Sample.tsx" });
}

describe("check-busy-state — the defect it must catch", () => {
  it("catches signal A: one flag driving both aria-busy and disabled", () => {
    // The original NotificationToggle shape (uif/issue-4673).
    const violations = scan(`
      export function Toggle({ disabled, busy, onChange }) {
        return <button aria-busy={busy || undefined} disabled={disabled || busy} onClick={onChange} />;
      }
    `);

    expect(violations).toHaveLength(1);
    expect(violations[0].value).toBe("busy");
    expect(violations[0].note).toMatch(/different states/);
  });

  it("catches signal A through a property access, as WorkflowCommandBar had it", () => {
    const violations = scan(`
      function CommandButton({ command }) {
        return <Button aria-busy={command.busy || undefined} disabled={command.disabled || command.busy} />;
      }
    `);

    expect(violations).toHaveLength(1);
    expect(violations[0].value).toBe("command.busy");
    expect(violations[0].selector).toBe("CommandButton > Button");
  });

  it("catches signal A when busy is declared through Button.loading", () => {
    const violations = scan(`
      function Save({ busy }) {
        return <Button loading={busy} disabled={busy} />;
      }
    `);

    expect(violations).toHaveLength(1);
  });

  it("catches signal B: the element's own children switch on the same flag", () => {
    // ThemeLabPanel and ThemeExportPanel had no aria-busy at all, so signal A
    // could not see them — the label swap is the only evidence in the source
    // that this button is the one doing the work.
    const violations = scan(`
      function Generate({ action }) {
        return (
          <Button disabled={action.disabled || action.busy}>
            {action.busy ? action.busyLabel : action.label}
          </Button>
        );
      }
    `);

    expect(violations).toHaveLength(1);
    expect(violations[0].value).toBe("action.busy");
    expect(violations[0].note).toMatch(/it is the busy control/);
  });

  it("sees through a local const alias, which hid two of the nine", () => {
    // NewsletterSignupPanel and ResourceTransferDialog both wrote the
    // conflation into a const and passed the const to `disabled`. A guard
    // reading only the literal attribute text would have missed both.
    const violations = scan(`
      function Signup({ disabled, busy, submitted, busyLabel, submitLabel }) {
        const submitDisabled = disabled || busy || submitted;
        return <Button disabled={submitDisabled}>{busy ? busyLabel : submitLabel}</Button>;
      }
    `);

    expect(violations).toHaveLength(1);
    expect(violations[0].property).toBe("disabled");
  });

  it("recognises the other in-flight vocabularies, not just `busy`", () => {
    // The five extra occurrences this gate found used `saving`, `submitting`
    // and `formState.isSubmitting` rather than `busy`.
    for (const flag of ["saving", "submitting", "isLoading", "pending", "formState.isSubmitting"]) {
      const violations = scan(`
        function Submit(props) {
          return <Button disabled={${flag}}>{${flag} ? "Working" : "Save"}</Button>;
        }
      `);
      expect(violations, `${flag} should be recognised as an in-flight flag`).toHaveLength(1);
    }
  });
});

describe("check-busy-state — what it must NOT flag", () => {
  it("leaves a sibling control disabled during another action's flight alone", () => {
    // A Cancel button locked while a destructive confirm runs is a deliberate
    // product decision. Flagging it would bury the real defect in noise, and a
    // noisy gate gets switched off.
    const violations = scan(`
      function Actions({ busy, onCancel }) {
        return <Button disabled={busy} onClick={onCancel}>Cancel</Button>;
      }
    `);

    expect(violations).toEqual([]);
  });

  it("leaves a correctly fixed control alone", () => {
    const violations = scan(`
      function Command({ command }) {
        return (
          <Button disabled={command.disabled} loading={command.busy}>
            {command.busy ? command.busyLabel : command.label}
          </Button>
        );
      }
    `);

    expect(violations).toEqual([]);
  });

  it("does not treat a plain disabled prop as an in-flight flag", () => {
    const violations = scan(`
      function Plain({ action }) {
        return <Button disabled={action.disabled}>{action.label}</Button>;
      }
    `);

    expect(violations).toEqual([]);
  });

  it("does not flag a busy-conditional child of a control with no disabled at all", () => {
    const violations = scan(`
      function Status({ busy }) {
        return <span>{busy ? "Working" : "Idle"}</span>;
      }
    `);

    expect(violations).toEqual([]);
  });
});

describe("check-busy-state — helpers", () => {
  it("refuses to resolve a name declared twice, rather than guessing", () => {
    // Two different `flag`s in one file cannot be told apart by name alone.
    const consts = collectConstInitializers(
      parse("function a(){const flag = busy;} function b(){const flag = other;}"),
    );

    expect(consts.has("flag")).toBe(false);
  });

  it("inlines an alias without matching it as a property suffix", () => {
    const consts = new Map([["busyish", "busy || x"]]);

    // `props.busyish` must not be rewritten — only the bare identifier is an alias.
    expect(resolveText("props.busyish", consts)).toBe("props.busyish");
    expect(resolveText("busyish", consts)).toBe("(busy || x)");
  });

  it("collects busy flags but not ordinary identifiers", () => {
    const sf = parse("const e = a.disabled || a.busy || other;");
    const expression = sf.statements[0].declarationList.declarations[0].initializer;

    expect(busyFlagsIn(expression, sf)).toEqual(["a.busy"]);
  });
});
