import { spawnSync } from "node:child_process";
import { copyFileSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { fileURLToPath } from "node:url";
import { afterEach, describe, expect, it } from "vitest";
import { EXEMPTION_CATEGORIES as THEME_CATEGORIES } from "./check-theme-tokens.mjs";
import { EXEMPTION_CATEGORIES as TOUCH_CATEGORIES } from "./check-touch-targets.mjs";
import {
  applyBaseline,
  carryReasons,
  inadequateReasons,
  parseGuardArgs,
  reasonProblem,
  serializeBaseline,
  unexplainedEntries,
  violationKey,
} from "./guard-baseline.mjs";

const scriptsDir = fileURLToPath(new URL(".", import.meta.url));

// The guards derive their package root — and therefore their conventional
// baseline path — from their own location on disk. To exercise the real CLI
// wiring (`node scripts/check-theme-tokens.mjs`, which is what `npm run
// check:theme` runs) without depending on the live src/styles.css, copy the
// guard scripts into a throwaway package root with a tiny stylesheet of its
// own. The guards import nothing outside node: builtins and their sibling
// modules, so a plain file copy is a faithful harness.
const GUARD_MODULES = [
  "guard-baseline.mjs",
  "css-source.mjs",
  "check-theme-tokens.mjs",
  "check-touch-targets.mjs",
];

// 3 hard violations (#fff, #000000, #123456) and 1 soft var() fallback
// (#0f766e), which only `--strict` escalates.
const THEME_CSS = `.ui-known__a { color: #fff; }
.ui-known__b { background: #000000; }
.ui-fresh__c { border-color: #123456; }
.ui-soft__d { color: var(--text, #0f766e); }
`;

// 2 hard violations; `.ui-thing__chip` is ambiguous and only reviewed.
const TOUCH_CSS = `.ui-known__close { min-height: 30px; }
.ui-fresh__trigger { min-height: 28px; }
.ui-thing__chip { min-height: 26px; }
`;

const sandboxes = [];

// A justification that clears the ratchet for each guard: long enough to be an
// argument, and naming one of that guard's declared exemption categories.
const THEME_REASON =
  "National flag, not a theme colour: the tricolour band is a depiction whose meaning is the hue, so following the palette would make it wrong rather than merely unthemed.";
const TOUCH_REASON =
  "Declared dense variant accepted by the TOUCH-TARGETS 'Dense' tier (rule 3): a deliberate density tradeoff that still clears the 24px floor.";

function validReasonFor(guard) {
  return guard === "check-touch-targets" ? TOUCH_REASON : THEME_REASON;
}

function createGuardSandbox() {
  const root = mkdtempSync(join(tmpdir(), "guard-baseline-"));
  sandboxes.push(root);
  mkdirSync(join(root, "scripts"), { recursive: true });
  mkdirSync(join(root, "src"), { recursive: true });
  for (const name of GUARD_MODULES) copyFileSync(join(scriptsDir, name), join(root, "scripts", name));
  writeFileSync(join(root, "src", "theme.css"), THEME_CSS, "utf8");
  writeFileSync(join(root, "src", "touch.css"), TOUCH_CSS, "utf8");

  const defaultBaseline = (guard) => join(root, "scripts", "baselines", `${guard}.json`);

  return {
    root,
    themeBaseline: defaultBaseline("theme-tokens"),
    touchBaseline: defaultBaseline("touch-targets"),
    /**
     * Record a baseline file by hand, so a test states exactly what is known.
     *
     * Reasons default to a valid one per key: the guards FAIL on an entry with
     * no usable justification (that is the ratchet), so a test about anything
     * else has to satisfy it, exactly as a real baseline must. Pass `reasons`
     * explicitly — including `{}` — to exercise the ratchet itself.
     */
    writeBaselineFile(path, guard, keys, reasons = undefined) {
      mkdirSync(join(path, ".."), { recursive: true });
      const entries = {};
      for (const key of keys) entries[key] = 1;
      const baseline = { guard, version: 1, total: keys.length, entries };
      const resolved =
        reasons === undefined ? Object.fromEntries(keys.map((key) => [key, validReasonFor(guard)])) : reasons;
      if (resolved && Object.keys(resolved).length > 0) baseline.reasons = resolved;
      writeFileSync(path, `${JSON.stringify(baseline, null, 2)}\n`, "utf8");
    },
    readBaselineFile(path) {
      return JSON.parse(readFileSync(path, "utf8"));
    },
    run(script, args = []) {
      const result = spawnSync(process.execPath, [join(root, "scripts", script), ...args], { encoding: "utf8" });
      return { status: result.status, stdout: result.stdout, stderr: result.stderr, output: result.stdout + result.stderr };
    },
  };
}

afterEach(() => {
  while (sandboxes.length > 0) rmSync(sandboxes.pop(), { recursive: true, force: true });
});

const THEME_KNOWN = ["src/theme.css :: .ui-known__a :: color :: #fff", "src/theme.css :: .ui-known__b :: background :: #000000"];
const THEME_FRESH = "src/theme.css :: .ui-fresh__c :: border-color :: #123456";
const THEME_SOFT = "src/theme.css :: .ui-soft__d :: color :: #0f766e";
const TOUCH_KNOWN = ["src/touch.css :: .ui-known__close :: min-height :: 30px"];
const TOUCH_FRESH = "src/touch.css :: .ui-fresh__trigger :: min-height :: 28px";

describe("parseGuardArgs — default baseline resolution", () => {
  const defaultBaseline = join(scriptsDir, "baselines", "theme-tokens.json");
  const missing = join(scriptsDir, "baselines", "does-not-exist.json");

  it("adopts the default baseline on a bare invocation when the file exists", () => {
    // The bug: a bare `node scripts/check-theme-tokens.mjs` resolved to no
    // baseline at all, so every recorded exception failed the build.
    expect(parseGuardArgs([], { defaultBaseline })).toEqual({
      strict: false,
      baseline: defaultBaseline,
      updateBaseline: false,
    });
  });

  it("leaves the baseline unset when the default file does not exist", () => {
    expect(parseGuardArgs([], { defaultBaseline: missing }).baseline).toBe(null);
    expect(parseGuardArgs([], {}).baseline).toBe(null);
    expect(parseGuardArgs([]).baseline).toBe(null);
  });

  it("lets an explicit --baseline win over the default, in both syntaxes", () => {
    expect(parseGuardArgs(["--baseline", "other.json"], { defaultBaseline }).baseline).toBe("other.json");
    expect(parseGuardArgs(["--baseline=other.json"], { defaultBaseline }).baseline).toBe("other.json");
    // …including a path that does not exist yet: the caller asked for it.
    expect(parseGuardArgs(["--baseline", missing], { defaultBaseline }).baseline).toBe(missing);
  });

  it("targets the default for --update-baseline even when the file is not there yet", () => {
    expect(parseGuardArgs(["--update-baseline"], { defaultBaseline: missing })).toEqual({
      strict: false,
      baseline: missing,
      updateBaseline: true,
    });
    expect(parseGuardArgs(["--update-baseline", "--baseline", "other.json"], { defaultBaseline }).baseline).toBe(
      "other.json",
    );
  });

  it("keeps --strict independent of how the baseline was resolved", () => {
    expect(parseGuardArgs(["--strict"], { defaultBaseline })).toEqual({
      strict: true,
      baseline: defaultBaseline,
      updateBaseline: false,
    });
    expect(parseGuardArgs(["--strict"], { defaultBaseline: missing }).strict).toBe(true);
    expect(parseGuardArgs(["--strict", "--update-baseline"], { defaultBaseline })).toEqual({
      strict: true,
      baseline: defaultBaseline,
      updateBaseline: true,
    });
  });

  it("still rejects malformed arguments", () => {
    expect(() => parseGuardArgs(["--nope"], { defaultBaseline })).toThrow(/Unknown argument: --nope/);
    expect(() => parseGuardArgs(["--baseline"], { defaultBaseline })).toThrow(/--baseline needs a file path/);
    expect(() => parseGuardArgs(["--baseline", "--strict"], { defaultBaseline })).toThrow(/--baseline needs a file path/);
  });

  it("resolves each guard's shipped baseline file, which is a baseline for that guard", () => {
    const theme = parseGuardArgs([], { defaultBaseline: join(scriptsDir, "baselines", "theme-tokens.json") });
    const touch = parseGuardArgs([], { defaultBaseline: join(scriptsDir, "baselines", "touch-targets.json") });
    expect(JSON.parse(readFileSync(theme.baseline, "utf8")).guard).toBe("check-theme-tokens");
    expect(JSON.parse(readFileSync(touch.baseline, "utf8")).guard).toBe("check-touch-targets");
  });
});

describe("guard CLI — a bare invocation reads the conventional baseline", () => {
  it("suppresses baselined colours and still fails on a new one", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", THEME_KNOWN);

    const result = sandbox.run("check-theme-tokens.mjs");
    expect(result.status).toBe(1);
    expect(result.stderr).toContain("#123456");
    expect(result.stderr).not.toContain("#fff");
    expect(result.stderr).toContain("2 further violation(s) suppressed by scripts/baselines/theme-tokens.json");
  });

  it("passes when the baseline accounts for everything", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", [...THEME_KNOWN, THEME_FRESH]);

    const result = sandbox.run("check-theme-tokens.mjs");
    expect(result.status).toBe(0);
    expect(result.stdout).toContain("3 known violation(s) held by the baseline");
  });

  it("does the same for the touch target guard", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.touchBaseline, "check-touch-targets", TOUCH_KNOWN);

    const result = sandbox.run("check-touch-targets.mjs");
    expect(result.status).toBe(1);
    expect(result.stderr).toContain(".ui-fresh__trigger");
    expect(result.stderr).not.toContain(".ui-known__close");
    expect(result.stderr).toContain("1 further violation(s) suppressed by scripts/baselines/touch-targets.json");
  });
});

describe("guard CLI — --baseline overrides the default", () => {
  it("reads the given file instead of the conventional one", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", THEME_KNOWN);
    const override = join(sandbox.root, "override.json");
    sandbox.writeBaselineFile(override, "check-theme-tokens", [THEME_FRESH]);

    const result = sandbox.run("check-theme-tokens.mjs", ["--baseline", override]);
    expect(result.status).toBe(1);
    // The override knows only #123456, so the two the default holds now fail.
    expect(result.stderr).toContain("#fff");
    expect(result.stderr).toContain("#000000");
    expect(result.stderr).not.toContain("#123456");
    expect(result.stderr).toContain("1 further violation(s) suppressed by");

    expect(sandbox.run("check-theme-tokens.mjs", [`--baseline=${override}`]).status).toBe(1);
  });
});

describe("guard CLI — a missing default baseline is not a crash", () => {
  it("reports every violation as a failure and never mentions a baseline", () => {
    const sandbox = createGuardSandbox();
    expect(existsSync(sandbox.themeBaseline)).toBe(false);

    const result = sandbox.run("check-theme-tokens.mjs");
    expect(result.status).toBe(1);
    expect(result.stderr).toContain("3 hardcoded colour violation(s).");
    expect(result.stderr).not.toContain("suppressed by");
    expect(result.output).not.toMatch(/ENOENT|Cannot read|is not a guard baseline/);
  });

  it("is also not a crash for the touch target guard", () => {
    const sandbox = createGuardSandbox();
    const result = sandbox.run("check-touch-targets.mjs");
    expect(result.status).toBe(1);
    expect(result.stderr).toContain("2 undersized interactive control(s).");
    expect(result.stderr).not.toContain("suppressed by");
  });
});

describe("guard CLI — --update-baseline still writes", () => {
  it("creates the conventional baseline file when it does not exist", () => {
    const sandbox = createGuardSandbox();
    const result = sandbox.run("check-theme-tokens.mjs", ["--update-baseline"]);

    expect(result.status).toBe(0);
    expect(result.stdout).toContain("wrote baseline of 3 violation(s) to scripts/baselines/theme-tokens.json");
    const written = JSON.parse(readFileSync(sandbox.themeBaseline, "utf8"));
    expect(written.guard).toBe("check-theme-tokens");
    expect(written.total).toBe(3);
    expect(Object.keys(written.entries).sort()).toEqual([...THEME_KNOWN, THEME_FRESH].sort());

    // …and the guard it just recorded still FAILS bare, because none of the
    // three entries is justified. This is the whole point of the ratchet: a
    // `--update-baseline` on its own cannot buy a green build. Somebody has to
    // write down why each exception is acceptable first.
    const unjustified = sandbox.run("check-theme-tokens.mjs");
    expect(unjustified.status).toBe(1);
    expect(unjustified.stderr).toContain("not accountable");

    // With the justifications written in, it passes.
    written.reasons = Object.fromEntries(Object.keys(written.entries).map((key) => [key, THEME_REASON]));
    writeFileSync(sandbox.themeBaseline, `${JSON.stringify(written, null, 2)}\n`, "utf8");
    expect(sandbox.run("check-theme-tokens.mjs").status).toBe(0);
  });

  it("writes to an explicit --baseline path and leaves the default alone", () => {
    const sandbox = createGuardSandbox();
    const target = join(sandbox.root, "nested", "custom.json");

    expect(sandbox.run("check-theme-tokens.mjs", ["--update-baseline", "--baseline", target]).status).toBe(0);
    expect(JSON.parse(readFileSync(target, "utf8")).total).toBe(3);
    expect(existsSync(sandbox.themeBaseline)).toBe(false);
  });

  it("records the soft var() fallback too under --strict", () => {
    const sandbox = createGuardSandbox();
    expect(sandbox.run("check-theme-tokens.mjs", ["--strict", "--update-baseline"]).status).toBe(0);
    const written = JSON.parse(readFileSync(sandbox.themeBaseline, "utf8"));
    expect(written.total).toBe(4);
    expect(Object.keys(written.entries)).toContain(THEME_SOFT);
  });
});

describe("guard CLI — --strict still escalates the soft category", () => {
  it("turns a var() fallback warning into a failure once the hard ones are baselined", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", [...THEME_KNOWN, THEME_FRESH]);

    const lenient = sandbox.run("check-theme-tokens.mjs");
    expect(lenient.status).toBe(0);
    expect(lenient.stderr).toContain("These do not fail the build");

    const strict = sandbox.run("check-theme-tokens.mjs", ["--strict"]);
    expect(strict.status).toBe(1);
    expect(strict.stderr).toContain("#0f766e");
  });

  it("passes under --strict when the baseline also holds the soft violation", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", [
      ...THEME_KNOWN,
      THEME_FRESH,
      THEME_SOFT,
    ]);
    expect(sandbox.run("check-theme-tokens.mjs", ["--strict"]).status).toBe(0);
  });

  it("escalates the touch target review list the same way", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.touchBaseline, "check-touch-targets", [...TOUCH_KNOWN, TOUCH_FRESH]);

    expect(sandbox.run("check-touch-targets.mjs").status).toBe(0);
    const strict = sandbox.run("check-touch-targets.mjs", ["--strict"]);
    expect(strict.status).toBe(1);
    expect(strict.stderr).toContain(".ui-thing__chip");
  });
});

describe("baseline reasons — why each surviving exception is accepted", () => {
  const REASON_A = "declared dense variant: the --sm scale, above the 24px floor";
  const REASON_B = "host-bounded: the largest square its 44px field allows";

  it("carryReasons keeps reasons for surviving keys and drops the rest", () => {
    const previous = {
      reasons: { a: REASON_A, gone: "this exception no longer exists", blank: "   ", wrong: 7 },
    };
    // `blank` and `wrong` are not usable justifications; `gone` no longer has
    // an entry to justify, so its reason goes with it.
    expect(carryReasons(previous, { a: 1, blank: 1, wrong: 1 })).toEqual({ a: REASON_A });
    // `gone` is absent from the new entries, so its reason is not carried.
    expect(carryReasons(previous, { a: 1 })).toEqual({ a: REASON_A });
    expect(carryReasons(previous, { blank: 1, wrong: 1 })).toBe(null);
    expect(carryReasons(null, { a: 1 })).toBe(null);
    expect(carryReasons({}, { a: 1 })).toBe(null);
  });

  it("unexplainedEntries names exactly the entries with nothing written against them", () => {
    const baseline = { entries: { a: 1, b: 2, c: 1 }, reasons: { a: REASON_A, b: "  " } };
    expect(unexplainedEntries(baseline)).toEqual(["b", "c"]);
    expect(unexplainedEntries({ entries: { a: 1 } })).toEqual(["a"]);
    expect(unexplainedEntries(null)).toEqual([]);
  });

  it("serializeBaseline carries the previous reasons onto the rewritten entries", () => {
    const violations = [
      { file: "src/theme.css", selector: ".ui-known__a", property: "color", value: "#fff" },
      { file: "src/theme.css", selector: ".ui-known__b", property: "background", value: "#000000" },
    ];
    const previous = { reasons: { [THEME_KNOWN[0]]: REASON_A, [THEME_FRESH]: "stale" } };
    const written = serializeBaseline("check-theme-tokens", violations, { previous });
    expect(written.reasons).toEqual({ [THEME_KNOWN[0]]: REASON_A });
    // With nothing to carry, the field is simply absent — an older baseline
    // file stays byte-identical in shape.
    expect(serializeBaseline("check-theme-tokens", violations).reasons).toBeUndefined();
  });

  it("--update-baseline preserves reasons instead of silently dropping them", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", THEME_KNOWN, {
      [THEME_KNOWN[0]]: REASON_A,
      [THEME_KNOWN[1]]: REASON_B,
      "src/theme.css :: .ui-deleted__x :: color :: #abcdef": "this violation is gone",
    });

    expect(sandbox.run("check-theme-tokens.mjs", ["--update-baseline"]).status).toBe(0);

    const written = sandbox.readBaselineFile(sandbox.themeBaseline);
    // The regenerated baseline picked up a third violation, and kept both
    // written justifications for the two it already knew.
    expect(Object.keys(written.entries).sort()).toEqual([...THEME_KNOWN, THEME_FRESH].sort());
    expect(written.reasons[THEME_KNOWN[0]]).toBe(REASON_A);
    expect(written.reasons[THEME_KNOWN[1]]).toBe(REASON_B);
    // …and dropped the one whose entry no longer exists.
    expect(written.reasons["src/theme.css :: .ui-deleted__x :: color :: #abcdef"]).toBeUndefined();

    // A second regeneration is a fixed point: nothing decays on the next run.
    expect(sandbox.run("check-theme-tokens.mjs", ["--update-baseline"]).status).toBe(0);
    expect(sandbox.readBaselineFile(sandbox.themeBaseline)).toEqual(written);
  });

  it("does the same for the touch target guard", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.touchBaseline, "check-touch-targets", TOUCH_KNOWN, {
      [TOUCH_KNOWN[0]]: REASON_B,
    });

    expect(sandbox.run("check-touch-targets.mjs", ["--update-baseline"]).status).toBe(0);
    const written = sandbox.readBaselineFile(sandbox.touchBaseline);
    expect(Object.keys(written.entries)).toContain(TOUCH_FRESH);
    expect(written.reasons).toEqual({ [TOUCH_KNOWN[0]]: REASON_B });
  });

  // The ratchet used to live ONLY in a `npm test` assertion — and `npm test` is
  // not in the `build` chain, and the repo has no CI workflow. So
  // `--update-baseline` followed by a green `npm run build` parked a defect
  // with nothing going red anywhere. The guards themselves enforce it now.
  it("FAILS the guard — it does not warn — while a baselined entry has no reason", () => {
    const sandbox = createGuardSandbox();
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", [...THEME_KNOWN, THEME_FRESH], {});

    const bare = sandbox.run("check-theme-tokens.mjs");
    expect(bare.status).toBe(1);
    expect(bare.stderr).toContain("3 baseline entry/entries in scripts/baselines/theme-tokens.json are not accountable");
    expect(bare.stderr).toContain("no reason recorded");

    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", [...THEME_KNOWN, THEME_FRESH]);
    const explained = sandbox.run("check-theme-tokens.mjs");
    expect(explained.status).toBe(0);
    expect(explained.stderr).not.toContain("not accountable");
  });

  it("FAILS on a reason that is present but says nothing", () => {
    const sandbox = createGuardSandbox();
    const keys = [...THEME_KNOWN, THEME_FRESH];
    // Clears the OLD bar (`length > 30`) and says nothing at all.
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", keys, {
      [keys[0]]: "known issue, we will fix this later",
      [keys[1]]: "known issue, we will fix this later",
      [keys[2]]: "known issue, we will fix this later",
    });

    const result = sandbox.run("check-theme-tokens.mjs");
    expect(result.status).toBe(1);
    expect(result.stderr).toContain("not accountable");
  });

  it("FAILS on a baseline key that matches nothing, so it cannot pre-authorise a return", () => {
    const sandbox = createGuardSandbox();
    const gone = "src/theme.css :: .ui-deleted__x :: color :: #abcdef";
    sandbox.writeBaselineFile(sandbox.themeBaseline, "check-theme-tokens", [...THEME_KNOWN, THEME_FRESH, gone]);

    const result = sandbox.run("check-theme-tokens.mjs");
    expect(result.status).toBe(1);
    expect(result.stderr).toContain("matched nothing in the source");
    expect(result.stderr).toContain(gone);
    // …and only that one: the three live entries are not called stale.
    expect(result.stderr).not.toContain(THEME_FRESH);
  });

  it("reasonProblem states the bar, and applyBaseline reports what nothing claimed", () => {
    expect(reasonProblem("")).toBe("no reason recorded");
    expect(reasonProblem("too short to be an argument")).toMatch(/at least 60/);
    expect(reasonProblem(`TODO: ${THEME_REASON}`)).toMatch(/placeholder/);
    expect(reasonProblem(THEME_REASON)).toBe(null);
    // A category vocabulary makes the reason name which exemption it claims.
    const categories = [{ label: "declared dense variant", pattern: /dense variant/i }];
    expect(reasonProblem(THEME_REASON, { categories })).toMatch(/names no declared exemption category/);
    expect(reasonProblem(TOUCH_REASON, { categories })).toBe(null);

    const violation = { file: "s.css", selector: ".a", property: "color", value: "#fff" };
    const baseline = { entries: { [violationKey(violation)]: 2, "s.css :: .gone :: color :: #000": 1 } };
    const applied = applyBaseline([violation], baseline);
    expect(applied.stale).toEqual(["s.css :: .gone :: color :: #000"]);
    expect(applied.overProvisioned).toEqual([{ key: violationKey(violation), budget: 2, matched: 1 }]);
  });

  it("every entry in each SHIPPED baseline carries a justification that meets the bar", () => {
    // The point of the field: the repo's own baselines must never contain an
    // exception nobody can account for. The guards enforce this themselves now;
    // this keeps the assertion where a reader looks for it, and checks both
    // shipped baselines against their own guard's exemption categories.
    const categoriesFor = { "theme-tokens": THEME_CATEGORIES, "touch-targets": TOUCH_CATEGORIES };
    for (const guard of ["theme-tokens", "touch-targets"]) {
      const baseline = JSON.parse(readFileSync(join(scriptsDir, "baselines", `${guard}.json`), "utf8"));
      expect({ guard, unexplained: unexplainedEntries(baseline) }).toEqual({ guard, unexplained: [] });
      expect({ guard, problems: inadequateReasons(baseline, { categories: categoriesFor[guard] }) }).toEqual({
        guard,
        problems: [],
      });
    }
  });
});

describe("serializeBaseline round trip", () => {
  it("writes a file the guard reads back and fully suppresses", () => {
    const sandbox = createGuardSandbox();
    const violations = [
      { file: "src/theme.css", selector: ".ui-known__a", property: "color", value: "#fff" },
      { file: "src/theme.css", selector: ".ui-known__b", property: "background", value: "#000000" },
      { file: "src/theme.css", selector: ".ui-fresh__c", property: "border-color", value: "#123456" },
    ];
    const baseline = serializeBaseline("check-theme-tokens", violations, {
      previous: { reasons: Object.fromEntries(violations.map((v) => [violationKey(v), THEME_REASON])) },
    });
    mkdirSync(join(sandbox.themeBaseline, ".."), { recursive: true });
    writeFileSync(sandbox.themeBaseline, `${JSON.stringify(baseline, null, 2)}\n`, "utf8");

    expect(sandbox.run("check-theme-tokens.mjs").status).toBe(0);
  });
});
