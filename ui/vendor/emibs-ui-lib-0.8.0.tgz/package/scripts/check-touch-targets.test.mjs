import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import {
  THEME_LENGTH_TOKENS,
  collectClickableElements,
  collectLengthTokens,
  elementSignature,
  findTouchTargetViolations,
  isVisuallyHidden,
  lastCompound,
  parseBaselineKey,
  resolveLengthPx,
  subFloorBaselineReport,
} from "./check-touch-targets.mjs";
import { parseCss } from "./css-source.mjs";
import { applyBaseline, serializeBaseline, violationKey } from "./guard-baseline.mjs";
// The authoritative table these guard values must track. Imported straight
// from the theme so the pin below has no chance to restate a number itself.
import { foundationalTokens } from "../src/theme/tokens.ts";

const fixture = (name) => readFileSync(new URL(`./fixtures/touch-target-gate/${name}`, import.meta.url), "utf8");

// Length tokens come from the sources under test, exactly as they do in the
// real run — the `:root` block in src/styles.css is what makes
// `calc(var(--space-6) + var(--space-2))` a number the guard can judge.
const check = (file, source) =>
  findTouchTargetViolations(
    file,
    source,
    collectClickableElements([{ file, source }]),
    collectLengthTokens([{ file, source }]),
  );
const run = (name) => check(`fixtures/${name}`, fixture(name));
const shape = (violations) =>
  violations.map((violation) => `${violation.selector} | ${violation.property}: ${violation.value}`);
const selectors = (violations) => [...new Set(violations.map((violation) => violation.selector))];

describe("touch target gate — clean source", () => {
  it("passes controls sized at or above 44px", () => {
    const { hard, review } = run("clean.css");
    expect(hard).toEqual([]);
    expect(review).toEqual([]);
  });
});

describe("touch target gate — undersized interactive controls", () => {
  const { hard, review } = run("undersized-controls.css");

  it("fails every interactive signal in the real BEM vocabulary", () => {
    expect(selectors(hard)).toEqual([
      ".ui-panel__close",
      ".ui-panel__tab",
      ".ui-panel__trigger",
      ".ui-panel__link",
      ".ui-panel__action",
      ".ui-panel__toggle",
      ".ui-toolbar button",
      ".ui-form input, .ui-form select, .ui-form textarea",
      ".ui-card a",
      '.ui-menu__entry[role="button"]',
      ".ui-button--sm",
      ".ui-icon-button--sm",
      "@media (max-width: 600px) .ui-panel__close",
    ]);
    expect(review).toEqual([]);
  });

  it("covers all four size properties", () => {
    expect([...new Set(hard.map((violation) => violation.property))].sort()).toEqual([
      "height",
      "min-height",
      "min-width",
      "width",
    ]);
  });

  it("records the measured px and the signal that made it interactive", () => {
    const close = hard.find((violation) => violation.selector === ".ui-panel__close");
    expect(close.px).toBe(34);
    expect(close.note).toBe("__close");
    expect(hard.find((violation) => violation.selector === ".ui-card a").note).toBe("<a>");
    expect(hard.find((violation) => violation.selector.includes("[role=")).note).toBe('[role="button"]');
  });
});

describe("touch target gate — exclusions", () => {
  it("never flags non-interactive decoration", () => {
    const { hard, review } = run("decoration.css");
    expect(hard).toEqual([]);
    expect(review).toEqual([]);
  });

  it("reads the LAST word of a BEM element name, so __tab-badge is a badge", () => {
    const { hard } = check(
      "inline.css",
      `.ui-tabs__tab-badge { min-height: 20px; }\n.ui-switch__toggle-track { height: 24px; }\n`,
    );
    expect(hard).toEqual([]);
  });

  it("never flags the visually-hidden 1x1 input pattern, in any of its variants", () => {
    const { hard, review } = run("visually-hidden.css");
    expect(hard).toEqual([]);
    expect(review).toEqual([]);
  });

  it("recognises sr-only by position + clip / opacity / pointer-events / off-screen", () => {
    const blockFor = (css) => parseCss(css).blocks.find((block) => block.declarations.length > 0);
    expect(isVisuallyHidden(blockFor(".a { position: absolute; width: 1px; clip: rect(0 0 0 0); }"))).toBe(true);
    expect(isVisuallyHidden(blockFor(".a { position: absolute; width: 1px; opacity: 0; }"))).toBe(true);
    expect(isVisuallyHidden(blockFor(".a { position: absolute; width: 1px; pointer-events: none; }"))).toBe(true);
    expect(isVisuallyHidden(blockFor(".a { position: absolute; left: -10000px; width: 1px; }"))).toBe(true);
    // A normally positioned small control is NOT the sr-only pattern.
    expect(isVisuallyHidden(blockFor(".a { position: relative; width: 30px; opacity: 0; }"))).toBe(false);
    expect(isVisuallyHidden(blockFor(".a { position: absolute; top: 12px; width: 30px; }"))).toBe(false);
  });

  it("never flags a DECLARATION sized by --control-min-height, a resolvable density token, min-*: 0 or a relative unit", () => {
    const { hard, review } = run("token-sized.css");
    expect(hard).toEqual([]);
    expect(review).toEqual([]);
  });

  it("never flags an animation keyframe", () => {
    const { hard, review } = run("keyframes.css");
    expect(hard).toEqual([]);
    expect(review).toEqual([]);
  });
});

describe("touch target gate — units and expressions, not just a bare px literal", () => {
  // The guard used to match `/^\d+px$/` on four physical properties. Every
  // declaration in this fixture is under the standard and used to pass in
  // silence — the logical-property spellings most consequentially, because they
  // are how materialControls.css sizes the whole Button/Menu/Breadcrumb/Tooltip
  // family, which the a11y gate could not see at all.
  const { hard, review } = run("units-and-expressions.css");

  it("reads rem, em, calc(), clamp(), max-* and the logical properties", () => {
    expect(shape(hard)).toEqual([
      ".ui-expr__button | min-block-size: calc(var(--space-6) + var(--space-2))",
      ".ui-expr__close | inline-size: 36px",
      ".ui-expr__close | block-size: 36px",
      ".ui-expr__link | min-inline-size: 30px",
      ".ui-expr__tab | min-height: 2rem",
      ".ui-expr__toggle | height: 1.75em",
      ".ui-expr__trigger | max-height: 28px",
      ".ui-expr__action | max-block-size: 2rem",
      ".ui-expr__submit | min-height: calc(var(--space-6) + var(--space-1))",
      ".ui-expr__reset | min-height: clamp(28px, 5vw, 60px)",
      ".ui-expr__reveal | min-block-size: 1rem",
    ]);
    expect(review).toEqual([]);
  });

  it("resolves each expression to the smallest size it can produce", () => {
    const px = (selector) => hard.find((violation) => violation.selector === selector).px;
    expect(px(".ui-expr__button")).toBe(40); // 32 + 8
    expect(px(".ui-expr__tab")).toBe(32); // 2rem at the 16px root default
    expect(px(".ui-expr__toggle")).toBe(28); // 1.75em, same basis
    expect(px(".ui-expr__reset")).toBe(28); // clamp()'s guaranteed minimum
    expect(px(".ui-expr__reveal")).toBe(16); // below the 24px floor
  });

  it("names the floor breach specifically, because rule 1 outranks every tier", () => {
    // 1rem = 16px is under the absolute floor, not merely under the standard.
    expect(hard.find((violation) => violation.selector === ".ui-expr__reveal").px).toBeLessThan(24);
  });

  it("resolves a length expression to its lower bound, or says it cannot", () => {
    const tokens = { "--space-6": 32, "--space-2": 8, "--control-min-height": 44 };
    expect(resolveLengthPx("calc(var(--space-6) + var(--space-2))", tokens)).toBe(40);
    expect(resolveLengthPx("calc(var(--space-6) * 8)", tokens)).toBe(256);
    expect(resolveLengthPx("clamp(20px, 5vw, 60px)", tokens)).toBe(20);
    expect(resolveLengthPx("max(30px, 5vw)", tokens)).toBe(30);
    // min() needs every term: an unresolvable one could be the smallest.
    expect(resolveLengthPx("min(30px, var(--unknown))", tokens)).toBe("unresolved");
    // Not a fixed size at all.
    expect(resolveLengthPx("auto", tokens)).toBe(null);
    expect(resolveLengthPx("100%", tokens)).toBe(null);
    expect(resolveLengthPx("max-content", tokens)).toBe(null);
    expect(resolveLengthPx("calc(100vh - 24px)", tokens)).toBe(null);
    expect(resolveLengthPx("0", tokens)).toBe(null);
    // A size expression it genuinely cannot pin down: review, not a pass.
    expect(resolveLengthPx("var(--component-local-width)", tokens)).toBe("unresolved");
  });

  it("sends an unresolvable size on a proven control to review rather than passing it", () => {
    const { hard: unknownHard, review: unknownReview } = check(
      "inline.css",
      `.ui-a__close { min-block-size: var(--component-local-height); }`,
    );
    expect(unknownHard).toEqual([]);
    expect(shape(unknownReview)).toEqual([".ui-a__close | min-block-size: var(--component-local-height)"]);
  });
});

describe("touch target gate — the token exemption is per declaration, not per block", () => {
  const { hard, review } = run("token-exemption-scope.css");

  it("does not let a density token on one property exempt a hardcoded size on another", () => {
    expect(shape(hard)).toEqual([
      ".ui-probe__close | min-height: 20px",
      ".ui-probe__toggle | height: 32px",
      ".ui-probe__tab | min-block-size: var(--density-gap-compact, 8px)",
    ]);
  });

  it("holds the 24px floor above the dense tier", () => {
    const floorBreaches = hard.filter((violation) => violation.px !== null && violation.px < 24);
    expect(shape(floorBreaches)).toEqual([
      ".ui-probe__close | min-height: 20px",
      ".ui-probe__tab | min-block-size: var(--density-gap-compact, 8px)",
    ]);
    expect(hard.find((violation) => violation.selector === ".ui-probe__tab").note).toContain("below the 24px floor");
  });

  it("sends --density-control-height to review: it is defined nowhere in CSS, so it is no floor at all", () => {
    expect(shape(review)).toEqual([".ui-probe__trigger | min-height: var(--density-control-height)"]);
    expect(review[0].note).toContain("<DensityScope>");
  });
});

describe("touch target gate — ambiguous selectors go to review, not failure", () => {
  it("lists chips, field wrappers and native check glyphs for review only", () => {
    const { hard, review } = run("ambiguous.css");
    expect(hard).toEqual([]);
    expect(shape(review)).toEqual([
      ".ui-filter__chip | min-height: 30px",
      ".ui-field__control | min-height: 42px",
      '.ui-form input[type="checkbox"] | width: 16px',
      '.ui-form input[type="checkbox"] | height: 16px',
      ".ui-form__check input | width: 16px",
      ".ui-form__check input | height: 16px",
    ]);
    expect(review.filter((violation) => violation.note.startsWith("native"))).toHaveLength(4);
  });
});

describe("touch target gate — cursor: pointer evidence", () => {
  const { hard, review } = run("clickable-evidence.css");

  it("promotes an ambiguous element the stylesheet itself styles as clickable", () => {
    expect(shape(hard)).toEqual([
      ".ui-nav__item | min-height: 40px",
      ".ui-nav--compact .ui-nav__item | min-height: 32px",
      ".ui-dialog__close-icon | min-height: 28px",
    ]);
  });

  it("lets cursor: pointer on the rule beat a decoration-sounding name", () => {
    // The evasion: renaming `__close` to `__close-icon` used to retire a
    // control from the guard outright, because the decoration check ran ahead
    // of both the control-name check and the pointer evidence.
    const renamed = hard.find((violation) => violation.selector === ".ui-dialog__close-icon");
    expect(renamed.note).toBe("cursor: pointer on this rule");
  });

  it("leaves the same BEM name in review when nothing proves it clickable", () => {
    expect(shape(review)).toContain(".ui-plain__item | min-height: 30px");
  });

  it("downgrades decoration proved clickable only ELSEWHERE to review, never to a failure", () => {
    expect(shape(review)).toContain(".ui-card__pin | width: 30px");
    expect(shape(hard)).not.toContain(".ui-card__pin | width: 30px");
  });

  it("does not let one clickable span make every span interactive", () => {
    expect(shape(hard)).not.toContain(".ui-legend span | min-height: 20px");
    expect(shape(review)).not.toContain(".ui-legend span | min-height: 20px");
    expect(elementSignature("span")).toBe("");
  });

  it("shares evidence between a block and its modifier rules", () => {
    expect(elementSignature(".ui-nav--compact .ui-nav__item")).toBe("ui-nav__item");
    expect(elementSignature(".ui-nav__item--wide")).toBe("ui-nav__item");
    expect(elementSignature(".ui-nav__item.is-active")).toBe("ui-nav__item");
    expect(lastCompound(".ui-nav--compact > .ui-nav__item:hover")).toBe(".ui-nav__item:hover");
    expect(lastCompound('.ui-menu li[data-role="x y"]')).toBe('li[data-role="x y"]');
  });
});

describe("touch target gate — an unrecognised name is review, not silence", () => {
  // The review bucket used to be an unbounded SILENT channel: anything whose
  // BEM name was in none of the three hand-written vocabularies fell out of
  // classifyCompound as `null`. Those vocabularies were written from the
  // stylesheet as it stood, so every name coined afterwards was invisible.
  it("reports a name it has never seen for a human to classify", () => {
    const { hard, review } = check("inline.css", `.ui-widget__doohickey { min-height: 30px; }`);
    expect(hard).toEqual([]);
    expect(shape(review)).toEqual([".ui-widget__doohickey | min-height: 30px"]);
    expect(review[0].note).toContain("unclassified name");
  });

  it("reads the decoration and ambiguity vocabularies on block names too", () => {
    // `.ui-signal-dot` is a dot; `.ui-filter-chip` is a chip. Both used to be
    // judged only when the name had a `__element` part, which left every
    // block-level name unclassified.
    const { hard, review } = check(
      "inline.css",
      `.ui-signal-dot { width: 8px; }\n.ui-filter-chip { min-height: 30px; }\n`,
    );
    expect(hard).toEqual([]);
    expect(shape(review)).toEqual([".ui-filter-chip | min-height: 30px"]);
  });

  it("stays silent for a bare element selector, which has no identity to classify", () => {
    const { hard, review } = check("inline.css", `.ui-legend span { min-height: 20px; }`);
    expect(hard).toEqual([]);
    expect(review).toEqual([]);
  });
});

describe("touch target gate — baseline", () => {
  const source = `.ui-a__close { width: 30px; }\n.ui-b__tab { min-height: 32px; }\n`;

  it("keys entries by selector + property + value, not by line number", () => {
    const before = check("s.css", source).hard;
    const shifted = check("s.css", `\n\n/* unrelated edit above */\n${source}`).hard;
    expect(shifted[0].line).not.toBe(before[0].line);
    expect(shifted.map(violationKey)).toEqual(before.map(violationKey));
  });

  it("fails only on violations the baseline does not record", () => {
    const baseline = serializeBaseline("check-touch-targets", check("s.css", source).hard);
    expect(applyBaseline(check("s.css", source).hard, baseline).fresh).toEqual([]);

    const added = check("s.css", `${source}.ui-c__trigger { min-height: 28px; }\n`).hard;
    expect(shape(applyBaseline(added, baseline).fresh)).toEqual([".ui-c__trigger | min-height: 28px"]);
  });
});

// Rule 1 is absolute and outranks the baseline itself. Before this check, the
// only thing stopping a sub-floor control from being shelved as an "accepted
// exception" was whoever reviewed the JSON — the three exemption categories all
// accept a size of any value, so a 12px button could be filed as a dense tier
// and read as a decision. The one honest sub-floor entry is a checkbox/radio
// glyph under rule 5, where the guard matched the glyph INSTEAD of the wrapping
// <label> that carries the target, and it now has to say so in those words.
describe("touch target gate — the 24px floor is not baselineable", () => {
  const withReason = (key, reason) => ({
    guard: "check-touch-targets",
    version: 1,
    total: 1,
    entries: { [key]: 1 },
    reasons: { [key]: reason },
  });
  const denseTier = "Declared dense variant - accepted by the dense tier, a deliberate density tradeoff here.";
  const glyph =
    "Guard artifact - the rule does not size the control the guard matched: a native checkbox glyph, which " +
    "TOUCH-TARGETS rule 5 says must not be enlarged; the target is the wrapping <label>.";
  const report = (baseline) => subFloorBaselineReport(baseline, THEME_LENGTH_TOKENS, { label: "b.json" });

  it("splits a baseline key back into the property and value it recorded", () => {
    expect(parseBaselineKey("s.css :: .ui-a__close, .ui-b :: min-height :: 12px")).toEqual({
      property: "min-height",
      value: "12px",
    });
    expect(parseBaselineKey("not a key")).toBeNull();
  });

  it("rejects a sub-floor entry filed under any category other than the rule 5 glyph", () => {
    const failed = report(withReason("s.css :: .ui-a__close :: min-height :: 12px", denseTier));
    expect(failed).toContain(".ui-a__close");
    expect(failed).toContain("resolves to 12px");
  });

  it("accepts a sub-floor entry that identifies itself as a rule 5 checkbox/radio glyph", () => {
    expect(report(withReason('s.css :: .ui-a__check input :: width :: 16px', glyph))).toBeNull();
  });

  it("resolves the recorded value rather than trusting the literal text", () => {
    // var(--density-control-height-compact) is 32px and passes; a token below
    // the floor would not, and neither would the same number written in rem.
    expect(report(withReason("s.css :: .ui-a :: min-height :: var(--density-control-height-compact)", denseTier))).toBeNull();
    expect(report(withReason("s.css :: .ui-a :: min-height :: 1rem", denseTier))).toContain("resolves to 16px");
  });

  it("ignores entries at or above the floor, and `min-*: 0`, which declares no floor at all", () => {
    expect(report(withReason("s.css :: .ui-a :: min-height :: 24px", denseTier))).toBeNull();
    expect(report(withReason("s.css :: .ui-a :: min-width :: 0", denseTier))).toBeNull();
  });

  it("holds the shipped baseline: every sub-floor entry in it is a rule 5 glyph", () => {
    const baseline = JSON.parse(readFileSync(new URL("./baselines/touch-targets.json", import.meta.url), "utf8"));
    const styles = readFileSync(new URL("../src/styles.css", import.meta.url), "utf8");
    const tokens = collectLengthTokens([{ file: "src/styles.css", source: styles }]);
    expect(subFloorBaselineReport(baseline, tokens, { label: "shipped" })).toBeNull();

    // …and the check is not passing vacuously: the shipped baseline really does
    // hold sub-floor entries for it to have judged.
    const subFloor = Object.keys(baseline.entries).filter((key) => {
      const parsed = parseBaselineKey(key);
      const px = parsed && resolveLengthPx(parsed.value, tokens);
      return typeof px === "number" && px < 24;
    });
    expect(subFloor.length).toBeGreaterThan(0);
  });
});

// THEME_LENGTH_TOKENS restates theme values in JavaScript so the guard can
// resolve `var(--control-min-height)` without booting React. That makes it a
// SECOND copy of numbers src/theme/tokens.ts owns, and `:root` in
// src/styles.css a THIRD. Nothing verified any of them against each other, so
// a theme that moved `--control-min-height` to 40px would leave the guard
// still measuring against 44 — silently checking a number the product no
// longer uses. These tests pin all three together; tokens.ts is the authority
// and the other two must follow it.
describe("touch target gate — theme length tokens are pinned to src/theme/tokens.ts", () => {
  // foundationalTokens already spreads densityTokens, so it is the single list
  // that carries every non-brand token a packaged theme ships.
  const themeValues = new Map(foundationalTokens.map((token) => [token.name, token.value]));
  // The size-FLOOR tokens: the standard itself plus the density scale's control
  // and row heights. Deliberately not the gap/padding entries — those size the
  // space around a control, not the control's own box.
  const floorTokenPattern = /^(?:--control-min-height|--density-(?:control|row)-height-[a-z]+)$/;

  it("carries exactly the theme's size-floor tokens, at exactly the theme's values", () => {
    const expected = Object.fromEntries(
      foundationalTokens
        .filter((token) => floorTokenPattern.test(token.name))
        .map((token) => [token.name, resolveLengthPx(token.value, {})]),
    );
    // Guards against a value edit on either side AND against the sets drifting:
    // a token added to the density scale but not to the guard fails here, as
    // does a guard entry for a token no theme declares.
    expect(THEME_LENGTH_TOKENS).toEqual(expected);
  });

  it("names only tokens the theme actually defines", () => {
    for (const name of Object.keys(THEME_LENGTH_TOKENS)) {
      expect(themeValues.has(name), `${name} is not declared in foundationalTokens`).toBe(true);
    }
  });

  // The `:root` copy is the defensive floor for markup rendered outside a
  // <ThemeScope> (see the comment on the block itself). It is a deliberate
  // SUBSET — the row heights are intentionally absent — so this asserts
  // agreement for what it does declare rather than demanding the full set,
  // which would fail the moment someone correctly narrowed the defensive copy.
  it("agrees with the `:root` defensive copy in src/styles.css", () => {
    const styles = readFileSync(new URL("../src/styles.css", import.meta.url), "utf8");
    const declared = new Map();
    for (const block of parseCss(styles, "src/styles.css").blocks) {
      if (!block.selectors.includes(":root")) continue;
      for (const declaration of block.declarations) {
        if (THEME_LENGTH_TOKENS[declaration.property] !== undefined) {
          declared.set(declaration.property, declaration.value.trim());
        }
      }
    }
    // If this is empty the test has stopped proving anything — fail loudly
    // rather than pass vacuously on a parse or rename.
    expect(declared.size).toBeGreaterThan(0);
    for (const [name, value] of declared) {
      expect(value, `:root ${name} must match src/theme/tokens.ts`).toBe(themeValues.get(name));
    }
  });
});
