import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, isAbsolute, relative, sep } from "node:path";

// Shared CLI/baseline plumbing for the stylesheet guards. A guard can be wired
// into the build immediately, before its backlog is burned down, by recording
// the current violation set as a baseline: only violations that are NOT in the
// baseline fail. Entries are keyed by file + selector + property + value and
// never by line number, so unrelated edits above a violation do not invalidate
// the baseline (the whole point — src/styles.css is ~32.5k lines and several
// agents edit it concurrently).

const BASELINE_VERSION = 1;

export function parseGuardArgs(argv, { defaultBaseline = null } = {}) {
  const options = { strict: false, baseline: null, updateBaseline: false };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === "--strict") {
      options.strict = true;
    } else if (arg === "--update-baseline") {
      options.updateBaseline = true;
    } else if (arg === "--baseline") {
      const next = argv[i + 1];
      if (!next || next.startsWith("--")) throw new Error("--baseline needs a file path");
      options.baseline = next;
      i += 1;
    } else if (arg.startsWith("--baseline=")) {
      options.baseline = arg.slice("--baseline=".length);
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  // Resolve the baseline the guard will use when `--baseline` was not given.
  //
  // A bare invocation (`node scripts/check-theme-tokens.mjs`, i.e. exactly what
  // `npm run check:theme` runs) MUST pick up the conventional baseline file:
  // without it the guard fails on every recorded exception, which would make it
  // impossible to wire into `npm run build` — the whole point of the mechanism.
  //
  // `--update-baseline` writes that same file, and writes it even when it does
  // not exist yet (that is how a baseline is first recorded). A read, by
  // contrast, only adopts the default when the file is actually there; leaving
  // `baseline` null keeps `loadBaseline` a no-op and the log label honest
  // ("(none)"), so a missing baseline reports every violation as a failure
  // rather than crashing.
  if (!options.baseline && defaultBaseline) {
    if (options.updateBaseline || existsSync(defaultBaseline)) options.baseline = defaultBaseline;
  }
  return options;
}

/**
 * Stable identity of a violation. Deliberately excludes the line number: a
 * violation "moves" whenever anything above it changes, and a baseline that
 * churned on every unrelated edit would be useless.
 */
export function violationKey(violation) {
  return [violation.file, violation.selector, violation.property, violation.value].join(" :: ");
}

function countByKey(violations) {
  const counts = new Map();
  for (const violation of violations) {
    const key = violationKey(violation);
    counts.set(key, (counts.get(key) ?? 0) + 1);
  }
  return counts;
}

/**
 * Reasons carried forward across an `--update-baseline`.
 *
 * A baseline of unexplained exceptions rots exactly like the hardcoded values
 * it was recorded to hold: nobody can tell an accepted design decision from a
 * defect somebody shelved. So every entry carries a short written
 * justification in a sibling `reasons` map, keyed identically to `entries`
 * (same `file :: selector :: property :: value` key), and `--update-baseline`
 * PRESERVES those reasons instead of silently dropping them.
 *
 * A sibling map rather than a per-entry object because `entries` values are
 * occurrence counts that `applyBaseline` decrements: keeping the count a bare
 * number keeps that budgeting logic and every existing baseline file valid.
 *
 * Reasons for keys that no longer violate anything are dropped — the exception
 * is gone, so its justification is too.
 */
export function carryReasons(previous, entries) {
  const source = previous && typeof previous.reasons === "object" && previous.reasons ? previous.reasons : null;
  if (!source) return null;
  const reasons = {};
  for (const key of Object.keys(entries).sort()) {
    const reason = source[key];
    if (typeof reason === "string" && reason.trim() !== "") reasons[key] = reason;
  }
  return Object.keys(reasons).length > 0 ? reasons : null;
}

/** Baselined keys with no recorded justification — the entries that would rot. */
export function unexplainedEntries(baseline) {
  if (!baseline || typeof baseline.entries !== "object" || !baseline.entries) return [];
  const reasons = typeof baseline.reasons === "object" && baseline.reasons ? baseline.reasons : {};
  return Object.keys(baseline.entries).filter((key) => {
    const reason = reasons[key];
    return typeof reason !== "string" || reason.trim() === "";
  });
}

// ---------------------------------------------------------------------------
// The justification ratchet.
//
// A baseline is a promise that every entry in it is an ACCEPTED decision rather
// than a shelved defect, and the only thing that can keep that promise is a
// written reason somebody can check. Two things were wrong before:
//
//   1. The check lived only in `npm test`, which is not in the `build` chain and
//      has no CI workflow behind it, so `--update-baseline` + `npm run build`
//      parked a defect silently. The guards themselves now FAIL on it.
//   2. The bar was `reason.length > 30` — "known issue, fix later, see ticket"
//      clears 30 characters and says nothing. The bar below asks for a reason
//      that is long enough to be an argument and CONCRETE enough to be checked
//      against the code: it must point at a selector, a token, a file or a
//      named rule of the contract it is claiming an exemption from.
//
// Deliberately not a taste test: it cannot tell a good argument from a bad one.
// It can only refuse the reasons that are obviously not arguments at all, which
// is the difference between "somebody had to justify this" and "somebody had to
// type 31 characters".
// ---------------------------------------------------------------------------

const MIN_REASON_CHARACTERS = 60;
const MIN_REASON_WORDS = 10;

// A reason that OPENS with one of these is a note about the future, not a
// justification for the present. Anchored to the start deliberately: "the guard
// cannot see the later override" is a real argument that happens to contain the
// word "later", and a blacklist of ordinary English words would reject good
// reasons — which is how bars get lowered again.
const PLACEHOLDER_OPENING = /^\W*(?:tbd|todo|to do|fixme|wip|n\/a|xxx|later|temporary|unknown|none|no reason|see (?:above|ticket|issue))\b/i;

/**
 * Why one baseline reason is not usable, or `null` when it is fine.
 *
 * `categories` is the guard's own list of exemptions it is willing to grant, as
 * `{ label, pattern }`. Requiring the reason to NAME one is the part that makes
 * this more than a length check: it forces the author to say which declared
 * exemption they are claiming, so a reader can check the claim against the code
 * and a reviewer can see when somebody invents a new category. A guard that
 * passes no categories gets the generic bar only.
 *
 * It cannot tell a good argument from a bad one — nothing static can. It can
 * refuse the things that are not arguments at all, which is the difference
 * between "somebody had to justify this" and "somebody had to type 31
 * characters", which is what `reason.length > 30` actually asked for.
 */
export function reasonProblem(reason, { categories = [] } = {}) {
  if (typeof reason !== "string" || reason.trim() === "") return "no reason recorded";
  const text = reason.trim();
  if (text.length < MIN_REASON_CHARACTERS) {
    return `reason is ${text.length} characters; at least ${MIN_REASON_CHARACTERS} are needed to state an argument`;
  }
  const words = text.split(/\s+/).filter(Boolean);
  if (words.length < MIN_REASON_WORDS) {
    return `reason is ${words.length} words; at least ${MIN_REASON_WORDS} are needed to state an argument`;
  }
  if (PLACEHOLDER_OPENING.test(text)) return "reason opens as a placeholder, not a justification";
  if (categories.length > 0 && !categories.some(({ pattern }) => pattern.test(text))) {
    return `reason names no declared exemption category (${categories.map(({ label }) => label).join(", ")})`;
  }
  return null;
}

/**
 * Every baseline entry whose justification does not meet the bar, as
 * `{ key, problem }`. This is a superset of `unexplainedEntries`: a missing
 * reason is reported here too, as "no reason recorded".
 */
export function inadequateReasons(baseline, options = {}) {
  if (!baseline || typeof baseline.entries !== "object" || !baseline.entries) return [];
  const reasons = typeof baseline.reasons === "object" && baseline.reasons ? baseline.reasons : {};
  const problems = [];
  for (const key of Object.keys(baseline.entries).sort()) {
    const problem = reasonProblem(reasons[key], options);
    if (problem) problems.push({ key, problem });
  }
  return problems;
}

/**
 * Build the baseline file contents. Pass the currently-recorded baseline as
 * `previous` (the guards read it before they overwrite it) so that the written
 * justifications survive the rewrite.
 */
export function serializeBaseline(guard, violations, { previous = null } = {}) {
  const counts = countByKey(violations);
  const entries = {};
  for (const key of [...counts.keys()].sort()) entries[key] = counts.get(key);
  const baseline = { guard, version: BASELINE_VERSION, total: violations.length, entries };
  const reasons = carryReasons(previous, entries);
  if (reasons) baseline.reasons = reasons;
  return baseline;
}

export function loadBaseline(path) {
  if (!path || !existsSync(path)) return null;
  const parsed = JSON.parse(readFileSync(path, "utf8"));
  if (!parsed || typeof parsed !== "object" || typeof parsed.entries !== "object") {
    throw new Error(`Baseline ${path} is not a guard baseline file`);
  }
  return parsed;
}

/** Package-relative path for log lines, so output does not leak absolute paths. */
export function baselineLabel(packageRoot, path) {
  if (!path) return "(none)";
  return isAbsolute(path) ? relative(packageRoot, path).split(sep).join("/") : path;
}

export function writeBaseline(path, baseline) {
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, `${JSON.stringify(baseline, null, 2)}\n`, "utf8");
}

/**
 * Split violations into those the baseline already accounts for and those it
 * does not. Counts matter: a baseline entry recorded twice tolerates two
 * occurrences and fails on a third, so duplicating a known-bad declaration is
 * still caught.
 *
 * Also reports what the baseline pre-authorised and nothing claimed:
 *
 * - `stale` — keys that matched NO violation at all. The rule they were
 *   recorded against is gone (renamed, deleted, fixed), but the key survives,
 *   silently holding the door open for that exact violation to come back later
 *   with nobody noticing. A baseline is a list of things that exist; a key for
 *   something that does not exist is a standing pre-authorisation.
 * - `overProvisioned` — keys that matched fewer times than they budget for, as
 *   `{ key, budget, matched }`. Same failure, one occurrence at a time.
 */
export function applyBaseline(violations, baseline) {
  if (!baseline) return { fresh: violations, suppressed: [], stale: [], overProvisioned: [] };
  const budgets = new Map(Object.entries(baseline.entries));
  const remaining = new Map(budgets);
  const fresh = [];
  const suppressed = [];
  for (const violation of violations) {
    const key = violationKey(violation);
    const budget = remaining.get(key) ?? 0;
    if (budget > 0) {
      remaining.set(key, budget - 1);
      suppressed.push(violation);
    } else {
      fresh.push(violation);
    }
  }
  const stale = [];
  const overProvisioned = [];
  for (const [key, budget] of budgets) {
    const left = remaining.get(key) ?? 0;
    if (left <= 0) continue;
    if (left === budget) stale.push(key);
    else overProvisioned.push({ key, budget, matched: budget - left });
  }
  return { fresh, suppressed, stale: stale.sort(), overProvisioned };
}

/**
 * Baseline drift measured against EVERY violation the guard can see, not just
 * the subset the current mode enforces.
 *
 * `applyBaseline` runs over one bucket at a time (hard only, unless `--strict`
 * adds the soft/review bucket), so its `stale` list would call a soft-category
 * entry stale on a lenient run. This takes the union, so the answer does not
 * depend on the flags the guard was invoked with.
 */
export function baselineDrift(baseline, allViolations) {
  if (!baseline) return { stale: [], overProvisioned: [] };
  const counts = countByKey(allViolations);
  const stale = [];
  const overProvisioned = [];
  for (const [key, budget] of Object.entries(baseline.entries)) {
    const matched = counts.get(key) ?? 0;
    if (matched >= budget) continue;
    if (matched === 0) stale.push(key);
    else overProvisioned.push({ key, budget, matched });
  }
  return { stale: stale.sort(), overProvisioned };
}

/**
 * The two things that make a baseline dishonest, rendered as failure text:
 * an entry nobody justified, and an entry nothing matches. Returns `null` when
 * the baseline is clean (or absent).
 *
 * Both FAIL the guard rather than warn. They used to be a `npm test` assertion
 * and a nudge on stderr respectively — neither of which is in the `build`
 * chain, so `--update-baseline` followed by a green build parked a defect with
 * nothing going red anywhere.
 */
export function baselineIntegrityReport(baseline, allViolations, { label = "(none)", categories = [] } = {}) {
  if (!baseline) return null;
  const problems = inadequateReasons(baseline, { categories });
  const { stale, overProvisioned } = baselineDrift(baseline, allViolations);
  if (problems.length === 0 && stale.length === 0 && overProvisioned.length === 0) return null;

  const lines = [];
  if (problems.length > 0) {
    lines.push(
      `\n${problems.length} baseline entry/entries in ${label} are not accountable. Every entry is a` +
        '\nrecorded EXCEPTION, so each one needs a written justification under "reasons", keyed the' +
        "\nsame as the entry, naming the selector/token/file or contract rule it relies on:\n",
    );
    for (const { key, problem } of problems) lines.push(`  - ${key}\n      ${problem}`);
  }
  if (stale.length > 0) {
    lines.push(
      `\n${stale.length} baseline entry/entries in ${label} matched nothing in the source. The rule they` +
        "\nwere recorded against is gone, but the key survives — pre-authorising that exact violation" +
        "\nto return unnoticed. Confirm the rule really is gone, then re-run with --update-baseline:\n",
    );
    for (const key of stale) lines.push(`  - ${key}`);
  }
  if (overProvisioned.length > 0) {
    lines.push(
      `\n${overProvisioned.length} baseline entry/entries in ${label} budget for more occurrences than exist,` +
        "\nwhich pre-authorises the difference coming back. Re-run with --update-baseline:\n",
    );
    for (const { key, budget, matched } of overProvisioned) {
      lines.push(`  - ${key}\n      budgets ${budget}, matched ${matched}`);
    }
  }
  return lines.join("\n");
}

/**
 * Group violations by the block they sit in and render them as
 * `<file>:<line>: <property>: <value>` under a selector heading, matching the
 * `- <detail>` failure style the other guards in this directory use.
 */
export function formatViolations(violations, { indent = "", limit = Infinity } = {}) {
  const groups = new Map();
  for (const violation of violations) {
    const heading = `${violation.file} — ${violation.selector}`;
    if (!groups.has(heading)) groups.set(heading, []);
    groups.get(heading).push(violation);
  }
  const lines = [];
  let shown = 0;
  for (const [heading, group] of groups) {
    if (shown >= limit) break;
    lines.push(`${indent}${heading}`);
    for (const violation of group) {
      if (shown >= limit) break;
      const note = violation.note ? `  (${violation.note})` : "";
      lines.push(`${indent}  - ${violation.file}:${violation.line}: ${violation.property}: ${violation.value}${note}`);
      shown += 1;
    }
  }
  if (shown < violations.length) {
    lines.push(`${indent}  … and ${violations.length - shown} more (this list is capped so the failure above stays readable).`);
  }
  return lines.join("\n");
}

/** The N selectors carrying the most violations, for the summary footer. */
export function topOffenders(violations, limit = 10) {
  const counts = new Map();
  for (const violation of violations) {
    counts.set(violation.selector, (counts.get(violation.selector) ?? 0) + 1);
  }
  return [...counts.entries()]
    .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
    .slice(0, limit)
    .map(([selector, count]) => ({ selector, count }));
}
