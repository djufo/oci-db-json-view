import { readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { findNativeConfirmCalls } from "./check-confirm-source.mjs";

const fixture = (name) =>
  readFileSync(new URL(`./fixtures/confirm-source-gate/${name}`, import.meta.url), "utf8");

describe("confirm source gate", () => {
  it("rejects browser-native confirmation calls", () => {
    expect(findNativeConfirmCalls(fileURLToPath(import.meta.url), fixture("reject-window.ts"))).toEqual([
      "browser-native window.confirm is forbidden",
    ]);
    expect(findNativeConfirmCalls(fileURLToPath(import.meta.url), fixture("reject-unqualified.ts"))).toEqual([
      "unqualified confirm(...) is forbidden",
    ]);
  });

  it("allows domain methods named confirm", () => {
    expect(findNativeConfirmCalls(fileURLToPath(import.meta.url), fixture("allow-domain-methods.ts"))).toEqual([]);
  });
});
