# emibs-ui-lib Architecture

This document is the source of truth for layer boundary decisions in
`emibs-ui-lib`, including the Forms initiative and future extractions.

## Repo Surface

- `src/components/primitives/` contains the small building blocks such as
  `Collapsible`, `PayloadBlock`, `CheckboxControl`, `TextInputControl`,
  `CommandPalette`, and `Field`.
- Application-facing UI lives in `src/components/auth/`,
  `src/components/data/`, `src/components/feedback/`, and
  `src/components/layout/`.
- `src/catalog/`, `src/explorer/`, `src/compositions/`, and `src/demos/`
  implement the review and demo surfaces that exercise the library.

## Dependency Direction

Dependencies move downward only. A higher layer may consume lower layers; a
lower layer must not import from or assume a higher layer. Core and primitives
are sibling lower layers: components and forms may consume both, but primitives
do not import core and core does not import primitives/components.

```text
catalog / explorer / demos
        |
        v
forms ---------------> core
        |
        v
components ----------> core
        |
        v
primitives
```

## Layers

### Core

Core contains decoupled CONFIGURATION and cross-component ORCHESTRATION. It is
presentation-free: no component markup, styling, DOM assumptions, product copy,
or app-specific API behavior belongs here.

Use core for shared models, `FormSpec`-style schemas, and engines that
coordinate multiple components or fields without owning their rendering.

#### Folder shape (issue-583)

The core home is scaffolded as two sub-areas, each with an `index.ts` barrel,
under a top-level `src/core/index.ts` barrel:

```text
src/core/
  index.ts          re-exports config + orchestration
  config/
    index.ts        declarative configuration decoupled from form + primitives
                    (FormSpec, validation/field config, entity models)
  orchestration/
    index.ts        cross-component / application coordination
    forms/          the form engine (issue-552 / issue-592) — headless
```

This shape was chosen over a flat `src/config/` + `src/orchestration/` pair so
the whole decoupled-logic layer lives under one root that maps 1:1 to a future
`@emibs/core` workspace package (see `docs/EXTRACTION-PLAN.md`), while still
separating configuration from orchestration internally. The library's public
surface (`src/lib/index.ts`) re-exports `../core`, so consumers reach core
through the package entry rather than deep paths. Primitives do not import
core; the layer stays presentation-free (no JSX, no `src/components/**`
imports).

#### Enforced boundary guard (issue-584)

Layer boundaries are enforced by `npm run check:architecture` in this package
(dependency-cruiser with `.dependency-cruiser.cjs`, plus a core presentation
guard). The dependency graph includes TypeScript pre-compilation dependencies,
so erased `import type` statements cannot bypass the same layer rules. The
package `build` script runs this guard first, so the root workspace build path
and CI fail before TypeScript/Vite if the rules are violated.

Direct rules:

- `src/core/**` must not import `src/components/**`.
- `src/components/primitives/**` must not import `src/core/**`.
- `src/components/primitives/**` must not import `src/components/data/**`.
- `src/catalog/**` and `src/explorer/**` are demo/review surfaces: they may
  import downward, but non-demo code must not import them.

Barrel-aware rules (issue-1262): `src/lib/index.ts` is the PUBLIC entry barrel
and re-exports higher layers (core, components, forms). A lower layer that
imports the barrel would route THROUGH those re-exports and bypass the direct
rules above (e.g. `src/core/**` importing `../lib` to reach a component). The
guard therefore adds `reachable` rules that follow the whole dependency graph,
treating the barrel's re-exports as transparent:

- `src/core/**` must not REACH `src/(components|forms|catalog|explorer)/**`
  through any chain, including the `src/lib` barrel.
- `src/components/primitives/**` must not REACH `src/core/**` or
  `src/components/data/**` through any chain, including the `src/lib` barrel.

A second guard now reads the same designation: `npm run check:registration`
(`scripts/check-catalog-registration.mjs`, uif/issue-4675) walks the export
closure of `src/lib/index.ts` and fails the build when a component reachable
from it has no `componentMeta` entry. The barrel is therefore the package's
public surface for two purposes — what a lower layer may not import THROUGH,
and what the catalog must account FOR. Widening it widens both.

So that primitives can still consume the `cn` class-name utility without
importing the layer-mixing barrel, `cn` lives in its own leaf module
`src/lib/cn.ts` (re-exported by the barrel for external consumers). Low layers
import `cn` from `src/lib/cn` directly.

Core presentation guard: `scripts/check-core-presentation.mjs` keeps `src/core`
presentation-free at the source level, which the import graph cannot see. React
hooks and pure functions are allowed, but a core file (`.ts` or `.tsx`) may not
be a `.tsx` file, call `createElement`, or import `react/jsx-runtime`,
`react-dom`, or `lucide-react`.

The current tree has no known violations.

#### Interaction-state guard (uif/issue-4684)

`npm run check:busy-state` (`scripts/check-busy-state.mjs`) enforces the one
part of `src/theme/STATES.md` rule 5 that a parser can actually decide: a
control must not remove its own interactivity because it is busy. `disabled`
and `busy` are different states — `disabled` is not focusable, `busy` dims but
stays focusable and announces `aria-busy` — and `disabled={x || busy}` collapses
them, dropping the control out of the tab order at the moment the user activates
it. The shape recurred nine times and every occurrence was caught by human
review, never by the build.

Telling the defect apart from the legitimate case (locking a SIBLING control
while another action is in flight) is the hard part, and the guard does not
attempt it in general. It fires only when an element identifies itself as the
busy one: (A) the same flag drives both `disabled` and `aria-busy`/`loading`,
which rule 5 makes a contradiction whatever the flag means, or (B) the element's
own children switch on the same flag that appears in its `disabled`. Both
signals are syntactic, and together they caught all nine known occurrences plus
five previously unknown ones while flagging nothing legitimate.

It is deliberately incomplete, and the script's header says where: form fields
locked during their own form's submit carry neither signal and are invisible to
it, as is a busy flag that reaches `disabled` through a function call or a
`useMemo`. Those still need review. `scripts/baselines/busy-state.json` holds
the three Forms-slice demo occurrences that are being burned down separately.

The house mechanism for the fixed form is `Button.loading`, which sets
`aria-busy`, leaves `disabled` alone so the button stays focusable, and blocks
activation in its own click handler; on a raw element, set `aria-busy` and guard
re-entry in the click/submit handler instead.

### Primitives

Primitives are reusable presentation building blocks. They own their local UI
state, event wiring, accessibility attributes, and rendering details.

Primitive-local state stays in the primitive. Examples include a single
`Collapsible` opening or closing, an input's value, hover state, focus state,
and other UI mechanics that belong to one primitive instance.

Do not extract per-primitive state into core. Do not build a forced
cross-primitive state-reuse abstraction just because several primitives have
similar local behavior.

### Components

Components are application-level UI surfaces composed from primitives and core
contracts. They can express Score/eLitua product patterns, data shapes, slots,
controlled actions, loading and error states, and domain-facing presentation.

Components may depend on primitives and core, but components must not depend on
forms or catalog/explorer code.

### Forms

Forms contain form-specific configuration, orchestration, and composition. The
forms layer may consume core, primitives, and components to build reusable form
flows and field coordination.

Forms must not push presentation-free engines upward into components or
downward into primitives unless the extraction test below passes.

### Catalog / Explorer

The catalog and explorer are demo and review surfaces. They consume every other
layer and are consumed by none.

Catalog fixtures, demos, inspection UI, route/hash state, and review-only tools
stay in the catalog/explorer layer. No core, primitive, component, or forms
module may depend on catalog/explorer code.

## Extraction Test

Move logic out of a primitive or component only when all three conditions hold:

1. The separation is clear.
2. The extracted logic can evolve independently without affecting the
   primitives library.
3. There is a concrete benefit: independent evolution, build-size reduction, or
   proven duplication.

If any condition is missing, keep the logic where it is. Similarity alone is
not enough to extract.

## Canonical Composite Ownership

Each composite concept has one public owner. Lower-level primitives provide
mechanics; composites assemble them without copying their markup or state
logic.

| Concept | Canonical owner | Required composition | Replaced paths |
| --- | --- | --- | --- |
| Tabular data | `DataTable` in `components/data` | `useDataTable` derives client state, `Toolbar` owns toolbar semantics, `TablePrimitive` is the only table renderer, and `DataStatePanel` owns non-ready states. Filters, export effects, server pagination, fetching, and persistence remain caller-owned. | `DataTableView`, `PagedDataTable`, and the legacy static `DataTable` implementation. |
| Page section | `SectionCard` in `components/layout` | A page or page-layout slot may place this single depth-one surface around flat content. It owns the v4 section header/body/footer arrangement, while the parent owns sibling gaps. | `SectionPanel` and product-local section-card chrome. |
| Label/value facts | `DescriptionList` plus its `FieldRow` renderer | `DescriptionList` owns `dl` semantics and the parent grid/gap; every item renders through the same flat `FieldRow`. Editable input rows continue to use `Field` and are not a second fact-row mechanism. | Card-style description-list items and product-local read-only field rows. |
| Async/empty feedback | `DataStatePanel` | `EmptyState` and `LoadingState` are typed presets of `DataStatePanel`, not independent renderers. Loading geometry composes `Skeleton`; fetching, retry, timing, and localization remain caller-owned. | Bespoke loading/empty blocks inside shared composites. |
| Confirmation | `ConfirmationDialog` | `BlastRadiusConfirm` is the consequential-write variant and composes the same overlay/actions. Its impact is computed from live caller data. | Browser-native confirm calls and any second confirm frame. |

`FieldRow` in this matrix means the read-only label/value renderer owned by
`DescriptionList`. `AuthFieldRow` is an editable auth-input layout helper, not
the canonical fact row and not evidence of this consolidation. The catalog must
demonstrate the canonical row through `#/c/description-list`; it does not need
to render that row on the auth-access or catalog home pages.

`Skeleton` remains the E2 primitive owned by `components/primitives`; E4 only
composes it through the `DataStatePanel` loading preset. The searchable
`#/c/skeleton` catalog entry is required prerequisite evidence, not a second E4
skeleton implementation.

`SectionCard` is the one intentional page-owned surface abstraction. Shared
data, auth, feedback, and form components MUST NOT render it internally; they
stay flat so the only accepted composition is page background →
`SectionCard` → optional inset. The architecture gate must keep this import
allow-list explicit.

Composite migrations are complete only after their replaced source, styles,
catalog ids, demos, exports, and internal call sites are deleted. Temporary
coexistence is limited to the implementation sequence and ends at the final
retirement gate; no compatibility alias is retained for internal consumers.
Catalog acceptance must exercise a built artifact containing the candidate
head (or an integrated descendant), and must verify both canonical routes above;
an older deployed bundle is not release evidence for or against the candidate.

## Worked Examples

- `FormSpec` is configuration. If it is generic and presentation-free, it
  belongs in core. If it is specific to a reusable form workflow, it belongs in
  forms.
- A form engine coordinating many fields is cross-component orchestration. It is
  presentation-free coordination logic with independent value, validation, and
  submission behavior, so it should be extracted out of individual field
  components.
- A single `Collapsible` opening and closing is primitive-local state. It
  belongs inside `Collapsible`; extracting it would create a forced state
  abstraction without independent evolution or proven duplication benefit.

## Repo Examples

- `EditableFormPanel` in `src/components/data/EditableFormPanel.tsx` is a
  presentational shell for dense forms.
- `CommandConsole` in `src/components/data/CommandConsole.tsx` is a
  presentation surface for command sessions and transcripts.
- `ExplorerWorkspace` in `src/components/layout/ExplorerWorkspace.tsx` and
  `CatalogExplorer` in `src/explorer/CatalogExplorer.tsx` show the layer
  direction in practice: explorer consumes components, primitives, catalog
  data, compositions, and theme tokens.
