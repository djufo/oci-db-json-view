# Phase-2 Package Extraction Plan

Status source of truth for turning the in-place layers of `emibs-ui-lib` into
`packages/*` workspaces **later**, when their APIs stabilize. Read alongside
[`../ARCHITECTURE.md`](../ARCHITECTURE.md) — this plan is the Phase-2 companion
to the layer model and extraction test defined there.

## Goal

When APIs stabilize, extracting a layer to its own workspace package must be a
**folder move + a `package.json`**, not a rewrite. Everything below is arranged
so that success is measured by that test: if pulling a layer out requires
re-plumbing imports across the codebase or reworking logic, the layer was not
actually decoupled and stays put.

## Success test (per layer)

A layer is *extractable* when all of the following hold:

1. It already lives under a single root folder inside `src/` that maps 1:1 to
   the future package (no sources scattered across unrelated folders).
2. Its outward dependencies point **only downward** in the layer graph (it never
   imports from a layer above it).
3. It satisfies the [ARCHITECTURE.md extraction test](../ARCHITECTURE.md#extraction-test):
   clear separation, independent evolution, concrete benefit.
4. The move is mechanical: `git mv src/<root> packages/<pkg>/src`, add a
   `package.json`, update the workspace's dependency wiring — no source edits to
   the moved logic.

## Layer → workspace mapping

| Layer | Current root(s) in `src/` | Future package | App or lib | Status |
| --- | --- | --- | --- | --- |
| core (config + orchestration) | `src/core/` | `@emibs/ui-core` | lib | **NOT-YET** (young API; scaffolded issue-583, first resident is the forms engine issue-592) |
| primitives | `src/components/primitives/`, `src/theme/`, `src/lib/cn` | `@emibs/ui-primitives` | lib | **NOT-YET** (broad, stable shape, but no consuming pressure yet) |
| components | `src/components/{auth,data,feedback,layout}/`, `src/compositions/` | `@emibs/ui-components` | lib | **NOT-YET** (largest surface; extract last) |
| forms | `src/forms/` | `@emibs/ui-forms` | lib | **NOT-YET** (engine just landing; pilot for the extraction test) |
| catalog / explorer | `src/catalog/`, `src/explorer/` (incl. the `src/explorer/main.tsx` entry point), `src/demos/` | stays an app (`emibs-ui-lib` app / `ui-lib.ayc.io`) | app | **STAYS** (demo/review surface; consumes all, consumed by none) |

No layer is marked ready-to-extract today. This is deliberate: per the
extraction test, extraction is *earned*, and the concrete pressure that earns it
(a second consumer needing the layer without the rest, or a proven build-size
win) has not yet arrived. The point of Phase 2 is to keep the folders shaped so
that the move stays mechanical when that pressure does arrive.

## Dependency graph (Phase-2 packages)

Dependencies point downward only, mirroring
[ARCHITECTURE.md → Dependency Direction](../ARCHITECTURE.md#dependency-direction):

```text
emibs-ui-lib (app: catalog / explorer / demos)   ← stays an app
        |  depends on
        v
   @emibs/ui-forms ----------------> @emibs/ui-core
        |  depends on
        v
 @emibs/ui-components -------------> @emibs/ui-core
        |  depends on
        v
 @emibs/ui-primitives
```

Wiring rules:

- `@emibs/ui-core` depends on nothing in this graph (React is a peer dep). It is
  presentation-free: no JSX, no import of primitives/components.
- `@emibs/ui-primitives` depends on nothing in this graph; it must not import
  core, components, forms, or the app, including type-only imports.
- `@emibs/ui-components` may depend on `@emibs/ui-primitives` and `@emibs/ui-core`.
- `@emibs/ui-forms` may depend on core, primitives, and components (it is the
  pilot that proves config + engine stay decoupled from field primitives).
- The app depends on all packages; nothing depends on the app.
- `react` / `react-dom` become `peerDependencies` on every extracted lib package
  so consumers dedupe a single React instance. Shared build tooling (`tsconfig`,
  `vite`) is provided at the workspace root, as it is today.

## Cross-package dependency policy

- The forms engine lives in `@emibs/ui-core` (orchestration). It must **not**
  pull in the heavyweight `emibs-ui-services` RxJS `StateService`; core carries
  its own lightweight `useSyncExternalStore` selector store so the package stays
  dependency-light and independently versionable. The selector *contract*
  (subscribe + selector + bail-out on an unchanged slice) is honored natively.
- Any future need to share app-level RxJS state stays in `emibs-ui-services`, a
  sibling package the **app** may consume — not a dependency of the ui-* libs.

## Sequencing

1. **Phase 1 (done / in progress):** stand the layers up in place under single
   roots with public barrels (`src/core` scaffold — issue-583; forms engine —
   issue-592). Keep the import boundary clean (core imports no JSX; primitives
   import no core).
2. **Phase 2 (this plan, gated on stable APIs):** when a layer's API stops
   churning *and* a concrete benefit appears, extract it bottom-up
   (core → primitives → components → forms), one package per PR, each a
   folder-move + `package.json`. Verify with a root `npm run build` after each.
3. **Phase 3 (optional):** independent versioning / publish for whichever
   packages prove genuinely independent evolution.

## Non-goals

- Extracting anything today (no layer passes the test with a concrete benefit yet).
- Pulling per-primitive local state into core (ARCHITECTURE.md forbids it).
- Publishing to an external registry.
- Breaking the live `ui-lib.ayc.io` explorer.
