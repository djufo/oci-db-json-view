---
id: uif-e6-score-adoption
version: 1.0.0
status: authoritative
---

# UIF-E6 — Score adoption wave

This is the decomposition and acceptance contract for `issue-2186`.

## 1. Outcome and boundary

Score MUST consume the released `emibs-ui-lib` implementations for every
pattern named by the UIF 1.0 duplication inventory: tables, tabs, page
sections, band colour, toolbars, chips, freshness, read-only field rows,
search fields, confirmations, meters, and empty/loading states. The migration
is behaviour-preserving: Score continues to own data fetching, mutations,
authorization, route/query state, filtering policy, formatting, persistence,
and toasts.

The E6 wave also converges the delivered Score v4 screens on the same shared
components. A v4-prefixed local copy is still a duplicate; its visual match to
the mock does not exempt it from this contract.

E6 does not redesign Score, change its APIs, or add product features. It does
not keep a second local implementation for fallback. Git history and this
specification preserve knowledge after old source is deleted.

## 2. Prerequisites and canonical owners

`issue-2184` defines the architecture prerequisite. Before Score adoption
starts, its canonical composite contract MUST exist as released package code:

| Concept | One shared owner | Required lower-level composition |
| --- | --- | --- |
| Tabular data | `DataTable` | `useDataTable` + `Toolbar` + `TablePrimitive` + `DataStatePanel` |
| Page surface | `SectionCard` | page-owned depth-one header/body/footer surface |
| Read-only fact row | `DescriptionList` / `FieldRow` | parent-owned `dl` grid and gap; flat rows |
| Async state | `DataStatePanel` presets `EmptyState` / `LoadingState` | `Skeleton` for loading geometry |
| Confirmation | `ConfirmationDialog` | `BlastRadiusConfirm` composes it for live impact |

The E4 implementation and package release are a foundation story in this
decomposition. That story MUST delete `DataTableView`, `PagedDataTable`, and
`SectionPanel` and MUST ship `SectionCard` and `LoadingState`. Score consumers
MUST NOT emulate missing shared owners locally.

E1/E2 primitives remain canonical for `ContentTabs`, `Toolbar`, `Chip` and its
taxonomies, `FreshnessBadge`, `SearchField`, `Meter`, `Skeleton`,
`TablePrimitive`, `SignalDot`, and `Button`.

## 3. Release and theme bridge

The first Score change after the E4 package release MUST pin the exact new
`emibs-ui-lib` tarball and install the Score light/dark `emibs-theme/2` maps at
the application theme boundary. Score MUST not copy the token values into a
second hand-authored JSON or CSS vocabulary.

For incremental merges, `ui/src/generated/tokens.css` may temporarily expose
generated `--score-*` aliases, but the source of every alias MUST be the
selected complete `emibs-theme/2` Score theme. The only consumer of this shim
is Score itself, and its expiry is the E6 finality story: after all pattern
stories land, remaining Score selectors migrate to canonical theme variables
and the alias generator/output is deleted. There is no indefinite dual-token
mode and no hand-authored fallback.

The bridge build MUST prove:

1. the light and dark Score maps contain the complete ordered
   `emibs-theme/2` vocabulary;
2. generated assets are byte-stable from the package theme source. The Score
   color bridge maps the live `tokens.json` values directly, including
   `textSecondary`, `primaryText`, `accentText`, and `link`; these are
   `/2`-only slots so `emibs-theme/1` remains an ordered, lossless subset;
3. light, dark, and compact/comfortable density scopes render through the same
   `ThemeScope`/`DensityScope` mechanism; and
4. Score's raw-colour and token-generation validators remain green during the
   incremental window.

## 4. Dependency-ordered stories

The Score board holds stable task IDs for this graph. IDs are recorded here
after creation; edges are authoritative in each task's `blockedBy` field.

```text
E4 implementation + package release
  -> Score exact-version vendor/theme bridge
       -> 12 independent per-pattern adoption stories
            -> v4 shared-component convergence
                 -> source/CSS/token finality fitness
                      -> reviewer acceptance
```

The pattern stories are deliberately per pattern, not per screen. Each story
updates every current occurrence of its pattern in one scoped migration and
deletes the replaced implementation in the same PR. The proposal counts are a
baseline inventory, not an allowance to leave newer occurrences behind.

| Task | Wave | Baseline | Required end state |
| --- | --- | ---: | --- |
| `issue-2234` | E4 package foundation | package-wide | released canonical composites and no retired E4 source path |
| `issue-2235` | Score vendor/theme foundation | app-wide | exact UIF pin and temporary aliases derived only from the Score `emibs-theme/2` maps |
| `issue-2236` | Tables | 10 screens | no raw `<table>` renderer or `.score-v2-table` / `.score-v4-table` family in Score UI; shared `DataTable` or `TablePrimitive` owns rendering |
| `issue-2237` | Tabs | 11 screens | no local tablist renderer or local tab CSS family; URL ownership remains in Score and items render through `ContentTabs` |
| `issue-2238` | Sections | 12 screens | one page-owned `SectionCard` surface around flat children; local section-card/header chrome deleted |
| `issue-2239` | Band colour | 10 screens | band thresholds/taxonomy and colour resolve through the shared band contract and theme tokens; no Score colour map |
| `issue-2240` | Toolbars | 9 screens | action/search/filter rows compose shared `Toolbar`; Score retains action effects and query state |
| `issue-2241` | Chips | 7 screens | `Chip`, `StatusChip`, `BandChip`, `ClassChip`, or `ModelChip` is the only chip renderer; local pill/chip CSS deleted |
| `issue-2242` | Freshness | 7 screens | `FreshnessBadge` is the one display formatter; Score supplies explicit stale policy where needed and deletes both duplicate CSS families |
| `issue-2243` | Field rows | 7 screens | read-only facts use `DescriptionList`/`FieldRow`; editable controls continue to use `Field` and are not conflated with fact rows |
| `issue-2244` | Search | 7 screens | search chrome uses `SearchField`; Score retains parsing, URL round-trip, submit timing, and result derivation |
| `issue-2245` | Confirms | 6 flows | every consequential flow uses `ConfirmationDialog` or `BlastRadiusConfirm`; zero browser-native confirms, including every occurrence present on the candidate head |
| `issue-2246` | Meters | inventory-wide | `Meter` owns known/unknown rendering; unknown is neutral-striped and never full/OK |
| `issue-2247` | Empty/loading | 16 files | `DataStatePanel` typed presets own semantics and `Skeleton` owns loading geometry; local empty/loading renderers and CSS deleted |
| `issue-2248` | V4-1..7 convergence | all v4 routes | no local copy of a released UIF presentation owner |
| `issue-2249` | Finality fitness | production UI | build-enforced zero local patterns and deletion of the temporary token bridge |
| `issue-2250` | Integrated review | integrated candidate | reviewed density, accessibility, theme, responsive, and deletion evidence |

### 4.1 Pattern-story acceptance shared by every story

- Inventory the candidate `origin/score-work` head before editing; migrate all
  matches, including occurrences added after the proposal.
- Preserve route hashes, query parameters, API payloads, authorization checks,
  mutation sequencing, optimistic rollback, focus return, and user-visible
  state copy unless the shared accessibility contract requires clearer text.
- Add public-behaviour tests for every affected screen family. Tests MUST
  assert the shared component contract or rendered semantics, not private
  implementation details.
- Delete the replaced JSX, helpers, exports, CSS selectors, tests, and dead
  token aliases in the same PR. No compatibility alias is allowed for internal
  Score consumers.
- Keep reusable components flat. Pages own depth-one `SectionCard` surfaces;
  a composed shared child adds no outer padding, margin, border, or shadow.
  Sibling spacing lives on the parent through theme tokens.
- Stateful icon/toggle/cycle controls MUST expose synchronized accessible text
  stating current state first and the next action/result second. Ordinary
  fixed-action controls continue to name the action.

## 5. V4 convergence

After all twelve pattern stories are released, the v4 convergence story MUST
reconcile V4-1 through V4-7 with the shared owners without changing the v4
route or operator behaviour contracts. It MUST replace and delete local
presentation copies including `BandChip`, `CapacityMeter`, `InspectorRail`,
`AlertLane`, `StatusStrip`, `CommandBar`, and `BlastRadiusConfirm` wherever a
released shared owner exists. Pure Score domain selectors and API adapters stay
local; presentation mapping belongs to `emibs-ui-lib`.

`ui/src/ui/v4/v4.css` may retain page-layout selectors that have no shared
owner, but MUST lose the table, tab, chip, band, meter, freshness, field-row,
toolbar, confirmation, and empty/loading families covered by E6. Shared
component chrome is not restyled back into a nested Score card at the
integration point.

## 6. Finality fitness

The final engineer story MUST add one build-invoked Score fitness check that
fails on recurrence. It MUST scan production UI source and CSS, with narrowly
documented fixture/test exclusions, for all of the following:

- raw table renderers and retired table class families;
- local tablist renderers and retired tab class families;
- local section-card/header, chip/pill, meter, freshness, field-row, search,
  toolbar, and empty/loading implementation families;
- browser-global `window.confirm` and unqualified `confirm(...)` calls while
  permitting object/domain methods named `confirm`;
- the deleted local v4 presentation modules named in section 5;
- hand-authored `--score-*` declarations or a second Score token source; and
- imports of retired E4 package symbols or compatibility aliases.

The gate MUST run in the ordinary Score UI test/build command, not as a manual
audit. The final PR also deletes the temporary generated `--score-*` alias
sheet and generator once the scan proves no Score consumer remains.

The reviewer story then verifies the complete graph on the integrated
`score-work` candidate: build/tests, light and dark themes, compact and
comfortable density, keyboard/focus behaviour, narrow layout, raw-colour
validation, zero-pattern fitness, and a DOM/screenshot density check of the
most composed page. Acceptance requires at most page → surface → optional inset
and no third padded box.

## 7. Completion

E6 is complete only when every child is in `prod`, `done`, or `closed`, the
final fitness check is green on the integrated Score tree, all replaced local
paths are deleted, and the reviewer has approved the integrated result. The
epic MUST remain open while any child is unfinished; temporary bridge code is
not a completion state.
