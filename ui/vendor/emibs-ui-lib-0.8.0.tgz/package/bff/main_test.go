package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"sort"
	"strings"
	"testing"
	"time"
)

const spaMarker = "<!doctype html><title>uif catalogue</title>"
const assetMarker = "console.log('uif bundle')"

// staticRoot builds a stand-in for the built catalogue: the SPA shell plus a
// hashed asset, which is exactly the shape the nginx container served.
func staticRoot(t *testing.T) string {
	t.Helper()
	root := t.TempDir()
	if err := os.WriteFile(filepath.Join(root, "index.html"), []byte(spaMarker), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(root, "assets"), 0o700); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(root, "assets", "index-abc123.js"), []byte(assetMarker), 0o600); err != nil {
		t.Fatal(err)
	}
	return root
}

func gatedServer(t *testing.T) *server {
	t.Helper()
	return newServer(config{Listen: defaultListen, StaticDir: staticRoot(t), Auth: &authConfig{
		PublicBaseURL:         "https://ui-lib.ayc.io",
		AuthorizeEndpoint:     "https://auth.ui.dev.ayc.io/realms/org/authorize",
		TokenEndpoint:         "https://auth.api.ayc.io/realms/org/token",
		TokenProofEndpoint:    "https://auth.api.ayc.io/realms/org/token",
		LogoutEndpoint:        "https://auth.api.ayc.io/realms/org/logout",
		ClientID:              "emibs-ui-lib",
		SessionIdleTTLSeconds: 3600,
	}})
}

func get(handler http.Handler, target string, decorate ...func(*http.Request)) *httptest.ResponseRecorder {
	request := httptest.NewRequest(http.MethodGet, "https://ui-lib.ayc.io"+target, nil)
	for _, apply := range decorate {
		apply(request)
	}
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, request)
	return response
}

func asNavigation(r *http.Request) { r.Header.Set("Sec-Fetch-Mode", "navigate") }

func withSession(id string) func(*http.Request) {
	return func(r *http.Request) { r.AddCookie(&http.Cookie{Name: sessionCookie, Value: id}) }
}

func liveSession(s *server, id string) {
	now := time.Now().UTC()
	_, proofKey, _ := ed25519.GenerateKey(rand.Reader)
	s.sessions[id] = &browserSession{Identity: "identity-token", Refresh: "refresh-token", IdentityEnds: now.Add(time.Minute), ProofKey: proofKey, EndsAt: now.Add(sessionAbsoluteLifetime), LastSeen: now}
}

// ---------------------------------------------------------------------------
// The gate is live and fail-closed. (There is no other mode: see
// entrypoint_test.go for the startup refusal.)
// ---------------------------------------------------------------------------

func TestGatedRefusesEveryAnonymousRequestForContent(t *testing.T) {
	handler := gatedServer(t).routes()
	for _, testCase := range []struct {
		name, path string
		navigation bool
		wantStatus int
	}{
		{"SPA shell, browser navigation", "/", true, http.StatusFound},
		{"SPA shell, programmatic", "/", false, http.StatusUnauthorized},
		{"arbitrary SPA route", "/components/button", true, http.StatusFound},
		{"arbitrary SPA route, programmatic", "/components/button", false, http.StatusUnauthorized},
		// Assets are refused too. Serving the built bundle to an anonymous
		// caller IS the exposure being closed — the catalogue's content is in
		// the bundle, not only behind a client-side route.
		{"hashed asset", "/assets/index-abc123.js", false, http.StatusUnauthorized},
		{"unknown path", "/does/not/exist", false, http.StatusUnauthorized},
	} {
		t.Run(testCase.name, func(t *testing.T) {
			decorators := []func(*http.Request){}
			if testCase.navigation {
				decorators = append(decorators, asNavigation)
			}
			response := get(handler, testCase.path, decorators...)
			if response.Code != testCase.wantStatus {
				t.Fatalf("gated uif answered %s with status=%d, want %d", testCase.path, response.Code, testCase.wantStatus)
			}
			if body := response.Body.String(); strings.Contains(body, spaMarker) || strings.Contains(body, assetMarker) {
				t.Fatalf("gated uif leaked catalogue content on %s: %q", testCase.path, body)
			}
		})
	}
}

func TestGatedRedirectsBrowserNavigationBackToWhereItAsked(t *testing.T) {
	response := get(gatedServer(t).routes(), "/components/button?variant=ghost", asNavigation)
	location := response.Header().Get("Location")
	if response.Code != http.StatusFound || !strings.HasPrefix(location, "/auth/login?return=") {
		t.Fatalf("gated navigation was not sent to login: status=%d location=%q", response.Code, location)
	}
	parsed, err := url.Parse(location)
	if err != nil || parsed.Query().Get("return") != "/components/button?variant=ghost" {
		t.Fatalf("login return target drifted: %q (%v)", location, err)
	}
}

// The login redirect reflects a caller-supplied value, so it is the one place
// this program could be turned into an open redirect.
func TestGatedLoginReturnTargetIsAlwaysSameOrigin(t *testing.T) {
	handler := gatedServer(t).routes()
	for _, path := range []string{"//evil.example.com/", "/\\evil.example.com", "///evil.example.com"} {
		response := get(handler, path, asNavigation)
		location := response.Header().Get("Location")
		parsed, err := url.Parse(location)
		if err != nil {
			t.Fatalf("unparseable login redirect for %q: %v", path, err)
		}
		// A protocol-relative target ("//host") is the open redirect: a browser
		// resolves it to another origin. Only a single-slash path may survive.
		target := parsed.Query().Get("return")
		if !strings.HasPrefix(target, "/") || strings.HasPrefix(target, "//") {
			t.Fatalf("login return target escaped the origin for %q: %q", path, target)
		}
	}

	// The same rule applies to the value the login handler accepts and later
	// redirects to, not only to the one the gate generates.
	for _, offered := range []string{"//evil.example.com/", "https://evil.example.com/", "evil.example.com"} {
		application := gatedServer(t)
		login := get(application.routes(), "/auth/login?return="+url.QueryEscape(offered))
		if login.Code != http.StatusFound {
			t.Fatalf("login status=%d", login.Code)
		}
		for _, flow := range application.flows {
			if flow.ReturnTo != "/" {
				t.Fatalf("login accepted an off-origin return target %q -> %q", offered, flow.ReturnTo)
			}
		}
	}
}

func TestGatedServesTheCatalogueToAnAuthenticatedCaller(t *testing.T) {
	application := gatedServer(t)
	liveSession(application, "session-1")
	handler := application.routes()
	for _, path := range []string{"/", "/components/button", "/assets/index-abc123.js"} {
		response := get(handler, path, withSession("session-1"))
		if response.Code != http.StatusOK {
			t.Fatalf("gated uif refused an authenticated caller on %s: status=%d", path, response.Code)
		}
	}
}

func TestHealthAndRobotsStayOpen(t *testing.T) {
	handler := gatedServer(t).routes()
	health := get(handler, "/health")
	if health.Code != http.StatusOK || health.Body.String() != "ok\n" {
		t.Fatalf("/health must answer the container healthcheck without a credential: status=%d body=%q", health.Code, health.Body.String())
	}
	robots := get(handler, "/robots.txt")
	if robots.Code != http.StatusOK || robots.Body.String() != "User-agent: *\nDisallow: /\n" {
		t.Fatalf("/robots.txt must stay readable by the crawlers it refuses: status=%d body=%q", robots.Code, robots.Body.String())
	}
	for _, path := range []string{"/", "/health", "/robots.txt", "/auth/login"} {
		if got := get(handler, path).Header().Get("X-Robots-Tag"); got != "noindex, nofollow, noarchive" {
			t.Fatalf("uif lost the noindex header on %s: %q", path, got)
		}
	}
}

func TestGatedSendsHardeningHeaders(t *testing.T) {
	response := get(gatedServer(t).routes(), "/", asNavigation)
	for header, want := range map[string]string{
		"X-Robots-Tag":           "noindex, nofollow, noarchive",
		"Referrer-Policy":        "no-referrer",
		"X-Content-Type-Options": "nosniff",
		"X-Frame-Options":        "DENY",
		"Cache-Control":          "no-store",
	} {
		if got := response.Header().Get(header); got != want {
			t.Fatalf("gated uif %s=%q, want %q", header, got, want)
		}
	}
}

// The allowlist is the whole gate: anything not on it is refused, including
// paths that do not exist yet and known paths on a method they do not serve.
// Pinning it as METHOD and path pairs means a future route cannot be added to
// the mux and quietly reach anonymous callers, and a POST-only route cannot be
// reached by GET.
func TestUnauthenticatedAllowlistIsExactlyTheOperationalSurface(t *testing.T) {
	allowed := []string{}
	for _, method := range []string{http.MethodGet, http.MethodHead, http.MethodPost, http.MethodPut, http.MethodDelete, http.MethodOptions} {
		for _, path := range []string{"/health", "/robots.txt", "/auth/login", "/auth/callback", "/auth/logout", "/", "/index.html", "/assets/index-abc123.js", "/components/button", "/auth", "/auth/", "/health/live", "/config.json"} {
			if unauthenticatedRoute(method, path) {
				allowed = append(allowed, method+" "+path)
			}
		}
	}
	sort.Strings(allowed)
	want := []string{"GET /auth/callback", "GET /auth/login", "POST /auth/logout"}
	for _, method := range []string{http.MethodDelete, http.MethodGet, http.MethodHead, http.MethodOptions, http.MethodPost, http.MethodPut} {
		want = append(want, method+" /health", method+" /robots.txt")
	}
	sort.Strings(want)
	if strings.Join(allowed, ",") != strings.Join(want, ",") {
		t.Fatalf("unauthenticated surface drifted:\n got %v\nwant %v", allowed, want)
	}
}

// ---------------------------------------------------------------------------
// Sessions: expiry, logout, tampering.
// ---------------------------------------------------------------------------

func TestGatedRefusesIdleExpiredSession(t *testing.T) {
	application := gatedServer(t)
	application.config.Auth.SessionIdleTTLSeconds = 300
	liveSession(application, "session-1")
	application.sessions["session-1"].LastSeen = time.Now().UTC().Add(-301 * time.Second)
	response := get(application.routes(), "/", withSession("session-1"))
	if response.Code == http.StatusOK || strings.Contains(response.Body.String(), spaMarker) {
		t.Fatalf("an idle-expired session still reached the catalogue: status=%d", response.Code)
	}
	if _, held := application.sessions["session-1"]; held {
		t.Fatal("an expired session was not dropped from the store")
	}
}

func TestGatedRefusesSessionPastItsAbsoluteLifetime(t *testing.T) {
	application := gatedServer(t)
	liveSession(application, "session-1")
	// Active the whole time — only the absolute lifetime forces re-login, which
	// on this service is the only thing that ever rechecks with AuthN.
	application.sessions["session-1"].LastSeen = time.Now().UTC()
	application.sessions["session-1"].EndsAt = time.Now().UTC().Add(-time.Second)
	if response := get(application.routes(), "/", withSession("session-1")); response.Code == http.StatusOK {
		t.Fatalf("a session past its absolute lifetime still reached the catalogue: status=%d", response.Code)
	}
}

func TestGatedRefusesUnknownAndTamperedSessionCookies(t *testing.T) {
	application := gatedServer(t)
	liveSession(application, "session-1")
	handler := application.routes()
	for _, value := range []string{"", "session-2", "session-1x", "SESSION-1", "session-1 ", "../session-1"} {
		response := get(handler, "/", withSession(value))
		if response.Code == http.StatusOK || strings.Contains(response.Body.String(), spaMarker) {
			t.Fatalf("session cookie %q was accepted: status=%d", value, response.Code)
		}
	}
}

func TestGatedLogoutEndsTheSession(t *testing.T) {
	application := gatedServer(t)
	// No logout endpoint: this test is about the local session ending, not
	// about the call to AuthN.
	application.config.Auth.LogoutEndpoint = ""
	liveSession(application, "session-1")
	handler := application.routes()

	if response := get(handler, "/", withSession("session-1")); response.Code != http.StatusOK {
		t.Fatalf("precondition failed: authenticated caller was refused: status=%d", response.Code)
	}

	request := httptest.NewRequest(http.MethodPost, "https://ui-lib.ayc.io/auth/logout", nil)
	request.AddCookie(&http.Cookie{Name: sessionCookie, Value: "session-1"})
	request.Header.Set("Origin", "https://ui-lib.ayc.io")
	request.Header.Set("Sec-Fetch-Site", "same-origin")
	logout := httptest.NewRecorder()
	handler.ServeHTTP(logout, request)
	if logout.Code != http.StatusSeeOther {
		t.Fatalf("logout status=%d body=%s", logout.Code, logout.Body.String())
	}
	if _, held := application.sessions["session-1"]; held {
		t.Fatal("logout left the session in the store")
	}
	if response := get(handler, "/", withSession("session-1")); response.Code == http.StatusOK {
		t.Fatalf("the session still worked after logout: status=%d", response.Code)
	}
}

func TestGatedRefusesCrossOriginLogout(t *testing.T) {
	application := gatedServer(t)
	liveSession(application, "session-1")
	request := httptest.NewRequest(http.MethodPost, "https://ui-lib.ayc.io/auth/logout", nil)
	request.AddCookie(&http.Cookie{Name: sessionCookie, Value: "session-1"})
	request.Header.Set("Origin", "https://evil.example.com")
	response := httptest.NewRecorder()
	application.routes().ServeHTTP(response, request)
	if response.Code != http.StatusForbidden {
		t.Fatalf("cross-origin logout status=%d, want 403", response.Code)
	}
	if _, held := application.sessions["session-1"]; !held {
		t.Fatal("a cross-origin request ended somebody's session")
	}
}

// ---------------------------------------------------------------------------
// The login round trip, against a stand-in AuthN.
// ---------------------------------------------------------------------------

func TestGatedLoginRoundTripAdmitsTheCaller(t *testing.T) {
	authn := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.ParseForm() != nil || r.Form.Get("grant_type") != "authorization_code" || r.Form.Get("code") != "auth-code" || r.Form.Get("code_verifier") == "" {
			t.Errorf("unexpected token request: %v", r.Form)
		}
		if r.Header.Get("DPoP") == "" {
			t.Error("token request was not proof-bound")
		}
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("Cache-Control", "no-store")
		_ = json.NewEncoder(w).Encode(humanTokenResponse{AccessToken: "identity", TokenType: "DPoP", ExpiresIn: 120, RefreshToken: "refresh"})
	}))
	defer authn.Close()

	application := gatedServer(t)
	application.config.Auth.TokenEndpoint = authn.URL + "/token"
	application.config.Auth.TokenProofEndpoint = authn.URL + "/token"
	application.client = authn.Client()
	handler := application.routes()

	login := get(handler, "/auth/login?return=/components/button")
	if login.Code != http.StatusFound {
		t.Fatalf("login status=%d", login.Code)
	}
	authorize, err := url.Parse(login.Header().Get("Location"))
	if err != nil {
		t.Fatal(err)
	}
	if authorize.Query().Get("code_challenge_method") != "S256" || authorize.Query().Get("code_challenge") == "" || authorize.Query().Get("state") == "" {
		t.Fatalf("authorize redirect is not a PKCE flow: %q", authorize.String())
	}
	if authorize.Query().Get("redirect_uri") != "https://ui-lib.ayc.io/auth/callback" {
		t.Fatalf("redirect_uri drifted: %q", authorize.Query().Get("redirect_uri"))
	}
	var flowProof string
	for _, cookie := range login.Result().Cookies() {
		if cookie.Name == loginFlowCookie {
			flowProof = cookie.Value
			if !cookie.Secure || !cookie.HttpOnly {
				t.Fatal("login flow cookie is not Secure+HttpOnly")
			}
		}
	}
	if flowProof == "" {
		t.Fatal("login did not bind the flow to this browser")
	}

	callback := get(handler, "/auth/callback?state="+url.QueryEscape(authorize.Query().Get("state"))+"&code=auth-code", func(r *http.Request) {
		r.AddCookie(&http.Cookie{Name: loginFlowCookie, Value: flowProof})
	})
	if callback.Code != http.StatusSeeOther || callback.Header().Get("Location") != "/components/button" {
		t.Fatalf("callback status=%d location=%q body=%s", callback.Code, callback.Header().Get("Location"), callback.Body.String())
	}
	var sessionID string
	for _, cookie := range callback.Result().Cookies() {
		if cookie.Name == sessionCookie && cookie.Value != "" {
			sessionID = cookie.Value
			if !cookie.Secure || !cookie.HttpOnly || cookie.SameSite != http.SameSiteLaxMode || cookie.Path != "/" {
				t.Fatalf("session cookie flags are unsafe: %#v", cookie)
			}
		}
	}
	if sessionID == "" {
		t.Fatal("callback issued no session")
	}
	if response := get(handler, "/", withSession(sessionID)); response.Code != http.StatusOK || !strings.Contains(response.Body.String(), spaMarker) {
		t.Fatalf("the logged-in caller was still refused: status=%d", response.Code)
	}
}

func TestGatedCallbackRefusesFlowsItDidNotStart(t *testing.T) {
	newFlow := func(application *server, state string, expires time.Time) string {
		proof, _ := randomToken(32)
		application.flows[state] = loginFlow{Verifier: "verifier", ReturnTo: "/", BrowserProof: sha256.Sum256([]byte(proof)), ExpiresAt: expires}
		return proof
	}
	for name, run := range map[string]func(*testing.T){
		"unknown state": func(t *testing.T) {
			application := gatedServer(t)
			newFlow(application, "state-1", time.Now().UTC().Add(time.Minute))
			if response := get(application.routes(), "/auth/callback?state=state-2&code=c"); response.Code != http.StatusBadRequest {
				t.Fatalf("status=%d", response.Code)
			}
		},
		"no browser proof cookie": func(t *testing.T) {
			application := gatedServer(t)
			newFlow(application, "state-1", time.Now().UTC().Add(time.Minute))
			if response := get(application.routes(), "/auth/callback?state=state-1&code=c"); response.Code != http.StatusBadRequest {
				t.Fatalf("status=%d", response.Code)
			}
		},
		"wrong browser proof cookie": func(t *testing.T) {
			application := gatedServer(t)
			newFlow(application, "state-1", time.Now().UTC().Add(time.Minute))
			response := get(application.routes(), "/auth/callback?state=state-1&code=c", func(r *http.Request) {
				r.AddCookie(&http.Cookie{Name: loginFlowCookie, Value: "somebody-elses-proof"})
			})
			if response.Code != http.StatusBadRequest {
				t.Fatalf("status=%d", response.Code)
			}
		},
		"expired flow": func(t *testing.T) {
			application := gatedServer(t)
			proof := newFlow(application, "state-1", time.Now().UTC().Add(-time.Second))
			response := get(application.routes(), "/auth/callback?state=state-1&code=c", func(r *http.Request) {
				r.AddCookie(&http.Cookie{Name: loginFlowCookie, Value: proof})
			})
			if response.Code != http.StatusBadRequest {
				t.Fatalf("status=%d", response.Code)
			}
		},
		"replayed state": func(t *testing.T) {
			application := gatedServer(t)
			proof := newFlow(application, "state-1", time.Now().UTC().Add(time.Minute))
			// The first attempt fails at the token exchange (no AuthN wired),
			// but it must still have consumed the flow.
			get(application.routes(), "/auth/callback?state=state-1&code=c", func(r *http.Request) {
				r.AddCookie(&http.Cookie{Name: loginFlowCookie, Value: proof})
			})
			response := get(application.routes(), "/auth/callback?state=state-1&code=c", func(r *http.Request) {
				r.AddCookie(&http.Cookie{Name: loginFlowCookie, Value: proof})
			})
			if response.Code != http.StatusBadRequest {
				t.Fatalf("a consumed login flow was replayable: status=%d", response.Code)
			}
		},
	} {
		t.Run(name, run)
	}
}

func TestLoginFlowsAndSessionsAreBounded(t *testing.T) {
	application := gatedServer(t)
	handler := application.routes()
	for i := 0; i < maxLoginFlows; i++ {
		if response := get(handler, "/auth/login"); response.Code != http.StatusFound {
			t.Fatalf("login %d refused early: status=%d", i, response.Code)
		}
	}
	if response := get(handler, "/auth/login"); response.Code != http.StatusServiceUnavailable {
		t.Fatalf("login flow store is unbounded: status=%d flows=%d", response.Code, len(application.flows))
	}
	if len(application.flows) != maxLoginFlows {
		t.Fatalf("login flow store held %d flows, want %d", len(application.flows), maxLoginFlows)
	}
}

// ---------------------------------------------------------------------------
// Configuration: absent, complete, partial.
// ---------------------------------------------------------------------------

func writeConfig(t *testing.T, body string) string {
	t.Helper()
	path := filepath.Join(t.TempDir(), "uif.json")
	if err := os.WriteFile(path, []byte(body), 0o600); err != nil {
		t.Fatal(err)
	}
	return path
}

// No config file, and a config file without an auth group, are startup
// failures: uif has no ungated mode (issue-2602).
func TestNoConfigOrNoAuthGroupIsAStartupFailure(t *testing.T) {
	for name, path := range map[string]string{
		"no config path":         "",
		"no auth group":          writeConfig(t, `{"listen":"127.0.0.1:9090","staticDir":"/srv/uif"}`),
		"null auth group":        writeConfig(t, `{"auth":null}`),
		"empty top-level object": writeConfig(t, `{}`),
	} {
		t.Run(name, func(t *testing.T) {
			if loaded, err := loadConfig(path); err == nil {
				t.Fatalf("uif would start ungated: %#v", loaded)
			}
		})
	}
}

func TestCompleteAuthGroupTurnsTheGateOn(t *testing.T) {
	loaded, err := loadConfig(writeConfig(t, `{
	  "listen": "0.0.0.0:8080",
	  "staticDir": "/app/static",
	  "auth": {
	    "publicBaseUrl": "https://ui-lib.ayc.io/",
	    "authorizeEndpoint": "https://auth.ui.dev.ayc.io/realms/org/authorize",
	    "tokenEndpoint": "https://auth.api.ayc.io/realms/org/token",
	    "tokenProofEndpoint": "https://auth.api.ayc.io/realms/org/token",
	    "logoutEndpoint": "https://auth.api.ayc.io/realms/org/logout",
	    "clientId": "emibs-ui-lib",
	    "sessionIdleTtlSeconds": 3600
	  }
	}`))
	if err != nil {
		t.Fatalf("a complete auth group was rejected: %v", err)
	}
	if loaded.Auth == nil || loaded.Listen != defaultListen || loaded.StaticDir != defaultStaticDir {
		t.Fatalf("a complete auth group did not load as configured: %#v", loaded)
	}
	if loaded.Auth.PublicBaseURL != "https://ui-lib.ayc.io" {
		t.Fatalf("publicBaseUrl was not normalised to an origin: %q", loaded.Auth.PublicBaseURL)
	}
}

// The committed example must actually be a valid complete group — an example
// that does not load is how a partial configuration gets written by hand.
func TestCommittedConfigExampleIsAValidCompleteGroup(t *testing.T) {
	loaded, err := loadConfig("config.example.json")
	if err != nil {
		t.Fatalf("config.example.json does not load: %v", err)
	}
	if loaded.Auth == nil {
		t.Fatal("config.example.json does not carry the auth group")
	}
}

// A partially-configured gate must be a startup failure, never a half-live
// gate. Every one of these must stop the process rather than serve.
func TestPartialConfigurationIsAStartupFailure(t *testing.T) {
	const complete = `"publicBaseUrl":"https://ui-lib.ayc.io","authorizeEndpoint":"https://a.ayc.io/authorize","tokenEndpoint":"https://a.ayc.io/token","tokenProofEndpoint":"https://a.ayc.io/token","clientId":"emibs-ui-lib","sessionIdleTtlSeconds":3600`
	for name, body := range map[string]string{
		"empty auth group":            `{"auth":{}}`,
		"missing clientId":            `{"auth":{"publicBaseUrl":"https://ui-lib.ayc.io","authorizeEndpoint":"https://a.ayc.io/authorize","tokenEndpoint":"https://a.ayc.io/token","tokenProofEndpoint":"https://a.ayc.io/token","sessionIdleTtlSeconds":3600}}`,
		"missing tokenEndpoint":       `{"auth":{"publicBaseUrl":"https://ui-lib.ayc.io","authorizeEndpoint":"https://a.ayc.io/authorize","tokenProofEndpoint":"https://a.ayc.io/token","clientId":"c","sessionIdleTtlSeconds":3600}}`,
		"missing tokenProofEndpoint":  `{"auth":{"publicBaseUrl":"https://ui-lib.ayc.io","authorizeEndpoint":"https://a.ayc.io/authorize","tokenEndpoint":"https://a.ayc.io/token","clientId":"c","sessionIdleTtlSeconds":3600}}`,
		"missing publicBaseUrl":       `{"auth":{"authorizeEndpoint":"https://a.ayc.io/authorize","tokenEndpoint":"https://a.ayc.io/token","tokenProofEndpoint":"https://a.ayc.io/token","clientId":"c","sessionIdleTtlSeconds":3600}}`,
		"missing sessionIdleTtl":      `{"auth":{` + complete[:strings.Index(complete, `,"sessionIdleTtlSeconds"`)] + `}}`,
		"session ttl below floor":     `{"auth":{` + strings.Replace(complete, "3600", "60", 1) + `}}`,
		"session ttl above ceiling":   `{"auth":{` + strings.Replace(complete, "3600", "999999", 1) + `}}`,
		"plaintext token endpoint":    `{"auth":{` + strings.Replace(complete, `"tokenEndpoint":"https://a.ayc.io/token"`, `"tokenEndpoint":"http://a.ayc.io/token"`, 1) + `}}`,
		"public base url with a path": `{"auth":{` + strings.Replace(complete, `"publicBaseUrl":"https://ui-lib.ayc.io"`, `"publicBaseUrl":"https://ui-lib.ayc.io/catalogue"`, 1) + `}}`,
		"invalid logout endpoint":     `{"auth":{` + complete + `,"logoutEndpoint":"not-a-url"}}`,
		"unknown field in the group":  `{"auth":{` + complete + `,"authzExchangeEndpoint":"https://a.ayc.io/oauth/token"}}`,
	} {
		t.Run(name, func(t *testing.T) {
			if loaded, err := loadConfig(writeConfig(t, body)); err == nil {
				t.Fatalf("a partial auth group started anyway: %#v", loaded)
			}
		})
	}
}

// A config path that is set but unusable is a startup failure too: falling back
// to anything would turn a provisioning mistake into a silently ungated public
// surface.
func TestUnusableConfigPathIsAStartupFailureNotOpenMode(t *testing.T) {
	for name, path := range map[string]string{
		"missing file": filepath.Join(t.TempDir(), "absent.json"),
		"a directory":  t.TempDir(),
		"empty file":   writeConfig(t, ""),
		"not JSON":     writeConfig(t, "listen = 0.0.0.0:8080"),
	} {
		t.Run(name, func(t *testing.T) {
			if loaded, err := loadConfig(path); err == nil {
				t.Fatalf("an unusable config path fell back to open mode: %#v", loaded)
			}
		})
	}
}

func TestStaticServingStaysInsideTheStaticRoot(t *testing.T) {
	root := t.TempDir()
	if err := os.WriteFile(filepath.Join(root, "index.html"), []byte(spaMarker), 0o600); err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(filepath.Dir(root), "outside.txt"), []byte("secret"), 0o600); err != nil {
		t.Fatal(err)
	}
	application := gatedServer(t)
	application.config.StaticDir = root
	liveSession(application, "session-1")
	handler := application.routes()
	for _, path := range []string{"/../outside.txt", "/..%2Foutside.txt", "/a/../../outside.txt"} {
		response := get(handler, path, withSession("session-1"))
		if strings.Contains(response.Body.String(), "secret") {
			t.Fatalf("%s escaped the static root", path)
		}
	}
}

// startLoginFlow drives /auth/login and returns the state and the browser-bound
// flow proof, so a test can reach the callback the way a real browser does.
func startLoginFlow(t *testing.T, handler http.Handler) (state, flowProof string) {
	t.Helper()
	login := get(handler, "/auth/login?return=/")
	if login.Code != http.StatusFound {
		t.Fatalf("login status=%d", login.Code)
	}
	authorize, err := url.Parse(login.Header().Get("Location"))
	if err != nil {
		t.Fatal(err)
	}
	for _, cookie := range login.Result().Cookies() {
		if cookie.Name == loginFlowCookie {
			flowProof = cookie.Value
		}
	}
	if flowProof == "" {
		t.Fatal("login did not bind the flow to this browser")
	}
	return authorize.Query().Get("state"), flowProof
}

// TestHostedAuthOutageDeniesAndIssuesNoSession is the "service failure denies"
// acceptance of issue-2602 and the "hosted outage" case of issue-2603.
//
// The failure mode being excluded is the one that makes a gate worthless: an
// identity provider that is unreachable, erroring, or answering with something
// unusable must not end in an admitted caller. The gate must stay SHUT when the
// thing it depends on is broken — a gate that opens when its authority is down
// is worse than no gate, because it looks protected.
//
// uif never re-contacts AuthN after login, so an outage cannot affect a session
// that already exists; the whole exposure is at the callback, which is what this
// drives.
func TestHostedAuthOutageDeniesAndIssuesNoSession(t *testing.T) {
	for _, outage := range []struct {
		name    string
		handler http.HandlerFunc
	}{
		{"token endpoint 500s", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusInternalServerError) }},
		{"token endpoint refuses", func(w http.ResponseWriter, _ *http.Request) { w.WriteHeader(http.StatusUnauthorized) }},
		{"token endpoint returns junk", func(w http.ResponseWriter, _ *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			_, _ = w.Write([]byte("not json"))
		}},
		{"token endpoint returns an empty token", func(w http.ResponseWriter, _ *http.Request) {
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(humanTokenResponse{AccessToken: "", TokenType: "DPoP", ExpiresIn: 120})
		}},
	} {
		t.Run(outage.name, func(t *testing.T) {
			authn := httptest.NewServer(outage.handler)
			defer authn.Close()

			application := gatedServer(t)
			application.config.Auth.TokenEndpoint = authn.URL + "/token"
			application.config.Auth.TokenProofEndpoint = authn.URL + "/token"
			application.client = authn.Client()
			handler := application.routes()

			state, flowProof := startLoginFlow(t, handler)
			callback := get(handler, "/auth/callback?state="+url.QueryEscape(state)+"&code=auth-code", func(r *http.Request) {
				r.AddCookie(&http.Cookie{Name: loginFlowCookie, Value: flowProof})
			})

			if callback.Code < 400 {
				t.Fatalf("an authority outage produced a non-error callback: status=%d", callback.Code)
			}
			for _, cookie := range callback.Result().Cookies() {
				if cookie.Name == sessionCookie && cookie.Value != "" {
					t.Fatalf("an authority outage still issued a session: %q", cookie.Value)
				}
			}
			// And the surface is still shut afterwards.
			if response := get(handler, "/"); response.Code != http.StatusUnauthorized {
				t.Fatalf("content was served after a failed login: status=%d", response.Code)
			}
		})
	}
}

// TestNoCredentialShortcutAdmitsACaller is the "production absence of dev-token
// paths" acceptance of issue-2603.
//
// The only way into this surface is a completed login flow. This pins that
// nothing ELSE is accepted — no bearer token, no shared secret header, no query
// parameter, no forwarded-identity header a proxy might attach. Those are the
// shapes a "temporary" bypass takes, and the point of writing them down as a
// test is that adding one later has to break this deliberately rather than
// quietly.
func TestNoCredentialShortcutAdmitsACaller(t *testing.T) {
	handler := gatedServer(t).routes()

	for _, shortcut := range []struct {
		name  string
		apply func(*http.Request)
	}{
		{"bearer token", func(r *http.Request) { r.Header.Set("Authorization", "Bearer any-token") }},
		{"basic auth", func(r *http.Request) { r.SetBasicAuth("admin", "admin") }},
		{"dev token header", func(r *http.Request) { r.Header.Set("X-Dev-Token", "dev") }},
		{"forwarded identity", func(r *http.Request) { r.Header.Set("X-Forwarded-User", "someone") }},
		{"forwarded auth decision", func(r *http.Request) { r.Header.Set("X-Auth-Request-Email", "someone@example.com") }},
		{"query parameter", func(r *http.Request) { r.URL.RawQuery = "token=dev&dev=1&debug=1" }},
		{"empty session cookie", func(r *http.Request) { r.AddCookie(&http.Cookie{Name: sessionCookie, Value: ""}) }},
	} {
		t.Run(shortcut.name, func(t *testing.T) {
			if response := get(handler, "/", shortcut.apply); response.Code != http.StatusUnauthorized {
				t.Fatalf("%s admitted a caller: status=%d", shortcut.name, response.Code)
			}
		})
	}
}
