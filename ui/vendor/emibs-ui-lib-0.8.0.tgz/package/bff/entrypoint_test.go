package main

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

// These tests pin issue-2602: the public entrypoint is fail-closed. They enter
// through serverFromEnvironment and httpServer, which is exactly the composition
// main() performs, so they exercise the handler the binary actually mounts.

const gatedConfigJSON = `{
  "auth": {
    "publicBaseUrl": "https://ui-lib.ayc.io",
    "authorizeEndpoint": "https://auth.api.ayc.io/realms/org/authorize",
    "tokenEndpoint": "https://auth.api.ayc.io/realms/org/token",
    "tokenProofEndpoint": "https://auth.api.ayc.io/realms/org/token",
    "logoutEndpoint": "https://auth.api.ayc.io/realms/org/logout",
    "clientId": "uif-browser",
    "sessionIdleTtlSeconds": 3600
  }
}`

func environment(values map[string]string) func(string) string {
	return func(key string) string { return values[key] }
}

// mountedServer builds the server the way main does, from a config file named by
// UI_LIB_CONFIG_FILE, with the static root pointed at a test catalogue.
func mountedServer(t *testing.T) (*server, http.Handler) {
	t.Helper()
	root := staticRoot(t)
	body := strings.Replace(gatedConfigJSON, `"auth"`, `"staticDir": "`+root+`", "auth"`, 1)
	application, err := serverFromEnvironment(environment(map[string]string{"UI_LIB_CONFIG_FILE": writeConfig(t, body)}))
	if err != nil {
		t.Fatalf("a complete configuration was refused: %v", err)
	}
	return application, application.httpServer().Handler
}

// There is no ungated mode. Every way of starting the process without a complete
// authentication group must stop it, because the only thing it could otherwise
// do is serve the internal catalogue to the public internet.
func TestEntrypointRefusesToStartWithoutACompleteGate(t *testing.T) {
	for name, env := range map[string]map[string]string{
		"no UI_LIB_CONFIG_FILE":         {},
		"blank UI_LIB_CONFIG_FILE":      {"UI_LIB_CONFIG_FILE": "   "},
		"config without an auth group":  {"UI_LIB_CONFIG_FILE": writeConfig(t, `{"listen":"127.0.0.1:9090","staticDir":"/srv/uif"}`)},
		"config with a null auth group": {"UI_LIB_CONFIG_FILE": writeConfig(t, `{"auth":null}`)},
		"empty JSON object":             {"UI_LIB_CONFIG_FILE": writeConfig(t, `{}`)},
	} {
		t.Run(name, func(t *testing.T) {
			if application, err := serverFromEnvironment(environment(env)); err == nil {
				t.Fatalf("uif started without a gate: %#v", application.config)
			}
		})
	}
}

func TestEntrypointMountsTheGate(t *testing.T) {
	application, handler := mountedServer(t)
	if application.httpServer().Addr != defaultListen {
		t.Fatalf("listen address drifted: %q", application.httpServer().Addr)
	}
	if response := get(handler, "/"); response.Code != http.StatusUnauthorized {
		t.Fatalf("the mounted handler served / anonymously: status=%d", response.Code)
	}
}

var everyMethod = []string{http.MethodGet, http.MethodHead, http.MethodPost, http.MethodPut, http.MethodPatch, http.MethodDelete, http.MethodOptions}

func request(handler http.Handler, method, target string, decorate ...func(*http.Request)) *httptest.ResponseRecorder {
	r := httptest.NewRequest(method, "https://ui-lib.ayc.io"+target, nil)
	for _, apply := range decorate {
		apply(r)
	}
	response := httptest.NewRecorder()
	handler.ServeHTTP(response, r)
	return response
}

// sameOrigin makes a request look like it came from the catalogue's own page, so
// the CSRF boundary is not what refuses it: whatever refuses it must be the gate.
func sameOrigin(r *http.Request) {
	r.Header.Set("Origin", "https://ui-lib.ayc.io")
	r.Header.Set("Sec-Fetch-Site", "same-origin")
}

func leaksCatalogue(response *httptest.ResponseRecorder) bool {
	body := response.Body.String()
	return strings.Contains(body, spaMarker) || strings.Contains(body, assetMarker)
}

// The live defect this closes: the allowlist was path-only, and /auth/logout is
// registered for POST alone, so an anonymous GET /auth/logout fell through to the
// SPA fallback and was handed the catalogue shell with 200. The same happened to
// POST /auth/login and POST /auth/callback. No method on any path may reach
// catalogue content without a session.
func TestNoMethodOnAnyPathServesTheCatalogueAnonymously(t *testing.T) {
	_, handler := mountedServer(t)
	paths := []string{"/", "/index.html", "/assets/index-abc123.js", "/components/button",
		"/auth/login", "/auth/callback", "/auth/logout", "/auth", "/auth/", "/auth/unknown", "/auth/login/", "/does/not/exist"}
	for _, method := range everyMethod {
		for _, path := range paths {
			for _, navigation := range []bool{false, true} {
				decorators := []func(*http.Request){sameOrigin}
				if navigation {
					decorators = append(decorators, asNavigation)
				}
				response := request(handler, method, path, decorators...)
				if leaksCatalogue(response) {
					t.Errorf("%s %s (navigation=%v) served catalogue content anonymously: status=%d", method, path, navigation, response.Code)
				}
				if response.Code >= 200 && response.Code < 300 && response.Body.Len() > 0 && !(method == http.MethodGet && path == "/auth/login") {
					t.Errorf("%s %s (navigation=%v) answered an anonymous caller with %d and a body", method, path, navigation, response.Code)
				}
			}
		}
	}
}

// With a session the catalogue is served — but only by GET/HEAD, and never from
// under /auth/, which is the login surface and holds no catalogue content.
func TestAuthenticatedCallerGetsTheCatalogueOnlyFromCatalogueReads(t *testing.T) {
	application, handler := mountedServer(t)
	liveSession(application, "session-1")
	for _, path := range []string{"/", "/components/button", "/assets/index-abc123.js"} {
		for _, method := range []string{http.MethodGet, http.MethodHead} {
			if response := request(handler, method, path, withSession("session-1")); response.Code != http.StatusOK {
				t.Fatalf("%s %s refused an authenticated caller: status=%d", method, path, response.Code)
			}
		}
		for _, method := range []string{http.MethodPost, http.MethodPut, http.MethodPatch, http.MethodDelete} {
			response := request(handler, method, path, withSession("session-1"), sameOrigin)
			if response.Code != http.StatusMethodNotAllowed || leaksCatalogue(response) {
				t.Fatalf("%s %s with a session: status=%d, want 405 and no catalogue", method, path, response.Code)
			}
		}
	}
	for _, target := range []struct{ method, path string }{
		{http.MethodGet, "/auth/logout"}, {http.MethodPost, "/auth/login"}, {http.MethodPost, "/auth/callback"},
		{http.MethodGet, "/auth/"}, {http.MethodGet, "/auth/unknown"},
	} {
		response := request(handler, target.method, target.path, withSession("session-1"), sameOrigin)
		if response.Code < 400 || leaksCatalogue(response) {
			t.Fatalf("%s %s with a session: status=%d, the login surface served the catalogue", target.method, target.path, response.Code)
		}
	}
}

// A navigation to the login surface itself is refused, not bounced into a login
// whose return target is the login surface.
func TestAnonymousNavigationToTheLoginSurfaceIsNotRedirectedIntoIt(t *testing.T) {
	_, handler := mountedServer(t)
	for _, path := range []string{"/auth/logout", "/auth/", "/auth/unknown"} {
		response := request(handler, http.MethodGet, path, asNavigation)
		if response.Code != http.StatusUnauthorized {
			t.Fatalf("GET %s navigation: status=%d location=%q, want 401", path, response.Code, response.Header().Get("Location"))
		}
	}
}

// The login handler stores a caller-supplied return target and redirects to it
// after login. A browser treats a backslash as a slash and strips tab, CR and LF
// from a URL, so "/\evil" and "/<TAB>/evil" both become "//evil" — a
// protocol-relative, off-origin redirect. Only a plain same-origin path survives.
func TestLoginReturnTargetCannotBecomeAnOpenRedirect(t *testing.T) {
	for _, offered := range []string{
		"/\\evil.example.com", "/\\/evil.example.com", "\\\\evil.example.com",
		"/\t/evil.example.com", "/\r\n/evil.example.com", "/\n/evil.example.com",
		"//evil.example.com", "https://evil.example.com/", "/%5Cevil.example.com",
		"/\x00/evil.example.com", "/ /evil.example.com", "/\x7f/evil.example.com",
	} {
		application, handler := mountedServer(t)
		login := request(handler, http.MethodGet, "/auth/login?return="+url.QueryEscape(offered))
		if login.Code != http.StatusFound {
			t.Fatalf("login status=%d for %q", login.Code, offered)
		}
		for _, flow := range application.flows {
			if flow.ReturnTo != "/" && !safeReturnTarget(flow.ReturnTo) {
				t.Fatalf("login stored an unsafe return target %q -> %q", offered, flow.ReturnTo)
			}
			if strings.ContainsAny(flow.ReturnTo, "\\\t\r\n\x00\x7f ") || strings.HasPrefix(flow.ReturnTo, "//") {
				t.Fatalf("login stored an off-origin return target %q -> %q", offered, flow.ReturnTo)
			}
		}
	}
	// A legitimate deep link keeps its path and query.
	application, handler := mountedServer(t)
	request(handler, http.MethodGet, "/auth/login?return="+url.QueryEscape("/components/button?variant=ghost"))
	for _, flow := range application.flows {
		if flow.ReturnTo != "/components/button?variant=ghost" {
			t.Fatalf("a same-origin deep link was not preserved: %q", flow.ReturnTo)
		}
	}
}
