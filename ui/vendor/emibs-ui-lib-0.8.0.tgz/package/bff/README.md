# uif BFF — the access gate for `ui-lib.ayc.io`

`packages/emibs-ui-lib` is an **internal** design catalogue that has been
reachable on the public internet with no credential. The repository `AGENT.md`
records the surface as *"External, **public**: the route carries no access
gate."* Until this program existed the catalogue could not gate itself: it was a
static SPA served by nginx, so nothing in-process could hold a session, and a
client-side guard protects nothing — the assets are handed to the anonymous
caller before any script runs.

This is that missing in-process gate. It is modelled on `emibs-files-ui/bff`,
the working reference in this repository, which is why the Files surface is not
exposed the way uif is. What it deliberately does not copy is Files' AuthZ
capability exchange: uif has no backend API and makes no downstream calls, so
**authentication is the whole gate**.

## One mode: gated (issue-2602)

The BFF first shipped **inert** (issue-2601): with no configuration it served
the catalogue openly, exactly as nginx had, so that merging it could not switch
a gate on unattended — uif redeploys every five minutes off `origin/score-work`
(`emibs-deploy-agent`, stack `ui-lib`). The gate has been on since 2026-09-04,
and that open mode then stopped being a migration step and became the one way
the process could still hand the catalogue to the public internet: dropping
`UI_LIB_CONFIG_FILE` from the compose file, or the `auth` group from the config,
would have reopened it on the next deploy with a green `/health` probe.

So the open mode is gone and the entrypoint is fail-closed:

| Configuration | Behaviour |
| --- | --- |
| No `UI_LIB_CONFIG_FILE` | **Startup failure.** |
| `UI_LIB_CONFIG_FILE` unusable (missing file, a directory, empty, not JSON, over 256 KiB) | **Startup failure.** |
| Config with no `auth` group, or `"auth": null` | **Startup failure.** |
| `auth` group present but partial or invalid | **Startup failure.** |
| Complete `auth` group | The gate is live. No session means no content — not the SPA shell, not an arbitrary route, not an asset, on any method. |

The unauthenticated surface is a pinned list of **method and path** pairs:
`/health` and `/robots.txt` on any method, `GET /auth/login`,
`GET /auth/callback`, `POST /auth/logout`. Everything else needs a session. A
login route on the wrong method answers `405`, an unknown `/auth/` path `404`,
and neither ever reaches the catalogue; the catalogue itself serves `GET` and
`HEAD` only. (The allowlist used to be path-only, which let an anonymous
`GET /auth/logout` fall through to the SPA fallback and receive the shell with
`200` — the defect issue-2602 closed.)

`/health` is unauthenticated: it is the container healthcheck and the deploy
agent's probe, and a healthcheck that needs a credential is a healthcheck that
fails.

## Required configuration

`UI_LIB_CONFIG_FILE` names a JSON file (`config.example.json` mirrors the live
shape). Unknown fields are rejected.

| Field | Required | Meaning |
| --- | --- | --- |
| `listen` | no (default `0.0.0.0:8080`) | Listener address inside the container. |
| `staticDir` | no (default `/app/static`) | The built catalogue. |
| `auth.publicBaseUrl` | yes | The browser origin, `https://ui-lib.ayc.io`. An https origin with no path (loopback http is accepted for local runs). The callback is `<publicBaseUrl>/auth/callback` and must be registered on the AuthN client. |
| `auth.authorizeEndpoint` | yes | The realm's `/authorize` on the hosted AuthN. |
| `auth.tokenEndpoint` | yes | The realm's `/token`. |
| `auth.tokenProofEndpoint` | yes | The URL the DPoP proof is bound to; the canonical token URL. |
| `auth.logoutEndpoint` | no | The realm's `/logout`; when set, logout revokes the AuthN session too. |
| `auth.clientId` | yes | The AuthN browser client, `uif-browser`. |
| `auth.sessionIdleTtlSeconds` | yes, 300-86400 | Idle timeout of a uif session. |

## The gate is ON

Turned on under issue-2601 on 2026-09-04. All three prerequisites are in place:

1. **AuthN browser client `uif-browser`**, redirect URI
   `https://ui-lib.ayc.io/auth/callback`. Its audience is `uif`, deliberately
   **not** `emibs-svc-authz`: browser-client audiences must be unique across the
   realm and `elitua-browser` already holds that one, so copying the workload
   convention would have refused realm startup and taken AuthN down.
   See `deployment/authn/WORKLOAD-CLIENT-REGISTRATION.md`.
2. **`/apps/ui-lib/config/uif.json` on the host**, mounted read-only at
   `/run/config/uif.json` with `UI_LIB_CONFIG_FILE` pointing at it — both set in
   `../docker-compose.yml`. `config.example.json` mirrors the live shape.
3. **The deploy agent's `ui-lib` verify probe is `/health`, not `/`.** Once the
   gate is live `/` answers `401` to the anonymous prober, so a `/` probe reads a
   successful rollout as a verify failure and rolls it back. That registry lives
   in `/engineering/agents/bin/emibs-deploy-agent`, outside this repository.

**Keeping it on.** The host config file is not optional state: without it, or
without its `auth` group, the process does not start, so losing it takes the
catalogue down rather than quietly reopening it. That is the intended trade.
There is no switch that turns the gate off; serving the catalogue publicly
again would be a code change reviewed as one.

`deployment/access-posture/inventory.json` declares this host `session-gated`
with no exception, and a test pins both, so re-excusing the exposure or
relabelling the host public fails the build.

### Verifying it

Anonymous checks, runnable by anyone:

```sh
curl -s -o /dev/null -w '%{http_code}\n' https://ui-lib.ayc.io/            # 401
curl -s -o /dev/null -w '%{http_code}\n' https://ui-lib.ayc.io/auth/logout # 401 (issue-2602)
curl -s -o /dev/null -w '%{http_code}\n' https://ui-lib.ayc.io/health      # 200
curl -s -o /dev/null -w '%{http_code}\n' https://ui-lib.ayc.io/robots.txt  # 200
curl -s -o /dev/null -w '%{http_code} %{redirect_url}\n' https://ui-lib.ayc.io/auth/login
#   302 to <AuthN>/realms/org/authorize?client_id=uif-browser&redirect_uri=https%3A%2F%2Fui-lib.ayc.io%2Fauth%2Fcallback&...
```

The last check proves the login leg is wired: following that redirect must land
on the hosted Auth UI's sign-in page, not an AuthN error (an unregistered client
or redirect URI is refused there). The only step no script can do is the sign-in
itself, which needs a realm identity: open `https://ui-lib.ayc.io/` in a browser,
sign in, and the catalogue loads. The full round trip, including the Google leg,
is proven against mocks by `production_test.go` on every change.

A `200` on the first line means the gate is not enforcing. Since issue-2602 that
cannot come from configuration, because the process refuses to start without its
gate. Check which image is actually running.

The estate-wide equivalent is the access-posture prober, which carries the same
probes for this host: `deployment/access-posture`, `go run ./cmd/access-posture`.

## Session model

Sessions live server-side; the browser holds only an opaque `__Host-uif-session`
cookie (`Secure`, `HttpOnly`, `SameSite=Lax`, `Path=/`, `Max-Age` = the
12-hour absolute lifetime). Login is PKCE
(`S256`) against the hosted Auth UI, with a one-time `__Host-uif-login-flow`
proof cookie binding the callback to the browser that started the flow, so a
leaked authorization code cannot be redeemed from elsewhere. Both server-side
stores are pruned on write and hard-capped; past the cap a new login is refused
rather than allowed to grow the process.

A session ends at whichever comes first: the configured idle TTL (sliding, and
enforced server-side), the fixed 12-hour absolute lifetime, logout, or a restart
of the process. Sessions live only in memory, so every deploy signs everyone out
and an old cookie is refused by the new process. That absolute cap is a deliberate deviation from
`emibs-files-ui/bff`'s 30-day refresh window. Files re-presents its refresh token
to AuthN on every capability exchange, so a revoked account stops working there
quickly. uif never speaks to AuthN again after login, so the absolute lifetime
*is* the re-authentication interval.

The cookie outlives the idle window on purpose: until issue-2603 its `Max-Age`
was the idle TTL, set once at login, which ended an active session one idle-TTL
after sign-in.

## Regression and production-like tests

`main_test.go` and `entrypoint_test.go` drive the handler in-process, entering
through `serverFromEnvironment` + `httpServer`, the composition `main()` mounts.

`production_test.go` (issue-2603) drives the **shipped binary**. It `go build`s
this package the way the Dockerfile does and runs it as its own process with a
real `UI_LIB_CONFIG_FILE`, behind a TLS edge proxy standing in for Caddy. Its
identity providers are loopback mocks and nothing live is contacted (SK.42). The
AuthN mock refuses unregistered clients and redirect URIs, requires PKCE S256,
redeems each code once, and verifies DPoP proofs with `emibs-auth-go`. It
federates to a Google mock that redirects only to AuthN's registered provider
callback. The suite covers:

| Case | Test |
| --- | --- |
| The process will not start without its gate | `TestProductionBinaryRefusesToStartWithoutItsGate` |
| The container healthcheck subcommand | `TestProductionHealthcheckSubcommand` |
| Anonymous denial: shell, deep links, assets, wrong-method login routes, every credential shortcut | `TestProductionAnonymousCallerGetsNoCatalogue` |
| Google callback and session: a deep link goes through AuthN and Google and back, and the session opens the shell and assets; cookie attributes are checked | `TestProductionGoogleSignInEstablishesASessionAtTheDeepLink` |
| Google consent denied | `TestProductionGoogleConsentDeniedIssuesNoSession` |
| A callback replayed from another browser, or replayed at all | `TestProductionCallbackIsBoundToTheBrowserThatStartedIt` |
| Logout: local, proof-bound revocation at AuthN, a replayed old cookie, a cross-site logout | `TestProductionLogoutEndsTheSessionEverywhere` |
| Hosted outage and then recovery | `TestProductionHostedOutageDeniesThenRecovers` |
| A restart (every deploy) invalidates sessions | `TestProductionRestartInvalidatesSessionsAndFailsClosed` |
| The cookie does not end an active session early | `TestProductionSessionCookieDoesNotEndAnActiveSessionEarly` |
| A 200 token response that breaks the contract (cacheable, over-long) | `TestProductionOffContractTokenResponseIssuesNoSession` |

Idle and absolute expiry take minutes to hours in real time, so they are covered
in-process (`TestGatedRefusesIdleExpiredSession`,
`TestGatedRefusesSessionPastItsAbsoluteLifetime`). Go's cookie jar does not
enforce `SameSite`, so the harness asserts the attribute instead.

## No Content-Security-Policy

Neither mode asserts a CSP. The catalogue renders arbitrary component demos and
its inline-style surface has not been audited, so a guessed policy would ship a
working gate and a broken catalogue. That audit is its own piece of work.

## Build and test

```sh
scripts/go-safe build ./...   # from packages/emibs-ui-lib/bff
scripts/go-safe vet ./...
scripts/go-safe test ./...
```
