module github.com/djufo/emibs/packages/emibs-ui-lib/bff

go 1.25.0

require github.com/djufo/emibs/packages/emibs-auth-go v0.0.0

require github.com/golang-jwt/jwt/v5 v5.2.2 // indirect

replace github.com/djufo/emibs/packages/emibs-auth-go => ../../emibs-auth-go
