package main

// Production-like regression tests for the uif gate (issue-2603).
//
// Everything else in this package drives the handler in-process. These tests
// drive the SHIPPED BINARY: `go build` of this package, the same artifact the
// Dockerfile copies to /app/uif-bff, started as its own process with
// UI_LIB_CONFIG_FILE pointing at a real config file. The topology is the live one:
//
//	browser --https--> edge (Caddy's role: TLS, reverse_proxy)
//	                     --http--> uif-bff process (127.0.0.1:<port>)
//	browser <--redirects--> hosted AuthN (realm org) <--redirects--> Google
//	uif-bff --server-to-server--> hosted AuthN /token, /logout
//
// No live provider is contacted (SK.42). Hosted AuthN and Google are mocks on
// loopback, and each one enforces the contract the real service enforces on
// uif's side of the wire:
//
//   - AuthN refuses an unregistered client or redirect URI, requires PKCE S256,
//     redeems a code exactly once, and requires a DPoP proof bound to the exact
//     token URL. It answers with the four-field no-store token response.
//     Logout requires the identity token AND a proof from the key that token was
//     issued to.
//   - Google only redirects to AuthN's registered provider callback. It answers
//     either with a code or with the OIDC `error=access_denied` a person's
//     "Cancel" produces.
//
// uif never talks to Google. The Google leg is here because it is the redirect
// chain a real sign-in takes: the browser leaves uif, crosses two other
// origins, and has to come back to /auth/callback still carrying uif's one-time
// flow cookie and a state AuthN echoes unchanged. AuthN's own verification of
// Google's JWKS-signed ID token is covered by emibs-svc-auth
// (TestNamedProvidersCompleteFakeAuthorizationCodeLogin/google), not here.
//
// The cookie jar is Go's, which honours Secure and host scoping but not
// SameSite. SameSite=Lax is asserted on the Set-Cookie attributes instead,
// because Lax is what lets the flow cookie ride the cross-site top-level
// redirect back from AuthN.

import (
	"bytes"
	"crypto/sha256"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/http/cookiejar"
	"net/http/httptest"
	"net/http/httputil"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"testing"
	"time"

	emibsauth "github.com/djufo/emibs/packages/emibs-auth-go"
)

// ---------------------------------------------------------------------------
// The shipped binary.
// ---------------------------------------------------------------------------

var (
	binaryOnce sync.Once
	binaryDir  string
	binaryPath string
	binaryErr  error
)

func TestMain(m *testing.M) {
	code := m.Run()
	if binaryDir != "" {
		_ = os.RemoveAll(binaryDir)
	}
	os.Exit(code)
}

// uifBinary builds this package exactly as the Dockerfile's bff-build stage
// does (CGO off, -trimpath), once per test run.
func uifBinary(t *testing.T) string {
	t.Helper()
	binaryOnce.Do(func() {
		binaryDir, binaryErr = os.MkdirTemp("", "uif-bff-production-")
		if binaryErr != nil {
			return
		}
		binaryPath = filepath.Join(binaryDir, "uif-bff")
		build := exec.Command("go", "build", "-trimpath", "-o", binaryPath, ".")
		build.Env = append(os.Environ(), "CGO_ENABLED=0")
		if output, err := build.CombinedOutput(); err != nil {
			binaryErr = fmt.Errorf("go build of the uif BFF failed: %v\n%s", err, output)
		}
	})
	if binaryErr != nil {
		t.Fatal(binaryErr)
	}
	return binaryPath
}

type lockedBuffer struct {
	mu  sync.Mutex
	buf bytes.Buffer
}

func (b *lockedBuffer) Write(p []byte) (int, error) {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.Write(p)
}

func (b *lockedBuffer) String() string {
	b.mu.Lock()
	defer b.mu.Unlock()
	return b.buf.String()
}

type uifProcess struct {
	cmd    *exec.Cmd
	output *lockedBuffer
	exited chan struct{}
	err    error
}

// startProcess runs the binary with exactly the given environment (nothing is
// inherited, so a stray UI_LIB_CONFIG_FILE in the developer's shell cannot leak
// in) and returns without waiting for it to become healthy.
func startProcess(t *testing.T, env []string, args ...string) *uifProcess {
	t.Helper()
	process := &uifProcess{cmd: exec.Command(uifBinary(t), args...), output: &lockedBuffer{}, exited: make(chan struct{})}
	process.cmd.Env = env
	process.cmd.Stdout, process.cmd.Stderr = process.output, process.output
	if err := process.cmd.Start(); err != nil {
		t.Fatalf("start uif BFF: %v", err)
	}
	go func() {
		process.err = process.cmd.Wait()
		close(process.exited)
	}()
	t.Cleanup(process.stop)
	return process
}

func (p *uifProcess) stop() {
	select {
	case <-p.exited:
		return
	default:
	}
	_ = p.cmd.Process.Signal(syscall.SIGTERM)
	select {
	case <-p.exited:
	case <-time.After(5 * time.Second):
		_ = p.cmd.Process.Kill()
		<-p.exited
	}
}

func (p *uifProcess) waitExit(t *testing.T, within time.Duration) (exitCode int) {
	t.Helper()
	select {
	case <-p.exited:
		if p.err == nil {
			return 0
		}
		if exitErr, ok := p.err.(*exec.ExitError); ok {
			return exitErr.ExitCode()
		}
		t.Fatalf("uif BFF did not exit cleanly: %v", p.err)
	case <-time.After(within):
		t.Fatalf("uif BFF was still running after %s; output:\n%s", within, p.output.String())
	}
	return -1
}

func freeLoopbackAddress(t *testing.T) string {
	t.Helper()
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	address := listener.Addr().String()
	_ = listener.Close()
	return address
}

func waitHealthy(t *testing.T, process *uifProcess, address string) {
	t.Helper()
	deadline := time.Now().Add(15 * time.Second)
	for time.Now().Before(deadline) {
		select {
		case <-process.exited:
			t.Fatalf("uif BFF exited during startup: %v\n%s", process.err, process.output.String())
		default:
		}
		if response, err := http.Get("http://" + address + "/health"); err == nil {
			response.Body.Close()
			if response.StatusCode == http.StatusOK {
				return
			}
		}
		time.Sleep(25 * time.Millisecond)
	}
	t.Fatalf("uif BFF never became healthy on %s; output:\n%s", address, process.output.String())
}

// ---------------------------------------------------------------------------
// Mock Google (the upstream identity provider AuthN federates to).
// ---------------------------------------------------------------------------

const (
	googleClientID     = "authn-org-google"
	googleClientSecret = "mock-google-client-secret"
	googleSubject      = "google-subject-1"
)

type googleProvider struct {
	server *httptest.Server
	base   string
	mu     sync.Mutex
	// The AuthN provider callback registered on the Google client. Google
	// refuses to redirect anywhere else.
	registeredRedirect string
	denyConsent        bool
	codes              map[string]bool
	authorizations     int
}

func newGoogleProvider(t *testing.T) *googleProvider {
	g := &googleProvider{codes: map[string]bool{}}
	g.server = httptest.NewServer(http.HandlerFunc(g.serve))
	t.Cleanup(g.server.Close)
	g.base = strings.Replace(g.server.URL, "127.0.0.1", "localhost", 1)
	return g
}

func (g *googleProvider) serve(w http.ResponseWriter, r *http.Request) {
	g.mu.Lock()
	defer g.mu.Unlock()
	switch {
	case r.Method == http.MethodGet && r.URL.Path == "/o/oauth2/v2/auth":
		query := r.URL.Query()
		if query.Get("client_id") != googleClientID || query.Get("redirect_uri") != g.registeredRedirect || query.Get("response_type") != "code" || query.Get("state") == "" {
			// Google shows its own error page; it never redirects to an
			// unregistered URI.
			http.Error(w, "redirect_uri_mismatch", http.StatusBadRequest)
			return
		}
		g.authorizations++
		target, _ := url.Parse(g.registeredRedirect)
		values := url.Values{"state": {query.Get("state")}}
		if g.denyConsent {
			values.Set("error", "access_denied")
		} else {
			code := randomTestToken()
			g.codes[code] = true
			values.Set("code", code)
		}
		target.RawQuery = values.Encode()
		http.Redirect(w, r, target.String(), http.StatusFound)
	case r.Method == http.MethodPost && r.URL.Path == "/token":
		if r.ParseForm() != nil || r.PostForm.Get("client_id") != googleClientID || r.PostForm.Get("client_secret") != googleClientSecret ||
			r.PostForm.Get("redirect_uri") != g.registeredRedirect || !g.codes[r.PostForm.Get("code")] {
			writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid_grant"})
			return
		}
		delete(g.codes, r.PostForm.Get("code"))
		writeJSON(w, http.StatusOK, map[string]any{"sub": googleSubject, "email": "person@example.com", "email_verified": true})
	default:
		http.NotFound(w, r)
	}
}

// ---------------------------------------------------------------------------
// Mock hosted AuthN (realm org), the only authority uif talks to.
// ---------------------------------------------------------------------------

const uifClientID = "uif-browser"

type relyingPartyRequest struct {
	redirectURI, state, nonce, challenge string
}

type issuedCode struct {
	request relyingPartyRequest
	subject string
}

type issuedIdentity struct {
	subject, thumbprint string
	revoked             bool
}

type hostedAuthN struct {
	t      *testing.T
	server *httptest.Server
	base   string
	google *googleProvider
	mu     sync.Mutex

	registeredRedirect string
	pending            map[string]relyingPartyRequest // AuthN's own provider state -> the relying party's request
	codes              map[string]issuedCode
	identities         map[string]*issuedIdentity // access token -> binding
	proofIDs           map[string]bool
	tokenOutage        atomic.Bool
	// tokenShape, when set, makes a SUCCESSFUL-looking exchange answer with one
	// contract violation: "cacheable" drops Cache-Control: no-store, and
	// "long-lived" issues a 3600s identity token where AuthN issues 300s.
	tokenShape     atomic.Value
	tokenExchanges int
	logouts        int
}

func newHostedAuthN(t *testing.T, google *googleProvider) *hostedAuthN {
	a := &hostedAuthN{t: t, google: google, pending: map[string]relyingPartyRequest{}, codes: map[string]issuedCode{}, identities: map[string]*issuedIdentity{}, proofIDs: map[string]bool{}}
	a.server = httptest.NewServer(http.HandlerFunc(a.serve))
	t.Cleanup(a.server.Close)
	a.base = strings.Replace(a.server.URL, "127.0.0.1", "localhost", 1)
	google.registeredRedirect = a.base + "/api/realms/org/providers/google/callback"
	return a
}

func (a *hostedAuthN) tokenURL() string  { return a.base + "/realms/org/token" }
func (a *hostedAuthN) logoutURL() string { return a.base + "/realms/org/logout" }

func (a *hostedAuthN) serve(w http.ResponseWriter, r *http.Request) {
	switch {
	case r.Method == http.MethodGet && r.URL.Path == "/realms/org/authorize":
		a.authorize(w, r)
	case r.Method == http.MethodGet && r.URL.Path == "/api/realms/org/providers/google/callback":
		a.googleCallback(w, r)
	case r.Method == http.MethodPost && r.URL.Path == "/realms/org/token":
		a.token(w, r)
	case r.Method == http.MethodPost && r.URL.Path == "/realms/org/logout":
		a.logout(w, r)
	default:
		http.NotFound(w, r)
	}
}

// authorize validates the relying party's request and — standing in for the
// hosted Auth UI on which the person picks "Continue with Google" — sends the
// browser to Google.
func (a *hostedAuthN) authorize(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	if query.Get("client_id") != uifClientID || query.Get("redirect_uri") != a.registeredRedirect {
		// An unregistered client or redirect URI is shown an error by AuthN;
		// it is never redirected, or the redirect itself would be the leak.
		http.Error(w, "unregistered client or redirect_uri", http.StatusBadRequest)
		return
	}
	if query.Get("response_type") != "code" || query.Get("scope") != "openid" || query.Get("code_challenge_method") != "S256" ||
		query.Get("code_challenge") == "" || query.Get("state") == "" || query.Get("nonce") == "" {
		http.Error(w, "invalid authorization request", http.StatusBadRequest)
		return
	}
	providerState := randomTestToken()
	a.mu.Lock()
	a.pending[providerState] = relyingPartyRequest{redirectURI: query.Get("redirect_uri"), state: query.Get("state"), nonce: query.Get("nonce"), challenge: query.Get("code_challenge")}
	a.mu.Unlock()
	google := url.Values{"client_id": {googleClientID}, "redirect_uri": {a.google.registeredRedirect}, "response_type": {"code"}, "scope": {"openid email"}, "state": {providerState}}
	http.Redirect(w, r, a.google.base+"/o/oauth2/v2/auth?"+google.Encode(), http.StatusFound)
}

// googleCallback completes the upstream leg and returns the browser to the
// relying party with AuthN's OWN one-time code — or with the OIDC error when
// Google did not authenticate the person.
func (a *hostedAuthN) googleCallback(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query()
	a.mu.Lock()
	request, ok := a.pending[query.Get("state")]
	delete(a.pending, query.Get("state"))
	a.mu.Unlock()
	if !ok {
		http.Error(w, "unknown provider state", http.StatusBadRequest)
		return
	}
	back, _ := url.Parse(request.redirectURI)
	values := url.Values{"state": {request.state}}
	if query.Get("error") != "" || query.Get("code") == "" {
		values.Set("error", "access_denied")
		back.RawQuery = values.Encode()
		http.Redirect(w, r, back.String(), http.StatusFound)
		return
	}
	exchange, err := http.PostForm(a.google.base+"/token", url.Values{"grant_type": {"authorization_code"}, "code": {query.Get("code")},
		"client_id": {googleClientID}, "client_secret": {googleClientSecret}, "redirect_uri": {a.google.registeredRedirect}})
	if err != nil {
		http.Error(w, "google unavailable", http.StatusBadGateway)
		return
	}
	defer exchange.Body.Close()
	var identity struct {
		Sub           string `json:"sub"`
		EmailVerified bool   `json:"email_verified"`
	}
	if exchange.StatusCode != http.StatusOK || json.NewDecoder(exchange.Body).Decode(&identity) != nil || identity.Sub == "" || !identity.EmailVerified {
		values.Set("error", "access_denied")
		back.RawQuery = values.Encode()
		http.Redirect(w, r, back.String(), http.StatusFound)
		return
	}
	code := randomTestToken()
	a.mu.Lock()
	a.codes[code] = issuedCode{request: request, subject: "google:" + identity.Sub}
	a.mu.Unlock()
	values.Set("code", code)
	back.RawQuery = values.Encode()
	http.Redirect(w, r, back.String(), http.StatusFound)
}

func (a *hostedAuthN) token(w http.ResponseWriter, r *http.Request) {
	if a.tokenOutage.Load() {
		// The outage answer carries a token-shaped, no-store body on purpose:
		// an error page or a half-failed upstream can look like a success.
		// Only the status may decide, so only the status is wrong here.
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusServiceUnavailable)
		_ = json.NewEncoder(w).Encode(humanTokenResponse{AccessToken: "identity-outage", TokenType: "DPoP", ExpiresIn: 300, RefreshToken: "refresh-outage"})
		return
	}
	proof, err := emibsauth.VerifyDPoP(r.Header.Get("DPoP"), http.MethodPost, a.tokenURL(), "", "", time.Now().UTC())
	if err != nil || r.ParseForm() != nil {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid_dpop_proof"})
		return
	}
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.proofIDs[proof.ID] {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid_dpop_proof"})
		return
	}
	a.proofIDs[proof.ID] = true
	issued, ok := a.codes[r.PostForm.Get("code")]
	delete(a.codes, r.PostForm.Get("code")) // one redemption, successful or not
	verifier := sha256.Sum256([]byte(r.PostForm.Get("code_verifier")))
	if !ok || r.PostForm.Get("grant_type") != "authorization_code" || r.PostForm.Get("client_id") != uifClientID ||
		r.PostForm.Get("redirect_uri") != issued.request.redirectURI || base64.RawURLEncoding.EncodeToString(verifier[:]) != issued.request.challenge {
		writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid_grant"})
		return
	}
	a.tokenExchanges++
	access := "identity-" + randomTestToken()
	a.identities[access] = &issuedIdentity{subject: issued.subject, thumbprint: proof.Thumbprint}
	expiresIn := int64(300)
	shape, _ := a.tokenShape.Load().(string)
	if shape != "cacheable" {
		w.Header().Set("Cache-Control", "no-store")
	}
	if shape == "long-lived" {
		expiresIn = 3600
	}
	writeJSON(w, http.StatusOK, humanTokenResponse{AccessToken: access, TokenType: "DPoP", ExpiresIn: expiresIn, RefreshToken: "refresh-" + randomTestToken()})
}

func (a *hostedAuthN) logout(w http.ResponseWriter, r *http.Request) {
	access := strings.TrimPrefix(r.Header.Get("Authorization"), "Bearer ")
	proof, err := emibsauth.VerifyDPoP(r.Header.Get("DPoP"), http.MethodPost, a.logoutURL(), access, "", time.Now().UTC())
	a.mu.Lock()
	defer a.mu.Unlock()
	identity := a.identities[access]
	if err != nil || identity == nil || identity.thumbprint != proof.Thumbprint {
		w.WriteHeader(http.StatusUnauthorized)
		return
	}
	identity.revoked = true
	a.logouts++
	w.WriteHeader(http.StatusNoContent)
}

func randomTestToken() string {
	token, err := randomToken(24)
	if err != nil {
		panic(err)
	}
	return token
}

// ---------------------------------------------------------------------------
// The stack: edge + uif process + AuthN + Google.
// ---------------------------------------------------------------------------

type productionStack struct {
	edge     *httptest.Server
	origin   string
	upstream atomic.Pointer[url.URL]
	authn    *hostedAuthN
	google   *googleProvider
	config   string
	process  *uifProcess
}

func newProductionStack(t *testing.T) *productionStack {
	t.Helper()
	stack := &productionStack{}
	stack.google = newGoogleProvider(t)
	stack.authn = newHostedAuthN(t, stack.google)
	// The edge terminates TLS and reverse-proxies to whatever uif process is
	// current, the way Caddy's `reverse_proxy 127.0.0.1:8283` does across a
	// container swap.
	stack.edge = httptest.NewTLSServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		target := stack.upstream.Load()
		if target == nil {
			http.Error(w, "no upstream", http.StatusBadGateway)
			return
		}
		httputil.NewSingleHostReverseProxy(target).ServeHTTP(w, r)
	}))
	t.Cleanup(stack.edge.Close)
	stack.origin = stack.edge.URL
	stack.authn.registeredRedirect = stack.origin + "/auth/callback"

	staticDir := staticRoot(t)
	stack.config = writeConfig(t, fmt.Sprintf(`{
  "staticDir": %q,
  "auth": {
    "publicBaseUrl": %q,
    "authorizeEndpoint": %q,
    "tokenEndpoint": %q,
    "tokenProofEndpoint": %q,
    "logoutEndpoint": %q,
    "clientId": %q,
    "sessionIdleTtlSeconds": 3600
  }
}`, staticDir, stack.origin, stack.authn.base+"/realms/org/authorize", stack.authn.tokenURL(), stack.authn.tokenURL(), stack.authn.logoutURL(), uifClientID))
	stack.startUIF(t)
	return stack
}

// startUIF starts (or replaces) the uif process, as a deploy does.
func (stack *productionStack) startUIF(t *testing.T) {
	t.Helper()
	if stack.process != nil {
		stack.process.stop()
	}
	address := freeLoopbackAddress(t)
	config := strings.Replace(readFile(t, stack.config), `"staticDir"`, fmt.Sprintf(`"listen": %q, "staticDir"`, address), 1)
	path := writeConfig(t, config)
	stack.process = startProcess(t, []string{"UI_LIB_CONFIG_FILE=" + path})
	waitHealthy(t, stack.process, address)
	stack.upstream.Store(&url.URL{Scheme: "http", Host: address})
}

func readFile(t *testing.T, path string) string {
	t.Helper()
	raw, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	return string(raw)
}

// browser is a cookie-holding client that trusts the edge's certificate and
// records every Set-Cookie the edge sends, so cookie attributes can be checked
// as the browser received them.
type browser struct {
	t          *testing.T
	stack      *productionStack
	jar        *cookiejar.Jar
	follow     *http.Client
	noFollow   *http.Client
	mu         sync.Mutex
	setCookies []*http.Cookie
}

type recordingTransport struct {
	base    http.RoundTripper
	browser *browser
}

func (rt recordingTransport) RoundTrip(r *http.Request) (*http.Response, error) {
	response, err := rt.base.RoundTrip(r)
	if err == nil && strings.HasPrefix(r.URL.String(), rt.browser.stack.origin) {
		rt.browser.mu.Lock()
		rt.browser.setCookies = append(rt.browser.setCookies, response.Cookies()...)
		rt.browser.mu.Unlock()
	}
	return response, err
}

func newBrowser(t *testing.T, stack *productionStack) *browser {
	jar, err := cookiejar.New(nil)
	if err != nil {
		t.Fatal(err)
	}
	b := &browser{t: t, stack: stack, jar: jar}
	transport := recordingTransport{base: stack.edge.Client().Transport, browser: b}
	b.follow = &http.Client{Jar: jar, Transport: transport, Timeout: 20 * time.Second}
	b.noFollow = &http.Client{Jar: jar, Transport: transport, Timeout: 20 * time.Second,
		CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	return b
}

type observed struct {
	status   int
	body     string
	finalURL string
	header   http.Header
}

func (b *browser) do(client *http.Client, method, target string, decorate func(*http.Request)) observed {
	b.t.Helper()
	request, err := http.NewRequest(method, b.stack.origin+target, nil)
	if err != nil {
		b.t.Fatal(err)
	}
	if decorate != nil {
		decorate(request)
	}
	response, err := client.Do(request)
	if err != nil {
		b.t.Fatalf("%s %s: %v", method, target, err)
	}
	defer response.Body.Close()
	body, _ := io.ReadAll(response.Body)
	return observed{status: response.StatusCode, body: string(body), finalURL: response.Request.URL.String(), header: response.Header}
}

// navigate is a top-level browser navigation that follows every redirect,
// across origins, as a browser does.
func (b *browser) navigate(target string) observed {
	return b.do(b.follow, http.MethodGet, target, func(r *http.Request) {
		r.Header.Set("Sec-Fetch-Mode", "navigate")
		r.Header.Set("Accept", "text/html,application/xhtml+xml")
	})
}

// fetch is a subresource or programmatic request; redirects are not followed.
func (b *browser) fetch(method, target string, decorate func(*http.Request)) observed {
	return b.do(b.noFollow, method, target, decorate)
}

func (b *browser) logout() observed {
	return b.fetch(http.MethodPost, "/auth/logout", func(r *http.Request) {
		r.Header.Set("Origin", b.stack.origin)
		r.Header.Set("Sec-Fetch-Site", "same-origin")
	})
}

func (b *browser) sessionCookie() *http.Cookie {
	edge, _ := url.Parse(b.stack.origin)
	for _, cookie := range b.jar.Cookies(edge) {
		if cookie.Name == sessionCookie {
			return cookie
		}
	}
	return nil
}

func (b *browser) lastSetCookie(name string) *http.Cookie {
	b.mu.Lock()
	defer b.mu.Unlock()
	for i := len(b.setCookies) - 1; i >= 0; i-- {
		if b.setCookies[i].Name == name {
			return b.setCookies[i]
		}
	}
	return nil
}

func (b *browser) signIn(target string) observed {
	b.t.Helper()
	page := b.navigate(target)
	if page.status != http.StatusOK || !strings.Contains(page.body, spaMarker) {
		b.t.Fatalf("Google sign-in via %s did not reach the catalogue: status=%d final=%s body=%q", target, page.status, page.finalURL, page.body)
	}
	return page
}

func assertShut(t *testing.T, got observed, what string) {
	t.Helper()
	if strings.Contains(got.body, spaMarker) || strings.Contains(got.body, assetMarker) {
		t.Fatalf("%s leaked catalogue content: status=%d", what, got.status)
	}
	if got.status != http.StatusUnauthorized {
		t.Fatalf("%s: status=%d, want 401", what, got.status)
	}
}

// ---------------------------------------------------------------------------
// The tests.
// ---------------------------------------------------------------------------

// The binary itself refuses to start ungated (issue-2602), observed as a process
// exit — not a function returning an error.
func TestProductionBinaryRefusesToStartWithoutItsGate(t *testing.T) {
	for name, env := range map[string][]string{
		"no UI_LIB_CONFIG_FILE":     {},
		"missing config file":       {"UI_LIB_CONFIG_FILE=" + filepath.Join(t.TempDir(), "absent.json")},
		"config without auth group": {"UI_LIB_CONFIG_FILE=" + writeConfig(t, `{"listen":"127.0.0.1:0"}`)},
		"partial auth group":        {"UI_LIB_CONFIG_FILE=" + writeConfig(t, `{"listen":"127.0.0.1:0","auth":{"clientId":"uif-browser"}}`)},
	} {
		t.Run(name, func(t *testing.T) {
			process := startProcess(t, env)
			if code := process.waitExit(t, 10*time.Second); code == 0 {
				t.Fatalf("uif BFF exited 0 without a gate; output:\n%s", process.output.String())
			}
			if strings.Contains(process.output.String(), "listener starting") {
				t.Fatalf("uif BFF began listening without a gate; output:\n%s", process.output.String())
			}
		})
	}
}

// The container HEALTHCHECK runs `/app/uif-bff healthcheck`; it must pass
// against a gated process (so the gate does not fail its own healthcheck) and
// fail when nothing is listening.
func TestProductionHealthcheckSubcommand(t *testing.T) {
	stack := newProductionStack(t)
	live := stack.upstream.Load().Host
	ok := startProcess(t, []string{"UI_LIB_HEALTH_URL=http://" + live + "/health"}, "healthcheck")
	if code := ok.waitExit(t, 10*time.Second); code != 0 {
		t.Fatalf("healthcheck against a live gated process exited %d", code)
	}
	down := startProcess(t, []string{"UI_LIB_HEALTH_URL=http://" + freeLoopbackAddress(t) + "/health"}, "healthcheck")
	if code := down.waitExit(t, 10*time.Second); code == 0 {
		t.Fatal("healthcheck passed with nothing listening")
	}
}

// Anonymous denial, through the edge, for the shell, deep links, assets, the
// login surface on the wrong method, and every credential shortcut a
// "temporary" bypass would take. /health and /robots.txt stay open.
func TestProductionAnonymousCallerGetsNoCatalogue(t *testing.T) {
	stack := newProductionStack(t)
	anonymous := newBrowser(t, stack)

	for _, path := range []string{"/", "/index.html", "/components/button", "/components/forms/date-picker?state=open", "/assets/index-abc123.js", "/auth/logout", "/auth/unknown"} {
		assertShut(t, anonymous.fetch(http.MethodGet, path, nil), "anonymous GET "+path)
	}
	for _, method := range []string{http.MethodPost, http.MethodPut, http.MethodDelete} {
		for _, path := range []string{"/", "/auth/login", "/auth/callback"} {
			got := anonymous.fetch(method, path, func(r *http.Request) {
				r.Header.Set("Origin", stack.origin)
				r.Header.Set("Sec-Fetch-Site", "same-origin")
			})
			if got.status < 400 || strings.Contains(got.body, spaMarker) {
				t.Fatalf("anonymous %s %s: status=%d, served content", method, path, got.status)
			}
		}
	}
	for name, apply := range map[string]func(*http.Request){
		"bearer token":        func(r *http.Request) { r.Header.Set("Authorization", "Bearer identity-anything") },
		"DPoP token":          func(r *http.Request) { r.Header.Set("Authorization", "DPoP identity-anything") },
		"basic auth":          func(r *http.Request) { r.SetBasicAuth("admin", "admin") },
		"forwarded user":      func(r *http.Request) { r.Header.Set("X-Forwarded-User", "owner") },
		"forwarded email":     func(r *http.Request) { r.Header.Set("X-Auth-Request-Email", "owner@example.com") },
		"dev token header":    func(r *http.Request) { r.Header.Set("X-Dev-Token", "dev") },
		"query token":         func(r *http.Request) { r.URL.RawQuery = "token=dev&access_token=x&debug=1" },
		"unknown session":     func(r *http.Request) { r.AddCookie(&http.Cookie{Name: sessionCookie, Value: "forged"}) },
		"empty session":       func(r *http.Request) { r.AddCookie(&http.Cookie{Name: sessionCookie, Value: ""}) },
		"non-__Host- cookie":  func(r *http.Request) { r.AddCookie(&http.Cookie{Name: "uif-session", Value: "forged"}) },
		"flow cookie instead": func(r *http.Request) { r.AddCookie(&http.Cookie{Name: loginFlowCookie, Value: "forged"}) },
	} {
		assertShut(t, anonymous.fetch(http.MethodGet, "/", apply), "shortcut "+name)
	}

	navigation := anonymous.fetch(http.MethodGet, "/components/button?variant=ghost", func(r *http.Request) { r.Header.Set("Sec-Fetch-Mode", "navigate") })
	if navigation.status != http.StatusFound || !strings.HasPrefix(navigation.header.Get("Location"), "/auth/login?return=") || strings.Contains(navigation.body, spaMarker) {
		t.Fatalf("anonymous navigation: status=%d location=%q", navigation.status, navigation.header.Get("Location"))
	}

	health := anonymous.fetch(http.MethodGet, "/health", nil)
	robots := anonymous.fetch(http.MethodGet, "/robots.txt", nil)
	if health.status != http.StatusOK || health.body != "ok\n" || robots.status != http.StatusOK || robots.body != "User-agent: *\nDisallow: /\n" {
		t.Fatalf("operational surface drifted: health=%d %q robots=%d %q", health.status, health.body, robots.status, robots.body)
	}
	if got := robots.header.Get("X-Robots-Tag"); got != "noindex, nofollow, noarchive" {
		t.Fatalf("robots.txt lost its noindex header: %q", got)
	}
	if stack.authn.tokenExchanges != 0 || stack.google.authorizations != 0 {
		t.Fatal("anonymous probing reached the identity providers")
	}
}

// The Google callback/session case: a deep link, followed by a browser, goes
// uif -> AuthN -> Google -> AuthN -> uif /auth/callback -> the deep link, and
// ends with a session that opens the catalogue and its assets.
func TestProductionGoogleSignInEstablishesASessionAtTheDeepLink(t *testing.T) {
	stack := newProductionStack(t)
	person := newBrowser(t, stack)

	page := person.signIn("/components/forms/date-picker?state=open")
	if page.finalURL != stack.origin+"/components/forms/date-picker?state=open" {
		t.Fatalf("sign-in did not return to the deep link: %s", page.finalURL)
	}
	if stack.google.authorizations != 1 || stack.authn.tokenExchanges != 1 {
		t.Fatalf("expected one Google authorization and one AuthN exchange, got %d and %d", stack.google.authorizations, stack.authn.tokenExchanges)
	}

	session := person.lastSetCookie(sessionCookie)
	if session == nil || session.Value == "" {
		t.Fatal("no session cookie was set")
	}
	// __Host- requires Secure, Path=/ and no Domain; SameSite=Lax is what lets
	// the flow cookie ride AuthN's cross-site redirect back; HttpOnly keeps the
	// session identifier out of script.
	if !session.Secure || !session.HttpOnly || session.SameSite != http.SameSiteLaxMode || session.Path != "/" || session.Domain != "" {
		t.Fatalf("session cookie attributes are unsafe: %#v", session)
	}
	flow := person.lastSetCookie(loginFlowCookie)
	if flow == nil || flow.MaxAge >= 0 || !flow.Secure || !flow.HttpOnly || flow.SameSite != http.SameSiteLaxMode {
		t.Fatalf("the one-time login flow cookie was not cleared by the callback: %#v", flow)
	}
	for _, value := range []string{session.Value} {
		if strings.Contains(value, "identity-") || strings.Contains(value, "refresh-") {
			t.Fatal("the session cookie carries AuthN token material instead of an opaque identifier")
		}
	}

	if asset := person.fetch(http.MethodGet, "/assets/index-abc123.js", nil); asset.status != http.StatusOK || !strings.Contains(asset.body, assetMarker) {
		t.Fatalf("the signed-in browser could not load the bundle: status=%d", asset.status)
	}
	if shell := person.fetch(http.MethodGet, "/", nil); shell.status != http.StatusOK || shell.header.Get("Cache-Control") != "no-store" {
		t.Fatalf("signed-in shell: status=%d cache-control=%q", shell.status, shell.header.Get("Cache-Control"))
	}

	// A second, independent browser is still shut out: the session is the
	// browser's, not the process's.
	assertShut(t, newBrowser(t, stack).fetch(http.MethodGet, "/", nil), "a different browser after someone signed in")
}

// A person who cancels at Google comes back to uif with the OIDC error. No
// session is created and the catalogue stays shut.
func TestProductionGoogleConsentDeniedIssuesNoSession(t *testing.T) {
	stack := newProductionStack(t)
	stack.google.denyConsent = true
	person := newBrowser(t, stack)

	page := person.navigate("/")
	if page.status != http.StatusBadRequest || strings.Contains(page.body, spaMarker) || !strings.Contains(page.finalURL, "/auth/callback") {
		t.Fatalf("a denied Google sign-in: status=%d final=%s", page.status, page.finalURL)
	}
	if person.sessionCookie() != nil || stack.authn.tokenExchanges != 0 {
		t.Fatal("a denied Google sign-in produced a session or a token exchange")
	}
	assertShut(t, person.fetch(http.MethodGet, "/", nil), "after a denied Google sign-in")
}

// The browser that returns to /auth/callback must be the one that started the
// flow: a callback URL replayed from another browser, or replayed at all, is
// refused.
func TestProductionCallbackIsBoundToTheBrowserThatStartedIt(t *testing.T) {
	stack := newProductionStack(t)
	victim := newBrowser(t, stack)

	// Stop the victim's flow at the moment AuthN hands back the code.
	var callback string
	victim.follow.CheckRedirect = func(r *http.Request, _ []*http.Request) error {
		if r.URL.Path == "/auth/callback" && strings.HasPrefix(r.URL.String(), stack.origin) {
			callback = r.URL.RequestURI()
			return http.ErrUseLastResponse
		}
		return nil
	}
	victim.navigate("/")
	if callback == "" {
		t.Fatal("the flow never reached the uif callback")
	}

	attacker := newBrowser(t, stack)
	if got := attacker.fetch(http.MethodGet, callback, nil); got.status != http.StatusBadRequest || attacker.sessionCookie() != nil {
		t.Fatalf("a callback replayed from another browser: status=%d", got.status)
	}
	// The attacker's attempt consumed nothing it should not have; the victim's
	// own browser still completes — and only once.
	if got := victim.fetch(http.MethodGet, callback, nil); got.status != http.StatusSeeOther || victim.sessionCookie() == nil {
		t.Fatalf("the originating browser could not complete its own flow: status=%d", got.status)
	}
	if got := victim.fetch(http.MethodGet, callback, nil); got.status != http.StatusBadRequest {
		t.Fatalf("a completed callback was replayable: status=%d", got.status)
	}
}

// Logout ends the session in uif AND revokes it at AuthN with a proof from the
// key the identity was bound to. The old cookie value is dead afterwards, even
// replayed by hand.
func TestProductionLogoutEndsTheSessionEverywhere(t *testing.T) {
	stack := newProductionStack(t)
	person := newBrowser(t, stack)
	person.signIn("/")
	stolen := person.sessionCookie().Value

	out := person.logout()
	if out.status != http.StatusSeeOther || out.header.Get("Location") != "/" {
		t.Fatalf("logout: status=%d location=%q", out.status, out.header.Get("Location"))
	}
	if stack.authn.logouts != 1 {
		t.Fatalf("logout did not revoke the identity at AuthN (proof-bound): %d revocations", stack.authn.logouts)
	}
	if cleared := person.lastSetCookie(sessionCookie); cleared == nil || cleared.MaxAge >= 0 {
		t.Fatalf("logout did not clear the session cookie: %#v", cleared)
	}
	assertShut(t, person.fetch(http.MethodGet, "/", nil), "after logout")
	assertShut(t, newBrowser(t, stack).fetch(http.MethodGet, "/", func(r *http.Request) {
		r.AddCookie(&http.Cookie{Name: sessionCookie, Value: stolen})
	}), "a replayed pre-logout session cookie")

	// A cross-site logout POST is refused and ends nobody's session.
	other := newBrowser(t, stack)
	other.signIn("/")
	refused := other.fetch(http.MethodPost, "/auth/logout", func(r *http.Request) {
		r.Header.Set("Origin", "https://evil.example.com")
		r.Header.Set("Sec-Fetch-Site", "cross-site")
	})
	if refused.status != http.StatusForbidden {
		t.Fatalf("cross-site logout: status=%d, want 403", refused.status)
	}
	if got := other.fetch(http.MethodGet, "/", nil); got.status != http.StatusOK {
		t.Fatalf("a cross-site logout ended the session: status=%d", got.status)
	}
}

// Hosted AuthN down at the moment of sign-in: the browser ends on an error, no
// session exists, and the catalogue stays shut. When AuthN recovers, a fresh
// sign-in works without restarting uif.
func TestProductionHostedOutageDeniesThenRecovers(t *testing.T) {
	stack := newProductionStack(t)
	stack.authn.tokenOutage.Store(true)
	person := newBrowser(t, stack)

	page := person.navigate("/")
	if page.status != http.StatusBadGateway || strings.Contains(page.body, spaMarker) {
		t.Fatalf("sign-in during an AuthN outage: status=%d final=%s", page.status, page.finalURL)
	}
	if person.sessionCookie() != nil {
		t.Fatal("an AuthN outage still issued a session")
	}
	assertShut(t, person.fetch(http.MethodGet, "/", nil), "during an AuthN outage")

	stack.authn.tokenOutage.Store(false)
	person.signIn("/")
}

// A uif restart (every deploy is one) drops every session: they live only in the
// process. The old cookie is refused, never honoured by a new process, and the
// person simply signs in again.
func TestProductionRestartInvalidatesSessionsAndFailsClosed(t *testing.T) {
	stack := newProductionStack(t)
	person := newBrowser(t, stack)
	person.signIn("/")
	if got := person.fetch(http.MethodGet, "/", nil); got.status != http.StatusOK {
		t.Fatalf("precondition: signed-in browser refused: status=%d", got.status)
	}

	stack.startUIF(t)
	assertShut(t, person.fetch(http.MethodGet, "/", nil), "a pre-restart session after a restart")
	person.signIn("/")
}

// The session is bounded by the server: a sliding idle timeout and a fixed
// absolute lifetime. The cookie must not end it sooner. It used to be set with
// Max-Age = the idle TTL, once, at login — so a person active the whole time was
// still signed out one idle-TTL after signing in, because the browser dropped a
// cookie the server would have honoured. The cookie now lives as long as the
// absolute lifetime and the server decides everything shorter.
func TestProductionSessionCookieDoesNotEndAnActiveSessionEarly(t *testing.T) {
	stack := newProductionStack(t)
	person := newBrowser(t, stack)
	person.signIn("/")
	session := person.lastSetCookie(sessionCookie)
	if session == nil {
		t.Fatal("no session cookie was set")
	}
	if session.MaxAge != int(sessionAbsoluteLifetime/time.Second) {
		t.Fatalf("session cookie Max-Age=%d, want the absolute lifetime %d; a shorter cookie ends an active session before the server does", session.MaxAge, int(sessionAbsoluteLifetime/time.Second))
	}
}

// A 200 from AuthN is not enough: a token response that could be cached, or an
// identity token living longer than AuthN's 300s, is a contract violation, and
// uif must refuse it rather than build a session on it.
func TestProductionOffContractTokenResponseIssuesNoSession(t *testing.T) {
	for _, shape := range []string{"cacheable", "long-lived"} {
		t.Run(shape, func(t *testing.T) {
			stack := newProductionStack(t)
			stack.authn.tokenShape.Store(shape)
			person := newBrowser(t, stack)
			page := person.navigate("/")
			if page.status != http.StatusBadGateway || strings.Contains(page.body, spaMarker) || person.sessionCookie() != nil {
				t.Fatalf("an off-contract (%s) token response: status=%d session=%v", shape, page.status, person.sessionCookie() != nil)
			}
			assertShut(t, person.fetch(http.MethodGet, "/", nil), "after an off-contract token response")
		})
	}
}
