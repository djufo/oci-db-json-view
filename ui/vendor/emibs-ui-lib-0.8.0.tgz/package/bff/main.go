// Command uif-bff serves the emibs-ui-lib catalogue (uif) behind an
// authenticated server-side session.
//
// Why this exists (issue-2601).
//
// uif is an INTERNAL design catalogue that is reachable on the public internet
// as ui-lib.ayc.io with no credential at all — the repository AGENT.md records
// the surface as "External, public: the route carries no access gate". Until
// this program existed it could not gate itself: the container was plain nginx
// serving a static SPA, so there was nothing in-process to hold a session, and
// a client-side guard protects nothing because the assets are still handed to
// an unauthenticated caller before any script runs.
//
// This is that missing in-process gate. Its shape is taken from
// emibs-files-ui/bff, the working reference in this repository — the reason the
// Files surface is not exposed the way uif is. Session cookie flags, the PKCE
// login flow, the browser-proof binding, the bounded server-side stores, the
// disallow-all robots policy and the static fallback all follow that program
// rather than inventing new conventions. What is deliberately NOT carried over
// is the AuthZ capability exchange: uif has no backend API and makes no
// downstream calls, so authentication is the whole gate.
//
// One mode: gated. There is no ungated mode (issue-2602).
//
// This program first shipped inert (issue-2601): with no configuration it served
// the catalogue openly, exactly as nginx had, so that merging it could not switch
// a gate on unattended. The gate has been on since 2026-09-04 and
// deployment/access-posture/inventory.json declares the host session-gated with
// no exception, so that open mode stopped being a migration step and became the
// one way this process could still hand an internal catalogue to the public
// internet: drop UI_LIB_CONFIG_FILE from the compose file, or the auth group from
// the config, and every deploy after that would have served it to anyone, with a
// green /health probe. The entrypoint is now fail-closed instead:
//
//   - no UI_LIB_CONFIG_FILE, an unusable file, or a file without a complete
//     auth group -> the process refuses to start. It never serves content.
//   - a complete auth group -> the gate is live. No session, no content: not the
//     SPA shell, not an arbitrary route, not an asset, on any method.
//
// An unclassified request is DENIED rather than defaulted open. The unauthenticated
// surface is a pinned list of METHOD and path pairs, not paths: a path-only list
// let GET /auth/logout (a POST-only route) fall through to the SPA fallback and
// serve the catalogue shell anonymously.
package main

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/json"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	emibsauth "github.com/djufo/emibs/packages/emibs-auth-go"
)

const (
	sessionCookie   = "__Host-uif-session"
	loginFlowCookie = "__Host-uif-login-flow"

	defaultListen    = "0.0.0.0:8080"
	defaultStaticDir = "/app/static"

	// Bounded stores. Both maps are pruned on every write, but pruning alone
	// bounds nothing against a caller that opens flows faster than they expire,
	// so there is also a hard ceiling: past it a new login is refused with 503
	// rather than allowed to grow the process until it is killed. Existing
	// sessions are unaffected — refusing new logins degrades a catalogue, while
	// evicting live sessions to admit a flood would hand the flooder the
	// eviction.
	maxLoginFlows = 1024
	maxSessions   = 4096

	loginFlowTTL = 10 * time.Minute

	// The absolute lifetime of a browser session, independent of idle timeout.
	//
	// This is a deliberate deviation from emibs-files-ui/bff, which keeps a
	// 30-day refresh window. Files re-presents its refresh token to AuthN on
	// every capability exchange, so a revoked account stops working there within
	// one access-token lifetime. uif makes NO downstream calls, so after login
	// it never speaks to AuthN again and has no such forcing function: the
	// absolute lifetime IS the re-authentication interval. Twelve hours keeps a
	// revoked account out within a working day while not logging a person out
	// mid-session.
	sessionAbsoluteLifetime = 12 * time.Hour
)

// authConfig is the authentication configuration GROUP. Every field is
// required: a group that is present but incomplete is a startup failure, never
// a partially-enforced gate. Absent (JSON `auth` omitted or null) is a startup
// failure too — there is no ungated mode; `"auth": {}` is partial, and fails.
type authConfig struct {
	PublicBaseURL         string `json:"publicBaseUrl"`
	AuthorizeEndpoint     string `json:"authorizeEndpoint"`
	TokenEndpoint         string `json:"tokenEndpoint"`
	TokenProofEndpoint    string `json:"tokenProofEndpoint"`
	LogoutEndpoint        string `json:"logoutEndpoint"`
	ClientID              string `json:"clientId"`
	SessionIdleTTLSeconds int    `json:"sessionIdleTtlSeconds"`
}

type config struct {
	Listen    string      `json:"listen"`
	StaticDir string      `json:"staticDir"`
	Auth      *authConfig `json:"auth"`
}

type loginFlow struct {
	Verifier     string
	Nonce        string
	ReturnTo     string
	BrowserProof [sha256.Size]byte
	ExpiresAt    time.Time
}

type browserSession struct {
	mu           sync.Mutex
	Identity     string
	Refresh      string
	IdentityEnds time.Time
	ProofKey     ed25519.PrivateKey
	EndsAt       time.Time
	LastSeen     time.Time
}

type server struct {
	config   config
	client   *http.Client
	mu       sync.Mutex
	flows    map[string]loginFlow
	sessions map[string]*browserSession
}

type humanTokenResponse struct {
	AccessToken  string `json:"access_token"`
	TokenType    string `json:"token_type"`
	ExpiresIn    int64  `json:"expires_in"`
	RefreshToken string `json:"refresh_token"`
}

func main() {
	if len(os.Args) == 2 && os.Args[1] == "healthcheck" {
		healthcheck()
		return
	}
	application, err := serverFromEnvironment(os.Getenv)
	if err != nil {
		slog.Error("uif BFF configuration rejected", "error", err)
		os.Exit(1)
	}
	httpServer := application.httpServer()
	slog.Info("uif BFF listener starting", "address", httpServer.Addr)
	if err := httpServer.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
		slog.Error("uif BFF stopped", "error", err)
		os.Exit(1)
	}
}

// serverFromEnvironment is the whole composition main performs before it
// listens. Tests enter here and through httpServer, so what they exercise is the
// handler the binary mounts, not a sibling of it.
func serverFromEnvironment(getenv func(string) string) (*server, error) {
	configured, err := loadConfig(getenv("UI_LIB_CONFIG_FILE"))
	if err != nil {
		return nil, err
	}
	return newServer(configured), nil
}

func (s *server) httpServer() *http.Server {
	return &http.Server{
		Addr:              s.config.Listen,
		Handler:           s.routes(),
		ReadHeaderTimeout: 5 * time.Second,
		ReadTimeout:       time.Minute,
		WriteTimeout:      time.Minute,
		IdleTimeout:       30 * time.Second,
		MaxHeaderBytes:    32 * 1024,
	}
}

func newServer(configured config) *server {
	return &server{
		config:   configured,
		client:   &http.Client{Timeout: 30 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }},
		flows:    map[string]loginFlow{},
		sessions: map[string]*browserSession{},
	}
}

func (s *server) routes() http.Handler {
	mux := http.NewServeMux()
	// Registered with no method so they answer every verb, exactly as nginx's
	// `location = /health` and `location = /robots.txt` did.
	mux.HandleFunc("/health", writeHealth)
	mux.HandleFunc("/robots.txt", writeDisallowAllRobots)
	mux.HandleFunc("GET /auth/login", s.login)
	mux.HandleFunc("GET /auth/callback", s.callback)
	mux.HandleFunc("POST /auth/logout", s.logout)
	// Everything else under /auth/ — a known login route on the wrong method, or
	// a path that does not exist — is answered here and never reaches the
	// catalogue. Without this the SPA fallback below was the most specific match
	// for GET /auth/logout.
	mux.HandleFunc("/auth/", writeLoginSurfaceMiss)
	mux.Handle("/", s.staticFallback())
	return s.securityHeaders(s.requireBrowserOrigin(s.requireSession(mux)))
}

// unauthenticatedRoute is the complete set of requests a caller makes without a
// session, as METHOD and path pairs. Everything else is gated, including paths
// that do not exist and known paths on a method they do not serve: an
// unclassified request is refused rather than defaulted open, so adding a route
// later cannot silently open it.
//
// /health is here because it is the container healthcheck and the deploy
// agent's verify probe; /robots.txt is here because a robots policy behind a
// login is a robots policy no crawler can read, which would leave the catalogue
// indexable by exactly the crawlers the policy exists to refuse. Both answer
// every method with the same fixed body and carry no catalogue content.
func unauthenticatedRoute(method, path string) bool {
	switch path {
	case "/health", "/robots.txt":
		return true
	case "/auth/login", "/auth/callback":
		return method == http.MethodGet
	case "/auth/logout":
		return method == http.MethodPost
	}
	return false
}

// requireSession is the gate.
func (s *server) requireSession(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if unauthenticatedRoute(r.Method, r.URL.Path) {
			next.ServeHTTP(w, r)
			return
		}
		if _, err := s.browserSession(r); err == nil {
			next.ServeHTTP(w, r)
			return
		}
		// Nothing is served: not the SPA shell, not an asset. A browser
		// navigation to the catalogue is sent to the login flow so the
		// catalogue stays usable; every other caller — asset loads, fetch(),
		// curl, and any navigation into the login surface itself, which would
		// only come back to a login route — is refused outright. Both paths
		// transfer zero catalogue content.
		if isDocumentNavigation(r) && !loginSurface(r.URL.Path) {
			http.Redirect(w, r, "/auth/login?return="+url.QueryEscape(returnTarget(r)), http.StatusFound)
			return
		}
		writeError(w, http.StatusUnauthorized, "authentication_required")
	})
}

func loginSurface(path string) bool { return path == "/auth" || strings.HasPrefix(path, "/auth/") }

// writeLoginSurfaceMiss answers any request under /auth/ that no login route
// took. A known route on the wrong method is 405 with its Allow header; anything
// else is 404. Neither ever carries catalogue content.
func writeLoginSurfaceMiss(w http.ResponseWriter, r *http.Request) {
	allow := map[string]string{"/auth/login": "GET", "/auth/callback": "GET", "/auth/logout": "POST"}[r.URL.Path]
	if allow == "" {
		writeError(w, http.StatusNotFound, "not_found")
		return
	}
	w.Header().Set("Allow", allow)
	writeError(w, http.StatusMethodNotAllowed, "method_not_allowed")
}

// isDocumentNavigation distinguishes a top-level browser navigation from an
// asset or programmatic fetch. Sec-Fetch-Mode is authoritative when present
// (every browser that can reach a __Host- cookie sends it); Accept is the
// fallback for anything else.
func isDocumentNavigation(r *http.Request) bool {
	if r.Method != http.MethodGet && r.Method != http.MethodHead {
		return false
	}
	if mode := strings.TrimSpace(r.Header.Get("Sec-Fetch-Mode")); mode != "" {
		return strings.EqualFold(mode, "navigate")
	}
	return strings.Contains(strings.ToLower(r.Header.Get("Accept")), "text/html")
}

// returnTarget is the same-origin path the login flow should come back to. Only
// a path is ever reflected — never a caller-supplied absolute URL — so the
// login redirect cannot be turned into an open redirect.
func returnTarget(r *http.Request) string {
	target := r.URL.EscapedPath()
	if !strings.HasPrefix(target, "/") || strings.HasPrefix(target, "//") {
		return "/"
	}
	if r.URL.RawQuery != "" {
		target += "?" + r.URL.RawQuery
	}
	return target
}

// requireBrowserOrigin is the CSRF boundary for the one state-changing route
// (POST /auth/logout).
func (s *server) requireBrowserOrigin(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead && r.Method != http.MethodOptions {
			origin := strings.TrimSuffix(r.Header.Get("Origin"), "/")
			fetchSite := strings.ToLower(strings.TrimSpace(r.Header.Get("Sec-Fetch-Site")))
			if origin == "" || origin != s.config.Auth.PublicBaseURL || (fetchSite != "" && fetchSite != "same-origin") {
				writeError(w, http.StatusForbidden, "origin_denied")
				return
			}
		}
		next.ServeHTTP(w, r)
	})
}

// securityHeaders sets the noindex tag nginx always set, plus the hardening a
// session-holding surface needs.
//
// No Content-Security-Policy is asserted. The catalogue renders arbitrary
// component demos and its inline-style surface has not been audited, so a
// guessed policy would ship a gate that works and a catalogue that does not.
// That audit is its own piece of work.
func (s *server) securityHeaders(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// uif is an internal system reachable on the public internet, so the
		// login page and the service itself are crawlable even with the gate
		// live. Authentication stops a crawler READING the catalogue; it does
		// not stop a search engine listing the service, and an indexed entry
		// outlives any later change to who may reach it. Archived copies
		// outlive it entirely.
		w.Header().Set("X-Robots-Tag", "noindex, nofollow, noarchive")
		w.Header().Set("Referrer-Policy", "no-referrer")
		w.Header().Set("X-Content-Type-Options", "nosniff")
		w.Header().Set("X-Frame-Options", "DENY")
		w.Header().Set("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
		if !strings.HasPrefix(r.URL.Path, "/assets/") {
			w.Header().Set("Cache-Control", "no-store")
		}
		next.ServeHTTP(w, r)
	})
}

func (s *server) login(w http.ResponseWriter, r *http.Request) {
	state, stateErr := randomToken(32)
	verifier, verifierErr := randomToken(48)
	nonce, nonceErr := randomToken(32)
	browserProof, proofErr := randomToken(32)
	if stateErr != nil || verifierErr != nil || nonceErr != nil || proofErr != nil {
		writeError(w, http.StatusServiceUnavailable, "login_unavailable")
		return
	}
	returnTo := r.URL.Query().Get("return")
	if !safeReturnTarget(returnTo) {
		returnTo = "/"
	}
	now := time.Now().UTC()
	s.mu.Lock()
	s.pruneLocked(now)
	if len(s.flows) >= maxLoginFlows {
		s.mu.Unlock()
		writeError(w, http.StatusServiceUnavailable, "login_unavailable")
		return
	}
	s.flows[state] = loginFlow{Verifier: verifier, Nonce: nonce, ReturnTo: returnTo, BrowserProof: sha256.Sum256([]byte(browserProof)), ExpiresAt: now.Add(loginFlowTTL)}
	s.mu.Unlock()
	http.SetCookie(w, &http.Cookie{Name: loginFlowCookie, Value: browserProof, Path: "/", Secure: true, HttpOnly: true, SameSite: http.SameSiteLaxMode, MaxAge: int(loginFlowTTL / time.Second)})
	digest := sha256.Sum256([]byte(verifier))
	query := url.Values{
		"response_type":         {"code"},
		"client_id":             {s.config.Auth.ClientID},
		"redirect_uri":          {s.config.Auth.PublicBaseURL + "/auth/callback"},
		"scope":                 {"openid"},
		"state":                 {state},
		"nonce":                 {nonce},
		"code_challenge_method": {"S256"},
		"code_challenge":        {base64.RawURLEncoding.EncodeToString(digest[:])},
	}
	http.Redirect(w, r, s.config.Auth.AuthorizeEndpoint+"?"+query.Encode(), http.StatusFound)
}

func (s *server) callback(w http.ResponseWriter, r *http.Request) {
	state, code := r.URL.Query().Get("state"), r.URL.Query().Get("code")
	flowCookie, cookieErr := r.Cookie(loginFlowCookie)
	http.SetCookie(w, &http.Cookie{Name: loginFlowCookie, Value: "", Path: "/", Secure: true, HttpOnly: true, SameSite: http.SameSiteLaxMode, MaxAge: -1})
	now := time.Now().UTC()
	s.mu.Lock()
	flow, ok := s.flows[state]
	proof := sha256.Sum256([]byte(flowCookieValue(flowCookie)))
	// The state parameter alone proves nothing about WHICH browser started the
	// flow. The one-time proof cookie binds the callback to that browser, so a
	// leaked authorization code cannot be redeemed from anywhere else.
	bound := cookieErr == nil && subtle.ConstantTimeCompare(proof[:], flow.BrowserProof[:]) == 1
	if ok && bound {
		delete(s.flows, state)
	}
	s.mu.Unlock()
	if !ok || !bound || !flow.ExpiresAt.After(now) || code == "" {
		writeError(w, http.StatusBadRequest, "login_invalid")
		return
	}
	_, proofKey, err := ed25519.GenerateKey(rand.Reader)
	if err != nil {
		writeError(w, http.StatusServiceUnavailable, "login_unavailable")
		return
	}
	tokens, err := s.exchangeCode(r.Context(), code, flow.Verifier, proofKey)
	if err != nil {
		writeError(w, http.StatusBadGateway, "login_unavailable")
		return
	}
	id, err := randomToken(32)
	if err != nil {
		writeError(w, http.StatusServiceUnavailable, "login_unavailable")
		return
	}
	s.mu.Lock()
	s.pruneLocked(now)
	if len(s.sessions) >= maxSessions {
		s.mu.Unlock()
		writeError(w, http.StatusServiceUnavailable, "login_unavailable")
		return
	}
	s.sessions[id] = &browserSession{
		Identity:     tokens.AccessToken,
		Refresh:      tokens.RefreshToken,
		IdentityEnds: now.Add(time.Duration(tokens.ExpiresIn) * time.Second),
		ProofKey:     proofKey,
		EndsAt:       now.Add(sessionAbsoluteLifetime),
		LastSeen:     now,
	}
	s.mu.Unlock()
	// The cookie lives as long as the absolute lifetime; the server enforces the
	// sliding idle timeout and the absolute cap. A cookie Max-Age of the idle
	// TTL, set once here, would end an ACTIVE session one idle-TTL after login.
	http.SetCookie(w, &http.Cookie{Name: sessionCookie, Value: id, Path: "/", Secure: true, HttpOnly: true, SameSite: http.SameSiteLaxMode, MaxAge: int(sessionAbsoluteLifetime / time.Second)})
	http.Redirect(w, r, flow.ReturnTo, http.StatusSeeOther)
}

// safeReturnTarget accepts only a same-origin path (with optional query) as the
// place to send the browser after login. The value is caller-supplied, so this
// is the one place the program could become an open redirect. A browser treats
// a backslash as a slash in an http(s) URL and silently strips tab, CR and LF,
// so "/\evil" and "/<TAB>/evil" both resolve to the protocol-relative "//evil":
// checking the first two bytes for "//" is not enough. Anything that is not
// plain printable ASCII without a backslash is refused, then the remainder must
// parse as a path with no scheme and no host.
func safeReturnTarget(target string) bool {
	if !strings.HasPrefix(target, "/") || strings.HasPrefix(target, "//") {
		return false
	}
	for i := 0; i < len(target); i++ {
		if c := target[i]; c <= ' ' || c >= 0x7f || c == '\\' {
			return false
		}
	}
	parsed, err := url.Parse(target)
	return err == nil && parsed.Scheme == "" && parsed.Host == "" && parsed.User == nil && strings.HasPrefix(parsed.Path, "/") && !strings.HasPrefix(parsed.Path, "//")
}

func flowCookieValue(cookie *http.Cookie) string {
	if cookie == nil {
		return ""
	}
	return cookie.Value
}

func (s *server) exchangeCode(ctx context.Context, code, verifier string, proofKey ed25519.PrivateKey) (humanTokenResponse, error) {
	values := url.Values{
		"grant_type":    {"authorization_code"},
		"client_id":     {s.config.Auth.ClientID},
		"code":          {code},
		"redirect_uri":  {s.config.Auth.PublicBaseURL + "/auth/callback"},
		"code_verifier": {verifier},
	}
	proofID, err := randomToken(18)
	if err != nil {
		return humanTokenResponse{}, err
	}
	proof, err := emibsauth.SignDPoP(http.MethodPost, s.config.Auth.TokenProofEndpoint, "", proofKey, time.Now().UTC(), proofID)
	if err != nil {
		return humanTokenResponse{}, errors.New("create AuthN proof")
	}
	request, err := http.NewRequestWithContext(ctx, http.MethodPost, s.config.Auth.TokenEndpoint, strings.NewReader(values.Encode()))
	if err != nil {
		return humanTokenResponse{}, errors.New("create AuthN request")
	}
	request.Header.Set("Content-Type", "application/x-www-form-urlencoded")
	request.Header.Set("DPoP", proof)
	response, err := s.client.Do(request)
	if err != nil {
		return humanTokenResponse{}, errors.New("AuthN transport failed")
	}
	defer response.Body.Close()
	if response.StatusCode != http.StatusOK || !strings.Contains(strings.ToLower(response.Header.Get("Cache-Control")), "no-store") {
		return humanTokenResponse{}, errors.New("AuthN exchange failed")
	}
	var tokens humanTokenResponse
	decoder := json.NewDecoder(io.LimitReader(response.Body, 64*1024))
	decoder.DisallowUnknownFields()
	if decoder.Decode(&tokens) != nil || tokens.TokenType != "DPoP" || tokens.AccessToken == "" || tokens.RefreshToken == "" || tokens.ExpiresIn <= 0 || tokens.ExpiresIn > 300 {
		return humanTokenResponse{}, errors.New("AuthN exchange invalid")
	}
	return tokens, nil
}

func (s *server) logout(w http.ResponseWriter, r *http.Request) {
	if cookie, err := r.Cookie(sessionCookie); err == nil {
		s.mu.Lock()
		session := s.sessions[cookie.Value]
		delete(s.sessions, cookie.Value)
		s.mu.Unlock()
		if session != nil {
			session.mu.Lock()
			if session.Identity != "" && session.IdentityEnds.After(time.Now().UTC()) && s.config.Auth.LogoutEndpoint != "" {
				proofID, _ := randomToken(18)
				request, requestErr := emibsauth.NewAuthenticatedRequest(r.Context(), http.MethodPost, s.config.Auth.LogoutEndpoint, nil, session.Identity, session.ProofKey, time.Now().UTC(), proofID)
				if requestErr == nil {
					if response, _ := s.client.Do(request); response != nil {
						response.Body.Close()
					}
				}
			}
			session.Identity, session.Refresh = "", ""
			session.mu.Unlock()
		}
	}
	http.SetCookie(w, &http.Cookie{Name: sessionCookie, Value: "", Path: "/", Secure: true, HttpOnly: true, SameSite: http.SameSiteLaxMode, MaxAge: -1})
	http.Redirect(w, r, "/", http.StatusSeeOther)
}

// browserSession resolves the caller's session, or reports that there is none.
// An unknown cookie value, an idle-expired session and one past its absolute
// lifetime are indistinguishable to the caller: all three are simply "no
// session".
func (s *server) browserSession(r *http.Request) (*browserSession, error) {
	cookie, err := r.Cookie(sessionCookie)
	if err != nil {
		return nil, errors.New("session cookie absent")
	}
	now := time.Now().UTC()
	s.mu.Lock()
	session := s.sessions[cookie.Value]
	if session == nil || !sessionLiveLocked(session, now, s.config.Auth.SessionIdleTTLSeconds) {
		delete(s.sessions, cookie.Value)
		session = nil
	} else {
		session.LastSeen = now
	}
	s.mu.Unlock()
	if session == nil {
		return nil, errors.New("session unavailable")
	}
	return session, nil
}

// sessionLiveLocked must be called with server.mu held: LastSeen and EndsAt are
// read and written under that lock, not the per-session lock (which guards only
// the token material during a logout).
func sessionLiveLocked(session *browserSession, now time.Time, idleTTLSeconds int) bool {
	return session.EndsAt.After(now) && now.Sub(session.LastSeen) <= time.Duration(idleTTLSeconds)*time.Second
}

func (s *server) pruneLocked(now time.Time) {
	for key, flow := range s.flows {
		if !flow.ExpiresAt.After(now) {
			delete(s.flows, key)
		}
	}
	for key, session := range s.sessions {
		if !sessionLiveLocked(session, now, s.config.Auth.SessionIdleTTLSeconds) {
			delete(s.sessions, key)
		}
	}
}

// staticFallback serves the built catalogue: a real file when the path names
// one, and index.html otherwise so client-side routes resolve. This is the SPA
// behaviour nginx's `try_files $uri $uri/ /index.html` provided, reproduced
// exactly — and nothing reaches it without a session. It serves reads only:
// any other method is 405, as nginx answered a POST to a static file.
func (s *server) staticFallback() http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet && r.Method != http.MethodHead {
			w.Header().Set("Allow", "GET, HEAD")
			writeError(w, http.StatusMethodNotAllowed, "method_not_allowed")
			return
		}
		filePath, confined := confinedStaticPath(s.config.StaticDir, r.URL.Path)
		if !confined {
			http.NotFound(w, r)
			return
		}
		if info, err := os.Stat(filePath); err == nil && !info.IsDir() {
			http.ServeFile(w, r, filePath)
			return
		}
		http.ServeFile(w, r, filepath.Join(s.config.StaticDir, "index.html"))
	})
}

// confinedStaticPath refuses any request path that would resolve outside the
// static root once cleaned.
func confinedStaticPath(root, requestPath string) (string, bool) {
	clean := filepath.Clean(strings.TrimPrefix(requestPath, "/"))
	if filepath.IsAbs(clean) || clean == ".." || strings.HasPrefix(clean, ".."+string(filepath.Separator)) {
		return "", false
	}
	return filepath.Join(root, clean), true
}

// writeHealth answers the container healthcheck and the deploy agent's verify
// probe. It is unauthenticated by design: a healthcheck that
// needs a credential is a healthcheck that fails. It reveals nothing beyond
// "this process is listening" — byte-identical to what the nginx container
// returned.
func writeHealth(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte("ok\n"))
}

// writeDisallowAllRobots refuses every crawler. uif is internal: there is no
// page here a search engine should hold, including the login page, which is the
// only thing an unauthenticated crawler can reach once the gate is live.
func writeDisallowAllRobots(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "text/plain; charset=utf-8")
	w.Header().Set("X-Robots-Tag", "noindex, nofollow, noarchive")
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte("User-agent: *\nDisallow: /\n"))
}

// loadConfig reads the configuration, and refuses anything that is not a
// complete authentication group. There is no default and no fallback: with no
// path, an unusable file, or no auth group, the only thing this process could
// do is serve the internal catalogue ungated, so it does not start.
func loadConfig(path string) (config, error) {
	if strings.TrimSpace(path) == "" {
		return config{}, errors.New("UI_LIB_CONFIG_FILE is required: uif serves only behind its authentication gate and has no ungated mode")
	}
	info, err := os.Lstat(path)
	if err != nil || !info.Mode().IsRegular() || info.Size() <= 0 || info.Size() > 256*1024 {
		return config{}, errors.New("UI_LIB_CONFIG_FILE must be a bounded regular file")
	}
	raw, err := os.ReadFile(path)
	if err != nil {
		return config{}, errors.New("read uif BFF config")
	}
	var value config
	decoder := json.NewDecoder(strings.NewReader(string(raw)))
	decoder.DisallowUnknownFields()
	if decoder.Decode(&value) != nil {
		return config{}, errors.New("decode uif BFF config")
	}
	if value.Listen == "" {
		value.Listen = defaultListen
	}
	if value.StaticDir == "" {
		value.StaticDir = defaultStaticDir
	}
	if value.Auth == nil {
		return config{}, errors.New("uif BFF config has no auth group: uif serves only behind its authentication gate and has no ungated mode")
	}
	if err := validateAuthGroup(value.Auth); err != nil {
		return config{}, err
	}
	return value, nil
}

// validateAuthGroup enforces "complete or fail". Every field is checked; there
// is no defaulting, because a defaulted field in an authentication group is how
// a gate ends up enforcing something nobody chose.
func validateAuthGroup(auth *authConfig) error {
	auth.PublicBaseURL = strings.TrimSuffix(strings.TrimSpace(auth.PublicBaseURL), "/")
	if !validBrowserOrigin(auth.PublicBaseURL) {
		return errors.New("uif auth group: publicBaseUrl must be an https origin with no path")
	}
	for name, endpoint := range map[string]string{
		"authorizeEndpoint":  auth.AuthorizeEndpoint,
		"tokenEndpoint":      auth.TokenEndpoint,
		"tokenProofEndpoint": auth.TokenProofEndpoint,
	} {
		if !validEndpointURL(endpoint) {
			return errors.New("uif auth group: " + name + " must be an https URL with a path")
		}
	}
	// The only optional field in the group, and it is optional because AuthN
	// exposes no logout endpoint in every environment. Set, it must be valid.
	if auth.LogoutEndpoint != "" && !validEndpointURL(auth.LogoutEndpoint) {
		return errors.New("uif auth group: logoutEndpoint must be an https URL with a path")
	}
	if strings.TrimSpace(auth.ClientID) == "" {
		return errors.New("uif auth group: clientId is required")
	}
	if auth.SessionIdleTTLSeconds < 300 || auth.SessionIdleTTLSeconds > 86400 {
		return errors.New("uif auth group: sessionIdleTtlSeconds must be between 300 and 86400")
	}
	return nil
}

// validBrowserOrigin accepts an https origin, plus a loopback http origin so
// the gate can be exercised locally. Loopback is the only http exception: a
// __Host- cookie needs a secure context, and browsers treat localhost as one.
func validBrowserOrigin(value string) bool {
	parsed, err := url.Parse(value)
	if err != nil || parsed.Host == "" || parsed.User != nil || parsed.Path != "" || parsed.RawQuery != "" || parsed.Fragment != "" || parsed.String() != value {
		return false
	}
	return parsed.Scheme == "https" || (parsed.Scheme == "http" && loopbackHost(parsed.Hostname()))
}

func validEndpointURL(value string) bool {
	parsed, err := url.Parse(value)
	if err != nil || parsed.Host == "" || parsed.User != nil || parsed.Path == "" || parsed.RawQuery != "" || parsed.Fragment != "" || parsed.String() != value {
		return false
	}
	return parsed.Scheme == "https" || (parsed.Scheme == "http" && loopbackHost(parsed.Hostname()))
}

func loopbackHost(host string) bool {
	return host == "127.0.0.1" || host == "localhost" || host == "::1"
}

func randomToken(size int) (string, error) {
	raw := make([]byte, size)
	if _, err := rand.Read(raw); err != nil {
		return "", err
	}
	return base64.RawURLEncoding.EncodeToString(raw), nil
}

func writeJSON(w http.ResponseWriter, status int, value any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(value)
}

func writeError(w http.ResponseWriter, status int, code string) {
	writeJSON(w, status, map[string]any{"error": map[string]string{"code": code}})
}

func healthcheck() {
	endpoint := os.Getenv("UI_LIB_HEALTH_URL")
	if endpoint == "" {
		endpoint = "http://127.0.0.1:8080/health"
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	request, _ := http.NewRequestWithContext(ctx, http.MethodGet, endpoint, nil)
	response, err := http.DefaultClient.Do(request)
	if err != nil || response.StatusCode != http.StatusOK {
		os.Exit(1)
	}
	response.Body.Close()
}
