import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";

import { AutoForm, type AutoFormOverrides } from "../../src/forms";
import type { FormSpec } from "../../src/core/config";

// Flat spec with two declared sections; fields join a section via `field.section`.
const spec: FormSpec = {
  fields: [
    { name: "name", type: "text", label: "Name", section: "main", required: true, validation: { required: true } },
    { name: "color", type: "text", label: "Favorite color", section: "main" },
    { name: "notes", type: "textarea", label: "Notes", section: "extra" },
  ],
  sections: [
    { id: "main", title: "Main" },
    { id: "extra", title: "Extra" },
  ],
};

describe("AutoForm overrides + layout slots (issue-602)", () => {
  it("renders a bespoke control for one named field, engine-bound", () => {
    const overrides: AutoFormOverrides = {
      controls: {
        color: ({ field, binding, id }) => (
          <div className="custom-color">
            <label htmlFor={id}>{String(field.label)}</label>
            <input
              id={id}
              type="color"
              value={String(binding.value ?? "#000000")}
              onChange={binding.onChange}
            />
          </div>
        ),
      },
    };
    const html = renderToStaticMarkup(
      <AutoForm spec={spec} overrides={overrides} submitLabel="Save" onSubmit={() => undefined} />,
    );
    // the override replaced the default text control for `color` only
    expect(html).toContain("custom-color");
    expect(html).toContain('type="color"');
    // other fields still auto-render
    expect(html).toContain("ui-text-input-control"); // name
    expect(html).toContain("ui-textarea-control"); // notes
    expect(html).toContain("Save");
  });

  it("wraps a field's layout cell without abandoning auto-render", () => {
    const overrides: AutoFormOverrides = {
      renderField: ({ field, cell }) =>
        field.name === "name" ? <div className="wrapped-cell">{cell}</div> : cell,
    };
    const html = renderToStaticMarkup(
      <AutoForm spec={spec} overrides={overrides} submitLabel="Save" onSubmit={() => undefined} />,
    );
    expect(html).toContain("wrapped-cell");
    // the wrapped field still renders its default control (auto-render preserved)
    expect(html).toContain("ui-text-input-control");
  });

  it("replaces a section's body via the section layout slot", () => {
    const overrides: AutoFormOverrides = {
      renderSection: ({ section, content }) =>
        section.id === "extra" ? (
          <div className="section-slot">
            <p>Custom intro</p>
            {content}
          </div>
        ) : (
          content
        ),
    };
    const html = renderToStaticMarkup(
      <AutoForm spec={spec} overrides={overrides} submitLabel="Save" onSubmit={() => undefined} />,
    );
    expect(html).toContain("section-slot");
    expect(html).toContain("Custom intro");
    // the auto-rendered field inside the slotted section is preserved
    expect(html).toContain("ui-textarea-control");
    // the untouched section still auto-renders
    expect(html).toContain("Favorite color");
  });
});
