import { useRef } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { z } from "zod";

import {
  AutoForm,
  FormProvider,
  defaultControlRegistry,
  useField,
  useForm,
} from "../../src/forms";
import { zodToSpec, type FormFieldSpec, type FormSpec } from "../../src/core/config";

// AutoForm consumes the flat score-work FormSpec ({ fields, sections? }); form-level
// chrome (title / submit label) is an AutoForm prop.
const spec: FormSpec = {
  fields: [
    { name: "name", type: "text", label: "Full name", required: true, validation: { required: true } },
    { name: "age", type: "number", label: "Age" },
    {
      name: "role",
      type: "select",
      label: "Role",
      options: [
        { value: "admin", label: "Admin" },
        { value: "user", label: "User" },
      ],
    },
    { name: "subscribe", type: "switch", label: "Subscribe" },
  ],
};

describe("AutoForm — schema-driven renderer (issue-601)", () => {
  it("renders every field into the EditableFormPanel shell with title + submit", () => {
    const html = renderToStaticMarkup(
      <AutoForm spec={spec} title="Profile" submitLabel="Save profile" onSubmit={() => undefined} />,
    );
    expect(html).toContain("ui-editable-form");
    expect(html).toMatch(/<form[^>]*novalidate=""/i);
    expect(html).toContain("Profile");
    expect(html).toContain("Full name");
    expect(html).toContain("Age");
    expect(html).toContain("Role");
    expect(html).toContain("Subscribe");
    expect(html).toContain("Save profile");
    // each field type maps to its primitive chrome
    expect(html).toContain("ui-text-input-control");
    expect(html).toContain("ui-number-input-control");
    expect(html).toContain("ui-select-control");
    expect(html).toContain("ui-switch-control");
    // required field surfaces the required affordance
    expect(html).toContain("aria-required");
  });

  it("swaps the rendered control when a field's type changes, nothing else", () => {
    const asSelect = renderToStaticMarkup(
      <AutoForm spec={spec} title="Profile" submitLabel="Save profile" onSubmit={() => undefined} />,
    );
    expect(asSelect).toContain("ui-select");

    const swapped: FormSpec = {
      ...spec,
      fields: spec.fields.map((f) => (f.name === "role" ? { ...f, type: "radio" as const } : f)),
    };
    const asRadio = renderToStaticMarkup(
      <AutoForm spec={swapped} title="Profile" submitLabel="Save profile" onSubmit={() => undefined} />,
    );
    expect(asRadio).toContain("ui-radio-group");
    expect(asRadio).not.toContain("ui-select-control");
    // the surrounding fields are unchanged
    expect(asRadio).toContain("Full name");
    expect(asRadio).toContain("Save profile");
  });

  it("wires a live engine error onto the bound control (aria-invalid + alert)", () => {
    const field: FormFieldSpec = {
      name: "name",
      type: "text",
      label: "Full name",
      required: true,
      validation: { required: true },
    };
    function Probe() {
      const binding = useField<{ name: string }, "name">("name");
      return defaultControlRegistry.text({ field, binding, id: "probe-name" });
    }
    function Harness() {
      const form = useForm<{ name: string }>({ defaultValues: { name: "" } });
      const seeded = useRef(false);
      if (!seeded.current) {
        seeded.current = true;
        form.setError("name", "Name is required");
      }
      return (
        <FormProvider form={form}>
          <Probe />
        </FormProvider>
      );
    }
    const html = renderToStaticMarkup(<Harness />);
    expect(html).toContain("Name is required");
    expect(html).toContain('aria-invalid="true"');
    expect(html).toContain("aria-required");
  });

  it("derives + renders from a Zod schema (single source of truth)", () => {
    const schema = z.object({
      email: z.string().email(),
      plan: z.enum(["free", "pro"]),
      active: z.boolean().default(true),
    });
    const derived = zodToSpec(schema);
    const html = renderToStaticMarkup(
      <AutoForm spec={derived} schema={schema} title="Account" submitLabel="Create" onSubmit={() => undefined} />,
    );
    expect(html).toContain("Account");
    // labels default to the humanized field name
    expect(html).toContain("Email");
    expect(html).toContain("Plan");
    expect(html).toContain("Active");
    expect(html).toContain("Create");
    // enum -> select options (option labels are the raw enum values)
    expect(html).toContain("free");
    expect(html).toContain("pro");
  });
});
