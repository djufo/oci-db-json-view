import { describe, expect, it } from "vitest";
import { z } from "zod";

import {
  createFormSpecResolver,
  createServerValidationError,
  extractServerValidationErrors,
  standardSchemaResolver,
  validateValuesAgainstSpec,
  type MessageAwareFormFieldSpec,
} from "../../src/forms";
import type { FormSpec } from "../../src/core/config";

describe("Forms validation message model (issue 615)", () => {
  it("keeps the existing default FormSpec messages", () => {
    const spec: FormSpec = {
      fields: [{ name: "full_name", type: "text", label: "Full name", required: true, validation: { required: true } }],
    };

    expect(validateValuesAgainstSpec(spec, { full_name: "" }).full_name).toBe("Full name is required.");
  });

  it("localizes default messages through a rule-keyed dictionary", () => {
    const spec: FormSpec = {
      fields: [
        { name: "email", type: "text", label: "El. pastas", required: true, validation: { required: true } },
        { name: "bio", type: "textarea", label: "Aprasymas", validation: { minLength: 12 } },
      ],
    };
    const errors = validateValuesAgainstSpec(
      spec,
      { email: "", bio: "trumpas" },
      {
        messages: {
          required: ({ label }) => `${label}: privaloma.`,
          minLength: ({ label, constraint }) => `${label}: bent ${constraint} simboliu.`,
        },
      },
    );

    expect(errors.email).toBe("El. pastas: privaloma.");
    expect(errors.bio).toBe("Aprasymas: bent 12 simboliu.");
  });

  it("lets field-level schema/spec overrides win over the dictionary", () => {
    const field: MessageAwareFormFieldSpec = {
      name: "email",
      type: "text",
      label: "Email",
      required: true,
      validation: {
        required: true,
        format: "email",
        messages: {
          required: "Email is needed before we can continue.",
        },
      },
      messages: {
        email: "Use the address format name@example.com.",
      },
    };
    const spec: FormSpec = { fields: [field] };

    expect(
      validateValuesAgainstSpec(spec, { email: "" }, { messages: { required: "Dictionary required." } }).email,
    ).toBe("Email is needed before we can continue.");
    expect(validateValuesAgainstSpec(spec, { email: "bad" }, { messages: { email: "Dictionary email." } }).email).toBe(
      "Use the address format name@example.com.",
    );
  });

  it("applies the message model through createFormSpecResolver", async () => {
    const spec: FormSpec = {
      fields: [{ name: "quantity", type: "number", label: "Quantity", validation: { min: 2 } }],
    };
    const resolver = createFormSpecResolver(spec, {
      messages: { min: ({ constraint }) => `Minimum is ${constraint}.` },
    });

    const result = await resolver({ quantity: 1 });
    expect(result.errors.quantity).toBe("Minimum is 2.");
  });

  it("preserves schema-native Zod messages as schema-message overrides", async () => {
    const schema = z.object({
      email: z.string().email("Correo invalido"),
    });
    const result = await standardSchemaResolver(schema)({ email: "bad" });
    expect(result.errors.email).toBe("Correo invalido");
  });

  it("turns the documented server 422 payload into a FormSubmissionError", () => {
    const error = createServerValidationError({
      formError: "Could not save.",
      fieldErrors: { email: "Email already exists" },
    });

    expect(extractServerValidationErrors(error)).toEqual({
      formError: "Could not save.",
      fieldErrors: { email: "Email already exists" },
    });
  });
});
