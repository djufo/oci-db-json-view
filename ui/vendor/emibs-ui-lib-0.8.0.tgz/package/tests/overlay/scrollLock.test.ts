import { describe, expect, it } from "vitest";
import {
  __resetScrollLock,
  computeScrollbarCompensation,
  lockBodyScroll,
} from "../../src/components/primitives/overlay/scrollLock";

describe("computeScrollbarCompensation", () => {
  it("returns the width the scrollbar reclaims", () => {
    expect(computeScrollbarCompensation(1024, 1009)).toBe(15);
  });

  it("never returns a negative value", () => {
    expect(computeScrollbarCompensation(800, 800)).toBe(0);
    expect(computeScrollbarCompensation(800, 820)).toBe(0);
  });
});

describe("lockBodyScroll", () => {
  it("is a safe no-op without a DOM and releases idempotently", () => {
    __resetScrollLock();
    const release = lockBodyScroll();
    expect(typeof release).toBe("function");
    // Releasing more than once must not throw.
    release();
    release();
  });
});
