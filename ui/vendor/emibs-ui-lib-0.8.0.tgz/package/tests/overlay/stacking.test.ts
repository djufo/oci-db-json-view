import { afterEach, describe, expect, it, vi } from "vitest";
import {
  __resetOverlayStack,
  getOverlayStack,
  isTopOverlay,
  overlayDepth,
  pushOverlay,
  removeOverlay,
  subscribeOverlayStack,
} from "../../src/components/primitives/overlay/stacking";

afterEach(() => {
  __resetOverlayStack();
});

describe("overlay stacking", () => {
  it("layers overlays in open order and reports the top-most", () => {
    pushOverlay("a");
    pushOverlay("b");
    expect(getOverlayStack()).toEqual(["a", "b"]);
    expect(overlayDepth("a")).toBe(0);
    expect(overlayDepth("b")).toBe(1);
    expect(isTopOverlay("b")).toBe(true);
    expect(isTopOverlay("a")).toBe(false);
  });

  it("closing the top-most promotes the one beneath it", () => {
    pushOverlay("a");
    pushOverlay("b");
    removeOverlay("b");
    expect(getOverlayStack()).toEqual(["a"]);
    expect(isTopOverlay("a")).toBe(true);
  });

  it("re-pushing an open overlay moves it to the top without duplicating", () => {
    pushOverlay("a");
    pushOverlay("b");
    pushOverlay("a");
    expect(getOverlayStack()).toEqual(["b", "a"]);
    expect(isTopOverlay("a")).toBe(true);
  });

  it("reports absent overlays as depth -1 and not top", () => {
    expect(overlayDepth("missing")).toBe(-1);
    expect(isTopOverlay("missing")).toBe(false);
    expect(isTopOverlay("anything")).toBe(false); // empty stack
  });

  it("notifies subscribers on change and stops after unsubscribe", () => {
    const listener = vi.fn();
    const unsubscribe = subscribeOverlayStack(listener);
    pushOverlay("a");
    expect(listener).toHaveBeenCalledTimes(1);
    removeOverlay("a");
    expect(listener).toHaveBeenCalledTimes(2);
    removeOverlay("a"); // no-op, no notification
    expect(listener).toHaveBeenCalledTimes(2);
    unsubscribe();
    pushOverlay("b");
    expect(listener).toHaveBeenCalledTimes(2);
  });
});
