import { describe, expect, it } from "vitest";
import { FOCUSABLE_SELECTOR, resolveTrapTarget } from "../../src/components/primitives/overlay/focusTrap";

describe("resolveTrapTarget", () => {
  it("returns null when there are no tabbable elements", () => {
    expect(resolveTrapTarget({ count: 0, activeIndex: -1, shiftKey: false })).toBeNull();
    expect(resolveTrapTarget({ count: 0, activeIndex: -1, shiftKey: true })).toBeNull();
  });

  it("wraps forward from the last element to the first", () => {
    expect(resolveTrapTarget({ count: 3, activeIndex: 2, shiftKey: false })).toBe(0);
  });

  it("wraps backward from the first element to the last", () => {
    expect(resolveTrapTarget({ count: 3, activeIndex: 0, shiftKey: true })).toBe(2);
  });

  it("lets the browser handle mid-list tabbing", () => {
    expect(resolveTrapTarget({ count: 3, activeIndex: 1, shiftKey: false })).toBeNull();
    expect(resolveTrapTarget({ count: 3, activeIndex: 1, shiftKey: true })).toBeNull();
  });

  it("pulls focus onto the first element when focus is outside the list", () => {
    expect(resolveTrapTarget({ count: 3, activeIndex: -1, shiftKey: false })).toBe(0);
  });

  it("wraps to the last element when Shift-tabbing from outside the list", () => {
    expect(resolveTrapTarget({ count: 3, activeIndex: -1, shiftKey: true })).toBe(2);
  });

  it("handles a single tabbable element by keeping focus on it", () => {
    expect(resolveTrapTarget({ count: 1, activeIndex: 0, shiftKey: false })).toBe(0);
    expect(resolveTrapTarget({ count: 1, activeIndex: 0, shiftKey: true })).toBe(0);
  });
});

describe("FOCUSABLE_SELECTOR", () => {
  it("covers the standard interactive elements and excludes tabindex -1", () => {
    expect(FOCUSABLE_SELECTOR).toContain("a[href]");
    expect(FOCUSABLE_SELECTOR).toContain("button:not([disabled])");
    expect(FOCUSABLE_SELECTOR).toContain("[tabindex]:not([tabindex='-1'])");
  });
});
