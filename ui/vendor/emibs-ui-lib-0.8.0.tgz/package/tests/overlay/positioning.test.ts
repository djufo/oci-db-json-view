import { describe, expect, it } from "vitest";
import {
  computePopoverPosition,
  getPopoverTriggerProps,
  resolvePopoverSide,
} from "../../src/components/primitives/overlay/positioning";

const viewport = { width: 1000, height: 800 };
// A centered anchor: 100x40 at (450, 380).
const anchor = { top: 380, left: 450, width: 100, height: 40 };
const floating = { width: 200, height: 120 };

describe("resolvePopoverSide", () => {
  it("keeps the preferred side when it has room", () => {
    expect(resolvePopoverSide({ anchor, floating, viewport, side: "bottom", offset: 8 })).toBe("bottom");
    expect(resolvePopoverSide({ anchor, floating, viewport, side: "top", offset: 8 })).toBe("top");
  });

  it("flips to the opposite side when the preferred one is clipped", () => {
    // Anchor pinned near the bottom edge: no room below, plenty above.
    const low = { top: 760, left: 450, width: 100, height: 40 };
    expect(resolvePopoverSide({ anchor: low, floating, viewport, side: "bottom", offset: 8 })).toBe("top");
  });

  it("keeps the preferred side when neither side fits but it has the most room", () => {
    const tall = { width: 200, height: 700 };
    // Anchor just below center: slightly more room above than below.
    const anchorMid = { top: 420, left: 450, width: 100, height: 40 };
    expect(resolvePopoverSide({ anchor: anchorMid, floating: tall, viewport, side: "top", offset: 8 })).toBe("top");
  });

  it("flips left/right on the horizontal axis", () => {
    const right = { top: 380, left: 940, width: 40, height: 40 };
    expect(resolvePopoverSide({ anchor: right, floating, viewport, side: "right", offset: 8 })).toBe("left");
  });
});

describe("computePopoverPosition", () => {
  it("places a centered bottom popover directly under the anchor", () => {
    const pos = computePopoverPosition({ anchor, floating, viewport, side: "bottom", align: "center", offset: 8 });
    expect(pos.side).toBe("bottom");
    expect(pos.top).toBe(anchor.top + anchor.height + 8); // 428
    // Cross-axis centered: 450 + 100/2 - 200/2 = 400.
    expect(pos.left).toBe(400);
  });

  it("places a top popover above the anchor accounting for its height", () => {
    const pos = computePopoverPosition({ anchor, floating, viewport, side: "top", align: "center", offset: 8 });
    expect(pos.side).toBe("top");
    expect(pos.top).toBe(anchor.top - floating.height - 8); // 380 - 128 = 252
  });

  it("aligns start and end to the anchor edges", () => {
    const start = computePopoverPosition({ anchor, floating, viewport, side: "bottom", align: "start" });
    expect(start.left).toBe(anchor.left); // 450
    const end = computePopoverPosition({ anchor, floating, viewport, side: "bottom", align: "end" });
    expect(end.left).toBe(anchor.left + anchor.width - floating.width); // 350
  });

  it("shifts the cross axis to keep the popover inside the padded viewport", () => {
    // Anchor hugging the right edge would push a centered popover offscreen.
    const rightAnchor = { top: 380, left: 960, width: 40, height: 40 };
    const pos = computePopoverPosition({
      anchor: rightAnchor,
      floating,
      viewport,
      side: "bottom",
      align: "center",
      offset: 8,
      padding: 8,
    });
    // Clamped so right edge sits at viewport.width - padding: 1000 - 200 - 8 = 792.
    expect(pos.left).toBe(792);
  });

  it("clamps the cross axis to the near edge when the floating element is wider than the viewport band", () => {
    const wide = { width: 1200, height: 120 };
    const pos = computePopoverPosition({ anchor, floating: wide, viewport, side: "bottom", padding: 8 });
    expect(pos.left).toBe(8);
  });

  it("flips a clipped bottom popover to the top", () => {
    const low = { top: 760, left: 450, width: 100, height: 40 };
    const pos = computePopoverPosition({ anchor: low, floating, viewport, side: "bottom", offset: 8 });
    expect(pos.side).toBe("top");
    expect(pos.top).toBe(low.top - floating.height - 8);
  });

  it("clamps the main axis when neither vertical side can fit", () => {
    const tall = { width: 200, height: 700 };
    const anchorMid = { top: 420, left: 450, width: 100, height: 40 };
    const pos = computePopoverPosition({ anchor: anchorMid, floating: tall, viewport, side: "top", padding: 8 });

    expect(pos.side).toBe("top");
    expect(pos.top).toBe(8);
  });

  it("positions a right-side popover and clamps its vertical cross axis", () => {
    const pos = computePopoverPosition({ anchor, floating, viewport, side: "right", align: "start", offset: 8 });
    expect(pos.side).toBe("right");
    expect(pos.left).toBe(anchor.left + anchor.width + 8); // 558
    expect(pos.top).toBe(anchor.top); // start-aligned, within viewport
  });
});

describe("getPopoverTriggerProps", () => {
  it("reports collapsed state without aria-controls when closed", () => {
    expect(getPopoverTriggerProps({ open: false, id: "pop-1" })).toEqual({
      "aria-haspopup": "dialog",
      "aria-expanded": false,
      "aria-controls": undefined,
    });
  });

  it("exposes aria-controls and expanded state when open", () => {
    expect(getPopoverTriggerProps({ open: true, id: "pop-1", haspopup: "menu" })).toEqual({
      "aria-haspopup": "menu",
      "aria-expanded": true,
      "aria-controls": "pop-1",
    });
  });
});
