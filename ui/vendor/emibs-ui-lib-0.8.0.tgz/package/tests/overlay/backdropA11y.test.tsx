// @vitest-environment happy-dom

import { act, type ReactNode } from "react";
import { createRoot, type Root } from "react-dom/client";
import axe from "axe-core";
import { afterEach, describe, expect, it } from "vitest";

import { AlertDialogFrame } from "../../src/components/feedback/AlertDialogFrame";
import { DialogFrame } from "../../src/components/feedback/DialogFrame";
import { Dialog } from "../../src/components/primitives/overlay/Dialog";
import { Drawer } from "../../src/components/primitives/overlay/Drawer";
import { OverlayHarness } from "../../src/components/primitives/overlay/OverlayHarness";
import { useOverlay } from "../../src/components/primitives/overlay/useOverlay";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

type MountedOverlay = {
  container: HTMLDivElement;
  root: Root;
};

function ButtonBackdrop() {
  const { getBackdropProps } = useOverlay({ open: true, onClose: () => undefined });
  // tabIndex={0} keeps the backdrop genuinely tabbable so axe's aria-hidden-focus
  // rule can fire — a backdrop pinned at tabIndex=-1 is never in the tab order and
  // would pass the rule even if aria-hidden crept back in.
  return (
    <button {...getBackdropProps()} tabIndex={0}>
      Dismiss overlay
    </button>
  );
}

let capturedBackdropProps: Record<string, unknown> = {};

function CaptureBackdrop() {
  const { getBackdropProps } = useOverlay({ open: true, onClose: () => undefined });
  capturedBackdropProps = getBackdropProps();
  return null;
}

async function mountOverlay(node: ReactNode): Promise<MountedOverlay> {
  const container = document.createElement("div");
  document.body.append(container);
  const root = createRoot(container);

  await act(async () => {
    root.render(node);
  });

  return { container, root };
}

async function expectNoAriaHiddenFocusViolation() {
  const results = await axe.run(document.body, {
    runOnly: { type: "rule", values: ["aria-hidden-focus"] },
  });

  expect(results.violations).toEqual([]);
}

afterEach(async () => {
  await act(async () => {
    document.body.replaceChildren();
  });
});

describe("overlay backdrop accessibility", () => {
  it("never sets aria-hidden on backdrop props", async () => {
    capturedBackdropProps = {};
    const captured = await mountOverlay(<CaptureBackdrop />);
    try {
      expect(capturedBackdropProps).not.toHaveProperty("aria-hidden");
    } finally {
      await act(async () => captured.root.unmount());
    }
  });

  it("does not hide a consumer-provided focusable backdrop from assistive technology", async () => {
    const backdrop = await mountOverlay(<ButtonBackdrop />);
    try {
      await expectNoAriaHiddenFocusViolation();
    } finally {
      await act(async () => backdrop.root.unmount());
    }
  });

  it("keeps Dialog and Drawer backdrops out of the aria-hidden focusable set", async () => {
    const dialog = await mountOverlay(<Dialog open onClose={() => undefined} title="Dialog title" />);
    try {
      await expectNoAriaHiddenFocusViolation();
    } finally {
      await act(async () => dialog.root.unmount());
    }

    const drawer = await mountOverlay(<Drawer open onClose={() => undefined} title="Drawer title" />);
    try {
      await expectNoAriaHiddenFocusViolation();
    } finally {
      await act(async () => drawer.root.unmount());
    }
  });

  it("keeps the headless harness backdrop out of the aria-hidden focusable set", async () => {
    const harness = await mountOverlay(<OverlayHarness />);
    try {
      const trigger = Array.from(harness.container.querySelectorAll("button")).find(
        (button) => button.textContent === "Open overlay",
      );
      expect(trigger).toBeDefined();
      await act(async () => trigger?.click());

      await expectNoAriaHiddenFocusViolation();
    } finally {
      await act(async () => harness.root.unmount());
    }
  });

  it("keeps DialogFrame and AlertDialogFrame backdrops out of the aria-hidden focusable set", async () => {
    const dialogFrame = await mountOverlay(<DialogFrame open onClose={() => undefined} title="Frame title" />);
    try {
      await expectNoAriaHiddenFocusViolation();
    } finally {
      await act(async () => dialogFrame.root.unmount());
    }

    const alertFrame = await mountOverlay(
      <AlertDialogFrame open onClose={() => undefined} title="Alert frame title" description="Confirm the operation." />,
    );
    try {
      await expectNoAriaHiddenFocusViolation();
    } finally {
      await act(async () => alertFrame.root.unmount());
    }
  });
});
