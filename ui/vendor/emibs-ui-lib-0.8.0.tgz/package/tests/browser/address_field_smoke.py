"""Smoke a built local catalog: python address_field_smoke.py [base-url] [artifact-dir]."""
import sys
from pathlib import Path
from playwright.sync_api import expect, sync_playwright

base_url = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:5177"
artifacts = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("/tmp/address-field-smoke")
artifacts.mkdir(parents=True, exist_ok=True)

with sync_playwright() as playwright:
    browser = playwright.chromium.launch(headless=True)
    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda error: errors.append(str(error)))
    page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
    try:
        page.goto(f"{base_url}/#/c/address-field")
        page.wait_for_load_state("networkidle")
        editor = page.locator(".xpl-canvas__stage > .ui-address-field")
        expect(editor).to_be_visible()
        # A centered canvas must not shrink the editor to its intrinsic width.
        assert editor.evaluate("""el => {
            const parent = el.parentElement;
            const style = getComputedStyle(parent);
            const available = parent.clientWidth - parseFloat(style.paddingLeft) - parseFloat(style.paddingRight);
            return el.clientWidth >= available - 1;
        }"""), "Address editor must fill the width its parent provides"
        editor.get_by_label("Street", exact=True).fill("Updated example avenue")
        expect(editor.get_by_label("Street", exact=True)).to_have_value("Updated example avenue")
        editor.get_by_role("button", name="Map hidden — show on map").click()
        editor.get_by_role("button", name="Pick demo point").click()
        expect(editor.get_by_label("Latitude", exact=True)).to_have_value("55.7")
        expect(editor.get_by_label("Longitude", exact=True)).to_have_value("21.1")
        assert editor.get_by_label("Street", exact=True).evaluate("el => el.getBoundingClientRect().height >= 44")
        page.screenshot(path=str(artifacts / "address-editable-light.png"), full_page=True)

        page.get_by_role("tab", name="Variants", exact=True).click()
        figures = page.locator(".xpl-variant")
        expect(figures).to_have_count(3)
        readonly = figures.nth(1)
        expect(readonly.locator("figcaption")).to_have_text("read-only")
        assert readonly.get_by_label("Street", exact=True).evaluate("el => el.readOnly")
        readonly.get_by_role("button", name="Map hidden — show on map").click()
        expect(readonly.get_by_text("Selected point:", exact=False)).to_be_visible()
        expect(readonly.get_by_role("button", name="Pick demo point")).to_have_count(0)
        no_map = figures.nth(2)
        expect(no_map.locator("figcaption")).to_have_text("no-map")
        no_map.get_by_label("Latitude", exact=True).fill("-45")
        expect(no_map.get_by_label("Latitude", exact=True)).to_have_value("-45")
        no_map.get_by_role("button", name="Map hidden — show on map").click()
        expect(no_map.get_by_text("Map unavailable.", exact=False)).to_be_visible()
        page.get_by_role("button", name="Dark", exact=True).click()
        page.screenshot(path=str(artifacts / "address-variants-dark.png"), full_page=True)

        page.goto(f"{base_url}/#/c/geo-coordinate-picker")
        page.wait_for_load_state("networkidle")
        page.get_by_role("tab", name="Preview", exact=True).click()
        picker = page.locator(".xpl-canvas__stage > .ui-address-field")
        expect(picker.get_by_label("Latitude", exact=True)).to_be_visible()
        picker.get_by_role("button", name="Map hidden — show on map").click()
        picker.get_by_role("button", name="Pick demo point").click()
        expect(picker.get_by_label("Longitude", exact=True)).to_have_value("21.1")
        page.screenshot(path=str(artifacts / "coordinate-picker.png"), full_page=True)

        page.set_viewport_size({"width": 390, "height": 844})
        page.goto(f"{base_url}/#/c/address-field")
        page.wait_for_load_state("networkidle")
        page.get_by_role("tab", name="Preview", exact=True).click()
        editor = page.locator(".xpl-canvas__stage > .ui-address-field")
        page.get_by_role("button", name="Set canvas width to Mobile", exact=True).click()
        assert editor.evaluate("el => el.clientWidth <= 390"), "Mobile canvas must constrain the component"
        assert editor.evaluate("el => el.scrollWidth <= el.clientWidth + 1"), "Address fields overflow at mobile width"
        editor.screenshot(path=str(artifacts / "address-mobile.png"))
        assert not errors, errors
        print("PASS: editable, read-only, no-map, point selection, light/dark, mobile canvas; clean console")
    finally:
        browser.close()
