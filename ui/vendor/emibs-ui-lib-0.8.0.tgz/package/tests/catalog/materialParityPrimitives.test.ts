import { describe, expect, it } from "vitest";
import { entryById, isMigrated } from "../../src/catalog/registry";
import { getSpec } from "../../src/catalog/specs";

const materialParityPrimitiveIds = [
  "button",
  "tooltip",
  "menu",
  "breadcrumb",
  "slider",
  "skeleton",
  "toolbar",
  "table-primitive",
  "chip",
  "meter",
  "signal-dot",
  "freshness-badge",
  "keyboard-hint",
] as const;

describe("UIF-E2 material-parity catalog completeness", () => {
  it.each(materialParityPrimitiveIds)("registers %s with the complete review surface", (id) => {
    const entry = entryById[id];

    expect(entry, `${id} metadata`).toBeDefined();
    expect(isMigrated(entry), `${id} demo`).toBe(true);
    expect(entry.variants?.length, `${id} states matrix`).toBeGreaterThan(0);
    expect(entry.playground?.controls.length, `${id} playground`).toBeGreaterThan(0);
    expect(entry.usage, `${id} usage`).toBeDefined();
    expect(entry.propDocs?.length, `${id} prop docs`).toBeGreaterThan(0);
    expect(entry.hasSpec, `${id} spec flag`).toBe(true);
    expect(getSpec(entry.specPath), `${id} resolved spec`).toBeTruthy();
  });
});
