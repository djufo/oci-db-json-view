import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { getEntry } from "../../src/catalog/registry";

describe("address catalog", () => {
  for (const id of ["address-field", "geo-coordinate-picker"]) {
    it(`${id} demonstrates editable, read-only and no-map modes`, () => {
      const entry = getEntry(id);
      expect(entry).toBeDefined();
      expect(entry!.variants?.map(v => v.label)).toEqual(["editable", "read-only", "no-map"]);
      expect(renderToStaticMarkup(<>{entry!.variants![0].render()}</>)).toContain("Latitude");
      expect(renderToStaticMarkup(<>{entry!.variants![1].render()}</>)).toContain('readOnly=""');
      expect(renderToStaticMarkup(<>{entry!.variants![2].render()}</>)).toContain("Longitude");
    });
  }
});
