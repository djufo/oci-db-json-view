import { describe, expect, it } from "vitest";

import { componentMeta } from "../../src/catalog/metadata";
import { entries } from "../../src/catalog/registry";

describe("DataTable catalog registration", () => {
  it("exposes the canonical DataTable without retired table entries", () => {
    const metaIds = new Set(componentMeta.map((meta) => meta.id));
    const entryIds = new Set(entries.map((entry) => entry.id));

    expect(metaIds.has("data-table")).toBe(true);
    expect(entryIds.has("data-table")).toBe(true);
    expect(metaIds.has("paged-data-table")).toBe(false);
    expect(entryIds.has("paged-data-table")).toBe(false);

    const dataTable = entries.find((entry) => entry.id === "data-table");
    expect(dataTable?.render).toBeTruthy();
    expect(dataTable?.variants?.length).toBeGreaterThan(0);
    expect(dataTable?.usage?.snippet).toContain("DataTable");
    expect(dataTable?.propDocs?.length).toBeGreaterThan(0);
  });
});
