import { describe, expect, it } from "vitest";

import { getSpec } from "../../src/catalog/specs";

/**
 * uif/issue-4675 — the spec loader's reachable roots.
 *
 * `src/catalog/specs.ts` used to glob only `../components/**` and
 * `../forms/**`. A `.SPEC.md` written beside a source file in
 * `src/compositions/**` or `src/core/**` could not be loaded at all: the
 * catalog's "1014/1014 checks (100%)" was silent about those directories by
 * construction, not by measurement.
 *
 * These cases pin the two new roots against a real spec in each, so a future
 * edit that drops a glob fails here rather than degrading quietly to "no spec
 * exists for this component yet".
 */
describe("catalog spec loader — reachable source roots", () => {
  it("loads a spec from src/compositions/**", () => {
    expect(getSpec("./compositions/CompositionFrame.SPEC.md")).toContain("# CompositionFrame");
  });

  it("loads a spec from src/core/**", () => {
    expect(getSpec("./core/orchestration/forms/useForm.SPEC.md")).toContain("# useForm");
  });

  it("still loads the pre-existing components/** and forms/** roots", () => {
    expect(getSpec("./components/data/DataTable.SPEC.md")).toContain("# DataTable");
    expect(getSpec("./forms/AutoForm.SPEC.md")).toContain("# AutoForm");
  });

  it("keys nested paths by their src-relative suffix, with or without a leading ./", () => {
    const withPrefix = getSpec("./core/orchestration/forms/useForm.SPEC.md");
    expect(getSpec("core/orchestration/forms/useForm.SPEC.md")).toBe(withPrefix);
  });

  it("returns null for an unknown path and for a null specPath", () => {
    expect(getSpec("./compositions/NotAReal.SPEC.md")).toBeNull();
    expect(getSpec(null)).toBeNull();
  });
});
