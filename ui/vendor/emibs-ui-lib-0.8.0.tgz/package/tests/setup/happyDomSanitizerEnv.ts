/**
 * Shared vitest setup: repair the parts of `happy-dom` that silently disable
 * DOMPurify.
 *
 * Wired through `vite.config.ts` (`test.setupFiles`), so it runs for EVERY test
 * file in this package, before the test module — and therefore before
 * `dompurify` — is evaluated. That ordering is the whole point: DOMPurify
 * captures the DOM primitives it trusts at module-evaluation time, so a shim
 * installed inside a test body is already too late.
 *
 * ## Why this exists
 *
 * `dompurify` is effectively INERT under `happy-dom`. Verified by direct
 * probing against happy-dom 20.10.6 / dompurify 3.4.13; with neither shim,
 *
 *     DOMPurify.sanitize('<p>hi</p><script>alert(1)</script>')
 *       === 'hi<script>alert(1)</script>'
 *
 * — the script survives, and `DOMPurify.isSupported` is still `true`, so
 * nothing warns. Any test that asserts "the sanitizer stripped X" in an
 * unrepaired happy-dom environment is therefore asserting nothing: it can pass
 * against a sanitizer that does not work, and it can equally report a WORKING
 * sanitizer as broken. Browsers are unaffected — this is a test-environment
 * defect only, and the shipped app sanitizes correctly.
 *
 * There are two independent causes.
 *
 * ### Defect 1 — `nodeName` on the wrong prototype (SHIMMED BELOW)
 *
 * happy-dom defines a `nodeName` getter on BOTH `Node.prototype` and
 * `Element.prototype`, but the `Node.prototype` one returns `''` for every
 * node; only the `Element.prototype` override returns the real tag name.
 * Ordinary property access (`div.nodeName === 'DIV'`) therefore looks correct,
 * which is why this is easy to miss.
 *
 * DOMPurify hardens itself against prototype tampering by capturing
 * `lookupGetter(Node.prototype, 'nodeName')` once, at module scope, and calling
 * that captured getter directly on every node it visits. Under happy-dom it
 * consequently reads EVERY tag name as `''`, matches nothing against its
 * allow-list, and strips every element it walks.
 *
 * The shim below replaces the `Node.prototype` getter with one that computes
 * the correct name for the node it is applied to — i.e. it makes
 * `Node.prototype`'s getter agree with `Element.prototype`'s, which is what a
 * real DOM does. It is deliberately minimal: it patches exactly one accessor on
 * one prototype and changes no other behavior.
 *
 * ### Defect 2 — `NodeIterator` desync on removal (NOT SHIMMED — READ THIS)
 *
 * happy-dom's `NodeIterator` STOPS ADVANCING as soon as a node is removed
 * mid-iteration. A real browser keeps walking (the spec requires the iterator
 * to adjust its reference node). Probed directly: iterating four sibling
 * elements and removing the second yields `[DIV, A, B]` and then `nextNode()`
 * returns `null` — `C` and `D` are never visited.
 *
 * DOMPurify sanitizes by walking a `NodeIterator` and removing hostile nodes as
 * it goes, so under happy-dom it stops sanitizing after its FIRST removal.
 * With the `nodeName` shim applied but the iterator still broken:
 *
 *     DOMPurify.sanitize('<script>a()</script><img src=x onerror=b()><script>c()</script>')
 *       === '<img src="x" onerror="b()"><script>c()</script>'
 *
 * The first payload is removed; everything after it is passed through
 * untouched. This CANNOT be shimmed the way `nodeName` can — it would mean
 * reimplementing happy-dom's iterator — so it is documented instead.
 *
 * ## What this means when you write a sanitizer test
 *
 * - **One hostile payload per rendered string.** Do not concatenate several
 *   payloads into one input and assert they are all gone: DOMPurify will
 *   correctly strip the first and silently pass the rest, and your test will
 *   fail for an environment reason that has nothing to do with the component.
 *   Use `it.each` over a payload table, rendering each payload on its own.
 * - **A "sanitizer removed it" pass proves less than it looks like.** With this
 *   setup a single-payload assertion is a real statement about the component.
 *   A multi-payload assertion is a statement about happy-dom's iterator.
 * - Benign markup round-trips correctly with this setup applied
 *   (`'<p>hello</p><a href="https://example.com">docs</a>'` survives intact),
 *   so allow-list assertions are trustworthy.
 *
 * ## When this file can be deleted
 *
 * Both defects are upstream happy-dom bugs. Re-probe on a happy-dom upgrade:
 * if `Object.getOwnPropertyDescriptor(Node.prototype, 'nodeName').get.call(el)`
 * returns the tag name, defect 1 is fixed and the shim can go. If a
 * `NodeIterator` keeps advancing past a removal, defect 2 is fixed and the
 * one-payload-per-render rule can go with it. Delete the shim rather than
 * leaving it: a redundant DOM-global patch is its own hazard.
 */

const NON_ELEMENT_NODE_NAMES: Record<number, string> = {
  3: "#text",
  4: "#cdata-section",
  8: "#comment",
  9: "#document",
  11: "#document-fragment",
};

type NamedNode = {
  nodeType: number;
  tagName?: string;
  name?: string;
  target?: string;
};

installNodeNameGetter();

function installNodeNameGetter(): void {
  // Node-environment test files (`// @vitest-environment node`, or the default)
  // have no DOM at all. Nothing to repair, and nothing that reads it.
  const NodeCtor = (globalThis as { Node?: { prototype: object } }).Node;
  if (!NodeCtor) {
    return;
  }

  // Only patch an environment that actually exhibits defect 1, so a fixed
  // happy-dom (or a real browser runner) is left completely alone.
  const descriptor = Object.getOwnPropertyDescriptor(NodeCtor.prototype, "nodeName");
  if (!descriptor?.get) {
    return;
  }
  const probe = (globalThis as { document?: Document }).document?.createElement("div");
  if (!probe || descriptor.get.call(probe) === "DIV") {
    return;
  }

  Object.defineProperty(NodeCtor.prototype, "nodeName", {
    configurable: true,
    get(this: NamedNode) {
      // Mirrors the DOM spec's nodeName table. Element/ProcessingInstruction/
      // DocumentType read their own name; everything else is a fixed literal.
      if (this.nodeType === 1) {
        return this.tagName ?? "";
      }
      if (this.nodeType === 7) {
        return this.target ?? "";
      }
      if (this.nodeType === 10) {
        return this.name ?? "";
      }
      return NON_ELEMENT_NODE_NAMES[this.nodeType] ?? "";
    },
  });
}
