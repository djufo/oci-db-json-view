// @vitest-environment happy-dom

/**
 * One contract, eight components (uif/issue-4684).
 *
 * `src/theme/STATES.md` rule 5 makes `disabled` and `busy` different states:
 *
 *   - `disabled` removes interactivity — `pointer-events: none`, NOT focusable.
 *   - `busy` signals in-flight work — the control dims through
 *     `--state-busy-opacity` but STAYS FOCUSABLE and announces `aria-busy="true"`.
 *
 * Nine components collapsed the two into `disabled={x || busy}`. The harm is
 * always the same and always invisible to a sighted mouse user: the control the
 * user just activated leaves the tab order at the exact moment it starts
 * reporting on itself, so a keyboard or screen-reader user is dropped to the top
 * of the document with no way back to read the outcome. `NotificationToggle` was
 * fixed first (uif/issue-4673) and keeps its own tests; the six reported
 * siblings are below, followed by two more that the `check-busy-state` gate
 * found on its first run.
 *
 * The tests live together rather than beside each component because they are one
 * rule, not eight coincidences: a future component that reintroduces the
 * conflation should land next to the others, and a reader auditing the rule
 * should find every instance of it in one file.
 *
 * Each component gets the same four questions:
 *   1. while busy, is the control still focusable (not `disabled`)?
 *   2. while busy, does it announce `aria-busy="true"`?
 *   3. while busy, is re-entry blocked — the correct mechanism for preventing a
 *      double submit, since `disabled` destroys focus?
 *   4. does a genuine `disabled` still remove interactivity?
 */

import { act, createElement, type ReactElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { WorkflowCommandBar } from "../../src/components/data/WorkflowCommandBar";
import { ThemeLabPanel } from "../../src/components/data/ThemeLabPanel";
import { ThemeExportPanel } from "../../src/components/data/ThemeExportPanel";
import { NewsletterSignupPanel } from "../../src/components/data/NewsletterSignupPanel";
import { ConfirmationDialog } from "../../src/components/feedback/ConfirmationDialog";
import { ResourceTransferDialog } from "../../src/components/data/ResourceTransferDialog";
import { ScheduleEditorDialog } from "../../src/components/data/ScheduleEditorDialog";
import { CreationDialog } from "../../src/components/feedback/CreationDialog";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;

let container: HTMLDivElement;
let root: Root;

beforeEach(() => {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
});

afterEach(() => {
  act(() => root.unmount());
  container.remove();
  // The two dialogs mount through the overlay engine's portal, outside `container`.
  document.querySelectorAll("[data-ui-overlay-portal]").forEach((node) => node.remove());
});

function render(element: ReactElement) {
  act(() => root.render(element));
}

/** Buttons anywhere the component rendered, portal included. */
function buttons(): HTMLButtonElement[] {
  return [...document.querySelectorAll<HTMLButtonElement>("button")];
}

function buttonWithText(text: string): HTMLButtonElement {
  const match = buttons().find((button) => (button.textContent ?? "").includes(text));
  if (!match) {
    throw new Error(
      `No button containing "${text}". Present: ${buttons().map((b) => JSON.stringify(b.textContent)).join(", ")}`,
    );
  }
  return match;
}

/**
 * The whole point of the rule, as one assertion: a busy control is still
 * reachable by keyboard, and says that it is busy.
 */
function expectBusyButStillFocusable(control: HTMLElement) {
  expect((control as HTMLButtonElement).disabled).toBe(false);
  expect(control.getAttribute("aria-busy")).toBe("true");

  control.focus();
  expect(document.activeElement).toBe(control);
}

describe("STATES.md rule 5 — WorkflowCommandBar", () => {
  const command = (overrides: Record<string, unknown> = {}) => ({
    id: "advance",
    label: "Advance to review",
    onSelect: vi.fn(),
    ...overrides,
  });

  it("keeps a busy command focusable and announces aria-busy", () => {
    render(createElement(WorkflowCommandBar, { commands: [command({ busy: true })] }));

    expectBusyButStillFocusable(buttonWithText("Advance to review"));
  });

  it("does not re-fire a command while it is in flight", () => {
    const onSelect = vi.fn();
    render(createElement(WorkflowCommandBar, { commands: [command({ busy: true, onSelect })] }));

    act(() => buttonWithText("Advance to review").click());

    expect(onSelect).not.toHaveBeenCalled();
  });

  it("still fires the command when idle", () => {
    const onSelect = vi.fn();
    render(createElement(WorkflowCommandBar, { commands: [command({ onSelect })] }));

    act(() => buttonWithText("Advance to review").click());

    expect(onSelect).toHaveBeenCalledTimes(1);
  });

  it("keeps the busy command's accessible name specific to that command", () => {
    render(createElement(WorkflowCommandBar, { commands: [command({ busy: true })] }));

    // Not the bare "Loading" every in-flight command in the bar would share.
    expect(buttonWithText("Advance to review").getAttribute("aria-label")).toBe("Loading: Advance to review");
  });

  it("still removes interactivity when the command is genuinely disabled", () => {
    const onSelect = vi.fn();
    render(createElement(WorkflowCommandBar, { commands: [command({ disabled: true, onSelect })] }));

    const button = buttonWithText("Advance to review");
    expect(button.disabled).toBe(true);
    act(() => button.click());
    expect(onSelect).not.toHaveBeenCalled();
  });
});

describe("STATES.md rule 5 — ThemeLabPanel", () => {
  const prompt = { label: "Prompt", value: "", onChange: vi.fn() };

  it("keeps a busy generate action focusable and announces aria-busy", () => {
    render(
      createElement(ThemeLabPanel, {
        prompt,
        generateAction: { label: "Generate", busyLabel: "Generating", busy: true, onClick: vi.fn() },
      }),
    );

    expectBusyButStillFocusable(buttonWithText("Generating"));
  });

  it("keeps a busy apply action focusable and announces aria-busy", () => {
    render(
      createElement(ThemeLabPanel, {
        prompt,
        applyAction: { label: "Apply", busyLabel: "Applying", busy: true, onClick: vi.fn() },
      }),
    );

    expectBusyButStillFocusable(buttonWithText("Applying"));
  });

  it("does not re-fire generate while it is in flight", () => {
    const onClick = vi.fn();
    render(
      createElement(ThemeLabPanel, {
        prompt,
        generateAction: { label: "Generate", busyLabel: "Generating", busy: true, onClick },
      }),
    );

    act(() => buttonWithText("Generating").click());

    expect(onClick).not.toHaveBeenCalled();
  });

  it("names the busy button with its visible busy text, not a bare Loading", () => {
    render(
      createElement(ThemeLabPanel, {
        prompt,
        generateAction: { label: "Generate", busyLabel: "Generating", busy: true, onClick: vi.fn() },
      }),
    );

    expect(buttonWithText("Generating").getAttribute("aria-label")).toBe("Generating");
  });

  it("still removes interactivity when the action is genuinely disabled", () => {
    const onClick = vi.fn();
    render(
      createElement(ThemeLabPanel, {
        prompt,
        generateAction: { label: "Generate", disabled: true, onClick },
      }),
    );

    const button = buttonWithText("Generate");
    expect(button.disabled).toBe(true);
    act(() => button.click());
    expect(onClick).not.toHaveBeenCalled();
  });
});

describe("STATES.md rule 5 — ThemeExportPanel", () => {
  it("keeps a busy export action focusable and announces aria-busy", () => {
    render(
      createElement(ThemeExportPanel, {
        actions: [{ id: "copy", label: "Copy", busyLabel: "Copying", busy: true, onClick: vi.fn() }],
      }),
    );

    expectBusyButStillFocusable(buttonWithText("Copying"));
  });

  it("does not re-fire the export while it is in flight", () => {
    const onClick = vi.fn();
    render(
      createElement(ThemeExportPanel, {
        actions: [{ id: "copy", label: "Copy", busyLabel: "Copying", busy: true, onClick }],
      }),
    );

    act(() => buttonWithText("Copying").click());

    expect(onClick).not.toHaveBeenCalled();
  });

  it("still removes interactivity when the action is genuinely disabled", () => {
    const onClick = vi.fn();
    render(
      createElement(ThemeExportPanel, {
        actions: [{ id: "copy", label: "Copy", disabled: true, onClick }],
      }),
    );

    const button = buttonWithText("Copy");
    expect(button.disabled).toBe(true);
    act(() => button.click());
    expect(onClick).not.toHaveBeenCalled();
  });
});

describe("STATES.md rule 5 — NewsletterSignupPanel", () => {
  const base = { title: "Stay in the loop", value: "reader@example.com" };

  it("keeps the busy submit button focusable and announces aria-busy", () => {
    render(createElement(NewsletterSignupPanel, { ...base, busy: true, onSubmit: vi.fn() }));

    expectBusyButStillFocusable(buttonWithText("Subscribing..."));
  });

  it("keeps the email field focusable while submitting, as readonly rather than disabled", () => {
    render(createElement(NewsletterSignupPanel, { ...base, busy: true, onSubmit: vi.fn() }));

    const input = document.querySelector<HTMLInputElement>('input[type="email"]')!;

    // `readonly` is the state model's own answer to "shown, not editable": it
    // keeps the value announced and the field reachable, which `disabled` does not.
    expect(input.disabled).toBe(false);
    expect(input.readOnly).toBe(true);

    input.focus();
    expect(document.activeElement).toBe(input);
  });

  it("does not submit again while a submission is in flight", () => {
    const onSubmit = vi.fn();
    render(createElement(NewsletterSignupPanel, { ...base, busy: true, onSubmit }));

    // Enter inside the field submits the form without going through the button's
    // own click handler, so the form needs its own guard.
    const form = document.querySelector("form")!;
    act(() => form.requestSubmit());

    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("still submits when idle", () => {
    const onSubmit = vi.fn((event: { preventDefault: () => void }) => event.preventDefault());
    render(createElement(NewsletterSignupPanel, { ...base, onSubmit }));

    const form = document.querySelector("form")!;
    act(() => form.requestSubmit());

    expect(onSubmit).toHaveBeenCalledTimes(1);
  });

  it("still removes interactivity when genuinely disabled", () => {
    render(createElement(NewsletterSignupPanel, { ...base, disabled: true, onSubmit: vi.fn() }));

    expect(document.querySelector<HTMLInputElement>('input[type="email"]')!.disabled).toBe(true);
    expect(buttonWithText("Subscribe").disabled).toBe(true);
  });
});

describe("STATES.md rule 5 — ConfirmationDialog", () => {
  const base = { open: true as const, title: "Delete attachment?" };

  it("keeps the busy confirm button focusable and announces aria-busy", () => {
    render(
      createElement(ConfirmationDialog, { ...base, busy: true, onCancel: vi.fn(), onConfirm: vi.fn() }),
    );

    // Losing focus here is the worst case for the rule: the user has just
    // triggered a destructive mutation and needs to hear how it went.
    expectBusyButStillFocusable(buttonWithText("Working"));
  });

  it("does not confirm twice while the mutation is in flight", () => {
    const onConfirm = vi.fn();
    render(createElement(ConfirmationDialog, { ...base, busy: true, onCancel: vi.fn(), onConfirm }));

    act(() => buttonWithText("Working").click());

    // Double-submission is blocked in `requestConfirm`, not by `disabled`.
    expect(onConfirm).not.toHaveBeenCalled();
  });

  it("still confirms when idle", () => {
    const onConfirm = vi.fn();
    render(createElement(ConfirmationDialog, { ...base, onCancel: vi.fn(), onConfirm }));

    act(() => buttonWithText("Confirm").click());

    expect(onConfirm).toHaveBeenCalledTimes(1);
  });

  it("still removes interactivity when the caller disables confirmation", () => {
    const onConfirm = vi.fn();
    render(
      createElement(ConfirmationDialog, { ...base, confirmDisabled: true, onCancel: vi.fn(), onConfirm }),
    );

    const button = buttonWithText("Confirm");
    expect(button.disabled).toBe(true);
    act(() => button.click());
    expect(onConfirm).not.toHaveBeenCalled();
  });
});

describe("STATES.md rule 5 — ResourceTransferDialog", () => {
  const base = {
    open: true as const,
    resource: { title: "quarterly-report.pdf" },
    targets: [
      { id: "alpha", label: "Project Alpha" },
      { id: "beta", label: "Project Beta" },
    ],
    targetId: "alpha",
    move: false,
  };

  it("keeps the busy confirm button focusable and announces aria-busy", () => {
    render(
      createElement(ResourceTransferDialog, {
        ...base,
        busy: true,
        onTargetChange: vi.fn(),
        onCancel: vi.fn(),
        onConfirm: vi.fn(),
      }),
    );

    expectBusyButStillFocusable(buttonWithText("Working"));
  });

  it("keeps the destination radios focusable while the transfer is in flight", () => {
    render(
      createElement(ResourceTransferDialog, {
        ...base,
        busy: true,
        onTargetChange: vi.fn(),
        onCancel: vi.fn(),
        onConfirm: vi.fn(),
      }),
    );

    const radios = [...document.querySelectorAll<HTMLInputElement>('input[type="radio"]')];
    expect(radios).toHaveLength(2);

    // Disabling these emptied the dialog out of the accessibility tree: a
    // screen-reader user could not read back the destination they had chosen.
    for (const radio of radios) expect(radio.disabled).toBe(false);

    radios[0].focus();
    expect(document.activeElement).toBe(radios[0]);

    expect(
      document.querySelector('[role="radiogroup"]')!.getAttribute("aria-readonly"),
    ).toBe("true");
  });

  it("refuses a destination change while the transfer is in flight", () => {
    const onTargetChange = vi.fn();
    render(
      createElement(ResourceTransferDialog, {
        ...base,
        busy: true,
        onTargetChange,
        onCancel: vi.fn(),
        onConfirm: vi.fn(),
      }),
    );

    const beta = [...document.querySelectorAll<HTMLInputElement>('input[type="radio"]')][1];
    act(() => beta.click());

    expect(onTargetChange).not.toHaveBeenCalled();
  });

  it("keeps the move checkbox focusable and unchangeable while in flight", () => {
    const onMoveChange = vi.fn();
    render(
      createElement(ResourceTransferDialog, {
        ...base,
        busy: true,
        onMoveChange,
        onTargetChange: vi.fn(),
        onCancel: vi.fn(),
        onConfirm: vi.fn(),
      }),
    );

    const checkbox = document.querySelector<HTMLInputElement>('input[type="checkbox"]')!;
    expect(checkbox.disabled).toBe(false);
    expect(checkbox.getAttribute("aria-readonly")).toBe("true");

    checkbox.focus();
    expect(document.activeElement).toBe(checkbox);

    act(() => checkbox.click());
    expect(onMoveChange).not.toHaveBeenCalled();
  });

  it("still changes destination and mode when idle", () => {
    const onTargetChange = vi.fn();
    const onMoveChange = vi.fn();
    render(
      createElement(ResourceTransferDialog, {
        ...base,
        onMoveChange,
        onTargetChange,
        onCancel: vi.fn(),
        onConfirm: vi.fn(),
      }),
    );

    const beta = [...document.querySelectorAll<HTMLInputElement>('input[type="radio"]')][1];
    act(() => beta.click());
    expect(onTargetChange).toHaveBeenCalledWith("beta");

    act(() => document.querySelector<HTMLInputElement>('input[type="checkbox"]')!.click());
    expect(onMoveChange).toHaveBeenCalledWith(true);
  });

  it("still disables a target the caller marked unavailable", () => {
    render(
      createElement(ResourceTransferDialog, {
        ...base,
        targets: [base.targets[0], { id: "beta", label: "Project Beta", disabled: true }],
        onTargetChange: vi.fn(),
        onCancel: vi.fn(),
        onConfirm: vi.fn(),
      }),
    );

    const radios = [...document.querySelectorAll<HTMLInputElement>('input[type="radio"]')];
    expect(radios[0].disabled).toBe(false);
    expect(radios[1].disabled).toBe(true);
  });
});

/**
 * The last two were not in the original report. The `check-busy-state` gate
 * added by this ticket found them — along with three more in the Forms slice
 * that are baselined — which is the first evidence that the gate catches what
 * review missed rather than only what review already found.
 */
describe("STATES.md rule 5 — ScheduleEditorDialog (found by the gate)", () => {
  const base = {
    open: true as const,
    title: "Edit schedule",
    enabled: true,
    schedule: "0 9 * * 1",
  };

  it("keeps the busy save button focusable and announces aria-busy", () => {
    render(
      createElement(ScheduleEditorDialog, {
        ...base,
        saving: true,
        onClose: vi.fn(),
        onEnabledChange: vi.fn(),
        onScheduleChange: vi.fn(),
        onSubmit: vi.fn(),
      }),
    );

    expectBusyButStillFocusable(buttonWithText("Saving"));
  });

  it("does not save again while a save is in flight", () => {
    const onSubmit = vi.fn();
    render(
      createElement(ScheduleEditorDialog, {
        ...base,
        saving: true,
        onClose: vi.fn(),
        onEnabledChange: vi.fn(),
        onScheduleChange: vi.fn(),
        onSubmit,
      }),
    );

    act(() => document.querySelector("form")!.requestSubmit());

    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("still saves when idle", () => {
    const onSubmit = vi.fn((event: { preventDefault: () => void }) => event.preventDefault());
    render(
      createElement(ScheduleEditorDialog, {
        ...base,
        onClose: vi.fn(),
        onEnabledChange: vi.fn(),
        onScheduleChange: vi.fn(),
        onSubmit,
      }),
    );

    act(() => document.querySelector("form")!.requestSubmit());

    expect(onSubmit).toHaveBeenCalledTimes(1);
  });

  it("still removes interactivity when the caller disables submission", () => {
    render(
      createElement(ScheduleEditorDialog, {
        ...base,
        submitDisabled: true,
        onClose: vi.fn(),
        onEnabledChange: vi.fn(),
        onScheduleChange: vi.fn(),
        onSubmit: vi.fn(),
      }),
    );

    expect(buttonWithText("Save").disabled).toBe(true);
  });
});

describe("STATES.md rule 5 — CreationDialog (found by the gate)", () => {
  const base = { open: true as const, title: "New project" };

  it("keeps the busy submit button focusable and announces aria-busy", () => {
    render(createElement(CreationDialog, { ...base, submitting: true, onClose: vi.fn(), onSubmit: vi.fn() }));

    expectBusyButStillFocusable(buttonWithText("Creating"));
  });

  it("does not submit again while a submission is in flight", () => {
    const onSubmit = vi.fn();
    render(createElement(CreationDialog, { ...base, submitting: true, onClose: vi.fn(), onSubmit }));

    act(() => document.querySelector("form")!.requestSubmit());

    expect(onSubmit).not.toHaveBeenCalled();
  });

  it("still submits when idle", () => {
    const onSubmit = vi.fn((event: { preventDefault: () => void }) => event.preventDefault());
    render(createElement(CreationDialog, { ...base, onClose: vi.fn(), onSubmit }));

    act(() => document.querySelector("form")!.requestSubmit());

    expect(onSubmit).toHaveBeenCalledTimes(1);
  });

  it("still removes interactivity when the caller disables submission", () => {
    render(createElement(CreationDialog, { ...base, submitDisabled: true, onClose: vi.fn(), onSubmit: vi.fn() }));

    expect(buttonWithText("Create").disabled).toBe(true);
  });
});
