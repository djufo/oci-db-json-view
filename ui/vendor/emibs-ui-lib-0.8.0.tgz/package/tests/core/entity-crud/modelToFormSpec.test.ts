import { describe, expect, it } from "vitest";

import {
  FIELD_TYPES,
  exampleProjectModel,
  modelToFormSpec,
  type EntityFormFieldSpec,
  type EntityModel,
  type ExampleProjectRecord,
} from "../../../src/core/config";

function field(name: string, fields: readonly EntityFormFieldSpec[]): EntityFormFieldSpec {
  const match = fields.find((entry) => entry.name === name);
  if (!match) throw new Error(`No field named ${name}`);
  return match;
}

describe("EntityModel -> FormSpec", () => {
  it("derives create/edit specs from the typed entity model", () => {
    const typedModel: EntityModel<ExampleProjectRecord> = exampleProjectModel;
    const createSpec = modelToFormSpec(typedModel, { mode: "create" });
    const editSpec = modelToFormSpec(typedModel, { mode: "edit" });

    expect(createSpec.fields.map((entry) => entry.name)).toEqual([
      "id",
      "name",
      "status",
      "ownerId",
      "budget",
      "launchDate",
      "tags",
      "description",
    ]);
    expect(field("id", createSpec.fields).readOnly).toBeUndefined();
    expect(field("id", editSpec.fields).readOnly).toBe(true);
    expect(editSpec.sections).toEqual(exampleProjectModel.sections);
  });

  it("reuses the AutoForm field type vocabulary exactly", () => {
    const spec = modelToFormSpec(exampleProjectModel);
    expect(spec.fields.every((entry) => FIELD_TYPES.includes(entry.type))).toBe(true);
    expect(field("tags", spec.fields).type).toBe("tags");
    expect(field("description", spec.fields).type).toBe("textarea");
  });

  it("carries relation metadata without inventing a new FormSpec field type", () => {
    const spec = modelToFormSpec(exampleProjectModel);
    const owner = field("ownerId", spec.fields);

    expect(owner.type).toBe("select");
    expect(owner.relation).toEqual({
      id: "project-owner",
      target: "owner",
      cardinality: "one",
    });
  });
});
