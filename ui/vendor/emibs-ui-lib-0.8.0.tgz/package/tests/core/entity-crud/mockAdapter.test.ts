import { describe, expect, it } from "vitest";

import {
  createMockAdapter,
  exampleProjectRows,
  type CrudAdapter,
  type ExampleProjectRecord,
} from "../../../src/core";

describe("CrudAdapter mock implementation", () => {
  it("paginates, sorts, and filters in memory", async () => {
    const adapter = createMockAdapter(exampleProjectRows, { identity: "id" });

    const result = await adapter.list({
      page: 1,
      pageSize: 2,
      sort: { field: "budget", direction: "desc" },
      filter: { status: "active" },
    });

    expect(result.total).toBe(1);
    expect(result.rows[0]?.name).toBe("Atlas Portal");
  });

  it("creates, updates, removes, and snapshots without exposing mutable state", async () => {
    const adapter = createMockAdapter(exampleProjectRows, { identity: "id", idPrefix: "project" });

    const created = await adapter.create({
      name: "Risk Console",
      status: "planned",
      ownerId: "owner-1",
      budget: 9000,
      launchDate: "2026-11-01",
      tags: [],
      description: "Risk review workspace.",
    });
    expect(created.id).toBe("project-4");

    const updated = await adapter.update(created.id, { status: "active", budget: 12000 });
    expect(updated.status).toBe("active");
    expect(updated.budget).toBe(12000);

    await adapter.remove(created.id);
    expect(await adapter.get(created.id)).toBeNull();

    const snapshot = adapter.snapshot();
    (snapshot[0] as ExampleProjectRecord).name = "mutated outside";
    expect((await adapter.get("project-1"))?.name).toBe("Atlas Portal");
  });

  it("lets ResourceManager swap to any CrudAdapter implementation", async () => {
    const customAdapter: CrudAdapter<ExampleProjectRecord> = {
      async list() {
        return { rows: [exampleProjectRows[0]], total: 1 };
      },
      async get(id) {
        return exampleProjectRows.find((row) => row.id === id) ?? null;
      },
      async create(values) {
        return { ...exampleProjectRows[0], ...values, id: "custom-1" };
      },
      async update(id, values) {
        return { ...exampleProjectRows[0], ...values, id: String(id) };
      },
      async remove() {
        return undefined;
      },
    };

    await expect(customAdapter.list({ page: 1, pageSize: 10 })).resolves.toMatchObject({
      total: 1,
    });
  });
});
