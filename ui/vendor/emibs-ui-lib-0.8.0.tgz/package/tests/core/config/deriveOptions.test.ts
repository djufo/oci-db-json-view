import { describe, expect, it } from "vitest";
import { z } from "zod";

import { zodToSpec, type FormFieldSpec, type FormSpec } from "../../../src/core/config";

function field(spec: FormSpec, name: string): FormFieldSpec {
  const f = spec.fields.find((x) => x.name === name);
  if (!f) throw new Error(`no field "${name}" in spec`);
  return f;
}

// issue-600 derivation completeness: choice unions and enum-typed arrays carry
// their options through so AutoForm can render a select / tag vocabulary.
describe("zodToSpec — union + array-enum options", () => {
  it("maps a union of string literals to a select with those options", () => {
    const schema = z.object({
      size: z.union([z.literal("s"), z.literal("m"), z.literal("l")]),
    });
    const spec = zodToSpec(schema);
    expect(field(spec, "size").type).toBe("select");
    expect(field(spec, "size").options).toEqual([
      { value: "s", label: "s" },
      { value: "m", label: "m" },
      { value: "l", label: "l" },
    ]);
  });

  it("seeds tag options from an array of an enum", () => {
    const schema = z.object({
      labels: z.array(z.enum(["bug", "chore", "feat"])),
    });
    const spec = zodToSpec(schema);
    expect(field(spec, "labels").type).toBe("tags");
    expect(field(spec, "labels").options).toEqual([
      { value: "bug", label: "bug" },
      { value: "chore", label: "chore" },
      { value: "feat", label: "feat" },
    ]);
  });

  it("leaves a plain string array without options", () => {
    const spec = zodToSpec(z.object({ tags: z.array(z.string()) }));
    expect(field(spec, "tags").type).toBe("tags");
    expect(field(spec, "tags").options).toBeUndefined();
  });
});
