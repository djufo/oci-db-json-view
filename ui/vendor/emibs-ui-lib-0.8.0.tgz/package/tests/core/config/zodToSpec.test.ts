import { describe, expect, it } from "vitest";
import { z } from "zod";

import {
  FIELD_TYPES,
  isFieldType,
  zodToSpec,
  type FormFieldSpec,
  type FormSpec,
} from "../../../src/core/config";
import { standardSchemaResolver } from "../../../src/core/orchestration/forms";

function field(spec: FormSpec, name: string): FormFieldSpec {
  const f = spec.fields.find((x) => x.name === name);
  if (!f) throw new Error(`no field "${name}" in spec`);
  return f;
}

describe("FIELD_TYPES / isFieldType", () => {
  it("covers the documented control surface", () => {
    expect(FIELD_TYPES).toEqual([
      "text",
      "number",
      "select",
      "combobox",
      "checkbox",
      "switch",
      "radio",
      "date",
      "file",
      "tags",
      "textarea",
    ]);
  });

  it("guards known vs unknown control types", () => {
    expect(isFieldType("select")).toBe(true);
    expect(isFieldType("dropdown")).toBe(false);
    expect(isFieldType(42)).toBe(false);
  });
});

describe("zodToSpec — core type mapping", () => {
  const schema = z.object({
    name: z.string(),
    age: z.coerce.number(),
    active: z.boolean(),
    role: z.enum(["admin", "user"]),
    tags: z.array(z.string()),
    when: z.date(),
  });

  const spec = zodToSpec(schema);

  it("emits one field per schema key in shape order", () => {
    expect(spec.fields.map((f) => f.name)).toEqual([
      "name",
      "age",
      "active",
      "role",
      "tags",
      "when",
    ]);
  });

  it("maps zod field types to the documented default controls", () => {
    expect(field(spec, "name").type).toBe("text");
    expect(field(spec, "age").type).toBe("number");
    expect(field(spec, "active").type).toBe("checkbox");
    expect(field(spec, "role").type).toBe("select");
    expect(field(spec, "tags").type).toBe("tags");
    expect(field(spec, "when").type).toBe("date");
  });

  it("derives options for enum fields", () => {
    expect(field(spec, "role").options).toEqual([
      { value: "admin", label: "admin" },
      { value: "user", label: "user" },
    ]);
  });
});

describe("zodToSpec — required, defaults, description", () => {
  const schema = z.object({
    email: z.string().describe("Login email"),
    nickname: z.string().optional(),
    remember: z.boolean().default(true),
    country: z.string().nullable(),
  });
  const spec = zodToSpec(schema);

  it("marks non-optional fields required and mirrors it into validation", () => {
    expect(field(spec, "email").required).toBe(true);
    expect(field(spec, "email").validation?.required).toBe(true);
  });

  it("treats optional and defaulted fields as not required", () => {
    expect(field(spec, "nickname").required).toBe(false);
    expect(field(spec, "nickname").validation?.required).toBeUndefined();
    expect(field(spec, "remember").required).toBe(false);
  });

  it("keeps nullable fields required (must be present, may be null)", () => {
    expect(field(spec, "country").required).toBe(true);
  });

  it("carries the default value through the wrapper", () => {
    expect(field(spec, "remember").default).toBe(true);
    expect("default" in field(spec, "email")).toBe(false);
  });

  it("reads .describe() text as the field description", () => {
    expect(field(spec, "email").description).toBe("Login email");
  });
});

describe("zodToSpec — validation hints", () => {
  const schema = z.object({
    username: z.string().min(2).max(20),
    quantity: z.number().min(1).max(99),
    contact: z.string().email(),
  });
  const spec = zodToSpec(schema);

  it("extracts string length bounds", () => {
    expect(field(spec, "username").validation).toMatchObject({
      required: true,
      minLength: 2,
      maxLength: 20,
    });
  });

  it("extracts numeric bounds", () => {
    expect(field(spec, "quantity").validation).toMatchObject({
      required: true,
      min: 1,
      max: 99,
    });
  });

  it("extracts a string format", () => {
    expect(field(spec, "contact").validation?.format).toBe("email");
  });
});

describe("zodToSpec — .meta() authoring hints", () => {
  const schema = z.object({
    bio: z.string().meta({
      control: "textarea",
      label: "About you",
      placeholder: "A few words",
      width: "full",
      section: "profile",
      order: 2,
    }),
    theme: z.enum(["light", "dark"]).meta({ control: "radio" }),
    unused: z.string().meta({ control: "not-a-control" }),
  });
  const spec = zodToSpec(schema);

  it("lets .meta({ control }) override the derived control type", () => {
    expect(field(spec, "bio").type).toBe("textarea");
    expect(field(spec, "theme").type).toBe("radio");
  });

  it("keeps enum options even when the control is overridden to radio", () => {
    expect(field(spec, "theme").options).toEqual([
      { value: "light", label: "light" },
      { value: "dark", label: "dark" },
    ]);
  });

  it("carries label / placeholder / width / section / order from meta", () => {
    const f = field(spec, "bio");
    expect(f.label).toBe("About you");
    expect(f.placeholder).toBe("A few words");
    expect(f.width).toBe("full");
    expect(f.section).toBe("profile");
    expect(f.order).toBe(2);
  });

  it("ignores an invalid meta control and falls back to the derived default", () => {
    expect(field(spec, "unused").type).toBe("text");
  });
});

describe("zodToSpec — overrides + sections", () => {
  const schema = z.object({
    plan: z.enum(["free", "pro"]),
    note: z.string().min(3),
  });
  const spec = zodToSpec(schema, {
    overrides: {
      plan: { type: "radio", label: "Choose a plan", section: "billing" },
      note: { type: "textarea", validation: { maxLength: 500 } },
    },
    sections: [{ id: "billing", title: "Billing" }],
  });

  it("applies per-field overrides over the derived field", () => {
    expect(field(spec, "plan").type).toBe("radio");
    expect(field(spec, "plan").label).toBe("Choose a plan");
    expect(field(spec, "plan").section).toBe("billing");
  });

  it("shallow-merges a partial validation override with derived hints", () => {
    // derived minLength (3) preserved; overridden maxLength (500) added.
    expect(field(spec, "note").validation).toMatchObject({
      required: true,
      minLength: 3,
      maxLength: 500,
    });
  });

  it("carries sections onto the spec", () => {
    expect(spec.sections).toEqual([{ id: "billing", title: "Billing" }]);
  });
});

describe("zodToSpec — unsupported types", () => {
  it("throws on a non-object schema", () => {
    expect(() => zodToSpec(z.string() as never)).toThrow(/expected a Zod object/);
  });

  it("fails loudly (default) on an unmapped field type, naming the field", () => {
    const schema = z.object({ payload: z.record(z.string(), z.unknown()) });
    expect(() => zodToSpec(schema)).toThrow(/payload/);
  });

  it('degrades to text when { onUnknown: "text" }', () => {
    const schema = z.object({ payload: z.record(z.string(), z.unknown()) });
    const spec = zodToSpec(schema, { onUnknown: "text" });
    expect(field(spec, "payload").type).toBe("text");
  });
});

describe("zodToSpec — schema stays the validation source of truth", () => {
  it("the same schema drives both the spec and the engine resolver", async () => {
    const schema = z.object({
      email: z.string().email("Enter a valid email"),
      age: z.coerce.number().min(18, "Must be 18+"),
    });
    const spec = zodToSpec(schema);
    expect(field(spec, "email").type).toBe("text");
    expect(field(spec, "age").type).toBe("number");

    const resolve = standardSchemaResolver(schema);
    const bad = await resolve({ email: "nope", age: 5 } as never);
    expect(bad.errors.email).toBe("Enter a valid email");
    expect(bad.errors.age).toBe("Must be 18+");
  });
});
