import { afterEach, describe, expect, it, vi } from "vitest";
import { z } from "zod";

import {
  createFormStore,
  standardSchemaResolver,
  type Resolver,
} from "../../../src/core/orchestration/forms";

const flush = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

afterEach(() => {
  vi.useRealTimers();
});

describe("standardSchemaResolver (zod reference adapter)", () => {
  const schema = z.object({
    email: z.string().email("Enter a valid email"),
    age: z.coerce.number().min(18, "Must be 18+"),
  });

  it("maps field issues to name-addressed errors and passes valid input", async () => {
    const resolve = standardSchemaResolver(schema);

    const bad = await resolve({ email: "nope", age: 5 } as never);
    expect(bad.errors.email).toBe("Enter a valid email");
    expect(bad.errors.age).toBe("Must be 18+");

    const ok = await resolve({ email: "a@b.co", age: 20 } as never);
    expect(ok.errors).toEqual({});
  });

  it("returns schema-sanitized output values (coercion) when valid", async () => {
    const resolve = standardSchemaResolver(schema);
    const ok = await resolve({ email: "a@b.co", age: "42" } as never);
    expect(ok.values).toEqual({ email: "a@b.co", age: 42 });
    expect(typeof ok.values.age).toBe("number");
  });
});

describe("form validation — timing modes", () => {
  const schema = z.object({ email: z.string().email("bad email") });

  function makeStore(mode: "onChange" | "onBlur" | "onSubmit" | "all") {
    return createFormStore<{ email: string }>({
      defaultValues: { email: "" },
      resolver: standardSchemaResolver(schema) as unknown as Resolver<{ email: string }>,
      mode,
    });
  }

  it("onSubmit mode: no field errors on change/blur before submit", async () => {
    const store = makeStore("onSubmit");
    store.setValue("email", "bad");
    store.setTouched("email", true);
    await flush();
    expect(store.getError("email")).toBeUndefined();
    expect(store.getFormState().isValid).toBe(true); // unknown until validated
  });

  it("onChange mode: validates on every change", async () => {
    const store = makeStore("onChange");
    store.setValue("email", "bad");
    await flush();
    expect(store.getError("email")).toBe("bad email");
    expect(store.getFormState().isValid).toBe(false);

    store.setValue("email", "good@x.co");
    await flush();
    expect(store.getError("email")).toBeUndefined();
    expect(store.getFormState().isValid).toBe(true);
  });

  it("onBlur mode: validates on blur, not on change", async () => {
    const store = makeStore("onBlur");
    store.setValue("email", "bad");
    await flush();
    expect(store.getError("email")).toBeUndefined();

    store.setTouched("email", true);
    await flush();
    expect(store.getError("email")).toBe("bad email");
  });
});

describe("form validation — reValidate after first error", () => {
  const schema = z.object({ email: z.string().email("bad email") });

  it("re-validates on change once a field is errored (default reValidateMode)", async () => {
    const store = createFormStore<{ email: string }>({
      defaultValues: { email: "" },
      resolver: standardSchemaResolver(schema) as unknown as Resolver<{ email: string }>,
      mode: "onBlur",
      reValidateMode: "onChange",
    });

    // first error only appears on blur
    store.setValue("email", "bad");
    await flush();
    expect(store.getError("email")).toBeUndefined();
    store.setTouched("email", true);
    await flush();
    expect(store.getError("email")).toBe("bad email");

    // now that it's errored, a change re-validates immediately (clears it)
    store.setValue("email", "ok@x.co");
    await flush();
    expect(store.getError("email")).toBeUndefined();
  });
});

describe("form validation — cross-field rules", () => {
  const schema = z
    .object({ password: z.string().min(8, "Too short"), confirm: z.string() })
    .refine((v) => v.password === v.confirm, {
      path: ["confirm"],
      message: "Passwords must match",
    });

  it("reports a cross-field mismatch on the addressed field", async () => {
    const store = createFormStore<{ password: string; confirm: string }>({
      defaultValues: { password: "", confirm: "" },
      resolver: standardSchemaResolver(schema) as never,
      mode: "onChange",
    });

    store.setValue("password", "longenough");
    store.setValue("confirm", "different");
    await flush();
    expect(store.getError("confirm")).toBe("Passwords must match");

    store.setValue("confirm", "longenough");
    await flush();
    expect(store.getError("confirm")).toBeUndefined();
  });
});

describe("form validation — async debounce", () => {
  it("debounces async validation and reports isValidating", async () => {
    vi.useFakeTimers();
    const calls: string[] = [];
    const resolver: Resolver<{ handle: string }> = async (values) => {
      calls.push(values.handle);
      return values.handle === "taken"
        ? { values, errors: { handle: "Handle is taken" } }
        : { values, errors: {} };
    };
    const store = createFormStore<{ handle: string }>({
      defaultValues: { handle: "" },
      resolver,
      mode: "onChange",
      asyncDebounceMs: 300,
    });

    store.setValue("handle", "t");
    store.setValue("handle", "ta");
    store.setValue("handle", "taken");
    expect(store.getFormState().isValidating).toBe(true);
    expect(calls).toEqual([]); // still debouncing

    await vi.advanceTimersByTimeAsync(300);
    expect(calls).toEqual(["taken"]); // only the final value validated once
    expect(store.getError("handle")).toBe("Handle is taken");
    expect(store.getFormState().isValidating).toBe(false);
  });
});
