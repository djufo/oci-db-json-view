import { describe, expect, it } from "vitest";

import { createFormStore } from "../../../src/core/orchestration/forms";

interface Login {
  email: string;
  password: string;
  remember: boolean;
}

describe("createFormStore", () => {
  it("seeds values from defaultValues and reports them via getValues", () => {
    const store = createFormStore<Login>({
      defaultValues: { email: "a@b.co", password: "", remember: false },
    });
    expect(store.getValue("email")).toBe("a@b.co");
    expect(store.getValues()).toEqual({ email: "a@b.co", password: "", remember: false });
  });

  it("keeps the getValues snapshot stable until values change", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "a@b.co", password: "", remember: false } });

    const before = store.getValues();
    expect(store.getValues()).toBe(before);

    store.setValue("email", "next@x.co");
    expect(store.getValues()).not.toBe(before);
  });

  it("round-trips register / unregister", () => {
    const store = createFormStore<Login>();
    expect(store.isRegistered("email")).toBe(false);

    store.register("email", { defaultValue: "seed@x.co" });
    expect(store.isRegistered("email")).toBe(true);
    expect(store.getValue("email")).toBe("seed@x.co");
    expect(store.getRegisteredNames()).toEqual(["email"]);

    store.unregister("email");
    expect(store.isRegistered("email")).toBe(false);
    expect(store.getRegisteredNames()).toEqual([]);
  });

  it("removes an unregistered value from a previously read getValues snapshot", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "a@b.co", password: "secret", remember: false } });

    const before = store.getValues();
    store.unregister("password");

    expect(before).toEqual({ email: "a@b.co", password: "secret", remember: false });
    expect(store.getValues()).toEqual({ email: "a@b.co", remember: false });
  });

  it("tracks dirty per field and isDirty at form level", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "", password: "", remember: false } });
    expect(store.getFormState().isDirty).toBe(false);

    store.setValue("email", "typed@x.co");
    expect(store.getFieldState("email").dirty).toBe(true);
    expect(store.getFieldState("password").dirty).toBe(false);
    expect(store.getFormState().isDirty).toBe(true);
  });

  it("reset restores initial values and clears touched/visited/dirty", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "start@x.co", password: "", remember: false } });
    store.setValue("email", "changed@x.co");
    store.setTouched("email", true);
    store.setVisited("email", true);

    store.reset();

    expect(store.getValue("email")).toBe("start@x.co");
    const email = store.getFieldState("email");
    expect(email.value).toBe("start@x.co");
    expect(email.dirty).toBe(false);
    expect(email.touched).toBe(false);
    expect(email.visited).toBe(false);
    expect(store.getFormState().isDirty).toBe(false);
  });

  it("reset(nextValues) adopts new initial values", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "old@x.co", password: "", remember: false } });
    store.reset({ email: "new@x.co" });
    expect(store.getValue("email")).toBe("new@x.co");
    expect(store.getFieldState("email").dirty).toBe(false);
  });

  it("owns submit flags without running a submit lifecycle", () => {
    const store = createFormStore<Login>();
    expect(store.getFormState().isSubmitting).toBe(false);
    store.setSubmitting(true);
    expect(store.getFormState().isSubmitting).toBe(true);
    store.countSubmit();
    store.countSubmit();
    expect(store.getFormState().submitCount).toBe(2);
  });
});

describe("createFormStore — selector bail-out (perf contract)", () => {
  it("leaves a sibling field's snapshot reference untouched on edit", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "", password: "", remember: false } });

    const emailBefore = store.getFieldState("email");
    const passwordBefore = store.getFieldState("password");

    store.setValue("password", "hunter2");

    expect(store.getFieldState("email")).toBe(emailBefore); // unchanged ref
    expect(store.getFieldState("password")).not.toBe(passwordBefore); // new ref
  });

  it("models useSyncExternalStore render counts: editing one field re-renders only that subscriber", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "", password: "", remember: false } });

    // Mirror React's useSyncExternalStore bail-out: a subscriber only "renders"
    // when its selected snapshot reference changes under Object.is.
    function trackField(name: keyof Login & string) {
      let renders = 0;
      let last = store.getFieldState(name);
      const unsubscribe = store.subscribe(() => {
        const next = store.getFieldState(name);
        if (!Object.is(next, last)) {
          last = next;
          renders += 1;
        }
      });
      return { renders: () => renders, unsubscribe };
    }

    const email = trackField("email");
    const password = trackField("password");

    store.setValue("password", "a");
    store.setValue("password", "ab");

    expect(password.renders()).toBe(2);
    expect(email.renders()).toBe(0); // sibling never re-rendered

    email.unsubscribe();
    password.unsubscribe();
  });

  it("does not notify when a set is a no-op for the snapshot", () => {
    const store = createFormStore<Login>({ defaultValues: { email: "", password: "", remember: false } });
    let notifications = 0;
    store.subscribe(() => {
      notifications += 1;
    });
    store.setTouched("email", false); // already false → no change
    expect(notifications).toBe(0);

    store.setTouched("email", true); // real change
    expect(notifications).toBe(1);
  });
});
