import { describe, expect, it } from "vitest";
import { z } from "zod";

import {
  createFormStore,
  standardSchemaResolver,
  type Resolver,
} from "../../../src/core/orchestration/forms";

const flush = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

interface LineItem {
  description: string;
  qty: number;
  price: number;
}

interface Order {
  lineItems: LineItem[];
  customer: {
    name: string;
  };
}

const orderDefaults: Order = {
  customer: { name: "Ada" },
  lineItems: [
    { description: "Design", qty: 1, price: 125 },
    { description: "Build", qty: 2, price: 250 },
  ],
};

const orderSchema = z.object({
  customer: z.object({ name: z.string().min(1, "Customer is required") }),
  lineItems: z
    .array(
      z.object({
        description: z.string().min(1, "Description is required"),
        qty: z.coerce.number().min(1, "Qty must be at least 1"),
        price: z.coerce.number().min(0, "Price cannot be negative"),
      }),
    )
    .min(1, "Add at least one line item"),
});

describe("form nested paths", () => {
  it("reads and writes dotted and bracket array paths into the submitted object shape", () => {
    const store = createFormStore<Order>({ defaultValues: orderDefaults });

    expect(store.getValue("lineItems[0].qty")).toBe(1);
    expect(store.getValue("customer.name")).toBe("Ada");

    store.setValue("lineItems[0].qty", 3);
    store.setValue("customer.name", "Grace");

    expect(store.getValue("lineItems.0.qty")).toBe(3);
    expect(store.getValues()).toEqual({
      customer: { name: "Grace" },
      lineItems: [
        { description: "Design", qty: 3, price: 125 },
        { description: "Build", qty: 2, price: 250 },
      ],
    });
    expect(store.getFieldState("lineItems[0].qty").dirty).toBe(true);
    expect(store.getFieldState("lineItems.1.qty").dirty).toBe(false);
    expect(store.getFormState().isDirty).toBe(true);
  });

  it("maps nested resolver errors to either bracket or dotted field names", async () => {
    const store = createFormStore<Order>({
      defaultValues: orderDefaults,
      resolver: standardSchemaResolver(orderSchema) as unknown as Resolver<Order>,
      mode: "onChange",
    });

    store.setValue("lineItems[1].qty", 0);
    await flush();

    expect(store.getError("lineItems.1.qty")).toBe("Qty must be at least 1");
    expect(store.getError("lineItems[1].qty")).toBe("Qty must be at least 1");
    expect(store.getFieldState("lineItems[1].qty").error).toBe("Qty must be at least 1");
  });
});

describe("field arrays", () => {
  it("keeps stable row keys across append, insert, remove, move, and replace", () => {
    const store = createFormStore<Order>({ defaultValues: orderDefaults });

    const initial = store.getFieldArrayState("lineItems");
    expect(initial.fields).toHaveLength(2);
    const [firstId, secondId] = initial.fields.map((field) => field.id);

    store.appendFieldArrayItem("lineItems", { description: "QA", qty: 1, price: 50 });
    const appended = store.getFieldArrayState("lineItems");
    expect(appended.fields.map((field) => field.id)).toEqual([firstId, secondId, expect.any(String)]);

    store.insertFieldArrayItem("lineItems", 1, { description: "Plan", qty: 1, price: 75 });
    const inserted = store.getFieldArrayState("lineItems");
    expect(inserted.fields[0].id).toBe(firstId);
    expect(inserted.fields[2].id).toBe(secondId);

    store.moveFieldArrayItem("lineItems", 2, 0);
    const moved = store.getFieldArrayState("lineItems");
    expect(moved.fields[0].id).toBe(secondId);
    expect(moved.fields[1].id).toBe(firstId);

    store.removeFieldArrayItem("lineItems", 1);
    const removed = store.getFieldArrayState("lineItems");
    expect(removed.fields.map((field) => field.id)).toEqual([
      secondId,
      inserted.fields[1].id,
      appended.fields[2].id,
    ]);

    store.replaceFieldArrayItems("lineItems", [{ description: "Only", qty: 1, price: 1 }]);
    const replaced = store.getFieldArrayState("lineItems");
    expect(replaced.fields).toHaveLength(1);
    expect(replaced.fields[0].id).not.toBe(secondId);
  });

  it("rebases row touched state and errors when removing a preceding row", () => {
    const store = createFormStore<Order>({ defaultValues: orderDefaults });

    store.setTouched("lineItems.1.qty", true);
    store.setError("lineItems.1.qty", "Bad qty");
    store.removeFieldArrayItem("lineItems", 0);

    expect(store.getFieldState("lineItems.0.qty").touched).toBe(true);
    expect(store.getError("lineItems.0.qty")).toBe("Bad qty");
    expect(store.getError("lineItems.1.qty")).toBeUndefined();
  });

  it("does not delete array values when an indexed child field unregisters", () => {
    const store = createFormStore<Order>({ defaultValues: orderDefaults });
    store.register("lineItems.1.qty");

    store.unregister("lineItems.1.qty");

    expect(store.isRegistered("lineItems.1.qty")).toBe(false);
    expect(store.getValue("lineItems.1.qty")).toBe(2);
    expect(store.getValues().lineItems[1]).toEqual({ description: "Build", qty: 2, price: 250 });
  });

  it("surfaces array-level validation errors on the array field", async () => {
    const store = createFormStore<Order>({
      defaultValues: { ...orderDefaults, lineItems: [{ description: "Only", qty: 1, price: 1 }] },
      resolver: standardSchemaResolver(orderSchema) as unknown as Resolver<Order>,
      mode: "onChange",
    });

    store.removeFieldArrayItem("lineItems", 0, { shouldValidate: true });
    await flush();

    expect(store.getError("lineItems")).toBe("Add at least one line item");
    expect(store.getFieldArrayState("lineItems").error).toBe("Add at least one line item");
  });

  it("does not change unrelated row snapshots when one row field mutates", () => {
    const store = createFormStore<Order>({ defaultValues: orderDefaults });
    const rowZero = store.getFieldState("lineItems.0.qty");
    const rowOne = store.getFieldState("lineItems.1.qty");
    const array = store.getFieldArrayState("lineItems");

    store.setValue("lineItems.1.qty", 4);

    expect(store.getFieldState("lineItems.0.qty")).toBe(rowZero);
    expect(store.getFieldState("lineItems.1.qty")).not.toBe(rowOne);
    expect(store.getFieldArrayState("lineItems")).toBe(array);
  });
});
