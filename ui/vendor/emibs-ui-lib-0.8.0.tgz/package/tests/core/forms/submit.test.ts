import { describe, expect, it, vi } from "vitest";
import { z } from "zod";

import {
  createFormStore,
  FormSubmissionError,
  standardSchemaResolver,
  type Resolver,
} from "../../../src/core/orchestration/forms";

const flush = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

interface Signup {
  email: string;
  age: number;
}

const schema = z.object({
  email: z.string().email("Enter a valid email"),
  age: z.coerce.number().min(18, "Must be 18+"),
});

function makeStore() {
  return createFormStore<Signup>({
    defaultValues: { email: "", age: 0 },
    resolver: standardSchemaResolver(schema) as unknown as Resolver<Signup>,
    mode: "onSubmit",
  });
}

describe("handleSubmit — lifecycle", () => {
  it("blocks submit when invalid, populates errors, and does not call onValid", async () => {
    const store = makeStore();
    const onValid = vi.fn();
    store.setValue("email", "nope");
    store.setValue("age", 5 as never);

    await store.handleSubmit(onValid)();

    expect(onValid).not.toHaveBeenCalled();
    expect(store.getError("email")).toBe("Enter a valid email");
    expect(store.getFormState().isValid).toBe(false);
    expect(store.getFormState().isSubmitting).toBe(false);
    expect(store.getFormState().submitCount).toBe(1);
  });

  it("focuses the first errored field after a blocked submit", async () => {
    const store = makeStore();
    store.setValue("email", "nope"); // email is first-registered → first error
    store.setValue("age", 5 as never);

    await store.handleSubmit(vi.fn())();
    expect(store.getPendingFocus()).toBe("email");
  });

  it("calls onValid with schema-sanitized values on a valid submit", async () => {
    const store = makeStore();
    const onValid = vi.fn();
    store.setValue("email", "a@b.co");
    store.setValue("age", "42" as never); // string coerced by the schema

    await store.handleSubmit(onValid)();

    expect(onValid).toHaveBeenCalledTimes(1);
    expect(onValid).toHaveBeenCalledWith({ email: "a@b.co", age: 42 });
    expect(store.getFormState().isSubmitting).toBe(false);
  });

  it("toggles isSubmitting across an async onValid", async () => {
    const store = makeStore();
    store.setValue("email", "a@b.co");
    store.setValue("age", 20 as never);

    let seenSubmitting = false;
    const submit = store.handleSubmit(async () => {
      seenSubmitting = store.getFormState().isSubmitting;
      await flush();
    });
    await submit();
    expect(seenSubmitting).toBe(true);
    expect(store.getFormState().isSubmitting).toBe(false);
  });
});

describe("handleSubmit — server-error reconciliation", () => {
  it("maps a simulated 422 onto the right fields, surfaces a form error, and focuses", async () => {
    const store = makeStore();
    store.setValue("email", "a@b.co");
    store.setValue("age", 20 as never);

    await store.handleSubmit(async () => {
      throw new FormSubmissionError({
        formError: "Could not create account.",
        fieldErrors: { email: "Email already registered" },
      });
    })();

    expect(store.getError("email")).toBe("Email already registered");
    expect(store.getFormState().submitError).toBe("Could not create account.");
    expect(store.getPendingFocus()).toBe("email");
    expect(store.getFormState().isSubmitting).toBe(false);
  });

  it("clears reconciled server errors on the next successful submit", async () => {
    const store = makeStore();
    store.setValue("email", "a@b.co");
    store.setValue("age", 20 as never);

    await store.handleSubmit(async () => {
      throw new FormSubmissionError({ fieldErrors: { email: "taken" } });
    })();
    expect(store.getError("email")).toBe("taken");

    await store.handleSubmit(async () => {
      /* success */
    })();
    expect(store.getError("email")).toBeUndefined();
    expect(store.getFormState().submitError).toBeUndefined();
  });

  it("accepts a plain thrown object with fieldErrors/formError", async () => {
    const store = makeStore();
    store.setValue("email", "a@b.co");
    store.setValue("age", 20 as never);

    await store.handleSubmit(async () => {
      throw { fieldErrors: { age: "Underage per records" }, formError: "Rejected" };
    })();
    expect(store.getError("age")).toBe("Underage per records");
    expect(store.getFormState().submitError).toBe("Rejected");
  });
});

describe("imperative APIs", () => {
  it("setError / clearErrors drive per-field and form validity", () => {
    const store = makeStore();
    store.setError("email", "manual");
    expect(store.getError("email")).toBe("manual");
    expect(store.getFieldState("email").error).toBe("manual");
    expect(store.getFormState().isValid).toBe(false);

    store.clearErrors("email");
    expect(store.getError("email")).toBeUndefined();
    expect(store.getFormState().isValid).toBe(true);
  });

  it("reset restores initial state and clears submitCount + errors + submitError", async () => {
    const store = makeStore();
    store.setValue("email", "nope");
    store.setValue("age", 5 as never);
    await store.handleSubmit(vi.fn())(); // fails → error + submitCount=1
    store.setSubmitError("boom");
    expect(store.getFormState().submitCount).toBe(1);

    store.reset();

    expect(store.getValue("email")).toBe("");
    expect(store.getError("email")).toBeUndefined();
    expect(store.getFormState().submitError).toBeUndefined();
    expect(store.getFormState().submitCount).toBe(0);
    expect(store.getFormState().isValid).toBe(true);
    expect(store.getPendingFocus()).toBeNull();
  });

  it("reset(nextValues) adopts new initial values and stays clean", () => {
    const store = makeStore();
    store.reset({ email: "seed@x.co" });
    expect(store.getValue("email")).toBe("seed@x.co");
    expect(store.getFieldState("email").dirty).toBe(false);
  });
});
