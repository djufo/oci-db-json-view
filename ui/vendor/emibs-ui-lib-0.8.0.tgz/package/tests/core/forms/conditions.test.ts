import { describe, expect, it } from "vitest";
import { z } from "zod";

import {
  createFormStore,
  standardSchemaResolver,
  evaluateCondition,
  type FieldRules,
  type Resolver,
} from "../../../src/core/orchestration/forms";

const flush = () => new Promise<void>((resolve) => setTimeout(resolve, 0));

describe("evaluateCondition — leaf + group operators", () => {
  const values = { a: 3, b: "hello", c: true, tags: ["x", "y"] };

  it("evaluates comparison leaves", () => {
    expect(evaluateCondition({ field: "a", op: "eq", value: 3 }, values)).toBe(true);
    expect(evaluateCondition({ field: "a", op: "gt", value: 2 }, values)).toBe(true);
    expect(evaluateCondition({ field: "a", op: "lt", value: 2 }, values)).toBe(false);
    expect(evaluateCondition({ field: "c", op: "truthy" }, values)).toBe(true);
    expect(evaluateCondition({ field: "a", op: "in", value: [1, 3, 5] }, values)).toBe(true);
    expect(evaluateCondition({ field: "b", op: "contains", value: "ell" }, values)).toBe(true);
    expect(evaluateCondition({ field: "tags", op: "contains", value: "y" }, values)).toBe(true);
  });

  it("evaluates all/any/not groups", () => {
    expect(
      evaluateCondition(
        { all: [{ field: "a", op: "gt", value: 2 }, { field: "c", op: "truthy" }] },
        values,
      ),
    ).toBe(true);
    expect(
      evaluateCondition(
        { any: [{ field: "a", op: "lt", value: 0 }, { field: "c", op: "truthy" }] },
        values,
      ),
    ).toBe(true);
    expect(evaluateCondition({ not: { field: "c", op: "truthy" } }, values)).toBe(false);
  });

  it("honors the boolean and function escape hatches", () => {
    expect(evaluateCondition(true, values)).toBe(true);
    expect(evaluateCondition((v: typeof values) => v.a === 3, values)).toBe(true);
  });
});

describe("form conditions — effective field status", () => {
  interface Shipping {
    sameAsBilling: boolean;
    shippingAddress: string;
    country: string;
    state: string;
  }

  const rules: FieldRules<Shipping> = {
    // a boolean toggles another field's visibility
    shippingAddress: { visible: { field: "sameAsBilling", op: "falsy" } },
    // a dependent select drives required-ness of another field
    state: { required: { field: "country", op: "eq", value: "US" } },
  };

  it("a boolean toggles a dependent field's visibility (minimal status churn)", () => {
    const store = createFormStore<Shipping>({
      defaultValues: { sameAsBilling: false, shippingAddress: "", country: "CA", state: "" },
      rules,
    });

    const before = store.getFieldStatus("shippingAddress");
    expect(before.visible).toBe(true);
    // editing an unrelated field leaves the status reference intact
    store.setValue("country", "US");
    expect(store.getFieldStatus("shippingAddress")).toBe(before);

    store.setValue("sameAsBilling", true);
    const after = store.getFieldStatus("shippingAddress");
    expect(after.visible).toBe(false);
    expect(after).not.toBe(before);
  });

  it("a dependent select narrows another field's required status", () => {
    const store = createFormStore<Shipping>({
      defaultValues: { sameAsBilling: false, shippingAddress: "", country: "CA", state: "" },
      rules,
    });
    expect(store.getFieldStatus("state").required).toBe(false);
    store.setValue("country", "US");
    expect(store.getFieldStatus("state").required).toBe(true);
  });

  it("a field with no rule reports the default status by shared reference", () => {
    const store = createFormStore<Shipping>({ rules });
    const s1 = store.getFieldStatus("sameAsBilling");
    const s2 = store.getFieldStatus("country");
    expect(s1).toEqual({ visible: true, disabled: false, required: false });
    expect(s1).toBe(s2); // DEFAULT_FIELD_STATUS shared
  });
});

describe("form computed / derived fields", () => {
  interface Order {
    qty: number;
    price: number;
    total: number;
  }

  const rules: FieldRules<Order> = {
    total: { compute: (v) => v.qty * v.price, deps: ["qty", "price"] },
  };

  it("seeds the computed value at construction (non-dirty)", () => {
    const store = createFormStore<Order>({
      defaultValues: { qty: 2, price: 10, total: 0 },
      rules,
    });
    expect(store.getValue("total")).toBe(20);
    expect(store.getFieldState("total").dirty).toBe(false);
  });

  it("recomputes on dependency change", () => {
    const store = createFormStore<Order>({
      defaultValues: { qty: 2, price: 10, total: 0 },
      rules,
    });
    store.setValue("qty", 5);
    expect(store.getValue("total")).toBe(50);
    store.setValue("price", 3);
    expect(store.getValue("total")).toBe(15);
  });

  it("keeps computed re-derivation non-dirty after reset", () => {
    const store = createFormStore<Order>({
      defaultValues: { qty: 2, price: 10, total: 0 },
      rules,
    });
    store.setValue("qty", 9);
    expect(store.getValue("total")).toBe(90);
    store.reset({ qty: 4, price: 5 });
    expect(store.getValue("total")).toBe(20);
    expect(store.getFieldState("total").dirty).toBe(false);
  });

  it("settles chained computed fields", () => {
    interface Chain {
      base: number;
      doubled: number;
      plusOne: number;
    }
    const store = createFormStore<Chain>({
      defaultValues: { base: 3, doubled: 0, plusOne: 0 },
      rules: {
        doubled: { compute: (v) => v.base * 2 },
        plusOne: { compute: (v) => v.doubled + 1 },
      } as FieldRules<Chain>,
    });
    expect(store.getValue("doubled")).toBe(6);
    expect(store.getValue("plusOne")).toBe(7);
    store.setValue("base", 10);
    expect(store.getValue("doubled")).toBe(20);
    expect(store.getValue("plusOne")).toBe(21);
  });
});

describe("hidden/disabled fields skip validation + submit values", () => {
  interface Account {
    kind: "person" | "company";
    companyName: string;
  }

  const schema = z.object({
    kind: z.enum(["person", "company"]),
    companyName: z.string().min(1, "Company name is required"),
  });

  function makeStore() {
    return createFormStore<Account>({
      defaultValues: { kind: "person", companyName: "" },
      resolver: standardSchemaResolver(schema) as unknown as Resolver<Account>,
      mode: "onChange",
      rules: {
        // companyName only matters for companies
        companyName: { visible: { field: "kind", op: "eq", value: "company" } },
      },
    });
  }

  it("does not surface an error for a hidden field", async () => {
    const store = makeStore();
    expect(await store.validate()).toBe(true); // companyName hidden → not blocking
    expect(store.getError("companyName")).toBeUndefined();
  });

  it("validates the field once it becomes visible", async () => {
    const store = makeStore();
    store.setValue("kind", "company");
    expect(await store.validate()).toBe(false);
    expect(store.getError("companyName")).toBe("Company name is required");
  });

  it("clears a field's error when it goes hidden", async () => {
    const store = makeStore();
    store.setValue("kind", "company");
    await store.validate();
    expect(store.getError("companyName")).toBe("Company name is required");
    store.setValue("kind", "person");
    await flush();
    expect(store.getError("companyName")).toBeUndefined();
  });

  it("excludes hidden fields from submit values", async () => {
    const store = makeStore();
    let received: Partial<Account> | null = null;
    await store.handleSubmit((values) => {
      received = values;
    })();
    expect(received).toEqual({ kind: "person" });
    expect(store.getSubmitValues()).toEqual({ kind: "person" });
  });

  it("includes the field in submit values once visible", async () => {
    const store = makeStore();
    store.setValue("kind", "company");
    store.setValue("companyName", "Acme");
    let received: Partial<Account> | null = null;
    await store.handleSubmit((values) => {
      received = values;
    })();
    expect(received).toEqual({ kind: "company", companyName: "Acme" });
  });
});
