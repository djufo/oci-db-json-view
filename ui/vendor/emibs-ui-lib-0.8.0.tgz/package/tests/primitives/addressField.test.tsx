// @vitest-environment happy-dom
import { act, type ReactElement } from "react";
import { createRoot, type Root } from "react-dom/client";
import { afterEach, describe, expect, it, vi } from "vitest";
import { AddressField } from "../../src/components/data/AddressField";
import { GeoCoordinatePicker } from "../../src/components/data/GeoCoordinatePicker";
import type { AddressMapAdapter, AddressValue, MapAdapterViewProps } from "../../src/components/data/addressTypes";

(globalThis as { IS_REACT_ACT_ENVIRONMENT?: boolean }).IS_REACT_ACT_ENVIRONMENT = true;
const value: AddressValue = { street: "Sample street", number: "1", city: "Vilnius", postcode: "00100", countryCode: "LT", latitude: 54.6, longitude: 25.2 };
let root: Root;
let container: HTMLDivElement;
async function mount(element: ReactElement) {
  container = document.createElement("div");
  document.body.append(container);
  root = createRoot(container);
  await act(async () => root.render(element));
}
afterEach(async () => {
  if (root) await act(async () => root.unmount());
  container?.remove();
});
const input = (label: string) => {
  const el = [...container.querySelectorAll("label")].find(el => el.textContent === label)!;
  expect(el, `Missing field: ${label}`).toBeTruthy();
  return document.getElementById(el.htmlFor) as HTMLInputElement;
};
async function change(label: string, value: string) {
  const el = input(label);
  Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value")!.set!.call(el, value);
  await act(async () => el.dispatchEvent(new Event("input", { bubbles: true })));
}
async function click(text: string) {
  const button = [...container.querySelectorAll("button")].find(el => el.textContent === text)!;
  expect(button).toBeTruthy();
  await act(async () => button.click());
}
function deferred<T>() {
  let resolve!: (value: T) => void;
  const promise = new Promise<T>(r => { resolve = r; });
  return { promise, resolve };
}
let view: MapAdapterViewProps;
const adapter: AddressMapAdapter = {
  View: props => { view = props; return <div>Adapter map</div>; },
};

describe("AddressField", () => {
  it("emits complete manual values without a map or persistence", async () => {
    const onChange = vi.fn();
    await mount(<AddressField value={value} onChange={onChange} />);
    await change("Street", "New street");
    expect(onChange).toHaveBeenLastCalledWith({ ...value, street: "New street" });
    await change("Longitude", "150");
    expect(onChange).toHaveBeenLastCalledWith({ ...value, longitude: 150 });
    await click("Show on map");
    expect(container.textContent).toContain("Map unavailable");
    expect(container.querySelector("button")?.getAttribute("aria-label")).toBe("Map shown — hide map");
  });

  it("locks owned fields while allowing selection of an existing read-only address", async () => {
    const existing = { ...value, id: 7, canEdit: false };
    const onChange = vi.fn();
    const search = vi.fn().mockResolvedValue([existing]);
    await mount(<AddressField value={{ ...value, canEdit: false }} onChange={onChange} searchAddresses={search} />);
    expect(input("Street").readOnly).toBe(true);
    expect(input("Latitude").readOnly).toBe(true);
    await click("Search addresses");
    const result = [...container.querySelectorAll("button")].find(el => el.textContent?.includes("Read-only"))!;
    await act(async () => result.click());
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenLastCalledWith(existing);
  });

  it("aborts stale searches on query change, readOnly and unmount", async () => {
    const pending = deferred<AddressValue[]>();
    let signal!: AbortSignal;
    const search = vi.fn((_query: string, s: AbortSignal) => { signal = s; return pending.promise; });
    const onChange = vi.fn();
    await mount(<AddressField value={value} onChange={onChange} searchAddresses={search} />);
    await click("Search addresses");
    const first = signal;
    await change("Find existing address", "new");
    expect(first.aborted).toBe(true);
    await act(async () => pending.resolve([{ ...value, id: 99 }]));
    expect(container.textContent).not.toContain("Read-only");
    expect(container.querySelectorAll("button")).toHaveLength(2);
    await click("Search addresses");
    await act(async () => root.render(<AddressField value={value} onChange={onChange} searchAddresses={search} readOnly />));
    expect(signal.aborted).toBe(true);
    expect(input("Street").readOnly).toBe(true);
    expect(container.textContent).not.toContain("Search addresses");
    await act(async () => root.render(<AddressField value={value} onChange={onChange} searchAddresses={search} />));
    await click("Search addresses");
    await act(async () => root.unmount());
    expect(signal.aborted).toBe(true);
  });

  it("honors explicit edit permission, country props and readOnly precedence", async () => {
    const onChange = vi.fn();
    const address = { ...value, countryCode: "NZ", canEdit: false };
    await mount(<AddressField value={address} onChange={onChange} canEdit countryLabel="New Zealand" />);
    expect(input("Street").readOnly).toBe(false);
    expect(input("Country").value).toBe("New Zealand");
    expect(input("Country").readOnly).toBe(true);
    await act(async () => root.render(<AddressField value={address} onChange={onChange} canEdit readOnly />));
    await change("Street", "Forbidden");
    await change("Latitude", "10");
    expect(input("Street").readOnly).toBe(true);
    expect(onChange).not.toHaveBeenCalled();
  });

  it("bounds search queries and displayed results", async () => {
    const search = vi.fn().mockResolvedValue(Array.from({ length: 60 }, (_, id) => ({ ...value, id })));
    await mount(<AddressField value={value} onChange={vi.fn()} searchAddresses={search} />);
    await change("Find existing address", "a".repeat(200));
    await click("Search addresses");
    expect(search.mock.calls[0][0]).toHaveLength(128);
    expect(container.querySelectorAll("button")).toHaveLength(52);
  });

  it.each([null, { latitude: 91, longitude: 2 }, { latitude: 1, longitude: Infinity }])("keeps manual entry when geocoding returns %j", async point => {
    const onChange = vi.fn();
    await mount(<AddressField value={value} onChange={onChange} mapAdapter={{ ...adapter, geocode: async () => point }} />);
    await click("Locate address");
    expect(onChange).not.toHaveBeenCalled();
    expect(container.querySelector('[role="alert"]')?.textContent).toContain("Location not found");
    expect(input("Latitude").readOnly).toBe(false);
  });

  it("does not expose geocoder failure details", async () => {
    await mount(<AddressField value={value} onChange={vi.fn()} mapAdapter={{ ...adapter, geocode: async () => { throw new Error("private provider detail"); } }} />);
    await click("Locate address");
    expect(container.querySelector('[role="alert"]')?.textContent).toBe("Address location unavailable. Enter coordinates manually.");
    expect(container.textContent).not.toContain("private provider detail");
  });

  it("cancels a replaced search callback and ignores its later result", async () => {
    const pending = deferred<AddressValue[]>();
    let signal!: AbortSignal;
    const search = (_query: string, s: AbortSignal) => { signal = s; return pending.promise; };
    await mount(<AddressField value={value} onChange={vi.fn()} searchAddresses={search} />);
    await click("Search addresses");
    await act(async () => root.render(<AddressField value={value} onChange={vi.fn()} searchAddresses={async () => []} />));
    expect(signal.aborted).toBe(true);
    await act(async () => pending.resolve([{ ...value, street: "Stale result" }]));
    expect(container.textContent).not.toContain("Stale result");
  });

  it("shows safe search failure text", async () => {
    await mount(<AddressField value={value} onChange={vi.fn()} searchAddresses={async () => { throw new Error("private provider detail"); }} />);
    await click("Search addresses");
    expect(container.querySelector('[role="alert"]')?.textContent).toBe("Address search unavailable. Try again.");
    expect(container.textContent).not.toContain("private provider detail");
  });

  it("geocodes through the optional adapter and rejects late results after locking", async () => {
    const pending = deferred<{ latitude: number; longitude: number } | null>();
    const geocode = vi.fn().mockResolvedValueOnce({ latitude: 10, longitude: 150 }).mockImplementationOnce(() => pending.promise);
    const mapAdapter = { ...adapter, geocode };
    const onChange = vi.fn();
    await mount(<AddressField value={value} onChange={onChange} mapAdapter={mapAdapter} />);
    await click("Locate address");
    expect(geocode.mock.calls[0][0]).toBe("Sample street, 1, Vilnius, 00100, LT");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenLastCalledWith({ ...value, latitude: 10, longitude: 150 });
    await click("Locate address");
    const signal = geocode.mock.calls[1][1] as AbortSignal;
    await act(async () => root.render(<AddressField value={value} onChange={onChange} mapAdapter={mapAdapter} canEdit={false} />));
    expect(signal.aborted).toBe(true);
    await act(async () => pending.resolve({ latitude: 1, longitude: 2 }));
    expect(onChange).toHaveBeenCalledTimes(1);
  });
});

describe("GeoCoordinatePicker", () => {
  it("shows/clears the controlled point and allows valid map picks", async () => {
    const onChange = vi.fn();
    await mount(<GeoCoordinatePicker latitude={54} longitude={25} onChange={onChange} mapAdapter={adapter} />);
    await click("Show on map");
    expect(view.point).toEqual({ latitude: 54, longitude: 25 });
    expect(container.querySelector(".ui-map-viewport")).not.toBeNull();
    await act(async () => view.onPick?.({ latitude: -45, longitude: 150 }));
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenLastCalledWith({ latitude: -45, longitude: 150 });
    await act(async () => view.onPick?.({ latitude: NaN, longitude: 25 }));
    await act(async () => view.onPick?.({ latitude: 91, longitude: 25 }));
    await act(async () => view.onPick?.({ latitude: 0, longitude: 181 }));
    expect(onChange).toHaveBeenCalledTimes(1);
    await act(async () => view.onPick?.({ latitude: 0, longitude: -180 }));
    expect(onChange).toHaveBeenLastCalledWith({ latitude: 0, longitude: -180 });
    await act(async () => root.render(<GeoCoordinatePicker latitude={null} longitude={25} onChange={onChange} mapAdapter={adapter} />));
    expect(view.point).toBeNull();
    await change("Longitude", "");
    expect(onChange).toHaveBeenLastCalledWith({ latitude: null, longitude: null });
    await click("Hide map");
    expect(container.textContent).not.toContain("Adapter map");
    expect(container.querySelector("button")?.getAttribute("aria-expanded")).toBe("false");
  });

  it("keeps a map view available in read-only mode with no pick handler", async () => {
    const onChange = vi.fn();
    await mount(<GeoCoordinatePicker latitude={54} longitude={25} onChange={onChange} mapAdapter={adapter} readOnly />);
    await click("Show on map");
    expect(view.readOnly).toBe(true);
    expect(view.onPick).toBeUndefined();
    expect(input("Latitude").readOnly).toBe(true);
    expect(onChange).not.toHaveBeenCalled();
  });

  it("rejects out-of-range manual coordinates", async () => {
    const onChange = vi.fn();
    await mount(<GeoCoordinatePicker latitude={null} longitude={null} onChange={onChange} />);
    await change("Latitude", "91");
    await change("Longitude", "181");
    expect(onChange).not.toHaveBeenCalled();
    await change("Latitude", "-90");
    expect(onChange).toHaveBeenCalledTimes(1);
    expect(onChange).toHaveBeenLastCalledWith({ latitude: -90, longitude: null });
  });
});
