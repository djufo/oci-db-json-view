import { describe, expect, it } from "vitest";
import { isDateWithinRange, isIsoDateString } from "../../src/components/primitives/DateField";

describe("isIsoDateString", () => {
  it("accepts real ISO calendar dates", () => {
    expect(isIsoDateString("2026-07-04")).toBe(true);
    expect(isIsoDateString("2024-02-29")).toBe(true);
  });

  it("rejects malformed strings and impossible dates", () => {
    expect(isIsoDateString("")).toBe(false);
    expect(isIsoDateString("2026-7-4")).toBe(false);
    expect(isIsoDateString("2026/07/04")).toBe(false);
    expect(isIsoDateString("2026-13-01")).toBe(false);
    expect(isIsoDateString("2026-02-30")).toBe(false);
    expect(isIsoDateString("2023-02-29")).toBe(false);
  });
});

describe("isDateWithinRange", () => {
  it("treats missing bounds as open", () => {
    expect(isDateWithinRange("2026-07-04")).toBe(true);
    expect(isDateWithinRange("2026-07-04", "2026-01-01")).toBe(true);
    expect(isDateWithinRange("2026-07-04", undefined, "2026-12-31")).toBe(true);
  });

  it("enforces inclusive min and max bounds", () => {
    expect(isDateWithinRange("2026-01-01", "2026-01-01", "2026-12-31")).toBe(true);
    expect(isDateWithinRange("2026-12-31", "2026-01-01", "2026-12-31")).toBe(true);
    expect(isDateWithinRange("2025-12-31", "2026-01-01", "2026-12-31")).toBe(false);
    expect(isDateWithinRange("2027-01-01", "2026-01-01", "2026-12-31")).toBe(false);
  });

  it("rejects non-ISO values outright", () => {
    expect(isDateWithinRange("not-a-date", "2026-01-01", "2026-12-31")).toBe(false);
  });
});
