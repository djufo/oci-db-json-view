import { describe, expect, it } from "vitest";
import {
  resolveFocusableRadioValue,
  resolveRadioNavValue,
  type RadioGroupOption,
} from "../../src/components/primitives/RadioGroup";

const options: RadioGroupOption[] = [
  { value: "a", label: "A" },
  { value: "b", label: "B", disabled: true },
  { value: "c", label: "C" },
  { value: "d", label: "D" },
];

describe("resolveRadioNavValue", () => {
  it("moves to the next enabled option, skipping disabled ones", () => {
    expect(resolveRadioNavValue(options, "a", "ArrowDown")).toBe("c");
    expect(resolveRadioNavValue(options, "a", "ArrowRight")).toBe("c");
  });

  it("moves to the previous enabled option, skipping disabled ones", () => {
    expect(resolveRadioNavValue(options, "c", "ArrowUp")).toBe("a");
    expect(resolveRadioNavValue(options, "c", "ArrowLeft")).toBe("a");
  });

  it("wraps at both ends across enabled options", () => {
    expect(resolveRadioNavValue(options, "d", "ArrowDown")).toBe("a");
    expect(resolveRadioNavValue(options, "a", "ArrowUp")).toBe("d");
  });

  it("jumps to the first and last enabled option for Home/End", () => {
    expect(resolveRadioNavValue(options, "c", "Home")).toBe("a");
    expect(resolveRadioNavValue(options, "a", "End")).toBe("d");
  });

  it("starts from a sensible edge when nothing is selected", () => {
    expect(resolveRadioNavValue(options, undefined, "ArrowDown")).toBe("a");
    expect(resolveRadioNavValue(options, undefined, "ArrowUp")).toBe("d");
  });

  it("returns null for non-navigation keys or when no option is selectable", () => {
    expect(resolveRadioNavValue(options, "a", "Tab")).toBeNull();
    expect(resolveRadioNavValue([{ value: "x", label: "X", disabled: true }], "x", "ArrowDown")).toBeNull();
  });
});

describe("resolveFocusableRadioValue", () => {
  it("keeps the selected value focusable when it is enabled", () => {
    expect(resolveFocusableRadioValue(options, "c")).toBe("c");
  });

  it("falls back to the first enabled option when selection is missing or disabled", () => {
    expect(resolveFocusableRadioValue(options, undefined)).toBe("a");
    expect(resolveFocusableRadioValue(options, "b")).toBe("a");
  });

  it("returns null when every option is disabled", () => {
    expect(resolveFocusableRadioValue([{ value: "x", label: "X", disabled: true }], undefined)).toBeNull();
  });
});
