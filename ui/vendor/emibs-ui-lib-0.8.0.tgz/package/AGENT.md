# AGENT.md — emibs-ui-lib

> Read [`../../AGENT.md`](../../AGENT.md) first — project rules live there. This file is emibs-ui-lib-specific only.

## Purpose

Hostable React catalog for EMIBS UI framework candidates. It is based on
shadcn-style primitives, tokenized theming, and extracted UI patterns from
workspace apps before they are promoted back into product code.

## Rules

- Every exported component must have a visible demo in the catalog.
- Each component's co-located `*.SPEC.md` owns its current behavior and the
  consumer/product boundary. Source chronology and return work belong in Git
  and Score, not a parallel extraction diary.
- Components are presentational by default. Product state and app-specific API
  calls stay in consuming apps.
- The public surface is the `exports` map in `package.json`, enumerated one
  entry per module — never a `*` pattern. A component that owns a module file is
  documented at its own deep specifier (`emibs-ui-lib/components/<category>/
  <Name>`); the bare barrel is documented only for symbols with no owning
  component module. Consumers import through those specifiers, never through
  `emibs-ui-lib/src/**`. `npm run check:exports` fails the build when the map
  and the catalog's documented paths disagree in either direction.
- The catalog is deployed at `ui-lib.ayc.io` through the host reverse proxy.
- Branch normal work from `origin/score-work` and deliver it through a pull
  request with `base=score-work`.

## Deploy

- The catalog DOES auto-deploy: `emibs-deploy-agent` (stack `ui-lib`) rebuilds it
  from `origin/score-work` every five minutes whenever `packages/emibs-ui-lib/**`
  changed, and rolls back on a failed verify probe. Anything merged here reaches
  `https://ui-lib.ayc.io` unattended — assume that, and never merge a change whose
  deployed behaviour you have not decided on. (An earlier version of this file said
  the opposite; the deploy agent's stack registry is the truth.)
- A manual deploy is `docker compose build ui && docker compose up -d ui` from this
  package directory (the container publishes `127.0.0.1:8283`, proxied to
  `https://ui-lib.ayc.io`). The build context is the repository root — see
  `Dockerfile`.
- The container serves the built SPA through `bff/`, a small Go server holding a
  server-side session. Its access gate is **ON** (issue-2601): `docker-compose.yml`
  mounts `/apps/ui-lib/config/uif.json` and sets `UI_LIB_CONFIG_FILE`, so an
  anonymous caller gets `401` for the shell and every asset. `/health` and
  `/robots.txt` remain open deliberately. [`bff/README.md`](bff/README.md) owns
  the gate and its configuration.
- **The mounted config file must exist on the deploy host.** The BFF has no
  ungated mode (issue-2602): no `UI_LIB_CONFIG_FILE`, a missing or unparseable
  file, or a file without a complete `auth` group is a hard startup failure by
  design — it must never fall back to serving the catalogue publicly — so the
  container would fail its verify probe and roll back. The deploy agent's `ui-lib` probe is
  `/health` for the same reason: `/` answers `401` to an anonymous prober.
- The main checkout at `projects/emibs` is a shared, volatile tree (worker
  agents switch branches and leave uncommitted work in it). Never commit or
  deploy from it. Use a detached worktree instead:
  `git worktree add --detach <tmp> origin/score-work`, then build the exact
  reviewed `score-work` target from that worktree. Task changes use a separate
  task branch and pull request; never push directly to `score-work`.
- Verify a deploy live: `curl -s http://127.0.0.1:8283/` and confirm the
  hashed `index-*.js` bundle name changed, or grep the served bundle for a
  marker string from the change.

## Current instruction sources

- The component registry, co-located `*.SPEC.md` files, and catalog demos define the released UIF surface.
- [`SPEC.md`](SPEC.md) owns architecture and theme contracts; `docs/` contains concern-specific adoption and extraction instructions.
- Product behavior, persistence, routing, and service calls remain in consumers unless an owning current spec explicitly promotes them.
